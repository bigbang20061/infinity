--
-- PostgreSQL database dump
--

\restrict YRsu16LgzoPv7KAzu5Fj33FJlFZLvMZ2wubtmZ1xDRwIUVkkfuSjfauffHTIHYM

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: schoolmap; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.schoolmap (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: schoolmap; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.schoolmap (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "schoolID": 11, "solarSystemID": 30003489}
1	2	{"_key": 2, "schoolID": 12, "solarSystemID": 30005042}
2	3	{"_key": 3, "schoolID": 13, "solarSystemID": 30001672}
3	4	{"_key": 4, "schoolID": 14, "solarSystemID": 30002547}
4	5	{"_key": 5, "schoolID": 15, "solarSystemID": 30002505}
5	6	{"_key": 6, "schoolID": 16, "solarSystemID": 30003410}
6	7	{"_key": 7, "schoolID": 17, "solarSystemID": 30000141}
7	8	{"_key": 8, "schoolID": 18, "solarSystemID": 30001392}
8	9	{"_key": 9, "schoolID": 19, "solarSystemID": 30001407}
9	10	{"_key": 10, "schoolID": 20, "solarSystemID": 30004971}
10	11	{"_key": 11, "schoolID": 21, "solarSystemID": 30002715}
11	12	{"_key": 12, "schoolID": 22, "solarSystemID": 30005305}
\.


--
-- Name: schoolmap schoolmap_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.schoolmap
    ADD CONSTRAINT schoolmap_pkey PRIMARY KEY (row_no);


--
-- Name: schoolmap_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX schoolmap_key_idx ON sde_native.schoolmap USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict YRsu16LgzoPv7KAzu5Fj33FJlFZLvMZ2wubtmZ1xDRwIUVkkfuSjfauffHTIHYM

