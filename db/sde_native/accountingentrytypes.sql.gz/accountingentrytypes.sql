--
-- PostgreSQL database dump
--

\restrict qYk3jPfuh9hh4BlIyt84KpAx3PH2jjjOGMEh5pzGcwKlDmhhrgZDhS3qdJXlykZ

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accountingentrytypes; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.accountingentrytypes (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: accountingentrytypes; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.accountingentrytypes (row_no, key, data) FROM stdin;
0	0	{"_key": 0, "name": "Undefined", "description": "", "entryTypeNameID": 59792}
1	1	{"_key": 1, "name": "Player Trading", "description": "", "entryTypeNameID": 59793, "entryJournalMessageID": 234499}
2	2	{"_key": 2, "name": "Market Transaction", "description": "", "entryTypeNameID": 59794, "entryJournalMessageID": 234500}
3	3	{"_key": 3, "name": "GM Cash Transfer", "description": "", "entryTypeNameID": 59795, "entryJournalMessageID": 234502}
4	4	{"_key": 4, "name": "ATM Withdraw", "description": "", "entryTypeNameID": 59796}
5	5	{"_key": 5, "name": "ATM Deposit", "description": "", "entryTypeNameID": 59797}
6	6	{"_key": 6, "name": "Backward Compatible", "description": "", "entryTypeNameID": 59798}
7	7	{"_key": 7, "name": "Mission Reward", "description": "", "entryTypeNameID": 59799, "entryJournalMessageID": 234504}
8	8	{"_key": 8, "name": "Clone Activation", "description": "", "entryTypeNameID": 59800, "entryJournalMessageID": 234505}
9	9	{"_key": 9, "name": "Inheritance", "description": "", "entryTypeNameID": 59801, "entryJournalMessageID": 234507}
10	10	{"_key": 10, "name": "Player Donation", "description": "Player gave cash to another owner", "entryTypeNameID": 59802, "entryJournalMessageID": 234508, "entryTypeDescriptionID": 59719}
11	11	{"_key": 11, "name": "Corporation Payment", "description": "CEO or Accountant transferred cash  from corp. account", "entryTypeNameID": 59803, "entryTypeDescriptionID": 59720}
12	12	{"_key": 12, "name": "Docking Fee", "description": "", "entryTypeNameID": 59804, "entryJournalMessageID": 234511}
13	13	{"_key": 13, "name": "Office Rental Fee", "description": "", "entryTypeNameID": 59805, "entryJournalMessageID": 234512}
14	14	{"_key": 14, "name": "Factory Slot Rental Fee", "description": "", "entryTypeNameID": 59806, "entryJournalMessageID": 234513}
15	15	{"_key": 15, "name": "Repair Bill", "description": "", "entryTypeNameID": 59807, "entryJournalMessageID": 234527}
16	16	{"_key": 16, "name": "Bounty", "description": "Player gave cash to someone's  bounty pool", "entryTypeNameID": 59808, "entryTypeDescriptionID": 59721}
17	17	{"_key": 17, "name": "Bounty Prize", "description": "Player got bounty prize for killing someone", "entryTypeNameID": 59809, "entryTypeDescriptionID": 59722}
18	18	{"_key": 18, "name": "Agents_temporary", "description": "TEMP", "entryTypeNameID": 59810, "entryTypeDescriptionID": 59723}
19	19	{"_key": 19, "name": "Insurance", "description": "", "entryTypeNameID": 59811}
20	20	{"_key": 20, "name": "Mission Expiration", "description": "", "entryTypeNameID": 59812, "entryJournalMessageID": 234549}
21	21	{"_key": 21, "name": "Mission Completion", "description": "", "entryTypeNameID": 59813, "entryJournalMessageID": 234550}
22	22	{"_key": 22, "name": "Shares", "description": "", "entryTypeNameID": 59814, "entryJournalMessageID": 234551}
23	23	{"_key": 23, "name": "Courier Mission Escrow", "description": "", "entryTypeNameID": 59815, "entryJournalMessageID": 234552}
24	24	{"_key": 24, "name": "Mission Cost", "description": "", "entryTypeNameID": 59816, "entryJournalMessageID": 234553}
25	25	{"_key": 25, "name": "Agent Miscellaneous", "description": "Agent paid you", "entryTypeNameID": 59817, "entryJournalMessageID": 234514, "entryTypeDescriptionID": 59724}
26	26	{"_key": 26, "name": "LP Store", "description": "Payment to LP Store", "entryTypeNameID": 59818, "entryJournalMessageID": 234618, "entryTypeDescriptionID": 59725}
27	27	{"_key": 27, "name": "Agent Location Services", "description": "You paid agent to locate somebody", "entryTypeNameID": 59819, "entryJournalMessageID": 234521, "entryTypeDescriptionID": 59726}
28	28	{"_key": 28, "name": "Agent Donation", "description": "You donated/bribed the agent", "entryTypeNameID": 59820, "entryJournalMessageID": 234519, "entryTypeDescriptionID": 59727}
29	29	{"_key": 29, "name": "Agent Security Services", "description": "You paid agent to clean your rep", "entryTypeNameID": 59821, "entryJournalMessageID": 234520, "entryTypeDescriptionID": 59728}
30	30	{"_key": 30, "name": "Agent Mission Collateral Paid", "description": "You gave agent collateral for a mission", "entryTypeNameID": 59822, "entryJournalMessageID": 234517, "entryTypeDescriptionID": 59729}
31	31	{"_key": 31, "name": "Agent Mission Collateral Refunded", "description": "The agent returned collateral to you", "entryTypeNameID": 59823, "entryJournalMessageID": 234518, "entryTypeDescriptionID": 59730}
32	32	{"_key": 32, "name": "Agents_preward", "description": "The agent gave you this when you accepted the mission", "entryTypeNameID": 59824, "entryTypeDescriptionID": 59731}
33	33	{"_key": 33, "name": "Agent Mission Reward", "description": "The agent gave you this as a reward", "entryTypeNameID": 59825, "entryJournalMessageID": 234515, "entryTypeDescriptionID": 59732}
34	34	{"_key": 34, "name": "Agent Mission Time Bonus Reward", "description": "The agent gave you this as a special reward for fast mission completion", "entryTypeNameID": 59826, "entryJournalMessageID": 234516, "entryTypeDescriptionID": 59733}
35	35	{"_key": 35, "name": "CSPA", "description": "CONCORD Spam Prevention Act", "entryTypeNameID": 59827, "entryTypeDescriptionID": 59734}
36	36	{"_key": 36, "name": "CSPAOfflineRefund", "description": "Refunded CSPA charge because the other party was not online", "entryTypeNameID": 59828, "entryTypeDescriptionID": 59735}
37	37	{"_key": 37, "name": "Corporation Account Withdrawal", "description": "Withdrawal from corporation account", "entryTypeNameID": 59829, "entryTypeDescriptionID": 59736}
38	38	{"_key": 38, "name": "Corporation Dividend Payment", "description": "", "entryTypeNameID": 59830}
39	39	{"_key": 39, "name": "Corporation Registration Fee", "description": "", "entryTypeNameID": 59831, "entryJournalMessageID": 234565}
40	40	{"_key": 40, "name": "Corporation Logo Change Cost", "description": "", "entryTypeNameID": 59832}
41	41	{"_key": 41, "name": "Release Of Impounded Property", "description": "Charge for the receipt of goods from a corporation hangar that is no longer rented", "entryTypeNameID": 59833, "entryTypeDescriptionID": 59737}
42	42	{"_key": 42, "name": "Market Escrow", "description": "", "entryTypeNameID": 59834}
43	43	{"_key": 43, "name": "Agent Services Rendered", "description": "For miscellaneous services rendered by the agent", "entryTypeNameID": 59835, "entryTypeDescriptionID": 59738}
44	44	{"_key": 44, "name": "Market Fine Paid", "description": "", "entryTypeNameID": 59836, "entryJournalMessageID": 234501}
45	45	{"_key": 45, "name": "Corporation Liquidation", "description": "Funds from the liquidation of a corporation to a shareholder", "entryTypeNameID": 59837, "entryTypeDescriptionID": 59739}
46	46	{"_key": 46, "name": "Brokers Fee", "description": "", "entryTypeNameID": 59838}
47	47	{"_key": 47, "name": "Corporation Bulk Payment", "description": "A payment from a corporation", "entryTypeNameID": 59839, "entryTypeDescriptionID": 59740}
48	48	{"_key": 48, "name": "Alliance Registration Fee", "description": "", "entryTypeNameID": 59840, "entryJournalMessageID": 234575}
49	49	{"_key": 49, "name": "War Fee", "description": "", "entryTypeNameID": 59841}
50	50	{"_key": 50, "name": "Alliance Maintainance Fee", "description": "", "entryTypeNameID": 59842}
51	51	{"_key": 51, "name": "Contraband Fine", "description": "", "entryTypeNameID": 59843, "entryJournalMessageID": 234587}
52	52	{"_key": 52, "name": "Clone Transfer", "description": "", "entryTypeNameID": 59844, "entryJournalMessageID": 234506}
53	53	{"_key": 53, "name": "Acceleration Gate Fee", "description": "", "entryTypeNameID": 59845}
54	54	{"_key": 54, "name": "Transaction Tax", "description": "Sales tax paid to the SCC for any transaction", "entryTypeNameID": 59846, "entryJournalMessageID": 234580, "entryTypeDescriptionID": 59741}
55	55	{"_key": 55, "name": "Jump Clone Installation Fee", "description": "", "entryTypeNameID": 59847, "entryJournalMessageID": 234617}
56	56	{"_key": 56, "name": "Manufacturing", "description": "Installation and runtime cost for a manufacturing job", "entryTypeNameID": 59848, "entryJournalMessageID": 234588, "entryTypeDescriptionID": 59742}
57	57	{"_key": 57, "name": "Researching Technology", "description": "Installation and runtime cost for a technological research job", "entryTypeNameID": 59849, "entryJournalMessageID": 234589, "entryTypeDescriptionID": 59743}
58	58	{"_key": 58, "name": "Researching Time Productivity", "description": "Installation and runtime cost for a time productivity research job", "entryTypeNameID": 59850, "entryJournalMessageID": 234590, "entryTypeDescriptionID": 59744}
59	59	{"_key": 59, "name": "Researching Material Productivity", "description": "Installation and runtime cost for a material productivity research job", "entryTypeNameID": 59851, "entryJournalMessageID": 234591, "entryTypeDescriptionID": 59745}
60	60	{"_key": 60, "name": "Copying", "description": "Installation and runtime cost for a blueprint copying job", "entryTypeNameID": 59852, "entryJournalMessageID": 234592, "entryTypeDescriptionID": 59746}
61	61	{"_key": 61, "name": "Duplicating", "description": "Installation and runtime cost for an item duplication job", "entryTypeNameID": 59853, "entryTypeDescriptionID": 59747}
62	62	{"_key": 62, "name": "Reverse Engineering", "description": "Installation and runtime cost for a reverse engineering job", "entryTypeNameID": 59854, "entryJournalMessageID": 234593, "entryTypeDescriptionID": 59748}
63	63	{"_key": 63, "name": "Contract Auction Bid", "description": "A bid on an Auction", "entryTypeNameID": 59855, "entryJournalMessageID": 234594, "entryTypeDescriptionID": 59749}
64	64	{"_key": 64, "name": "Contract Auction Bid Refund", "description": "Auction Bid refund", "entryTypeNameID": 59856, "entryJournalMessageID": 234595, "entryTypeDescriptionID": 59750}
65	65	{"_key": 65, "name": "Contract Collateral", "description": "Collateral for a contract", "entryTypeNameID": 59857, "entryJournalMessageID": 234596, "entryTypeDescriptionID": 59751}
66	66	{"_key": 66, "name": "Contract Reward Refund", "description": "Reward refund for a cancelled contract", "entryTypeNameID": 59858, "entryJournalMessageID": 234597, "entryTypeDescriptionID": 59752}
67	67	{"_key": 67, "name": "Contract Auction Sold", "description": "Bid payout for an Auction contract", "entryTypeNameID": 59859, "entryJournalMessageID": 234598, "entryTypeDescriptionID": 59753}
68	68	{"_key": 68, "name": "Contract Reward", "description": "Reward for completing a contract", "entryTypeNameID": 59860, "entryJournalMessageID": 234599, "entryTypeDescriptionID": 59754}
69	69	{"_key": 69, "name": "Contract Collateral Refund", "description": "Refund of collateral for a Courier contract", "entryTypeNameID": 59861, "entryJournalMessageID": 234600, "entryTypeDescriptionID": 59755}
70	70	{"_key": 70, "name": "Contract Collateral Payout", "description": "Collateral Payout because of a failed contract", "entryTypeNameID": 59862, "entryJournalMessageID": 234601, "entryTypeDescriptionID": 59756}
71	71	{"_key": 71, "name": "Contract Price", "description": "Contract Price", "entryTypeNameID": 59863, "entryJournalMessageID": 234602, "entryTypeDescriptionID": 59757}
72	72	{"_key": 72, "name": "Contract Brokers Fee", "description": "Non-refundable contract tax", "entryTypeNameID": 59864, "entryJournalMessageID": 234603, "entryTypeDescriptionID": 59758}
73	73	{"_key": 73, "name": "Contract Sales Tax", "description": "Contract Tax for a successful contract", "entryTypeNameID": 59865, "entryJournalMessageID": 234604, "entryTypeDescriptionID": 59759}
74	74	{"_key": 74, "name": "Contract Deposit", "description": "Contract Deposit, refundable upon successful contract", "entryTypeNameID": 59866, "entryJournalMessageID": 234606, "entryTypeDescriptionID": 59760}
75	75	{"_key": 75, "name": "Contract Deposit Sales Tax", "description": "Contract Deposit Refund", "entryTypeNameID": 59867, "entryJournalMessageID": 234607, "entryTypeDescriptionID": 59761}
76	76	{"_key": 76, "name": "Secure EVE Time Code Exchange", "description": "Selling or buying of EVE Time Codes for ISK on secure.eve-online.com", "entryTypeNameID": 59868, "entryJournalMessageID": 234619, "entryTypeDescriptionID": 59762}
77	77	{"_key": 77, "name": "Contract Auction Bid (corp)", "description": "", "entryTypeNameID": 59869, "entryJournalMessageID": 234610}
78	78	{"_key": 78, "name": "Contract Collateral Deposited (corp)", "description": "", "entryTypeNameID": 59870, "entryJournalMessageID": 234611}
79	79	{"_key": 79, "name": "Contract Price Payment (corp)", "description": "", "entryTypeNameID": 59871, "entryJournalMessageID": 234612}
80	80	{"_key": 80, "name": "Contract Brokers Fee (corp)", "description": "", "entryTypeNameID": 59872, "entryJournalMessageID": 234613}
81	81	{"_key": 81, "name": "Contract Deposit (corp)", "description": "", "entryTypeNameID": 59873, "entryJournalMessageID": 234614}
82	82	{"_key": 82, "name": "Contract Deposit Refund", "description": "", "entryTypeNameID": 59874, "entryJournalMessageID": 234615}
83	83	{"_key": 83, "name": "Contract Reward Deposited", "description": "", "entryTypeNameID": 59875, "entryJournalMessageID": 234608}
84	84	{"_key": 84, "name": "Contract Reward Deposited (corp)", "description": "", "entryTypeNameID": 59876, "entryJournalMessageID": 234616}
85	85	{"_key": 85, "name": "Bounty Prizes", "description": "", "entryTypeNameID": 59877}
86	86	{"_key": 86, "name": "Advertisement Listing Fee", "description": "Creating a corporate recruitment advertisement", "entryTypeNameID": 59878, "entryJournalMessageID": 234567, "entryTypeDescriptionID": 59763}
87	87	{"_key": 87, "name": "Medal Creation", "description": "Medal was created", "entryTypeNameID": 59879, "entryJournalMessageID": 234620, "entryTypeDescriptionID": 59764}
88	88	{"_key": 88, "name": "Medal Issued", "description": "Medal was issued", "entryTypeNameID": 59880, "entryJournalMessageID": 234621, "entryTypeDescriptionID": 59765}
89	89	{"_key": 89, "name": "Betting", "description": "Minigame betting", "entryTypeNameID": 59881, "entryTypeDescriptionID": 59766}
90	90	{"_key": 90, "name": "DNA Modification Fee", "description": "Fee for attribute modification surgery", "entryTypeNameID": 59882, "entryJournalMessageID": 234622, "entryTypeDescriptionID": 59767}
91	91	{"_key": 91, "name": "Sovereignity bill", "description": "CONCORD sovereignity registrar fee", "entryTypeNameID": 59883, "entryTypeDescriptionID": 59768}
92	92	{"_key": 92, "name": "Bounty Prize Corporation Tax", "description": "", "entryTypeNameID": 59884, "entryJournalMessageID": 234554}
93	93	{"_key": 93, "name": "Agent Mission Reward Corporation Tax", "description": "", "entryTypeNameID": 59885, "entryJournalMessageID": 234555}
94	94	{"_key": 94, "name": "Agent Mission Time Bonus Reward Corporation Tax", "description": "", "entryTypeNameID": 59886, "entryJournalMessageID": 234556}
95	95	{"_key": 95, "name": "Upkeep adjustment fee", "description": "Upkeep cost of upgrade for remainder of current billing period", "entryTypeNameID": 59887, "entryTypeDescriptionID": 59769}
96	96	{"_key": 96, "name": "Planetary Import Tax", "description": "", "entryTypeNameID": 59888}
97	97	{"_key": 97, "name": "Planetary Export Tax", "description": "", "entryTypeNameID": 59889}
98	98	{"_key": 98, "name": "Planetary Construction", "description": "Construction on Planet", "entryTypeNameID": 59890, "entryTypeDescriptionID": 59770}
99	99	{"_key": 99, "name": "Corporate Reward Payout", "description": "Corporate reward awarded a player", "entryTypeNameID": 59891, "entryJournalMessageID": 234626, "entryTypeDescriptionID": 59771}
100	101	{"_key": 101, "name": "Bounty Surcharge", "description": "Surcharge on bounty because of local conditions.", "entryTypeNameID": 59893, "entryJournalMessageID": 234526, "entryTypeDescriptionID": 59773}
101	102	{"_key": 102, "name": "Contract Reversal", "description": "Contract Reversed by GM", "entryTypeNameID": 59894, "entryJournalMessageID": 234609, "entryTypeDescriptionID": 59774}
102	103	{"_key": 103, "name": "Corporate Reward Tax", "description": "", "entryTypeNameID": 59895, "entryJournalMessageID": 234557}
103	106	{"_key": 106, "name": "Store Purchase", "description": "Purchased something from the virtual goods store", "entryTypeNameID": 59898, "entryJournalMessageID": 234629, "entryTypeDescriptionID": 59777}
104	107	{"_key": 107, "name": "Store Purchase Refund", "description": "We refunded a purchase from the store", "entryTypeNameID": 59899, "entryJournalMessageID": 234630, "entryTypeDescriptionID": 59778}
105	108	{"_key": 108, "name": "PLEX sold for Aurum", "description": "Conversion of a PLEX to AURUM", "entryTypeNameID": 59900, "entryJournalMessageID": 234631, "entryTypeDescriptionID": 59779}
106	109	{"_key": 109, "name": "Lottery Give Away", "description": "This is Gift of cash to the players", "entryTypeNameID": 234494, "entryJournalMessageID": 234632, "entryTypeDescriptionID": 234493}
107	111	{"_key": 111, "name": "Aurum Token exchanged for Aur", "description": "The player has converted a aurum token for aurum.", "entryTypeNameID": 263475, "entryJournalMessageID": 261454, "entryTypeDescriptionID": 263478}
108	112	{"_key": 112, "name": "Datacore Fee", "description": "Player bought datacore(s) from agent", "entryTypeNameID": 277685, "entryJournalMessageID": 277692, "entryTypeDescriptionID": 277690}
109	113	{"_key": 113, "name": "War fee surrender", "description": "One entity surrendered from a war", "entryTypeNameID": 279064}
110	114	{"_key": 114, "name": "War ally contract", "description": "Entity offered its help in a war", "entryTypeNameID": 279063}
111	115	{"_key": 115, "name": "Bounty Reimbursement", "description": "Bounty was repaid", "entryTypeNameID": 285170, "entryJournalMessageID": 283461}
112	116	{"_key": 116, "name": "Kill Right Fee", "description": "Kill right bought", "entryTypeNameID": 285169}
113	117	{"_key": 117, "name": "Security Processing Fee", "description": "Tags traded for security status", "entryTypeNameID": 287844, "entryJournalMessageID": 570553}
114	118	{"_key": 118, "name": "Escrow for Industry Team Auction", "description": "Money taken into escrow for bid on an industry team", "entryTypeNameID": 503028, "entryJournalMessageID": 502898}
115	119	{"_key": 119, "name": "Reimbursement of escrow", "description": "Money reimbursed because your bid for industry team was not accepted", "entryTypeNameID": 503029, "entryJournalMessageID": 502899}
116	120	{"_key": 120, "name": "Industry Job Tax", "description": "Tax paid to facility owners for manufacturing Jobs", "entryTypeNameID": 503484, "entryJournalMessageID": 503483}
117	122	{"_key": 122, "name": "Infrastructure Hub maintenance", "description": "Maintenance fee for running an Infrastructure Hub (plus upgrades)", "entryTypeNameID": 507741}
118	123	{"_key": 123, "name": "Asset Safety recovery Tax", "description": "Tax paid for recovering assets from asset safety", "entryTypeNameID": 510859, "entryJournalMessageID": 570551}
119	124	{"_key": 124, "name": "Opportunity reward", "description": "Rewarded granted for finishing a whole opportunity", "entryTypeNameID": 514021, "entryJournalMessageID": 570555, "entryTypeDescriptionID": 514020}
120	125	{"_key": 125, "name": "Project Discovery reward", "description": "Reward granted for submitting a sample in Project Discovery", "entryTypeNameID": 515360, "entryJournalMessageID": 570557, "entryTypeDescriptionID": 515363}
121	126	{"_key": 126, "name": "Project Discovery Tax", "description": "Tax paid for rewards given by Project Discovery", "entryTypeNameID": 515396, "entryJournalMessageID": 570548}
122	127	{"_key": 127, "name": "Reprocessing Tax", "description": "Tax paid for reprocessing", "entryTypeNameID": 312131}
123	128	{"_key": 128, "name": "Jump Clone Activation Fee", "description": "Fee for activating a jump clone", "entryTypeNameID": 312132, "entryJournalMessageID": 516539, "entryTypeDescriptionID": 312133}
124	129	{"_key": 129, "name": "Operation Bonus", "description": "Operation Bonus from your Mentor", "entryTypeNameID": 522816, "entryJournalMessageID": 570554, "entryTypeDescriptionID": 522817}
125	131	{"_key": 131, "name": "Resource Wars Site Completion", "description": "Payment for assisting your faction in protecting valuable ore from pirates", "entryTypeNameID": 529365, "entryJournalMessageID": 570541, "entryTypeDescriptionID": 529366}
126	132	{"_key": 132, "name": "Duel Wager Escrow", "description": "Escrow payment for a duel wager", "entryTypeNameID": 530052, "entryJournalMessageID": 570542}
127	133	{"_key": 133, "name": "Duel Wager Payment", "description": "Reward for winning duel", "entryTypeNameID": 530053, "entryJournalMessageID": 570543}
128	134	{"_key": 134, "name": "Duel Wager Refund", "description": "Refunded duel wager", "entryTypeNameID": 530054, "entryJournalMessageID": 570544}
129	135	{"_key": 135, "name": "Reactions", "description": "Installation and runtime cost for a reaction job", "entryTypeNameID": 317046, "entryJournalMessageID": 530995, "entryTypeDescriptionID": 317047}
130	136	{"_key": 136, "name": "External Trade Freeze", "description": "Money is frozen by request of external trading service because it has been put on sale.", "entryTypeNameID": 531920, "entryJournalMessageID": 564314}
131	137	{"_key": 137, "name": "External Trade Thaw", "description": "Money is no longer frozen by request of external trading service.", "entryTypeNameID": 531921, "entryJournalMessageID": 564319}
132	138	{"_key": 138, "name": "External Trade Delivery", "description": "Money was sold between characters by external trading service.", "entryTypeNameID": 531922}
133	139	{"_key": 139, "name": "Season Challenge Reward", "description": "A reward for completing a seasonal event challenge.", "entryTypeNameID": 539336, "entryJournalMessageID": 570540, "entryTypeDescriptionID": 539337}
134	140	{"_key": 140, "name": "Structure Stargate Jump", "description": "Payment for using a privately owned stargate", "entryTypeNameID": 543036, "entryJournalMessageID": 570552, "entryTypeDescriptionID": 543037}
135	141	{"_key": 141, "name": "Skill Purchase", "description": "The player purchased a skill.", "entryTypeNameID": 543737, "entryJournalMessageID": 543653}
136	142	{"_key": 142, "name": "Item Trader Payment", "description": "A payment made in exchange for items from an item trader.", "entryTypeNameID": 545149, "entryJournalMessageID": 570550, "entryTypeDescriptionID": 545150}
137	143	{"_key": 143, "name": "Flux Ticket Sale", "description": "A payment for a flux ticket", "entryTypeNameID": 552172}
138	144	{"_key": 144, "name": "Flux Payout", "description": "A payment for a succesful flux", "entryTypeNameID": 552175}
139	145	{"_key": 145, "name": "Flux Tax", "description": "Tax for a succesful flux", "entryTypeNameID": 552173}
140	146	{"_key": 146, "name": "Flux Ticket Repayment", "description": "Ticket repayment for an expired flux", "entryTypeNameID": 552174}
141	147	{"_key": 147, "name": "Redeemed ISK token", "description": "The player redeemed an ISK token to their wallet", "entryTypeNameID": 552388, "entryJournalMessageID": 570549, "entryTypeDescriptionID": 552496}
142	148	{"_key": 148, "name": "Daily Challenge Completed", "description": "Reward for completing a daily challenge", "entryTypeNameID": 559010, "entryJournalMessageID": 570556, "entryTypeDescriptionID": 559001}
143	149	{"_key": 149, "name": "SCC surcharge", "description": "Tax paid by the player to the SCC when doing market trade in structures", "entryTypeNameID": 559228}
144	155	{"_key": 155, "name": "ESS Main Bank Autopayment", "description": "Payment made to player when autopayment timer expires and main bank has not been robbed", "entryTypeNameID": 571898, "entryJournalMessageID": 571899}
145	156	{"_key": 156, "name": "First Day ISK Bonus", "description": "Reward for  First Day ISK Bonus", "entryTypeNameID": 584301, "entryJournalMessageID": 584300}
146	157	{"_key": 157, "name": "Roguelike Unlock", "description": "Roguelike unlock shop Item", "entryTypeNameID": 589704, "entryJournalMessageID": 589706}
147	158	{"_key": 158, "name": "Roguelike Purchase", "description": "Roguelike Purchase Item", "entryTypeNameID": 589705, "entryJournalMessageID": 589707}
148	159	{"_key": 159, "name": "Roguelike Unlock Return", "description": "Roguelike unlock shop Item return", "entryTypeNameID": 597414, "entryJournalMessageID": 597413}
149	160	{"_key": 160, "name": "Rehabilitation Costs", "description": "Fees charged for MRT restoration and distribution", "entryTypeNameID": 609118, "entryJournalMessageID": 609117}
150	162	{"_key": 162, "name": "exchange shop cost", "description": "exchange shop cost", "entryTypeNameID": 610419, "entryJournalMessageID": 610420, "entryTypeDescriptionID": 610421}
151	164	{"_key": 164, "name": "Worldtask Mission Reward", "description": "Worldtask Mission Reward", "entryTypeNameID": 610846, "entryTypeDescriptionID": 610847}
152	166	{"_key": 166, "name": "Under constructions", "description": "Isk people get after depositing some items needed to build another item in space (using UnderConstruction spacecomponent)", "entryTypeNameID": 644856, "entryJournalMessageID": 644889, "entryTypeDescriptionID": 644855}
153	167	{"_key": 167, "name": "Alignment Based Gate Toll", "description": "Player was charged while using a gate with a alignmentBasedToll spacecomponent", "entryTypeNameID": 662530}
154	168	{"_key": 168, "name": "Alignment Based Zarzakh Stargate Toll", "description": "The ISK people get charged for using the external Jovian stargates to Zarzakh", "entryTypeNameID": 669909, "entryJournalMessageID": 669907, "entryTypeDescriptionID": 669908}
155	170	{"_key": 170, "name": "Corporation Projects Payment", "description": "Entry type is used for payments made related to corporation projects", "entryTypeNameID": 682461, "entryJournalMessageID": 682460}
156	171	{"_key": 171, "name": "TransferToMatrix", "description": "Transfer ISK to Matrix", "entryTypeNameID": 696386}
157	172	{"_key": 172, "name": "Insurgency corruption contribution ISK reward", "description": "ISK reward for pirate characters who contribute towards raising corruption during an Insurgency", "entryTypeNameID": 697061, "entryJournalMessageID": 697066}
158	173	{"_key": 173, "name": "Insurgency suppression contribution ISK reward", "description": "ISK reward for antipirate characters who contribute towards raising suppression during an Insurgency", "entryTypeNameID": 697062, "entryJournalMessageID": 697067}
159	174	{"_key": 174, "name": "Daily Goal Entry type", "description": "Entry type is used for payments made related to daily goals", "entryTypeNameID": 698549, "entryJournalMessageID": 699226}
160	175	{"_key": 175, "name": "Daily Goal tax Entry type", "description": "", "entryTypeNameID": 699236, "entryJournalMessageID": 699235}
161	176	{"_key": 176, "name": "BlueBirdIndustryFee", "description": "", "entryTypeNameID": 709523, "entryJournalMessageID": 709524, "entryTypeDescriptionID": 709525}
162	177	{"_key": 177, "name": "Mass Based Gate Toll", "description": "Player was charged while using a gate with a massBasedToll spacecomponent", "entryTypeNameID": 711366}
163	178	{"_key": 178, "name": "Cosmetic Market Component Item Purchase", "description": "Accounting entry for purchases of SKIN Component Items in the Cosmetic Market", "entryTypeNameID": 712104}
164	179	{"_key": 179, "name": "Cosmetic Market Skin Sale Broker Fee", "description": "Accounting entry for the broker fee paid when listing SKINs for sale on the Cosmetic Market", "entryTypeNameID": 720962}
165	180	{"_key": 180, "name": "Cosmetic Market Skin Purchase", "description": "Accounting entry for purchases of SKINs in the Cosmetic Market", "entryTypeNameID": 720963}
166	181	{"_key": 181, "name": "Cosmetic Market Skin Sale", "description": "Accounting entry for the sale of a SKIN on the Cosmetic Market", "entryTypeNameID": 720964}
167	182	{"_key": 182, "name": "Cosmetic Market Skin Sale Tax", "description": "Accounting entry for the tax paid on a sale of a SKIN on the Cosmetic Market", "entryTypeNameID": 720965}
168	183	{"_key": 183, "name": "Cosmetic Market Skin Transaction", "description": "Accounting entry for transactions of SKINs between players in the Cosmetic Market", "entryTypeNameID": 721956}
169	184	{"_key": 184, "name": "Fee for SovHub to claim a local Skyhook", "description": "Accounting entry for fee paid when a SovHub claims ownership of a Skyhook", "entryTypeNameID": 1010920, "entryJournalMessageID": 1010919}
170	185	{"_key": 185, "name": "Air Career Program Reward", "description": "Accounting entry for AIR Career Program goal rewards", "entryTypeNameID": 1011296, "entryJournalMessageID": 1011295}
171	186	{"_key": 186, "name": "Freelance Job Creation - Base Fee", "description": "Entry type is used for payments made when creating Freelance Jobs - for the base fee", "entryTypeNameID": 1011633, "entryJournalMessageID": 1011632}
172	187	{"_key": 187, "name": "Freelance Job Creation - Broadcasting Fee", "description": "Entry type is used for payments made when creating Freelance Jobs - for the broadcasting fee", "entryTypeNameID": 1011635, "entryJournalMessageID": 1011634}
173	188	{"_key": 188, "name": "Freelance Job Creation - Rewards Deposit", "description": "Entry type is used for payments made when creating Freelance Jobs - for the rewards deposit", "entryTypeNameID": 1011637, "entryJournalMessageID": 1011636}
174	189	{"_key": 189, "name": "Freelance Job Contribution Payouts", "description": "Entry type is used for payouts made when players contribute to Freelance Jobs", "entryTypeNameID": 1011653, "entryJournalMessageID": 1011652}
175	190	{"_key": 190, "name": "Freelance Job Closing Refunds", "description": "Entry type is used for refunds made when closing or expiring Freelance Jobs", "entryTypeNameID": 1011655, "entryJournalMessageID": 1011654}
176	191	{"_key": 191, "name": "Freelance Job Contribution Payouts Tax", "description": "Entry type is used for corporation tax on payouts made when players contribute to Freelance Jobs", "entryTypeNameID": 1014042, "entryJournalMessageID": 1014041}
177	192	{"_key": 192, "name": "PLEX Order Fee Cancellation Refund", "description": "Entry type is used for refunds when cancelling PLEX orders due to market policy changes", "entryTypeNameID": 1017441, "entryJournalMessageID": 1017440}
178	194	{"_key": 194, "name": "Market Security Tax", "description": "Tax charged", "entryTypeNameID": 1038647, "entryJournalMessageID": 1040039}
179	195	{"_key": 195, "name": "Npc Bounty security Tax", "description": "Bounty Security Tax", "entryTypeNameID": 1039203, "entryJournalMessageID": 1040003}
180	196	{"_key": 196, "name": "Industry Security Tax", "description": " Industry security tax charged in safe sec", "entryTypeNameID": 1039622, "entryJournalMessageID": 1040347}
181	197	{"_key": 197, "name": "AGENTMISSIONSECURITYTAX", "description": "placeholder", "entryTypeNameID": 1039790, "entryJournalMessageID": 1040953}
182	198	{"_key": 198, "name": "Achievement", "description": "Reward for reaching an achievement milestone", "entryTypeNameID": 1040362, "entryJournalMessageID": 1040364}
183	199	{"_key": 199, "name": "Achievement Category", "description": "Reward for reaching an achievement category milestone", "entryTypeNameID": 1040363, "entryJournalMessageID": 1040365}
184	200	{"_key": 200, "name": "CampaignObjectiveIskReward", "description": "The type of the ISK transaction for rewards for contributions to the campaign objectives", "entryTypeNameID": 1041757, "entryJournalMessageID": 1043870}
185	201	{"_key": 201, "name": "CampaignObjectiveIskRewardTax", "description": "The type of the ISK transaction for corporation tax on the rewards for contributions to the campaign objectives", "entryTypeNameID": 1046599, "entryJournalMessageID": 1046598}
186	10001	{"_key": 10001, "name": "Modify ISK", "description": "DUST - Modify ISK", "entryTypeNameID": 59901, "entryTypeDescriptionID": 59780}
187	10002	{"_key": 10002, "name": "Primary Marketplace Purchase", "description": "DUST - Primary Marketplace Purchase", "entryTypeNameID": 59902, "entryTypeDescriptionID": 59781}
188	10003	{"_key": 10003, "name": "Battle Reward", "description": "DUST - Battle Reward", "entryTypeNameID": 59903, "entryTypeDescriptionID": 59782}
189	10004	{"_key": 10004, "name": "New Character Starting Funds", "description": "DUST - New Character Starting Funds", "entryTypeNameID": 59904, "entryTypeDescriptionID": 59783}
190	10005	{"_key": 10005, "name": "Corporation Account Withdrawal", "description": "DUST - Corporation Account Withdrawal", "entryTypeNameID": 59905, "entryTypeDescriptionID": 59784}
191	10006	{"_key": 10006, "name": "Corporation Account Deposit", "description": "DUST - Corporation Account Deposit", "entryTypeNameID": 59906, "entryTypeDescriptionID": 59785}
192	10007	{"_key": 10007, "name": "Battle WP Win Reward", "description": "DUST - Battle Reward", "entryTypeNameID": 59907, "entryTypeDescriptionID": 59786}
193	10008	{"_key": 10008, "name": "Battle WP Loss Reward", "description": "DUST - Battle Reward", "entryTypeNameID": 59908, "entryTypeDescriptionID": 59787}
194	10009	{"_key": 10009, "name": "Battle Win Reward", "description": "DUST - Battle Reward", "entryTypeNameID": 59909, "entryTypeDescriptionID": 59788}
195	10010	{"_key": 10010, "name": "Battle Loss Reward", "description": "DUST - Battle Reward", "entryTypeNameID": 59910, "entryTypeDescriptionID": 59789}
196	10011	{"_key": 10011, "name": "Reset ISK for Character Reset", "description": "DUST - ISK set to initial level for a character reset", "entryTypeNameID": 570207}
197	10012	{"_key": 10012, "name": "District Contract Deposit", "description": "DUST - District Contract Deposit", "entryTypeNameID": 283741, "entryTypeDescriptionID": 283746}
198	10013	{"_key": 10013, "name": "District Contract Deposit Refund", "description": "DUST - District Contract Deposit Refund", "entryTypeNameID": 283742, "entryTypeDescriptionID": 283747}
199	10014	{"_key": 10014, "name": "District Contract Collateral", "description": "DUST - District Contract Collateral", "entryTypeNameID": 283743, "entryTypeDescriptionID": 283748}
200	10015	{"_key": 10015, "name": "District Contract Collateral Refund", "description": "DUST - District Contract Collateral Refund", "entryTypeNameID": 283744, "entryTypeDescriptionID": 283749}
201	10016	{"_key": 10016, "name": "District Contract Reward", "description": "DUST - District Contract Reward", "entryTypeNameID": 283745, "entryTypeDescriptionID": 283750}
202	10017	{"_key": 10017, "name": "District Clone Transportation", "description": "DUST - District Clone Transportation", "entryTypeNameID": 287027, "entryTypeDescriptionID": 287028}
203	10018	{"_key": 10018, "name": "District Clone Transportation Refund", "description": "DUST - District Clone Transportation Refund", "entryTypeNameID": 287029, "entryTypeDescriptionID": 287030}
204	10019	{"_key": 10019, "name": "District Infrastructure", "description": "DUST - District Infrastructure", "entryTypeNameID": 287031, "entryTypeDescriptionID": 287032}
205	10020	{"_key": 10020, "name": "District Clone Sales", "description": "DUST - District Clone Sales", "entryTypeNameID": 287033, "entryTypeDescriptionID": 287034}
206	10021	{"_key": 10021, "name": "District Clone Purchase", "description": "DUST - District Clone Purchase", "entryTypeNameID": 287035, "entryTypeDescriptionID": 287036}
207	10022	{"_key": 10022, "name": "Biomass Reward", "description": "DUST - Biomass Reward", "entryTypeNameID": 288205, "entryTypeDescriptionID": 288206}
208	10023	{"_key": 10023, "name": "ISK Swap Reward", "description": "DUST - ISK Swap Reward", "entryTypeNameID": 306849, "entryTypeDescriptionID": 306850}
209	11001	{"_key": 11001, "name": "Modify AUR", "description": "DUST - Modify AUR", "entryTypeNameID": 59911, "entryTypeDescriptionID": 59790}
210	11002	{"_key": 11002, "name": "Respec payment", "description": "DUST - Respec payment", "entryTypeNameID": 59912, "entryTypeDescriptionID": 59791}
211	11003	{"_key": 11003, "name": "Entitlement", "description": "DUST - AUR awarded as part of consuming a PSN entitlement", "entryTypeNameID": 570204}
212	11004	{"_key": 11004, "name": "Reset Reimbursement", "description": "DUST - AUR reimbursed after a character reset", "entryTypeNameID": 570205}
213	11005	{"_key": 11005, "name": "Reset AUR for Character Reset", "description": "DUST - AUR set to zero for a character reset", "entryTypeNameID": 570206}
214	12001	{"_key": 12001, "name": "Daily mission CP", "description": "DUST - CP from daily mission", "entryTypeNameID": 505817, "entryTypeDescriptionID": 505818}
215	12002	{"_key": 12002, "name": "Warbarge CP", "description": "DUST - CP from warbarge", "entryTypeNameID": 505819, "entryTypeDescriptionID": 505820}
216	12003	{"_key": 12003, "name": "Donate CP", "description": "DUST - CP from donation", "entryTypeNameID": 505821, "entryTypeDescriptionID": 505822}
217	12004	{"_key": 12004, "name": "Use CP for clone packs", "description": "DUST - Use CP to buy clone packs", "entryTypeNameID": 505823, "entryTypeDescriptionID": 570203}
218	12005	{"_key": 12005, "name": "Use CP for moving clones", "description": "DUST - Use CP to move clones", "entryTypeNameID": 505825, "entryTypeDescriptionID": 505826}
219	12006	{"_key": 12006, "name": "Use CP for selling clones", "description": "DUST - Use CP to sell clones", "entryTypeNameID": 505829, "entryTypeDescriptionID": 505830}
220	12007	{"_key": 12007, "name": "Use CP for changing reinforcement", "description": "DUST - Use CP to change reinforcement", "entryTypeNameID": 505827, "entryTypeDescriptionID": 505828}
221	12008	{"_key": 12008, "name": "Use CP for changing surface infrastructure", "description": "DUST - Use CP to change surface infrastructure", "entryTypeNameID": 505831, "entryTypeDescriptionID": 505832}
222	13001	{"_key": 13001, "name": "Daily mission DK", "description": "DUST - DK from daily mission", "entryTypeNameID": 505873, "entryTypeDescriptionID": 505874}
223	13002	{"_key": 13002, "name": "Planetary conquest DK", "description": "DUST - DK from planetary conquest", "entryTypeNameID": 505875, "entryTypeDescriptionID": 505876}
224	13003	{"_key": 13003, "name": "Use DK for purchasing items", "description": "DUST - Use DK to purchase items", "entryTypeNameID": 505877, "entryTypeDescriptionID": 505878}
225	13004	{"_key": 13004, "name": "Use DK for rerolling market", "description": "DUST - Use DK to reroll market", "entryTypeNameID": 505879, "entryTypeDescriptionID": 505880}
226	13005	{"_key": 13005, "name": "Selling Clones DK", "description": "DUST - DK from selling clones", "entryTypeNameID": 505960, "entryTypeDescriptionID": 505961}
\.


--
-- Name: accountingentrytypes accountingentrytypes_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.accountingentrytypes
    ADD CONSTRAINT accountingentrytypes_pkey PRIMARY KEY (row_no);


--
-- Name: accountingentrytypes_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX accountingentrytypes_key_idx ON sde_native.accountingentrytypes USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict qYk3jPfuh9hh4BlIyt84KpAx3PH2jjjOGMEh5pzGcwKlDmhhrgZDhS3qdJXlykZ

