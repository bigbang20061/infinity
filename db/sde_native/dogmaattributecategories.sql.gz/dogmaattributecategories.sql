--
-- PostgreSQL database dump
--

\restrict BDJOrcaJqxv7fF9FeDln1S5V0bebsuWSG0xeYJXdwbWEcgj0CdSDMn2c7Ygl376

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dogmaattributecategories; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.dogmaattributecategories (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: dogmaattributecategories; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.dogmaattributecategories (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "name": "Fitting", "description": "Fitting capabilities of a ship"}
1	2	{"_key": 2, "name": "Shield", "description": "Shield attributes of ships"}
2	3	{"_key": 3, "name": "Armor", "description": "Armor attributes of ships"}
3	4	{"_key": 4, "name": "Structure", "description": "Structure attributes of ships"}
4	5	{"_key": 5, "name": "Capacitor", "description": "Capacitor attributes for ships"}
5	6	{"_key": 6, "name": "Targeting", "description": "Targeting Attributes for ships"}
6	7	{"_key": 7, "name": "Miscellaneous", "description": "Misc. attributes"}
7	8	{"_key": 8, "name": "Required Skills", "description": "Skill requirements"}
8	9	{"_key": 9, "name": "NULL", "description": "Attributes already checked and not going into a category"}
9	10	{"_key": 10, "name": "Drones", "description": "All you need to know about drones"}
10	12	{"_key": 12, "name": "AI", "description": "Attribs for the AI configuration"}
11	17	{"_key": 17, "name": "Speed and Travel", "description": "Attributes used for velocity, speed and such"}
12	19	{"_key": 19, "name": "Loot", "description": "Attributes that affect loot drops"}
13	20	{"_key": 20, "name": "Remote Assistance", "description": "Remote shield transfers, armor, structure and such  "}
14	21	{"_key": 21, "name": "EW - Target Painting", "description": "NPC Target Painting Attributes"}
15	22	{"_key": 22, "name": "EW - Energy Neutralizing", "description": "NPC Energy Neutralizing Attributes"}
16	23	{"_key": 23, "name": "EW - Remote Electronic Counter Measures", "description": "NPC Remote Electronic Counter Measures Attributes"}
17	24	{"_key": 24, "name": "EW - Sensor Dampening", "description": "NPC Sensor Dampening Attributes"}
18	25	{"_key": 25, "name": "EW - Target Jamming", "description": "NPC Target Jamming Attributes"}
19	26	{"_key": 26, "name": "EW - Tracking Disruption", "description": "NPC Tracking Disruption Attributes"}
20	27	{"_key": 27, "name": "EW - Warp Scrambling", "description": "NPC Warp Scrambling Attributes"}
21	28	{"_key": 28, "name": "EW - Webbing", "description": "NPC Stasis Webbing  Attributes"}
22	29	{"_key": 29, "name": "Turrets", "description": "NPC Turrets Attributes"}
23	30	{"_key": 30, "name": "Missile", "description": "NPC Missile Attributes"}
24	31	{"_key": 31, "name": "Graphics", "description": "NPC Graphic Attributes"}
25	32	{"_key": 32, "name": "Entity Rewards", "description": "NPC Entity Rewards Attributes"}
26	33	{"_key": 33, "name": "Entity Extra Attributes", "description": "NPC Extra Attributes"}
27	34	{"_key": 34, "name": "Fighter Abilities", "description": "Fighter abilities are like built-in modules on fighters"}
28	36	{"_key": 36, "name": "EW - Resistance", "description": "Resistances to different types of EWar Effects"}
29	37	{"_key": 37, "name": "Bonuses", "description": "Bonuses"}
30	38	{"_key": 38, "name": "Fighter Attributes", "description": "Attributes related to fighters (but not abilities)"}
31	39	{"_key": 39, "name": "Superweapons", "description": "Attributes relating to Doomsdays and Superweapons"}
32	40	{"_key": 40, "name": "Hangars & Bays", "description": "Hangars & Bays"}
33	41	{"_key": 41, "name": "On Death", "description": "Attributes relating to the death of a ship"}
34	42	{"_key": 42, "name": "Behavior Attributes", "description": "NPC Behavior Attributes"}
35	51	{"_key": 51, "name": "Mining", "description": "Mining related attributes"}
36	52	{"_key": 52, "name": "Heat"}
37	55	{"_key": 55, "name": "Life", "description": "Item service life"}
38	56	{"_key": 56, "name": "Ship Adaption", "description": "Ship Adaption related attributes"}
39	57	{"_key": 57, "name": "Cloud Computing", "description": "Cloud Computing related attributes"}
\.


--
-- Name: dogmaattributecategories dogmaattributecategories_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.dogmaattributecategories
    ADD CONSTRAINT dogmaattributecategories_pkey PRIMARY KEY (row_no);


--
-- Name: dogmaattributecategories_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX dogmaattributecategories_key_idx ON sde_native.dogmaattributecategories USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict BDJOrcaJqxv7fF9FeDln1S5V0bebsuWSG0xeYJXdwbWEcgj0CdSDMn2c7Ygl376

