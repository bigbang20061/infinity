--
-- PostgreSQL database dump
--

\restrict ze6heL5eueCmOfahjTLpaducppbFvqnEatFO5mSrcWeU1ZmURg6y8AOT0Nobgc0

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: schools; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.schools (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: schools; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.schools (row_no, key, data) FROM stdin;
0	11	{"_key": 11, "iconID": 1447, "nameID": 60004, "raceID": 4, "titleID": 572103, "careerID": 41, "careerAgents": [3018921, 3019338, 3019339, 3019446, 3019469], "corporationID": 1000166, "descriptionID": 59989, "startingStations": [60015154, 60015021, 60015022, 60015023, 60015024], "characterDescriptionID": 572211}
1	12	{"_key": 12, "iconID": 1448, "nameID": 60005, "raceID": 4, "titleID": 572104, "careerID": 44, "careerAgents": [3018930, 3019348, 3019349, 3019445, 3019468], "corporationID": 1000165, "descriptionID": 59990, "startingStations": [60015155, 60015017, 60015018, 60015019, 60015020], "characterDescriptionID": 572213}
2	13	{"_key": 13, "iconID": 1449, "nameID": 60006, "raceID": 4, "titleID": 572105, "careerID": 47, "careerAgents": [3018924, 3019336, 3019337, 3019447, 3019470], "corporationID": 1000077, "descriptionID": 59991, "startingStations": [60015156, 60015009, 60015010, 60015011, 60015012], "characterDescriptionID": 572214}
3	14	{"_key": 14, "iconID": 1450, "nameID": 60007, "raceID": 2, "titleID": 572106, "careerID": 21, "careerAgents": [3018920, 3019344, 3019345, 3019454, 3019477], "corporationID": 1000170, "descriptionID": 59992, "startingStations": [60015162, 60015037, 60015038, 60015039, 60015040], "characterDescriptionID": 572216}
4	15	{"_key": 15, "iconID": 1451, "nameID": 60008, "raceID": 2, "titleID": 572107, "careerID": 27, "careerAgents": [3018927, 3019342, 3019343, 3019455, 3019478], "corporationID": 1000171, "descriptionID": 59993, "startingStations": [60015164, 60015041, 60015042, 60015043, 60015044], "characterDescriptionID": 572217}
5	16	{"_key": 16, "iconID": 1458, "nameID": 60009, "raceID": 2, "titleID": 572108, "careerID": 24, "careerAgents": [3018932, 3019346, 3019347, 3019456, 3019479], "corporationID": 1000172, "descriptionID": 59994, "startingStations": [60015163, 60015045, 60015046, 60015047, 60015048], "characterDescriptionID": 572218}
6	17	{"_key": 17, "iconID": 1452, "nameID": 60010, "raceID": 1, "titleID": 572109, "careerID": 11, "careerAgents": [3018935, 3019352, 3019353, 3019449, 3019472], "corporationID": 1000167, "descriptionID": 59995, "startingStations": [60015157, 60015025, 60015026, 60015027, 60015028], "characterDescriptionID": 572219}
7	18	{"_key": 18, "iconID": 1453, "nameID": 60011, "raceID": 1, "titleID": 572110, "careerID": 14, "careerAgents": [3018929, 3019354, 3019355, 3019450, 3019473], "corporationID": 1000045, "descriptionID": 59996, "startingStations": [60015159, 60015005, 60015006, 60015007, 60015008], "characterDescriptionID": 572220}
8	19	{"_key": 19, "iconID": 1455, "nameID": 60012, "raceID": 1, "titleID": 572111, "careerID": 17, "careerAgents": [3018938, 3019370, 3019371, 3019448, 3019471], "corporationID": 1000044, "descriptionID": 59997, "startingStations": [60015158, 60015001, 60015002, 60015003, 60015004], "characterDescriptionID": 572221}
9	20	{"_key": 20, "iconID": 1454, "nameID": 60013, "raceID": 8, "titleID": 572112, "careerID": 81, "careerAgents": [3018923, 3019334, 3019335, 3019453, 3019476], "corporationID": 1000168, "descriptionID": 59998, "startingStations": [60015160, 60015029, 60015030, 60015031, 60015032], "characterDescriptionID": 572222}
10	21	{"_key": 21, "iconID": 1456, "nameID": 60014, "raceID": 8, "titleID": 572113, "careerID": 84, "careerAgents": [3018931, 3019340, 3019341, 3019451, 3019474], "corporationID": 1000115, "descriptionID": 59999, "startingStations": [60015153, 60015013, 60015014, 60015015, 60015016], "characterDescriptionID": 572223}
11	22	{"_key": 22, "iconID": 1457, "nameID": 60015, "raceID": 8, "titleID": 572114, "careerID": 87, "careerAgents": [3018926, 3019332, 3019333, 3019452, 3019475], "corporationID": 1000169, "descriptionID": 60000, "startingStations": [60015161, 60015033, 60015034, 60015035, 60015036], "characterDescriptionID": 572224}
12	23	{"_key": 23, "nameID": 60016, "raceID": 16, "careerID": 161, "corporationID": 1000131, "descriptionID": 60001}
13	24	{"_key": 24, "nameID": 60017, "raceID": 16, "careerID": 164, "corporationID": 1000177, "descriptionID": 60002}
14	25	{"_key": 25, "nameID": 60018, "raceID": 16, "careerID": 167, "corporationID": 1000178, "descriptionID": 60003}
15	31	{"_key": 31, "iconID": 1448, "nameID": 1036363, "raceID": 4, "titleID": 1036364, "careerID": 44, "careerAgents": [3020203, 3020207, 3020206, 3020205, 3020204], "corporationID": 1000165, "startingStations": [60015157], "characterDescriptionID": 1036362, "is_starter_space_school": 1}
16	32	{"_key": 32, "iconID": 1449, "nameID": 1036439, "raceID": 4, "titleID": 1036440, "careerID": 47, "careerAgents": [3020210, 3020211, 3020212, 3020208, 3020209], "corporationID": 1000077, "startingStations": [60015153], "is_starter_space_school": 1}
17	33	{"_key": 33, "iconID": 1451, "nameID": 1036441, "raceID": 2, "titleID": 1036442, "careerID": 27, "careerAgents": [3020229, 3020230, 3020228, 3020231, 3020232], "corporationID": 1000171, "startingStations": [60015156], "is_starter_space_school": 1}
18	34	{"_key": 34, "iconID": 1458, "nameID": 1036445, "raceID": 2, "titleID": 1036446, "careerID": 24, "careerAgents": [3020224, 3020225, 3020226, 3020223, 3020227], "corporationID": 1000172, "startingStations": [60015154], "is_starter_space_school": 1}
19	35	{"_key": 35, "iconID": 1453, "nameID": 1036447, "raceID": 1, "titleID": 1036448, "careerID": 14, "careerAgents": [3020178, 3020181, 3020179, 3020180, 3020182], "corporationID": 1000045, "startingStations": [60015159], "is_starter_space_school": 1}
20	36	{"_key": 36, "iconID": 1455, "nameID": 1036449, "raceID": 1, "titleID": 1036450, "careerID": 17, "careerAgents": [3020198, 3020200, 3020202, 3020199, 3020201], "corporationID": 1000044, "startingStations": [60015164], "is_starter_space_school": 1}
21	37	{"_key": 37, "iconID": 1456, "nameID": 1036455, "raceID": 8, "titleID": 1036456, "careerID": 84, "careerAgents": [3020222, 3020219, 3020218, 3020220, 3020221], "corporationID": 1000115, "startingStations": [60015160], "is_starter_space_school": 1}
22	38	{"_key": 38, "iconID": 1457, "nameID": 1036457, "raceID": 8, "titleID": 1036458, "careerID": 87, "careerAgents": [3020217, 3020216, 3020215, 3020213, 3020214], "corporationID": 1000169, "startingStations": [60015163], "is_starter_space_school": 1}
\.


--
-- Name: schools schools_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.schools
    ADD CONSTRAINT schools_pkey PRIMARY KEY (row_no);


--
-- Name: schools_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX schools_key_idx ON sde_native.schools USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict ze6heL5eueCmOfahjTLpaducppbFvqnEatFO5mSrcWeU1ZmURg6y8AOT0Nobgc0

