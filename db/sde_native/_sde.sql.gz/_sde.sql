--
-- PostgreSQL database dump
--

\restrict qxFnWmc6Wio2e3R15Jk9DxipwZVbXQEmOobGbv3dsVS4mrgS1XLXnmcbN9FTxUa

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _sde; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native._sde (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: _sde; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native._sde (row_no, key, data) FROM stdin;
0	\N	{"source": "client", "bundleName": "eve-online-client-static-data-3653293-jsonl", "clientBuild": "3653293", "generatedAt": "2026-10-27T00:50:27.764795Z", "datasetCount": 278, "resourceCount": 268, "resourceRoots": ["res:/staticdata/", "res:/localizationfsd/"], "decodeFailureCount": 0}
\.


--
-- Name: _sde _sde_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native._sde
    ADD CONSTRAINT _sde_pkey PRIMARY KEY (row_no);


--
-- Name: _sde_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX _sde_key_idx ON sde_native._sde USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict qxFnWmc6Wio2e3R15Jk9DxipwZVbXQEmOobGbv3dsVS4mrgS1XLXnmcbN9FTxUa

