--
-- PostgreSQL database dump
--

\restrict KdMO0iobbNxqeaXglemhOmW7JsxpZsEHrQO2fetPGMsYSgL3QnsYhBBFYUbAgni

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: stationservices; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.stationservices (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: stationservices; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.stationservices (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "serviceNameID": 61496}
1	2	{"_key": 2, "serviceNameID": 61497}
2	3	{"_key": 3, "serviceNameID": 61498}
3	4	{"_key": 4, "serviceNameID": 61499}
4	5	{"_key": 5, "serviceNameID": 61500}
5	6	{"_key": 6, "serviceNameID": 61501}
6	7	{"_key": 7, "serviceNameID": 61502}
7	8	{"_key": 8, "serviceNameID": 61503}
8	9	{"_key": 9, "serviceNameID": 61504}
9	10	{"_key": 10, "serviceNameID": 61505}
10	11	{"_key": 11, "serviceNameID": 61506}
11	12	{"_key": 12, "serviceNameID": 61507}
12	13	{"_key": 13, "serviceNameID": 61508}
13	14	{"_key": 14, "serviceNameID": 61509}
14	15	{"_key": 15, "serviceNameID": 61510}
15	16	{"_key": 16, "serviceNameID": 61511}
16	17	{"_key": 17, "serviceNameID": 61512}
17	18	{"_key": 18, "serviceNameID": 61513}
18	19	{"_key": 19, "serviceNameID": 61514}
19	20	{"_key": 20, "serviceNameID": 61515}
20	21	{"_key": 21, "descriptionID": 61495, "serviceNameID": 61516}
21	22	{"_key": 22, "serviceNameID": 61517}
22	23	{"_key": 23, "serviceNameID": 61518}
23	24	{"_key": 24, "serviceNameID": 61519}
24	25	{"_key": 25, "serviceNameID": 61520}
25	26	{"_key": 26, "serviceNameID": 61521}
26	27	{"_key": 27, "serviceNameID": 568978}
27	55	{"_key": 55, "serviceNameID": 623527}
\.


--
-- Name: stationservices stationservices_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.stationservices
    ADD CONSTRAINT stationservices_pkey PRIMARY KEY (row_no);


--
-- Name: stationservices_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX stationservices_key_idx ON sde_native.stationservices USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict KdMO0iobbNxqeaXglemhOmW7JsxpZsEHrQO2fetPGMsYSgL3QnsYhBBFYUbAgni

