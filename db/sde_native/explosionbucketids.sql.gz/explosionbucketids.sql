--
-- PostgreSQL database dump
--

\restrict czyyOHPyMLLtY6sTChKXf8avqkQQn7EvNIvIGb1gF3RX47xrLzQHpdujQk7EpOV

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: explosionbucketids; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.explosionbucketids (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: explosionbucketids; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.explosionbucketids (row_no, key, data) FROM stdin;
0	3	{"_key": 3, "racialExplosions": {"default": [{"localScale": 1.27, "explosionID": "generic_structure_large_explosion", "globalScale": 14.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
1	4	{"_key": 4, "racialExplosions": {"default": [{"localScale": 1.0, "explosionID": "generic_structure_medium_explosion", "globalScale": 7.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
2	5	{"_key": 5, "racialExplosions": {"default": [{"localScale": 0.42, "explosionID": "generic_structure_extra_large_explosion", "globalScale": 110.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
3	11	{"_key": 11, "racialExplosions": {"default": [{"localScale": 1.5, "explosionID": "generic_explosive_Long_01a", "globalScale": 3.0, "chanceMultiplier": 3, "localExplosionCount": -1}, {"localScale": 1.5, "explosionID": "generic_explosive_Long_01b", "globalScale": 3.0, "chanceMultiplier": 3, "localExplosionCount": -1}, {"localScale": 1.5, "explosionID": "generic_explosive_Long_01c", "globalScale": 3.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
4	12	{"_key": 12, "racialExplosions": {"default": [{"localScale": 1.0, "explosionID": "generic_explosive_01a", "globalScale": 0.225, "chanceMultiplier": 6, "localExplosionCount": 42}, {"localScale": 1.0, "explosionID": "generic_explosive_01b", "globalScale": 0.28, "chanceMultiplier": 4, "localExplosionCount": 42}, {"localScale": 1.0, "explosionID": "generic_explosive_01c", "globalScale": 0.2, "chanceMultiplier": 1, "localExplosionCount": 42}]}}
5	13	{"_key": 13, "racialExplosions": {"default": [{"localScale": 0.4, "explosionID": "generic_explosive_01a", "globalScale": 0.25, "chanceMultiplier": 5, "localExplosionCount": 28}, {"localScale": 0.4, "explosionID": "generic_explosive_01b", "globalScale": 0.3, "chanceMultiplier": 4, "localExplosionCount": 28}, {"localScale": 0.4, "explosionID": "generic_explosive_01c", "globalScale": 0.4, "chanceMultiplier": 1, "localExplosionCount": 28}]}}
6	14	{"_key": 14, "racialExplosions": {"default": [{"localScale": 0.42, "explosionID": "generic_explosive_01a", "globalScale": 0.35, "chanceMultiplier": 5, "localExplosionCount": 32}, {"localScale": 0.42, "explosionID": "generic_explosive_01b", "globalScale": 0.35, "chanceMultiplier": 4, "localExplosionCount": 32}, {"localScale": 0.42, "explosionID": "generic_explosive_01c", "globalScale": 0.35, "chanceMultiplier": 1, "localExplosionCount": 32}]}}
7	15	{"_key": 15, "racialExplosions": {"default": [{"localScale": 0.3, "explosionID": "generic_explosive_01a", "globalScale": 0.375, "chanceMultiplier": 5, "localExplosionCount": 28}, {"localScale": 0.5, "explosionID": "generic_explosive_01b", "globalScale": 0.325, "chanceMultiplier": 4, "localExplosionCount": 28}, {"localScale": 0.5, "explosionID": "generic_explosive_01c", "globalScale": 0.3, "chanceMultiplier": 1, "localExplosionCount": 28}]}}
8	16	{"_key": 16, "racialExplosions": {"default": [{"localScale": 0.3, "explosionID": "generic_explosive_01a", "globalScale": 0.325, "chanceMultiplier": 5, "localExplosionCount": 24}, {"localScale": 0.32, "explosionID": "generic_explosive_01b", "globalScale": 0.325, "chanceMultiplier": 4, "localExplosionCount": 24}, {"localScale": 0.32, "explosionID": "generic_explosive_01c", "globalScale": 0.3, "chanceMultiplier": 1, "localExplosionCount": 24}]}}
9	17	{"_key": 17, "racialExplosions": {"default": [{"localScale": 0.32, "explosionID": "generic_explosive_01a", "globalScale": 0.25, "chanceMultiplier": 5, "localExplosionCount": 14}, {"localScale": 0.3, "explosionID": "generic_explosive_01b", "globalScale": 0.25, "chanceMultiplier": 4, "localExplosionCount": 14}, {"localScale": 0.42, "explosionID": "generic_explosive_01c", "globalScale": 0.3, "chanceMultiplier": 1, "localExplosionCount": 10}]}}
10	18	{"_key": 18, "racialExplosions": {"default": [{"localScale": 0.55, "explosionID": "generic_explosive_short_01a", "globalScale": 0.05, "chanceMultiplier": 3, "localExplosionCount": 3}, {"localScale": 0.75, "explosionID": "generic_explosive_short_01b", "globalScale": 0.075, "chanceMultiplier": 2, "localExplosionCount": 3}]}}
11	19	{"_key": 19, "racialExplosions": {"default": [{"localScale": 0.55, "explosionID": "generic_explosive_short_01a", "globalScale": 0.04, "chanceMultiplier": 3, "localExplosionCount": 3}, {"localScale": 0.55, "explosionID": "generic_explosive_short_01b", "globalScale": 0.04, "chanceMultiplier": 2, "localExplosionCount": 3}]}}
12	20	{"_key": 20, "racialExplosions": {"default": [{"localScale": 0.55, "explosionID": "generic_explosive_short_01a", "globalScale": 0.03, "chanceMultiplier": 3, "localExplosionCount": 3}, {"localScale": 0.55, "explosionID": "generic_explosive_short_01b", "globalScale": 0.03, "chanceMultiplier": 2, "localExplosionCount": 3}]}}
13	21	{"_key": 21, "racialExplosions": {"default": [{"localScale": 0.1, "explosionID": "pod_generic_explosive_01a", "globalScale": 2.0, "chanceMultiplier": 1, "localExplosionCount": 0}]}}
14	22	{"_key": 22, "racialExplosions": {"default": [{"localScale": 1.5, "explosionID": "generic_explosive_Long_01a", "globalScale": 3.0, "chanceMultiplier": 3, "localExplosionCount": -1}, {"localScale": 1.5, "explosionID": "generic_explosive_Long_01b", "globalScale": 3.0, "chanceMultiplier": 3, "localExplosionCount": -1}, {"localScale": 1.5, "explosionID": "generic_explosive_Long_01c", "globalScale": 3.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
15	23	{"_key": 23, "racialExplosions": {"default": [{"localScale": 1.35, "explosionID": "generic_explosive_Long_01a", "globalScale": 4.5, "chanceMultiplier": 3, "localExplosionCount": -1}, {"localScale": 1.35, "explosionID": "generic_explosive_Long_01b", "globalScale": 4.3, "chanceMultiplier": 3, "localExplosionCount": -1}, {"localScale": 1.35, "explosionID": "generic_explosive_Long_01c", "globalScale": 5.42, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
16	24	{"_key": 24, "racialExplosions": {"default": [{"localScale": 1.8, "explosionID": "generic_explosive_Long_01a", "globalScale": 1.8, "chanceMultiplier": 3, "localExplosionCount": -1}, {"localScale": 1.8, "explosionID": "generic_explosive_Long_01b", "globalScale": 1.9, "chanceMultiplier": 3, "localExplosionCount": -1}, {"localScale": 1.8, "explosionID": "generic_explosive_Long_01c", "globalScale": 1.8, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
17	25	{"_key": 25, "racialExplosions": {"default": [{"localScale": 2.5, "explosionID": "generic_explosive_Long_01a", "globalScale": 1.42, "chanceMultiplier": 3, "localExplosionCount": -1}, {"localScale": 2.5, "explosionID": "generic_explosive_Long_01b", "globalScale": 1.7, "chanceMultiplier": 3, "localExplosionCount": -1}, {"localScale": 2.5, "explosionID": "generic_explosive_Long_01c", "globalScale": 1.6, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
18	27	{"_key": 27, "racialExplosions": {"default": [{"localScale": 2.4, "explosionID": "generic_explosive_Long_01a", "globalScale": 2.0, "chanceMultiplier": 3, "localExplosionCount": -1}, {"localScale": 2.4, "explosionID": "generic_explosive_Long_01b", "globalScale": 2.3, "chanceMultiplier": 3, "localExplosionCount": -1}, {"localScale": 2.0, "explosionID": "generic_explosive_Long_01c", "globalScale": 2.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
19	28	{"_key": 28, "racialExplosions": {"default": [{"localScale": 0.4, "explosionID": "generic_explosive_01a", "globalScale": 0.4, "chanceMultiplier": 5, "localExplosionCount": -1}, {"localScale": 0.4, "explosionID": "generic_explosive_01b", "globalScale": 0.4, "chanceMultiplier": 4, "localExplosionCount": -1}, {"localScale": 0.4, "explosionID": "generic_explosive_01c", "globalScale": 0.4, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
20	29	{"_key": 29, "racialExplosions": {"default": [{"localScale": 0.1, "explosionID": "generic_explosive_short_01a", "globalScale": 0.04, "chanceMultiplier": 1, "localExplosionCount": 0}, {"localScale": 0.1, "explosionID": "generic_explosive_short_01b", "globalScale": 0.04, "chanceMultiplier": 1, "localExplosionCount": 0}]}}
21	30	{"_key": 30, "racialExplosions": {"default": [{"localScale": 1.42, "explosionID": "lco_generic_explosive_01c", "globalScale": 0.62, "chanceMultiplier": 1, "localExplosionCount": 8}, {"localScale": 1.42, "explosionID": "lco_generic_explosive_01b", "globalScale": 0.62, "chanceMultiplier": 1, "localExplosionCount": 8}, {"localScale": 1.42, "explosionID": "lco_generic_explosive_01a", "globalScale": 0.42, "chanceMultiplier": 1, "localExplosionCount": 8}]}}
22	31	{"_key": 31, "racialExplosions": {"default": [{"localScale": 2.25, "explosionID": "lco_generic_explosive_01c", "globalScale": 0.92, "chanceMultiplier": 1, "localExplosionCount": 12}, {"localScale": 2.25, "explosionID": "lco_generic_explosive_01b", "globalScale": 0.72, "chanceMultiplier": 1, "localExplosionCount": 12}, {"localScale": 2.0, "explosionID": "lco_generic_explosive_01a", "globalScale": 0.72, "chanceMultiplier": 1, "localExplosionCount": 12}]}}
23	32	{"_key": 32, "racialExplosions": {"default": [{"localScale": 2.67, "explosionID": "lco_generic_explosive_01c", "globalScale": 1.1, "chanceMultiplier": 1, "localExplosionCount": 15}, {"localScale": 2.67, "explosionID": "lco_generic_explosive_01b", "globalScale": 1.1, "chanceMultiplier": 1, "localExplosionCount": 15}, {"localScale": 2.67, "explosionID": "lco_generic_explosive_01a", "globalScale": 1.1, "chanceMultiplier": 1, "localExplosionCount": 15}]}}
24	33	{"_key": 33, "racialExplosions": {"default": [{"localScale": 3.2, "explosionID": "lco_generic_explosive_01c", "globalScale": 1.78, "chanceMultiplier": 1, "localExplosionCount": 23}, {"localScale": 3.33, "explosionID": "lco_generic_explosive_01b", "globalScale": 1.78, "chanceMultiplier": 1, "localExplosionCount": 23}, {"localScale": 3.33, "explosionID": "lco_generic_explosive_01a", "globalScale": 1.78, "chanceMultiplier": 1, "localExplosionCount": 23}]}}
25	34	{"_key": 34, "racialExplosions": {"default": [{"localScale": 12.0, "explosionID": "lco_generic_explosive_01c", "globalScale": 1.66, "chanceMultiplier": 1, "localExplosionCount": -1}, {"localScale": 12.0, "explosionID": "lco_generic_explosive_01b", "globalScale": 1.66, "chanceMultiplier": 1, "localExplosionCount": -1}, {"localScale": 12.0, "explosionID": "lco_generic_explosive_01a", "globalScale": 1.66, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
26	35	{"_key": 35, "racialExplosions": {"amarr": [{"localScale": 5.0, "explosionID": "titan_amarr_explosive_01a", "globalScale": 1.42, "chanceMultiplier": 1, "localExplosionCount": -1}], "angel": [{"localScale": 5.0, "explosionID": "titan_angel_explosive_01a", "globalScale": 1.42, "chanceMultiplier": 1, "localExplosionCount": -1}], "caldari": [{"localScale": 5.0, "explosionID": "titan_caldari_explosive_01a", "globalScale": 1.42, "chanceMultiplier": 1, "localExplosionCount": -1}], "gallente": [{"localScale": 5.0, "explosionID": "titan_gallente_explosive_01a", "globalScale": 1.42, "chanceMultiplier": 1, "localExplosionCount": -1}], "minmatar": [{"localScale": 5.0, "explosionID": "titan_minmatar_explosive_01a", "globalScale": 1.42, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
27	36	{"_key": 36, "racialExplosions": {"jove": [{"localScale": 0.8, "explosionID": "drifter_explosive_01a", "globalScale": 0.75, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
28	37	{"_key": 37, "racialExplosions": {"sleeper": [{"localScale": 0.66, "explosionID": "sleeper_explosive_01a", "globalScale": 0.33, "chanceMultiplier": 1, "localExplosionCount": 42}]}}
29	38	{"_key": 38, "racialExplosions": {"sleeper": [{"localScale": 0.42, "explosionID": "sleeper_explosive_01a", "globalScale": 0.22, "chanceMultiplier": 1, "localExplosionCount": 32}]}}
30	39	{"_key": 39, "racialExplosions": {"sleeper": [{"localScale": 0.32, "explosionID": "sleeper_explosive_01a", "globalScale": 0.15, "chanceMultiplier": 1, "localExplosionCount": 22}]}}
31	40	{"_key": 40, "racialExplosions": {"sleeper": [{"localScale": 0.22, "explosionID": "sleeper_explosive_01a", "globalScale": 0.06, "chanceMultiplier": 1, "localExplosionCount": 7}]}}
32	41	{"_key": 41, "racialExplosions": {"default": [{"localScale": 0.125, "explosionID": "lco_generic_explosive_01c", "globalScale": 0.55, "chanceMultiplier": 1, "localExplosionCount": 9}, {"localScale": 0.125, "explosionID": "lco_generic_explosive_01b", "globalScale": 0.325, "chanceMultiplier": 1, "localExplosionCount": 8}, {"localScale": 0.125, "explosionID": "lco_generic_explosive_01a", "globalScale": 0.2, "chanceMultiplier": 1, "localExplosionCount": 5}]}}
33	42	{"_key": 42, "racialExplosions": {"default": [{"localScale": 1.0, "explosionID": "generic_corpse_explosive_01a", "globalScale": 0.25, "chanceMultiplier": 1, "localExplosionCount": 0}]}}
34	43	{"_key": 43, "racialExplosions": {"default": [{"localScale": 1.0, "explosionID": "generic_container_explosive_01a", "globalScale": 0.25, "chanceMultiplier": 1, "localExplosionCount": 0}]}}
35	44	{"_key": 44, "racialExplosions": {"default": []}}
36	45	{"_key": 45, "racialExplosions": {"default": []}}
37	46	{"_key": 46, "racialExplosions": {"default": []}}
38	47	{"_key": 47, "racialExplosions": {"default": []}}
39	48	{"_key": 48, "racialExplosions": {"default": [{"localScale": 1.0, "explosionID": "generic_asteroid_01a", "globalScale": 1.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
40	49	{"_key": 49, "racialExplosions": {"default": [{"localScale": 1.4, "explosionID": "moonchunk_explosive_01a", "globalScale": 13.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}, "specialExplosion": {"localScale": 1.4, "explosionID": "moonchunk_explosivespecial_01a", "globalScale": 13.0, "localExplosionCount": -1}}
41	51	{"_key": 51, "racialExplosions": {"default": [{"localScale": 1.4, "explosionID": "moonchunk_explosive_01a", "globalScale": 18.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}, "specialExplosion": {"localScale": 1.4, "explosionID": "moonchunk_explosivespecial_01a", "globalScale": 18.0, "localExplosionCount": -1}}
42	53	{"_key": 53, "racialExplosions": {"default": [{"localScale": 1.4, "explosionID": "moonchunk_explosive_01a", "globalScale": 26.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}, "specialExplosion": {"localScale": 1.4, "explosionID": "moonchunk_explosivespecial_01a", "globalScale": 26.0, "localExplosionCount": -1}}
43	55	{"_key": 55, "racialExplosions": {"default": [{"localScale": 1.4, "explosionID": "moonchunk_explosive_01a", "globalScale": 31.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}, "specialExplosion": {"localScale": 1.4, "explosionID": "moonchunk_explosivespecial_01a", "globalScale": 31.0, "localExplosionCount": -1}}
44	56	{"_key": 56, "racialExplosions": {"jove": [{"localScale": 0.25, "explosionID": "drifter_cruiser_explosive_01a", "globalScale": 0.3, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
45	57	{"_key": 57, "racialExplosions": {"triglavian": [{"localScale": 0.75, "explosionID": "triglavian_explosive_01a", "globalScale": 0.8, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
46	58	{"_key": 58, "racialExplosions": {"triglavian": [{"localScale": 0.2, "explosionID": "triglavian_explosive_01a", "globalScale": 0.45, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
47	59	{"_key": 59, "racialExplosions": {"triglavian": [{"localScale": 10.0, "explosionID": "triglavian_structure_xl_explosive_01a", "globalScale": 4.35, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
48	60	{"_key": 60, "racialExplosions": {"triglavian": [{"localScale": 1.0, "explosionID": "triglavian_lootcontainer_01a", "globalScale": 0.65, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
49	61	{"_key": 61, "racialExplosions": {"triglavian": [{"localScale": 0.15, "explosionID": "triglavian_explosive_short_01a", "globalScale": 0.35, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
50	62	{"_key": 62, "racialExplosions": {"triglavian": [{"localScale": 3.0, "explosionID": "triglavian_lootcontainer_01a", "globalScale": 0.8, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
51	63	{"_key": 63, "racialExplosions": {"triglavian": [{"localScale": 8.0, "explosionID": "triglavian_lootcontainer_01a", "globalScale": 1.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
52	64	{"_key": 64, "racialExplosions": {"triglavian": [{"localScale": 0.2, "explosionID": "triglavian_explosive_01a", "globalScale": 0.45, "chanceMultiplier": 1, "localExplosionCount": 7}]}}
53	65	{"_key": 65, "racialExplosions": {"triglavian": [{"localScale": 4.0, "explosionID": "triglavian_structure_xl_explosive_02a", "globalScale": 0.4, "chanceMultiplier": 1, "localExplosionCount": 18}]}}
54	66	{"_key": 66, "racialExplosions": {"triglavian": [{"localScale": 1.0, "explosionID": "triglavian_explosive_Dreadnought_01a", "globalScale": 1.0, "chanceMultiplier": 1, "localExplosionCount": 26}]}}
55	67	{"_key": 67, "racialExplosions": {"default": [{"localScale": 10.0, "explosionID": "concord_structure_l_explosive_01a", "globalScale": 0.1, "chanceMultiplier": 1, "localExplosionCount": 15}]}}
56	68	{"_key": 68, "racialExplosions": {"triglavian": [{"localScale": 0.65, "explosionID": "triglavian_explosive_01a", "globalScale": 1.2, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
57	69	{"_key": 69, "racialExplosions": {"triglavian": [{"localScale": 1.5, "explosionID": "triglavian_structure_xl_explosive_02a", "globalScale": 0.25, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
58	70	{"_key": 70, "racialExplosions": {"triglavian": [{"localScale": 0.85, "explosionID": "triglavian_explosive_sentry_01a", "globalScale": 1.0, "chanceMultiplier": 1, "localExplosionCount": 15}]}}
59	71	{"_key": 71, "racialExplosions": {"triglavian": [{"localScale": 1.0, "explosionID": "triglavian_structure_s_explosive_01a", "globalScale": 1.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
60	72	{"_key": 72, "racialExplosions": {"default": [{"localScale": 1.5, "explosionID": "edencom_structure_extra_large_explosive_01a", "globalScale": 1.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
61	73	{"_key": 73, "racialExplosions": {"default": [{"localScale": 1.0, "explosionID": "edencom_structure_large_explosive_01a", "globalScale": 1.0, "chanceMultiplier": 1, "localExplosionCount": 15}]}}
62	74	{"_key": 74, "racialExplosions": {"default": [{"localScale": 0.25, "explosionID": "upwell_explosive_short_01a", "globalScale": 0.25, "chanceMultiplier": 1, "localExplosionCount": 5}]}}
63	75	{"_key": 75, "racialExplosions": {"default": [{"localScale": 0.3, "explosionID": "upwell_explosive_01a", "globalScale": 0.325, "chanceMultiplier": 1, "localExplosionCount": 24}]}}
64	76	{"_key": 76, "racialExplosions": {"default": [{"localScale": 0.7501, "explosionID": "upwell_explosive_long_01a", "globalScale": 1.0, "chanceMultiplier": 1, "localExplosionCount": 42}]}}
65	77	{"_key": 77, "racialExplosions": {"default": [{"localScale": 1.0, "explosionID": "edencom_structure_large_explosive_01a", "globalScale": 1.0, "chanceMultiplier": 1, "localExplosionCount": 15}]}}
66	2066	{"_key": 2066, "racialExplosions": {"default": [{"localScale": 3.0, "explosionID": "triglavian_structure_tfu_explosive_01a", "globalScale": 0.25, "chanceMultiplier": 1, "localExplosionCount": 8}]}}
67	2077	{"_key": 2077, "racialExplosions": {"default": [{"localScale": 6.53, "explosionID": "lco_generic_explosive_01c", "globalScale": 2.3, "chanceMultiplier": 1, "localExplosionCount": 23}, {"localScale": 6.53, "explosionID": "lco_generic_explosive_01b", "globalScale": 2.3, "chanceMultiplier": 1, "localExplosionCount": 23}, {"localScale": 6.53, "explosionID": "lco_generic_explosive_01a", "globalScale": 2.3, "chanceMultiplier": 1, "localExplosionCount": 23}]}}
68	2078	{"_key": 2078, "racialExplosions": {"default": [{"localScale": 1.34, "explosionID": "generic_structure_large_explosion", "globalScale": 20.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
69	2079	{"_key": 2079, "racialExplosions": {"default": [{"localScale": 1.0, "explosionID": "upwell_skyhook_explosive_01a", "globalScale": 1.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
70	2080	{"_key": 2080, "racialExplosions": {"default": [{"localScale": 0.14, "explosionID": "upwell_freighter_explosive_01a", "globalScale": 6.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
71	2081	{"_key": 2081, "racialExplosions": {"default": [{"localScale": 0.045, "explosionID": "upwell_industrial_explosive_01a", "globalScale": 5.02, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
72	2082	{"_key": 2082, "racialExplosions": {"default": [{"localScale": 0.5, "explosionID": "deathless_structure_large_explosive_01a", "globalScale": 1.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
73	2083	{"_key": 2083, "racialExplosions": {"default": [{"localScale": 6.0, "explosionID": "drifter_structure_explosive_01a", "globalScale": 7.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
74	2084	{"_key": 2084, "racialExplosions": {"default": [{"localScale": 1.0, "explosionID": "drifter_structure_explosive_01a", "globalScale": 1.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
75	2085	{"_key": 2085, "racialExplosions": {"default": [{"localScale": 0.55, "explosionID": "drifter_explosive_short_01a", "globalScale": 0.05, "chanceMultiplier": 1, "localExplosionCount": 3}]}}
76	2086	{"_key": 2086, "racialExplosions": {"default": [{"localScale": 1.0, "explosionID": "lco_fast_explosive_01a", "globalScale": 1.0, "chanceMultiplier": 1, "localExplosionCount": 0}]}}
77	2087	{"_key": 2087, "racialExplosions": {"default": [{"localScale": 2.0, "explosionID": "lco_fast_explosive_01a", "globalScale": 2.0, "chanceMultiplier": 1, "localExplosionCount": 0}]}}
78	2088	{"_key": 2088, "racialExplosions": {"default": [{"localScale": 3.0, "explosionID": "lco_fast_explosive_01a", "globalScale": 3.0, "chanceMultiplier": 1, "localExplosionCount": 0}]}}
79	2089	{"_key": 2089, "racialExplosions": {"default": [{"localScale": 4.0, "explosionID": "lco_fast_explosive_01a", "globalScale": 4.0, "chanceMultiplier": 1, "localExplosionCount": 0}]}}
80	2090	{"_key": 2090, "racialExplosions": {"default": [{"localScale": 0.75, "explosionID": "ore_strucuture_small_explosive_01a", "globalScale": 1.0, "chanceMultiplier": 1, "localExplosionCount": 10}]}}
81	2091	{"_key": 2091, "racialExplosions": {"default": [{"localScale": 0.4, "explosionID": "lco_fast_explosive_01a", "globalScale": 0.4, "chanceMultiplier": 1, "localExplosionCount": 0}]}}
82	2092	{"_key": 2092, "racialExplosions": {"default": [{"localScale": 0.35, "explosionID": "holographic_medium", "globalScale": 1.0, "chanceMultiplier": 1, "localExplosionCount": 19}]}}
83	2093	{"_key": 2093, "racialExplosions": {"default": [{"localScale": 0.66, "explosionID": "holographic_large", "globalScale": 0.75, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
84	2094	{"_key": 2094, "racialExplosions": {"default": [{"localScale": 1.0, "explosionID": "holographic_xl", "globalScale": 0.85, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
85	2095	{"_key": 2095, "racialExplosions": {"default": [{"localScale": 2.0, "explosionID": "holographic_xl", "globalScale": 3.0, "chanceMultiplier": 1, "localExplosionCount": -1}]}}
86	2096	{"_key": 2096, "racialExplosions": {"default": [{"localScale": 0.25, "explosionID": "holographic_small", "globalScale": 0.75, "chanceMultiplier": 1, "localExplosionCount": 3}]}}
\.


--
-- Name: explosionbucketids explosionbucketids_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.explosionbucketids
    ADD CONSTRAINT explosionbucketids_pkey PRIMARY KEY (row_no);


--
-- Name: explosionbucketids_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX explosionbucketids_key_idx ON sde_native.explosionbucketids USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict czyyOHPyMLLtY6sTChKXf8avqkQQn7EvNIvIGb1gF3RX47xrLzQHpdujQk7EpOV

