--
-- PostgreSQL database dump
--

\restrict 1IbsBbwtR5Oxj6UrMBzoSDjOGDLhCBfURQatBgvhNZMKh2CfblywzelwWbbWui9

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: conversationagents; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.conversationagents (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: conversationagents; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.conversationagents (row_no, key, data) FROM stdin;
0	5	{"_key": 5, "name": 519116, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/aura_neutral_mid.png", "scenePath": "res:/Animation_Gstate/Scenes/Templates/Aura/Template_Aura_Neutral/", "preloadCachePath": "res:/Animation_Gstate/Scenes/Templates/aura_curve_cache_list.yaml"}
1	18	{"_key": 18, "name": 541478, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/mentorsoe.png", "loopVideoPath": "res:/ui/texture/classes/conversationui/conversationagents/mentor_soe_loop.webm"}
2	19	{"_key": 19, "name": 545509, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/mentorAmarr.png", "loopVideoPath": "res:/ui/texture/classes/conversationui/conversationagents/mentor_amarr_loop.webm"}
3	2022	{"_key": 2022, "name": 577065, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/balin_neutral_close_citadel.png", "scenePath": "res:/Animation_Gstate/Scenes/Templates/Balin/Template_Balin_Medium/"}
4	2023	{"_key": 2023, "name": 581838, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/vesper_neutral_close_citadel.png", "scenePath": "res:/Animation_Gstate/Scenes/Templates/Vesper/Template_Vesper_Medium/"}
5	2026	{"_key": 2026, "name": 591475, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Elias_Close.png", "scenePath": "res:/Animation_Gstate/Scenes/Templates/Elias/Template_Elias_Medium/"}
6	2027	{"_key": 2027, "name": 600888, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Tahmar.png", "scenePath": "res:/Animation_Gstate/Scenes/NPC/Tahmar"}
7	2028	{"_key": 2028, "name": 600891, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/TheDevout.png", "scenePath": "res:/Animation_Gstate/Scenes/NPC/TheDevout"}
8	2029	{"_key": 2029, "name": 600889, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Wolf.png", "scenePath": "res:/Animation_Gstate/Scenes/NPC/Wolf"}
9	2030	{"_key": 2030, "name": 600890, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Steon.png", "scenePath": "res:/Animation_Gstate/Scenes/NPC/Steon"}
10	2031	{"_key": 2031, "name": 600892, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/PirateRaider.png", "scenePath": "res:/Animation_Gstate/Scenes/NPC/PirateRaider"}
11	2032	{"_key": 2032, "name": 602578, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/HaratMamtan.png", "scenePath": "res:/Animation_Gstate/Scenes/NPC/HaratMamtan"}
12	2033	{"_key": 2033, "name": 609727, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/AsanIkkaa.png", "scenePath": "res:/Animation_Gstate/Scenes/NPC/AsanIkkaa"}
13	2034	{"_key": 2034, "name": 609728, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/AnzarPuydenmont.png", "scenePath": "res:/Animation_Gstate/Scenes/NPC/AnzarPuydenmont"}
14	2035	{"_key": 2035, "name": 609729, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/PirateRaider_Neutral.png", "scenePath": "res:/Animation_Gstate/Scenes/NPC/PirateRaider_Neutral"}
15	2039	{"_key": 2039, "name": 638860, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Iris.png", "scenePath": "res:/Animation_Gstate/Scenes/NPC/Iris_Idle/", "preloadCachePath": "res:/Animation_Gstate/Scenes/NPC/Iris_curve_cache_list.yaml"}
16	2041	{"_key": 2041, "name": 657074, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Anya.png", "scenePath": "res:/Animation_Gstate/Scenes/NPC/AnyaHorvak/", "preloadCachePath": "res:/Animation_Gstate/Scenes/NPC/AnyaHorvak_curve_cache_list.yaml"}
17	2042	{"_key": 2042, "name": 657075, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Sarva.png", "scenePath": "res:/Animation_Gstate/Scenes/NPC/SarvaBurman/", "preloadCachePath": "res:/Animation_Gstate/Scenes/NPC/SarvaBurman_curve_cache_list.yaml"}
18	2043	{"_key": 2043, "name": 657076, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Cephus.png", "scenePath": "res:/Animation_Gstate/Scenes/NPC/CephusZafir/", "preloadCachePath": "res:/Animation_Gstate/Scenes/NPC/CephusZafir_curve_cache_list.yaml"}
19	2044	{"_key": 2044, "name": 657077, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Dana.png", "scenePath": "res:/Animation_Gstate/Scenes/NPC/DanaHuginn/", "preloadCachePath": "res:/Animation_Gstate/Scenes/NPC/DanaHuginn_curve_cache_list.yaml"}
20	2049	{"_key": 2049, "name": 725962, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/MalayaHrada2.png"}
21	2051	{"_key": 2051, "name": 870950, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/CasimirGarmoniya.png"}
22	2052	{"_key": 2052, "name": 872341, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/SuldrunMurat.png"}
23	2053	{"_key": 2053, "name": 1011899, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/BaldurChaiya.png"}
24	2061	{"_key": 2061, "name": 1022405, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/CharlotteBecker.png"}
25	2062	{"_key": 2062, "name": 1022406, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/JacquesQuelouse.png"}
26	2063	{"_key": 2063, "name": 1022433, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/EliasORE.png"}
27	2064	{"_key": 2064, "name": 1022435, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Elias_Close.png"}
28	2065	{"_key": 2065, "name": 1040017, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Cassandra_Ahfrim.png"}
29	2066	{"_key": 2066, "name": 1040018, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Sirdan_Xer_Qosh.png"}
30	2067	{"_key": 2067, "name": 1040019, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Heika_Torigo.png"}
31	2068	{"_key": 2068, "name": 1040020, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Foriana_Revelli.png"}
32	2069	{"_key": 2069, "name": 1040021, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Kanth_Filmir.png"}
33	2070	{"_key": 2070, "name": 1040308, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Admiral_Yakiya_Tovil-Toba.png"}
34	2071	{"_key": 2071, "name": 1040307, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/President_Luc_Duvailer.png"}
35	2072	{"_key": 2072, "name": 1040306, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Central_Dispatch.png"}
36	2073	{"_key": 2073, "name": 1040315, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Lord_Governor_Juliano_Corvinos.png"}
37	2074	{"_key": 2074, "name": 1040316, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/LjosNegat.png"}
38	2075	{"_key": 2075, "name": 1040314, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/HanaNuras.png"}
39	2077	{"_key": 2077, "name": 1040312, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Sasha_Shoti.png"}
40	2078	{"_key": 2078, "name": 1040313, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/CasiaEladi.png"}
41	2083	{"_key": 2083, "name": 1045771, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/Ronit_Joranth.png"}
42	2085	{"_key": 2085, "name": 1045781, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/XavierPard.png"}
43	2086	{"_key": 2086, "name": 1046176, "imagePath": "res:/ui/texture/classes/conversationui/conversationagents/EmperprHeideran.png"}
\.


--
-- Name: conversationagents conversationagents_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.conversationagents
    ADD CONSTRAINT conversationagents_pkey PRIMARY KEY (row_no);


--
-- Name: conversationagents_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX conversationagents_key_idx ON sde_native.conversationagents USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 1IbsBbwtR5Oxj6UrMBzoSDjOGDLhCBfURQatBgvhNZMKh2CfblywzelwWbbWui9

