--
-- PostgreSQL database dump
--

\restrict cRIUla9gBJMg5487jCJqV4nv0yaaAOpncaor13PObkTSe0pLmomoPqpdm8IwoRh

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: selectiongroups; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.selectiongroups (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: selectiongroups; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.selectiongroups (row_no, key, data) FROM stdin;
0	7	{"yaw": 360.0, "_key": 7, "roll": 0.0, "pitch": 0.0, "roomID": 22085, "selectionGroupName": "Untitled01"}
1	8	{"yaw": 360.0, "_key": 8, "roll": 0.0, "pitch": 0.0, "roomID": 22085, "selectionGroupName": "Untitled02"}
2	9	{"yaw": 360.0, "_key": 9, "roll": 0.0, "pitch": 0.0, "roomID": 22085, "selectionGroupName": "Untitled01"}
3	10	{"yaw": 360.0, "_key": 10, "roll": 0.0, "pitch": 0.0, "roomID": 22100, "selectionGroupName": "Untitled01"}
4	12	{"yaw": 360.0, "_key": 12, "roll": 0.0, "pitch": 0.0, "roomID": 22153, "selectionGroupName": "Untitled02"}
5	13	{"yaw": 360.0, "_key": 13, "roll": 0.0, "pitch": 0.0, "roomID": 22153, "selectionGroupName": "Untitled03"}
6	17	{"yaw": 360.0, "_key": 17, "roll": 0.0, "pitch": 0.0, "roomID": 22185, "selectionGroupName": "Untitled01"}
7	18	{"yaw": 360.0, "_key": 18, "roll": 0.0, "pitch": 0.0, "roomID": 22185, "selectionGroupName": "Untitled01"}
8	19	{"yaw": 360.0, "_key": 19, "roll": 0.0, "pitch": 0.0, "roomID": 22190, "selectionGroupName": "Untitled01"}
9	20	{"yaw": 360.0, "_key": 20, "roll": 0.0, "pitch": 0.0, "roomID": 22190, "selectionGroupName": "Untitled02"}
10	21	{"yaw": 360.0, "_key": 21, "roll": 0.0, "pitch": 0.0, "roomID": 22190, "selectionGroupName": "Untitled01"}
11	22	{"yaw": 360.0, "_key": 22, "roll": 0.0, "pitch": 0.0, "roomID": 22190, "selectionGroupName": "Untitled02"}
12	23	{"yaw": 360.0, "_key": 23, "roll": 0.0, "pitch": 0.0, "roomID": 22190, "selectionGroupName": "Untitled01"}
13	24	{"yaw": 360.0, "_key": 24, "roll": 0.0, "pitch": 0.0, "roomID": 22190, "selectionGroupName": "Untitled01"}
14	25	{"yaw": 360.0, "_key": 25, "roll": 0.0, "pitch": 0.0, "roomID": 22242, "selectionGroupName": "Untitled01"}
15	29	{"yaw": 360.0, "_key": 29, "roll": 0.0, "pitch": 0.0, "roomID": 22285, "selectionGroupName": "Untitled01"}
16	30	{"yaw": 360.0, "_key": 30, "roll": 0.0, "pitch": 0.0, "roomID": 22298, "selectionGroupName": "Untitled01"}
17	32	{"yaw": 360.0, "_key": 32, "roll": 0.0, "pitch": 0.0, "roomID": 22301, "selectionGroupName": "Untitled01"}
18	33	{"yaw": 360.0, "_key": 33, "roll": 0.0, "pitch": 0.0, "roomID": 22302, "selectionGroupName": "Untitled01"}
19	36	{"yaw": 360.0, "_key": 36, "roll": 0.0, "pitch": 0.0, "roomID": 22283, "selectionGroupName": "Untitled01"}
20	37	{"yaw": 360.0, "_key": 37, "roll": 0.0, "pitch": 0.0, "roomID": 22285, "selectionGroupName": "Untitled02"}
21	38	{"yaw": 360.0, "_key": 38, "roll": 0.0, "pitch": 0.0, "roomID": 22301, "selectionGroupName": "Untitled02"}
22	39	{"yaw": 0.0, "_key": 39, "roll": 0.0, "pitch": 0.0, "roomID": 22316, "selectionGroupName": "Untitled01"}
23	40	{"yaw": 0.0, "_key": 40, "roll": 0.0, "pitch": 0.0, "roomID": 22316, "selectionGroupName": "Untitled01"}
24	41	{"yaw": 0.0, "_key": 41, "roll": 0.0, "pitch": 0.0, "roomID": 22316, "selectionGroupName": "Untitled01"}
25	42	{"yaw": 0.0, "_key": 42, "roll": 0.0, "pitch": 0.0, "roomID": 22316, "selectionGroupName": "Untitled02"}
26	43	{"yaw": 360.0, "_key": 43, "roll": 0.0, "pitch": 0.0, "roomID": 22331, "selectionGroupName": "Untitled01"}
27	44	{"yaw": 360.0, "_key": 44, "roll": 0.0, "pitch": 0.0, "roomID": 22332, "selectionGroupName": "Untitled01"}
28	45	{"yaw": 360.0, "_key": 45, "roll": 0.0, "pitch": 0.0, "roomID": 22335, "selectionGroupName": "Untitled01"}
29	46	{"yaw": 360.0, "_key": 46, "roll": 0.0, "pitch": 0.0, "roomID": 22336, "selectionGroupName": "Untitled01"}
30	48	{"yaw": 360.0, "_key": 48, "roll": 0.0, "pitch": 0.0, "roomID": 22340, "selectionGroupName": "Untitled01"}
31	49	{"yaw": 360.0, "_key": 49, "roll": 0.0, "pitch": 0.0, "roomID": 22340, "selectionGroupName": "Untitled02"}
32	50	{"yaw": 360.0, "_key": 50, "roll": 0.0, "pitch": 0.0, "roomID": 22341, "selectionGroupName": "Untitled01"}
33	57	{"yaw": 0.0, "_key": 57, "roll": 0.0, "pitch": 0.0, "roomID": 22350, "selectionGroupName": "Untitled01"}
34	60	{"yaw": 0.0, "_key": 60, "roll": 0.0, "pitch": 0.0, "roomID": 22350, "selectionGroupName": "Untitled02"}
35	70	{"yaw": 0.0, "_key": 70, "roll": 0.0, "pitch": 0.0, "roomID": 22356, "selectionGroupName": "Untitled01"}
36	71	{"yaw": 0.0, "_key": 71, "roll": 0.0, "pitch": 0.0, "roomID": 22356, "selectionGroupName": "Untitled02"}
37	72	{"yaw": 360.0, "_key": 72, "roll": 0.0, "pitch": 0.0, "roomID": 22379, "selectionGroupName": "Untitled01"}
38	73	{"yaw": 0.0, "_key": 73, "roll": 0.0, "pitch": 0.0, "roomID": 22380, "selectionGroupName": "Untitled01"}
39	75	{"yaw": 360.0, "_key": 75, "roll": 0.0, "pitch": 0.0, "roomID": 22529, "selectionGroupName": "Untitled01"}
40	76	{"yaw": 360.0, "_key": 76, "roll": 0.0, "pitch": 0.0, "roomID": 21834, "selectionGroupName": "Untitled01"}
41	77	{"yaw": 360.0, "_key": 77, "roll": 0.0, "pitch": 0.0, "roomID": 21834, "selectionGroupName": "Untitled02"}
42	78	{"yaw": 360.0, "_key": 78, "roll": 0.0, "pitch": 0.0, "roomID": 21834, "selectionGroupName": "Untitled03"}
43	79	{"yaw": 360.0, "_key": 79, "roll": 0.0, "pitch": 0.0, "roomID": 21834, "selectionGroupName": "Untitled04"}
44	80	{"yaw": 360.0, "_key": 80, "roll": 0.0, "pitch": 0.0, "roomID": 21834, "selectionGroupName": "Untitled05"}
45	81	{"yaw": 360.0, "_key": 81, "roll": 0.0, "pitch": 0.0, "roomID": 21834, "selectionGroupName": "Untitled06"}
46	82	{"yaw": 354.42462158203125, "_key": 82, "roll": 0.0, "pitch": 0.0, "roomID": 21834, "selectionGroupName": "Untitled07"}
47	83	{"yaw": 360.0, "_key": 83, "roll": 0.0, "pitch": 0.0, "roomID": 21834, "selectionGroupName": "Untitled08"}
48	88	{"yaw": 360.0, "_key": 88, "roll": 0.0, "pitch": 0.0, "roomID": 23197, "selectionGroupName": "Untitled04"}
49	89	{"yaw": 0.0, "_key": 89, "roll": 0.0, "pitch": 0.0, "roomID": 23264, "selectionGroupName": "Untitled01"}
50	91	{"yaw": 360.0, "_key": 91, "roll": 0.0, "pitch": 0.0, "roomID": 23225, "selectionGroupName": "Untitled01"}
51	92	{"yaw": 0.0, "_key": 92, "roll": 0.0, "pitch": 0.0, "roomID": 23225, "selectionGroupName": "Untitled01"}
52	93	{"yaw": 360.0, "_key": 93, "roll": 0.0, "pitch": 0.0, "roomID": 23277, "selectionGroupName": "Bunker1"}
53	94	{"yaw": 360.0, "_key": 94, "roll": 0.0, "pitch": 0.0, "roomID": 23277, "selectionGroupName": "Bunker2"}
54	95	{"yaw": 0.0, "_key": 95, "roll": 0.0, "pitch": 0.0, "roomID": 23284, "selectionGroupName": "Untitled01"}
55	96	{"yaw": 360.0, "_key": 96, "roll": 0.0, "pitch": 0.0, "roomID": 23279, "selectionGroupName": "Untitled01"}
56	97	{"yaw": 360.0, "_key": 97, "roll": 0.0, "pitch": 0.0, "roomID": 23279, "selectionGroupName": "Untitled02"}
57	98	{"yaw": 360.0, "_key": 98, "roll": 0.0, "pitch": 0.0, "roomID": 23287, "selectionGroupName": "Untitled01"}
58	99	{"yaw": 360.0, "_key": 99, "roll": 0.0, "pitch": 0.0, "roomID": 23290, "selectionGroupName": "Untitled01"}
59	100	{"yaw": 360.0, "_key": 100, "roll": 0.0, "pitch": 0.0, "roomID": 23294, "selectionGroupName": "Untitled01"}
60	101	{"yaw": 360.0, "_key": 101, "roll": 0.0, "pitch": 0.0, "roomID": 23299, "selectionGroupName": "Untitled01"}
61	102	{"yaw": 360.0, "_key": 102, "roll": 0.0, "pitch": 0.0, "roomID": 23299, "selectionGroupName": "Untitled02"}
62	103	{"yaw": 360.0, "_key": 103, "roll": 0.0, "pitch": 0.0, "roomID": 23592, "selectionGroupName": "Untitled01"}
63	105	{"yaw": 360.0, "_key": 105, "roll": 0.0, "pitch": 0.0, "roomID": 23495, "selectionGroupName": "Untitled01"}
64	107	{"yaw": 360.0, "_key": 107, "roll": 0.0, "pitch": 0.0, "roomID": 23592, "selectionGroupName": "Untitled01"}
65	109	{"yaw": 0.0, "_key": 109, "roll": 0.0, "pitch": 0.0, "roomID": 23650, "selectionGroupName": "Untitled01"}
\.


--
-- Name: selectiongroups selectiongroups_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.selectiongroups
    ADD CONSTRAINT selectiongroups_pkey PRIMARY KEY (row_no);


--
-- Name: selectiongroups_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX selectiongroups_key_idx ON sde_native.selectiongroups USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict cRIUla9gBJMg5487jCJqV4nv0yaaAOpncaor13PObkTSe0pLmomoPqpdm8IwoRh

