--
-- PostgreSQL database dump
--

\restrict MZP8TIEMebHxyojWhflbgMplS8Q3uM47eZpAfG9HkkC6t2D0n0CEgloPQMxB6pf

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: challengeevents; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.challengeevents (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: challengeevents; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.challengeevents (row_no, key, data) FROM stdin;
0	NPCBountyPaid	{"_key": "NPCBountyPaid", "value": 6}
1	abyssDestroyHostileNPC	{"_key": "abyssDestroyHostileNPC", "value": 15}
2	abyssPocketCompleted	{"_key": "abyssPocketCompleted", "value": 14}
3	abyssSequenceCompleted	{"_key": "abyssSequenceCompleted", "value": 13}
4	abyssSequenceStarted	{"_key": "abyssSequenceStarted", "value": 12}
5	agentCourierMissionCompleted	{"_key": "agentCourierMissionCompleted", "value": 7}
6	agentDungeonMissionCompleted	{"_key": "agentDungeonMissionCompleted", "value": 8}
7	agentMiningMissionCompleted	{"_key": "agentMiningMissionCompleted", "value": 9}
8	agentTradeMissionCompleted	{"_key": "agentTradeMissionCompleted", "value": 10}
9	client_lookAtObject	{"_key": "client_lookAtObject", "value": 19}
10	damageDealt	{"_key": "damageDealt", "value": 31}
11	destroyHostileNPC	{"_key": "destroyHostileNPC", "value": 1}
12	dungeonEntered	{"_key": "dungeonEntered", "value": 5}
13	dungeonRoomEntered	{"_key": "dungeonRoomEntered", "value": 20}
14	facWarDungeonRewardGranted	{"_key": "facWarDungeonRewardGranted", "value": 34}
15	groupRewardGranted	{"_key": "groupRewardGranted", "value": 32}
16	hackingMiniGameWon	{"_key": "hackingMiniGameWon", "value": 17}
17	itemReceivedFromItemTrader	{"_key": "itemReceivedFromItemTrader", "value": 25}
18	marketBoughtType	{"_key": "marketBoughtType", "value": 22}
19	marketSoldType	{"_key": "marketSoldType", "value": 23}
20	moduleActivate	{"_key": "moduleActivate", "value": 26}
21	moduleMutated	{"_key": "moduleMutated", "value": 16}
22	provingGroundsEntered	{"_key": "provingGroundsEntered", "value": 27}
23	provingGroundsWon	{"_key": "provingGroundsWon", "value": 30}
24	questItemAcquired	{"_key": "questItemAcquired", "value": 11}
25	reprocessingInput	{"_key": "reprocessingInput", "value": 21}
26	resourceWarsCompleted	{"_key": "resourceWarsCompleted", "value": 28}
27	resourceWarsHaulerDeposit	{"_key": "resourceWarsHaulerDeposit", "value": 29}
28	siteComplete	{"_key": "siteComplete", "value": 2}
29	somethingExplode	{"_key": "somethingExplode", "value": 24}
30	successfulSalvageCount	{"_key": "successfulSalvageCount", "value": 18}
31	totalMined	{"_key": "totalMined", "value": 3}
32	typeManufacturedCount	{"_key": "typeManufacturedCount", "value": 4}
33	vanguardAssignmentCompleted	{"_key": "vanguardAssignmentCompleted", "value": 33}
34	volumeMined	{"_key": "volumeMined", "value": 35}
\.


--
-- Name: challengeevents challengeevents_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.challengeevents
    ADD CONSTRAINT challengeevents_pkey PRIMARY KEY (row_no);


--
-- Name: challengeevents_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX challengeevents_key_idx ON sde_native.challengeevents USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict MZP8TIEMebHxyojWhflbgMplS8Q3uM47eZpAfG9HkkC6t2D0n0CEgloPQMxB6pf

