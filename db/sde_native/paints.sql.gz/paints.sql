--
-- PostgreSQL database dump
--

\restrict tK7BXcedrjAgfYi0RqfrgvYEooyBmAcDIb78RbJdJwF8FAQlxjoy351k3B5Gvtu

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: paints; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.paints (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: paints; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.paints (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "finish": "coated", "rarity": "uncommon", "hueCategory": "azure", "paintNameID": 664397, "materialName": "cosm_azure_vibrant_bright_coated_200_96_50"}
1	2	{"_key": 2, "finish": "coated", "rarity": "uncommon", "hueCategory": "azure", "paintNameID": 664398, "materialName": "cosm_azure_vibrant_bright_coated_202_79_80"}
2	3	{"_key": 3, "finish": "matt", "rarity": "common", "hueCategory": "azure", "paintNameID": 664399, "materialName": "cosm_azure_vibrant_bright_matt_200_96_50"}
3	4	{"_key": 4, "finish": "matt", "rarity": "common", "hueCategory": "azure", "paintNameID": 664400, "materialName": "cosm_azure_vibrant_bright_matt_202_79_80"}
4	5	{"_key": 5, "finish": "satin", "rarity": "rare", "hueCategory": "azure", "paintNameID": 664401, "materialName": "cosm_azure_vibrant_bright_satin_200_96_50"}
5	6	{"_key": 6, "finish": "satin", "rarity": "rare", "hueCategory": "azure", "paintNameID": 664402, "materialName": "cosm_azure_vibrant_bright_satin_202_79_80"}
6	7	{"_key": 7, "finish": "coated", "rarity": "uncommon", "hueCategory": "azure", "paintNameID": 664403, "materialName": "cosm_azure_vibrant_dark_coated_202_76_24"}
7	8	{"_key": 8, "finish": "matt", "rarity": "common", "hueCategory": "azure", "paintNameID": 664404, "materialName": "cosm_azure_vibrant_dark_matt_202_76_24"}
8	9	{"_key": 9, "finish": "satin", "rarity": "rare", "hueCategory": "azure", "paintNameID": 664405, "materialName": "cosm_azure_vibrant_dark_satin_202_76_24"}
9	10	{"_key": 10, "finish": "coated", "rarity": "uncommon", "hueCategory": "blue", "paintNameID": 664406, "materialName": "cosm_blue_vibrant_bright_coated_232_79_74"}
10	11	{"_key": 11, "finish": "coated", "rarity": "uncommon", "hueCategory": "blue", "paintNameID": 664407, "materialName": "cosm_blue_vibrant_bright_coated_247_79_80"}
11	12	{"_key": 12, "finish": "matt", "rarity": "common", "hueCategory": "blue", "paintNameID": 664408, "materialName": "cosm_blue_vibrant_bright_matt_232_79_74"}
12	13	{"_key": 13, "finish": "matt", "rarity": "common", "hueCategory": "blue", "paintNameID": 664409, "materialName": "cosm_blue_vibrant_bright_matt_247_79_80"}
13	14	{"_key": 14, "finish": "satin", "rarity": "rare", "hueCategory": "blue", "paintNameID": 664410, "materialName": "cosm_blue_vibrant_bright_satin_232_79_74"}
14	15	{"_key": 15, "finish": "satin", "rarity": "rare", "hueCategory": "blue", "paintNameID": 664411, "materialName": "cosm_blue_vibrant_bright_satin_247_79_80"}
15	16	{"_key": 16, "finish": "coated", "rarity": "uncommon", "hueCategory": "bw", "paintNameID": 664412, "materialName": "cosm_bw_pale_bright_coated_0_0_90"}
16	17	{"_key": 17, "finish": "matt", "rarity": "common", "hueCategory": "bw", "paintNameID": 664413, "materialName": "cosm_bw_pale_bright_matt_0_0_90"}
17	18	{"_key": 18, "finish": "satin", "rarity": "rare", "hueCategory": "bw", "paintNameID": 664414, "materialName": "cosm_bw_pale_bright_satin_0_0_90"}
18	19	{"_key": 19, "finish": "coated", "rarity": "uncommon", "hueCategory": "bw", "paintNameID": 664415, "materialName": "cosm_bw_pale_dark_coated_0_0_5"}
19	20	{"_key": 20, "finish": "matt", "rarity": "common", "hueCategory": "bw", "paintNameID": 664416, "materialName": "cosm_bw_pale_dark_matt_0_0_5"}
20	21	{"_key": 21, "finish": "satin", "rarity": "rare", "hueCategory": "bw", "paintNameID": 664417, "materialName": "cosm_bw_pale_dark_satin_0_0_5"}
21	22	{"_key": 22, "finish": "coated", "rarity": "uncommon", "hueCategory": "bw", "paintNameID": 664418, "materialName": "cosm_bw_pale_medium_coated_0_0_41"}
22	23	{"_key": 23, "finish": "matt", "rarity": "common", "hueCategory": "bw", "paintNameID": 664419, "materialName": "cosm_bw_pale_medium_matt_0_0_41"}
23	24	{"_key": 24, "finish": "satin", "rarity": "rare", "hueCategory": "bw", "paintNameID": 664420, "materialName": "cosm_bw_pale_medium_satin_0_0_41"}
24	25	{"_key": 25, "finish": "coated", "rarity": "uncommon", "hueCategory": "cheese", "paintNameID": 664421, "materialName": "cosm_cheese_vibrant_bright_coated_50_80_100"}
25	26	{"_key": 26, "finish": "matt", "rarity": "common", "hueCategory": "cheese", "paintNameID": 664422, "materialName": "cosm_cheese_vibrant_bright_matt_50_80_100"}
26	27	{"_key": 27, "finish": "satin", "rarity": "rare", "hueCategory": "cheese", "paintNameID": 664423, "materialName": "cosm_cheese_vibrant_bright_satin_50_80_100"}
27	28	{"_key": 28, "finish": "coated", "rarity": "uncommon", "hueCategory": "clover", "paintNameID": 664424, "materialName": "cosm_clover_vibrant_bright_coated_142_79_80"}
28	29	{"_key": 29, "finish": "matt", "rarity": "common", "hueCategory": "clover", "paintNameID": 664425, "materialName": "cosm_clover_vibrant_bright_matt_142_79_80"}
29	30	{"_key": 30, "finish": "satin", "rarity": "rare", "hueCategory": "clover", "paintNameID": 664426, "materialName": "cosm_clover_vibrant_bright_satin_142_79_80"}
30	31	{"_key": 31, "finish": "coated", "rarity": "uncommon", "hueCategory": "grape", "paintNameID": 664427, "materialName": "cosm_grape_vibrant_bright_coated_66_79_80"}
31	32	{"_key": 32, "finish": "matt", "rarity": "common", "hueCategory": "grape", "paintNameID": 664428, "materialName": "cosm_grape_vibrant_bright_matt_66_79_80"}
32	33	{"_key": 33, "finish": "satin", "rarity": "rare", "hueCategory": "grape", "paintNameID": 664429, "materialName": "cosm_grape_vibrant_bright_satin_66_79_80"}
33	34	{"_key": 34, "finish": "coated", "rarity": "uncommon", "hueCategory": "green", "paintNameID": 664430, "materialName": "cosm_green_vibrant_bright_coated_113_100_99"}
34	35	{"_key": 35, "finish": "matt", "rarity": "common", "hueCategory": "green", "paintNameID": 664431, "materialName": "cosm_green_vibrant_bright_matt_113_100_99"}
35	36	{"_key": 36, "finish": "satin", "rarity": "rare", "hueCategory": "green", "paintNameID": 664432, "materialName": "cosm_green_vibrant_bright_satin_113_100_99"}
36	37	{"_key": 37, "finish": "coated", "rarity": "uncommon", "hueCategory": "lavender", "paintNameID": 664433, "materialName": "cosm_lavender_vibrant_bright_coated_262_79_80"}
37	38	{"_key": 38, "finish": "matt", "rarity": "common", "hueCategory": "lavender", "paintNameID": 664434, "materialName": "cosm_lavender_vibrant_bright_matt_262_79_80"}
38	39	{"_key": 39, "finish": "satin", "rarity": "rare", "hueCategory": "lavender", "paintNameID": 664435, "materialName": "cosm_lavender_vibrant_bright_satin_262_79_80"}
39	40	{"_key": 40, "finish": "coated", "rarity": "uncommon", "hueCategory": "malachite", "paintNameID": 664436, "materialName": "cosm_malachite_vibrant_bright_coated_171_79_80"}
40	41	{"_key": 41, "finish": "matt", "rarity": "common", "hueCategory": "malachite", "paintNameID": 664437, "materialName": "cosm_malachite_vibrant_bright_matt_171_79_80"}
41	42	{"_key": 42, "finish": "satin", "rarity": "rare", "hueCategory": "malachite", "paintNameID": 664438, "materialName": "cosm_malachite_vibrant_bright_satin_171_79_80"}
42	43	{"_key": 43, "finish": "coated", "rarity": "uncommon", "hueCategory": "orange", "paintNameID": 664439, "materialName": "cosm_orange_soft_bright_coated_22_49_100"}
43	44	{"_key": 44, "finish": "matt", "rarity": "common", "hueCategory": "orange", "paintNameID": 664440, "materialName": "cosm_orange_soft_bright_matt_22_49_100"}
44	45	{"_key": 45, "finish": "satin", "rarity": "rare", "hueCategory": "orange", "paintNameID": 664441, "materialName": "cosm_orange_soft_bright_satin_22_49_100"}
45	46	{"_key": 46, "finish": "coated", "rarity": "uncommon", "hueCategory": "orange", "paintNameID": 664442, "materialName": "cosm_orange_vibrant_bright_coated_21_79_80"}
46	47	{"_key": 47, "finish": "coated", "rarity": "uncommon", "hueCategory": "orange", "paintNameID": 664443, "materialName": "cosm_orange_vibrant_bright_coated_31_100_100"}
47	48	{"_key": 48, "finish": "coated", "rarity": "uncommon", "hueCategory": "orange", "paintNameID": 664444, "materialName": "cosm_orange_vibrant_bright_coated_36_79_80"}
48	49	{"_key": 49, "finish": "matt", "rarity": "common", "hueCategory": "orange", "paintNameID": 664445, "materialName": "cosm_orange_vibrant_bright_matt_21_79_80"}
49	50	{"_key": 50, "finish": "matt", "rarity": "common", "hueCategory": "orange", "paintNameID": 664446, "materialName": "cosm_orange_vibrant_bright_matt_31_100_100"}
50	51	{"_key": 51, "finish": "matt", "rarity": "common", "hueCategory": "orange", "paintNameID": 664447, "materialName": "cosm_orange_vibrant_bright_matt_36_79_80"}
51	52	{"_key": 52, "finish": "satin", "rarity": "rare", "hueCategory": "orange", "paintNameID": 664448, "materialName": "cosm_orange_vibrant_bright_satin_21_79_80"}
52	53	{"_key": 53, "finish": "satin", "rarity": "rare", "hueCategory": "orange", "paintNameID": 664449, "materialName": "cosm_orange_vibrant_bright_satin_31_100_100"}
53	54	{"_key": 54, "finish": "satin", "rarity": "rare", "hueCategory": "orange", "paintNameID": 664450, "materialName": "cosm_orange_vibrant_bright_satin_36_79_80"}
54	55	{"_key": 55, "finish": "coated", "rarity": "uncommon", "hueCategory": "pea", "paintNameID": 664451, "materialName": "cosm_pea_vibrant_bright_coated_82_79_80"}
55	56	{"_key": 56, "finish": "matt", "rarity": "common", "hueCategory": "pea", "paintNameID": 664452, "materialName": "cosm_pea_vibrant_bright_matt_82_79_80"}
56	57	{"_key": 57, "finish": "satin", "rarity": "rare", "hueCategory": "pea", "paintNameID": 664453, "materialName": "cosm_pea_vibrant_bright_satin_82_79_80"}
57	58	{"_key": 58, "finish": "coated", "rarity": "uncommon", "hueCategory": "pea", "paintNameID": 664454, "materialName": "cosm_pea_vibrant_dark_coated_82_76_24"}
58	59	{"_key": 59, "finish": "matt", "rarity": "common", "hueCategory": "pea", "paintNameID": 664455, "materialName": "cosm_pea_vibrant_dark_matt_82_76_24"}
59	60	{"_key": 60, "finish": "satin", "rarity": "rare", "hueCategory": "pea", "paintNameID": 664456, "materialName": "cosm_pea_vibrant_dark_satin_82_76_24"}
60	61	{"_key": 61, "finish": "coated", "rarity": "uncommon", "hueCategory": "pea", "paintNameID": 664457, "materialName": "cosm_pea_vibrant_medium_coated_90_96_30"}
61	62	{"_key": 62, "finish": "matt", "rarity": "common", "hueCategory": "pea", "paintNameID": 664458, "materialName": "cosm_pea_vibrant_medium_matt_90_96_30"}
62	63	{"_key": 63, "finish": "satin", "rarity": "rare", "hueCategory": "pea", "paintNameID": 664459, "materialName": "cosm_pea_vibrant_medium_satin_90_96_30"}
63	64	{"_key": 64, "finish": "coated", "rarity": "uncommon", "hueCategory": "pink", "paintNameID": 664460, "materialName": "cosm_pink_vibrant_bright_coated_308_79_80"}
64	65	{"_key": 65, "finish": "matt", "rarity": "common", "hueCategory": "pink", "paintNameID": 664461, "materialName": "cosm_pink_vibrant_bright_matt_308_79_80"}
65	66	{"_key": 66, "finish": "satin", "rarity": "rare", "hueCategory": "pink", "paintNameID": 664462, "materialName": "cosm_pink_vibrant_bright_satin_308_79_80"}
66	67	{"_key": 67, "finish": "coated", "rarity": "uncommon", "hueCategory": "plum", "paintNameID": 664463, "materialName": "cosm_plum_soft_medium_coated_335_49_34"}
67	68	{"_key": 68, "finish": "matt", "rarity": "common", "hueCategory": "plum", "paintNameID": 664464, "materialName": "cosm_plum_soft_medium_matt_335_49_34"}
68	69	{"_key": 69, "finish": "satin", "rarity": "rare", "hueCategory": "plum", "paintNameID": 664465, "materialName": "cosm_plum_soft_medium_satin_335_49_34"}
69	70	{"_key": 70, "finish": "coated", "rarity": "uncommon", "hueCategory": "plum", "paintNameID": 664466, "materialName": "cosm_plum_vibrant_bright_coated_338_79_80"}
70	71	{"_key": 71, "finish": "coated", "rarity": "uncommon", "hueCategory": "plum", "paintNameID": 664467, "materialName": "cosm_plum_vibrant_bright_coated_351_79_80"}
71	72	{"_key": 72, "finish": "matt", "rarity": "common", "hueCategory": "plum", "paintNameID": 664468, "materialName": "cosm_plum_vibrant_bright_matt_338_79_80"}
72	73	{"_key": 73, "finish": "matt", "rarity": "common", "hueCategory": "plum", "paintNameID": 664469, "materialName": "cosm_plum_vibrant_bright_matt_351_79_80"}
73	74	{"_key": 74, "finish": "satin", "rarity": "rare", "hueCategory": "plum", "paintNameID": 664470, "materialName": "cosm_plum_vibrant_bright_satin_338_79_80"}
74	75	{"_key": 75, "finish": "satin", "rarity": "rare", "hueCategory": "plum", "paintNameID": 664471, "materialName": "cosm_plum_vibrant_bright_satin_351_79_80"}
75	76	{"_key": 76, "finish": "coated", "rarity": "uncommon", "hueCategory": "red", "paintNameID": 664472, "materialName": "cosm_red_vibrant_bright_coated_0_100_99"}
76	77	{"_key": 77, "finish": "coated", "rarity": "uncommon", "hueCategory": "red", "paintNameID": 664473, "materialName": "cosm_red_vibrant_bright_coated_7_79_80"}
77	78	{"_key": 78, "finish": "matt", "rarity": "common", "hueCategory": "red", "paintNameID": 664474, "materialName": "cosm_red_vibrant_bright_matt_0_100_99"}
78	79	{"_key": 79, "finish": "matt", "rarity": "common", "hueCategory": "red", "paintNameID": 664475, "materialName": "cosm_red_vibrant_bright_matt_7_79_80"}
79	80	{"_key": 80, "finish": "satin", "rarity": "rare", "hueCategory": "red", "paintNameID": 664476, "materialName": "cosm_red_vibrant_bright_satin_0_100_99"}
80	81	{"_key": 81, "finish": "satin", "rarity": "rare", "hueCategory": "red", "paintNameID": 664477, "materialName": "cosm_red_vibrant_bright_satin_7_79_80"}
81	82	{"_key": 82, "finish": "coated", "rarity": "uncommon", "hueCategory": "red", "paintNameID": 664478, "materialName": "cosm_red_vibrant_medium_coated_0_60_34"}
82	83	{"_key": 83, "finish": "coated", "rarity": "uncommon", "hueCategory": "red", "paintNameID": 664479, "materialName": "cosm_red_vibrant_medium_coated_12_50_44"}
83	84	{"_key": 84, "finish": "matt", "rarity": "common", "hueCategory": "red", "paintNameID": 664480, "materialName": "cosm_red_vibrant_medium_matt_0_60_34"}
84	85	{"_key": 85, "finish": "matt", "rarity": "common", "hueCategory": "red", "paintNameID": 664481, "materialName": "cosm_red_vibrant_medium_matt_12_50_44"}
85	86	{"_key": 86, "finish": "satin", "rarity": "rare", "hueCategory": "red", "paintNameID": 664482, "materialName": "cosm_red_vibrant_medium_satin_0_60_34"}
86	87	{"_key": 87, "finish": "satin", "rarity": "rare", "hueCategory": "red", "paintNameID": 664483, "materialName": "cosm_red_vibrant_medium_satin_12_50_44"}
87	89	{"_key": 89, "finish": "coated", "rarity": "uncommon", "hueCategory": "royal", "paintNameID": 664484, "materialName": "cosm_royal_vibrant_bright_coated_217_79_80"}
88	91	{"_key": 91, "finish": "matt", "rarity": "common", "hueCategory": "royal", "paintNameID": 664485, "materialName": "cosm_royal_vibrant_bright_matt_217_79_80"}
89	93	{"_key": 93, "finish": "satin", "rarity": "rare", "hueCategory": "royal", "paintNameID": 664486, "materialName": "cosm_royal_vibrant_bright_satin_217_79_80"}
90	94	{"_key": 94, "finish": "coated", "rarity": "uncommon", "hueCategory": "turmeric", "paintNameID": 664487, "materialName": "cosm_turmeric_vibrant_medium_coated_38_50_44"}
91	95	{"_key": 95, "finish": "matt", "rarity": "common", "hueCategory": "turmeric", "paintNameID": 664488, "materialName": "cosm_turmeric_vibrant_medium_matt_38_50_44"}
92	96	{"_key": 96, "finish": "satin", "rarity": "rare", "hueCategory": "turmeric", "paintNameID": 664489, "materialName": "cosm_turmeric_vibrant_medium_satin_38_50_44"}
93	97	{"_key": 97, "finish": "coated", "rarity": "uncommon", "hueCategory": "yellow", "paintNameID": 664490, "materialName": "cosm_yellow_vibrant_bright_coated_60_100_100"}
94	98	{"_key": 98, "finish": "matt", "rarity": "common", "hueCategory": "yellow", "paintNameID": 664491, "materialName": "cosm_yellow_vibrant_bright_matt_60_100_100"}
95	99	{"_key": 99, "finish": "satin", "rarity": "rare", "hueCategory": "yellow", "paintNameID": 664492, "materialName": "cosm_yellow_vibrant_bright_satin_60_100_100"}
\.


--
-- Name: paints paints_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.paints
    ADD CONSTRAINT paints_pkey PRIMARY KEY (row_no);


--
-- Name: paints_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX paints_key_idx ON sde_native.paints USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict tK7BXcedrjAgfYi0RqfrgvYEooyBmAcDIb78RbJdJwF8FAQlxjoy351k3B5Gvtu

