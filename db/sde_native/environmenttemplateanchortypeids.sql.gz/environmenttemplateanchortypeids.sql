--
-- PostgreSQL database dump
--

\restrict RbrKVkzBfthcVX7xXYMrespPxwPYCzueteVgwClbQhvPINLWCoB1athHIzRCM2j

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: environmenttemplateanchortypeids; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.environmenttemplateanchortypeids (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: environmenttemplateanchortypeids; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.environmenttemplateanchortypeids (row_no, key, data) FROM stdin;
0	6	{"_key": 6, "baseEnvironment": 30}
1	7	{"_key": 7, "baseEnvironment": 11}
2	8	{"_key": 8, "baseEnvironment": 24}
3	9	{"_key": 9, "baseEnvironment": 6}
4	10	{"_key": 10, "baseEnvironment": 26}
5	11	{"_key": 11, "baseEnvironment": 3154}
6	12	{"_key": 12, "baseEnvironment": 3150}
7	13	{"_key": 13, "baseEnvironment": 3148}
8	14	{"_key": 14, "baseEnvironment": 3157}
9	15	{"_key": 15, "baseEnvironment": 1}
10	16	{"_key": 16, "baseEnvironment": 503}
11	17	{"_key": 17, "baseEnvironment": 502}
12	2014	{"_key": 2014, "baseEnvironment": 3152}
13	2015	{"_key": 2015, "baseEnvironment": 3151}
14	2016	{"_key": 2016, "baseEnvironment": 3147}
15	2017	{"_key": 2017, "baseEnvironment": 3153}
16	2063	{"_key": 2063, "baseEnvironment": 3155}
17	3796	{"_key": 3796, "baseEnvironment": 10}
18	3797	{"_key": 3797, "baseEnvironment": 19}
19	3798	{"_key": 3798, "baseEnvironment": 17}
20	3799	{"_key": 3799, "baseEnvironment": 21}
21	3800	{"_key": 3800, "baseEnvironment": 14}
22	3801	{"_key": 3801, "baseEnvironment": 9}
23	3802	{"_key": 3802, "baseEnvironment": 33}
24	3803	{"_key": 3803, "baseEnvironment": 28}
25	3873	{"_key": 3873, "baseEnvironment": 503}
26	3874	{"_key": 3874, "baseEnvironment": 504}
27	3875	{"_key": 3875, "baseEnvironment": 504}
28	3876	{"_key": 3876, "baseEnvironment": 504}
29	3877	{"_key": 3877, "baseEnvironment": 505}
30	12292	{"_key": 12292, "baseEnvironment": 501}
31	19713	{"_key": 19713, "baseEnvironment": 2689}
32	19746	{"_key": 19746, "baseEnvironment": 2702}
33	19747	{"_key": 19747, "baseEnvironment": 2703}
34	19748	{"_key": 19748, "baseEnvironment": 2704}
35	19749	{"_key": 19749, "baseEnvironment": 2705}
36	19750	{"_key": 19750, "baseEnvironment": 2706}
37	19751	{"_key": 19751, "baseEnvironment": 2707}
38	19752	{"_key": 19752, "baseEnvironment": 2708}
39	19753	{"_key": 19753, "baseEnvironment": 2709}
40	19754	{"_key": 19754, "baseEnvironment": 2710}
41	19755	{"_key": 19755, "baseEnvironment": 2711}
42	19756	{"_key": 19756, "baseEnvironment": 2712}
43	29624	{"_key": 29624, "baseEnvironment": 502}
44	29625	{"_key": 29625, "baseEnvironment": 502}
45	29626	{"_key": 29626, "baseEnvironment": 502}
46	29627	{"_key": 29627, "baseEnvironment": 503}
47	29629	{"_key": 29629, "baseEnvironment": 503}
48	29632	{"_key": 29632, "baseEnvironment": 504}
49	29633	{"_key": 29633, "baseEnvironment": 505}
50	29634	{"_key": 29634, "baseEnvironment": 505}
51	29635	{"_key": 29635, "baseEnvironment": 505}
52	30889	{"_key": 30889, "baseEnvironment": 3156}
53	34331	{"_key": 34331, "baseEnvironment": 23}
54	35841	{"_key": 35841, "baseEnvironment": 501}
55	45006	{"_key": 45006, "overrides": {"189": 35, "228": 37}}
56	45030	{"_key": 45030, "baseEnvironment": 31}
57	45031	{"_key": 45031, "baseEnvironment": 12}
58	45032	{"_key": 45032, "baseEnvironment": 13}
59	45033	{"_key": 45033, "baseEnvironment": 25}
60	45034	{"_key": 45034, "baseEnvironment": 7}
61	45035	{"_key": 45035, "baseEnvironment": 27}
62	45036	{"_key": 45036, "baseEnvironment": 20}
63	45037	{"_key": 45037, "baseEnvironment": 18}
64	45038	{"_key": 45038, "baseEnvironment": 22}
65	45039	{"_key": 45039, "baseEnvironment": 15}
66	45040	{"_key": 45040, "baseEnvironment": 16}
67	45041	{"_key": 45041, "baseEnvironment": 34}
68	45042	{"_key": 45042, "baseEnvironment": 29}
69	45046	{"_key": 45046, "baseEnvironment": 8}
70	45047	{"_key": 45047, "baseEnvironment": 32}
71	47378	{"_key": 47378, "baseEnvironment": 49}
72	47379	{"_key": 47379, "baseEnvironment": 50}
73	47380	{"_key": 47380, "baseEnvironment": 51}
74	47381	{"_key": 47381, "baseEnvironment": 40}
75	47382	{"_key": 47382, "baseEnvironment": 41}
76	47383	{"_key": 47383, "baseEnvironment": 42}
77	47384	{"_key": 47384, "baseEnvironment": 46}
78	47385	{"_key": 47385, "baseEnvironment": 47}
79	47386	{"_key": 47386, "baseEnvironment": 48}
80	47387	{"_key": 47387, "baseEnvironment": 43}
81	47388	{"_key": 47388, "baseEnvironment": 44}
82	47389	{"_key": 47389, "baseEnvironment": 45}
83	47390	{"_key": 47390, "baseEnvironment": 52}
84	47391	{"_key": 47391, "baseEnvironment": 53}
85	47392	{"_key": 47392, "baseEnvironment": 54}
86	47393	{"_key": 47393, "baseEnvironment": 39}
87	49104	{"_key": 49104, "baseEnvironment": 105}
88	49105	{"_key": 49105, "baseEnvironment": 106}
89	49106	{"_key": 49106, "baseEnvironment": 107}
90	49107	{"_key": 49107, "baseEnvironment": 108}
91	49110	{"_key": 49110, "baseEnvironment": 110}
92	49126	{"_key": 49126, "baseEnvironment": 99}
93	49418	{"_key": 49418, "baseEnvironment": 112}
94	49615	{"_key": 49615, "baseEnvironment": 111}
95	49754	{"_key": 49754, "baseEnvironment": 55}
96	49757	{"_key": 49757, "baseEnvironment": 111}
97	49758	{"_key": 49758, "baseEnvironment": 111}
98	50096	{"_key": 50096, "baseEnvironment": 123}
99	50125	{"_key": 50125, "baseEnvironment": 502}
100	52326	{"_key": 52326, "baseEnvironment": 124}
101	52327	{"_key": 52327, "baseEnvironment": 125}
102	52328	{"_key": 52328, "baseEnvironment": 126}
103	52364	{"_key": 52364, "baseEnvironment": 2508}
104	52518	{"_key": 52518, "baseEnvironment": 2517}
105	52590	{"_key": 52590, "baseEnvironment": 2518}
106	52673	{"_key": 52673, "baseEnvironment": 3157}
107	52678	{"_key": 52678, "baseEnvironment": 2573}
108	53342	{"_key": 53342, "baseEnvironment": 2520}
109	53885	{"_key": 53885, "baseEnvironment": 2556}
110	54837	{"_key": 54837, "baseEnvironment": 2558}
111	55765	{"_key": 55765, "baseEnvironment": 2559}
112	56018	{"_key": 56018, "baseEnvironment": 3147}
113	56019	{"_key": 56019, "baseEnvironment": 3150}
114	56020	{"_key": 56020, "baseEnvironment": 3151}
115	56021	{"_key": 56021, "baseEnvironment": 3152}
116	56022	{"_key": 56022, "baseEnvironment": 3155}
117	56023	{"_key": 56023, "baseEnvironment": 3154}
118	56024	{"_key": 56024, "baseEnvironment": 3153}
119	56047	{"_key": 56047, "baseEnvironment": 2560}
120	56048	{"_key": 56048, "baseEnvironment": 2561}
121	56049	{"_key": 56049, "baseEnvironment": 2562}
122	56050	{"_key": 56050, "baseEnvironment": 2563}
123	56051	{"_key": 56051, "baseEnvironment": 2564}
124	56052	{"_key": 56052, "baseEnvironment": 2565}
125	56053	{"_key": 56053, "baseEnvironment": 2566}
126	56054	{"_key": 56054, "baseEnvironment": 2567}
127	56055	{"_key": 56055, "baseEnvironment": 2568}
128	56056	{"_key": 56056, "baseEnvironment": 2569}
129	56703	{"_key": 56703, "baseEnvironment": 2569}
130	56736	{"_key": 56736, "baseEnvironment": 2571}
131	57034	{"_key": 57034, "baseEnvironment": 2576}
132	57043	{"_key": 57043, "baseEnvironment": 2580}
133	57044	{"_key": 57044, "baseEnvironment": 2577}
134	57225	{"_key": 57225, "baseEnvironment": 2581}
135	57685	{"_key": 57685, "baseEnvironment": 2586}
136	57760	{"_key": 57760, "baseEnvironment": 2588}
137	58734	{"_key": 58734, "baseEnvironment": 2592}
138	59482	{"_key": 59482, "baseEnvironment": 2600}
139	59483	{"_key": 59483, "baseEnvironment": 43}
140	60123	{"_key": 60123, "baseEnvironment": 3256}
141	60124	{"_key": 60124, "baseEnvironment": 3256}
142	61195	{"_key": 61195, "baseEnvironment": 2601}
143	61196	{"_key": 61196, "baseEnvironment": 2602}
144	61923	{"_key": 61923, "baseEnvironment": 3256}
145	61925	{"_key": 61925, "baseEnvironment": 3256}
146	64024	{"_key": 64024, "baseEnvironment": 3250}
147	64025	{"_key": 64025, "baseEnvironment": 3250}
148	64026	{"_key": 64026, "baseEnvironment": 3250}
149	64027	{"_key": 64027, "baseEnvironment": 3250}
150	64028	{"_key": 64028, "baseEnvironment": 3250}
151	64030	{"_key": 64030, "baseEnvironment": 3250}
152	64031	{"_key": 64031, "baseEnvironment": 3250}
153	64032	{"_key": 64032, "baseEnvironment": 3250}
154	64057	{"_key": 64057, "baseEnvironment": 3250}
155	64058	{"_key": 64058, "baseEnvironment": 3250}
156	64059	{"_key": 64059, "baseEnvironment": 3250}
157	64060	{"_key": 64060, "baseEnvironment": 3250}
158	64061	{"_key": 64061, "baseEnvironment": 3250}
159	64062	{"_key": 64062, "baseEnvironment": 3250}
160	64063	{"_key": 64063, "baseEnvironment": 3250}
161	64064	{"_key": 64064, "baseEnvironment": 3250}
162	64065	{"_key": 64065, "baseEnvironment": 3250}
163	64066	{"_key": 64066, "baseEnvironment": 3250}
164	64067	{"_key": 64067, "baseEnvironment": 3250}
165	64068	{"_key": 64068, "baseEnvironment": 3250}
166	64069	{"_key": 64069, "baseEnvironment": 3250}
167	64070	{"_key": 64070, "baseEnvironment": 3250}
168	64071	{"_key": 64071, "baseEnvironment": 3250}
169	64072	{"_key": 64072, "baseEnvironment": 3250}
170	64073	{"_key": 64073, "baseEnvironment": 3250}
171	64074	{"_key": 64074, "baseEnvironment": 3250}
172	64075	{"_key": 64075, "baseEnvironment": 3250}
173	64076	{"_key": 64076, "baseEnvironment": 3250}
174	64077	{"_key": 64077, "baseEnvironment": 3250}
175	64602	{"_key": 64602, "baseEnvironment": 2716}
176	64603	{"_key": 64603, "baseEnvironment": 2722}
177	64604	{"_key": 64604, "baseEnvironment": 2678}
178	64605	{"_key": 64605, "baseEnvironment": 2715}
179	64606	{"_key": 64606, "baseEnvironment": 2720}
180	64607	{"_key": 64607, "baseEnvironment": 2681}
181	64608	{"_key": 64608, "baseEnvironment": 2717}
182	64609	{"_key": 64609, "baseEnvironment": 2718}
183	64610	{"_key": 64610, "baseEnvironment": 2679}
184	64611	{"_key": 64611, "baseEnvironment": 2719}
185	64612	{"_key": 64612, "baseEnvironment": 2721}
186	64613	{"_key": 64613, "baseEnvironment": 2680}
187	64614	{"_key": 64614, "baseEnvironment": 2727}
188	64615	{"_key": 64615, "baseEnvironment": 2728}
189	64616	{"_key": 64616, "baseEnvironment": 2688}
190	64617	{"_key": 64617, "baseEnvironment": 2682}
191	64618	{"_key": 64618, "baseEnvironment": 2683}
192	64619	{"_key": 64619, "baseEnvironment": 2684}
193	64620	{"_key": 64620, "baseEnvironment": 2685}
194	64621	{"_key": 64621, "baseEnvironment": 2686}
195	64622	{"_key": 64622, "baseEnvironment": 2687}
196	64623	{"_key": 64623, "baseEnvironment": 3250}
197	64629	{"_key": 64629, "baseEnvironment": 3250}
198	64821	{"_key": 64821, "baseEnvironment": 3256}
199	64822	{"_key": 64822, "baseEnvironment": 3256}
200	64823	{"_key": 64823, "baseEnvironment": 3256}
201	64890	{"_key": 64890, "baseEnvironment": 0}
202	77876	{"_key": 77876, "baseEnvironment": 3090}
203	77918	{"_key": 77918, "baseEnvironment": 3090}
204	78187	{"_key": 78187, "baseEnvironment": 3087}
205	78264	{"_key": 78264, "baseEnvironment": 3090}
206	78265	{"_key": 78265, "baseEnvironment": 3090}
207	78266	{"_key": 78266, "baseEnvironment": 3090}
208	78350	{"_key": 78350, "baseEnvironment": 3087}
209	85090	{"_key": 85090, "baseEnvironment": 3256}
210	85091	{"_key": 85091, "baseEnvironment": 3256}
211	85092	{"_key": 85092, "baseEnvironment": 3256}
212	85093	{"_key": 85093, "baseEnvironment": 3256}
213	85094	{"_key": 85094, "baseEnvironment": 3256}
214	85095	{"_key": 85095, "baseEnvironment": 3256}
215	85096	{"_key": 85096, "baseEnvironment": 3256}
216	85097	{"_key": 85097, "baseEnvironment": 3256}
217	85098	{"_key": 85098, "baseEnvironment": 3256}
218	85099	{"_key": 85099, "baseEnvironment": 3256}
219	85100	{"_key": 85100, "baseEnvironment": 3256}
220	85101	{"_key": 85101, "baseEnvironment": 3256}
221	85102	{"_key": 85102, "baseEnvironment": 3256}
222	85103	{"_key": 85103, "baseEnvironment": 3256}
223	85114	{"_key": 85114, "baseEnvironment": 3244}
224	85115	{"_key": 85115, "baseEnvironment": 3245}
225	85116	{"_key": 85116, "baseEnvironment": 3246}
226	85625	{"_key": 85625, "baseEnvironment": 3296}
227	85626	{"_key": 85626, "baseEnvironment": 3297}
228	85627	{"_key": 85627, "baseEnvironment": 3298}
229	87725	{"_key": 87725, "baseEnvironment": 3351}
230	88113	{"_key": 88113, "baseEnvironment": 3352}
231	88131	{"_key": 88131, "baseEnvironment": 3354}
232	88132	{"_key": 88132, "baseEnvironment": 3353}
233	88246	{"_key": 88246, "baseEnvironment": 3357}
234	88247	{"_key": 88247, "baseEnvironment": 3358}
235	88427	{"_key": 88427, "baseEnvironment": 3359}
236	93272	{"_key": 93272, "baseEnvironment": 3465}
237	94169	{"_key": 94169, "baseEnvironment": 3474}
238	95165	{"_key": 95165, "baseEnvironment": 3480}
239	95166	{"_key": 95166, "baseEnvironment": 3481}
240	95167	{"_key": 95167, "baseEnvironment": 3482}
241	95168	{"_key": 95168, "baseEnvironment": 3483}
242	95171	{"_key": 95171, "baseEnvironment": 3484}
243	95172	{"_key": 95172, "baseEnvironment": 3485}
244	95178	{"_key": 95178, "baseEnvironment": 3486}
245	95179	{"_key": 95179, "baseEnvironment": 3487}
\.


--
-- Name: environmenttemplateanchortypeids environmenttemplateanchortypeids_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.environmenttemplateanchortypeids
    ADD CONSTRAINT environmenttemplateanchortypeids_pkey PRIMARY KEY (row_no);


--
-- Name: environmenttemplateanchortypeids_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX environmenttemplateanchortypeids_key_idx ON sde_native.environmenttemplateanchortypeids USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict RbrKVkzBfthcVX7xXYMrespPxwPYCzueteVgwClbQhvPINLWCoB1athHIzRCM2j

