--
-- PostgreSQL database dump
--

\restrict qQwNTlhcCxVoWFlprh2dGwdd5cgKzEOZW8NH8bqm5fkv1hPdZPK9weNNPwXoozg

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: infobubbles__infobubblefactions; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.infobubbles__infobubblefactions (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: infobubbles__infobubblefactions; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.infobubbles__infobubblefactions (row_no, key, data) FROM stdin;
0	500001	{"_key": 500001, "icon": "res:/UI/Texture/Classes/ShipTree/factions/caldari.png", "elements": {"1": 9, "2": 12, "3": 20, "4": 15}, "descriptionID": 500621}
1	500002	{"_key": 500002, "icon": "res:/UI/Texture/Classes/ShipTree/factions/minmatar.png", "elements": {"1": 10, "2": 9, "3": 7, "4": 20, "5": 16, "6": 18}, "descriptionID": 500623}
2	500003	{"_key": 500003, "icon": "res:/UI/Texture/Classes/ShipTree/factions/amarr.png", "elements": {"1": 8, "2": 11, "3": 7, "4": 17, "5": 13}, "descriptionID": 500620}
3	500004	{"_key": 500004, "icon": "res:/UI/Texture/Classes/ShipTree/factions/gallente.png", "elements": {"1": 12, "2": 11, "3": 7, "4": 14, "5": 19}, "descriptionID": 500622}
4	500006	{"_key": 500006, "icon": "res:/UI/texture/icons/75_32_16.png", "elements": {"1": 2046}, "descriptionID": 708515}
5	500010	{"_key": 500010, "icon": "res:/UI/texture/icons/75_32_10.png", "elements": {"1": 11, "2": 9, "3": 20}, "descriptionID": 500627}
6	500011	{"_key": 500011, "icon": "res:/UI/texture/icons/75_32_11.png", "elements": {"1": 10, "2": 20}, "descriptionID": 500625}
7	500012	{"_key": 500012, "icon": "res:/UI/texture/icons/75_32_20.png", "elements": {"1": 8, "2": 7, "3": 13, "4": 18}, "descriptionID": 500626}
8	500014	{"_key": 500014, "icon": "res:/UI/texture/icons/75_32_13.png", "elements": {"1": 20}, "descriptionID": 500624}
9	500016	{"_key": 500016, "icon": "res:/UI/texture/icons/75_32_15.png", "elements": {"1": 11, "2": 8, "3": 7}, "descriptionID": 500630}
10	500017	{"_key": 500017, "icon": "res:/UI/texture/icons/75_32_6.png", "elements": {"1": 28, "2": 2046}, "descriptionID": 708516}
11	500018	{"_key": 500018, "icon": "res:/UI/texture/icons/75_32_17.png", "elements": {"1": 9, "2": 20, "3": 19}, "descriptionID": 503538}
12	500019	{"_key": 500019, "icon": "res:/UI/texture/icons/75_32_18.png", "elements": {"1": 8, "2": 20}, "descriptionID": 500628}
13	500020	{"_key": 500020, "icon": "res:/UI/texture/icons/75_32_19.png", "elements": {"1": 12, "2": 7, "3": 18}, "descriptionID": 500629}
14	500026	{"_key": 500026, "icon": "res:/UI/texture/icons/triglavianCollective.png", "elements": {"1": 45, "2": 7, "3": 13}, "descriptionID": 535747}
15	500027	{"_key": 500027, "icon": "res:/UI/texture/icons/triglavianCollective.png", "elements": {"1": 2048, "2": 20}, "descriptionID": 564591}
16	500029	{"_key": 500029, "icon": "res:/UI/Texture/Classes/ShipTree/factions/deathless.png", "elements": {"1": 2056, "2": 10, "3": 9, "4": 20}, "descriptionID": 727470}
17	500034	{"_key": 500034, "icon": "res:/UI/Texture/Classes/ShipTree/factions/solarflare.png", "elements": {"1": 20, "2": 7, "3": 8, "4": 12, "5": 10, "6": 9}, "descriptionID": 596564}
\.


--
-- Name: infobubbles__infobubblefactions infobubbles__infobubblefactions_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.infobubbles__infobubblefactions
    ADD CONSTRAINT infobubbles__infobubblefactions_pkey PRIMARY KEY (row_no);


--
-- Name: infobubbles__infobubblefactions_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX infobubbles__infobubblefactions_key_idx ON sde_native.infobubbles__infobubblefactions USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict qQwNTlhcCxVoWFlprh2dGwdd5cgKzEOZW8NH8bqm5fkv1hPdZPK9weNNPwXoozg

