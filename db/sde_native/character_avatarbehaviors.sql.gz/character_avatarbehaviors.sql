--
-- PostgreSQL database dump
--

\restrict JOFgRIwhtTgLDmWplXbYA3SH8SthyFaxCpY7Oqbhmg8FtmXp5DFyGBUSNadjvAI

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: character_avatarbehaviors; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.character_avatarbehaviors (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: character_avatarbehaviors; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.character_avatarbehaviors (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "name": "aura_template_behavior", "resGender": 0, "resPathList": ["res:\\\\Animation_Gstate\\\\Scenes\\\\Templates\\\\Aura\\\\Template_Aura_Neutral\\\\curvesets\\\\Aura_V3_Effect_HeadGlow_Blue_0.red", "res:\\\\Animation_Gstate\\\\Scenes\\\\Templates\\\\Aura\\\\Template_Aura_Neutral\\\\curvesets\\\\Aura_V3_Effect_HeadGlow_SpecularAlpha_0.red", "res:\\\\Animation_Gstate\\\\Scenes\\\\Templates\\\\Aura\\\\Template_Aura_Neutral\\\\curvesets\\\\Aura_V3_Effect_HeadGlow_Threshold_0.red"]}
\.


--
-- Name: character_avatarbehaviors character_avatarbehaviors_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.character_avatarbehaviors
    ADD CONSTRAINT character_avatarbehaviors_pkey PRIMARY KEY (row_no);


--
-- Name: character_avatarbehaviors_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX character_avatarbehaviors_key_idx ON sde_native.character_avatarbehaviors USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict JOFgRIwhtTgLDmWplXbYA3SH8SthyFaxCpY7Oqbhmg8FtmXp5DFyGBUSNadjvAI

