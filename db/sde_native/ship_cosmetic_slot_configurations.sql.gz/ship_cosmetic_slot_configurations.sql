--
-- PostgreSQL database dump
--

\restrict jueGMTXACbA2bwupODQQurUgw8v5PeTp3aX6BpSjUI4zsCWgEkQ6l4gcS0J5iei

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ship_cosmetic_slot_configurations; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.ship_cosmetic_slot_configurations (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: ship_cosmetic_slot_configurations; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.ship_cosmetic_slot_configurations (row_no, key, data) FROM stdin;
0	5	{"_key": 5, "name": "Default configuration", "config": [1, 2, 3, 4, 5, 6, 7, 8], "priority": 3, "allow_all_ships": 1}
1	6	{"_key": 6, "name": "No custom skins allowed", "ships": [29986, 29988, 29990, 29984, 670, 33328, 74316, 74141, 60765, 60764, 48636, 48635, 42246, 42245, 35781, 35779, 33675, 33673, 33397, 33395, 32790, 32788, 32209, 32207, 34317, 34828, 34562, 29986, 11942, 35683, 3518, 3516, 2836, 2834, 58745, 45531, 45530, 34590, 32811, 30842, 27305, 27303, 27301, 27299, 26842, 25560, 21628, 21097, 11019, 11011, 9862, 9860, 9854, 4388, 4363, 3532, 2078, 1233, 617, 11940, 11936, 11938, 615, 33079, 77726, 34496, 33081, 26840, 33083, 45534, 78414, 635, 44993, 44995, 33513, 33553, 2863, 13202, 44996, 85236, 85062, 85229, 89807, 89808, 64034, 75993, 76009, 77980, 77500, 80983, 81386, 82192, 84004, 84219, 84373, 78589, 84925, 70891, 70882, 70881, 65101, 70893, 73893, 73891, 73907, 73885, 75678, 75679, 75681, 78353, 72160, 72654, 72655, 72656, 72161, 72657, 72658, 72659, 73476, 73477, 73478, 73479, 75737, 75738, 75739, 75740, 74108, 86485, 89107, 91901], "config": [], "priority": 0}
2	7	{"_key": 7, "name": "NoSecondarySlot", "ships": [47269, 52250, 49710, 52254, 47270, 49712, 52252, 49713, 49711, 47271, 52907, 88001], "config": [1, 3, 4, 5, 6, 7, 8], "priority": 1}
3	8	{"_key": 8, "name": "NoDetailingSlot", "ships": [77283, 28844, 20185], "config": [1, 2, 4, 5, 6, 7, 8], "priority": 2}
\.


--
-- Name: ship_cosmetic_slot_configurations ship_cosmetic_slot_configurations_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.ship_cosmetic_slot_configurations
    ADD CONSTRAINT ship_cosmetic_slot_configurations_pkey PRIMARY KEY (row_no);


--
-- Name: ship_cosmetic_slot_configurations_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX ship_cosmetic_slot_configurations_key_idx ON sde_native.ship_cosmetic_slot_configurations USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict jueGMTXACbA2bwupODQQurUgw8v5PeTp3aX6BpSjUI4zsCWgEkQ6l4gcS0J5iei

