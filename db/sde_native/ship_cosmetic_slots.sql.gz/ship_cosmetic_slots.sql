--
-- PostgreSQL database dump
--

\restrict NVWR8OYNqkYXexwUdc2gmwScfvNIIwYH2dCWyAmXGdYQIICfdKWGkCDVfMzkUFU

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ship_cosmetic_slots; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.ship_cosmetic_slots (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: ship_cosmetic_slots; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.ship_cosmetic_slots (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "name": 709823, "category": 1, "description": 709822, "internal_name": 1, "allowed_design_component_categories": [1, 3]}
1	2	{"_key": 2, "name": 709825, "category": 1, "description": 709824, "internal_name": 2, "allowed_design_component_categories": [1, 3]}
2	3	{"_key": 3, "name": 709827, "category": 1, "description": 709826, "internal_name": 3, "allowed_design_component_categories": [1, 3]}
3	4	{"_key": 4, "name": 709829, "category": 1, "description": 709828, "internal_name": 4, "allowed_design_component_categories": [3, 1]}
4	5	{"_key": 5, "name": 709831, "category": 2, "description": 709830, "internal_name": 5, "allowed_design_component_categories": [2]}
5	6	{"_key": 6, "name": 709876, "category": 3, "description": 709875, "internal_name": 6, "allowed_design_component_categories": [1, 3]}
6	7	{"_key": 7, "name": 725961, "category": 2, "description": 725960, "internal_name": 7, "allowed_design_component_categories": [2]}
7	8	{"_key": 8, "name": 726303, "category": 3, "description": 726302, "internal_name": 8, "allowed_design_component_categories": [1, 3]}
\.


--
-- Name: ship_cosmetic_slots ship_cosmetic_slots_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.ship_cosmetic_slots
    ADD CONSTRAINT ship_cosmetic_slots_pkey PRIMARY KEY (row_no);


--
-- Name: ship_cosmetic_slots_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX ship_cosmetic_slots_key_idx ON sde_native.ship_cosmetic_slots USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict NVWR8OYNqkYXexwUdc2gmwScfvNIIwYH2dCWyAmXGdYQIICfdKWGkCDVfMzkUFU

