--
-- PostgreSQL database dump
--

\restrict bw7dHWBKwR8jYapdg9npaCZQ1DtgzqAoUNYOeBd5jxvxyNfUpMkD6MbqhhuRjve

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ship_cosmetic_slot_names; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.ship_cosmetic_slot_names (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: ship_cosmetic_slot_names; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.ship_cosmetic_slot_names (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "name": "primary_nanocoating"}
1	2	{"_key": 2, "name": "secondary_nanocoating"}
2	3	{"_key": 3, "name": "tertiary_nanocoating"}
3	4	{"_key": 4, "name": "tech_area"}
4	5	{"_key": 5, "name": "pattern"}
5	6	{"_key": 6, "name": "pattern_material"}
6	7	{"_key": 7, "name": "secondary_pattern"}
7	8	{"_key": 8, "name": "secondary_pattern_material"}
\.


--
-- Name: ship_cosmetic_slot_names ship_cosmetic_slot_names_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.ship_cosmetic_slot_names
    ADD CONSTRAINT ship_cosmetic_slot_names_pkey PRIMARY KEY (row_no);


--
-- Name: ship_cosmetic_slot_names_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX ship_cosmetic_slot_names_key_idx ON sde_native.ship_cosmetic_slot_names USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict bw7dHWBKwR8jYapdg9npaCZQ1DtgzqAoUNYOeBd5jxvxyNfUpMkD6MbqhhuRjve

