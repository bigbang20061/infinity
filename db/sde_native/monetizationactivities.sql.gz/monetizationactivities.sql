--
-- PostgreSQL database dump
--

\restrict ByQTkd7E08XhS81hLNVtt9ms1SrXry8s6hkBrxeaje2CxIA8tfyRZweh9bJvxio

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: monetizationactivities; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.monetizationactivities (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: monetizationactivities; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.monetizationactivities (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "entries": [{"entry_id": 1, "condition": 0, "reward_items": [], "repeatedly_taken": 0, "reward_currencies": [{"amount": 0, "currency_type": 2, "use_input_amount": 1, "input_amount_factor": 0.1}]}, {"entry_id": 2, "condition": 0, "reward_items": [], "repeatedly_taken": 0, "reward_currencies": [{"amount": 0, "currency_type": 2, "use_input_amount": 1, "input_amount_factor": 0.11}]}, {"entry_id": 3, "condition": 0, "reward_items": [], "repeatedly_taken": 0, "reward_currencies": [{"amount": 0, "currency_type": 2, "use_input_amount": 1, "input_amount_factor": 0.12}]}, {"entry_id": 4, "condition": 0, "reward_items": [], "repeatedly_taken": 0, "reward_currencies": [{"amount": 0, "currency_type": 2, "use_input_amount": 1, "input_amount_factor": 0.13}]}, {"entry_id": 5, "condition": 0, "reward_items": [], "repeatedly_taken": 0, "reward_currencies": [{"amount": 0, "currency_type": 2, "use_input_amount": 1, "input_amount_factor": 0.14}]}, {"entry_id": 6, "condition": 0, "reward_items": [], "repeatedly_taken": 0, "reward_currencies": [{"amount": 0, "currency_type": 2, "use_input_amount": 1, "input_amount_factor": 0.15}]}, {"entry_id": 7, "condition": 0, "reward_items": [], "repeatedly_taken": 0, "reward_currencies": [{"amount": 0, "currency_type": 2, "use_input_amount": 1, "input_amount_factor": 0.16}]}], "name_id": 623884, "activity_type": 1, "stat_from_npe": 0, "unlock_by_day": 1, "reset_if_break": 0, "stat_end_datetime": "2022-08-07 03:00", "is_character_level": 0, "process_event_type": 10200, "reward_end_datetime": "2022-08-13 03:00", "stat_start_datetime": "2022-08-01 03:00", "max_entry_gain_count": 999999, "reward_start_datetime": "2022-08-07 03:00"}
1	2	{"_key": 2, "entries": [{"entry_id": 1, "condition": 110, "reward_items": [{"amount": 1, "type_id": 72405, "is_soul_bound": 1}, {"amount": 2, "type_id": 72229, "is_soul_bound": 1}, {"amount": 1, "type_id": 72409, "is_soul_bound": 1}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 2, "condition": 330, "reward_items": [{"amount": 1, "type_id": 65139, "is_soul_bound": 1}, {"amount": 3, "type_id": 72229, "is_soul_bound": 1}, {"amount": 5, "type_id": 72409, "is_soul_bound": 1}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 3, "condition": 660, "reward_items": [{"amount": 1, "type_id": 64788, "is_soul_bound": 1}, {"amount": 5, "type_id": 72229, "is_soul_bound": 1}, {"amount": 10, "type_id": 72409, "is_soul_bound": 1}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 4, "condition": 1320, "reward_items": [{"amount": 1, "type_id": 70882, "is_soul_bound": 1}, {"amount": 100, "type_id": 72080, "is_soul_bound": 1}, {"amount": 1, "type_id": 72169, "is_soul_bound": 1}, {"amount": 1, "type_id": 72326, "is_soul_bound": 1}, {"amount": 5, "type_id": 72229, "is_soul_bound": 1}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 5, "condition": 3300, "reward_items": [{"amount": 10, "type_id": 72230, "is_soul_bound": 1}, {"amount": 30, "type_id": 72229, "is_soul_bound": 1}, {"amount": 50, "type_id": 72409, "is_soul_bound": 1}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 6, "condition": 6600, "reward_items": [{"amount": 1, "type_id": 70881, "is_soul_bound": 1}, {"amount": 100, "type_id": 72079, "is_soul_bound": 1}, {"amount": 1, "type_id": 72170, "is_soul_bound": 1}, {"amount": 1, "type_id": 72327, "is_soul_bound": 1}, {"amount": 20, "type_id": 72229, "is_soul_bound": 1}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 7, "condition": 13200, "reward_items": [{"amount": 1, "type_id": 72547, "is_soul_bound": 1}, {"amount": 20, "type_id": 72230, "is_soul_bound": 1}, {"amount": 75, "type_id": 72409, "is_soul_bound": 1}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 8, "condition": 33000, "reward_items": [{"amount": 1, "type_id": 65101, "is_soul_bound": 1}, {"amount": 100, "type_id": 72078, "is_soul_bound": 1}, {"amount": 1, "type_id": 72328, "is_soul_bound": 1}, {"amount": 20, "type_id": 72230, "is_soul_bound": 1}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 9, "condition": 66000, "reward_items": [{"amount": 1, "type_id": 70893, "is_soul_bound": 1}, {"amount": 100, "type_id": 72081, "is_soul_bound": 1}, {"amount": 1, "type_id": 72329, "is_soul_bound": 1}, {"amount": 100, "type_id": 72230, "is_soul_bound": 1}, {"amount": 1, "type_id": 70892, "is_soul_bound": 1}], "repeatedly_taken": 0, "reward_currencies": []}], "name_id": 623885, "activity_type": 3, "stat_from_npe": 0, "unlock_by_day": 0, "reset_if_break": 0, "stat_end_datetime": "2032-09-12 03:00", "is_character_level": 0, "process_event_type": 10100, "reward_end_datetime": "2032-09-12 03:00", "stat_start_datetime": "2022-08-22 03:00", "max_entry_gain_count": 999999, "reward_start_datetime": "2022-08-22 03:00"}
2	3	{"_key": 3, "entries": [{"entry_id": 1, "condition": 440, "reward_items": [{"amount": 1, "type_id": 49810, "is_soul_bound": 0}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 2, "condition": 440, "reward_items": [{"amount": 1, "type_id": 49810, "is_soul_bound": 0}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 3, "condition": 440, "reward_items": [{"amount": 1, "type_id": 49810, "is_soul_bound": 0}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 4, "condition": 440, "reward_items": [{"amount": 1, "type_id": 49810, "is_soul_bound": 0}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 5, "condition": 440, "reward_items": [{"amount": 1, "type_id": 49810, "is_soul_bound": 0}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 6, "condition": 440, "reward_items": [{"amount": 1, "type_id": 49810, "is_soul_bound": 0}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 7, "condition": 440, "reward_items": [{"amount": 4, "type_id": 49810, "is_soul_bound": 0}], "repeatedly_taken": 0, "reward_currencies": []}], "name_id": 623886, "activity_type": 4, "stat_from_npe": 0, "unlock_by_day": 1, "reset_if_break": 1, "stat_end_datetime": "2022-09-12 03:00", "is_character_level": 0, "process_event_type": 10200, "reward_end_datetime": "2022-09-12 03:00", "max_entry_gain_count": 7, "reward_start_datetime": "2022-08-22 03:00"}
3	4	{"_key": 4, "entries": [{"entry_id": 1, "condition": 1, "reward_items": [{"amount": 1, "type_id": 72545, "is_soul_bound": 0}], "repeatedly_taken": 1, "reward_currencies": []}], "name_id": 623887, "activity_type": 2, "stat_from_npe": 0, "unlock_by_day": 0, "reset_if_break": 0, "stat_end_datetime": "2022-02-01 03:00", "is_character_level": 0, "process_event_type": 10300, "reward_end_datetime": "2022-02-01 03:00", "stat_start_datetime": "2022-01-16 03:00", "max_entry_gain_count": 999999, "reward_start_datetime": "2022-01-16 03:00"}
4	5	{"_key": 5, "entries": [{"entry_id": 1, "condition": 440, "reward_items": [{"amount": 1, "type_id": 49810, "is_soul_bound": 0}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 2, "condition": 440, "reward_items": [{"amount": 1, "type_id": 49810, "is_soul_bound": 0}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 3, "condition": 440, "reward_items": [{"amount": 1, "type_id": 49810, "is_soul_bound": 0}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 4, "condition": 440, "reward_items": [{"amount": 1, "type_id": 49810, "is_soul_bound": 0}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 5, "condition": 440, "reward_items": [{"amount": 1, "type_id": 49810, "is_soul_bound": 0}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 6, "condition": 440, "reward_items": [{"amount": 1, "type_id": 49810, "is_soul_bound": 0}], "repeatedly_taken": 0, "reward_currencies": []}, {"entry_id": 7, "condition": 440, "reward_items": [{"amount": 4, "type_id": 49810, "is_soul_bound": 0}], "repeatedly_taken": 0, "reward_currencies": []}], "name_id": 640169, "activity_type": 4, "stat_from_npe": 0, "unlock_by_day": 1, "reset_if_break": 0, "stat_end_datetime": "2023-01-01 03:00", "is_character_level": 0, "process_event_type": 10200, "reward_end_datetime": "2023-01-01 03:00", "max_entry_gain_count": 7, "reward_start_datetime": "2022-12-01 03:00"}
5	6	{"_key": 6, "entries": [{"entry_id": 1, "condition": 1, "reward_items": [{"amount": 1, "type_id": 72545, "is_soul_bound": 0}], "repeatedly_taken": 1, "reward_currencies": []}], "name_id": 623887, "activity_type": 2, "stat_from_npe": 0, "unlock_by_day": 0, "reset_if_break": 0, "stat_end_datetime": "2023-02-01 03:00", "is_character_level": 0, "process_event_type": 10300, "reward_end_datetime": "2023-02-01 03:00", "stat_start_datetime": "2023-01-16 03:00", "max_entry_gain_count": 999999, "reward_start_datetime": "2023-01-16 03:00"}
\.


--
-- Name: monetizationactivities monetizationactivities_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.monetizationactivities
    ADD CONSTRAINT monetizationactivities_pkey PRIMARY KEY (row_no);


--
-- Name: monetizationactivities_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX monetizationactivities_key_idx ON sde_native.monetizationactivities USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict ByQTkd7E08XhS81hLNVtt9ms1SrXry8s6hkBrxeaje2CxIA8tfyRZweh9bJvxio

