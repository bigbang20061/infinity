--
-- PostgreSQL database dump
--

\restrict 2Mqu3uA3wR718yN2QjDAlyWjpTgo3xxLoBr9WNc1terELRmht77dSRqhTRLVL9R

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: monetizationevents; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.monetizationevents (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: monetizationevents; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.monetizationevents (row_no, key, data) FROM stdin;
0	10100	{"_key": 10100, "name": "RMB Purchase", "conditions": [{"name": "RMB Amount", "condition_type": 10101}]}
1	10200	{"_key": 10200, "name": "GEMs Purchase", "conditions": [{"name": "GEMs Amount", "condition_type": 10201}]}
2	10300	{"_key": 10300, "name": "PLEX Consumption", "conditions": [{"name": "PLEX Amount", "condition_type": 10301}]}
\.


--
-- Name: monetizationevents monetizationevents_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.monetizationevents
    ADD CONSTRAINT monetizationevents_pkey PRIMARY KEY (row_no);


--
-- Name: monetizationevents_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX monetizationevents_key_idx ON sde_native.monetizationevents USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 2Mqu3uA3wR718yN2QjDAlyWjpTgo3xxLoBr9WNc1terELRmht77dSRqhTRLVL9R

