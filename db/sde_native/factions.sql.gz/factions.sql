--
-- PostgreSQL database dump
--

\restrict Kfx5aB0STE48sQmxmGswSfa1O4nerlVfk4PyvayTPXMGU7GVvh3jLfI1kQ1bq7V

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: factions; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.factions (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: factions; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.factions (row_no, key, data) FROM stdin;
0	500001	{"_key": 500001, "iconID": 1439, "nameID": 61832, "flatLogo": "caldari_logo", "sizeFactor": 5.0, "uniqueName": 1, "memberRaces": [1], "corporationID": 1000035, "descriptionID": 61853, "solarSystemID": 30000145, "flatLogoWithName": "caldari_logo_w_letters", "shortDescriptionID": 572571, "militiaCorporationID": 1000180}
1	500002	{"_key": 500002, "iconID": 1440, "nameID": 61833, "flatLogo": "minmatar_logo", "sizeFactor": 5.0, "uniqueName": 1, "memberRaces": [2], "corporationID": 1000051, "descriptionID": 61854, "solarSystemID": 30002544, "flatLogoWithName": "minmatar_logo_w_letters", "shortDescriptionID": 572581, "militiaCorporationID": 1000182}
2	500003	{"_key": 500003, "iconID": 1442, "nameID": 61834, "flatLogo": "amarr_logo", "sizeFactor": 5.0, "uniqueName": 1, "memberRaces": [4], "corporationID": 1000084, "descriptionID": 61855, "solarSystemID": 30002187, "flatLogoWithName": "amarr_logo_w_letters", "shortDescriptionID": 572580, "militiaCorporationID": 1000179}
3	500004	{"_key": 500004, "iconID": 1441, "nameID": 61835, "flatLogo": "gallente_logo", "sizeFactor": 5.0, "uniqueName": 1, "memberRaces": [8], "corporationID": 1000120, "descriptionID": 61856, "solarSystemID": 30004993, "flatLogoWithName": "gallente_logo_w_letters", "shortDescriptionID": 572579, "militiaCorporationID": 1000181}
4	500005	{"_key": 500005, "iconID": 2195, "nameID": 61836, "sizeFactor": 5.0, "uniqueName": 1, "memberRaces": [16], "corporationID": 1000149, "descriptionID": 61857, "solarSystemID": 30001642}
5	500006	{"_key": 500006, "iconID": 1434, "nameID": 61837, "flatLogo": "concord_logo", "sizeFactor": 5.0, "uniqueName": 1, "memberRaces": [1, 2, 4, 8], "corporationID": 1000137, "descriptionID": 61858, "solarSystemID": 30005204}
6	500007	{"_key": 500007, "iconID": 10172, "nameID": 61838, "sizeFactor": 4.0, "uniqueName": 1, "memberRaces": [2], "corporationID": 1000123, "descriptionID": 61859, "solarSystemID": 30000001}
7	500008	{"_key": 500008, "iconID": 10173, "nameID": 61839, "sizeFactor": 4.0, "uniqueName": 1, "memberRaces": [4], "corporationID": 1000156, "descriptionID": 61860, "solarSystemID": 30003863}
8	500009	{"_key": 500009, "iconID": 1437, "nameID": 61840, "flatLogo": "the_syndicate_logo", "sizeFactor": 4.0, "uniqueName": 1, "memberRaces": [8], "corporationID": 1000146, "descriptionID": 61861, "solarSystemID": 30003271}
9	500010	{"_key": 500010, "iconID": 1630, "nameID": 61841, "flatLogo": "guristas_logo", "sizeFactor": 4.0, "uniqueName": 1, "memberRaces": [1, 8], "corporationID": 1000127, "descriptionID": 61862, "solarSystemID": 30001290, "flatLogoWithName": "guristas_logo_w_letters", "militiaCorporationID": 1000437}
10	500011	{"_key": 500011, "iconID": 10174, "nameID": 61842, "flatLogo": "angel_cartel_logo", "sizeFactor": 4.0, "uniqueName": 1, "memberRaces": [1, 2, 4, 8], "corporationID": 1000138, "descriptionID": 61863, "solarSystemID": 30001045, "flatLogoWithName": "angel_cartel_logo_w_letters", "militiaCorporationID": 1000436}
11	500012	{"_key": 500012, "iconID": 1441, "nameID": 61843, "flatLogo": "blood_raiders_logo", "sizeFactor": 3.0, "uniqueName": 1, "memberRaces": [4], "corporationID": 1000134, "descriptionID": 61864, "solarSystemID": 30003088}
12	500013	{"_key": 500013, "iconID": 25463, "nameID": 61844, "sizeFactor": 3.0, "uniqueName": 1, "memberRaces": [1, 2, 4, 8], "corporationID": 1000148, "descriptionID": 61865, "solarSystemID": 30005203}
13	500014	{"_key": 500014, "iconID": 1720, "nameID": 61845, "flatLogo": "ore_logo", "sizeFactor": 3.0, "uniqueName": 1, "memberRaces": [8], "corporationID": 1000129, "descriptionID": 61866, "solarSystemID": 30004504}
14	500015	{"_key": 500015, "iconID": 10175, "nameID": 61846, "sizeFactor": 3.0, "uniqueName": 1, "memberRaces": [2], "corporationID": 1000163, "descriptionID": 61867, "solarSystemID": 30000905}
15	500016	{"_key": 500016, "iconID": 1004, "nameID": 61847, "flatLogo": "soe_logo", "sizeFactor": 3.0, "uniqueName": 1, "memberRaces": [1, 2, 4, 8], "corporationID": 1000130, "descriptionID": 61868, "solarSystemID": 30001978}
16	500017	{"_key": 500017, "iconID": 10176, "nameID": 61848, "flatLogo": "soct_logo", "sizeFactor": 3.0, "uniqueName": 1, "memberRaces": [16], "corporationID": 1000131, "descriptionID": 61869, "solarSystemID": 30002423}
17	500018	{"_key": 500018, "iconID": 1722, "nameID": 61849, "flatLogo": "mordus_legion_logo", "sizeFactor": 3.0, "uniqueName": 1, "memberRaces": [1, 8], "corporationID": 1000128, "descriptionID": 61870, "solarSystemID": 30002005}
18	500019	{"_key": 500019, "iconID": 10177, "nameID": 61850, "flatLogo": "sansha_logo", "sizeFactor": 4.0, "uniqueName": 1, "memberRaces": [1, 2, 4, 8], "corporationID": 1000162, "descriptionID": 61871, "solarSystemID": 30001868}
19	500020	{"_key": 500020, "iconID": 10178, "nameID": 61851, "flatLogo": "serpentis_logo", "sizeFactor": 4.0, "uniqueName": 1, "memberRaces": [1], "corporationID": 1000135, "descriptionID": 61872, "solarSystemID": 30004623}
20	500021	{"_key": 500021, "iconID": 0, "nameID": 61852, "sizeFactor": 0.0, "uniqueName": 0, "memberRaces": [1, 2, 4, 8, 16], "descriptionID": 305257, "solarSystemID": 30005286}
21	500024	{"_key": 500024, "iconID": 21404, "nameID": 305272, "sizeFactor": 0.0, "uniqueName": 0, "memberRaces": [16], "corporationID": 1000274, "descriptionID": 305273, "solarSystemID": 30005286}
22	500025	{"_key": 500025, "iconID": 20996, "nameID": 317735, "sizeFactor": 0.0, "uniqueName": 0, "memberRaces": [134], "corporationID": 1000287, "descriptionID": 317736, "solarSystemID": 30005286}
23	500026	{"_key": 500026, "iconID": 20996, "nameID": 317737, "flatLogo": "triglavian_logo", "sizeFactor": 5.0, "uniqueName": 1, "memberRaces": [135], "corporationID": 1000298, "descriptionID": 317738, "solarSystemID": 30005286}
24	500027	{"_key": 500027, "iconID": 24419, "nameID": 318203, "flatLogo": "edencom_logo", "sizeFactor": 5.0, "uniqueName": 0, "memberRaces": [1, 2, 4, 8], "corporationID": 1000297, "descriptionID": 318204, "solarSystemID": 30005204}
25	500028	{"_key": 500028, "iconID": 21, "nameID": 586300, "sizeFactor": 5.0, "uniqueName": 1, "memberRaces": [4, 1, 8, 2], "corporationID": 1000413, "descriptionID": 586305, "solarSystemID": 30005305}
26	500029	{"_key": 500029, "iconID": 25666, "nameID": 666800, "flatLogo": "deathless_logo", "sizeFactor": 4.0, "uniqueName": 1, "memberRaces": [1, 4, 8, 2], "corporationID": 1000441, "descriptionID": 666799, "solarSystemID": 30100000}
27	500034	{"_key": 500034, "iconID": 1442, "nameID": 596483, "sizeFactor": 5.0, "uniqueName": 1, "memberRaces": [4], "corporationID": 1000084, "descriptionID": 596482, "solarSystemID": 30002187}
28	500056	{"_key": 500056, "iconID": 26261, "nameID": 725160, "sizeFactor": 5.0, "uniqueName": 1, "memberRaces": [169], "corporationID": 1000465, "descriptionID": 725159, "solarSystemID": 30003482}
\.


--
-- Name: factions factions_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.factions
    ADD CONSTRAINT factions_pkey PRIMARY KEY (row_no);


--
-- Name: factions_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX factions_key_idx ON sde_native.factions USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict Kfx5aB0STE48sQmxmGswSfa1O4nerlVfk4PyvayTPXMGU7GVvh3jLfI1kQ1bq7V

