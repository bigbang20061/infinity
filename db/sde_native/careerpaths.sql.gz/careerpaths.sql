--
-- PostgreSQL database dump
--

\restrict 26DRdaptggRhJOT4Owbb3gQbEMsWiEyHzVTMd3bv83bQSDnZd0pK3qpRKPauUfd

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: careerpaths; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.careerpaths (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: careerpaths; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.careerpaths (row_no, key, data) FROM stdin;
0	4	{"_key": 4, "nameID": 582516, "internalName": "Explorer", "descriptionID": 582517}
1	5	{"_key": 5, "nameID": 582518, "internalName": "Industrialist", "descriptionID": 582519}
2	6	{"_key": 6, "nameID": 582520, "internalName": "Enforcer", "descriptionID": 582521}
3	7	{"_key": 7, "nameID": 582522, "internalName": "Soldier of Fortune", "descriptionID": 582523}
\.


--
-- Name: careerpaths careerpaths_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.careerpaths
    ADD CONSTRAINT careerpaths_pkey PRIMARY KEY (row_no);


--
-- Name: careerpaths_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX careerpaths_key_idx ON sde_native.careerpaths USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 26DRdaptggRhJOT4Owbb3gQbEMsWiEyHzVTMd3bv83bQSDnZd0pK3qpRKPauUfd

