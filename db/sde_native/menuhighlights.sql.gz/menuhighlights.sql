--
-- PostgreSQL database dump
--

\restrict kICpGmV58H22I1768IS6PBtUoyaEYhqNEkhkp6VeLIFd5DMy5fZ5NHB5p4GEkki

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: menuhighlights; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.menuhighlights (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: menuhighlights; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.menuhighlights (row_no, key, data) FROM stdin;
0	2	{"_key": 2, "name": "Approach Bunker", "typeID": [47401], "menuName": "Approach"}
1	3	{"_key": 3, "name": "Lock Bunker", "typeID": [47401], "menuName": "LockTarget"}
2	4	{"_key": 4, "name": "Dock in Station", "typeID": [], "menuName": "DockInStation"}
3	5	{"_key": 5, "name": "Orbit Bunker", "typeID": [47401], "menuName": "Orbit"}
4	6	{"_key": 6, "name": "Orbit Bunker 500m", "typeID": [47401], "menuName": "Orbit500m"}
5	7	{"_key": 7, "name": "Approach Seeker", "typeID": [42692, 47489, 47492], "menuName": "Approach"}
6	8	{"_key": 8, "name": "Lock Seeker", "typeID": [42692], "menuName": "LockTarget"}
7	9	{"_key": 9, "name": "Orbit Seeker", "typeID": [42692], "menuName": "Orbit"}
8	10	{"_key": 10, "name": "Orbit Seeker 500m", "typeID": [42692], "menuName": "Orbit500m"}
9	14	{"_key": 14, "name": "AS01B03: Locate Wreck (Approach wreck hint)", "typeID": [34190], "menuName": "Approach"}
10	15	{"_key": 15, "name": "AS01B04: Approach Enemy (Approach seeker hint)", "typeID": [42692], "menuName": "Approach"}
11	16	{"_key": 16, "name": "AS01B05: Orbit Enemy (Orbit seeker hint)", "typeID": [42692], "menuName": "Orbit"}
12	17	{"_key": 17, "name": "AS01B05: Orbit Enemy (Orbit 500m seeker hint)", "typeID": [42692], "menuName": "Orbit500m"}
13	18	{"_key": 18, "name": "AS01B06: Lock Enemy (Lock seeker hint)", "typeID": [42692], "menuName": "LockTarget"}
14	2021	{"_key": 2021, "name": "Open Cargo", "typeID": [], "menuName": "OpenCargo"}
15	2022	{"_key": 2022, "name": "Jump", "typeID": [], "menuName": "Jump"}
16	2024	{"_key": 2024, "name": "FittingWndUnfitModule", "typeID": [], "menuName": "Unfit"}
17	2026	{"_key": 2026, "name": "Orbit Seeker 1,000m", "typeID": [42692], "menuName": "Orbit1,000m"}
18	2030	{"_key": 2030, "name": "Look at [AIR]Impalier", "typeID": [58745], "menuName": "LookAt"}
19	2033	{"_key": 2033, "name": "Approach Balin (Approach Balin hint)", "typeID": [57788], "menuName": "Approach"}
20	2036	{"_key": 2036, "name": "[AIR NPE] 5.2 - Sell Items Context Menu", "typeID": [60771], "menuName": "Sell"}
21	2042	{"_key": 2042, "name": "[CA] BtB 06 - View Market Details", "typeID": [21853], "menuName": "ViewMarketDetails"}
22	2044	{"_key": 2044, "name": "[CA] BtB 09 - View Market Details", "typeID": [439], "menuName": "ViewMarketDetails"}
23	2045	{"_key": 2045, "name": "[CA] Buy Missing Materials", "typeID": [], "menuName": "BuyMultipleTypesMissing"}
24	2048	{"_key": 2048, "name": "Look at container", "typeID": [74846], "menuName": "LookAt"}
25	2049	{"_key": 2049, "name": "Look at cloud", "typeID": [74294], "menuName": "LookAt"}
\.


--
-- Name: menuhighlights menuhighlights_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.menuhighlights
    ADD CONSTRAINT menuhighlights_pkey PRIMARY KEY (row_no);


--
-- Name: menuhighlights_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX menuhighlights_key_idx ON sde_native.menuhighlights USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict kICpGmV58H22I1768IS6PBtUoyaEYhqNEkhkp6VeLIFd5DMy5fZ5NHB5p4GEkki

