--
-- PostgreSQL database dump
--

\restrict Mjdd98fe6gCCPnySGHP6rbiL6YQNDoEyTFDZnYtTpJtJk073s3AdiaICeHqvnA3

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: fuzzysearch; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.fuzzysearch (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: fuzzysearch; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.fuzzysearch (row_no, key, data) FROM stdin;
0	\N	{"listOfMatching": [{"replacing": ["﻿跃迁扰断"], "matchingList": ["﻿1点", "﻿一点", "﻿1点", "﻿长反"]}, {"replacing": ["﻿跃迁扰频"], "matchingList": ["﻿2点", "﻿二点", "﻿2点", "﻿短反"]}, {"replacing": ["﻿重型跃迁扰频"], "matchingList": ["﻿重反"]}, {"replacing": ["﻿停滞缠绕光束"], "matchingList": ["﻿网子"]}, {"replacing": ["﻿重型停滞捕捉光束"], "matchingList": ["﻿重网"]}, {"replacing": ["﻿远程感应抑阻器"], "matchingList": ["﻿帽子"]}, {"replacing": ["﻿索敌扰断器"], "matchingList": ["﻿炮扰"]}, {"replacing": ["﻿制导干扰器"], "matchingList": ["﻿弹扰", "﻿蛋扰"]}, {"replacing": ["﻿能量中和器"], "matchingList": ["﻿毁电"]}, {"replacing": ["﻿掠能器"], "matchingList": ["﻿吸电"]}, {"replacing": ["﻿突击型损伤控制"], "matchingList": ["﻿BKB", "﻿adc", "﻿突击损控"]}, {"replacing": ["﻿无人机伤害增效装置"], "matchingList": ["﻿dda"]}, {"replacing": ["﻿远程电容传输装置"], "matchingList": ["﻿传电"]}, {"replacing": ["﻿指挥脉冲波"], "matchingList": ["﻿加成", "﻿Buff"]}, {"replacing": ["﻿跃迁扰"], "matchingList": ["﻿反跳"]}, {"replacing": ["﻿微型跃迁推进器"], "matchingList": ["﻿微曲", "﻿mwd"]}, {"replacing": ["﻿加力燃烧器"], "matchingList": ["﻿加力", "﻿ab"]}, {"replacing": ["﻿微型跃迁推进器", "﻿加力燃烧器"], "matchingList": ["﻿推子"]}, {"replacing": ["﻿盾扩"], "matchingList": ["﻿盾扩"]}, {"replacing": ["﻿电容回充器", "﻿电容能源继电器", "﻿电容通量线圈"], "matchingList": ["﻿回电"]}, {"replacing": ["﻿微型跳跃"], "matchingList": ["﻿跳刀"]}, {"replacing": ["﻿(?<!突击型)损伤控制"], "matchingList": ["﻿(?<!突击)损控", "﻿(?<!a)dc"]}, {"replacing": ["﻿反应式装甲增强器"], "matchingList": ["﻿反应甲"]}, {"replacing": ["﻿(?<!远程)装甲维修器"], "matchingList": ["﻿甲修", "﻿(?<![摇遥])修甲"]}, {"replacing": ["﻿辅助装甲维修器"], "matchingList": ["﻿注甲"]}, {"replacing": ["﻿远程装甲维修器"], "matchingList": ["﻿甲摇修", "﻿甲遥修", "﻿摇修甲", "﻿遥修甲", "﻿摇甲", "﻿遥甲"]}, {"replacing": ["﻿多谱式电压薄膜", "﻿多谱式涂层"], "matchingList": ["﻿甲全抗"]}, {"replacing": ["﻿动能装甲增强器", "﻿动能电压薄膜", "﻿动能涂层"], "matchingList": ["﻿甲动抗"]}, {"replacing": ["﻿热能装甲增强器", "﻿热能电压薄膜", "﻿爆炸涂层"], "matchingList": ["﻿甲热抗"]}, {"replacing": ["﻿爆炸装甲增强器", "﻿爆炸电压薄膜", "﻿热能涂层"], "matchingList": ["﻿甲爆抗"]}, {"replacing": ["﻿电磁装甲增强器", "﻿电磁电压薄膜", "﻿电磁涂层"], "matchingList": ["﻿甲电抗"]}, {"replacing": ["﻿附甲板"], "matchingList": ["﻿板子", "﻿钢板", "﻿甲板"]}, {"replacing": ["﻿(?<!远程)护盾回充增量器"], "matchingList": ["﻿盾修", "﻿(?<![摇遥])修盾"]}, {"replacing": ["﻿辅助护盾回充增量器"], "matchingList": ["﻿注盾"]}, {"replacing": ["﻿回充增量增效器"], "matchingList": ["﻿盾提"]}, {"replacing": ["﻿护盾远程回充增量器", "﻿远程护盾回充增量器"], "matchingList": ["﻿盾遥修", "﻿遥修盾", "﻿遥盾", "﻿盾摇修", "﻿摇修盾", "﻿摇盾"]}, {"replacing": ["﻿多谱式护盾增强器"], "matchingList": ["﻿盾全抗"]}, {"replacing": ["﻿动能护盾增强器", "﻿动能护盾增效器"], "matchingList": ["﻿盾动抗"]}, {"replacing": ["﻿热能护盾增强器", "﻿热能护盾增效器"], "matchingList": ["﻿盾热抗"]}, {"replacing": ["﻿爆炸护盾增强器", "﻿爆炸护盾增效器"], "matchingList": ["﻿盾爆抗"]}, {"replacing": ["﻿电磁护盾增强器", "﻿电磁护盾增效器"], "matchingList": ["﻿盾电抗"]}, {"replacing": ["﻿能源诊断系统"], "matchingList": ["﻿能诊"]}, {"replacing": ["﻿轻型快速导弹发射器"], "matchingList": ["﻿轻快", "﻿RLML", "﻿轻快导"]}, {"replacing": ["﻿重型快速导弹发射器"], "matchingList": ["﻿重快", "﻿RHML", "﻿重快导"]}, {"replacing": ["﻿快速鱼雷发射器"], "matchingList": ["﻿快雷", "﻿RTL"]}, {"replacing": ["﻿惯性稳定器"], "matchingList": ["﻿皮球"]}, {"replacing": ["﻿侵噬"], "matchingList": ["﻿手电", "﻿侵蚀"]}, {"specialCase": ["﻿Tech1"], "matchingList": ["﻿T1"]}, {"specialCase": ["﻿Tech2"], "matchingList": ["﻿T2"]}, {"specialCase": ["﻿Storyline"], "matchingList": ["﻿故事线"]}, {"specialCase": ["﻿Faction"], "matchingList": ["﻿势力"]}, {"specialCase": ["﻿Deadspace"], "matchingList": ["﻿死亡"]}, {"specialCase": ["﻿Officer"], "matchingList": ["﻿官员"]}]}
\.


--
-- Name: fuzzysearch fuzzysearch_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.fuzzysearch
    ADD CONSTRAINT fuzzysearch_pkey PRIMARY KEY (row_no);


--
-- Name: fuzzysearch_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX fuzzysearch_key_idx ON sde_native.fuzzysearch USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict Mjdd98fe6gCCPnySGHP6rbiL6YQNDoEyTFDZnYtTpJtJk073s3AdiaICeHqvnA3

