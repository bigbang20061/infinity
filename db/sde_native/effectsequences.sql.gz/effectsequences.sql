--
-- PostgreSQL database dump
--

\restrict kQgukQqLFYOxbvwTJ1kY4X2omSIudMDeT7WDy48W4Vrxef4KsoDjMC8ymizZXLr

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: effectsequences; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.effectsequences (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: effectsequences; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.effectsequences (row_no, key, data) FROM stdin;
0	moon_mining	{"_key": "moon_mining", "value": [{"name": "tractor_phase", "steps": [{"name": "turret_extraction_firing", "looped": 0, "source": "moduleID", "target": "targetID", "startTime": 0, "graphicFile": "res:/dx9/model/turret/structure/moonminer/moonminer_fireatmoon_fx.red"}, {"name": "invisiblize", "looped": 0, "startTime": 0, "callFunctions": [{"name": "MakeInvisible", "target": "targetID"}]}, {"name": "impact_on_moon", "looped": 0, "source": "targetID", "scaling": {"amount": 1.5, "parent": "targetID", "sourceValue": "boundingSphereRadius"}, "startTime": 0, "graphicFile": "res:/fisfx/structure/moonmining/moonmining_surfaceeffect_01a.red"}, {"name": "visibilize", "looped": 0, "startTime": 50500, "stepsToStop": ["invisibilize"], "callFunctions": [{"name": "MakeVisible", "target": "targetID"}]}, {"name": "decal_on_moon", "looped": 0, "source": "shipID", "target": "moonID", "scaling": {"amount": 2.0, "parent": "targetID", "sourceValue": "boundingSphereRadius"}, "startTime": 50100, "callFunctions": [{"name": "MoonMiningCreateCrater"}]}, {"name": "tractor_on_chunk", "looped": 1, "source": "moduleID", "target": "targetID", "startTime": 70000, "graphicFile": "res:/dx9/model/turret/structure/moonminer/moonminer_tractor_fx.red", "stepsToStop": ["turret_extraction_firing"]}, {"name": "stop_impact_on_moon", "looped": 0, "startTime": 140000, "stepsToStop": ["impact_on_moon"]}]}, {"name": "stasis_phase", "steps": [{"name": "stasis_on_chunk", "looped": 1, "source": "moduleID", "target": "targetID", "startTime": 0, "graphicFile": "res:/dx9/model/turret/structure/moonminer/moonminer_tractorstasis_fx.red"}], "stops": ["tractor_on_chunk"]}, {"name": "fracture_phase", "steps": [{"name": "turret_destruction_firing", "looped": 0, "source": "moduleID", "target": "targetID", "startTime": 0, "graphicFile": "res:/dx9/model/turret/structure/moonminer/moonminer_fireatchunk_fx.red"}], "stops": ["stasis_on_chunk"]}]}
\.


--
-- Name: effectsequences effectsequences_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.effectsequences
    ADD CONSTRAINT effectsequences_pkey PRIMARY KEY (row_no);


--
-- Name: effectsequences_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX effectsequences_key_idx ON sde_native.effectsequences USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict kQgukQqLFYOxbvwTJ1kY4X2omSIudMDeT7WDy48W4Vrxef4KsoDjMC8ymizZXLr

