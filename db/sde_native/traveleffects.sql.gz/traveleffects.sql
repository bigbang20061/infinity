--
-- PostgreSQL database dump
--

\restrict 2Vgaj7JUz1tQfSlaa4jjJnwhbNERSoGocNpEjesfILAgurAp5lFqmpUgVbMroH4

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: traveleffects; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.traveleffects (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: traveleffects; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.traveleffects (row_no, key, data) FROM stdin;
0	effects.JumpBridgeOut	{"_key": "effects.JumpBridgeOut", "type": "BetweenSystems", "effect": "res:/FisFX/Travel/KSpace/kspace_jumptunnel_effect_01a.red", "multiEffect": "res:/FisFX/Travel/KSpace/KSpace_JumpTunnel_MultiEffect_01a.red", "hidingEffect": {"path": "res:/Fisfx/Module/JumpOut_Tr_T1a.red", "shipHideDelay": 0.8, "effectDuration": 5.0}, "transitionScene": "res:/FisFX/Travel/KSpace/Kspace_Jumptunnel_Transitionscene_01a.red"}
1	effects.JumpDriveOut	{"_key": "effects.JumpDriveOut", "type": "BetweenSystems", "effect": "res:/FisFX/Travel/KSpace/KSpace_Cyno_JumpTunnel_Effect_01a.red", "multiEffect": "res:/FisFX/Travel/KSpace/KSpace_JumpTunnel_MultiEffect_01a.red", "hidingEffect": {"path": "res:/fisfx/jump/cyno_jump/cyno_jump_out.red", "shipHideDelay": 0.8, "effectDuration": 5.0}, "transitionScene": "res:/FisFX/Travel/KSpace/KSpace_Cyno_JumpTunnel_TransitionScene_01a.red"}
2	effects.JumpDriveOutBO	{"_key": "effects.JumpDriveOutBO", "type": "BetweenSystems", "effect": "res:/FisFX/Travel/KSpace/KSpace_CynoBlackOps_JumpTunnel_Effect_01a.red", "multiEffect": "res:/FisFX/Travel/KSpace/KSpace_JumpTunnel_MultiEffect_01a.red", "hidingEffect": {"path": "res:/fisfx/jump/cyno_jump/cyno_jump_out_bo.red", "shipHideDelay": 0.8, "effectDuration": 5.0}, "transitionScene": "res:/FisFX/Travel/KSpace/KSpace_CynoBlackOps_JumpTunnel_TransitionScene_01a.red"}
3	effects.JumpOut	{"_key": "effects.JumpOut", "type": "BetweenSystems", "effect": "res:/FisFX/Travel/KSpace/kspace_jumptunnel_effect_01a.red", "multiEffect": "res:/FisFX/Travel/KSpace/KSpace_JumpTunnel_MultiEffect_01a.red", "hidingEffect": {"path": "res:/Fisfx/Module/JumpOut_Tr_T1a.red", "shipHideDelay": 0.8, "effectDuration": 5.0}, "transitionScene": "res:/FisFX/Travel/KSpace/Kspace_Jumptunnel_Transitionscene_01a.red"}
4	effects.JumpOutAbyssal	{"_key": "effects.JumpOutAbyssal", "type": "BetweenSystems", "effect": "res:/FisFX/Travel/abyssal/abyssal_jumptunnel_effect_01a.red", "multiEffect": "res:/FisFX/Travel/abyssal/abyssal_JumpTunnel_MultiEffect_01a.red", "hidingEffect": {"path": "res:/fisfx/module/jumpout_abyssal_tr_t1a.red", "shipHideDelay": 0.8, "effectDuration": 5.0}, "transitionScene": "res:/FisFX/Travel/abyssal/abyssal_Jumptunnel_Transitionscene_01a.red"}
5	effects.JumpOutAbyssalBetween	{"_key": "effects.JumpOutAbyssalBetween", "type": "WithinSystem", "effect": "res:/FisFX/Travel/abyssal/abyssal_jumptunnel_effect_01a.red", "multiEffect": "res:/FisFX/Travel/abyssal/abyssal_JumpTunnel_MultiEffect_01a.red", "hidingEffect": {"path": "res:/fisfx/module/jumpout_abyssal_tr_t1a.red", "shipHideDelay": 0.8, "effectDuration": 5.0}, "transitionScene": "res:/FisFX/Travel/abyssal/abyssal_Jumptunnel_Transitionscene_01a.red"}
6	effects.JumpOutEventB	{"_key": "effects.JumpOutEventB", "type": "BetweenSystems", "effect": "res:/FisFX/Travel/KSpace/kspace_jumptunnel_effect_01b.red", "multiEffect": "res:/FisFX/Travel/KSpace/KSpace_JumpTunnel_MultiEffect_01b.red", "hidingEffect": {"path": "res:/Fisfx/Module/JumpOut_Tr_T1a.red", "shipHideDelay": 0.8, "effectDuration": 5.5}, "transitionScene": "res:/FisFX/Travel/KSpace/Kspace_Jumptunnel_Transitionscene_01a.red"}
7	effects.JumpShipCaster	{"_key": "effects.JumpShipCaster", "type": "BetweenSystems", "effect": "res:/FisFX/Travel/KSpace/KSpace_OmniTrig_JumpTunnel_Effect_01a.red", "multiEffect": "res:/FisFX/Travel/KSpace/KSpace_JumpTunnel_MultiEffect_01a.red", "hidingEffect": {"path": "res:/Fisfx/Module/JumpOut_Tr_T1a.red", "shipHideDelay": 0.8, "effectDuration": 5.0}, "transitionScene": "res:/FisFX/Travel/KSpace/KSpace_OmniTrig_JumpTunnel_TransitionScene_01a.red"}
\.


--
-- Name: traveleffects traveleffects_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.traveleffects
    ADD CONSTRAINT traveleffects_pkey PRIMARY KEY (row_no);


--
-- Name: traveleffects_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX traveleffects_key_idx ON sde_native.traveleffects USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 2Vgaj7JUz1tQfSlaa4jjJnwhbNERSoGocNpEjesfILAgurAp5lFqmpUgVbMroH4

