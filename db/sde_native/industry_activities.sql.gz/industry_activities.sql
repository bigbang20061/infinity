--
-- PostgreSQL database dump
--

\restrict KTrpyDM93awfuj0CgWaojnbUkpDzm1Z49hVulElsh7jopNmO1o5bYZ8gEdwhAO4

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: industry_activities; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.industry_activities (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: industry_activities; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.industry_activities (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "activityID": 1, "description": "Manufacturing of things", "activityName": "Manufacturing"}
1	3	{"_key": 3, "activityID": 3, "description": "Researching time efficiency", "activityName": "Time Efficiency Research"}
2	4	{"_key": 4, "activityID": 4, "description": "Researching material efficiency", "activityName": "Material Efficiency Research"}
3	5	{"_key": 5, "activityID": 5, "description": "Making blueprint copies", "activityName": "Copying"}
4	8	{"_key": 8, "activityID": 8, "description": "The process of creating a more advanced item based on an existing item", "activityName": "Invention"}
5	9	{"_key": 9, "activityID": 9, "description": "The process of combining raw and intermediate materials to create advanced components", "activityName": "Reactions"}
\.


--
-- Name: industry_activities industry_activities_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.industry_activities
    ADD CONSTRAINT industry_activities_pkey PRIMARY KEY (row_no);


--
-- Name: industry_activities_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX industry_activities_key_idx ON sde_native.industry_activities USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict KTrpyDM93awfuj0CgWaojnbUkpDzm1Z49hVulElsh7jopNmO1o5bYZ8gEdwhAO4

