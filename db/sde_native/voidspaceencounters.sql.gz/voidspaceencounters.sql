--
-- PostgreSQL database dump
--

\restrict qHsGvgSZWnbmHNvKODiMkG2S3CkYEKFhAJYRGzWLTTVWomYVUM1BKBWYOgHvw9N

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: voidspaceencounters; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.voidspaceencounters (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: voidspaceencounters; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.voidspaceencounters (row_no, key, data) FROM stdin;
0	62448	{"_key": 62448, "dungeonIDs": [9264], "numberOfPlayers": 1, "nebulaGraphicIDs": [25126], "traceDescriptionID": 594766, "validShipTypeListID": 27, "encounterDescriptionID": 594763, "traceDescriptionTitleID": 594765, "shipRestrictionsDescriptionID": 594764}
1	79996	{"_key": 79996, "dungeonIDs": [10589], "numberOfPlayers": 2, "nebulaGraphicIDs": [22041], "traceDescriptionID": 706302, "validShipTypeListID": 323, "encounterDescriptionID": 706300, "traceDescriptionTitleID": 706303, "shipRestrictionsDescriptionID": 706301}
2	79997	{"_key": 79997, "dungeonIDs": [10594], "numberOfPlayers": 1, "nebulaGraphicIDs": [22041], "traceDescriptionID": 706287, "validShipTypeListID": 325, "encounterDescriptionID": 706285, "traceDescriptionTitleID": 706288, "shipRestrictionsDescriptionID": 706286}
3	79998	{"_key": 79998, "dungeonIDs": [10590], "numberOfPlayers": 2, "nebulaGraphicIDs": [22042], "traceDescriptionID": 706307, "validShipTypeListID": 323, "encounterDescriptionID": 706305, "traceDescriptionTitleID": 706308, "shipRestrictionsDescriptionID": 706306}
4	79999	{"_key": 79999, "dungeonIDs": [10595], "numberOfPlayers": 1, "nebulaGraphicIDs": [22041], "traceDescriptionID": 706294, "validShipTypeListID": 325, "encounterDescriptionID": 706291, "traceDescriptionTitleID": 706295, "shipRestrictionsDescriptionID": 706292}
5	80000	{"_key": 80000, "dungeonIDs": [10591], "numberOfPlayers": 2, "nebulaGraphicIDs": [22041], "traceDescriptionID": 706311, "validShipTypeListID": 323, "encounterDescriptionID": 706309, "traceDescriptionTitleID": 706312, "shipRestrictionsDescriptionID": 706310}
6	80001	{"_key": 80001, "dungeonIDs": [10596], "numberOfPlayers": 1, "nebulaGraphicIDs": [22041], "traceDescriptionID": 706298, "validShipTypeListID": 325, "encounterDescriptionID": 706296, "traceDescriptionTitleID": 706299, "shipRestrictionsDescriptionID": 706297}
7	80002	{"_key": 80002, "dungeonIDs": [10592], "numberOfPlayers": 2, "nebulaGraphicIDs": [22041], "traceDescriptionID": 706315, "validShipTypeListID": 323, "encounterDescriptionID": 706313, "traceDescriptionTitleID": 706316, "shipRestrictionsDescriptionID": 706314}
\.


--
-- Name: voidspaceencounters voidspaceencounters_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.voidspaceencounters
    ADD CONSTRAINT voidspaceencounters_pkey PRIMARY KEY (row_no);


--
-- Name: voidspaceencounters_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX voidspaceencounters_key_idx ON sde_native.voidspaceencounters USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict qHsGvgSZWnbmHNvKODiMkG2S3CkYEKFhAJYRGzWLTTVWomYVUM1BKBWYOgHvw9N

