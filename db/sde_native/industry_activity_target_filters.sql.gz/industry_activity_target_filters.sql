--
-- PostgreSQL database dump
--

\restrict tU4BrP9sx204CVbtBn86HMoyAnrY7gj9CNiS6PL9f2yAs8FqaEe1cDeFXqT8Aup

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: industry_activity_target_filters; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.industry_activity_target_filters (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: industry_activity_target_filters; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.industry_activity_target_filters (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "name": "Drones/Fighters", "groupIDs": [], "categoryIDs": [18, 87]}
1	2	{"_key": 2, "name": "Equipment", "groupIDs": [12, 340, 448, 649], "categoryIDs": [7, 20, 22]}
2	3	{"_key": 3, "name": "Ships", "groupIDs": [], "categoryIDs": [6, 32]}
3	4	{"_key": 4, "name": "Charges", "groupIDs": [], "categoryIDs": [8]}
4	5	{"_key": 5, "name": "Small T1 Ships", "groupIDs": [25, 31, 420], "categoryIDs": []}
5	6	{"_key": 6, "name": "Small T2 Ships", "groupIDs": [324, 541, 830, 831, 834, 893, 1283, 1305, 1527, 1534], "categoryIDs": []}
6	7	{"_key": 7, "name": "Medium T1 Ships", "groupIDs": [26, 28, 419, 463, 1201, 4902, 5087], "categoryIDs": []}
7	8	{"_key": 8, "name": "Medium T2 Ships", "groupIDs": [358, 380, 540, 543, 832, 833, 894, 906, 963, 1202, 1972, 4902], "categoryIDs": [32]}
8	9	{"_key": 9, "name": "Large T1 Ships", "groupIDs": [27, 513, 941], "categoryIDs": []}
9	10	{"_key": 10, "name": "Large T2 Ships", "groupIDs": [898, 900, 902], "categoryIDs": []}
10	11	{"_key": 11, "name": "Capital Ships", "groupIDs": [485, 547, 883, 1538, 4594, 5120], "categoryIDs": []}
11	12	{"_key": 12, "name": "Structures", "groupIDs": [536, 1136, 4736], "categoryIDs": [23, 39, 40, 65, 66]}
12	13	{"_key": 13, "name": "Capital Components", "groupIDs": [873], "categoryIDs": []}
13	14	{"_key": 14, "name": "Components", "groupIDs": [332, 334, 716, 964], "categoryIDs": []}
14	15	{"_key": 15, "name": "Advanced Capital Components", "groupIDs": [913], "categoryIDs": []}
15	16	{"_key": 16, "name": "Hybrid Reactions", "groupIDs": [974], "categoryIDs": []}
16	17	{"_key": 17, "name": "Biochemical Reactions", "groupIDs": [712, 4096], "categoryIDs": []}
17	18	{"_key": 18, "name": "Composite Reactions", "groupIDs": [428, 429, 4932], "categoryIDs": []}
\.


--
-- Name: industry_activity_target_filters industry_activity_target_filters_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.industry_activity_target_filters
    ADD CONSTRAINT industry_activity_target_filters_pkey PRIMARY KEY (row_no);


--
-- Name: industry_activity_target_filters_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX industry_activity_target_filters_key_idx ON sde_native.industry_activity_target_filters USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict tU4BrP9sx204CVbtBn86HMoyAnrY7gj9CNiS6PL9f2yAs8FqaEe1cDeFXqT8Aup

