--
-- PostgreSQL database dump
--

\restrict NcbEfjK3IWhnT6iHp5BzGyPQkIV1kRwwEzUqdipGMEZgnhiGon3ANiCzwr1Y7e9

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: environmenttemplateanchorgroupids; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.environmenttemplateanchorgroupids (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: environmenttemplateanchorgroupids; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.environmenttemplateanchorgroupids (row_no, key, data) FROM stdin;
0	465	{"_key": 465, "baseEnvironment": 4}
1	1911	{"_key": 1911, "baseEnvironment": 36}
\.


--
-- Name: environmenttemplateanchorgroupids environmenttemplateanchorgroupids_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.environmenttemplateanchorgroupids
    ADD CONSTRAINT environmenttemplateanchorgroupids_pkey PRIMARY KEY (row_no);


--
-- Name: environmenttemplateanchorgroupids_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX environmenttemplateanchorgroupids_key_idx ON sde_native.environmenttemplateanchorgroupids USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict NcbEfjK3IWhnT6iHp5BzGyPQkIV1kRwwEzUqdipGMEZgnhiGon3ANiCzwr1Y7e9

