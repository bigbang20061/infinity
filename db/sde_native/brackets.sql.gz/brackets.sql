--
-- PostgreSQL database dump
--

\restrict lmr4kWXvuMAFt2SHVRrN2rg3KssBJasanxKKr2tzY8ucTwccakZrBj9umoCS7Bk

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: brackets; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.brackets (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: brackets; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.brackets (row_no, key, data) FROM stdin;
0	2313	{"_key": 2313, "name": "Planet", "texturePath": "res:/UI/Texture/Shared/Brackets/planet.png"}
1	2314	{"_key": 2314, "name": "Battlecruiser", "texturePath": "res:/UI/Texture/Shared/Brackets/battleCruiser_16.png"}
2	2315	{"_key": 2315, "name": "Bomb", "texturePath": "res:/UI/Texture/Shared/Brackets/bomb.png"}
3	2316	{"_key": 2316, "name": "NPC Carrier", "texturePath": "res:/UI/Texture/Shared/Brackets/npccarrier_16.png"}
4	2317	{"_key": 2317, "name": "Mobile Phase Stabilizer", "texturePath": "res:/UI/Texture/Shared/Brackets/PhasedStabilizer.png"}
5	2318	{"_key": 2318, "name": "Warp Gate", "texturePath": "res:/UI/Texture/Shared/Brackets/warpGate.png"}
6	2319	{"_key": 2319, "name": "Drone Salvaging", "texturePath": "res:/UI/Texture/Shared/Brackets/droneSalvaging_16.png"}
7	2320	{"_key": 2320, "name": "Asteroid Belt", "iconOffset": -20, "texturePath": "res:/UI/Texture/Shared/Brackets/asteroidBelt.png", "minVisibleDistance": 50000.0}
8	2321	{"_key": 2321, "name": "Mining Frigate", "texturePath": "res:/UI/Texture/Shared/Brackets/miningFrigate_16.png"}
9	2322	{"_key": 2322, "name": "Stargate", "texturePath": "res:/UI/Texture/Shared/Brackets/stargate.png"}
10	2324	{"_key": 2324, "name": "Starbase Hybrid Battery", "texturePath": "res:/UI/Texture/Shared/Brackets/mobileSentryHybrid.png"}
11	2325	{"_key": 2325, "name": "NPC Destroyer", "texturePath": "res:/UI/Texture/Shared/Brackets/npcdestroyer_16.png"}
12	2326	{"_key": 2326, "name": "Cynosural System Jammer", "texturePath": "res:/UI/Texture/Shared/Brackets/CynosuralSystemJammer.png"}
13	2327	{"_key": 2327, "name": "Rookie ship", "texturePath": "res:/UI/Texture/Shared/Brackets/rookie_16.png"}
14	2328	{"_key": 2328, "name": "Titan", "texturePath": "res:/UI/Texture/Shared/Brackets/titan_16.png"}
15	2329	{"_key": 2329, "name": "Large Collidable Structure", "texturePath": "res:/UI/Texture/Shared/Brackets/largeCollidableStructure.png", "maxVisibleDistance": 250000.0}
16	2330	{"_key": 2330, "name": "Reactor", "texturePath": "res:/UI/Texture/Shared/Brackets/mobileReactor.png"}
17	2331	{"_key": 2331, "name": "FW Infrastructure Hub", "texturePath": "res:/UI/Texture/Shared/Brackets/controlBunker.png"}
18	2332	{"_key": 2332, "name": "Jump Portal Array", "texturePath": "res:/UI/Texture/Shared/Brackets/jumpPortalArray.png"}
19	2333	{"_key": 2333, "name": "NPC Frigate", "texturePath": "res:/UI/Texture/Shared/Brackets/npcfrigate_16.png"}
20	2334	{"_key": 2334, "name": "Mining Barge", "texturePath": "res:/UI/Texture/Shared/Brackets/miningBarge_16.png"}
21	2335	{"_key": 2335, "name": "Sun", "texturePath": "res:/UI/Texture/Shared/Brackets/sun.png"}
22	2336	{"_key": 2336, "name": "Wormhole", "texturePath": "res:/UI/Texture/Shared/Brackets/wormhole.png"}
23	2337	{"_key": 2337, "name": "Drone Mining", "texturePath": "res:/UI/Texture/Shared/Brackets/droneMining_16.png"}
24	2338	{"_key": 2338, "name": "Destroyer", "texturePath": "res:/UI/Texture/Shared/Brackets/destroyer_16.png"}
25	2339	{"_key": 2339, "name": "Frigate", "texturePath": "res:/UI/Texture/Shared/Brackets/frigate_16.png"}
26	2340	{"_key": 2340, "name": "Mobile Power Core", "texturePath": "res:/UI/Texture/Icons/38_16_139.png"}
27	2341	{"_key": 2341, "name": "Scanner Probe", "iconOffset": -20, "texturePath": "res:/UI/Texture/Shared/Brackets/scannerProbe.png"}
28	2343	{"_key": 2343, "name": "Asteroid Billboard", "texturePath": "res:/UI/Texture/Shared/Brackets/billboard.png"}
29	2345	{"_key": 2345, "name": "NPC Industrial", "texturePath": "res:/UI/Texture/Shared/Brackets/npcindustrial_16.png"}
30	2346	{"_key": 2346, "name": "Industrial Command Ship", "texturePath": "res:/UI/Texture/Shared/Brackets/industrialCommand_16.png"}
31	2347	{"_key": 2347, "name": "Moon Mining", "texturePath": "res:/UI/Texture/Shared/Brackets/moonMining.png"}
32	2349	{"_key": 2349, "name": "Celestial Beacon II", "texturePath": "res:/UI/Texture/Shared/Brackets/beacon.png"}
33	2350	{"_key": 2350, "name": "Starbase Energy Neutralizing Battery", "texturePath": "res:/UI/Texture/Shared/Brackets/batteryEnergyNeutralizing.png"}
34	2352	{"_key": 2352, "name": "Starbase Missile Battery", "texturePath": "res:/UI/Texture/Shared/Brackets/mobileSentryMissile.png"}
35	2353	{"_key": 2353, "name": "Satellite Beacon", "texturePath": "res:/UI/Texture/Shared/Brackets/beacon.png"}
36	2354	{"_key": 2354, "name": "Cargo container", "texturePath": "res:/UI/Texture/Shared/Brackets/containerCargo.png"}
37	2355	{"_key": 2355, "name": "Platform", "texturePath": "res:/UI/Texture/Shared/Brackets/constructionPlatform.png", "maxVisibleDistance": 50000.0}
38	2356	{"_key": 2356, "name": "NPC Mining Barge", "texturePath": "res:/UI/Texture/Shared/Brackets/npcminingBarge_16.png"}
39	2357	{"_key": 2357, "name": "Mobile Storage", "texturePath": "res:/UI/Texture/Shared/Brackets/mobileStorage.png"}
40	2358	{"_key": 2358, "name": "Corporate Hangar Array", "texturePath": "res:/UI/Texture/Shared/Brackets/corpHangarArray.png"}
41	2359	{"_key": 2359, "name": "Planetary Customs Office", "texturePath": "res:/UI/Texture/Shared/Brackets/customsOffice.png"}
42	2361	{"_key": 2361, "name": "Shuttle", "texturePath": "res:/UI/Texture/Shared/Brackets/shuttle_16.png"}
43	2362	{"_key": 2362, "name": "Capture Point", "iconOffset": -20, "texturePath": "res:/UI/Texture/Shared/Brackets/capturePointTower.png"}
44	2363	{"_key": 2363, "name": "NPC Freighter", "texturePath": "res:/UI/Texture/Shared/Brackets/npcfreighter_16.png"}
45	2364	{"_key": 2364, "name": "NPC Battleship", "texturePath": "res:/UI/Texture/Shared/Brackets/npcbattleship_16.png"}
46	2365	{"_key": 2365, "name": "Freighter", "texturePath": "res:/UI/Texture/Shared/Brackets/freighter_16.png"}
47	2366	{"_key": 2366, "name": "Entity", "texturePath": "res:/UI/Texture/Shared/Brackets/entity.png"}
48	2367	{"_key": 2367, "name": "NPC Shuttle", "texturePath": "res:/UI/Texture/Shared/Brackets/npcshuttle_16.png"}
49	2368	{"_key": 2368, "name": "Carrier", "texturePath": "res:/UI/Texture/Shared/Brackets/carrier_16.png"}
50	2370	{"_key": 2370, "name": "Structure", "texturePath": "res:/UI/Texture/Shared/Brackets/structure.png"}
51	2371	{"_key": 2371, "name": "Mobile Shield Generator", "texturePath": "res:/UI/Texture/Icons/38_16_134.png"}
52	2372	{"_key": 2372, "name": "Starbase Electronic Warfare Battery", "texturePath": "res:/UI/Texture/Shared/Brackets/batteryElectronicWarfare.png"}
53	2373	{"_key": 2373, "name": "Cruiser", "texturePath": "res:/UI/Texture/Shared/Brackets/cruiser_16.png"}
54	2374	{"_key": 2374, "name": "Agents in Space", "texturePath": "res:/UI/Texture/Shared/Brackets/agentInSpace.png"}
55	2375	{"_key": 2375, "name": "Celestial Agent Site Beacon", "texturePath": "res:/UI/Texture/Shared/Brackets/beacon.png"}
56	2377	{"_key": 2377, "name": "Scanner Array", "texturePath": "res:/UI/Texture/Icons/38_16_240.png"}
57	2379	{"_key": 2379, "name": "Assembly Array", "texturePath": "res:/UI/Texture/Shared/Brackets/assemblyArray.png"}
58	2380	{"_key": 2380, "name": "Station", "texturePath": "res:/UI/Texture/Shared/Brackets/station.png", "minVisibleDistance": 7000.0}
59	2381	{"_key": 2381, "name": "Moon", "texturePath": "res:/UI/Texture/Shared/Brackets/moon.png"}
60	2382	{"_key": 2382, "name": "NPC Rookie Ship", "texturePath": "res:/UI/Texture/Shared/Brackets/npcrookie_16.png"}
61	2383	{"_key": 2383, "name": "NO BRACKET", "texturePath": "None"}
62	2384	{"_key": 2384, "name": "Sentry Gun", "texturePath": "res:/UI/Texture/Shared/Brackets/sentry.png", "minVisibleDistance": 2000.0}
63	2385	{"_key": 2385, "name": "Fighter", "texturePath": "res:/UI/Texture/Shared/Brackets/droneFighter_16.png"}
64	2386	{"_key": 2386, "name": "Mobile Jump Disruptor", "texturePath": "res:/UI/Texture/Shared/Brackets/mobileJumpDisruptor.png"}
65	2387	{"_key": 2387, "name": "Drone EW", "texturePath": "res:/UI/Texture/Shared/Brackets/droneEW_16.png"}
66	2388	{"_key": 2388, "name": "Industrial Ship", "texturePath": "res:/UI/Texture/Shared/Brackets/industrial_16.png"}
67	2389	{"_key": 2389, "name": "Drone Sentry", "texturePath": "res:/UI/Texture/Shared/Brackets/droneSentry_16.png"}
68	2391	{"_key": 2391, "name": "Capsule", "texturePath": "res:/UI/Texture/Shared/Brackets/capsule_16.png"}
69	2393	{"_key": 2393, "name": "Drone Logistics", "texturePath": "res:/UI/Texture/Shared/Brackets/droneLogistics_16.png"}
70	2394	{"_key": 2394, "name": "Dreadnought", "texturePath": "res:/UI/Texture/Shared/Brackets/dreadnought_16.png"}
71	2396	{"_key": 2396, "name": "Control Tower", "texturePath": "res:/UI/Texture/Shared/Brackets/controlTower.png"}
72	2397	{"_key": 2397, "name": "Battleship", "texturePath": "res:/UI/Texture/Shared/Brackets/battleship_16.png"}
73	2398	{"_key": 2398, "name": "NPC Cruiser", "texturePath": "res:/UI/Texture/Shared/Brackets/npccruiser_16.png"}
74	2399	{"_key": 2399, "name": "Drone", "texturePath": "res:/UI/Texture/Shared/Brackets/droneAttack_16.png"}
75	2400	{"_key": 2400, "name": "Harvestable Cloud", "iconOffset": -20, "texturePath": "res:/UI/Texture/Shared/Brackets/harvestableCloud.png", "minVisibleDistance": 50000.0}
76	2402	{"_key": 2402, "name": "Fighter Bomber", "texturePath": "res:/UI/Texture/Shared/Brackets/droneFighterBomber_16.png"}
77	2404	{"_key": 2404, "name": "Laboratory", "texturePath": "res:/UI/Texture/Shared/Brackets/mobileLab.png"}
78	2405	{"_key": 2405, "name": "Cargo Container NPC", "texturePath": "res:/UI/Texture/Shared/Brackets/containerCargoNPC.png"}
79	2407	{"_key": 2407, "name": "Wreck", "texturePath": "res:/UI/Texture/Shared/Brackets/wreck.png", "texturePathEmpty": "res:/UI/Texture/Shared/Brackets/wreckLooted.png"}
80	2409	{"_key": 2409, "name": "Wreck NPC", "texturePath": "res:/UI/Texture/Shared/Brackets/wreckNPC.png", "texturePathEmpty": "res:/UI/Texture/Shared/Brackets/wreckLootedNPC.png"}
81	2410	{"_key": 2410, "name": "Planetary Customs Office NPC", "texturePath": "res:/UI/Texture/Shared/Brackets/customsOfficeNPC.png"}
82	2413	{"_key": 2413, "name": "Super Carrier", "texturePath": "res:/UI/Texture/Shared/Brackets/superCarrier_16.png"}
83	2414	{"_key": 2414, "name": "NPC Super Carrier", "texturePath": "res:/UI/Texture/Shared/Brackets/npcsuperCarrier_16.png"}
84	2415	{"_key": 2415, "name": "Mobile Warp Disruptor", "texturePath": "res:/UI/Texture/Shared/Brackets/mobileWarpDisruptor.png"}
85	2416	{"_key": 2416, "name": "NPC Battlecruiser", "texturePath": "res:/UI/Texture/Shared/Brackets/npcbattlecruiser_16.png"}
86	2417	{"_key": 2417, "name": "NPC Drone EW", "texturePath": "res:/UI/Texture/Shared/Brackets/NPCdroneEW_16.png"}
87	2419	{"_key": 2419, "name": "NPC Drone", "texturePath": "res:/UI/Texture/Shared/Brackets/npcdroneAttack_16.png"}
88	2421	{"_key": 2421, "name": "Asteroid Medium", "texturePath": "res:/UI/Texture/Shared/Brackets/asteroidMedium.png"}
89	2422	{"_key": 2422, "name": "Asteroid Large", "texturePath": "res:/UI/Texture/Shared/Brackets/asteroidLarge.png"}
90	2423	{"_key": 2423, "name": "Asteroid Small", "texturePath": "res:/UI/Texture/Shared/Brackets/asteroidSmall.png"}
91	2424	{"_key": 2424, "name": "Ice Small", "texturePath": "res:/UI/Texture/Shared/Brackets/iceAsteroidSmall.png"}
92	2425	{"_key": 2425, "name": "Ice Large", "texturePath": "res:/UI/Texture/Shared/Brackets/iceAsteroidLarge.png"}
93	2426	{"_key": 2426, "name": "Ice Field", "texturePath": "res:/UI/Texture/Shared/Brackets/iceField.png"}
94	2427	{"_key": 2427, "name": "Destructible Station Service", "texturePath": "res:/UI/Texture/Shared/Brackets/destructibleStationServices.png"}
95	2428	{"_key": 2428, "name": "Reprocessing Array", "texturePath": "res:/UI/Texture/Shared/Brackets/mobileReprocessingArray.png"}
96	2429	{"_key": 2429, "name": "Compression Array", "texturePath": "res:/UI/Texture/Shared/Brackets/compressionArray.png"}
97	2430	{"_key": 2430, "name": "Starbase Laser Battery", "texturePath": "res:/UI/Texture/Shared/Brackets/mobileSentryLaser.png"}
98	2431	{"_key": 2431, "name": "Starbase Projectile Battery", "texturePath": "res:/UI/Texture/Shared/Brackets/mobileSentryProjectile.png"}
99	2432	{"_key": 2432, "name": "Starbase Sensor Dampening Battery", "texturePath": "res:/UI/Texture/Shared/Brackets/batterySensorDampening.png"}
100	2433	{"_key": 2433, "name": "Starbase Stasis Webification Battery", "texturePath": "res:/UI/Texture/Shared/Brackets/batteryStasisWebification.png"}
101	2434	{"_key": 2434, "name": "Starbase Warp Scrambling Battery", "texturePath": "res:/UI/Texture/Shared/Brackets/batteryWarpScrambling.png"}
102	2435	{"_key": 2435, "name": "Starbase Shield Hardening Array", "texturePath": "res:/UI/Texture/Shared/Brackets/shieldHardeningArray.png"}
103	2436	{"_key": 2436, "name": "NPC Fighter Bomber", "texturePath": "res:/UI/Texture/Shared/Brackets/npcdroneFighterBomber_16.png"}
104	2437	{"_key": 2437, "name": "Frozen Corpse", "texturePath": "res:/UI/Texture/Shared/Brackets/frozenCorpse.png"}
105	2438	{"_key": 2438, "name": "Ship Maintenance Array", "texturePath": "res:/UI/Texture/Shared/Brackets/shipMaintenanceArray.png"}
106	2439	{"_key": 2439, "name": "XL Ship maintenance Array", "texturePath": "res:/UI/Texture/Shared/Brackets/shipMaintenanceArrayXL.png"}
107	2440	{"_key": 2440, "name": "Personal Hangar Array", "texturePath": "res:/UI/Texture/Shared/Brackets/personalHangarArray.png"}
108	2441	{"_key": 2441, "name": "Silo", "texturePath": "res:/UI/Texture/Shared/Brackets/silo.png"}
109	2442	{"_key": 2442, "name": "Coupling Array", "texturePath": "res:/UI/Texture/Shared/Brackets/couplingArray.png"}
110	2443	{"_key": 2443, "name": "Mobile Scan Inhibitor", "texturePath": "res:/UI/Texture/Shared/Brackets/mobileScanInhibitor.png"}
111	2445	{"_key": 2445, "name": "Encounter Surveillance System", "texturePath": "res:/UI/Texture/Shared/Brackets/encounterSurveillanceSystem.png"}
112	2446	{"_key": 2446, "name": "Mobile Cynosural Inhibitor", "texturePath": "res:/UI/Texture/Shared/Brackets/mobileCynosuralInhibitor.png"}
113	2447	{"_key": 2447, "name": "Mobile Siphon Unit", "texturePath": "res:/UI/Texture/Shared/Brackets/mobileSiphonUnit.png"}
114	2448	{"_key": 2448, "name": "Mobile Tractor Unit", "texturePath": "res:/UI/Texture/Shared/Brackets/mobileTractorUnit.png"}
115	2449	{"_key": 2449, "name": "Mobile Micro Jump Unit", "texturePath": "res:/UI/Texture/Shared/Brackets/mobileMicroJumpUnit.png"}
116	2450	{"_key": 2450, "name": "Sovereignty Blockade Unit", "texturePath": "res:/UI/Texture/Shared/Brackets/sovereigntyBlockadeUnit.png"}
117	2451	{"_key": 2451, "name": "Territorial Claim Unit", "texturePath": "res:/UI/Texture/Shared/Brackets/territorialClaimUnit.png"}
118	2453	{"_key": 2453, "name": "Infrastructure Hub", "texturePath": "res:/UI/Texture/Shared/Brackets/infrastructureHub.png"}
119	2454	{"_key": 2454, "name": "Mobile Depot", "texturePath": "res:/UI/Texture/Shared/Brackets/mobileStorage.png"}
120	2455	{"_key": 2455, "name": "Biomass", "texturePath": "res:/UI/Texture/Shared/Brackets/frozenCorpse.png"}
121	2457	{"_key": 2457, "name": "NPC Fighter", "texturePath": "res:/UI/Texture/Shared/Brackets/npcdroneFighter_16.png"}
122	2458	{"_key": 2458, "name": "NPC Industrial Command Ship", "texturePath": "res:/UI/Texture/Shared/Brackets/npcindustrialCommand_16.png"}
123	2461	{"_key": 2461, "name": "Command Node Beacon", "texturePath": "res:/UI/Texture/Shared/Brackets/commandNode.png"}
124	2462	{"_key": 2462, "name": "Cynosural Field", "texturePath": "res:/UI/Texture/Shared/Brackets/cynosuralField.png"}
125	2466	{"_key": 2466, "name": "Force Field", "texturePath": "res:/UI/Texture/Shared/Brackets/forceFieldArray.png"}
126	2467	{"_key": 2467, "name": "Medium Structure", "texturePath": "res:/UI/Texture/Shared/Brackets/citadelMedium.png"}
127	2468	{"_key": 2468, "name": "Large Structure", "texturePath": "res:/UI/Texture/Shared/Brackets/citadelLarge.png"}
128	2469	{"_key": 2469, "name": "Extra Large Structure", "texturePath": "res:/UI/Texture/Shared/Brackets/citadelExtraLarge.png"}
129	2472	{"_key": 2472, "name": "Fighter Squadron", "texturePath": "res:/UI/Texture/Shared/Brackets/fighterSquad_16.png"}
130	2473	{"_key": 2473, "name": "NPC Fighter Squadron", "texturePath": "res:/UI/Texture/Shared/Brackets/npcfighterSquad_16.png"}
131	2474	{"_key": 2474, "name": "NPC Dreadnought", "texturePath": "res:/UI/Texture/Shared/Brackets/npcdreadnought_16.png"}
132	2475	{"_key": 2475, "name": "NPC Titan", "texturePath": "res:/UI/Texture/Shared/Brackets/npctitan_16.png"}
133	2476	{"_key": 2476, "name": "Force Auxiliary", "texturePath": "res:/UI/Texture/Shared/Brackets/forceAuxiliary_16.png"}
134	2478	{"_key": 2478, "name": "NPC Mining Frigate", "texturePath": "res:/UI/Texture/Shared/Brackets/npcminingFrigate_16.png"}
135	2479	{"_key": 2479, "name": "Extra Large Engineering Complex", "texturePath": "res:/UI/Texture/Shared/Brackets/engineeringComplexExtraLarge.png"}
136	2480	{"_key": 2480, "name": "Large Engineering Complex", "texturePath": "res:/UI/Texture/Shared/Brackets/engineeringComplexLarge.png"}
137	2481	{"_key": 2481, "name": "Medium Engineering Complex", "texturePath": "res:/UI/Texture/Shared/Brackets/engineeringComplexMedium.png"}
138	2482	{"_key": 2482, "name": "NPC Extra Large Engineering Complex", "texturePath": "res:/UI/Texture/Shared/Brackets/engineeringComplexExtraLargeNPC.png"}
139	2484	{"_key": 2484, "name": "NPC Force Auxiliary", "texturePath": "res:/UI/Texture/Shared/Brackets/npcforceAuxiliary_16.png"}
140	2485	{"_key": 2485, "name": "Medium Refinery", "texturePath": "res:/UI/Texture/Shared/Brackets/refineryMedium.png"}
141	2486	{"_key": 2486, "name": "Large Refinery", "texturePath": "res:/UI/Texture/Shared/Brackets/refineryLarge.png"}
142	2490	{"_key": 2490, "name": "Moon Asteroid", "texturePath": "res:/UI/Texture/Shared/Brackets/moonAsteroidRegular.png"}
143	2491	{"_key": 2491, "name": "Moon Asteroid Jackpot", "texturePath": "res:/UI/Texture/Shared/Brackets/moonAsteroidJackpot.png"}
144	2499	{"_key": 2499, "name": "Upwell Cyno Jammer", "texturePath": "res:/UI/Texture/Shared/Brackets/cynosuralJammer.png"}
145	2500	{"_key": 2500, "name": "Upwell Cyno Beacon", "texturePath": "res:/UI/Texture/Shared/Brackets/cynosuralBeacon.png"}
146	2501	{"_key": 2501, "name": "Upwell Jumpgate", "texturePath": "res:/UI/Texture/Shared/Brackets/playerStargateSmall.png"}
147	4506	{"_key": 4506, "name": "World Ark", "texturePath": "res:/UI/Texture/Shared/Brackets/Triglavian_16.png"}
148	4511	{"_key": 4511, "name": "NPC Capsule", "texturePath": "res:/UI/Texture/Shared/Brackets/npccapsule_16.png"}
149	4514	{"_key": 4514, "name": "Stargate Wreck", "texturePath": "res:/UI/Texture/Shared/Brackets/stargateWreck.png"}
150	4516	{"_key": 4516, "name": "Brawl Cloud", "texturePath": "res:/UI/Texture/Shared/Brackets/harvestableCloud.png"}
151	4519	{"_key": 4519, "name": "Shipcaster Launcher", "texturePath": "res:/UI/Texture/Shared/Brackets/shipcasterLauncher_16.png"}
152	4520	{"_key": 4520, "name": "Shipcaster Beacon", "texturePath": "res:/UI/Texture/Shared/Brackets/shipcasterLandingPad_16.png"}
153	4521	{"_key": 4521, "name": "Colossus", "texturePath": "res:/UI/Texture/Shared/Brackets/colossus_64.png"}
154	4522	{"_key": 4522, "name": "Pirate FOB", "texturePath": "res:/UI/Texture/Shared/Brackets/fob_bracket.png"}
155	4529	{"_key": 4529, "name": "Metenox Auto Moon Drill Miner", "texturePath": "res:/UI/Texture/eveicon/bracket_icons/auto_moon_miner_bracket_16px.png"}
156	4530	{"_key": 4530, "name": "Sovereignty Hub", "texturePath": "res:/UI/Texture/eveicon/bracket_icons/sov_hub_bracket_16px.png"}
157	4531	{"_key": 4531, "name": "Reagents Skyhook", "texturePath": "res:/UI/Texture/eveicon/bracket_icons/reagents_skyhook_bracket_16px.png"}
158	4532	{"_key": 4532, "name": "Skyhook", "texturePath": "res:/UI/Texture/eveicon/bracket_icons/skyhook_bracket_16px.png"}
159	4533	{"_key": 4533, "name": "Wreck Empty", "texturePath": "res:/UI/Texture/Shared/Brackets/wreckLooted.png"}
160	4534	{"_key": 4534, "name": "Crossover Enemies", "texturePath": "res:/UI/Texture/Shared/Brackets/npcdroneAttack_16.png"}
161	4535	{"_key": 4535, "name": "Mercenary Den", "texturePath": "res:/UI/Texture/eveicon/bracket_icons/mercenary_den_bracket_16px.png"}
162	4537	{"_key": 4537, "name": "MiningDestroyer", "texturePath": "res:/UI/Texture/Shared/Brackets/miningDestroyer_16.png"}
163	4538	{"_key": 4538, "name": "NPC MiningDestroyer", "texturePath": "res:/UI/Texture/Shared/Brackets/npcminingDestroyer_16.png"}
164	4539	{"_key": 4539, "name": "Expedition Command Ship", "texturePath": "res:/UI/Texture/Shared/Brackets/battleCruiser_16.png"}
165	4540	{"_key": 4540, "name": "Ore Deposit", "texturePath": "res:/UI/Texture/Shared/Brackets/ore_site_16.png"}
166	4541	{"_key": 4541, "name": "Phased Prismaticite", "texturePath": "res:/UI/Texture/Shared/Brackets/PhasedPrismaticite.png"}
167	4542	{"_key": 4542, "name": "Phased Field", "texturePath": "res:/UI/Texture/Shared/Brackets/PhasedField.png"}
168	4543	{"_key": 4543, "name": "Mobile Phase Stabilizer", "texturePath": "res:/UI/Texture/Shared/Brackets/PhasedStabilizer.png"}
\.


--
-- Name: brackets brackets_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.brackets
    ADD CONSTRAINT brackets_pkey PRIMARY KEY (row_no);


--
-- Name: brackets_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX brackets_key_idx ON sde_native.brackets USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict lmr4kWXvuMAFt2SHVRrN2rg3KssBJasanxKKr2tzY8ucTwccakZrBj9umoCS7Bk

