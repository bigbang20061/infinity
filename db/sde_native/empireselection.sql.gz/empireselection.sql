--
-- PostgreSQL database dump
--

\restrict 178b0agWaSdaLFe8YA1oUW7PJegHMzoo4xMvA8TsUu5QbuMCCs9oOlayibSv0KG

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: empireselection; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.empireselection (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: empireselection; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.empireselection (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "quote": 525621, "logoPath": "res:/UI/Texture/classes/EmpireSelection/empireLogoCaldari_NoText.png", "sealPath": "res:/UI/Texture/classes/EmpireSelection/empireSealCaldari.png", "bloodlines": {"1": 528365, "2": 528364, "11": 528363}, "empireColor": [0.29019609093666077, 0.4274509847164154, 0.501960813999176, 1.0], "namedLogoPath": "res:/UI/Texture/classes/EmpireSelection/empireLogoCaldari.png"}
1	2	{"_key": 2, "quote": 525623, "logoPath": "res:/UI/Texture/classes/EmpireSelection/empireLogoMinmatar_NoText.png", "sealPath": "res:/UI/Texture/classes/EmpireSelection/empireSealMinmatar.png", "bloodlines": {"3": 528373, "4": 528372, "14": 528371}, "empireColor": [0.4000000059604645, 0.21960784494876862, 0.20392157137393951, 1.0], "namedLogoPath": "res:/UI/Texture/classes/EmpireSelection/empireLogoMinmatar.png"}
2	4	{"_key": 4, "quote": 525620, "logoPath": "res:/UI/Texture/classes/EmpireSelection/empireLogoAmarr_NoText.png", "sealPath": "res:/UI/Texture/classes/EmpireSelection/empireSealAmarr.png", "bloodlines": {"5": 528359, "6": 528361, "13": 528362}, "empireColor": [0.501960813999176, 0.4274509847164154, 0.3176470696926117, 1.0], "namedLogoPath": "res:/UI/Texture/classes/EmpireSelection/empireLogoAmarr.png"}
3	8	{"_key": 8, "quote": 525622, "logoPath": "res:/UI/Texture/classes/EmpireSelection/empireLogoGallente_NoText.png", "sealPath": "res:/UI/Texture/classes/EmpireSelection/empireSealGallente.png", "bloodlines": {"7": 528369, "8": 528370, "12": 528368}, "empireColor": [0.21176470816135406, 0.4000000059604645, 0.4000000059604645, 1.0], "namedLogoPath": "res:/UI/Texture/classes/EmpireSelection/empireLogoGallente.png"}
\.


--
-- Name: empireselection empireselection_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.empireselection
    ADD CONSTRAINT empireselection_pkey PRIMARY KEY (row_no);


--
-- Name: empireselection_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX empireselection_key_idx ON sde_native.empireselection USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 178b0agWaSdaLFe8YA1oUW7PJegHMzoo4xMvA8TsUu5QbuMCCs9oOlayibSv0KG

