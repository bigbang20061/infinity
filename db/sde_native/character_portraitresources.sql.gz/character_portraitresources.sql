--
-- PostgreSQL database dump
--

\restrict FBaDbVzJ9eCitViiB0nIIh8MXh9OT0XMgxQlZ1Aso0VMvb8QuWpNArikcwrZOtB

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: character_portraitresources; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.character_portraitresources (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: character_portraitresources; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.character_portraitresources (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_1.dds", "resourceCategory": "background"}
1	2	{"_key": 2, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_2.dds", "resourceCategory": "background"}
2	3	{"_key": 3, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_3.dds", "resourceCategory": "background"}
3	4	{"_key": 4, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_4.dds", "resourceCategory": "background"}
4	5	{"_key": 5, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_5.dds", "resourceCategory": "background"}
5	6	{"_key": 6, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_6.dds", "resourceCategory": "background"}
6	7	{"_key": 7, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_7.dds", "resourceCategory": "background"}
7	8	{"_key": 8, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_8.dds", "resourceCategory": "background"}
8	9	{"_key": 9, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_9.dds", "resourceCategory": "background"}
9	10	{"_key": 10, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_10.dds", "resourceCategory": "background"}
10	11	{"_key": 11, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_11.dds", "resourceCategory": "background"}
11	12	{"_key": 12, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_12.dds", "resourceCategory": "background"}
12	13	{"_key": 13, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_13.dds", "resourceCategory": "background"}
13	14	{"_key": 14, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_14.dds", "resourceCategory": "background"}
14	15	{"_key": 15, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_15.dds", "resourceCategory": "background"}
15	16	{"_key": 16, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_16.dds", "resourceCategory": "background"}
16	17	{"_key": 17, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_17.dds", "resourceCategory": "background"}
17	18	{"_key": 18, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_18.dds", "resourceCategory": "background"}
18	19	{"_key": 19, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_19.dds", "resourceCategory": "background"}
19	20	{"_key": 20, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_20.dds", "resourceCategory": "background"}
20	21	{"_key": 21, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_21.dds", "resourceCategory": "background"}
21	22	{"_key": 22, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_22.dds", "resourceCategory": "background"}
22	23	{"_key": 23, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_23.dds", "resourceCategory": "background"}
23	24	{"_key": 24, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_24.dds", "resourceCategory": "background"}
24	25	{"_key": 25, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_25.dds", "resourceCategory": "background"}
25	26	{"_key": 26, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_26.dds", "resourceCategory": "background"}
26	27	{"_key": 27, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_27.dds", "resourceCategory": "background"}
27	28	{"_key": 28, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_28.dds", "resourceCategory": "background"}
28	29	{"_key": 29, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_29.dds", "resourceCategory": "background"}
29	30	{"_key": 30, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_30.dds", "resourceCategory": "background"}
30	31	{"_key": 31, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_31.dds", "resourceCategory": "background"}
31	32	{"_key": 32, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_32.dds", "resourceCategory": "background"}
32	33	{"_key": 33, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_33.dds", "resourceCategory": "background"}
33	34	{"_key": 34, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_34.dds", "resourceCategory": "background"}
34	35	{"_key": 35, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_35.dds", "resourceCategory": "background"}
35	36	{"_key": 36, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_36.dds", "resourceCategory": "background"}
36	37	{"_key": 37, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_37.dds", "resourceCategory": "background"}
37	38	{"_key": 38, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_38.dds", "resourceCategory": "background"}
38	39	{"_key": 39, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_39.dds", "resourceCategory": "background"}
39	40	{"_key": 40, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_40.dds", "resourceCategory": "background"}
40	41	{"_key": 41, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_41.dds", "resourceCategory": "background"}
41	42	{"_key": 42, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_42.dds", "resourceCategory": "background"}
42	43	{"_key": 43, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_43.dds", "resourceCategory": "background"}
43	44	{"_key": 44, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_44.dds", "resourceCategory": "background"}
44	45	{"_key": 45, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_45.dds", "resourceCategory": "background"}
45	46	{"_key": 46, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_46.dds", "resourceCategory": "background"}
46	47	{"_key": 47, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_47.dds", "resourceCategory": "background"}
47	48	{"_key": 48, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_48.dds", "resourceCategory": "background"}
48	49	{"_key": 49, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_49.dds", "resourceCategory": "background"}
49	50	{"_key": 50, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_50.dds", "resourceCategory": "background"}
50	51	{"_key": 51, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_51.dds", "resourceCategory": "background"}
51	52	{"_key": 52, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_52.dds", "resourceCategory": "background"}
52	53	{"_key": 53, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_53.dds", "resourceCategory": "background"}
53	54	{"_key": 54, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_54.dds", "resourceCategory": "background"}
54	55	{"_key": 55, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_55.dds", "resourceCategory": "background"}
55	56	{"_key": 56, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_56.dds", "resourceCategory": "background"}
56	57	{"_key": 57, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_57.dds", "resourceCategory": "background"}
57	58	{"_key": 58, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_58.dds", "resourceCategory": "background"}
58	59	{"_key": 59, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_59.dds", "resourceCategory": "background"}
59	60	{"_key": 60, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_60.dds", "resourceCategory": "background"}
60	61	{"_key": 61, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_61.dds", "resourceCategory": "background"}
61	62	{"_key": 62, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_62.dds", "resourceCategory": "background"}
62	63	{"_key": 63, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_63.dds", "resourceCategory": "background"}
63	64	{"_key": 64, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_64.dds", "resourceCategory": "background"}
64	65	{"_key": 65, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_65.dds", "resourceCategory": "background"}
65	66	{"_key": 66, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_66.dds", "resourceCategory": "background"}
66	67	{"_key": 67, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_67.dds", "resourceCategory": "background"}
67	68	{"_key": 68, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_68.dds", "resourceCategory": "background"}
68	69	{"_key": 69, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_69.dds", "resourceCategory": "background"}
69	70	{"_key": 70, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_70.dds", "resourceCategory": "background"}
70	71	{"_key": 71, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_71.dds", "resourceCategory": "background"}
71	72	{"_key": 72, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_72.dds", "resourceCategory": "background"}
72	73	{"_key": 73, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_73.dds", "resourceCategory": "background"}
73	74	{"_key": 74, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_74.dds", "resourceCategory": "background"}
74	75	{"_key": 75, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_75.dds", "resourceCategory": "background"}
75	76	{"_key": 76, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_76.dds", "resourceCategory": "background"}
76	77	{"_key": 77, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_77.dds", "resourceCategory": "background"}
77	78	{"_key": 78, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_78.dds", "resourceCategory": "background"}
78	79	{"_key": 79, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_79.dds", "resourceCategory": "background"}
79	80	{"_key": 80, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_80.dds", "resourceCategory": "background"}
80	81	{"_key": 81, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_81.dds", "resourceCategory": "background"}
81	82	{"_key": 82, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_82.dds", "resourceCategory": "background"}
82	83	{"_key": 83, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_83.dds", "resourceCategory": "background"}
83	84	{"_key": 84, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_84.dds", "resourceCategory": "background"}
84	85	{"_key": 85, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_85.dds", "resourceCategory": "background"}
85	86	{"_key": 86, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_86.dds", "resourceCategory": "background"}
86	87	{"_key": 87, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_87.dds", "resourceCategory": "background"}
87	88	{"_key": 88, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_88.dds", "resourceCategory": "background"}
88	89	{"_key": 89, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_89.dds", "resourceCategory": "background"}
89	90	{"_key": 90, "typeID": 55360, "resPath": "res:/ui/Texture/CharacterCreation/background/bg1.png", "resourceCategory": "background"}
90	95	{"_key": 95, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_Fanfest_2022.dds", "resourceCategory": "background"}
91	117	{"_key": 117, "typeID": 92554, "resPath": "res:/UI/Texture/CharacterCreation/Backdrops/Background_92.dds", "resourceCategory": "background"}
92	118	{"_key": 118, "typeID": 92555, "resPath": "res:/UI/Texture/CharacterCreation/Backdrops/Background_93.dds", "resourceCategory": "background"}
93	119	{"_key": 119, "typeID": 92550, "resPath": "res:/UI/Texture/CharacterCreation/Backdrops/Background_94.dds", "resourceCategory": "background"}
94	120	{"_key": 120, "typeID": 95228, "resPath": "res:/UI/Texture/CharacterCreation/Backdrops/Background_95.dds", "resourceCategory": "background"}
95	121	{"_key": 121, "typeID": 95275, "resPath": "res:/UI/Texture/CharacterCreation/Backdrops/Background_96.dds", "resourceCategory": "background"}
96	122	{"_key": 122, "typeID": 95458, "resPath": "res:/UI/Texture/CharacterCreation/Backdrops/Background_97.dds", "resourceCategory": "background"}
97	123	{"_key": 123, "typeID": 95501, "resPath": "res:/UI/Texture/CharacterCreation/Backdrops/Background_98.dds", "resourceCategory": "background"}
98	124	{"_key": 124, "typeID": 95672, "resPath": "res:/UI/Texture/CharacterCreation/Backdrops/Background_99.dds", "resourceCategory": "background"}
99	125	{"_key": 125, "typeID": 95673, "resPath": "res:/UI/Texture/CharacterCreation/Backdrops/Background_100.dds", "resourceCategory": "background"}
100	126	{"_key": 126, "typeID": 95674, "resPath": "res:/UI/Texture/CharacterCreation/Backdrops/Background_101.dds", "resourceCategory": "background"}
101	9999	{"_key": 9999, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_Crossover_2024.dds", "resourceCategory": "background"}
102	99991	{"_key": 99991, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_dhh_01.dds", "resourceCategory": "background"}
103	99992	{"_key": 99992, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_dhh_02.dds", "resourceCategory": "background"}
104	99993	{"_key": 99993, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_dhh_03.dds", "resourceCategory": "background"}
105	99994	{"_key": 99994, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_dhh_04.dds", "resourceCategory": "background"}
106	99995	{"_key": 99995, "typeID": 95454, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_20th_R.dds", "resourceCategory": "background"}
107	99996	{"_key": 99996, "typeID": 95455, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_20th_B.dds", "resourceCategory": "background"}
108	99997	{"_key": 99997, "typeID": 95456, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_20th_G.dds", "resourceCategory": "background"}
109	99998	{"_key": 99998, "typeID": 96056, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_Maj_Basic.dds", "resourceCategory": "background"}
110	99999	{"_key": 99999, "typeID": 96057, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_Maj_Bronze.dds", "resourceCategory": "background"}
111	100001	{"_key": 100001, "typeID": 96058, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_Maj_Silver.dds", "resourceCategory": "background"}
112	100002	{"_key": 100002, "typeID": 96059, "resPath": "res:/ui/Texture/CharacterCreation/backdrops/Background_Maj_Gold.dds", "resourceCategory": "background"}
\.


--
-- Name: character_portraitresources character_portraitresources_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.character_portraitresources
    ADD CONSTRAINT character_portraitresources_pkey PRIMARY KEY (row_no);


--
-- Name: character_portraitresources_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX character_portraitresources_key_idx ON sde_native.character_portraitresources USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict FBaDbVzJ9eCitViiB0nIIh8MXh9OT0XMgxQlZ1Aso0VMvb8QuWpNArikcwrZOtB

