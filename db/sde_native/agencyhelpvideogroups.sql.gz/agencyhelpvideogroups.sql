--
-- PostgreSQL database dump
--

\restrict 2MaUF3fHSKBaty2hpjAlERxhjgEQDDameqKCCBrx8Nk4cF5nMrdJBIAn8iglMvP

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agencyhelpvideogroups; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.agencyhelpvideogroups (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: agencyhelpvideogroups; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.agencyhelpvideogroups (row_no, key, data) FROM stdin;
0	22	{"_key": 22, "nameID": 573443, "videos": [37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50]}
1	25	{"_key": 25, "nameID": 582650, "videos": [58, 59, 65]}
2	26	{"_key": 26, "nameID": 582686, "videos": [57, 62, 63, 68]}
3	27	{"_key": 27, "nameID": 582687, "videos": [56, 64]}
4	28	{"_key": 28, "nameID": 582688, "videos": [55, 60]}
5	31	{"_key": 31, "nameID": 594344, "videos": [72, 73, 74, 75, 76]}
6	35	{"_key": 35, "nameID": 602204, "videos": [85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95]}
\.


--
-- Name: agencyhelpvideogroups agencyhelpvideogroups_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.agencyhelpvideogroups
    ADD CONSTRAINT agencyhelpvideogroups_pkey PRIMARY KEY (row_no);


--
-- Name: agencyhelpvideogroups_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX agencyhelpvideogroups_key_idx ON sde_native.agencyhelpvideogroups USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 2MaUF3fHSKBaty2hpjAlERxhjgEQDDameqKCCBrx8Nk4cF5nMrdJBIAn8iglMvP

