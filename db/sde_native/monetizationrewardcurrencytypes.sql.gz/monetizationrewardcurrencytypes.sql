--
-- PostgreSQL database dump
--

\restrict cScmb82X4XW9ahLuUCbus9i6hgZ1E3eT3asABwsk7V8qEqtOYrjSLU4EGMSGu8P

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: monetizationrewardcurrencytypes; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.monetizationrewardcurrencytypes (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: monetizationrewardcurrencytypes; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.monetizationrewardcurrencytypes (row_no, key, data) FROM stdin;
0	0	{"_key": 0, "name": "NOT_USED"}
1	1	{"_key": 1, "name": "GEMs"}
2	2	{"_key": 2, "name": "PLEX"}
3	3	{"_key": 3, "name": "ISK"}
\.


--
-- Name: monetizationrewardcurrencytypes monetizationrewardcurrencytypes_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.monetizationrewardcurrencytypes
    ADD CONSTRAINT monetizationrewardcurrencytypes_pkey PRIMARY KEY (row_no);


--
-- Name: monetizationrewardcurrencytypes_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX monetizationrewardcurrencytypes_key_idx ON sde_native.monetizationrewardcurrencytypes USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict cScmb82X4XW9ahLuUCbus9i6hgZ1E3eT3asABwsk7V8qEqtOYrjSLU4EGMSGu8P

