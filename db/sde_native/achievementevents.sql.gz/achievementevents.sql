--
-- PostgreSQL database dump
--

\restrict KlX8Ct0eoUkFLNricaNMQFFYOtuEpr6Ay6OodIfIpC1w6VQqhaYGB3FRcbruRfO

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: achievementevents; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.achievementevents (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: achievementevents; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.achievementevents (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "name": "destroyHostileNPC", "description": "An enemy NPC ship just got killed", "inputParameters": [5, 15, 1, 2]}
1	2	{"_key": 2, "name": "siteComplete", "description": "A dungeon was completed by the player", "inputParameters": [3]}
2	3	{"_key": 3, "name": "totalMined", "description": "Character just mined X amount of ore", "inputParameters": [7, 4, 5]}
3	4	{"_key": 4, "name": "typeManufacturedCount", "description": "Character completed a manufacturing industry job", "inputParameters": [7, 4, 6]}
4	5	{"_key": 5, "name": "dungeonEntered", "description": "Character just entered a dungeon", "inputParameters": [3, 22]}
5	6	{"_key": 6, "name": "NPCBountyPaid", "description": "Character was paid his bounty for killing NPCs in a given dungeon", "inputParameters": [1, 3]}
6	7	{"_key": 7, "name": "agentCourierMissionCompleted", "description": "Player just completed a courier mission for an agent", "inputParameters": [16, 17]}
7	8	{"_key": 8, "name": "agentDungeonMissionCompleted", "description": "Player just completed an encounter combat mission for an agent", "inputParameters": [16, 17]}
8	9	{"_key": 9, "name": "agentMiningMissionCompleted", "description": "Player just completed a mining mission for an agent", "inputParameters": [16, 17]}
9	10	{"_key": 10, "name": "agentTradeMissionCompleted", "description": "Player just completed a trade mission for an agent", "inputParameters": [16, 17]}
10	11	{"_key": 11, "name": "skillTrainingStarted", "description": "Character started training a skill towards level X", "inputParameters": [7, 20]}
11	15	{"_key": 15, "name": "client_lookAtObject", "description": "Player performed a Look At command in space"}
12	18	{"_key": 18, "name": "client_approach", "description": "Player performed an Approach command in space"}
13	19	{"_key": 19, "name": "shipStopped", "description": "Player performed a Stop Ship command for his ship"}
14	20	{"_key": 20, "name": "dungeonTriggerFired", "description": "Some objective in a dungeon just got completed", "inputParameters": [8]}
15	21	{"_key": 21, "name": "questItemAcquired", "description": "Player just moved a mission item to his cargo hold (see QUEST_ITEM_TYPE_IDS hardcoded list of typeIDs)", "inputParameters": [7, 19]}
16	22	{"_key": 22, "name": "client_lockTarget", "description": "Player performed a Lock Target command", "inputParameters": [7, 9]}
17	23	{"_key": 23, "name": "client_orbit", "description": "Player performed an Orbit command in space", "inputParameters": [7, 9]}
18	24	{"_key": 24, "name": "somethingExplode", "description": "An entity exploded after receiving damage from the player", "inputParameters": [7, 9]}
19	25	{"_key": 25, "name": "moduleActivate", "description": "The player activated one of his ship modules", "inputParameters": [7, 4]}
20	27	{"_key": 27, "name": "marketBoughtType", "description": "Player bought something through the market", "inputParameters": [7]}
21	28	{"_key": 28, "name": "client_windowOpened", "description": "A client window was opened", "inputParameters": [10]}
22	29	{"_key": 29, "name": "client_windowClosed", "description": "A client window was closed", "inputParameters": [10]}
23	33	{"_key": 33, "name": "typeRedeemed", "description": "An item was successfully redeemed from the redeeming queue", "inputParameters": [7, 4]}
24	34	{"_key": 34, "name": "undockFromStation", "description": "Player has successfully undocked from a station"}
25	35	{"_key": 35, "name": "entityGroupDestroyed", "description": "A specific group of enemy NPCs has been cleared in current dungeon", "inputParameters": [12]}
26	36	{"_key": 36, "name": "client_marketOrderPlaced", "description": "Player placed a market  buy order", "inputParameters": [7]}
27	37	{"_key": 37, "name": "itemFlagChanged", "description": "An item was moved to or from players inventory. Only includes items in CATEGORY_IDS_TRACKED_FOR_FLAG_CHANGES", "inputParameters": [7, 6, 13]}
28	38	{"_key": 38, "name": "accelerationGateActivated", "description": "An acceleration gate in a dungeon was activated", "inputParameters": [9]}
29	39	{"_key": 39, "name": "hackingMiniGameWon", "description": "Hacking minigame won"}
30	40	{"_key": 40, "name": "client_inventoryContainerShown", "description": "Player opened up inventory UI for a given inventory location", "inputParameters": [14]}
31	41	{"_key": 41, "name": "skillPointsInjected", "description": "Player successfully injected skill points", "inputParameters": [7]}
32	42	{"_key": 42, "name": "skillPointsApplied", "description": "Player applied skill points to a given skill", "inputParameters": [7]}
33	43	{"_key": 43, "name": "shipLeft", "description": "Player just ejected from is ship and is now in his capsule", "inputParameters": [7, 4]}
34	44	{"_key": 44, "name": "shipAssembled", "description": "Player assembled a ship (double click unassembled ship in inventory)", "inputParameters": [7, 4]}
35	45	{"_key": 45, "name": "shipBoarded", "description": "Player boarded a ship", "inputParameters": [7, 4]}
36	46	{"_key": 46, "name": "shipRepackaged", "description": "Player repackaged a ship that had been assembled", "inputParameters": [7, 4]}
37	47	{"_key": 47, "name": "consciousnessTransferred", "description": "Character performed a clone jump"}
38	49	{"_key": 49, "name": "inceptionWarped", "description": "Player warped to an Operation dungeon", "inputParameters": [18]}
39	50	{"_key": 50, "name": "client_operationDestinationSet", "description": "Player clicked \\"Set destination\\" button in Operations Info Panel for active operation", "inputParameters": [18]}
40	56	{"_key": 56, "name": "accelerationGateWarpExited", "description": "Player arrived in new dungeon pocket after Acceleration Gate jump", "inputParameters": [9]}
41	58	{"_key": 58, "name": "skillTrainingFinished", "description": "Player finished training skill to level X", "inputParameters": [7, 20]}
42	59	{"_key": 59, "name": "industryManufacturingJobDeliveredCount", "description": "Industry manufacturing job delivered successfully", "inputParameters": [11]}
43	60	{"_key": 60, "name": "client_crateOpened", "description": "Player opened up a crate", "inputParameters": [7]}
44	61	{"_key": 61, "name": "client_skillPrioritized", "description": "Player moved skill to top of training queue", "inputParameters": [7]}
45	64	{"_key": 64, "name": "client_skillAddedToQueue", "description": "Player added a skill of level x to the skill queue", "inputParameters": [7, 20]}
46	65	{"_key": 65, "name": "client_agencyContentExpanded", "description": "Player opened up a specific page of the Agency window", "inputParameters": [21, 23]}
47	66	{"_key": 66, "name": "client_endInceptionNavigation", "description": "DEPRICATED"}
48	67	{"_key": 67, "name": "client_selectSpaceBracket", "description": "Player clicked an in-space bracket ", "inputParameters": [7, 9]}
49	70	{"_key": 70, "name": "client_itemMovedTo", "description": "Player moved an item to a new inventory location. 'inventoryController' must match the name of corresponding invCtrl class.", "inputParameters": [7, 26]}
50	71	{"_key": 71, "name": "client_enterAsteroidBelt", "description": "Player warped to an asteroid belt"}
51	72	{"_key": 72, "name": "reprocessingInput", "description": "Player successfully reprocessed an item", "inputParameters": [7, 4]}
52	73	{"_key": 73, "name": "reprocessingOutput", "description": "Player yielded minerals from reprocessing an item", "inputParameters": [7, 4]}
53	74	{"_key": 74, "name": "stargateJumps", "description": "Player entered a new solar system after jumping through stargate"}
54	75	{"_key": 75, "name": "client_windowOpenedWithNameLike", "description": "Player opened a window that partially matches given windowID", "inputParameters": [10]}
55	76	{"_key": 76, "name": "client_careerAgentSystemEntered", "description": "Player entered a system that has Career Agents in it"}
56	77	{"_key": 77, "name": "client_shipDogmaAttributeChanged", "description": "A dogma attribute on active ship just changed, most likely due to a module being fitted or unfitted", "inputParameters": [24, 25]}
57	78	{"_key": 78, "name": "client_twoTurretsFreed", "description": "Player unfitted a high slot module so that there are now two slots empty"}
58	79	{"_key": 79, "name": "client_claimRewardsBtnClick", "description": "Player clicked the \\"Claim rewards\\" button under to Tutorial section of the Agency"}
59	80	{"_key": 80, "name": "client_jumpToNextSystemInRouteExecuted", "description": "Player jumped through a Stargate to a new system that is the next one in current autopilot route"}
60	81	{"_key": 81, "name": "client_dockInStationExecuted", "description": "Player executed a \\"Dock\\" command (may still have to warp or approach before actually docking)"}
61	82	{"_key": 82, "name": "client_operationSiteWarpToExecuted", "description": "Player executed a 'Warp To' command for an Operation dungeon site", "inputParameters": [18]}
62	83	{"_key": 83, "name": "client_openCargoExecuted", "description": "Player executed an \\"Open Cargo\\" command to approach and loot a wreck", "inputParameters": [7, 9]}
63	84	{"_key": 84, "name": "noncompletable", "description": "A task that cannot be completed by the player"}
64	86	{"_key": 86, "name": "timesMined", "description": "Player successfully completed a mining cycle"}
65	87	{"_key": 87, "name": "totalMinedSpecific", "description": "DEPRICATED"}
66	88	{"_key": 88, "name": "timesMinedSpecific", "description": "DEPRICATED"}
67	90	{"_key": 90, "name": "dockInStation", "description": "Player successfully docked in a station"}
68	92	{"_key": 92, "name": "agentStartCount", "description": "Player started a conversation with an agent", "inputParameters": [16, 17]}
69	93	{"_key": 93, "name": "agentMissionCompletedCount", "description": "Agent mission successfully completed", "inputParameters": [16, 17]}
70	94	{"_key": 94, "name": "agentMissionRequestedCount", "description": "Agent mission requested", "inputParameters": [16, 17]}
71	95	{"_key": 95, "name": "timesWarped", "description": "Player entered warp"}
72	96	{"_key": 96, "name": "buyCount", "description": "Player entered a market buy order"}
73	97	{"_key": 97, "name": "sellCount", "description": "Player entered a market sell order"}
74	99	{"_key": 99, "name": "agentAcceptCount", "description": "Agent mission accepted", "inputParameters": [16, 17]}
75	100	{"_key": 100, "name": "privateConvoCount", "description": "DEPRICATED"}
76	101	{"_key": 101, "name": "joinCorpCount", "description": "Player joined or created a player corporation"}
77	102	{"_key": 102, "name": "shipLossCount", "description": "Player had his ship destroyed (not pod)"}
78	103	{"_key": 103, "name": "podLossCount", "description": "Player had his pod destroyed"}
79	104	{"_key": 104, "name": "industryManufacturingJobStartedCount", "description": "Player started an industry manufacturing job", "inputParameters": [11]}
80	105	{"_key": 105, "name": "doubleClickInSpaceCount", "description": "DEPRICATED"}
81	106	{"_key": 106, "name": "fitItemCount", "description": "bla"}
82	107	{"_key": 107, "name": "refineOreCount", "description": "Player reprocessed/refined some ore "}
83	108	{"_key": 108, "name": "visitCosmicAnomalyCount", "description": "DEPRICATED"}
84	110	{"_key": 110, "name": "client_doubleClickInSpace", "description": "Player set ship direction by double clicking in space"}
85	112	{"_key": 112, "name": "client_orbitHostileNPC", "description": "Player executed an \\"Orbit\\" command on a hostile NPC (based on standings)"}
86	113	{"_key": 113, "name": "client_lockHostileNPC", "description": "Player completed target locking a hostile NPC (based on standings)"}
87	115	{"_key": 115, "name": "client_activateGun", "description": "A player activated a gun module (dogma events: effectProjectileFired or const.effectTargetAttack)"}
88	116	{"_key": 116, "name": "client_lootItems", "description": "Player moved an item away from a \\"fake location\\", which is typically a wreck"}
89	117	{"_key": 117, "name": "client_moveItemFromCargoToHangar", "description": "Player moved an item from ship cargo to item hangar"}
90	118	{"_key": 118, "name": "client_orbitAsteroid", "description": "Player executed an \\"Orbit\\" command on an asteroid"}
91	119	{"_key": 119, "name": "client_lockAsteroid", "description": "Player successfully target locked an asteroid"}
92	120	{"_key": 120, "name": "activateMiningLaser", "description": "Player just started a mining cycle on an asteroid"}
93	122	{"_key": 122, "name": "skillInjected", "description": "Player injected a new skill"}
94	123	{"_key": 123, "name": "client_openMap", "description": "Player just opened up the world map"}
95	124	{"_key": 124, "name": "client_mouseZoom_out", "description": "Player zoomed the camera out"}
96	125	{"_key": 125, "name": "client_activateSalvager", "description": "Player activated a salvager module (dogmaEffect: effectSalvaging)"}
97	126	{"_key": 126, "name": "client_chatMessageSent", "description": "Player sent a chat message on some chat channel"}
98	127	{"_key": 127, "name": "client_setDestination", "description": "Player executed a \\"Set destination\\" command to somewhere"}
99	128	{"_key": 128, "name": "client_activateAutopilot", "description": "Player activated autopilot"}
100	129	{"_key": 129, "name": "client_jumpToNextSystemInRoute", "description": "Player successfully activated a jump gate which leads to next system in autopilot route"}
101	130	{"_key": 130, "name": "client_unfitItem", "description": "Player just unfitted a module", "inputParameters": [7]}
102	131	{"_key": 131, "name": "inviteToConvoCount", "description": "DEPRICATED"}
103	132	{"_key": 132, "name": "mailSentCount", "description": "Player just sent an EVE mail"}
104	133	{"_key": 133, "name": "finishedReprocessingCount", "description": "Player successfully completed a refine or reprocess job"}
105	134	{"_key": 134, "name": "loadChargesCount", "description": "Player successfully loaded charges to a module", "inputParameters": [7]}
106	135	{"_key": 135, "name": "fitHiSlotCount", "description": "Player fitted a module to a high slot"}
107	136	{"_key": 136, "name": "fitMedSlotCount", "description": "Player fitted a module to a med slot"}
108	137	{"_key": 137, "name": "fitLoSlotCount", "description": "Player fitted a module to a low slot"}
109	138	{"_key": 138, "name": "client_mouseZoom_in", "description": "Player zoomed the camera in"}
110	139	{"_key": 139, "name": "client_spinCamera", "description": "Player span the camera around his ship by left dragging the mouse"}
111	140	{"_key": 140, "name": "contactAdded", "description": "Player added another player to his People & Places contacts"}
112	142	{"_key": 142, "name": "client_lookAtOwnShip", "description": "Player performed a \\"Look At\\" command on his own ship to reset the camera"}
113	145	{"_key": 145, "name": "successfulSalvageCount", "description": "Player successfully completed a salvaging module cycle"}
114	146	{"_key": 146, "name": "distributionSiteEnteredCount", "description": "Player just warped to a dungeon site that was via a distribution (combat/mining anomalies or scannable sites for example)"}
115	147	{"_key": 147, "name": "client_openCorpFinder", "description": "Player opened the Corp Finder page of the Corporation window"}
116	148	{"_key": 148, "name": "client_loadBlueprint", "description": "Player loaded a blueprint into the Industry window"}
117	149	{"_key": 149, "name": "client_launchProbes", "description": "Player launched a scanning probe from a probe launcher"}
118	150	{"_key": 150, "name": "client_reachPerfectScanResult", "description": "Player successfully scanned down a site, meaning he can warp to it"}
119	151	{"_key": 151, "name": "fitProbeLauncher", "description": "Player fitted a probe launcher to his ship"}
120	152	{"_key": 152, "name": "enterWormhole", "description": "Player activated a wormhole and is about to jump through"}
121	153	{"_key": 153, "name": "client_bookmarkWormhole", "description": "Player just added a bookmark for a wormhole"}
122	154	{"_key": 154, "name": "client_openAgency", "description": "DEPRICATED"}
123	159	{"_key": 159, "name": "client_setDestinationToCareerAgents", "description": "Player set destination to nearest career agent station. This event will cause a \\"Set Destination\\" button to appear in info panel."}
124	161	{"_key": 161, "name": "client_taskContinueButtonPressed", "description": "The \\"Continue\\" button of the task conversation window was pressed."}
125	162	{"_key": 162, "name": "client_windowClosedOrMinimized", "description": "A player closed or minimized a UI window", "inputParameters": [10]}
126	163	{"_key": 163, "name": "client_agencyContentGroupExpanded", "description": "Player opened up a specific content group page of the Agency window", "inputParameters": [27]}
127	166	{"_key": 166, "name": "client_operationProgression", "description": "Operation progression event from the client", "inputParameters": [28]}
128	189	{"_key": 189, "name": "groupRewardGranted", "description": "Player recieved a group reward", "inputParameters": [3]}
129	190	{"_key": 190, "name": "facWarDungeonRewardGranted", "description": "Player recieved LP from a Factional Warfare site", "inputParameters": [2, 3]}
130	191	{"_key": 191, "name": "volumeMined", "description": "Player mined X volume of ore"}
\.


--
-- Name: achievementevents achievementevents_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.achievementevents
    ADD CONSTRAINT achievementevents_pkey PRIMARY KEY (row_no);


--
-- Name: achievementevents_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX achievementevents_key_idx ON sde_native.achievementevents USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict KlX8Ct0eoUkFLNricaNMQFFYOtuEpr6Ay6OodIfIpC1w6VQqhaYGB3FRcbruRfO

