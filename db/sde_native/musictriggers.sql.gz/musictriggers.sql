--
-- PostgreSQL database dump
--

\restrict ZPxUUVOnTKlJr1rw9S4QIGSbfRnU3aesgoQU9MC3TSOxM74GoMXVcJTBIgbTrrx

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: musictriggers; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.musictriggers (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: musictriggers; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.musictriggers (row_no, key, data) FROM stdin;
0	4	{"_key": 4, "trigger": "tutorial_music_1_01_aura_3792_01", "category": "tutorial"}
1	5	{"_key": 5, "trigger": "tutorial_music_1_02_aura_3792_03", "category": "tutorial"}
2	6	{"_key": 6, "trigger": "tutorial_music_1_03_aura_3795", "category": "tutorial"}
3	7	{"_key": 7, "trigger": "tutorial_music_1_04_aura_3798", "category": "tutorial"}
4	8	{"_key": 8, "trigger": "tutorial_music_1_05_warp_1st", "category": "tutorial"}
5	9	{"_key": 9, "trigger": "tutorial_music_1_06_arrival_site_1", "category": "tutorial"}
6	10	{"_key": 10, "trigger": "tutorial_music_1_07_aura_3716", "category": "tutorial"}
7	11	{"_key": 11, "trigger": "tutorial_music_1_08_lock_target", "category": "tutorial"}
8	12	{"_key": 12, "trigger": "tutorial_music_1_09_aura_3717", "category": "tutorial"}
9	13	{"_key": 13, "trigger": "tutorial_music_1_10_fire", "category": "tutorial"}
10	14	{"_key": 14, "trigger": "tutorial_music_1_11_target_explodes", "category": "tutorial"}
11	15	{"_key": 15, "trigger": "tutorial_music_1_12_aura_3705_2", "category": "tutorial"}
12	16	{"_key": 16, "trigger": "tutorial_music_1_13_warp_to_station", "category": "tutorial"}
13	17	{"_key": 17, "trigger": "tutorial_music_1_14_arrival_station_1", "category": "tutorial"}
14	18	{"_key": 18, "trigger": "tutorial_music_1_15_enter_hangar", "category": "tutorial"}
15	21	{"_key": 21, "trigger": "tutorial_music_2_01_exit_station_1", "category": "tutorial"}
16	23	{"_key": 23, "trigger": "tutorial_music_2_02_warp", "category": "tutorial"}
17	24	{"_key": 24, "trigger": "tutorial_music_2_03_arrival_site_2", "category": "tutorial"}
18	25	{"_key": 25, "trigger": "tutorial_music_2_04_lock_target", "category": "tutorial"}
19	26	{"_key": 26, "trigger": "tutorial_music_2_05_fire", "category": "tutorial"}
20	27	{"_key": 27, "trigger": "tutorial_music_2_06_target_explodes", "category": "tutorial"}
21	28	{"_key": 28, "trigger": "tutorial_music_2_07_aura_3742", "category": "tutorial"}
22	29	{"_key": 29, "trigger": "tutorial_music_3_01_accept_mission", "category": "tutorial"}
23	30	{"_key": 30, "trigger": "tutorial_music_3_02_aura_3745_02", "category": "tutorial"}
24	31	{"_key": 31, "trigger": "tutorial_music_3_03_warp", "category": "tutorial"}
25	32	{"_key": 32, "trigger": "tutorial_music_3_04_arrival_site_3", "category": "tutorial"}
26	33	{"_key": 33, "trigger": "tutorial_music_3_05_lock_target", "category": "tutorial"}
27	34	{"_key": 34, "trigger": "tutorial_music_3_06_fire", "category": "tutorial"}
28	35	{"_key": 35, "trigger": "tutorial_music_3_07_target_explodes", "category": "tutorial"}
29	36	{"_key": 36, "trigger": "tutorial_music_3_08_lock_target", "category": "tutorial"}
30	37	{"_key": 37, "trigger": "tutorial_music_3_09_fire", "category": "tutorial"}
31	38	{"_key": 38, "trigger": "tutorial_music_3_10_aura_3751", "category": "tutorial"}
32	39	{"_key": 39, "trigger": "tutorial_music_3_11_aura_3752_1", "category": "tutorial"}
33	40	{"_key": 40, "trigger": "tutorial_music_4_01_warp", "category": "tutorial"}
34	41	{"_key": 41, "trigger": "tutorial_music_4_02_arrival_site_4", "category": "tutorial"}
35	42	{"_key": 42, "trigger": "tutorial_music_4_03_lock_target", "category": "tutorial"}
36	43	{"_key": 43, "trigger": "tutorial_music_4_04_fire", "category": "tutorial"}
37	44	{"_key": 44, "trigger": "tutorial_music_4_05_target_explodes_1", "category": "tutorial"}
38	45	{"_key": 45, "trigger": "tutorial_music_4_06_fire", "category": "tutorial"}
39	46	{"_key": 46, "trigger": "tutorial_music_4_07_target_explodes_2", "category": "tutorial"}
40	47	{"_key": 47, "trigger": "tutorial_music_4_08_aura_3759", "category": "tutorial"}
41	48	{"_key": 48, "trigger": "tutorial_music_5_01_warp", "category": "tutorial"}
42	49	{"_key": 49, "trigger": "tutorial_music_5_02_arrival_site_5", "category": "tutorial"}
43	50	{"_key": 50, "trigger": "tutorial_music_5_03_lock_target", "category": "tutorial"}
44	51	{"_key": 51, "trigger": "tutorial_music_5_04_fire", "category": "tutorial"}
45	52	{"_key": 52, "trigger": "tutorial_music_5_05_aura_3765", "category": "tutorial"}
46	53	{"_key": 53, "trigger": "tutorial_music_5_06_target_explodes", "category": "tutorial"}
47	54	{"_key": 54, "trigger": "tutorial_music_5_07_warp", "category": "tutorial"}
48	55	{"_key": 55, "trigger": "tutorial_music_5_08_arrival_station_2", "category": "tutorial"}
49	56	{"_key": 56, "trigger": "tutorial_music_7_01_exit_station_2", "category": "tutorial"}
50	57	{"_key": 57, "trigger": "tutorial_music_7_02_warp", "category": "tutorial"}
51	58	{"_key": 58, "trigger": "tutorial_music_7_03_arrival_site_6", "category": "tutorial"}
52	59	{"_key": 59, "trigger": "tutorial_music_7_04_lock_target", "category": "tutorial"}
53	60	{"_key": 60, "trigger": "tutorial_music_7_05_fireorhit", "category": "tutorial"}
54	61	{"_key": 61, "trigger": "tutorial_music_7_06_aura_3825", "category": "tutorial"}
55	62	{"_key": 62, "trigger": "tutorial_music_7_07_3rd_target_explodes", "category": "tutorial"}
56	63	{"_key": 63, "trigger": "tutorial_music_7_08_aura_3777", "category": "tutorial"}
57	64	{"_key": 64, "trigger": "tutorial_music_7_09_aura_3778_01", "category": "tutorial"}
58	65	{"_key": 65, "trigger": "tutorial_music_7_10_aura_3778_02", "category": "tutorial"}
59	66	{"_key": 66, "trigger": "tutorial_music_8_01_safe_in_space", "category": "tutorial"}
60	67	{"_key": 67, "trigger": "tutorial_music_8_02_arrival_stargate_1", "category": "tutorial"}
61	68	{"_key": 68, "trigger": "tutorial_music_8_03_arrival_stargate_2", "category": "tutorial"}
62	69	{"_key": 69, "trigger": "tutorial_music_8_04_aura_3786", "category": "tutorial"}
63	70	{"_key": 70, "trigger": "tutorial_music_8_05_arrival_stargate_3", "category": "tutorial"}
64	71	{"_key": 71, "trigger": "tutorial_music_8_06_arrival_stargate_4", "category": "tutorial"}
65	72	{"_key": 72, "trigger": "tutorial_music_8_07_jump_to_stargate_5_urien", "category": "tutorial"}
66	73	{"_key": 73, "trigger": "tutorial_music_8_08_arrival_stargate_5", "category": "tutorial"}
67	74	{"_key": 74, "trigger": "tutorial_music_8_09_arrival_stargate_6", "category": "tutorial"}
68	75	{"_key": 75, "trigger": "tutorial_music_8_10_arrival_stargate_7", "category": "tutorial"}
69	76	{"_key": 76, "trigger": "tutorial_music_8_11_aura_3787", "category": "tutorial"}
70	77	{"_key": 77, "trigger": "tutorial_music_8_12_warp_final", "category": "tutorial"}
71	78	{"_key": 78, "trigger": "tutorial_music_8_13_station_3", "category": "tutorial"}
72	80	{"_key": 80, "trigger": "tutorial_music_3_12_aura_3752_2", "category": "tutorial"}
73	81	{"_key": 81, "trigger": "tutorial_music_3_13_aura_3754", "category": "tutorial"}
74	82	{"_key": 82, "trigger": "tutorial_music_8_00_safe_in_space", "category": "tutorial"}
75	87	{"_key": 87, "trigger": "capital_caper_9062_1", "category": "dungeon"}
76	88	{"_key": 88, "trigger": "capital_caper_9062_2", "category": "dungeon"}
77	89	{"_key": 89, "trigger": "capital_caper_9062_3", "category": "dungeon"}
78	90	{"_key": 90, "trigger": "capital_caper_9062_4", "category": "dungeon"}
79	91	{"_key": 91, "trigger": "capital_caper_9062_5", "category": "dungeon"}
80	92	{"_key": 92, "trigger": "npe_music_01_02_aura_2755", "category": "tutorial"}
81	93	{"_key": 93, "trigger": "npe_music_01_03_board", "category": "tutorial"}
82	94	{"_key": 94, "trigger": "npe_music_01_04_aura_2794", "category": "tutorial"}
83	95	{"_key": 95, "trigger": "npe_music_01_06_balin_2859", "category": "tutorial"}
84	96	{"_key": 96, "trigger": "npe_music_01_07_warp", "category": "tutorial"}
85	97	{"_key": 97, "trigger": "npe_music_02_01_arrival", "category": "tutorial"}
86	98	{"_key": 98, "trigger": "npe_music_02_02_balin_2783", "category": "tutorial"}
87	99	{"_key": 99, "trigger": "npe_music_02_03_lock", "category": "tutorial"}
88	100	{"_key": 100, "trigger": "npe_music_02_04_fire", "category": "tutorial"}
89	101	{"_key": 101, "trigger": "npe_music_02_05_explode", "category": "tutorial"}
90	103	{"_key": 103, "trigger": "npe_music_01_05_balin_2793", "category": "tutorial"}
91	105	{"_key": 105, "trigger": "npe_music_02_09_balin_2775", "category": "tutorial"}
92	106	{"_key": 106, "trigger": "npe_music_02_10_lock", "category": "tutorial"}
93	107	{"_key": 107, "trigger": "npe_music_02_12_ecm", "category": "tutorial"}
94	108	{"_key": 108, "trigger": "npe_music_02_16_aura_2781", "category": "tutorial"}
95	109	{"_key": 109, "trigger": "npe_music_02_06_lock", "category": "tutorial"}
96	110	{"_key": 110, "trigger": "npe_music_02_07_fire", "category": "tutorial"}
97	111	{"_key": 111, "trigger": "npe_music_02_08_explode", "category": "tutorial"}
98	112	{"_key": 112, "trigger": "npe_music_01_01_opening", "category": "tutorial"}
99	113	{"_key": 113, "trigger": "npe_music_01_01_2_aura_2867", "category": "tutorial"}
100	114	{"_key": 114, "trigger": "npe_music_02_02_2_balin_2865", "category": "tutorial"}
101	115	{"_key": 115, "trigger": "npe_music_02_02_3_aura_2762", "category": "tutorial"}
102	116	{"_key": 116, "trigger": "npe_music_02_05_2_aura_2772", "category": "tutorial"}
103	117	{"_key": 117, "trigger": "npe_music_02_09_2_aura_2775", "category": "tutorial"}
104	118	{"_key": 118, "trigger": "npe_music_04_01_hangar", "category": "tutorial"}
105	119	{"_key": 119, "trigger": "npe_music_04_02_aura_2815", "category": "tutorial"}
106	120	{"_key": 120, "trigger": "npe_music_04_03_vesper_2833", "category": "tutorial"}
107	121	{"_key": 121, "trigger": "npe_music_04_04_inject", "category": "tutorial"}
108	122	{"_key": 122, "trigger": "npe_music_04_05_aura_2837", "category": "tutorial"}
109	123	{"_key": 123, "trigger": "npe_music_04_06_aura_2880", "category": "tutorial"}
110	124	{"_key": 124, "trigger": "npe_music_02_02_balin_2753", "category": "tutorial"}
111	128	{"_key": 128, "trigger": "npe_music_04_07_vesper_2837", "category": "tutorial"}
112	129	{"_key": 129, "trigger": "npe_music_04_08_aura_2909", "category": "tutorial"}
113	130	{"_key": 130, "trigger": "npe_music_05_01_exit_station_1", "category": "tutorial"}
114	131	{"_key": 131, "trigger": "npe_music_05_02_warp", "category": "tutorial"}
115	132	{"_key": 132, "trigger": "npe_music_05_03_arrival_stargate_1", "category": "tutorial"}
116	133	{"_key": 133, "trigger": "npe_music_05_04_arrival_stargate_2", "category": "tutorial"}
117	134	{"_key": 134, "trigger": "npe_music_05_05_arrival_stargate_3", "category": "tutorial"}
118	135	{"_key": 135, "trigger": "npe_music_05_06_aura_2889", "category": "tutorial"}
119	137	{"_key": 137, "trigger": "npe_music_05_07_warp", "category": "tutorial"}
120	138	{"_key": 138, "trigger": "npe_music_05_08_arrival_station_2", "category": "tutorial"}
121	139	{"_key": 139, "trigger": "npe_music_06_01_hangar", "category": "tutorial"}
122	140	{"_key": 140, "trigger": "npe_music_06_02_aura_2893", "category": "tutorial"}
123	141	{"_key": 141, "trigger": "npe_music_02_13_balin_2778", "category": "tutorial"}
124	142	{"_key": 142, "trigger": "npe_music_02_11_aura_2777", "category": "tutorial"}
125	143	{"_key": 143, "trigger": "npe_music_02_14_aura_2779", "category": "tutorial"}
126	144	{"_key": 144, "trigger": "npe_music_02_15_balin_2780", "category": "tutorial"}
127	145	{"_key": 145, "trigger": "npe_music_02_17_aura_2782", "category": "tutorial"}
128	146	{"_key": 146, "trigger": "npe_music_03_01_death", "category": "tutorial"}
129	147	{"_key": 147, "trigger": "npe_music_02_02_balin_2783_2", "category": "tutorial"}
130	148	{"_key": 148, "trigger": "npe_music_02_02_aura_2864", "category": "tutorial"}
131	149	{"_key": 149, "trigger": "npe_02_05_aura_2769", "category": "tutorial"}
132	150	{"_key": 150, "trigger": "npe_music_02_18_shipdeath", "category": "tutorial"}
133	151	{"_key": 151, "trigger": "npe_music_scene04_01_01_exit_station", "category": "tutorial"}
134	152	{"_key": 152, "trigger": "npe_music_scene04_01_02_warp", "category": "tutorial"}
135	153	{"_key": 153, "trigger": "npe_music_scene04_01_03_arrival", "category": "tutorial"}
136	154	{"_key": 154, "trigger": "npe_music_scene04_02_01_02_mine", "category": "tutorial"}
137	155	{"_key": 155, "trigger": "npe_music_scene04_03_01_conv_wreck_discovery", "category": "tutorial"}
138	156	{"_key": 156, "trigger": "npe_music_scene04_04_01_wreck_approach", "category": "tutorial"}
139	157	{"_key": 157, "trigger": "npe_music_scene04_03_03_loot", "category": "tutorial"}
140	158	{"_key": 158, "trigger": "npe_music_scene04_06_01_conv_hurry", "category": "tutorial"}
141	159	{"_key": 159, "trigger": "npe_music_scene04_07_01_warp", "category": "tutorial"}
142	160	{"_key": 160, "trigger": "npe_music_scene04_04_03_arrive_station", "category": "tutorial"}
143	161	{"_key": 161, "trigger": "npe_music_scene04_04_04_dock", "category": "tutorial"}
144	162	{"_key": 162, "trigger": "npe_music_scene04_01_04_camera_site", "category": "tutorial"}
145	163	{"_key": 163, "trigger": "npe_music_scene04_01_05_camera_elias", "category": "tutorial"}
146	164	{"_key": 164, "trigger": "npe_music_scene04_02_01_00_approach", "category": "tutorial"}
147	165	{"_key": 165, "trigger": "npe_music_scene04_01_06_camera_flyover", "category": "tutorial"}
148	166	{"_key": 166, "trigger": "npe_music_scene04_02_01_01_lock", "category": "tutorial"}
149	167	{"_key": 167, "trigger": "npe_music_scene04_02_01_04_depletion", "category": "tutorial"}
150	168	{"_key": 168, "trigger": "npe_music_scene04_02_02_01_lock", "category": "tutorial"}
151	169	{"_key": 169, "trigger": "npe_music_scene04_02_03_04_camera_wreck", "category": "tutorial"}
152	170	{"_key": 170, "trigger": "npe_music_scene04_02_02_02_mine", "category": "tutorial"}
153	171	{"_key": 171, "trigger": "npe_music_scene04_02_02_03_depletion", "category": "tutorial"}
154	172	{"_key": 172, "trigger": "npe_music_scene04_02_01_03_fruit", "category": "tutorial"}
155	173	{"_key": 173, "trigger": "npe_music_scene04_02_03_00_approach", "category": "tutorial"}
156	174	{"_key": 174, "trigger": "npe_music_scene04_02_03_01_lock", "category": "tutorial"}
157	175	{"_key": 175, "trigger": "npe_music_scene04_02_03_02_mine", "category": "tutorial"}
158	176	{"_key": 176, "trigger": "npe_music_scene04_02_03_03_depletion", "category": "tutorial"}
159	177	{"_key": 177, "trigger": "npe_music_scene04_03_02_wreck_approach", "category": "tutorial"}
160	178	{"_key": 178, "trigger": "npe_music_scene04_04_00_conv_significance", "category": "tutorial"}
161	179	{"_key": 179, "trigger": "npe_music_scene04_04_01_conv_align", "category": "tutorial"}
162	180	{"_key": 180, "trigger": "npe_music_scene04_04_02_fleetwarp", "category": "tutorial"}
163	181	{"_key": 181, "trigger": "music_dungeon_who_start", "category": "dungeon"}
164	182	{"_key": 182, "trigger": "npe_music_scene04_03_03_open_cargo", "category": "tutorial"}
165	183	{"_key": 183, "trigger": "npe_music_scene04_03_04_loot", "category": "tutorial"}
166	184	{"_key": 184, "trigger": "npe_music_scene04_02_02_00_orbit", "category": "tutorial"}
167	185	{"_key": 185, "trigger": "npe_music_scene04_01_04_conv_elias", "category": "tutorial"}
168	186	{"_key": 186, "trigger": "npe_music_scene04_01_06_camera_venture", "category": "tutorial"}
169	187	{"_key": 187, "trigger": "npe_music_scene04_01_03_02_camera_site", "category": "tutorial"}
170	188	{"_key": 188, "trigger": "npe_music_scene03_04_03_board", "category": "tutorial"}
171	189	{"_key": 189, "trigger": "npe_music_scene03_04_02_preboard", "category": "tutorial"}
172	190	{"_key": 190, "trigger": "gurista_special_music_room1_tr1_enter_play", "category": "dungeon"}
173	191	{"_key": 191, "trigger": "gurista_special_music_room1_tr2_boss_play", "category": "dungeon"}
174	192	{"_key": 192, "trigger": "gurista_special_music_room1_tr3_boss_death_play", "category": "dungeon"}
175	193	{"_key": 193, "trigger": "gurista_special_music_room2_tr4_enter_play", "category": "dungeon"}
176	194	{"_key": 194, "trigger": "gurista_special_music_room2_tr5_boss_death_play", "category": "dungeon"}
177	195	{"_key": 195, "trigger": "dungeon_music_capsuleerday_standard_arrival", "category": "dungeon"}
178	196	{"_key": 196, "trigger": "dungeon_music_capsuleerday_boss_room", "category": "dungeon"}
179	197	{"_key": 197, "trigger": "dungeon_music_capsuleerday_boss_combat", "category": "dungeon"}
180	198	{"_key": 198, "trigger": "dungeon_music_capsuleerday_hacking_room", "category": "dungeon"}
181	199	{"_key": 199, "trigger": "dungeon_music_capsuleerday_end", "category": "dungeon"}
182	201	{"_key": 201, "trigger": "dungeon_music_capsuleerday_advanced_room", "category": "dungeon"}
183	202	{"_key": 202, "trigger": "dungeon_music_liberationday_enter", "category": "dungeon"}
184	203	{"_key": 203, "trigger": "dungeon_music_liberationday_boss", "category": "dungeon"}
185	205	{"_key": 205, "trigger": "dungeon_music_liberationday_end", "category": "dungeon"}
186	206	{"_key": 206, "trigger": "dungeon_music_enforcer_missions_2096", "category": "dungeon"}
187	207	{"_key": 207, "trigger": "dungeon_music_enforcer_missions_2108", "category": "dungeon"}
188	208	{"_key": 208, "trigger": "dungeon_music_enforcer_missions_2064", "category": "dungeon"}
189	209	{"_key": 209, "trigger": "dungeon_music_enforcer_missions_2088", "category": "dungeon"}
190	210	{"_key": 210, "trigger": "dungeon_music_enforcer_missions_2093", "category": "dungeon"}
191	212	{"_key": 212, "trigger": "dungeon_music_enforcer_missions_2102", "category": "dungeon"}
192	213	{"_key": 213, "trigger": "dungeon_music_enforcer_missions_2051", "category": "dungeon"}
193	214	{"_key": 214, "trigger": "dungeon_music_enforcer_missions_amarr_play", "category": "dungeon"}
194	215	{"_key": 215, "trigger": "dungeon_music_enforcer_missions_caldari_play", "category": "dungeon"}
195	216	{"_key": 216, "trigger": "dungeon_music_enforcer_missions_gallente_play", "category": "dungeon"}
196	217	{"_key": 217, "trigger": "dungeon_music_enforcer_missions_minmatar_play", "category": "dungeon"}
197	218	{"_key": 218, "trigger": "dungeon_music_enforcer_missions_generic_play", "category": "dungeon"}
198	219	{"_key": 219, "trigger": "dungeon_music_unionday_hacking_enter", "category": "dungeon"}
199	220	{"_key": 220, "trigger": "dungeon_music_unionday_hacking_1min_left", "category": "dungeon"}
200	221	{"_key": 221, "trigger": "dungeon_music_unionday_combat_1_room_1_enter", "category": "dungeon"}
201	222	{"_key": 222, "trigger": "dungeon_music_unionday_combat_1_room_1_miniboss", "category": "dungeon"}
202	223	{"_key": 223, "trigger": "dungeon_music_unionday_combat_1_room_1_miniboss_defeat", "category": "dungeon"}
203	224	{"_key": 224, "trigger": "dungeon_music_unionday_combat_1_room_2_enter", "category": "dungeon"}
204	225	{"_key": 225, "trigger": "dungeon_music_unionday_combat_1_room_2_boss_defeat", "category": "dungeon"}
205	226	{"_key": 226, "trigger": "dungeon_music_unionday_combat_2_room_1_enter", "category": "dungeon"}
206	227	{"_key": 227, "trigger": "dungeon_music_unionday_combat_2_room_2_boss", "category": "dungeon"}
207	228	{"_key": 228, "trigger": "dungeon_music_unionday_combat_2_room_2_boss_defeat", "category": "dungeon"}
208	229	{"_key": 229, "trigger": "dungeon_music_unionday_combat_2_room_2_enter", "category": "dungeon"}
209	230	{"_key": 230, "trigger": "dungeon_music_battlefield_enter", "category": "dungeon"}
210	231	{"_key": 231, "trigger": "dungeon_music_battlefield_neutral", "category": "dungeon"}
211	232	{"_key": 232, "trigger": "dungeon_music_battlefield_amarr", "category": "dungeon"}
212	233	{"_key": 233, "trigger": "dungeon_music_battlefield_amarr_winning", "category": "dungeon"}
213	234	{"_key": 234, "trigger": "dungeon_music_battlefield_amarr_won", "category": "dungeon"}
214	235	{"_key": 235, "trigger": "dungeon_music_battlefield_caldari", "category": "dungeon"}
215	236	{"_key": 236, "trigger": "dungeon_music_battlefield_caldari_winning", "category": "dungeon"}
216	237	{"_key": 237, "trigger": "dungeon_music_battlefield_caldari_won", "category": "dungeon"}
217	238	{"_key": 238, "trigger": "dungeon_music_battlefield_gallente", "category": "dungeon"}
218	239	{"_key": 239, "trigger": "dungeon_music_battlefield_gallente_winning", "category": "dungeon"}
219	240	{"_key": 240, "trigger": "dungeon_music_battlefield_gallente_won", "category": "dungeon"}
220	241	{"_key": 241, "trigger": "dungeon_music_battlefield_minmatar", "category": "dungeon"}
221	242	{"_key": 242, "trigger": "dungeon_music_battlefield_minmatar_winning", "category": "dungeon"}
222	243	{"_key": 243, "trigger": "dungeon_music_battlefield_minmatar_won", "category": "dungeon"}
223	245	{"_key": 245, "trigger": "dungeon_music_minibattlefield", "category": "dungeon"}
224	246	{"_key": 246, "trigger": "dungeon_music_winter_nexus_combat", "category": "dungeon"}
225	247	{"_key": 247, "trigger": "dungeon_music_winter_nexus_hacking", "category": "dungeon"}
226	248	{"_key": 248, "trigger": "dungeon_music_winter_nexus_mining", "category": "dungeon"}
227	253	{"_key": 253, "trigger": "music_hq_amarr_play", "category": "dungeon"}
228	254	{"_key": 254, "trigger": "music_hq_caldari_play", "category": "dungeon"}
229	255	{"_key": 255, "trigger": "music_hq_gallente_play", "category": "dungeon"}
230	256	{"_key": 256, "trigger": "music_hq_minmatar_play", "category": "dungeon"}
231	257	{"_key": 257, "trigger": "dungeon_music_shipcaster_construct_event", "category": "dungeon"}
232	258	{"_key": 258, "trigger": "dungeon_music_default_hacking", "category": "dungeon"}
233	259	{"_key": 259, "trigger": "dungeon_music_default_mining", "category": "dungeon"}
234	260	{"_key": 260, "trigger": "dungeon_music_default_combat", "category": "dungeon"}
235	261	{"_key": 261, "trigger": "dungeon_music_default_exploration", "category": "dungeon"}
236	262	{"_key": 262, "trigger": "dungeon_music_default_agent", "category": "dungeon"}
237	263	{"_key": 263, "trigger": "dungeon_music_default_fallback", "category": "dungeon"}
238	264	{"_key": 264, "trigger": "music_hq_amarr_stellar_harvester", "category": "dungeon"}
239	265	{"_key": 265, "trigger": "music_hq_caldari_stellar_harvester", "category": "dungeon"}
240	266	{"_key": 266, "trigger": "music_hq_gallente_stellar_harvester", "category": "dungeon"}
241	267	{"_key": 267, "trigger": "music_hq_minmatar_stellar_harvester", "category": "dungeon"}
242	268	{"_key": 268, "trigger": "music_hq_amarr_station", "category": "dungeon"}
243	269	{"_key": 269, "trigger": "music_hq_caldari_station", "category": "dungeon"}
244	270	{"_key": 270, "trigger": "music_hq_gallente_station", "category": "dungeon"}
245	271	{"_key": 271, "trigger": "music_hq_minmatar_station", "category": "dungeon"}
246	272	{"_key": 272, "trigger": "music_hq_amarr_shipcaster", "category": "dungeon"}
247	273	{"_key": 273, "trigger": "music_hq_caldari_shipcaster", "category": "dungeon"}
248	274	{"_key": 274, "trigger": "music_hq_gallente_shipcaster", "category": "dungeon"}
249	275	{"_key": 275, "trigger": "music_hq_minmatar_shipcaster", "category": "dungeon"}
250	276	{"_key": 276, "trigger": "dungeon_music_cap_day_pirate_combat_r1", "category": "dungeon"}
251	277	{"_key": 277, "trigger": "dungeon_music_cap_day_pirate_combat_r2", "category": "dungeon"}
252	278	{"_key": 278, "trigger": "dungeon_music_cap_day_pirate_hacking", "category": "dungeon"}
253	279	{"_key": 279, "trigger": "dungeon_music_cap_day_soct_combat_r1", "category": "dungeon"}
254	280	{"_key": 280, "trigger": "dungeon_music_cap_day_soct_combat_r2", "category": "dungeon"}
255	281	{"_key": 281, "trigger": "dungeon_music_cap_day_soct_hacking", "category": "dungeon"}
256	282	{"_key": 282, "trigger": "dungeon_music_pochven_mining", "category": "dungeon"}
257	283	{"_key": 283, "trigger": "dungeon_music_pochven_hacking", "category": "dungeon"}
258	285	{"_key": 285, "trigger": "dungeon_music_pushyourluck_amarr", "category": "dungeon"}
259	286	{"_key": 286, "trigger": "dungeon_music_pushyourluck_caldari", "category": "dungeon"}
260	287	{"_key": 287, "trigger": "dungeon_music_pushyourluck_gallente", "category": "dungeon"}
261	288	{"_key": 288, "trigger": "dungeon_music_pushyourluck_minmatar", "category": "dungeon"}
262	289	{"_key": 289, "trigger": "dungeon_music_disabledefenses_amarr", "category": "dungeon"}
263	290	{"_key": 290, "trigger": "dungeon_music_disabledefenses_caldari", "category": "dungeon"}
264	291	{"_key": 291, "trigger": "dungeon_music_disabledefenses_gallente", "category": "dungeon"}
265	292	{"_key": 292, "trigger": "dungeon_music_disabledefenses_minmatar", "category": "dungeon"}
266	293	{"_key": 293, "trigger": "dungeon_music_chargethegun_amarr", "category": "dungeon"}
267	294	{"_key": 294, "trigger": "dungeon_music_chargethegun_caldari", "category": "dungeon"}
268	295	{"_key": 295, "trigger": "dungeon_music_chargethegun_gallente", "category": "dungeon"}
269	296	{"_key": 296, "trigger": "dungeon_music_chargethegun_minmatar", "category": "dungeon"}
270	297	{"_key": 297, "trigger": "dungeon_music_noescape_amarr", "category": "dungeon"}
271	298	{"_key": 298, "trigger": "dungeon_music_noescape_caldari", "category": "dungeon"}
272	299	{"_key": 299, "trigger": "dungeon_music_noescape_gallente", "category": "dungeon"}
273	300	{"_key": 300, "trigger": "dungeon_music_noescape_minmatar", "category": "dungeon"}
274	301	{"_key": 301, "trigger": "dungeon_music_miningrush_amarr", "category": "dungeon"}
275	302	{"_key": 302, "trigger": "dungeon_music_miningrush_caldari", "category": "dungeon"}
276	303	{"_key": 303, "trigger": "dungeon_music_miningrush_gallente", "category": "dungeon"}
277	304	{"_key": 304, "trigger": "dungeon_music_miningrush_minmatar", "category": "dungeon"}
278	305	{"_key": 305, "trigger": "dungeon_music_defendbase_amarr", "category": "dungeon"}
279	306	{"_key": 306, "trigger": "dungeon_music_defendbase_caldari", "category": "dungeon"}
280	307	{"_key": 307, "trigger": "dungeon_music_defendbase_gallente", "category": "dungeon"}
281	308	{"_key": 308, "trigger": "dungeon_music_defendbase_minmatar", "category": "dungeon"}
282	310	{"_key": 310, "trigger": "tutorial_music_homefront1_1_arrival", "category": "tutorial"}
283	311	{"_key": 311, "trigger": "tutorial_music_homefront1_2_aura_callToAction", "category": "tutorial"}
284	312	{"_key": 312, "trigger": "tutorial_music_homefront1_3_lootFound", "category": "tutorial"}
285	331	{"_key": 331, "trigger": "music_login_play", "category": "general"}
286	332	{"_key": 332, "trigger": "music_login_stop", "category": "general"}
287	333	{"_key": 333, "trigger": "music_eve_classic_play", "category": "general"}
288	335	{"_key": 335, "trigger": "es_screen_1_play", "category": "general"}
289	336	{"_key": 336, "trigger": "music_character_creation_play", "category": "general"}
290	337	{"_key": 337, "trigger": "music_character_creation_stop", "category": "general"}
291	338	{"_key": 338, "trigger": "es_screen_3_play", "category": "general"}
292	339	{"_key": 339, "trigger": "es_screen_4_play", "category": "general"}
293	340	{"_key": 340, "trigger": "es_screen_6_play", "category": "general"}
294	341	{"_key": 341, "trigger": "music_eve_dynamic_play", "category": "dungeon"}
295	342	{"_key": 342, "trigger": "music_switch_empire", "category": "general"}
296	343	{"_key": 343, "trigger": "music_switch_danger", "category": "general"}
297	344	{"_key": 344, "trigger": "music_switch_zero", "category": "general"}
298	345	{"_key": 345, "trigger": "music_switch_zero_wormhole", "category": "general"}
299	346	{"_key": 346, "trigger": "music_eve_dynamic_stop", "category": "general"}
300	347	{"_key": 347, "trigger": "music_switch_zero_special", "category": "general"}
301	348	{"_key": 348, "trigger": "music_dungeon_stop", "category": "dungeon"}
302	349	{"_key": 349, "trigger": "music_switch_triglavian_space", "category": "general"}
303	352	{"_key": 352, "trigger": "music_eve_combat_play", "category": "general"}
304	353	{"_key": 353, "trigger": "music_eve_combat_stop", "category": "general"}
305	354	{"_key": 354, "trigger": "music_switch_combat_triglavian", "category": "general"}
306	355	{"_key": 355, "trigger": "music_switch_combat_zerosec_and_wormhole", "category": "general"}
307	356	{"_key": 356, "trigger": "music_switch_combat_nullsec", "category": "general"}
308	357	{"_key": 357, "trigger": "music_switch_combat_empire", "category": "general"}
309	358	{"_key": 358, "trigger": "music_abyssal_deadspace_tier1_room1_play", "category": "general"}
310	359	{"_key": 359, "trigger": "music_abyssal_deadspace_tier1_room2_play", "category": "general"}
311	360	{"_key": 360, "trigger": "music_abyssal_deadspace_tier1_room3_play", "category": "general"}
312	361	{"_key": 361, "trigger": "music_abyssal_deadspace_tier2_room1_play", "category": "general"}
313	362	{"_key": 362, "trigger": "music_abyssal_deadspace_tier2_room2_play", "category": "general"}
314	363	{"_key": 363, "trigger": "music_abyssal_deadspace_tier2_room3_play", "category": "general"}
315	364	{"_key": 364, "trigger": "music_abyssal_deadspace_tier3_room1_play", "category": "general"}
316	365	{"_key": 365, "trigger": "music_abyssal_deadspace_tier3_room2_play", "category": "general"}
317	366	{"_key": 366, "trigger": "music_abyssal_deadspace_tier3_room3_play", "category": "general"}
318	367	{"_key": 367, "trigger": "music_abyssal_deadspace_tier4_room1_play", "category": "general"}
319	368	{"_key": 368, "trigger": "music_abyssal_deadspace_tier4_room2_play", "category": "general"}
320	369	{"_key": 369, "trigger": "music_abyssal_deadspace_tier4_room3_play", "category": "general"}
321	370	{"_key": 370, "trigger": "music_abyssal_deadspace_tier5_room1_play", "category": "general"}
322	371	{"_key": 371, "trigger": "music_abyssal_deadspace_tier5_room2_play", "category": "general"}
323	372	{"_key": 372, "trigger": "music_abyssal_deadspace_tier5_room3_play", "category": "general"}
324	373	{"_key": 373, "trigger": "dungeon_music_capday24_relic", "category": "dungeon"}
325	374	{"_key": 374, "trigger": "dungeon_music_capday24_relic_tier1", "category": "dungeon"}
326	375	{"_key": 375, "trigger": "dungeon_music_capday24_relic_tier2", "category": "dungeon"}
327	376	{"_key": 376, "trigger": "dungeon_music_capday24_relic_tier3", "category": "dungeon"}
328	377	{"_key": 377, "trigger": "dungeon_music_capday24_combat", "category": "dungeon"}
329	378	{"_key": 378, "trigger": "dungeon_music_capday24_combat_tier1", "category": "dungeon"}
330	379	{"_key": 379, "trigger": "dungeon_music_capday24_combat_tier2", "category": "dungeon"}
331	380	{"_key": 380, "trigger": "dungeon_music_capday24_combat_tier3", "category": "dungeon"}
332	381	{"_key": 381, "trigger": "dungeon_music_capday24_combat_tier4", "category": "dungeon"}
333	382	{"_key": 382, "trigger": "music_switch_zarzakh", "category": "general"}
334	383	{"_key": 383, "trigger": "music_switch_zarzakh_normal", "category": "general"}
335	384	{"_key": 384, "trigger": "music_switch_zarzakh_zone_safe", "category": "general"}
336	385	{"_key": 385, "trigger": "music_switch_zarzakh_zone_damage", "category": "general"}
337	386	{"_key": 386, "trigger": "music_switch_zarzakh_combat", "category": "general"}
338	387	{"_key": 387, "trigger": "music_zarzakh_stop", "category": "general"}
339	388	{"_key": 388, "trigger": "music_switch_havoc_insurgency", "category": "general"}
340	389	{"_key": 389, "trigger": "music_switch_havoc_insurgency_level_A", "category": "general"}
341	390	{"_key": 390, "trigger": "music_switch_havoc_insurgency_level_B", "category": "general"}
342	391	{"_key": 391, "trigger": "music_switch_havoc_insurgency_level_C", "category": "general"}
343	392	{"_key": 392, "trigger": "music_switch_havoc_insurgency_level_D", "category": "general"}
344	393	{"_key": 393, "trigger": "music_switch_havoc_insurgency_level_E", "category": "general"}
345	394	{"_key": 394, "trigger": "music_switch_havoc_insurgency_level_F", "category": "general"}
346	395	{"_key": 395, "trigger": "music_havoc_insurgency_combat_play", "category": "general"}
347	396	{"_key": 396, "trigger": "music_havoc_insurgency_combat_stop", "category": "general"}
348	398	{"_key": 398, "trigger": "music_eve_classic_stop", "category": "general"}
349	399	{"_key": 399, "trigger": "tutorial_music_stop", "category": "tutorial"}
350	400	{"_key": 400, "trigger": "music_eve_cemetery_play", "category": "dungeon"}
351	425	{"_key": 425, "trigger": "music_abyssal_deadspace_play", "category": "general"}
352	426	{"_key": 426, "trigger": "music_abyssal_deadspace_stop", "category": "general"}
353	461	{"_key": 461, "trigger": "music_switch_exordium_amarr", "category": "general"}
354	462	{"_key": 462, "trigger": "music_switch_exordium_caldari", "category": "general"}
355	463	{"_key": 463, "trigger": "music_switch_exordium_gallente", "category": "general"}
356	464	{"_key": 464, "trigger": "music_switch_exordium_minmatar", "category": "general"}
357	465	{"_key": 465, "trigger": "music_switch_exordium_manifest", "category": "general"}
358	466	{"_key": 466, "trigger": "music_switch_exordium_basic", "category": "general"}
359	467	{"_key": 467, "trigger": "music_exordium_arrival_gate", "category": "general"}
360	468	{"_key": 468, "trigger": "music_exordium_arrival_shipcaster", "category": "general"}
361	469	{"_key": 469, "trigger": "music_exordium_arrival_station", "category": "general"}
362	470	{"_key": 470, "trigger": "music_exordium_targeted_by_npc", "category": "general"}
363	471	{"_key": 471, "trigger": "music_exordium_targeted_by_player", "category": "general"}
364	472	{"_key": 472, "trigger": "music_exordium_change_a", "category": "general"}
365	473	{"_key": 473, "trigger": "music_exordium_change_b", "category": "general"}
366	474	{"_key": 474, "trigger": "music_exordium_change_c", "category": "general"}
367	475	{"_key": 475, "trigger": "music_switch_exordium", "category": "general"}
368	477	{"_key": 477, "trigger": "music_exordium_stop", "category": "general"}
369	479	{"_key": 479, "trigger": "music_exordium_targeted_by_npc_stop", "category": "general"}
370	482	{"_key": 482, "trigger": "music_exordium_air_dungeon_amarr_play", "category": "dungeon"}
371	483	{"_key": 483, "trigger": "music_exordium_air_dungeon_amarr_stop", "category": "dungeon"}
372	484	{"_key": 484, "trigger": "music_exordium_air_dungeon_amarr_switch_pt1", "category": "dungeon"}
373	485	{"_key": 485, "trigger": "music_exordium_air_dungeon_amarr_switch_pt2", "category": "dungeon"}
374	486	{"_key": 486, "trigger": "music_exordium_air_dungeon_amarr_switch_pt3", "category": "dungeon"}
375	487	{"_key": 487, "trigger": "music_exordium_air_dungeon_caldari_play", "category": "dungeon"}
376	488	{"_key": 488, "trigger": "music_exordium_air_dungeon_caldari_stop", "category": "dungeon"}
377	489	{"_key": 489, "trigger": "music_exordium_air_dungeon_caldari_switch_pt1", "category": "dungeon"}
378	491	{"_key": 491, "trigger": "music_exordium_air_dungeon_caldari_switch_pt3", "category": "dungeon"}
379	492	{"_key": 492, "trigger": "music_exordium_air_dungeon_caldari_switch_pt2", "category": "dungeon"}
380	493	{"_key": 493, "trigger": "music_exordium_air_dungeon_gallente_play", "category": "dungeon"}
381	494	{"_key": 494, "trigger": "music_exordium_air_dungeon_gallente_stop", "category": "dungeon"}
382	495	{"_key": 495, "trigger": "music_exordium_air_dungeon_gallente_switch_pt1", "category": "dungeon"}
383	496	{"_key": 496, "trigger": "music_exordium_air_dungeon_gallente_switch_pt2", "category": "dungeon"}
384	497	{"_key": 497, "trigger": "music_exordium_air_dungeon_gallente_switch_pt3", "category": "dungeon"}
385	498	{"_key": 498, "trigger": "music_exordium_air_dungeon_minmatar_play", "category": "dungeon"}
386	499	{"_key": 499, "trigger": "music_exordium_air_dungeon_minmatar_stop", "category": "dungeon"}
387	500	{"_key": 500, "trigger": "music_exordium_air_dungeon_minmatar_switch_pt1", "category": "dungeon"}
388	501	{"_key": 501, "trigger": "music_exordium_air_dungeon_minmatar_switch_pt2", "category": "dungeon"}
389	502	{"_key": 502, "trigger": "music_exordium_air_dungeon_minmatar_switch_pt3", "category": "dungeon"}
390	504	{"_key": 504, "trigger": "music_exordium_dungeon_play", "category": "dungeon"}
391	505	{"_key": 505, "trigger": "music_exordium_dungeon_stop", "category": "dungeon"}
\.


--
-- Name: musictriggers musictriggers_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.musictriggers
    ADD CONSTRAINT musictriggers_pkey PRIMARY KEY (row_no);


--
-- Name: musictriggers_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX musictriggers_key_idx ON sde_native.musictriggers USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict ZPxUUVOnTKlJr1rw9S4QIGSbfRnU3aesgoQU9MC3TSOxM74GoMXVcJTBIgbTrrx

