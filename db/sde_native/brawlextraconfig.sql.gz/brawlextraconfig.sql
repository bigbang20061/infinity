--
-- PostgreSQL database dump
--

\restrict XUxKiGEeqLbeMWyIbcLkqQpAbhXkT0uFK9gdHo0CXwTQKkAYY4dKrQxyfr4VFYc

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: brawlextraconfig; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.brawlextraconfig (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: brawlextraconfig; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.brawlextraconfig (row_no, key, data) FROM stdin;
0	\N	{"shipSlotConfig": {"73318": 14, "73379": 15, "74422": 15, "76010": 14, "77815": 15}, "moduleSuitConfig": {"1": [75322, 75323, 75324, 75325]}}
\.


--
-- Name: brawlextraconfig brawlextraconfig_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.brawlextraconfig
    ADD CONSTRAINT brawlextraconfig_pkey PRIMARY KEY (row_no);


--
-- Name: brawlextraconfig_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX brawlextraconfig_key_idx ON sde_native.brawlextraconfig USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict XUxKiGEeqLbeMWyIbcLkqQpAbhXkT0uFK9gdHo0CXwTQKkAYY4dKrQxyfr4VFYc

