--
-- PostgreSQL database dump
--

\restrict Dc0LWlj4ev9fT9UOogGVOfmLEZiS1FnI8WmI6nIPaJw1LTs5iwGTxSILUqqHPFC

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: monetizationactivitytypes; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.monetizationactivitytypes (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: monetizationactivitytypes; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.monetizationactivitytypes (row_no, key, data) FROM stdin;
0	0	{"_key": 0, "name": "NOT_USED"}
1	1	{"_key": 1, "name": "CASHBACK"}
2	2	{"_key": 2, "name": "PLEX_SPEND_REWARD"}
3	3	{"_key": 3, "name": "NPE_PURCHASE_REWARD"}
4	4	{"_key": 4, "name": "DAILY_PURCHASE_REWARD"}
\.


--
-- Name: monetizationactivitytypes monetizationactivitytypes_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.monetizationactivitytypes
    ADD CONSTRAINT monetizationactivitytypes_pkey PRIMARY KEY (row_no);


--
-- Name: monetizationactivitytypes_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX monetizationactivitytypes_key_idx ON sde_native.monetizationactivitytypes USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict Dc0LWlj4ev9fT9UOogGVOfmLEZiS1FnI8WmI6nIPaJw1LTs5iwGTxSILUqqHPFC

