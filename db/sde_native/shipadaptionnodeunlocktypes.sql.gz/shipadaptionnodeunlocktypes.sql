--
-- PostgreSQL database dump
--

\restrict iDHgXGJrY3MNx85BnhibD5p7dbdrHBOtLZQ60PqFGh3cLkKeu3iVFf581h0DOzv

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: shipadaptionnodeunlocktypes; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.shipadaptionnodeunlocktypes (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: shipadaptionnodeunlocktypes; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.shipadaptionnodeunlocktypes (row_no, key, data) FROM stdin;
0	0	{"_key": 0, "name": "Not Use"}
1	1	{"_key": 1, "name": "Material"}
2	2	{"_key": 2, "name": "Mission"}
\.


--
-- Name: shipadaptionnodeunlocktypes shipadaptionnodeunlocktypes_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.shipadaptionnodeunlocktypes
    ADD CONSTRAINT shipadaptionnodeunlocktypes_pkey PRIMARY KEY (row_no);


--
-- Name: shipadaptionnodeunlocktypes_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX shipadaptionnodeunlocktypes_key_idx ON sde_native.shipadaptionnodeunlocktypes USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict iDHgXGJrY3MNx85BnhibD5p7dbdrHBOtLZQ60PqFGh3cLkKeu3iVFf581h0DOzv

