--
-- PostgreSQL database dump
--

\restrict CPLD8NhnRSclOzj5hbmJzL1fkq3BYsRhTVjAKualDitkIumH3hOMEReLYkofacS

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: character_resources; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.character_resources (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: character_resources; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.character_resources (row_no, key, data) FROM stdin;
0	2	{"_key": 2, "resPath": "bottomOuter/PantsGF01/Types/PantsGF01_jinmei.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
1	3	{"_key": 3, "resPath": "Accessories/Glasses/Glasses_Pilot_01/Types/glasses_01_yellow.type", "resGender": 0, "empireRestrictions": [4]}
2	4	{"_key": 4, "resPath": "Feet/BootsMM01/Types/BootsMM01_generic01.type", "resGender": 1, "empireRestrictions": [4]}
3	5	{"_key": 5, "resPath": "bottomOuter/PantsAM01/Types/PantsAM01_generic01.type", "resGender": 1, "empireRestrictions": [2]}
4	6	{"_key": 6, "resPath": "Makeup/Scarring/Scarring_02/Types/Scarring_02.type", "resGender": 0}
5	7	{"_key": 7, "resPath": "Feet/BootsAF01/Types/BootsAF01_nikunni.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
6	8	{"_key": 8, "resPath": "Scars/Head/HeroScar06/Types/HeroScar06_v1.type", "resGender": 1}
7	9	{"_key": 9, "resPath": "Makeup/Lipstick/Lipstick_02/Types/Lipstick_02.type", "resGender": 1}
8	10	{"_key": 10, "resPath": "Feet/ShoesGM01/Types/ShoesGM01_generic02.type", "resGender": 1, "empireRestrictions": [1]}
9	11	{"_key": 11, "resPath": "hair/Hair_DreadlocksPonytail_02/Types/Hair_DreadlocksPonytail_02.type", "resGender": 0, "empireRestrictions": [1, 4]}
10	12	{"_key": 12, "resPath": "bottomUnderwear/BoxersCM01/Types/achura.type", "resGender": 1}
11	13	{"_key": 13, "resPath": "Beard/Beard_02/Types/Beard_02.type", "resGender": 1}
12	14	{"_key": 14, "resPath": "Makeup/Eyes/Eyes_07/Types/Eyes_07.type", "resGender": 0}
13	15	{"_key": 15, "resPath": "outer/JacketCM01/Types/JacketCM01_generic02.type", "resGender": 1, "empireRestrictions": [8]}
14	16	{"_key": 16, "resPath": "outer/JacketGM01/Types/JacketGM01_generic01.type", "resGender": 1, "empireRestrictions": [1]}
15	17	{"_key": 17, "resPath": "TopOuter/ShirtAM01/Types/ShirtAM01_nikunni.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
16	18	{"_key": 18, "resPath": "TopMiddle/ShirtCM01/Types/ShirtCM01_civire.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
17	19	{"_key": 19, "resPath": "outer/RobeAM01/Types/RobeAM01_blue.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
18	20	{"_key": 20, "resPath": "topUnderwear/BikiniTopCF01/Types/BikiniTopCF01_achura.type", "resGender": 0}
19	21	{"_key": 21, "resPath": "Makeup/Eyebrows/Eyebrows_02/Types/Eyebrows_02.type", "resGender": 1}
20	22	{"_key": 22, "resPath": "hair/Hair_BraidedBun_01/Types/Hair_BraidedBun_01.type", "resGender": 0, "empireRestrictions": [2, 8]}
21	23	{"_key": 23, "resPath": "bottomUnderwear/BikiniBottomGF01/Types/BikiniBottomGF01_intaki.type", "resGender": 0}
22	24	{"_key": 24, "resPath": "Makeup/Aging/Aging_03/Types/Aging_03.type", "resGender": 1}
23	25	{"_key": 25, "resPath": "Scars/Head/HeroScar13/Types/HeroScar13_v0.type", "resGender": 0}
24	26	{"_key": 26, "resPath": "Makeup/Eyes/Eyes_01/Types/Eyes_01.type", "resGender": 1}
25	27	{"_key": 27, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_generic01.type", "resGender": 1, "empireRestrictions": [1]}
26	28	{"_key": 28, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_extra01.type", "resGender": 1}
27	29	{"_key": 29, "resPath": "Scars/Head/HeroScar12/Types/HeroScar12_v0.type", "resGender": 0}
28	30	{"_key": 30, "resPath": "Makeup/Eyes/Eyes_09/Types/Eyes_09.type", "resGender": 1}
29	31	{"_key": 31, "resPath": "Scars/Head/HeroScar13/Types/HeroScar13_v1.type", "resGender": 0}
30	32	{"_key": 32, "resPath": "Feet/BootsGF01/Types/BootsGF01_intaki.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
31	33	{"_key": 33, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_extra01.type", "resGender": 0}
32	34	{"_key": 34, "resPath": "Scars/Head/HeroScar05/Types/HeroScar05_v0.type", "resGender": 1}
33	35	{"_key": 35, "resPath": "TopMiddle/ShirtMF01/Types/ShirtMF01_brutor.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
34	36	{"_key": 36, "resPath": "topUnderwear/BikiniTopAF01/Types/BikiniTopAF01_nikunni.type", "resGender": 0}
35	37	{"_key": 37, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_extra03.type", "resGender": 0}
36	38	{"_key": 38, "resPath": "Makeup/Freckles/Freckles_03/Types/Freckles_03.type", "resGender": 0}
37	39	{"_key": 39, "resPath": "outer/JacketCM01/Types/JacketCM01_civire.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
38	40	{"_key": 40, "resPath": "TopMiddle/ShirtMM01/Types/ShirtMM01_brutor.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
39	41	{"_key": 41, "resPath": "Makeup/Freckles/Freckles_01/Types/Freckles_01.type", "resGender": 1}
40	42	{"_key": 42, "resPath": "TopMiddle/ShirtMF01/Types/ShirtMF01_generic02.type", "resGender": 0, "empireRestrictions": [4]}
41	43	{"_key": 43, "resPath": "Beard/FiveOC/Types/FiveOC.type", "resGender": 1}
42	44	{"_key": 44, "resPath": "hair/Hair_Implant_01/Types/Hair_Implant_01.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
43	45	{"_key": 45, "resPath": "Makeup/Eyeliner/Eyeliner_07/Types/Eyeliner_07.type", "resGender": 0}
44	46	{"_key": 46, "resPath": "Scars/Head/HeroScar06/Types/HeroScar06_v0.type", "resGender": 0}
45	47	{"_key": 47, "resPath": "hair/Hair_Implant_03/Types/Hair_Implant_03.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
46	48	{"_key": 48, "resPath": "TopMiddle/ShirtMM01/Types/ShirtMM01_sebiestor.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
47	49	{"_key": 49, "resPath": "Scars/Head/HeroScar03/Types/HeroScar03_v0.type", "resGender": 1}
48	50	{"_key": 50, "resPath": "hair/Hair_MediumStyled_01/Types/Hair_MediumStyled_01.type", "resGender": 0}
49	51	{"_key": 51, "resPath": "Feet/BootsGF01/Types/BootsGF01_jinmei.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
50	52	{"_key": 52, "resPath": "TopOuter/ShirtAM01/Types/ShirtAM01_khanid.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
51	53	{"_key": 53, "resPath": "outer/RobeAM01/Types/RobeAM01_purple.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
52	54	{"_key": 54, "resPath": "outer/JacketAM01/Types/JacketAM01_generic01.type", "resGender": 1, "empireRestrictions": [2]}
53	55	{"_key": 55, "resPath": "bottomOuter/PantsGF01/Types/PantsGF01_generic02.type", "resGender": 0, "empireRestrictions": [1]}
54	56	{"_key": 56, "resPath": "hair/Hair_FrontCombed_02/Types/Hair_FrontCombed_02.type", "resGender": 0}
55	57	{"_key": 57, "resPath": "hair/Hair_Long_02/Types/Hair_Long_02.type", "resGender": 0}
56	58	{"_key": 58, "resPath": "hair/Hair_MediumParted_04/Types/Hair_MediumParted_04.type", "resGender": 0}
57	59	{"_key": 59, "resPath": "hair/Hair_ShortUnruly_01/Types/Hair_ShortUnruly_01.type", "resGender": 1, "empireRestrictions": [4]}
58	60	{"_key": 60, "resPath": "outer/JacketGM01/Types/JacketGM01_intaki.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
59	61	{"_key": 61, "resPath": "Makeup/Eyebrows/Eyebrows_05/Types/Eyebrows_05.type", "resGender": 1}
60	62	{"_key": 62, "resPath": "Outer/JacketGF01/Types/JacketGF01_generic01.type", "resGender": 0, "empireRestrictions": [1]}
61	63	{"_key": 63, "resPath": "Scars/Head/HeroScar03/Types/HeroScar03_v1.type", "resGender": 0}
62	64	{"_key": 64, "resPath": "Makeup/Aging/Aging_02/Types/Aging_02.type", "resGender": 1}
63	65	{"_key": 65, "resPath": "Makeup/Eyeliner/Eyeliner_05/Types/Eyeliner_05.type", "resGender": 0}
64	66	{"_key": 66, "resPath": "bottomOuter/PantsMM01/Types/JacketMM01_generic01.type", "resGender": 1, "empireRestrictions": [4]}
65	67	{"_key": 67, "resPath": "bottomOuter/PantsAM01/Types/PantsAM01_nikunni.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
66	68	{"_key": 68, "resPath": "Outer/JacketCF01/Types/JacketCF01_generic01.type", "resGender": 0, "empireRestrictions": [8]}
67	69	{"_key": 69, "resPath": "bottomOuter/PantsMF01/Types/PantsMF01_brutor.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
68	70	{"_key": 70, "resPath": "TopMiddle/ShirtAF01/Types/ShirtAF01_khanid.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
69	71	{"_key": 71, "resPath": "outer/JacketMM01/Types/JacketMM01_generic01.type", "resGender": 1, "empireRestrictions": [4]}
70	72	{"_key": 72, "resPath": "Feet/BootsCM01/Types/BootsCM01_generic02.type", "resGender": 1, "empireRestrictions": [8]}
71	73	{"_key": 73, "resPath": "Scars/Head/HeroScar03/Types/HeroScar03_v1.type", "resGender": 1}
72	74	{"_key": 74, "resPath": "Scars/Head/HeroScar08/Types/HeroScar08_v0.type", "resGender": 1}
73	75	{"_key": 75, "resPath": "Makeup/Eyeliner/Eyeliner_01/Types/Eyeliner_01.type", "resGender": 0}
74	76	{"_key": 76, "resPath": "Makeup/Scarring/Scarring_01/Types/Scarring_01.type", "resGender": 1}
75	77	{"_key": 77, "resPath": "TopOuter/ShirtAM01/Types/ShirtAM01_generic01.type", "resGender": 1, "empireRestrictions": [2]}
76	78	{"_key": 78, "resPath": "Outer/JacketAF01/Types/JacketAF01_generic02.type", "resGender": 0, "empireRestrictions": [2]}
77	79	{"_key": 79, "resPath": "Makeup/Eyes/Eyes_01/Types/Eyes_01.type", "resGender": 0}
78	80	{"_key": 80, "resPath": "bottomOuter/PantsGF01/Types/PantsGF01_intaki.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
79	81	{"_key": 81, "resPath": "TopMiddle/TanktopM01/Types/TanktopM01_generic01.type", "resGender": 1}
80	82	{"_key": 82, "resPath": "bottomUnderwear/BikiniBottomMF01/Types/BikiniBottomMF01_vherokior.type", "resGender": 0}
81	83	{"_key": 83, "resPath": "Makeup/Eyes/Eyes_04/Types/Eyes_04.type", "resGender": 0}
82	84	{"_key": 84, "resPath": "Scars/Head/HeroScar11/Types/HeroScar11_v0.type", "resGender": 1}
83	85	{"_key": 85, "resPath": "Outer/JacketCF01/Types/JacketCF01_civire.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
84	86	{"_key": 86, "resPath": "Scars/Head/HeroScar18/Types/HeroScar18_v0.type", "resGender": 0}
85	87	{"_key": 87, "resPath": "Beard/Beard_03/Types/Beard_03.type", "resGender": 1}
86	88	{"_key": 88, "resPath": "bottomOuter/PantsGM01/Types/PantsGM01_jinmei.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
87	89	{"_key": 89, "resPath": "outer/JacketAM01/Types/JacketAM01_khanid.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
88	90	{"_key": 90, "resPath": "Scars/Head/HeroScar17/Types/HeroScar17_v1.type", "resGender": 1}
89	91	{"_key": 91, "resPath": "bottomUnderwear/BoxersGM01/Types/gallente.type", "resGender": 1}
90	92	{"_key": 92, "resPath": "TopOuter/ShirtAM01/Types/ShirtAM01_amarr.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
91	93	{"_key": 93, "resPath": "Scars/Head/HeroScar02/Types/HeroScar02_v0.type", "resGender": 1}
92	94	{"_key": 94, "resPath": "outer/JacketAM01/Types/JacketAM01_amarr.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
93	95	{"_key": 95, "resPath": "Feet/BootsAM01/Types/BootsAM01_generic01.type", "resGender": 1, "empireRestrictions": [2]}
94	96	{"_key": 96, "resPath": "Scars/Head/HeroScar01/Types/HeroScar01_v0.type", "resGender": 0}
95	97	{"_key": 97, "resPath": "Makeup/Scarring/Scarring_03/Types/Scarring_03.type", "resGender": 0}
96	98	{"_key": 98, "resPath": "Makeup/Eyebrows/Eyebrows_03/Types/Eyebrows_03.type", "resGender": 1}
97	99	{"_key": 99, "resPath": "bottomUnderwear/BikiniBottomMF01/Types/BikiniBottomMF01_sebiestor.type", "resGender": 0}
98	100	{"_key": 100, "resPath": "hair/Hair_MediumParted_01/Types/Hair_MediumParted_01.type", "resGender": 0}
99	101	{"_key": 101, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_extra03.type", "resGender": 1}
100	102	{"_key": 102, "resPath": "Scars/Head/HeroScar17/Types/HeroScar17_v0.type", "resGender": 1}
101	103	{"_key": 103, "resPath": "Accessories/EarsLow/Stud01/Types/Stud01.type", "resGender": 0}
102	104	{"_key": 104, "resPath": "Makeup/Aging/Aging_03/Types/Aging_03.type", "resGender": 0}
103	105	{"_key": 105, "resPath": "Makeup/Freckles/Freckles_03/Types/Freckles_03.type", "resGender": 1}
104	106	{"_key": 106, "resPath": "Makeup/Freckles/Freckles_01/Types/Freckles_01.type", "resGender": 0}
105	107	{"_key": 107, "resPath": "Makeup/Eyebrows/Eyebrows_01/Types/Eyebrows_01.type", "resGender": 1}
106	108	{"_key": 108, "resPath": "hair/Hair_Slick_02/Types/Hair_Slick_02.type", "resGender": 1}
107	109	{"_key": 109, "resPath": "hair/Hair_Bun_01/Types/Hair_Bun_01.type", "resGender": 0}
108	110	{"_key": 110, "resPath": "Makeup/EyeShadow/Eyeshadow_06/Types/Eyeshadow_06.type", "resGender": 0}
109	111	{"_key": 111, "resPath": "Makeup/EyeShadow/Eyeshadow_09/Types/Eyeshadow_09.type", "resGender": 0}
110	112	{"_key": 112, "resPath": "TopMiddle/ShirtCF01/Types/ShirtCF01_achura.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
111	113	{"_key": 113, "resPath": "Makeup/Blush/Blush_02/Types/Blush_02.type", "resGender": 0}
112	114	{"_key": 114, "resPath": "bottomOuter/PantsAF01/Types/PantsAF01_generic01.type", "resGender": 0, "empireRestrictions": [2]}
113	115	{"_key": 115, "resPath": "Makeup/Eyebrows/Eyebrows_03/Types/Eyebrows_03.type", "resGender": 0}
114	116	{"_key": 116, "resPath": "bottomOuter/PantsAF01/Types/PantsAF01_khanid.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
115	117	{"_key": 117, "resPath": "bottomOuter/PantsGM01/Types/PantsGM01_intaki.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
116	118	{"_key": 118, "resPath": "Makeup/Eyeliner/Eyeliner_03/Types/Eyeliner_03.type", "resGender": 0}
117	119	{"_key": 119, "resPath": "Feet/BootsCM01/Types/BootsCM01_civire.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
118	120	{"_key": 120, "resPath": "Accessories/Glasses/Glasses_Pilot_01/Types/glasses_01_blue.type", "resGender": 0, "empireRestrictions": [4]}
119	121	{"_key": 121, "resPath": "Makeup/Eyebrows/Eyebrows_04/Types/Eyebrows_04.type", "resGender": 0}
120	122	{"_key": 122, "resPath": "hair/Hair_ShortStyled_01/Types/Hair_ShortStyled_01.type", "resGender": 0}
121	123	{"_key": 123, "resPath": "Makeup/Eyes/Eyes_02/Types/Eyes_02.type", "resGender": 1}
122	124	{"_key": 124, "resPath": "Scars/Head/HeroScar03/Types/HeroScar03_v0.type", "resGender": 0}
123	125	{"_key": 125, "resPath": "Makeup/Eyes/Eyes_05/Types/Eyes_05.type", "resGender": 1}
124	126	{"_key": 126, "resPath": "Beard/Beard_08/Types/Beard_08.type", "resGender": 1}
125	127	{"_key": 127, "resPath": "hair/Hair_Armycut_03/Types/Hair_Armycut_03.type", "resGender": 1}
126	128	{"_key": 128, "resPath": "bottomOuter/PantsCF01/Types/PantsCF01_achura.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
127	129	{"_key": 129, "resPath": "Accessories/Glasses/Glasses_Pilot_01/Types/glasses_01_blue.type", "resGender": 1, "empireRestrictions": [4]}
128	130	{"_key": 130, "resPath": "TopMiddle/ShirtCF01/Types/ShirtCF01_generic02.type", "resGender": 0, "empireRestrictions": [8]}
129	131	{"_key": 131, "resPath": "Makeup/Eyeliner/Eyeliner_01/Types/Eyeliner_01.type", "resGender": 1}
130	132	{"_key": 132, "resPath": "TopMiddle/ShirtMF01/Types/ShirtMF01_sebiestor.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
131	133	{"_key": 133, "resPath": "Scars/Head/HeroScar16/Types/HeroScar16_v0.type", "resGender": 0}
132	134	{"_key": 134, "resPath": "Scars/Head/HeroScar09/Types/HeroScar09_v0.type", "resGender": 1}
133	135	{"_key": 135, "resPath": "Accessories/Nostril/SimpleLoop01/Types/Ring01.type", "resGender": 0}
134	136	{"_key": 136, "resPath": "bottomOuter/PantsAF01/Types/PantsAF01_amarr.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
135	137	{"_key": 137, "resPath": "Accessories/EarsHigh/SimpleCluster01/Types/Type1.type", "resGender": 0}
136	138	{"_key": 138, "resPath": "bottomUnderwear/BoxersAM01/Types/amarr.type", "resGender": 1}
137	139	{"_key": 139, "resPath": "Scars/Head/HeroScar10/Types/HeroScar10_v0.type", "resGender": 1}
138	140	{"_key": 140, "resPath": "bottomOuter/PantsMF01/Types/PantsMF01_vherokior.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
139	141	{"_key": 141, "resPath": "TopMiddle/ShirtAF01/Types/ShirtAF01_generic02.type", "resGender": 0, "empireRestrictions": [2]}
140	142	{"_key": 142, "resPath": "bottomOuter/PantsMF01/Types/PantsMF01_generic02.type", "resGender": 0, "empireRestrictions": [4]}
141	143	{"_key": 143, "resPath": "Scars/Head/HeroScar14/Types/HeroScar14_v0.type", "resGender": 1}
142	144	{"_key": 144, "resPath": "bottomUnderwear/BikiniBottomMF01/Types/BikiniBottomMF01_brutor.type", "resGender": 0}
143	145	{"_key": 145, "resPath": "bottomOuter/PantsMF01/Types/PantsMF01_sebiestor.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
144	146	{"_key": 146, "resPath": "Makeup/Eyebrows/Eyebrows_02/Types/Eyebrows_02.type", "resGender": 0}
145	147	{"_key": 147, "resPath": "Makeup/Blush/Blush_01/Types/Blush_01.type", "resGender": 1}
146	148	{"_key": 148, "resPath": "outer/JacketCM01/Types/JacketCM01_achura.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
147	149	{"_key": 149, "resPath": "Beard/Beard_05/Types/Beard_05.type", "resGender": 1}
148	150	{"_key": 150, "resPath": "bottomUnderwear/BikiniBottomAF01/Types/BikiniBottomAF01_amarr.type", "resGender": 0}
149	151	{"_key": 151, "resPath": "Scars/Head/HeroScar09/Types/HeroScar09_v0.type", "resGender": 0}
150	152	{"_key": 152, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_extra02.type", "resGender": 1}
151	153	{"_key": 153, "resPath": "bottomUnderwear/BikiniBottomGF01/Types/BikiniBottomGF01_gallente.type", "resGender": 0}
152	154	{"_key": 154, "resPath": "Feet/BootsMF01/Types/BootsMF01_brutor.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
153	155	{"_key": 155, "resPath": "bottomOuter/PantsMM01/Types/JacketMM01_generic02.type", "resGender": 1, "empireRestrictions": [4]}
154	156	{"_key": 156, "resPath": "Feet/BootsCF01/Types/BootsCF01_deteis.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
155	157	{"_key": 157, "resPath": "Feet/BootsGF01/Types/BootsGF01_generic02.type", "resGender": 0, "empireRestrictions": [1]}
156	158	{"_key": 158, "resPath": "Outer/JacketCF01/Types/JacketCF01_generic02.type", "resGender": 0, "empireRestrictions": [8]}
157	159	{"_key": 159, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_gallente.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
158	160	{"_key": 160, "resPath": "TopMiddle/ShirtMM01/Types/ShirtMM01_generic01.type", "resGender": 1, "empireRestrictions": [4]}
159	161	{"_key": 161, "resPath": "Scars/Head/HeroScar05/Types/HeroScar05_v1.type", "resGender": 1}
160	162	{"_key": 162, "resPath": "bottomUnderwear/BoxersMM01/Types/brutor.type", "resGender": 1}
161	163	{"_key": 163, "resPath": "Feet/BootsAF01/Types/BootsAF01_amarr.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
162	164	{"_key": 164, "resPath": "bottomOuter/PantsMM01/Types/JacketMM01_brutor.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
163	165	{"_key": 165, "resPath": "bottomOuter/PantsGF01/Types/PantsGF01_gallente.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
164	166	{"_key": 166, "resPath": "TopMiddle/ShirtCF01/Types/ShirtCF01_deteis.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
165	167	{"_key": 167, "resPath": "bottomOuter/PantsGM01/Types/PantsGM01_generic02.type", "resGender": 1, "empireRestrictions": [1]}
166	168	{"_key": 168, "resPath": "Scars/Head/HeroScar05/Types/HeroScar05_v0.type", "resGender": 0}
167	169	{"_key": 169, "resPath": "Scars/Head/HeroScar18/Types/HeroScar18_v1.type", "resGender": 1}
168	170	{"_key": 170, "resPath": "Makeup/Eyeliner/Eyeliner_02/Types/Eyeliner_02.type", "resGender": 0}
169	171	{"_key": 171, "resPath": "Makeup/Lipstick/Lipstick_01/Types/Lipstick_01.type", "resGender": 1}
170	172	{"_key": 172, "resPath": "Makeup/Eyebrows/Eyebrows_01/Types/Eyebrows_01.type", "resGender": 0}
171	173	{"_key": 173, "resPath": "topUnderwear/BikiniTopMF01/Types/BikiniTopMF01_sebiestor.type", "resGender": 0}
172	174	{"_key": 174, "resPath": "Scars/Head/HeroScar10/Types/HeroScar10_v1.type", "resGender": 0}
173	175	{"_key": 175, "resPath": "Scars/Head/HeroScar10/Types/HeroScar10_v0.type", "resGender": 0}
174	176	{"_key": 176, "resPath": "Makeup/Lipstick/Lipstick_02/Types/Lipstick_02.type", "resGender": 0}
175	177	{"_key": 177, "resPath": "Makeup/Eyes/Eyes_08/Types/Eyes_08.type", "resGender": 1}
176	178	{"_key": 178, "resPath": "Outer/JacketMF01/Types/JacketMF01_sebiestor.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
177	179	{"_key": 179, "resPath": "bottomOuter/PantsCF01/Types/PantsCF01_civire.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
178	180	{"_key": 180, "resPath": "bottomOuter/PantsCF01/Types/PantsCF01_generic01.type", "resGender": 0, "empireRestrictions": [8]}
179	181	{"_key": 181, "resPath": "Makeup/EyeShadow/Eyeshadow_10/Types/Eyeshadow_10.type", "resGender": 0}
180	182	{"_key": 182, "resPath": "bottomUnderwear/BoxersMM01/Types/vherokior.type", "resGender": 1}
181	183	{"_key": 183, "resPath": "Scars/Head/HeroScar05/Types/HeroScar05_v1.type", "resGender": 0}
182	184	{"_key": 184, "resPath": "bottomOuter/PantsAM01/Types/PantsAM01_generic02.type", "resGender": 1, "empireRestrictions": [2]}
183	185	{"_key": 185, "resPath": "Accessories/EarsLow/SimpleHoop/Types/Type1.type", "resGender": 0}
184	186	{"_key": 186, "resPath": "bottomUnderwear/BoxersAM01/Types/khanid.type", "resGender": 1}
185	187	{"_key": 187, "resPath": "Makeup/Eyes/Eyes_09/Types/Eyes_09.type", "resGender": 0}
186	188	{"_key": 188, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_jinmei.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
187	189	{"_key": 189, "resPath": "hair/Hair_MohawkShort_01/Types/Hair_MohawkShort_01.type", "resGender": 1, "empireRestrictions": [4]}
188	190	{"_key": 190, "resPath": "Makeup/Blush/Blush_03/Types/Blush_03.type", "resGender": 1}
189	191	{"_key": 191, "resPath": "hair/Hair_MohawkUnruly_01/Types/Hair_MohawkUnruly_01.type", "resGender": 0, "empireRestrictions": [4]}
190	192	{"_key": 192, "resPath": "outer/JacketGM01/Types/JacketGM01_jinmei.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
191	193	{"_key": 193, "resPath": "Makeup/Eyes/Eyes_06/Types/Eyes_06.type", "resGender": 1}
192	194	{"_key": 194, "resPath": "Makeup/Eyeliner/Eyeliner_08/Types/Eyeliner_08.type", "resGender": 0}
193	195	{"_key": 195, "resPath": "Outer/JacketCF01/Types/JacketCF01_deteis.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
194	196	{"_key": 196, "resPath": "Scars/Head/HeroScar17/Types/HeroScar17_v0.type", "resGender": 0}
195	197	{"_key": 197, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_generic01.type", "resGender": 0, "empireRestrictions": [1]}
196	198	{"_key": 198, "resPath": "bottomOuter/PantsMM01/Types/JacketMM01_vherokior.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
197	199	{"_key": 199, "resPath": "Makeup/Eyes/Eyes_02/Types/Eyes_02.type", "resGender": 0}
198	200	{"_key": 200, "resPath": "Accessories/Glasses/Glasses_Pilot_01/Types/glasses_01_black.type", "resGender": 1, "empireRestrictions": [4]}
199	201	{"_key": 201, "resPath": "Scars/Head/HeroScar08/Types/HeroScar08_v1.type", "resGender": 0}
200	202	{"_key": 202, "resPath": "Makeup/Scarring/Scarring_02/Types/Scarring_02.type", "resGender": 1}
201	203	{"_key": 203, "resPath": "Makeup/Eyeshadow/Eyeshadow_01/Types/Eyeshadow_01.type", "resGender": 1}
202	204	{"_key": 204, "resPath": "topUnderwear/BikiniTopAF01/Types/BikiniTopAF01_amarr.type", "resGender": 0}
203	205	{"_key": 205, "resPath": "Scars/Head/HeroScar11/Types/HeroScar11_v0.type", "resGender": 0}
204	206	{"_key": 206, "resPath": "Outer/JacketGF01/Types/JacketGF01_intaki.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
205	207	{"_key": 207, "resPath": "Outer/JacketAF01/Types/JacketAF01_generic01.type", "resGender": 0, "empireRestrictions": [2]}
206	208	{"_key": 208, "resPath": "hair/Hair_Ponytail_02/Types/Hair_Ponytail_02.type", "resGender": 0}
207	209	{"_key": 209, "resPath": "outer/RobeAM01/Types/RobeAM01_default.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
208	210	{"_key": 210, "resPath": "Scars/Head/HeroScar15/Types/HeroScar15_v0.type", "resGender": 1}
209	211	{"_key": 211, "resPath": "Accessories/Nostril/SimpleLoop01/Types/Ring02.type", "resGender": 0}
210	212	{"_key": 212, "resPath": "Makeup/Eyes/Eyes_08/Types/Eyes_08.type", "resGender": 0}
211	213	{"_key": 213, "resPath": "Outer/JacketGF01/Types/JacketGF01_generic02.type", "resGender": 0, "empireRestrictions": [1]}
212	214	{"_key": 214, "resPath": "TopMiddle/ShirtMM01/Types/ShirtMM01_vherokior.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
213	215	{"_key": 215, "resPath": "Makeup/Lipstick/Lipstick_01/Types/Lipstick_01.type", "resGender": 0}
214	216	{"_key": 216, "resPath": "Feet/BootsAM01/Types/BootsAM01_amarr.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
215	217	{"_key": 217, "resPath": "hair/Hair_StyleCombed_01/Types/Hair_StyleCombed_01.type", "resGender": 1, "empireRestrictions": [4]}
216	218	{"_key": 218, "resPath": "Feet/BootsCF01/Types/BootsCF01_achura.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
217	219	{"_key": 219, "resPath": "Feet/BootsMF01/Types/BootsMF01_sebiestor.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
218	220	{"_key": 220, "resPath": "Beard/Beard_04/Types/Beard_04.type", "resGender": 1}
219	221	{"_key": 221, "resPath": "Makeup/Aging/Aging_01/Types/Aging_01.type", "resGender": 0}
220	222	{"_key": 222, "resPath": "bottomUnderwear/BoxersCM01/Types/civire.type", "resGender": 1}
221	223	{"_key": 223, "resPath": "Makeup/Aging/Aging_01/Types/Aging_01.type", "resGender": 1}
222	224	{"_key": 224, "resPath": "hair/Hair_Long_01/Types/Hair_Long_01.type", "resGender": 0}
223	225	{"_key": 225, "resPath": "hair/Hair_SideParted_01/Types/Hair_SideParted_01.type", "resGender": 0}
224	226	{"_key": 226, "resPath": "TopMiddle/ShirtCM01/Types/ShirtCM01_generic02.type", "resGender": 1, "empireRestrictions": [8]}
225	227	{"_key": 227, "resPath": "TopMiddle/ShirtCF01/Types/ShirtCF01_civire.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
226	228	{"_key": 228, "resPath": "Makeup/EyeLashes/EyeLashes_01/Types/EyeLashes_01.type", "resGender": 1}
227	229	{"_key": 229, "resPath": "Scars/Head/HeroScar12/Types/HeroScar12_v0.type", "resGender": 1}
228	230	{"_key": 230, "resPath": "Makeup/EyeShadow/Eyeshadow_01/Types/Eyeshadow_01.type", "resGender": 0}
229	231	{"_key": 231, "resPath": "Outer/JacketMF01/Types/JacketMF01_vherokior.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
230	232	{"_key": 232, "resPath": "hair/Hair_Slick_01/Types/Hair_Slick_01.type", "resGender": 1, "empireRestrictions": [4]}
231	233	{"_key": 233, "resPath": "Feet/BootsMF01/Types/BootsMF01_generic01.type", "resGender": 0, "empireRestrictions": [4]}
232	234	{"_key": 234, "resPath": "Accessories/Glasses/Glasses_Pilot_01/Types/glasses_01_yellow.type", "resGender": 1, "empireRestrictions": [4]}
233	235	{"_key": 235, "resPath": "hair/Hair_Stubble_01/Types/Hair_Stubble_01.type", "resGender": 0}
234	236	{"_key": 236, "resPath": "bottomOuter/PantsGF01/Types/PantsGF01_generic01.type", "resGender": 0, "empireRestrictions": [1]}
235	237	{"_key": 237, "resPath": "Makeup/Eyebrows/Eyebrows_04/Types/Eyebrows_04.type", "resGender": 1}
236	238	{"_key": 238, "resPath": "hair/Hair_Short_02/Types/Hair_Short_02.type", "resGender": 0}
237	239	{"_key": 239, "resPath": "Feet/BootsMM01/Types/BootsMM01_generic02.type", "resGender": 1, "empireRestrictions": [4]}
238	240	{"_key": 240, "resPath": "Scars/Head/HeroScar08/Types/HeroScar08_v0.type", "resGender": 0}
239	241	{"_key": 241, "resPath": "TopMiddle/ShirtMF01/Types/ShirtMF01_vherokior.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
240	242	{"_key": 242, "resPath": "bottomUnderwear/BikiniBottomCF01/Types/BikiniBottomCF01_civire.type", "resGender": 0}
241	243	{"_key": 243, "resPath": "Makeup/Eyeliner/Eyeliner_02/Types/Eyeliner_02.type", "resGender": 1}
242	244	{"_key": 244, "resPath": "Feet/BootsAM01/Types/BootsAM01_generic02.type", "resGender": 1, "empireRestrictions": [2]}
243	245	{"_key": 245, "resPath": "outer/JacketGM01/Types/JacketGM01_generic02.type", "resGender": 1, "empireRestrictions": [1]}
244	246	{"_key": 246, "resPath": "Outer/JacketAF01/Types/JacketAF01_nikunni.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
245	247	{"_key": 247, "resPath": "Feet/BootsAM01/Types/BootsAM01_khanid.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
246	248	{"_key": 248, "resPath": "hair/Hair_Short_01/Types/Hair_Short_01.type", "resGender": 0}
247	249	{"_key": 249, "resPath": "hair/Hair_MohawkCut_01/Types/Hair_MohawkCut_01.type", "resGender": 1, "empireRestrictions": [4]}
248	250	{"_key": 250, "resPath": "Makeup/Lipstick/Lipstick_05/Types/Lipstick_05.type", "resGender": 0}
249	251	{"_key": 251, "resPath": "Feet/BootsAM01/Types/BootsAM01_nikunni.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
250	252	{"_key": 252, "resPath": "Scars/Head/HeroScar02/Types/HeroScar02_v1.type", "resGender": 1}
251	253	{"_key": 253, "resPath": "Feet/BootsAF01/Types/BootsAF01_generic02.type", "resGender": 0, "empireRestrictions": [2]}
252	254	{"_key": 254, "resPath": "bottomOuter/PantsAM01/Types/PantsAM01_khanid.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
253	255	{"_key": 255, "resPath": "Accessories/Glasses/Goggles_01/Types/goggles_01_v1.type", "resGender": 1}
254	256	{"_key": 256, "resPath": "Scars/Head/HeroScar16/Types/HeroScar16_v0.type", "resGender": 1}
255	257	{"_key": 257, "resPath": "Accessories/Brow/RingCluster01/Types/Type1.type", "resGender": 0}
256	258	{"_key": 258, "resPath": "bottomUnderwear/BikiniBottomGF01/Types/BikiniBottomGF01_jinmei.type", "resGender": 0}
257	259	{"_key": 259, "resPath": "bottomOuter/PantsGM01/Types/PantsGM01_generic01.type", "resGender": 1, "empireRestrictions": [1]}
258	260	{"_key": 260, "resPath": "Makeup/Freckles/Freckles_02/Types/Freckles_02.type", "resGender": 0}
259	261	{"_key": 261, "resPath": "Accessories/Glasses/Glasses_Pilot_01/Types/glasses_01_olive.type", "resGender": 0, "empireRestrictions": [4]}
260	262	{"_key": 262, "resPath": "Makeup/Scarring/Scarring_03/Types/Scarring_03.type", "resGender": 1}
261	263	{"_key": 263, "resPath": "Scars/Head/HeroScar15/Types/HeroScar15_v1.type", "resGender": 0}
262	264	{"_key": 264, "resPath": "Scars/Head/HeroScar04/Types/HeroScar04_v0.type", "resGender": 0}
263	265	{"_key": 265, "resPath": "bottomUnderwear/BikiniBottomAF01/Types/BikiniBottomAF01_khanid.type", "resGender": 0}
264	266	{"_key": 266, "resPath": "bottomOuter/PantsGM01/Types/PantsGM01_gallente.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
265	267	{"_key": 267, "resPath": "Accessories/Glasses/Glasses_Pilot_01/Types/glasses_01_olive.type", "resGender": 1, "empireRestrictions": [4]}
266	268	{"_key": 268, "resPath": "Accessories/Nose/Bar/Types/Bar01.type", "resGender": 0}
267	269	{"_key": 269, "resPath": "Scars/Head/HeroScar18/Types/HeroScar18_v0.type", "resGender": 1}
268	270	{"_key": 270, "resPath": "bottomOuter/PantsMM01/Types/JacketMM01_sebiestor.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
269	271	{"_key": 271, "resPath": "outer/JacketMM01/Types/JacketMM01_brutor.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
270	272	{"_key": 272, "resPath": "Scars/Head/HeroScar09/Types/HeroScar09_v1.type", "resGender": 1}
271	273	{"_key": 273, "resPath": "Outer/JacketGF01/Types/JacketGF01_gallente.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
272	274	{"_key": 274, "resPath": "topUnderwear/BikiniTopMF01/Types/BikiniTopMF01_vherokior.type", "resGender": 0}
273	275	{"_key": 275, "resPath": "Makeup/Eyeliner/Eyeliner_06/Types/Eyeliner_06.type", "resGender": 0}
274	276	{"_key": 276, "resPath": "Scars/Head/HeroScar14/Types/HeroScar14_v1.type", "resGender": 0}
275	277	{"_key": 277, "resPath": "hair/Hair_MediumCombed_01/Types/Hair_MediumCombed_01.type", "resGender": 1, "empireRestrictions": [4]}
276	278	{"_key": 278, "resPath": "Beard/Beard_06/Types/Beard_06.type", "resGender": 1}
277	279	{"_key": 279, "resPath": "Accessories/Lips/Ring05/Types/Stud02.type", "resGender": 0}
278	280	{"_key": 280, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_jinmei.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
279	281	{"_key": 281, "resPath": "bottomOuter/PantsCF01/Types/PantsCF01_generic02.type", "resGender": 0, "empireRestrictions": [8]}
280	282	{"_key": 282, "resPath": "Outer/JacketMF01/Types/JacketMF01_generic01.type", "resGender": 0, "empireRestrictions": [4]}
281	283	{"_key": 283, "resPath": "Scars/Head/HeroScar15/Types/HeroScar15_v0.type", "resGender": 0}
282	284	{"_key": 284, "resPath": "Outer/JacketGF01/Types/JacketGF01_jinmei.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
283	285	{"_key": 285, "resPath": "Makeup/Implants/Plugs_02/Types/Plugs_02.type", "resGender": 0}
284	286	{"_key": 286, "resPath": "hair/Hair_BackCombed_01/Types/Hair_BackCombed_01.type", "resGender": 1}
285	287	{"_key": 287, "resPath": "bottomOuter/PantsAF01/Types/PantsAF01_nikunni.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
286	288	{"_key": 288, "resPath": "outer/JacketMM01/Types/JacketMM01_sebiestor.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
287	289	{"_key": 289, "resPath": "Scars/Head/HeroScar11/Types/HeroScar11_v1.type", "resGender": 1}
288	290	{"_key": 290, "resPath": "outer/JacketCM01/Types/JacketCM01_deteis.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
289	291	{"_key": 291, "resPath": "Scars/Head/HeroScar13/Types/HeroScar13_v0.type", "resGender": 1}
290	292	{"_key": 292, "resPath": "Accessories/Glasses/Glasses_Pilot_01/Types/glasses_01_brown.type", "resGender": 1, "empireRestrictions": [4]}
291	293	{"_key": 293, "resPath": "Scars/Head/HeroScar17/Types/HeroScar17_v1.type", "resGender": 0}
292	294	{"_key": 294, "resPath": "hair/Hair_Receding_02/Types/Hair_Receding_02.type", "resGender": 1}
293	295	{"_key": 295, "resPath": "Makeup/Eyes/Eyes_10/Types/Eyes_10.type", "resGender": 1}
294	296	{"_key": 296, "resPath": "hair/Hair_Shortcut_01/Types/Hair_Shortcut_01.type", "resGender": 1, "empireRestrictions": [4]}
295	297	{"_key": 297, "resPath": "Scars/Head/HeroScar09/Types/HeroScar09_v1.type", "resGender": 0}
296	298	{"_key": 298, "resPath": "Feet/BootsGF01/Types/BootsGF01_generic01.type", "resGender": 0, "empireRestrictions": [1]}
297	299	{"_key": 299, "resPath": "Scars/Head/HeroScar06/Types/HeroScar06_v1.type", "resGender": 0}
298	300	{"_key": 300, "resPath": "TopMiddle/ShirtAF01/Types/ShirtAF01_amarr.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
299	301	{"_key": 301, "resPath": "Makeup/Eyeliner/Eyeliner_04/Types/Eyeliner_04.type", "resGender": 0}
300	302	{"_key": 302, "resPath": "Outer/JacketAF01/Types/JacketAF01_amarr.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
301	303	{"_key": 303, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_intaki.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
302	304	{"_key": 304, "resPath": "Feet/BootsAF01/Types/BootsAF01_khanid.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
303	305	{"_key": 305, "resPath": "bottomUnderwear/BoxersCM01/Types/deteis.type", "resGender": 1}
304	306	{"_key": 306, "resPath": "Scars/Head/HeroScar12/Types/HeroScar12_v1.type", "resGender": 0}
305	307	{"_key": 307, "resPath": "Feet/BootsMM01/Types/BootsMM01_sebiestor.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
306	308	{"_key": 308, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_generic01.type", "resGender": 0}
307	309	{"_key": 309, "resPath": "TopMiddle/ShirtMF01/Types/ShirtMF01_brutor02.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
308	310	{"_key": 310, "resPath": "Accessories/Glasses/Glasses_Pilot_01/Types/glasses_01_black.type", "resGender": 0, "empireRestrictions": [4]}
309	311	{"_key": 311, "resPath": "Makeup/Eyes/Eyes_05/Types/Eyes_05.type", "resGender": 0}
310	312	{"_key": 312, "resPath": "Makeup/Aging/Aging_02/Types/Aging_02.type", "resGender": 0}
311	313	{"_key": 313, "resPath": "Makeup/Implants/Plugs_01/Types/Plugs_01.type", "resGender": 1}
312	314	{"_key": 314, "resPath": "outer/RobeAM01/Types/RobeAM01_brown.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
313	315	{"_key": 315, "resPath": "Makeup/Eyes/Eyes_06/Types/Eyes_06.type", "resGender": 0}
314	316	{"_key": 316, "resPath": "Scars/Head/HeroScar04/Types/HeroScar04_v0.type", "resGender": 1}
315	317	{"_key": 317, "resPath": "bottomOuter/PantsCM01/Types/PantsCM01_civire.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
316	318	{"_key": 318, "resPath": "Feet/ShoesGM01/Types/ShoesGM01_gallente.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
317	319	{"_key": 319, "resPath": "outer/JacketCM01/Types/JacketCM01_generic01.type", "resGender": 1, "empireRestrictions": [8]}
318	320	{"_key": 320, "resPath": "bottomOuter/PantsAF01/Types/PantsAF01_generic02.type", "resGender": 0, "empireRestrictions": [2]}
319	321	{"_key": 321, "resPath": "Makeup/Eyeliner/Eyeliner_09/Types/Eyeliner_09.type", "resGender": 0}
320	322	{"_key": 322, "resPath": "topUnderwear/BikiniTopGF01/Types/BikiniTopGF01_gallente.type", "resGender": 0}
321	323	{"_key": 323, "resPath": "TopMiddle/ShirtCF01/Types/ShirtCF01_generic01.type", "resGender": 0, "empireRestrictions": [8]}
322	324	{"_key": 324, "resPath": "TopMiddle/ShirtMM01/Types/ShirtMM01_generic02.type", "resGender": 1, "empireRestrictions": [4]}
323	325	{"_key": 325, "resPath": "outer/JacketMM01/Types/JacketMM01_generic02.type", "resGender": 1, "empireRestrictions": [4]}
324	326	{"_key": 326, "resPath": "hair/Hair_Cornrows_01/Types/Hair_Cornrows_01.type", "resGender": 1, "empireRestrictions": [1, 4]}
325	327	{"_key": 327, "resPath": "Makeup/Eyes/Eyes_07/Types/Eyes_07.type", "resGender": 1}
326	328	{"_key": 328, "resPath": "Scars/Head/HeroScar10/Types/HeroScar10_v1.type", "resGender": 1}
327	329	{"_key": 329, "resPath": "TopMiddle/ShirtCM01/Types/ShirtCM01_generic01.type", "resGender": 1, "empireRestrictions": [8]}
328	330	{"_key": 330, "resPath": "Scars/Head/HeroScar08/Types/HeroScar08_v1.type", "resGender": 1}
329	331	{"_key": 331, "resPath": "bottomOuter/PantsCF01/Types/PantsCF01_deteis.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
330	332	{"_key": 332, "resPath": "outer/JacketAM01/Types/JacketAM01_generic02.type", "resGender": 1, "empireRestrictions": [2]}
331	333	{"_key": 333, "resPath": "TopMiddle/ShirtAF01/Types/ShirtAF01_generic01.type", "resGender": 0, "empireRestrictions": [2]}
332	334	{"_key": 334, "resPath": "Makeup/EyeShadow/Eyeshadow_05/Types/Eyeshadow_05.type", "resGender": 0}
333	335	{"_key": 335, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_generic02.type", "resGender": 1, "empireRestrictions": [1]}
334	336	{"_key": 336, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_gallente.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
335	337	{"_key": 337, "resPath": "Feet/BootsAF01/Types/BootsAF01_generic01.type", "resGender": 0, "empireRestrictions": [2]}
336	338	{"_key": 338, "resPath": "Outer/JacketCF01/Types/JacketCF01_achura.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
337	339	{"_key": 339, "resPath": "outer/JacketMM01/Types/JacketMM01_vherockior.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
338	340	{"_key": 340, "resPath": "outer/JacketGM01/Types/JacketGM01_gallente.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
339	341	{"_key": 341, "resPath": "bottomUnderwear/BoxersMM01/Types/sebiestor.type", "resGender": 1}
340	342	{"_key": 342, "resPath": "Scars/Head/HeroScar04/Types/HeroScar04_v1.type", "resGender": 0}
341	343	{"_key": 343, "resPath": "Makeup/Eyeshadow/Eyeshadow_02/Types/Eyeshadow_02.type", "resGender": 1}
342	344	{"_key": 344, "resPath": "Feet/BootsMM01/Types/BootsMM01_brutor.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
343	345	{"_key": 345, "resPath": "Feet/BootsMF01/Types/BootsMF01_vherokior.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
344	346	{"_key": 346, "resPath": "Makeup/Scarring/Scarring_01/Types/Scarring_01.type", "resGender": 0}
345	347	{"_key": 347, "resPath": "TopOuter/ShirtAM01/Types/ShirtAM01_generic02.type", "resGender": 1, "empireRestrictions": [2]}
346	348	{"_key": 348, "resPath": "Accessories/Lips/Ring05/Types/Ring05.type", "resGender": 0}
347	349	{"_key": 349, "resPath": "Scars/Head/HeroScar01/Types/HeroScar01_v0.type", "resGender": 1}
348	350	{"_key": 350, "resPath": "Accessories/Glasses/Glasses_Pilot_01/Types/glasses_01_red.type", "resGender": 0, "empireRestrictions": [4]}
349	351	{"_key": 351, "resPath": "Feet/BootsMF01/Types/BootsMF01_generic02.type", "resGender": 0, "empireRestrictions": [4]}
350	352	{"_key": 352, "resPath": "Scars/Head/HeroScar07/Types/HeroScar07_v1.type", "resGender": 0}
351	353	{"_key": 353, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_intaki.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
352	354	{"_key": 354, "resPath": "Feet/ShoesGM01/Types/ShoesGM01_generic01.type", "resGender": 1, "empireRestrictions": [1]}
353	355	{"_key": 355, "resPath": "Makeup/EyeShadow/Eyeshadow_04/Types/Eyeshadow_04.type", "resGender": 0}
354	356	{"_key": 356, "resPath": "hair/Hair_Medium_01/Types/Hair_Medium_01.type", "resGender": 1}
355	357	{"_key": 357, "resPath": "hair/Hair_PonytailShort_01/Types/Hair_PonytailShort_01.type", "resGender": 0}
356	358	{"_key": 358, "resPath": "Scars/Head/HeroScar14/Types/HeroScar14_v0.type", "resGender": 0}
357	359	{"_key": 359, "resPath": "outer/JacketAM01/Types/JacketAM01_nikunni.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
358	360	{"_key": 360, "resPath": "TopMiddle/ShirtCM01/Types/ShirtCM01_achura.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
359	361	{"_key": 361, "resPath": "bottomUnderwear/BikiniBottomAF01/Types/BikiniBottomAF01_nikunni.type", "resGender": 0}
360	362	{"_key": 362, "resPath": "Makeup/Eyes/Eyes_10/Types/Eyes_10.type", "resGender": 0}
361	363	{"_key": 363, "resPath": "Scars/Head/HeroScar04/Types/HeroScar04_v1.type", "resGender": 1}
362	364	{"_key": 364, "resPath": "topUnderwear/BikiniTopCF01/Types/BikiniTopCF01_civire.type", "resGender": 0}
363	365	{"_key": 365, "resPath": "Beard/Beard_10/Types/Beard_10.type", "resGender": 1}
364	366	{"_key": 366, "resPath": "hair/Hair_Ponytail_01/Types/Hair_Ponytail_01.type", "resGender": 0}
365	367	{"_key": 367, "resPath": "bottomUnderwear/BoxersGM01/Types/jinmei.type", "resGender": 1}
366	368	{"_key": 368, "resPath": "Scars/Head/HeroScar18/Types/HeroScar18_v1.type", "resGender": 0}
367	369	{"_key": 369, "resPath": "Scars/Head/HeroScar12/Types/HeroScar12_v1.type", "resGender": 1}
368	370	{"_key": 370, "resPath": "Feet/BootsGF01/Types/BootsGF01_gallente.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
369	371	{"_key": 371, "resPath": "hair/Hair_DreadLong_01/Types/Hair_DreadLong_01.type", "resGender": 1, "empireRestrictions": [1, 4]}
370	372	{"_key": 372, "resPath": "hair/Hair_Stubble_02/Types/Hair_Stubble_02.type", "resGender": 1}
371	373	{"_key": 373, "resPath": "Makeup/EyeShadow/Eyeshadow_08/Types/Eyeshadow_08.type", "resGender": 0}
372	374	{"_key": 374, "resPath": "bottomUnderwear/BikiniBottomCF01/Types/BikiniBottomCF01_deteis.type", "resGender": 0}
373	375	{"_key": 375, "resPath": "Makeup/Eyes/Eyes_03/Types/Eyes_03.type", "resGender": 0}
374	376	{"_key": 376, "resPath": "topUnderwear/BikiniTopGF01/Types/BikiniTopGF01_jinmei.type", "resGender": 0}
375	377	{"_key": 377, "resPath": "Feet/BootsCM01/Types/BootsCM01_achura.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
376	378	{"_key": 378, "resPath": "Scars/Head/HeroScar15/Types/HeroScar15_v1.type", "resGender": 1}
377	379	{"_key": 379, "resPath": "hair/Hair_ShortAfro_03/Types/Hair_ShortAfro_03.type", "resGender": 1, "empireRestrictions": [4]}
378	380	{"_key": 380, "resPath": "Feet/BootsCF01/Types/BootsCF01_generic01.type", "resGender": 0, "empireRestrictions": [8]}
379	381	{"_key": 381, "resPath": "Beard/Stubble/Types/Stubble.type", "resGender": 1}
380	382	{"_key": 382, "resPath": "Feet/BootsCF01/Types/BootsCF01_generic02.type", "resGender": 0, "empireRestrictions": [8]}
381	383	{"_key": 383, "resPath": "Scars/Head/HeroScar06/Types/HeroScar06_v0.type", "resGender": 1}
382	384	{"_key": 384, "resPath": "topUnderwear/BikiniTopGF01/Types/BikiniTopGF01_intaki.type", "resGender": 0}
383	385	{"_key": 385, "resPath": "Scars/Head/HeroScar14/Types/HeroScar14_v1.type", "resGender": 1}
384	386	{"_key": 386, "resPath": "hair/Hair_Implant_02/Types/Hair_Implant_02.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
385	387	{"_key": 387, "resPath": "hair/Hair_Receding_01/Types/Hair_Receding_01.type", "resGender": 1}
386	388	{"_key": 388, "resPath": "topUnderwear/BikiniTopMF01/Types/BikiniTopMF01_brutor.type", "resGender": 0}
387	389	{"_key": 389, "resPath": "Scars/Head/HeroScar07/Types/HeroScar07_v1.type", "resGender": 1}
388	390	{"_key": 390, "resPath": "Beard/Beard_01/Types/Beard_01.type", "resGender": 1}
389	391	{"_key": 391, "resPath": "Scars/Head/HeroScar11/Types/HeroScar11_v1.type", "resGender": 0}
390	392	{"_key": 392, "resPath": "Scars/Head/HeroScar01/Types/HeroScar01_v1.type", "resGender": 0}
391	393	{"_key": 393, "resPath": "Scars/Head/HeroScar02/Types/HeroScar02_v1.type", "resGender": 0}
392	394	{"_key": 394, "resPath": "Scars/Head/HeroScar07/Types/HeroScar07_v0.type", "resGender": 1}
393	395	{"_key": 395, "resPath": "TopMiddle/ShirtAF01/Types/ShirtAF01_nikunni.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
394	396	{"_key": 396, "resPath": "Scars/Head/HeroScar16/Types/HeroScar16_v1.type", "resGender": 1}
395	397	{"_key": 397, "resPath": "Feet/BootsCF01/Types/BootsCF01_civire.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
396	398	{"_key": 398, "resPath": "Feet/ShoesGM01/Types/ShoesGM01_jinmei.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
397	399	{"_key": 399, "resPath": "TopMiddle/ShirtMF01/Types/ShirtMF01_generic01.type", "resGender": 0, "empireRestrictions": [4]}
398	400	{"_key": 400, "resPath": "Scars/Head/HeroScar13/Types/HeroScar13_v1.type", "resGender": 1}
399	401	{"_key": 401, "resPath": "Scars/Head/HeroScar01/Types/HeroScar01_v1.type", "resGender": 1}
400	402	{"_key": 402, "resPath": "Makeup/Blush/Blush_02/Types/Blush_02.type", "resGender": 1}
401	403	{"_key": 403, "resPath": "Makeup/Eyes/Eyes_03/Types/Eyes_03.type", "resGender": 1}
402	404	{"_key": 404, "resPath": "hair/Hair_ShortTop_01/Types/Hair_ShortTop_01.type", "resGender": 0}
403	405	{"_key": 405, "resPath": "Feet/ShoesGM01/Types/ShoesGM01_intaki.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
404	406	{"_key": 406, "resPath": "hair/Hair_CornrowsPigtails_01/Types/Hair_CornrowsPigtails_01.type", "resGender": 0, "empireRestrictions": [1, 4]}
405	407	{"_key": 407, "resPath": "hair/Hair_Bob_02/Types/Hair_Bob_02.type", "resGender": 0}
406	408	{"_key": 408, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_extra02.type", "resGender": 0}
407	409	{"_key": 409, "resPath": "hair/Hair_Shortcut_02/Types/Hair_Shortcut_02.type", "resGender": 1, "empireRestrictions": [4]}
408	410	{"_key": 410, "resPath": "bottomUnderwear/BoxersAM01/Types/nikunni.type", "resGender": 1}
409	411	{"_key": 411, "resPath": "bottomUnderwear/BoxersGM01/Types/intaki.type", "resGender": 1}
410	412	{"_key": 412, "resPath": "hair/Hair_BackCombed_03/Types/Hair_BackCombed_03.type", "resGender": 1}
411	413	{"_key": 413, "resPath": "Accessories/Glasses/Glasses_Pilot_01/Types/glasses_01_green.type", "resGender": 1, "empireRestrictions": [4]}
412	414	{"_key": 414, "resPath": "hair/Hair_Dreadlocks_01/Types/Hair_Dreadlocks_01.type", "resGender": 0, "empireRestrictions": [1, 4]}
413	415	{"_key": 415, "resPath": "Makeup/EyeShadow/Eyeshadow_07/Types/Eyeshadow_07.type", "resGender": 0}
414	416	{"_key": 416, "resPath": "hair/Hair_MediumParted_02/Types/Hair_MediumParted_02.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
415	417	{"_key": 417, "resPath": "bottomOuter/PantsCM01/Types/PantsCM01_generic01.type", "resGender": 1, "empireRestrictions": [8]}
416	418	{"_key": 418, "resPath": "bottomOuter/PantsAM01/Types/PantsAM01_amarr.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
417	419	{"_key": 419, "resPath": "Feet/BootsCM01/Types/BootsCM01_generic01.type", "resGender": 1, "empireRestrictions": [8]}
418	420	{"_key": 420, "resPath": "Outer/JacketMF01/Types/JacketMF01_brutor.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
419	421	{"_key": 421, "resPath": "hair/Hair_ShortCut_03/Types/Hair_ShortCut_03.type", "resGender": 0}
420	422	{"_key": 422, "resPath": "bottomOuter/PantsCM01/Types/PantsCM01_achura.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
421	423	{"_key": 423, "resPath": "bottomOuter/PantsCM01/Types/PantsCM01_generic02.type", "resGender": 1, "empireRestrictions": [8]}
422	424	{"_key": 424, "resPath": "bottomOuter/PantsCM01/Types/PantsCM01_deteis.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
423	425	{"_key": 425, "resPath": "Makeup/Freckles/Freckles_02/Types/Freckles_02.type", "resGender": 1}
424	426	{"_key": 426, "resPath": "TopMiddle/ShirtCM01/Types/ShirtCM01_deteis.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
425	427	{"_key": 427, "resPath": "Feet/BootsMM01/Types/BootsMM01_vherockior.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
426	428	{"_key": 428, "resPath": "Feet/BootsCM01/Types/BootsCM01_deteis.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
427	429	{"_key": 429, "resPath": "Makeup/Blush/Blush_01/Types/Blush_01.type", "resGender": 0}
428	430	{"_key": 430, "resPath": "hair/Hair_MediumParted_03/Types/Hair_MediumParted_03.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
429	431	{"_key": 431, "resPath": "Scars/Head/HeroScar16/Types/HeroScar16_v1.type", "resGender": 0}
430	432	{"_key": 432, "resPath": "Scars/Head/HeroScar07/Types/HeroScar07_v0.type", "resGender": 0}
431	433	{"_key": 433, "resPath": "Makeup/Eyes/Eyes_04/Types/Eyes_04.type", "resGender": 1}
432	434	{"_key": 434, "resPath": "Makeup/Eyeliner/Eyeliner_10/Types/Eyeliner_10.type", "resGender": 0}
433	435	{"_key": 435, "resPath": "bottomUnderwear/BikiniBottomCF01/Types/BikiniBottomCF01_achura.type", "resGender": 0}
434	436	{"_key": 436, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_generic02.type", "resGender": 0, "empireRestrictions": [1]}
435	437	{"_key": 437, "resPath": "Outer/JacketAF01/Types/JacketAF01_khanid.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
436	438	{"_key": 438, "resPath": "Makeup/Lipstick/Lipstick_04/Types/Lipstick_04.type", "resGender": 0}
437	439	{"_key": 439, "resPath": "Scars/Head/HeroScar02/Types/HeroScar02_v0.type", "resGender": 0}
438	440	{"_key": 440, "resPath": "Makeup/EyeShadow/Eyeshadow_03/Types/Eyeshadow_03.type", "resGender": 0}
439	441	{"_key": 441, "resPath": "bottomOuter/PantsMF01/Types/PantsMF01_generic01.type", "resGender": 0, "empireRestrictions": [4]}
440	442	{"_key": 442, "resPath": "topUnderwear/BikiniTopAF01/Types/BikiniTopAF01_khanid.type", "resGender": 0}
441	443	{"_key": 443, "resPath": "Accessories/Glasses/Glasses_Pilot_01/Types/glasses_01_red.type", "resGender": 1, "empireRestrictions": [4]}
442	444	{"_key": 444, "resPath": "Makeup/Eyebrows/Eyebrows_05/Types/Eyebrows_05.type", "resGender": 0}
443	445	{"_key": 445, "resPath": "hair/Hair_Bun_02/Types/Hair_Bun_02.type", "resGender": 0}
444	446	{"_key": 446, "resPath": "Outer/JacketMF01/Types/JacketMF01_generic02.type", "resGender": 0, "empireRestrictions": [4]}
445	447	{"_key": 447, "resPath": "Beard/Beard_09/Types/Beard_09.type", "resGender": 1}
446	448	{"_key": 448, "resPath": "Accessories/Glasses/Glasses_Pilot_01/Types/glasses_01_green.type", "resGender": 0, "empireRestrictions": [4]}
447	449	{"_key": 449, "resPath": "topUnderwear/BikiniTopCF01/Types/BikiniTopCF01_deteis.type", "resGender": 0}
448	450	{"_key": 450, "resPath": "Accessories/Glasses/Glasses_Pilot_01/Types/glasses_01_brown.type", "resGender": 0, "empireRestrictions": [4]}
449	451	{"_key": 451, "resPath": "Makeup/EyeLashes/EyeLashes_01/Types/EyeLashes_01.type", "resGender": 0}
450	452	{"_key": 452, "resPath": "hair/Hair_BraidedBun_02/Types/Hair_BraidedBun_02.type", "resGender": 0, "empireRestrictions": [2, 8]}
451	453	{"_key": 453, "resPath": "Beard/Beard_07/Types/Beard_07.type", "resGender": 1}
452	454	{"_key": 454, "resPath": "Makeup/EyeShadow/Eyeshadow_02/Types/Eyeshadow_02.type", "resGender": 0}
453	455	{"_key": 455, "resPath": "Makeup/Lipstick/Lipstick_03/Types/Lipstick_03.type", "resGender": 0}
454	456	{"_key": 456, "resPath": "Accessories/Glasses/Goggles_01/Types/goggles_01_v1.type", "resGender": 0}
455	457	{"_key": 457, "resPath": "Accessories/Glasses/Glasses_Slick_01/Types/Glasses_Slick_01.type", "resGender": 0, "empireRestrictions": [4]}
456	458	{"_key": 458, "resPath": "Accessories/Glasses/Goggles_01/Types/goggles_01_v0.type", "resGender": 0}
457	459	{"_key": 459, "resPath": "Tattoo/Head/Head1/Types/Head1.type", "resGender": 1}
458	460	{"_key": 460, "resPath": "Accessories/Glasses/Goggles_01/Types/goggles_01_v0.type", "resGender": 1}
459	461	{"_key": 461, "resPath": "Accessories/Glasses/Glasses_Slick_01/Types/Glasses_Slick_01.type", "resGender": 1, "empireRestrictions": [4]}
460	462	{"_key": 462, "resPath": "Tattoo/Head/Head2/Types/Head2.type", "resGender": 1}
461	463	{"_key": 463, "resPath": "Tattoo/Head/Head2/Types/Head2.type", "resGender": 0}
462	464	{"_key": 464, "typeID": 3958, "resPath": "Accessories/Glasses/Goggles_01/Types/goggles_01.type", "resGender": 1}
463	465	{"_key": 465, "resPath": "Tattoo/Head/Head1/Types/Head1.type", "resGender": 0}
464	466	{"_key": 466, "resPath": "Tattoo/Head/TattooFaceG01/Types/TattooFaceG01.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
465	467	{"_key": 467, "resPath": "Tattoo/Head/TattooFaceM01/Types/TattooFaceM01.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
466	468	{"_key": 468, "resPath": "Tattoo/Head/TattooFaceM05/Types/TattooFaceM05.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
467	469	{"_key": 469, "resPath": "Tattoo/Head/TattooFaceG03/Types/TattooFaceG03.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
468	470	{"_key": 470, "resPath": "Tattoo/Head/TattooFaceA03/Types/TattooFaceA03.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
469	471	{"_key": 471, "resPath": "Tattoo/Head/TattooFaceM07/Types/TattooFaceM07.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
470	472	{"_key": 472, "resPath": "Tattoo/Head/TattooFaceG06/Types/TattooFaceG06.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
471	473	{"_key": 473, "resPath": "Tattoo/Head/TattooFaceG07/Types/TattooFaceG07.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
472	474	{"_key": 474, "resPath": "Tattoo/Head/TattooFaceG04/Types/TattooFaceG04.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
473	475	{"_key": 475, "resPath": "Tattoo/Head/TattooFaceG01/Types/TattooFaceG01.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
474	476	{"_key": 476, "resPath": "Tattoo/Head/TattooFaceG05/Types/TattooFaceG05.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
475	477	{"_key": 477, "resPath": "Tattoo/Head/TattooFaceC04/Types/TattooFaceC04.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
476	478	{"_key": 478, "resPath": "Tattoo/Head/TattooFaceA05/Types/TattooFaceA05.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
477	479	{"_key": 479, "resPath": "Tattoo/Head/TattooFaceM02/Types/TattooFaceM02.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
478	480	{"_key": 480, "resPath": "Tattoo/Head/TattooFaceC01/Types/TattooFaceC01.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
479	481	{"_key": 481, "resPath": "Tattoo/Head/TattooFaceG02/Types/TattooFaceG02.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
480	482	{"_key": 482, "resPath": "Tattoo/Head/TattooFaceM09/Types/TattooFaceM09.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
481	483	{"_key": 483, "resPath": "Tattoo/Head/TattooFaceM11/Types/TattooFaceM11.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
482	484	{"_key": 484, "resPath": "Tattoo/Head/TattooFaceG09/Types/TattooFaceG09.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
483	485	{"_key": 485, "resPath": "Tattoo/Head/TattooFaceM07/Types/TattooFaceM07.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
484	486	{"_key": 486, "resPath": "Tattoo/Head/TattooFaceM02/Types/TattooFaceM02.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
485	487	{"_key": 487, "resPath": "Tattoo/Head/TattooFaceC02/Types/TattooFaceC02.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
486	488	{"_key": 488, "resPath": "Tattoo/Head/TattooFaceC02/Types/TattooFaceC02.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
487	489	{"_key": 489, "resPath": "Tattoo/Head/TattooFaceM05/Types/TattooFaceM05.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
488	490	{"_key": 490, "resPath": "Tattoo/Head/TattooFaceG09/Types/TattooFaceG09.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
489	491	{"_key": 491, "resPath": "Tattoo/Head/TattooFaceM06/Types/TattooFaceM06.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
490	492	{"_key": 492, "resPath": "Tattoo/Head/TattooFaceC04/Types/TattooFaceC04.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
491	493	{"_key": 493, "resPath": "Tattoo/Head/TattooFaceA05/Types/TattooFaceA05.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
492	494	{"_key": 494, "resPath": "Tattoo/Head/TattooFaceA02/Types/TattooFaceA02.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
493	495	{"_key": 495, "resPath": "Tattoo/Head/TattooFaceM11/Types/TattooFaceM11.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
494	496	{"_key": 496, "resPath": "Tattoo/Head/TattooFaceG06/Types/TattooFaceG06.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
495	497	{"_key": 497, "resPath": "Tattoo/Head/TattooFaceA04/Types/TattooFaceA04.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
496	498	{"_key": 498, "resPath": "Tattoo/Head/TattooFaceM10/Types/TattooFaceM10.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
497	499	{"_key": 499, "resPath": "Tattoo/Head/TattooFaceG05/Types/TattooFaceG05.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
498	500	{"_key": 500, "resPath": "Tattoo/Head/TattooFaceA04/Types/TattooFaceA04.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
499	501	{"_key": 501, "resPath": "Tattoo/Head/TattooFaceG08/Types/TattooFaceG08.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
500	502	{"_key": 502, "resPath": "Tattoo/Head/TattooFaceM09/Types/TattooFaceM09.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
501	503	{"_key": 503, "resPath": "Tattoo/Head/TattooFaceC01/Types/TattooFaceC01.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
502	504	{"_key": 504, "resPath": "Tattoo/Head/TattooFaceA01/Types/TattooFaceA01.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
503	505	{"_key": 505, "resPath": "Tattoo/Head/TattooFaceA01/Types/TattooFaceA01.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
504	506	{"_key": 506, "resPath": "Tattoo/Head/TattooFaceG02/Types/TattooFaceG02.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
505	507	{"_key": 507, "resPath": "Tattoo/Head/TattooFaceG08/Types/TattooFaceG08.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
506	508	{"_key": 508, "resPath": "Tattoo/Head/TattooFaceC03/Types/TattooFaceC03.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
507	509	{"_key": 509, "resPath": "Tattoo/Head/TattooFaceM03/Types/TattooFaceM03.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
508	510	{"_key": 510, "resPath": "Tattoo/Head/TattooFaceA02/Types/TattooFaceA02.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
509	511	{"_key": 511, "resPath": "Tattoo/Head/TattooFaceM04/Types/TattooFaceM04.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
510	512	{"_key": 512, "resPath": "Tattoo/Head/TattooFaceM10/Types/TattooFaceM10.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
511	513	{"_key": 513, "resPath": "Tattoo/Head/TattooFaceG04/Types/TattooFaceG04.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
512	514	{"_key": 514, "resPath": "Tattoo/Head/TattooFaceM12/Types/TattooFaceM12.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
513	515	{"_key": 515, "resPath": "Tattoo/Head/TattooFaceM13/Types/TattooFaceM13.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
514	516	{"_key": 516, "resPath": "Tattoo/Head/TattooFaceM06/Types/TattooFaceM06.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
515	517	{"_key": 517, "resPath": "Tattoo/Head/TattooFaceM13/Types/TattooFaceM13.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
516	518	{"_key": 518, "resPath": "Tattoo/Head/TattooFaceG03/Types/TattooFaceG03.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
517	519	{"_key": 519, "resPath": "Tattoo/Head/TattooFaceM01/Types/TattooFaceM01.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
518	520	{"_key": 520, "resPath": "Tattoo/Head/TattooFaceM12/Types/TattooFaceM12.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
519	521	{"_key": 521, "resPath": "Tattoo/Head/TattooFaceM08/Types/TattooFaceM08.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
520	522	{"_key": 522, "resPath": "Tattoo/Head/TattooFaceM04/Types/TattooFaceM04.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
521	523	{"_key": 523, "resPath": "Tattoo/Head/TattooFaceG10/Types/TattooFaceG10.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
522	524	{"_key": 524, "resPath": "Tattoo/Head/TattooFaceG07/Types/TattooFaceG07.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
523	525	{"_key": 525, "resPath": "Tattoo/Head/TattooFaceM03/Types/TattooFaceM03.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
524	526	{"_key": 526, "resPath": "Tattoo/Head/TattooFaceC03/Types/TattooFaceC03.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
525	527	{"_key": 527, "resPath": "Tattoo/Head/TattooFaceG10/Types/TattooFaceG10.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
526	528	{"_key": 528, "resPath": "Tattoo/Head/TattooFaceM08/Types/TattooFaceM08.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
527	529	{"_key": 529, "resPath": "Tattoo/Head/TattooFaceA03/Types/TattooFaceA03.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
528	549	{"_key": 549, "resPath": "Tattoo/Head/TattooElabM02/Types/TattooElabM02.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
529	550	{"_key": 550, "resPath": "Tattoo/Head/TattooElabM05/Types/TattooElabM05.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
530	551	{"_key": 551, "resPath": "Tattoo/Head/TattooElabM01/Types/TattooElabM01.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
531	552	{"_key": 552, "resPath": "Tattoo/Head/TattooElabM05/Types/TattooElabM05.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
532	553	{"_key": 553, "resPath": "Tattoo/Head/TattooElabM04/Types/TattooElabM04.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
533	554	{"_key": 554, "resPath": "Tattoo/Head/TattooElabM01/Types/TattooElabM01.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
534	555	{"_key": 555, "resPath": "Tattoo/Head/TattooElabM02/Types/TattooElabM02.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
535	556	{"_key": 556, "resPath": "Tattoo/Head/TattooElabM03/Types/TattooElabM03.type", "resGender": 0, "empireRestrictions": [1, 4, 8]}
536	557	{"_key": 557, "resPath": "Tattoo/Head/TattooElabM04/Types/TattooElabM04.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
537	558	{"_key": 558, "resPath": "Tattoo/Head/TattooElabM03/Types/TattooElabM03.type", "resGender": 1, "empireRestrictions": [1, 4, 8]}
538	559	{"_key": 559, "resPath": "Archetypes/AKShape/Types/Khanid.type", "resGender": 0}
539	560	{"_key": 560, "resPath": "Tattoo/Head/TattooFaceG10R/Types/TattooFaceG10R.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
540	561	{"_key": 561, "resPath": "Archetypes/GGShape/Types/Gallente.type", "resGender": 0}
541	562	{"_key": 562, "resPath": "Tattoo/Head/TattooFaceG07R/Types/TattooFaceG07R.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
542	563	{"_key": 563, "resPath": "TopMiddle/TanktopM01/Types/TanktopM01_generic03.type", "resGender": 1}
543	564	{"_key": 564, "resPath": "Tattoo/Head/TattooFaceA02R/Types/TattooFaceA02R.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
544	565	{"_key": 565, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_generic02.type", "resGender": 0}
545	566	{"_key": 566, "resPath": "Archetypes/GJMShape/Types/JinMei.type", "resGender": 0}
546	567	{"_key": 567, "resPath": "Tattoo/Head/TattooFaceA05R/Types/TattooFaceA05R.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
547	568	{"_key": 568, "resPath": "Tattoo/Head/TattooFaceG06R/Types/TattooFaceG06R.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
548	569	{"_key": 569, "resPath": "Archetypes/CDShape/Types/Deites.type", "resGender": 0}
549	570	{"_key": 570, "resPath": "Tattoo/Head/TattooFaceA04R/Types/TattooFaceA04R.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
550	571	{"_key": 571, "resPath": "Tattoo/Head/TattooFaceG05R/Types/TattooFaceG05R.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
551	572	{"_key": 572, "resPath": "Tattoo/Head/TattooFaceC01R/Types/TattooFaceC01R.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
552	573	{"_key": 573, "resPath": "Tattoo/Head/TattooFaceC03R/Types/TattooFaceC03R.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
553	574	{"_key": 574, "resPath": "Archetypes/AAShape/Types/Amarr.type", "resGender": 0}
554	575	{"_key": 575, "resPath": "Tattoo/Head/TattooFaceC02R/Types/TattooFaceC02R.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
555	576	{"_key": 576, "resPath": "Tattoo/Head/TattooFaceG05R/Types/TattooFaceG05R.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
556	577	{"_key": 577, "resPath": "Archetypes/ANShape/Types/Nikunni.type", "resGender": 0}
557	578	{"_key": 578, "resPath": "Tattoo/Head/TattooFaceG04R/Types/TattooFaceG04R.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
558	579	{"_key": 579, "resPath": "Tattoo/Head/TattooFaceG10R/Types/TattooFaceG10R.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
559	580	{"_key": 580, "resPath": "Accessories/Glasses/Glasses_Slick_01/Types/Glasses_Slick_01_black.type", "resGender": 0, "empireRestrictions": [4]}
560	581	{"_key": 581, "resPath": "Tattoo/Head/TattooFaceA03R/Types/TattooFaceA03R.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
561	582	{"_key": 582, "resPath": "Accessories/Glasses/Glasses_Slick_01/Types/Glasses_Slick_01_black.type", "resGender": 1, "empireRestrictions": [4]}
562	583	{"_key": 583, "resPath": "Tattoo/Head/TattooFaceA02R/Types/TattooFaceA02R.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
563	584	{"_key": 584, "resPath": "Archetypes/CAShape/Types/Achura.type", "resGender": 0}
564	585	{"_key": 585, "resPath": "Archetypes/CCShape/Types/Civire.type", "resGender": 0}
565	586	{"_key": 586, "resPath": "Tattoo/Head/TattooFaceC02R/Types/TattooFaceC02R.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
566	587	{"_key": 587, "resPath": "Archetypes/MVShape/Types/Verokior.type", "resGender": 0}
567	588	{"_key": 588, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_generic03.type", "resGender": 0}
568	589	{"_key": 589, "resPath": "Accessories/Glasses/Glasses_Slick_01/Types/Glasses_Slick_01_blue.type", "resGender": 0, "empireRestrictions": [4]}
569	590	{"_key": 590, "resPath": "Accessories/Glasses/Glasses_Slick_01/Types/Glasses_Slick_01_blue.type", "resGender": 1, "empireRestrictions": [4]}
570	591	{"_key": 591, "resPath": "Tattoo/Head/TattooFaceC03R/Types/TattooFaceC03R.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
571	592	{"_key": 592, "resPath": "TopMiddle/TanktopM01/Types/TanktopM01_generic02.type", "resGender": 1}
572	593	{"_key": 593, "resPath": "Tattoo/Head/TattooFaceC04R/Types/TattooFaceC04R.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
573	594	{"_key": 594, "resPath": "Tattoo/Head/TattooFaceC01R/Types/TattooFaceC01R.type", "resGender": 1, "empireRestrictions": [2, 4, 8]}
574	595	{"_key": 595, "resPath": "Tattoo/Head/TattooFaceA04R/Types/TattooFaceA04R.type", "resGender": 1, "empireRestrictions": [1, 2, 8]}
575	596	{"_key": 596, "resPath": "Tattoo/Head/TattooFaceA03R/Types/TattooFaceA03R.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
576	597	{"_key": 597, "resPath": "Tattoo/Head/TattooFaceC04R/Types/TattooFaceC04R.type", "resGender": 0, "empireRestrictions": [2, 4, 8]}
577	598	{"_key": 598, "resPath": "Accessories/Glasses/Glasses_Slick_01/Types/Glasses_Slick_01_brown.type", "resGender": 1, "empireRestrictions": [4]}
578	599	{"_key": 599, "resPath": "Tattoo/Head/TattooFaceA05R/Types/TattooFaceA05R.type", "resGender": 0, "empireRestrictions": [1, 2, 8]}
579	600	{"_key": 600, "resPath": "Archetypes/MBShape/Types/Brutor.type", "resGender": 0}
580	601	{"_key": 601, "resPath": "Tattoo/Head/TattooFaceG06R/Types/TattooFaceG06R.type", "resGender": 1, "empireRestrictions": [1, 2, 4]}
581	602	{"_key": 602, "resPath": "Archetypes/MSShape/Types/Sebiestor.type", "resGender": 0}
582	603	{"_key": 603, "resPath": "Archetypes/GIShape/Types/Intaki.type", "resGender": 0}
583	604	{"_key": 604, "resPath": "Tattoo/Head/TattooFaceG07R/Types/TattooFaceG07R.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
584	605	{"_key": 605, "resPath": "Tattoo/Head/TattooFaceG04R/Types/TattooFaceG04R.type", "resGender": 0, "empireRestrictions": [1, 2, 4]}
585	606	{"_key": 606, "resPath": "Accessories/Glasses/Glasses_Slick_01/Types/Glasses_Slick_01_brown.type", "resGender": 0, "empireRestrictions": [4]}
586	607	{"_key": 607, "resPath": "Accessories/Piercings/Stud08/Types/Stud08.type", "resGender": 0}
587	608	{"_key": 608, "resPath": "Accessories/Chin/Stud13_RightA/Types/Stud13_RightA.type", "resGender": 0}
588	609	{"_key": 609, "resPath": "Accessories/Lips/Ring05_PairA/Types/Ring05_PairA.type", "resGender": 1}
589	610	{"_key": 610, "resPath": "Accessories/EarsLow/Stud01_RightA/Types/Stud01_RightA.type", "resGender": 0}
590	611	{"_key": 611, "resPath": "Accessories/EarsHigh/Ring01_LeftA/Types/Ring01_LeftA.type", "resGender": 1}
591	612	{"_key": 612, "resPath": "Accessories/Lips/Ring02_RightA/Types/Ring02_RightA.type", "resGender": 0}
592	613	{"_key": 613, "resPath": "Accessories/EarsLow/Stud06_PairA/Types/Stud06_PairA.type", "resGender": 1}
593	614	{"_key": 614, "resPath": "Accessories/EarsLow/Earring01_PairA/Types/Earring01_PairA.type", "resGender": 0}
594	615	{"_key": 615, "resPath": "Accessories/EarsLow/Stud02_RightC/Types/Stud02_RightC.type", "resGender": 0}
595	616	{"_key": 616, "resPath": "Accessories/Lips/Ring03_CenterA/Types/Ring03_CenterA.type", "resGender": 0}
596	617	{"_key": 617, "resPath": "Accessories/EarsLow/Ring06_LeftC/Types/Ring06_LeftC.type", "resGender": 1}
597	618	{"_key": 618, "resPath": "Accessories/Lips/Ring03_RightA/Types/Ring03_RightA.type", "resGender": 0}
598	619	{"_key": 619, "resPath": "Accessories/EarsLow/Ring05_LeftA/Types/Ring05_LeftA.type", "resGender": 0}
599	620	{"_key": 620, "resPath": "Accessories/EarsLow/Stud07_LeftA/Types/Stud07_LeftA.type", "resGender": 0}
600	621	{"_key": 621, "resPath": "Accessories/Brow/Stud11_PairA/Types/Stud11_PairA.type", "resGender": 1}
601	622	{"_key": 622, "resPath": "Accessories/Piercings/Ring03/Types/LipLower03.type", "resGender": 0}
602	623	{"_key": 623, "resPath": "Accessories/Lips/Ring05_LeftA/Types/Ring05_LeftA.type", "resGender": 0}
603	624	{"_key": 624, "resPath": "Accessories/Nose/Ring01_RightA/Types/Ring01_RightA.type", "resGender": 1}
604	625	{"_key": 625, "resPath": "Accessories/Piercings/Pin01/Types/Ring04.type", "resGender": 1}
605	626	{"_key": 626, "resPath": "Accessories/EarsLow/Earring02/Types/Earring02.type", "resGender": 0}
606	627	{"_key": 627, "resPath": "Accessories/EarsLow/Ring06_RightC/Types/Ring06_RightC.type", "resGender": 1}
607	628	{"_key": 628, "resPath": "Accessories/EarsLow/Stud02_RightB/Types/Stud02_RightB.type", "resGender": 0}
608	629	{"_key": 629, "resPath": "Accessories/EarsHigh/Stud09_RightA/Types/Stud09_RightA.type", "resGender": 1}
609	630	{"_key": 630, "resPath": "Accessories/Lips/Ring02_CenterA/Types/Ring02_CenterA.type", "resGender": 0}
610	631	{"_key": 631, "resPath": "Accessories/EarsLow/Ring05_LeftB/Types/Ring05_LeftB.type", "resGender": 1}
611	632	{"_key": 632, "resPath": "Accessories/Lips/Ring03_PairA/Types/Ring03_PairA.type", "resGender": 0}
612	633	{"_key": 633, "resPath": "Accessories/Chin/Stud12_PairA/Types/Stud12_PairA.type", "resGender": 1}
613	634	{"_key": 634, "resPath": "Accessories/EarsLow/Earring03_RightA/Types/Earring03_RightA.type", "resGender": 1}
614	635	{"_key": 635, "resPath": "Accessories/Piercings/Stud02/Types/Stud02.type", "resGender": 0}
615	636	{"_key": 636, "resPath": "Accessories/Chin/Stud05_CenterA/Types/Stud05_CenterA.type", "resGender": 0}
616	637	{"_key": 637, "resPath": "Accessories/EarsLow/Ring06_LeftB/Types/Ring06_LeftB.type", "resGender": 1}
617	638	{"_key": 638, "resPath": "Accessories/Chin/Stud02_PairA/Types/Stud02_PairA.type", "resGender": 0}
618	639	{"_key": 639, "resPath": "Accessories/EarsLow/Stud02_RightA/Types/Stud02_RightA.type", "resGender": 0}
619	640	{"_key": 640, "resPath": "Accessories/EarsHigh/Stud01_LeftD/Types/Stud01_LeftD.type", "resGender": 0}
620	641	{"_key": 641, "resPath": "Accessories/Chin/Stud02_RightA/Types/Stud02_RightA.type", "resGender": 0}
621	642	{"_key": 642, "resPath": "Accessories/EarsLow/Ring05_PairB/Types/Ring05_PairB.type", "resGender": 0}
622	643	{"_key": 643, "resPath": "Accessories/EarsLow/Stud06_LeftA/Types/Stud06_LeftA.type", "resGender": 1}
623	644	{"_key": 644, "resPath": "Accessories/EarsHigh/Stud01_PairD/Types/Stud01_PairD.type", "resGender": 0}
624	645	{"_key": 645, "resPath": "Accessories/Piercings/Stud04/Types/Stud04.type", "resGender": 0}
625	646	{"_key": 646, "resPath": "Accessories/Piercings/Stud11/Types/Stud11.type", "resGender": 0}
626	647	{"_key": 647, "resPath": "Accessories/EarsLow/Earring02_RightA/Types/Earring02_RightA.type", "resGender": 0}
627	648	{"_key": 648, "resPath": "Accessories/Lips/Ring03_LeftA/Types/Ring03_LeftA.type", "resGender": 0}
628	649	{"_key": 649, "resPath": "Accessories/EarsLow/Ring03_RightB/Types/Ring03_RightB.type", "resGender": 0}
629	650	{"_key": 650, "resPath": "Accessories/EarsLow/Stud07_RightA/Types/Stud07_RightA.type", "resGender": 0}
630	651	{"_key": 651, "resPath": "Accessories/Chin/Stud05_LeftA/Types/Stud05_LeftA.type", "resGender": 1}
631	652	{"_key": 652, "resPath": "Accessories/EarsLow/Ring03_LeftA/Types/Ring03_LeftA.type", "resGender": 0}
632	653	{"_key": 653, "resPath": "Accessories/Piercings/JewelryForheadF01/Types/JewelryForhead.type", "resGender": 0}
633	654	{"_key": 654, "resPath": "Accessories/EarsLow/Types/EarsLow.type", "resGender": 0}
634	655	{"_key": 655, "resPath": "Accessories/EarsLow/Ring06_LeftA/Types/Ring06_LeftA.type", "resGender": 1}
635	656	{"_key": 656, "resPath": "Accessories/EarsHigh/Types/EarsHigh.type", "resGender": 0}
636	657	{"_key": 657, "resPath": "Accessories/Lips/Stud02_RightB/Types/Stud02_RightB.type", "resGender": 0}
637	658	{"_key": 658, "resPath": "Accessories/EarsHigh/Ring01_RightC/Types/Ring01_RightC.type", "resGender": 1}
638	659	{"_key": 659, "resPath": "Accessories/EarsLow/Earring02_PairA/Types/Earring02_PairA.type", "resGender": 0}
639	660	{"_key": 660, "resPath": "Accessories/Lips/Ring06_CenterA/Types/Ring06_CenterA.type", "resGender": 1}
640	661	{"_key": 661, "resPath": "Accessories/EarsHigh/Ring01_RightC/Types/Ring01_RightC.type", "resGender": 0}
641	662	{"_key": 662, "resPath": "Accessories/Chin/Stud02_CenterA/Types/Stud02_CenterA.type", "resGender": 1}
642	663	{"_key": 663, "resPath": "Accessories/EarsLow/Stud10_LeftA/Types/Stud10_LeftA.type", "resGender": 0}
643	664	{"_key": 664, "resPath": "Accessories/EarsHigh/Stud09_LeftB/Types/Stud09_LeftB.type", "resGender": 0}
644	665	{"_key": 665, "resPath": "Accessories/Lips/Types/Lips.type", "resGender": 0}
645	666	{"_key": 666, "resPath": "Accessories/EarsLow/Ring03_PairB/Types/Ring03_PairB.type", "resGender": 0}
646	667	{"_key": 667, "resPath": "Accessories/Piercings/Earring01/Types/Stud02.type", "resGender": 0}
647	668	{"_key": 668, "resPath": "Accessories/Lips/Ring01_RightA/Types/Ring01_RightA.type", "resGender": 1}
648	669	{"_key": 669, "resPath": "Accessories/Piercings/Stud07/Types/Stud02.type", "resGender": 0}
649	670	{"_key": 670, "resPath": "Accessories/Piercings/Stud11/Types/Stud11.type", "resGender": 1}
650	671	{"_key": 671, "resPath": "Accessories/EarsLow/Ring05_RightA/Types/Ring05_RightA.type", "resGender": 1}
651	672	{"_key": 672, "resPath": "Accessories/EarsHigh/Ring01_LeftA/Types/Ring01_LeftA.type", "resGender": 0}
652	673	{"_key": 673, "resPath": "Accessories/EarsLow/Ring05_PairC/Types/Ring05_PairC.type", "resGender": 1}
653	674	{"_key": 674, "resPath": "Accessories/EarsHigh/Ring01_LeftB/Types/Ring01_LeftB.type", "resGender": 1}
654	675	{"_key": 675, "resPath": "Accessories/EarsLow/Stud10_RightA/Types/Stud10_RightA.type", "resGender": 1}
655	676	{"_key": 676, "resPath": "Accessories/EarsLow/Ring02_LeftC/Types/Ring02_LeftC.type", "resGender": 0}
656	677	{"_key": 677, "resPath": "Accessories/EarsLow/Stud01_RightC/Types/Stud01_RightC.type", "resGender": 0}
657	678	{"_key": 678, "resPath": "Accessories/Lips/Ring05_LeftA/Types/Ring05_LeftA.type", "resGender": 1}
658	679	{"_key": 679, "resPath": "Accessories/EarsHigh/Ring01_RightB/Types/Ring01_RightB.type", "resGender": 1}
659	680	{"_key": 680, "resPath": "Accessories/Chin/Stud11_CenterA/Types/Stud11_CenterA.type", "resGender": 0}
660	681	{"_key": 681, "resPath": "Accessories/EarsLow/Ring05_PairA/Types/Ring05_PairA.type", "resGender": 1}
661	682	{"_key": 682, "resPath": "Accessories/EarsLow/Stud04_LeftA/Types/Stud04_LeftA.type", "resGender": 0}
662	683	{"_key": 683, "resPath": "Accessories/EarsLow/Ring05_LeftB/Types/Ring05_LeftB.type", "resGender": 0}
663	684	{"_key": 684, "resPath": "Accessories/Chin/Stud02_RightA/Types/Stud02_RightA.type", "resGender": 1}
664	685	{"_key": 685, "resPath": "Accessories/EarsLow/Ring06_RightA/Types/Ring06_RightA.type", "resGender": 0}
665	686	{"_key": 686, "resPath": "Accessories/Chin/Stud12_RightA/Types/Stud12_RightA.type", "resGender": 1}
666	687	{"_key": 687, "resPath": "Accessories/EarsLow/Ring05_RightA/Types/Ring05_RightA.type", "resGender": 0}
667	688	{"_key": 688, "resPath": "Accessories/EarsLow/Stud01_LeftB/Types/Stud01_LeftB.type", "resGender": 0}
668	689	{"_key": 689, "resPath": "Accessories/EarsHigh/Ring01_RightB/Types/Ring01_RightB.type", "resGender": 0}
669	690	{"_key": 690, "resPath": "Accessories/Lips/Ring06_PairA/Types/Ring06_PairA.type", "resGender": 0}
670	691	{"_key": 691, "resPath": "Accessories/EarsLow/Ring03_LeftB/Types/Ring03_LeftB.type", "resGender": 0}
671	692	{"_key": 692, "resPath": "Accessories/Chin/Stud11_RightA/Types/Stud11_RightA.type", "resGender": 1}
672	693	{"_key": 693, "resPath": "Accessories/Chin/Stud02_LeftA/Types/Stud02_LeftA.type", "resGender": 0}
673	694	{"_key": 694, "resPath": "Accessories/EarsLow/Ring05_LeftC/Types/Ring05_LeftC.type", "resGender": 0}
674	695	{"_key": 695, "resPath": "Accessories/Chin/Types/Chin.type", "resGender": 0}
675	696	{"_key": 696, "resPath": "Accessories/Nose/Pin01_CenterB/Types/Pin01_CenterB.type", "resGender": 0}
676	697	{"_key": 697, "resPath": "Accessories/Nose/Stud01_RightA/Types/Stud01_RightA.type", "resGender": 0}
677	698	{"_key": 698, "resPath": "Accessories/EarsHigh/Stud13_RightD/Types/Stud13_RightD.type", "resGender": 0}
678	699	{"_key": 699, "resPath": "Accessories/EarsLow/Ring01_RightB/Types/Ring01_RightB.type", "resGender": 1}
679	700	{"_key": 700, "resPath": "Accessories/EarsLow/Ring06_RightB/Types/Ring06_RightB.type", "resGender": 0}
680	701	{"_key": 701, "resPath": "Accessories/EarsLow/Ring01_LeftC/Types/Ring01_LeftC.type", "resGender": 1}
681	702	{"_key": 702, "resPath": "Accessories/Piercings/Stud09/Types/Stud09.type", "resGender": 0}
682	703	{"_key": 703, "resPath": "Accessories/Brow/Stud12_PairA/Types/Stud12_PairA.type", "resGender": 1}
683	704	{"_key": 704, "resPath": "Accessories/EarsLow/Stud07_PairA/Types/Stud07_PairA.type", "resGender": 0}
684	705	{"_key": 705, "resPath": "Accessories/Lips/Ring01_RightA/Types/Ring01_RightA.type", "resGender": 0}
685	706	{"_key": 706, "resPath": "Accessories/EarsLow/Stud10_PairA/Types/Stud10_PairA.type", "resGender": 1}
686	707	{"_key": 707, "resPath": "Accessories/EarsLow/Stud13_RightB/Types/Stud13_RightB.type", "resGender": 0}
687	708	{"_key": 708, "resPath": "Accessories/EarsLow/Ring05_RightC/Types/Ring05_RightC.type", "resGender": 0}
688	709	{"_key": 709, "resPath": "Accessories/EarsLow/Stud02_LeftA/Types/Stud02_LeftA.type", "resGender": 0}
689	710	{"_key": 710, "resPath": "Accessories/EarsLow/Stud13_RightC/Types/Stud13_RightC.type", "resGender": 0}
690	711	{"_key": 711, "resPath": "Accessories/Lips/Ring01_PairA/Types/Ring01_PairA.type", "resGender": 1}
691	712	{"_key": 712, "resPath": "Accessories/EarsLow/Stud04_RightA/Types/Stud04_RightA.type", "resGender": 1}
692	713	{"_key": 713, "resPath": "Accessories/Nose/Types/Nose.type", "resGender": 1}
693	714	{"_key": 714, "resPath": "Accessories/EarsLow/Stud04_RightA/Types/Stud04_RightA.type", "resGender": 0}
694	715	{"_key": 715, "resPath": "Accessories/EarsLow/Stud01_LeftC/Types/Stud01_LeftC.type", "resGender": 0}
695	716	{"_key": 716, "resPath": "Accessories/EarsLow/Stud03_LeftA/Types/Stud03_LeftA.type", "resGender": 0}
696	717	{"_key": 717, "resPath": "Accessories/EarsHigh/Stud09_LeftA/Types/Stud09_LeftA.type", "resGender": 1}
697	718	{"_key": 718, "resPath": "Accessories/EarsLow/Ring03_PairA/Types/Ring03_PairA.type", "resGender": 0}
698	719	{"_key": 719, "resPath": "Accessories/EarsLow/Ring05_RightB/Types/Ring05_RightB.type", "resGender": 1}
699	720	{"_key": 720, "resPath": "Accessories/EarsLow/Stud02_PairC/Types/Stud02_PairC.type", "resGender": 0}
700	721	{"_key": 721, "resPath": "Accessories/EarsHigh/Ring01_RightA/Types/Ring01_RightA.type", "resGender": 0}
701	722	{"_key": 722, "resPath": "Accessories/EarsLow/Ring06_LeftB/Types/Ring06_LeftB.type", "resGender": 0}
702	723	{"_key": 723, "resPath": "Accessories/EarsHigh/Stud09_LeftA/Types/Stud09_LeftA.type", "resGender": 0}
703	724	{"_key": 724, "resPath": "Accessories/Nose/Stud13_RightA/Types/Stud13_RightA.type", "resGender": 0}
704	725	{"_key": 725, "resPath": "Accessories/EarsLow/Stud13_LeftA/Types/Stud13_LeftA.type", "resGender": 0}
705	726	{"_key": 726, "resPath": "Accessories/EarsLow/Stud13_PairC/Types/Stud13_PairC.type", "resGender": 0}
706	727	{"_key": 727, "resPath": "Accessories/EarsLow/Ring06_PairC/Types/Ring06_PairC.type", "resGender": 1}
707	728	{"_key": 728, "resPath": "Accessories/Lips/Types/Lips.type", "resGender": 1}
708	729	{"_key": 729, "resPath": "Accessories/EarsLow/Ring02_LeftA/Types/Ring02_LeftA.type", "resGender": 0}
709	730	{"_key": 730, "resPath": "Accessories/EarsLow/Ring06_PairA/Types/Ring06_PairA.type", "resGender": 1}
710	731	{"_key": 731, "resPath": "Accessories/Piercings/Earring03/Types/Earring03.type", "resGender": 0}
711	732	{"_key": 732, "resPath": "Accessories/EarsLow/Stud01_PairC/Types/Stud01_PairC.type", "resGender": 0}
712	733	{"_key": 733, "resPath": "Accessories/Chin/Stud02_PairA/Types/Stud02_PairA.type", "resGender": 1}
713	734	{"_key": 734, "resPath": "Accessories/EarsLow/Ring01_LeftC/Types/Ring01_LeftC.type", "resGender": 0}
714	735	{"_key": 735, "resPath": "Accessories/EarsLow/Stud02_LeftA/Types/Stud02_LeftA.type", "resGender": 1}
715	736	{"_key": 736, "resPath": "Accessories/Nose/Stud02_LeftA/Types/Stud02_LeftA.type", "resGender": 0}
716	737	{"_key": 737, "resPath": "Accessories/EarsLow/Ring06_RightB/Types/Ring06_RightB.type", "resGender": 1}
717	738	{"_key": 738, "resPath": "Accessories/EarsLow/Stud03_LeftA/Types/Stud03_LeftA.type", "resGender": 1}
718	739	{"_key": 739, "resPath": "Accessories/EarsLow/Ring06_RightC/Types/Ring06_RightC.type", "resGender": 0}
719	740	{"_key": 740, "resPath": "Accessories/EarsLow/Stud13_RightA/Types/Stud13_RightA.type", "resGender": 0}
720	741	{"_key": 741, "resPath": "Accessories/EarsLow/Stud02_PairA/Types/Stud02_PairA.type", "resGender": 1}
721	742	{"_key": 742, "resPath": "Accessories/Chin/Stud11_LeftA/Types/Stud11_LeftA.type", "resGender": 1}
722	743	{"_key": 743, "resPath": "Accessories/EarsLow/Ring02_RightC/Types/Ring02_RightC.type", "resGender": 0}
723	744	{"_key": 744, "resPath": "Accessories/Piercings/Types/Piercings.type", "resGender": 0}
724	745	{"_key": 745, "resPath": "Accessories/EarsLow/Ring01_RightA/Types/Ring01_RightA.type", "resGender": 0}
725	746	{"_key": 746, "resPath": "Accessories/EarsLow/Ring01_PairB/Types/Ring01_PairB.type", "resGender": 1}
726	747	{"_key": 747, "resPath": "Accessories/EarsLow/Ring01_RightA/Types/Ring01_RightA.type", "resGender": 1}
727	748	{"_key": 748, "resPath": "Accessories/EarsLow/Stud04_PairA/Types/Stud04_PairA.type", "resGender": 1}
728	749	{"_key": 749, "resPath": "Accessories/Piercings/Ring05/Types/Ring05.type", "resGender": 0}
729	750	{"_key": 750, "resPath": "Accessories/EarsLow/Ring02_PairA/Types/Ring02_PairA.type", "resGender": 0}
730	751	{"_key": 751, "resPath": "Accessories/Brow/Ring01_PairA/Types/Ring01_PairA.type", "resGender": 1}
731	752	{"_key": 752, "resPath": "Accessories/EarsHigh/Stud13_LeftD/Types/Stud13_LeftD.type", "resGender": 0}
732	753	{"_key": 753, "resPath": "Accessories/EarsLow/Ring02_PairC/Types/Ring02_PairC.type", "resGender": 0}
733	754	{"_key": 754, "resPath": "Accessories/Piercings/Earring02/Types/Stud02.type", "resGender": 0}
734	755	{"_key": 755, "resPath": "Accessories/Brow/Ring01_RightA/Types/Ring01_RightA.type", "resGender": 1}
735	756	{"_key": 756, "resPath": "Accessories/EarsHigh/Stud02_LeftD/Types/Stud02_LeftD.type", "resGender": 0}
736	757	{"_key": 757, "resPath": "Accessories/EarsLow/Stud02_LeftB/Types/Stud02_LeftB.type", "resGender": 0}
737	758	{"_key": 758, "resPath": "Accessories/Chin/Stud01_LeftA/Types/Stud01_LeftA.type", "resGender": 0}
738	759	{"_key": 759, "resPath": "Accessories/Piercings/Stud06/Types/Stud06.type", "resGender": 0}
739	760	{"_key": 760, "resPath": "Accessories/EarsLow/Ring01_RightB/Types/Ring01_RightB.type", "resGender": 0}
740	761	{"_key": 761, "resPath": "Accessories/EarsLow/Ring01_LeftB/Types/Ring01_LeftB.type", "resGender": 1}
741	762	{"_key": 762, "resPath": "Accessories/EarsLow/Stud06_PairA/Types/Stud06_PairA.type", "resGender": 0}
742	763	{"_key": 763, "resPath": "Accessories/Chin/Stud12_CenterA/Types/Stud12_CenterA.type", "resGender": 1}
743	764	{"_key": 764, "resPath": "Accessories/Chin/Stud05_PairA/Types/Stud05_PairA.type", "resGender": 1}
744	765	{"_key": 765, "resPath": "Accessories/EarsLow/Stud06_RightA/Types/Stud06_RightA.type", "resGender": 0}
745	766	{"_key": 766, "resPath": "Accessories/EarsLow/Earring03_LeftA/Types/Earring03_LeftA.type", "resGender": 1}
746	767	{"_key": 767, "resPath": "Accessories/Lips/Ring06_PairA/Types/Ring06_PairA.type", "resGender": 1}
747	768	{"_key": 768, "resPath": "Accessories/EarsLow/Stud01_RightB/Types/Stud01_RightB.type", "resGender": 0}
748	769	{"_key": 769, "resPath": "Accessories/Piercings/Stud06/Types/Stud06.type", "resGender": 1}
749	770	{"_key": 770, "resPath": "Accessories/Lips/Ring06_LeftA/Types/Ring06_LeftA.type", "resGender": 1}
750	771	{"_key": 771, "resPath": "Accessories/EarsLow/Stud13_LeftB/Types/Stud13_LeftB.type", "resGender": 0}
751	772	{"_key": 772, "resPath": "Accessories/EarsLow/Ring01_PairA/Types/Ring01_PairA.type", "resGender": 0}
752	773	{"_key": 773, "resPath": "Accessories/EarsLow/Earring02_LeftA/Types/Earring02_LeftA.type", "resGender": 0}
753	774	{"_key": 774, "resPath": "Accessories/EarsLow/Ring06_PairB/Types/Ring06_PairB.type", "resGender": 1}
754	775	{"_key": 775, "resPath": "Accessories/EarsHigh/Stud02_LeftD/Types/Stud02_LeftD.type", "resGender": 1}
755	776	{"_key": 776, "resPath": "Accessories/Nose/Ring01_RightA/Types/Ring01_RightA.type", "resGender": 0}
756	777	{"_key": 777, "resPath": "Accessories/EarsLow/Ring01_PairC/Types/Ring01_PairC.type", "resGender": 1}
757	778	{"_key": 778, "resPath": "Accessories/Lips/Stud01_RightB/Types/Stud01_RightB.type", "resGender": 0}
758	779	{"_key": 779, "resPath": "Accessories/Piercings/Stud02/Types/Stud02.type", "resGender": 1}
759	780	{"_key": 780, "resPath": "Accessories/EarsLow/Ring01_PairB/Types/Ring01_PairB.type", "resGender": 0}
760	781	{"_key": 781, "resPath": "Accessories/EarsHigh/Stud02_PairD/Types/Stud02_PairD.type", "resGender": 1}
761	782	{"_key": 782, "resPath": "Accessories/Piercings/Ring04/Types/Ring04.type", "resGender": 0}
762	783	{"_key": 783, "resPath": "Accessories/EarsLow/Ring03_LeftC/Types/Ring03_LeftC.type", "resGender": 0}
763	784	{"_key": 784, "resPath": "Accessories/EarsHigh/Ring01_LeftC/Types/Ring01_LeftC.type", "resGender": 1}
764	785	{"_key": 785, "resPath": "Accessories/Chin/Stud12_LeftA/Types/Stud12_LeftA.type", "resGender": 1}
765	786	{"_key": 786, "resPath": "Accessories/EarsLow/Ring01_PairC/Types/Ring01_PairC.type", "resGender": 0}
766	787	{"_key": 787, "resPath": "Accessories/Piercings/Ring02/Types/LipLower02.type", "resGender": 0}
767	788	{"_key": 788, "resPath": "Accessories/EarsLow/Stud08_RightA/Types/Stud08_RightA.type", "resGender": 0}
768	789	{"_key": 789, "resPath": "Accessories/Lips/Ring01_PairA/Types/Ring01_PairA.type", "resGender": 0}
769	790	{"_key": 790, "resPath": "Accessories/EarsHigh/Stud02_RightD/Types/Stud02_RightD.type", "resGender": 1}
770	791	{"_key": 791, "resPath": "Accessories/Nose/Pin01_CenterB/Types/Pin01_CenterB.type", "resGender": 1}
771	792	{"_key": 792, "resPath": "Accessories/EarsLow/Ring06_LeftC/Types/Ring06_LeftC.type", "resGender": 0}
772	793	{"_key": 793, "resPath": "Accessories/EarsHigh/Stud13_PairD/Types/Stud13_PairD.type", "resGender": 0}
773	794	{"_key": 794, "resPath": "Accessories/EarsLow/Earring01_LeftA/Types/Earring01_LeftA.type", "resGender": 0}
774	795	{"_key": 795, "resPath": "Accessories/Piercings/Stud04/Types/Stud04.type", "resGender": 1}
775	796	{"_key": 796, "resPath": "Accessories/EarsLow/Ring01_LeftA/Types/Ring01_LeftA.type", "resGender": 1}
776	797	{"_key": 797, "resPath": "Accessories/EarsLow/Stud10_RightA/Types/Stud10_RightA.type", "resGender": 0}
777	798	{"_key": 798, "resPath": "Accessories/Piercings/Pin01/Types/Ring04.type", "resGender": 0}
778	799	{"_key": 799, "resPath": "Accessories/EarsLow/Stud10_PairA/Types/Stud10_PairA.type", "resGender": 0}
779	800	{"_key": 800, "resPath": "Accessories/EarsLow/Ring02_RightA/Types/Ring02_RightA.type", "resGender": 0}
780	801	{"_key": 801, "resPath": "Accessories/EarsLow/Stud03_PairA/Types/Stud03_PairA.type", "resGender": 1}
781	802	{"_key": 802, "resPath": "Accessories/Chin/Stud01_RightA/Types/Stud01_RightA.type", "resGender": 0}
782	803	{"_key": 803, "resPath": "Accessories/EarsLow/Earring03_LeftA/Types/Earring03_LeftA.type", "resGender": 0}
783	804	{"_key": 804, "resPath": "Accessories/Lips/Stud01_LeftB/Types/Stud01_LeftB.type", "resGender": 0}
784	805	{"_key": 805, "resPath": "Accessories/EarsHigh/Ring01_LeftC/Types/Ring01_LeftC.type", "resGender": 0}
785	806	{"_key": 806, "resPath": "Accessories/Nose/Ring01_LeftA/Types/Ring01_LeftA.type", "resGender": 0}
786	807	{"_key": 807, "resPath": "Accessories/EarsLow/Stud04_LeftA/Types/Stud04_LeftA.type", "resGender": 1}
787	808	{"_key": 808, "resPath": "Accessories/Brow/Ring01_LeftA/Types/Ring01_LeftA.type", "resGender": 1}
788	809	{"_key": 809, "resPath": "Accessories/EarsLow/Ring05_PairA/Types/Ring05_PairA.type", "resGender": 0}
789	810	{"_key": 810, "resPath": "Accessories/Lips/Stud13_RightB/Types/Stud13_RightB.type", "resGender": 0}
790	811	{"_key": 811, "resPath": "Accessories/Lips/Ring05_CenterA/Types/Ring05_CenterA.type", "resGender": 1}
791	812	{"_key": 812, "resPath": "Accessories/Lips/Ring01_LeftA/Types/Ring01_LeftA.type", "resGender": 0}
792	813	{"_key": 813, "resPath": "Accessories/EarsHigh/Stud01_RightD/Types/Stud01_RightD.type", "resGender": 0}
793	814	{"_key": 814, "resPath": "Accessories/Piercings/Ring05/Types/Ring05.type", "resGender": 1}
794	815	{"_key": 815, "resPath": "Accessories/Piercings/Stud05/Types/Stud05.type", "resGender": 0}
795	816	{"_key": 816, "resPath": "Accessories/Piercings/Ring04/Types/Ring04.type", "resGender": 1}
796	817	{"_key": 817, "resPath": "Accessories/Chin/Stud02_LeftA/Types/Stud02_LeftA.type", "resGender": 1}
797	818	{"_key": 818, "resPath": "Accessories/EarsLow/Ring03_RightC/Types/Ring03_RightC.type", "resGender": 0}
798	819	{"_key": 819, "resPath": "Accessories/EarsLow/Stud01_PairA/Types/Stud01_PairA.type", "resGender": 0}
799	820	{"_key": 820, "resPath": "Accessories/Piercings/Ring01/Types/LipLower01.type", "resGender": 0}
800	821	{"_key": 821, "resPath": "Accessories/EarsLow/Ring05_PairB/Types/Ring05_PairB.type", "resGender": 1}
801	822	{"_key": 822, "resPath": "Accessories/EarsLow/Stud01_LeftA/Types/Stud01_LeftA.type", "resGender": 0}
802	823	{"_key": 823, "resPath": "Accessories/EarsLow/Stud02_RightB/Types/Stud02_RightB.type", "resGender": 1}
803	824	{"_key": 824, "resPath": "Accessories/Nose/Ring04_CenterA/Types/Ring04_CenterA.type", "resGender": 0}
804	825	{"_key": 825, "resPath": "Accessories/Lips/Ring06_LeftA/Types/Ring06_LeftA.type", "resGender": 0}
805	826	{"_key": 826, "resPath": "Accessories/EarsLow/Ring07_PairA/Types/Ring07_PairA.type", "resGender": 0}
806	827	{"_key": 827, "resPath": "Accessories/EarsLow/Stud02_LeftC/Types/Stud02_LeftC.type", "resGender": 1}
807	828	{"_key": 828, "resPath": "Accessories/EarsLow/Stud08_PairA/Types/Stud08_PairA.type", "resGender": 0}
808	829	{"_key": 829, "resPath": "Accessories/Brow/Types/Brow.type", "resGender": 1}
809	830	{"_key": 830, "resPath": "Accessories/Lips/Ring06_CenterA/Types/Ring06_CenterA.type", "resGender": 0}
810	831	{"_key": 831, "resPath": "Accessories/EarsLow/Ring02_RightB/Types/Ring02_RightB.type", "resGender": 0}
811	832	{"_key": 832, "resPath": "Accessories/EarsLow/Stud02_PairC/Types/Stud02_PairC.type", "resGender": 1}
812	833	{"_key": 833, "resPath": "Accessories/EarsLow/Ring01_LeftA/Types/Ring01_LeftA.type", "resGender": 0}
813	834	{"_key": 834, "resPath": "Accessories/Chin/Stud05_PairA/Types/Stud05_PairA.type", "resGender": 0}
814	835	{"_key": 835, "resPath": "Accessories/Piercings/Stud01/Types/Stud01.type", "resGender": 0}
815	836	{"_key": 836, "resPath": "Accessories/EarsLow/Stud03_RightA/Types/Stud03_RightA.type", "resGender": 0}
816	837	{"_key": 837, "resPath": "Accessories/Lips/Ring02_LeftA/Types/Ring02_LeftA.type", "resGender": 0}
817	838	{"_key": 838, "resPath": "Accessories/EarsLow/Stud13_LeftC/Types/Stud13_LeftC.type", "resGender": 0}
818	839	{"_key": 839, "resPath": "Accessories/EarsLow/Ring06_PairC/Types/Ring06_PairC.type", "resGender": 0}
819	840	{"_key": 840, "resPath": "Accessories/EarsLow/Earring01_RightA/Types/Earring01_RightA.type", "resGender": 0}
820	841	{"_key": 841, "resPath": "Accessories/Piercings/Ring06/Types/Stud02.type", "resGender": 1}
821	842	{"_key": 842, "resPath": "Accessories/EarsLow/Ring01_RightC/Types/Ring01_RightC.type", "resGender": 0}
822	843	{"_key": 843, "resPath": "Accessories/EarsLow/Ring03_PairC/Types/Ring03_PairC.type", "resGender": 0}
823	844	{"_key": 844, "resPath": "Accessories/EarsLow/Ring06_RightA/Types/Ring06_RightA.type", "resGender": 1}
824	845	{"_key": 845, "resPath": "Accessories/Piercings/Stud10/Types/Stud10.type", "resGender": 1}
825	846	{"_key": 846, "resPath": "Accessories/EarsLow/Ring02_PairB/Types/Ring02_PairB.type", "resGender": 0}
826	847	{"_key": 847, "resPath": "Accessories/EarsLow/Ring05_PairC/Types/Ring05_PairC.type", "resGender": 0}
827	848	{"_key": 848, "resPath": "Accessories/EarsLow/Ring01_RightC/Types/Ring01_RightC.type", "resGender": 1}
828	849	{"_key": 849, "resPath": "Accessories/Chin/Stud01_PairA/Types/Stud01_PairA.type", "resGender": 0}
829	850	{"_key": 850, "resPath": "Accessories/Lips/Ring02_PairA/Types/Ring02_PairA.type", "resGender": 0}
830	851	{"_key": 851, "resPath": "Accessories/Chin/Stud11_CenterA/Types/Stud11_CenterA.type", "resGender": 1}
831	852	{"_key": 852, "resPath": "Accessories/EarsLow/Stud02_PairA/Types/Stud02_PairA.type", "resGender": 0}
832	853	{"_key": 853, "resPath": "Accessories/EarsLow/Stud13_PairB/Types/Stud13_PairB.type", "resGender": 0}
833	854	{"_key": 854, "resPath": "Accessories/Lips/Stud02_LeftB/Types/Stud02_LeftB.type", "resGender": 0}
834	855	{"_key": 855, "resPath": "Accessories/EarsLow/Stud02_LeftC/Types/Stud02_LeftC.type", "resGender": 0}
835	856	{"_key": 856, "resPath": "Accessories/Chin/Stud05_CenterA/Types/Stud05_CenterA.type", "resGender": 1}
836	857	{"_key": 857, "resPath": "Accessories/Piercings/Ring06/Types/Stud02.type", "resGender": 0}
837	858	{"_key": 858, "resPath": "Accessories/Chin/Stud12_CenterA/Types/Stud12_CenterA.type", "resGender": 0}
838	859	{"_key": 859, "resPath": "Accessories/Nose/Stud02_LeftA/Types/Stud02_LeftA.type", "resGender": 1}
839	860	{"_key": 860, "resPath": "Accessories/EarsLow/Stud06_LeftA/Types/Stud06_LeftA.type", "resGender": 0}
840	861	{"_key": 861, "resPath": "Accessories/EarsLow/Earring03_RightA/Types/Earring03_RightA.type", "resGender": 0}
841	862	{"_key": 862, "resPath": "Accessories/Piercings/Stud03/Types/Stud03.type", "resGender": 1}
842	863	{"_key": 863, "resPath": "Accessories/EarsLow/Ring05_LeftC/Types/Ring05_LeftC.type", "resGender": 1}
843	864	{"_key": 864, "resPath": "Accessories/EarsLow/Ring05_RightB/Types/Ring05_RightB.type", "resGender": 0}
844	865	{"_key": 865, "resPath": "Accessories/EarsLow/Ring06_PairB/Types/Ring06_PairB.type", "resGender": 0}
845	866	{"_key": 866, "resPath": "Accessories/Chin/Stud13_PairA/Types/Stud13_PairA.type", "resGender": 0}
846	867	{"_key": 867, "resPath": "Accessories/Piercings/Stud12/Types/Stud12.type", "resGender": 0}
847	868	{"_key": 868, "resPath": "Accessories/EarsLow/Earring03_PairA/Types/Earring03_PairA.type", "resGender": 1}
848	869	{"_key": 869, "resPath": "Accessories/Nose/Ring04_CenterA/Types/Ring04_CenterA.type", "resGender": 1}
849	870	{"_key": 870, "resPath": "Accessories/EarsLow/Stud02_RightA/Types/Stud02_RightA.type", "resGender": 1}
850	871	{"_key": 871, "resPath": "Accessories/EarsHigh/Stud09_RightB/Types/Stud09_RightB.type", "resGender": 0}
851	872	{"_key": 872, "resPath": "Accessories/EarsHigh/Stud02_RightD/Types/Stud02_RightD.type", "resGender": 0}
852	873	{"_key": 873, "resPath": "Accessories/EarsLow/Ring01_PairA/Types/Ring01_PairA.type", "resGender": 1}
853	874	{"_key": 874, "resPath": "Accessories/Nose/Stud02_RightA/Types/Stud02_RightA.type", "resGender": 1}
854	875	{"_key": 875, "resPath": "Accessories/Nose/Stud02_RightA/Types/Stud02_RightA.type", "resGender": 0}
855	876	{"_key": 876, "resPath": "Accessories/EarsHigh/Types/EarsHigh.type", "resGender": 1}
856	877	{"_key": 877, "resPath": "Accessories/EarsLow/Ring06_LeftA/Types/Ring06_LeftA.type", "resGender": 0}
857	878	{"_key": 878, "resPath": "Accessories/Chin/Stud02_CenterA/Types/Stud02_CenterA.type", "resGender": 0}
858	879	{"_key": 879, "resPath": "Accessories/EarsLow/Types/EarsLow.type", "resGender": 1}
859	880	{"_key": 880, "resPath": "Accessories/EarsLow/Stud10_LeftA/Types/Stud10_LeftA.type", "resGender": 1}
860	881	{"_key": 881, "resPath": "Accessories/Lips/Ring06_RightA/Types/Ring06_RightA.type", "resGender": 1}
861	882	{"_key": 882, "resPath": "Accessories/Lips/Ring06_RightA/Types/Ring06_RightA.type", "resGender": 0}
862	883	{"_key": 883, "resPath": "Accessories/Piercings/Stud12/Types/Stud12.type", "resGender": 1}
863	884	{"_key": 884, "resPath": "Accessories/EarsLow/Stud01_PairB/Types/Stud01_PairB.type", "resGender": 0}
864	885	{"_key": 885, "resPath": "Accessories/EarsLow/Stud02_RightC/Types/Stud02_RightC.type", "resGender": 1}
865	886	{"_key": 886, "resPath": "Accessories/Chin/Stud01_CenterA/Types/Stud01_CenterA.type", "resGender": 0}
866	887	{"_key": 887, "resPath": "Accessories/EarsLow/Stud03_PairA/Types/Stud03_PairA.type", "resGender": 0}
867	888	{"_key": 888, "resPath": "Accessories/EarsLow/Ring05_LeftA/Types/Ring05_LeftA.type", "resGender": 1}
868	889	{"_key": 889, "resPath": "Accessories/Piercings/Stud05/Types/Stud05.type", "resGender": 1}
869	890	{"_key": 890, "resPath": "Accessories/Chin/Stud13_LeftA/Types/Stud13_LeftA.type", "resGender": 0}
870	891	{"_key": 891, "resPath": "Accessories/Lips/Ring01_LeftA/Types/Ring01_LeftA.type", "resGender": 1}
871	892	{"_key": 892, "resPath": "Accessories/Piercings/Ring07/Types/Ring07.type", "resGender": 0}
872	893	{"_key": 893, "resPath": "Accessories/Nose/Ring01_LeftA/Types/Ring01_LeftA.type", "resGender": 1}
873	894	{"_key": 894, "resPath": "Accessories/EarsLow/Stud02_PairB/Types/Stud02_PairB.type", "resGender": 0}
874	895	{"_key": 895, "resPath": "Accessories/EarsLow/Stud02_LeftB/Types/Stud02_LeftB.type", "resGender": 1}
875	896	{"_key": 896, "resPath": "Accessories/Nose/Stud01_LeftA/Types/Stud01_LeftA.type", "resGender": 0}
876	897	{"_key": 897, "resPath": "Accessories/Chin/Stud13_CenterA/Types/Stud13_CenterA.type", "resGender": 0}
877	898	{"_key": 898, "resPath": "Accessories/EarsHigh/Stud02_PairD/Types/Stud02_PairD.type", "resGender": 0}
878	899	{"_key": 899, "resPath": "Accessories/EarsLow/Stud04_PairA/Types/Stud04_PairA.type", "resGender": 0}
879	900	{"_key": 900, "resPath": "Accessories/EarsLow/Ring06_PairA/Types/Ring06_PairA.type", "resGender": 0}
880	901	{"_key": 901, "resPath": "Accessories/EarsHigh/Stud09_PairB/Types/Stud09_PairB.type", "resGender": 0}
881	902	{"_key": 902, "resPath": "Accessories/EarsLow/Stud06_RightA/Types/Stud06_RightA.type", "resGender": 1}
882	903	{"_key": 903, "resPath": "Accessories/Piercings/Stud09/Types/Stud09.type", "resGender": 1}
883	904	{"_key": 904, "resPath": "Accessories/EarsLow/Stud02_PairB/Types/Stud02_PairB.type", "resGender": 1}
884	905	{"_key": 905, "resPath": "Accessories/Lips/Ring05_RightA/Types/Ring05_RightA.type", "resGender": 1}
885	906	{"_key": 906, "resPath": "Accessories/Nose/Stud13_LeftA/Types/Stud13_LeftA.type", "resGender": 0}
886	907	{"_key": 907, "resPath": "Accessories/EarsLow/Ring03_RightA/Types/Ring03_RightA.type", "resGender": 0}
887	908	{"_key": 908, "resPath": "Accessories/Lips/Stud13_LeftB/Types/Stud13_LeftB.type", "resGender": 0}
888	909	{"_key": 909, "resPath": "Accessories/EarsHigh/Stud09_RightA/Types/Stud09_RightA.type", "resGender": 0}
889	910	{"_key": 910, "resPath": "Accessories/Brow/Ring01_RightA/Types/Ring01_RightA.type", "resGender": 0}
890	911	{"_key": 911, "resPath": "Accessories/Nose/Types/Nose.type", "resGender": 0}
891	912	{"_key": 912, "resPath": "Accessories/EarsLow/Ring02_LeftB/Types/Ring02_LeftB.type", "resGender": 0}
892	913	{"_key": 913, "resPath": "Accessories/Piercings/Ring01/Types/LipLower01.type", "resGender": 1}
893	914	{"_key": 914, "resPath": "Accessories/Chin/Stud05_RightA/Types/Stud05_RightA.type", "resGender": 1}
894	915	{"_key": 915, "resPath": "Accessories/Piercings/Stud10/Types/Stud10.type", "resGender": 0}
895	916	{"_key": 916, "resPath": "Accessories/Lips/Ring05_PairA/Types/Ring05_PairA.type", "resGender": 0}
896	917	{"_key": 917, "resPath": "Accessories/EarsHigh/Stud09_PairA/Types/Stud09_PairA.type", "resGender": 0}
897	918	{"_key": 918, "resPath": "Accessories/Chin/Stud11_PairA/Types/Stud11_PairA.type", "resGender": 1}
898	919	{"_key": 919, "resPath": "Accessories/EarsLow/Earring03_PairA/Types/Earring03_PairA.type", "resGender": 0}
899	920	{"_key": 920, "resPath": "Accessories/EarsLow/Stud08_LeftA/Types/Stud08_LeftA.type", "resGender": 0}
900	921	{"_key": 921, "resPath": "Accessories/EarsLow/Ring05_RightC/Types/Ring05_RightC.type", "resGender": 1}
901	922	{"_key": 922, "resPath": "Accessories/Chin/Types/Chin.type", "resGender": 1}
902	923	{"_key": 923, "resPath": "Accessories/EarsLow/Stud03_RightA/Types/Stud03_RightA.type", "resGender": 1}
903	924	{"_key": 924, "resPath": "Accessories/EarsHigh/Ring01_LeftB/Types/Ring01_LeftB.type", "resGender": 0}
904	925	{"_key": 925, "resPath": "Accessories/Brow/Types/Brow.type", "resGender": 0}
905	926	{"_key": 926, "resPath": "Accessories/Piercings/Stud13/Types/Stud13.type", "resGender": 0}
906	927	{"_key": 927, "resPath": "Accessories/Piercings/Earring03/Types/Earring03.type", "resGender": 1}
907	928	{"_key": 928, "resPath": "Accessories/EarsLow/Ring01_LeftB/Types/Ring01_LeftB.type", "resGender": 0}
908	929	{"_key": 929, "resPath": "Accessories/Brow/Ring01_LeftA/Types/Ring01_LeftA.type", "resGender": 0}
909	930	{"_key": 930, "resPath": "Accessories/Piercings/Types/Piercings.type", "resGender": 1}
910	931	{"_key": 931, "resPath": "Accessories/EarsLow/Stud13_PairA/Types/Stud13_PairA.type", "resGender": 0}
911	932	{"_key": 932, "resPath": "Accessories/Lips/Ring05_RightA/Types/Ring05_RightA.type", "resGender": 0}
912	933	{"_key": 933, "resPath": "Accessories/EarsHigh/Ring01_RightA/Types/Ring01_RightA.type", "resGender": 1}
913	934	{"_key": 934, "resPath": "Accessories/Lips/Ring05_CenterA/Types/Ring05_CenterA.type", "resGender": 0}
914	935	{"_key": 935, "resPath": "Accessories/Piercings/Stud03/Types/Stud03.type", "resGender": 0}
915	936	{"_key": 936, "resPath": "Accessories/Brow/SpikesForehead_M01/Types/SpikesForehead_M01.type", "resGender": 1}
916	937	{"_key": 937, "resPath": "Accessories/Piercings/SpikesForhead01/Types/SpikesForhead01.type", "resGender": 1}
917	938	{"_key": 938, "resPath": "Accessories/Brow/JewelryForehead_01/Types/JewelryForehead_01.type", "resGender": 0}
918	939	{"_key": 939, "resPath": "Accessories/Piercings/Stud08/Types/Stud08.type", "resGender": 1}
919	940	{"_key": 940, "resPath": "Accessories/Brow/SpikesForehead_M02/Types/SpikesForehead_M02.type", "resGender": 1}
920	941	{"_key": 941, "resPath": "Accessories/Piercings/SpikesForhead02/Types/SpikesForhead02.type", "resGender": 1}
921	942	{"_key": 942, "resPath": "bottomOuter/PantsMilM01/Types/PantsMilM01_v1.type", "resGender": 1}
922	943	{"_key": 943, "resPath": "bottomOuter/PantsMilM01/Types/PantsMilM01_v0.type", "resGender": 1}
923	944	{"_key": 944, "resPath": "outer/JacketMilM01/Types/JacketMilM01.type", "resGender": 1}
924	945	{"_key": 945, "resPath": "bottomOuter/SkirtMilF01/Types/SkirtMilF01_V0.type", "resGender": 0}
925	946	{"_key": 946, "typeID": 4067, "resPath": "TopMiddle/ShirtQM01/Types/shirtqm01.type", "resGender": 1}
926	947	{"_key": 947, "resPath": "hair/Hair_ShortPixieTop_01/Types/hair_shortpixietop_01.type", "resGender": 0}
927	948	{"_key": 948, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01.type", "resGender": 0}
928	949	{"_key": 949, "typeID": 4088, "resPath": "hair/Hair_CurlyShoulderLength_01/Types/hair_curlyshoulderlength_01.type", "resGender": 0}
929	950	{"_key": 950, "resPath": "bottomOuter/SkirtMilF01/Types/SkirtMilF01_V1.type", "resGender": 0}
930	951	{"_key": 951, "resPath": "bottomOuter/SkirtMilF02/Types/SkirtMilF02.type", "resGender": 0}
931	952	{"_key": 952, "resPath": "outer/JacketMilM02/Types/JacketMilM02.type", "resGender": 1}
932	953	{"_key": 953, "typeID": 4066, "resPath": "TopMiddle/ShirtQF01/Types/shirtqf01.type", "resGender": 0}
933	955	{"_key": 955, "resPath": "bottomInner/BoxersCM01/Types/achura.type", "resGender": 1}
934	956	{"_key": 956, "resPath": "BottomUnderwear/BoxersGM01/Types/jinmei.type", "resGender": 1}
935	957	{"_key": 957, "typeID": 4098, "resPath": "outer/JacketMilM02/Types/JacketMilM02_blackgray.type", "resGender": 1}
936	958	{"_key": 958, "resPath": "TopUnderwear/BikiniTopCF01/Types/BikiniTopCF01_civire.type", "resGender": 0}
937	959	{"_key": 959, "resPath": "topInner/BikiniTopCF01/Types/BikiniTopCF01_achura.type", "resGender": 0}
938	960	{"_key": 960, "typeID": 4038, "resPath": "Accessories/Glasses/EyeImp01/Types/EyeImpF01_RightGray.type", "resGender": 0}
939	961	{"_key": 961, "resPath": "bottomInner/BikiniBottomMF01/Types/BikiniBottomMF01_vherokior.type", "resGender": 0}
940	962	{"_key": 962, "resPath": "BottomUnderwear/BikiniBottomAF01/Types/BikiniBottomAF01_amarr.type", "resGender": 0}
941	963	{"_key": 963, "resPath": "bottomInner/BikiniBottomGF01/Types/BikiniBottomGF01_intaki.type", "resGender": 0}
942	964	{"_key": 964, "resPath": "topInner/BikiniTopAF01/Types/BikiniTopAF01_nikunni.type", "resGender": 0}
943	965	{"_key": 965, "typeID": 4009, "resPath": "Accessories/Glasses/Monocle_01/Types/MonocleM01_RightGold.type", "resGender": 1}
944	966	{"_key": 966, "resPath": "TopUnderwear/BikiniTopAF01/Types/BikiniTopAF01_khanid.type", "resGender": 0}
945	967	{"_key": 967, "typeID": 4009, "resPath": "Accessories/Glasses/Monocle_01/Types/MonocleF01_RightGold.type", "resGender": 0}
946	968	{"_key": 968, "resPath": "topInner/BikiniTopMF01/Types/BikiniTopMF01_brutor.type", "resGender": 0}
947	969	{"_key": 969, "resPath": "TopUnderwear/BikiniTopCF01/Types/BikiniTopCF01_achura.type", "resGender": 0}
948	970	{"_key": 970, "resPath": "bottomInner/BikiniBottomCF01/Types/BikiniBottomCF01_civire.type", "resGender": 0}
949	971	{"_key": 971, "typeID": 4042, "resPath": "Accessories/Glasses/Monocle_01/Types/MonocleM01_RightGray.type", "resGender": 1}
950	972	{"_key": 972, "resPath": "BottomUnderwear/BoxersCM01/Types/achura.type", "resGender": 1}
951	973	{"_key": 973, "typeID": 4048, "resPath": "Accessories/Glasses/EyeImp01/Types/EyeImpM01_LeftGray.type", "resGender": 1}
952	974	{"_key": 974, "typeID": 4068, "resPath": "TopOuter/ShirtMilM01/Types/ShirtMilM01_ishukone.type", "resGender": 1}
953	975	{"_key": 975, "typeID": 4042, "resPath": "Accessories/Glasses/Monocle_01/Types/MonocleF01_RightGray.type", "resGender": 0}
954	976	{"_key": 976, "typeID": 4062, "resPath": "TopOuter/ShirtMilF01/Types/ShirtMilF01_blue.type", "resGender": 0}
955	977	{"_key": 977, "resPath": "TopUnderwear/BikiniTopGF01/Types/BikiniTopGF01_gallente.type", "resGender": 0}
956	978	{"_key": 978, "resPath": "bottomInner/BoxersGM01/Types/intaki.type", "resGender": 1}
957	979	{"_key": 979, "typeID": 4046, "resPath": "Accessories/Glasses/EyeImp01/Types/EyeImpF01_LeftGold.type", "resGender": 0}
958	980	{"_key": 980, "typeID": 3998, "resPath": "bottomOuter/SkirtMilF01/Types/SkirtMilF01_Gray.type", "resGender": 0}
959	981	{"_key": 981, "resPath": "BottomUnderwear/BoxersAM01/Types/nikunni.type", "resGender": 1}
960	982	{"_key": 982, "resPath": "bottomInner/BoxersMM01/Types/brutor.type", "resGender": 1}
961	983	{"_key": 983, "resPath": "BottomUnderwear/BikiniBottomMF01/Types/BikiniBottomMF01_brutor.type", "resGender": 0}
962	984	{"_key": 984, "resPath": "BottomUnderwear/BikiniBottomGF01/Types/BikiniBottomGF01_intaki.type", "resGender": 0}
963	985	{"_key": 985, "resPath": "bottomInner/BoxersGM01/Types/gallente.type", "resGender": 1}
964	986	{"_key": 986, "typeID": 4078, "resPath": "bottomOuter/SkirtMilF02/Types/SkirtMilF02_Camo.type", "resGender": 0}
965	987	{"_key": 987, "resPath": "bottomInner/BikiniBottomMF01/Types/BikiniBottomMF01_sebiestor.type", "resGender": 0}
966	988	{"_key": 988, "typeID": 4048, "resPath": "Accessories/Glasses/EyeImp01/Types/EyeImpF01_LeftGray.type", "resGender": 0}
967	989	{"_key": 989, "resPath": "topInner/BikiniTopGF01/Types/BikiniTopGF01_jinmei.type", "resGender": 0}
968	990	{"_key": 990, "resPath": "BottomUnderwear/BoxersGM01/Types/intaki.type", "resGender": 1}
969	991	{"_key": 991, "resPath": "TopUnderwear/BikiniTopGF01/Types/BikiniTopGF01_jinmei.type", "resGender": 0}
970	992	{"_key": 992, "resPath": "bottomInner/BoxersAM01/Types/amarr.type", "resGender": 1}
971	993	{"_key": 993, "typeID": 4039, "resPath": "Accessories/Glasses/EyeImp01/Types/EyeImpM01_RightGold.type", "resGender": 1}
972	994	{"_key": 994, "typeID": 4059, "resPath": "TopOuter/ShirtMilM01/Types/ShirtMilM01_dust.type", "resGender": 1}
973	995	{"_key": 995, "resPath": "BottomUnderwear/BikiniBottomGF01/Types/BikiniBottomGF01_gallente.type", "resGender": 0}
974	996	{"_key": 996, "resPath": "bottomInner/BikiniBottomAF01/Types/BikiniBottomAF01_amarr.type", "resGender": 0}
975	997	{"_key": 997, "resPath": "bottomInner/BikiniBottomGF01/Types/BikiniBottomGF01_gallente.type", "resGender": 0}
976	998	{"_key": 998, "resPath": "BottomUnderwear/BikiniBottomAF01/Types/BikiniBottomAF01_nikunni.type", "resGender": 0}
977	999	{"_key": 999, "typeID": 4037, "resPath": "Accessories/Glasses/EyeImp01/Types/EyeImpF01_RightDark.type", "resGender": 0}
978	1000	{"_key": 1000, "typeID": 4058, "resPath": "TopOuter/ShirtMilM01/Types/ShirtMilM01_blue.type", "resGender": 1}
979	1001	{"_key": 1001, "resPath": "BottomUnderwear/BoxersAM01/Types/khanid.type", "resGender": 1}
980	1002	{"_key": 1002, "resPath": "bottomInner/BikiniBottomCF01/Types/BikiniBottomCF01_achura.type", "resGender": 0}
981	1003	{"_key": 1003, "resPath": "topInner/BikiniTopMF01/Types/BikiniTopMF01_sebiestor.type", "resGender": 0}
982	1004	{"_key": 1004, "typeID": 4052, "resPath": "Accessories/Glasses/Monocle_01/Types/MonocleF01_LeftGray.type", "resGender": 0}
983	1005	{"_key": 1005, "typeID": 4096, "resPath": "hair/Hair_Stubble_01/Types/Hair_Stubble_01.type", "resGender": 1}
984	1006	{"_key": 1006, "resPath": "bottomInner/BoxersAM01/Types/khanid.type", "resGender": 1}
985	1007	{"_key": 1007, "resPath": "BottomUnderwear/BoxersGM01/Types/gallente.type", "resGender": 1}
986	1008	{"_key": 1008, "resPath": "bottomInner/BoxersCM01/Types/civire.type", "resGender": 1}
987	1009	{"_key": 1009, "resPath": "bottomInner/BikiniBottomAF01/Types/BikiniBottomAF01_khanid.type", "resGender": 0}
988	1010	{"_key": 1010, "typeID": 4039, "resPath": "Accessories/Glasses/EyeImp01/Types/EyeImpF01_RightGold.type", "resGender": 0}
989	1011	{"_key": 1011, "typeID": 4054, "resPath": "Outer/JacketMilF01/Types/JacketMilF01_blackgray.type", "resGender": 0}
990	1012	{"_key": 1012, "typeID": 4097, "resPath": "outer/JacketMilM01/Types/JacketMilM01_blackyellow.type", "resGender": 1}
991	1013	{"_key": 1013, "resPath": "bottomInner/BoxersMM01/Types/vherokior.type", "resGender": 1}
992	1014	{"_key": 1014, "resPath": "bottomInner/BikiniBottomAF01/Types/BikiniBottomAF01_nikunni.type", "resGender": 0}
993	1015	{"_key": 1015, "typeID": 4050, "resPath": "Accessories/Glasses/Monocle_01/Types/MonocleF01_LeftGold.type", "resGender": 0}
994	1016	{"_key": 1016, "resPath": "BottomUnderwear/BoxersMM01/Types/vherokior.type", "resGender": 1}
995	1017	{"_key": 1017, "typeID": 4061, "resPath": "TopOuter/ShirtMilF01/Types/ShirtMilF01_black.type", "resGender": 0}
996	1018	{"_key": 1018, "resPath": "BottomUnderwear/BoxersMM01/Types/sebiestor.type", "resGender": 1}
997	1019	{"_key": 1019, "resPath": "topInner/BikiniTopMF01/Types/BikiniTopMF01_vherokior.type", "resGender": 0}
998	1020	{"_key": 1020, "resPath": "BottomUnderwear/BikiniBottomCF01/Types/BikiniBottomCF01_civire.type", "resGender": 0}
999	1021	{"_key": 1021, "typeID": 4043, "resPath": "Accessories/Glasses/EyeImp01/Types/EyeImpF01_LeftDark.type", "resGender": 0}
1000	1022	{"_key": 1022, "typeID": 4052, "resPath": "Accessories/Glasses/Monocle_01/Types/MonocleM01_LefttGray.type", "resGender": 1}
1001	1023	{"_key": 1023, "resPath": "TopUnderwear/BikiniTopCF01/Types/BikiniTopCF01_deteis.type", "resGender": 0}
1002	1024	{"_key": 1024, "typeID": 4046, "resPath": "Accessories/Glasses/EyeImp01/Types/EyeImpM01_LeftGold.type", "resGender": 1}
1003	1025	{"_key": 1025, "resPath": "bottomInner/BoxersCM01/Types/deteis.type", "resGender": 1}
1004	1026	{"_key": 1026, "resPath": "BottomUnderwear/BoxersMM01/Types/brutor.type", "resGender": 1}
1005	1027	{"_key": 1027, "resPath": "BottomUnderwear/BikiniBottomMF01/Types/BikiniBottomMF01_sebiestor.type", "resGender": 0}
1006	1028	{"_key": 1028, "typeID": 4065, "resPath": "TopOuter/ShirtMilF01/Types/ShirtMilF01_lightgrey.type", "resGender": 0}
1007	1029	{"_key": 1029, "resPath": "topInner/BikiniTopGF01/Types/BikiniTopGF01_gallente.type", "resGender": 0}
1008	1030	{"_key": 1030, "resPath": "topInner/BikiniTopAF01/Types/BikiniTopAF01_amarr.type", "resGender": 0}
1009	1031	{"_key": 1031, "resPath": "bottomInner/BoxersMM01/Types/sebiestor.type", "resGender": 1}
1010	1032	{"_key": 1032, "resPath": "TopUnderwear/BikiniTopMF01/Types/BikiniTopMF01_vherokior.type", "resGender": 0}
1011	1033	{"_key": 1033, "resPath": "BottomUnderwear/BikiniBottomCF01/Types/BikiniBottomCF01_deteis.type", "resGender": 0}
1012	1034	{"_key": 1034, "resPath": "BottomUnderwear/BoxersCM01/Types/deteis.type", "resGender": 1}
1013	1035	{"_key": 1035, "typeID": 4060, "resPath": "TopOuter/ShirtMilM01/Types/ShirtMilM01_olive.type", "resGender": 1}
1014	1036	{"_key": 1036, "typeID": 3999, "resPath": "bottomOuter/SkirtMilF01/Types/SkirtMilF01_Blackwax.type", "resGender": 0}
1015	1037	{"_key": 1037, "typeID": 4085, "resPath": "bottomOuter/SkirtMilF02/Types/SkirtMilF02_Black.type", "resGender": 0}
1016	1038	{"_key": 1038, "resPath": "bottomInner/BikiniBottomCF01/Types/BikiniBottomCF01_deteis.type", "resGender": 0}
1017	1039	{"_key": 1039, "typeID": 4037, "resPath": "Accessories/Glasses/EyeImp01/Types/EyeImpM01_RightDark.type", "resGender": 1}
1018	1040	{"_key": 1040, "resPath": "topInner/BikiniTopCF01/Types/BikiniTopCF01_civire.type", "resGender": 0}
1019	1041	{"_key": 1041, "resPath": "bottomInner/BoxersGM01/Types/jinmei.type", "resGender": 1}
1020	1042	{"_key": 1042, "resPath": "BottomUnderwear/BikiniBottomAF01/Types/BikiniBottomAF01_khanid.type", "resGender": 0}
1021	1043	{"_key": 1043, "resPath": "TopUnderwear/BikiniTopAF01/Types/BikiniTopAF01_amarr.type", "resGender": 0}
1022	1044	{"_key": 1044, "resPath": "BottomUnderwear/BikiniBottomMF01/Types/BikiniBottomMF01_vherokior.type", "resGender": 0}
1023	1045	{"_key": 1045, "typeID": 4038, "resPath": "Accessories/Glasses/EyeImp01/Types/EyeImpM01_RightGray.type", "resGender": 1}
1024	1046	{"_key": 1046, "resPath": "BottomUnderwear/BoxersAM01/Types/amarr.type", "resGender": 1}
1025	1047	{"_key": 1047, "typeID": 4063, "resPath": "TopOuter/ShirtMilF01/Types/ShirtMilF01_dust.type", "resGender": 0}
1026	1048	{"_key": 1048, "resPath": "topInner/BikiniTopGF01/Types/BikiniTopGF01_intaki.type", "resGender": 0}
1027	1049	{"_key": 1049, "typeID": 4057, "resPath": "TopOuter/ShirtMilM01/Types/ShirtMilM01_black.type", "resGender": 1}
1028	1050	{"_key": 1050, "typeID": 3997, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_blackgray.type", "resGender": 0}
1029	1051	{"_key": 1051, "resPath": "TopUnderwear/BikiniTopAF01/Types/BikiniTopAF01_nikunni.type", "resGender": 0}
1030	1052	{"_key": 1052, "typeID": 4050, "resPath": "Accessories/Glasses/Monocle_01/Types/MonocleM01_LeftGold.type", "resGender": 1}
1031	1053	{"_key": 1053, "resPath": "TopUnderwear/BikiniTopMF01/Types/BikiniTopMF01_sebiestor.type", "resGender": 0}
1032	1054	{"_key": 1054, "resPath": "TopUnderwear/BikiniTopGF01/Types/BikiniTopGF01_intaki.type", "resGender": 0}
1033	1055	{"_key": 1055, "resPath": "BottomUnderwear/BikiniBottomCF01/Types/BikiniBottomCF01_achura.type", "resGender": 0}
1034	1056	{"_key": 1056, "typeID": 4064, "resPath": "TopOuter/ShirtMilF01/Types/ShirtMilF01_olive.type", "resGender": 0}
1035	1057	{"_key": 1057, "resPath": "TopUnderwear/BikiniTopMF01/Types/BikiniTopMF01_brutor.type", "resGender": 0}
1036	1058	{"_key": 1058, "resPath": "bottomInner/BoxersAM01/Types/nikunni.type", "resGender": 1}
1037	1059	{"_key": 1059, "typeID": 4043, "resPath": "Accessories/Glasses/EyeImp01/Types/EyeImpM01_LeftDark.type", "resGender": 1}
1038	1060	{"_key": 1060, "resPath": "bottomInner/BikiniBottomMF01/Types/BikiniBottomMF01_brutor.type", "resGender": 0}
1039	1061	{"_key": 1061, "resPath": "bottomInner/BikiniBottomGF01/Types/BikiniBottomGF01_jinmei.type", "resGender": 0}
1040	1062	{"_key": 1062, "resPath": "topInner/BikiniTopAF01/Types/BikiniTopAF01_khanid.type", "resGender": 0}
1041	1063	{"_key": 1063, "typeID": 3992, "resPath": "bottomOuter/PantsMilM01/Types/PantsMilM01_blackwaxed.type", "resGender": 1}
1042	1064	{"_key": 1064, "resPath": "topInner/BikiniTopCF01/Types/BikiniTopCF01_deteis.type", "resGender": 0}
1043	1065	{"_key": 1065, "typeID": 3958, "resPath": "Accessories/Glasses/Goggles_01/Types/goggles_01.type", "resGender": 0}
1044	1066	{"_key": 1066, "resPath": "BottomUnderwear/BikiniBottomGF01/Types/BikiniBottomGF01_jinmei.type", "resGender": 0}
1045	1067	{"_key": 1067, "resPath": "BottomUnderwear/BoxersCM01/Types/civire.type", "resGender": 1}
1046	1068	{"_key": 1068, "typeID": 4008, "resPath": "Feet/BootsMilM01/Types/BootsMilM01_black.type", "resGender": 1}
1047	1069	{"_key": 1069, "typeID": 3966, "resPath": "Feet/BootsMilM02/Types/BootsMilM02_black.type", "resGender": 1}
1048	1070	{"_key": 1070, "typeID": 4001, "resPath": "Feet/BootsMilM03/Types/BootsMilM03_black.type", "resGender": 1}
1049	1071	{"_key": 1071, "typeID": 4002, "resPath": "Feet/BootsMilF01/Types/BootsMilF01_black.type", "resGender": 0}
1050	1072	{"_key": 1072, "typeID": 4055, "resPath": "Outer/JacketMilF02/Types/JacketMilF02_blackgray.type", "resGender": 0}
1051	1073	{"_key": 1073, "typeID": 4003, "resPath": "Feet/BootsMilF02/Types/BootsMilF02_black.type", "resGender": 0}
1052	1074	{"_key": 1074, "typeID": 4004, "resPath": "Feet/BootsMilF03/Types/BootsMilF03_black.type", "resGender": 0}
1053	1075	{"_key": 1075, "typeID": 3975, "resPath": "Outer/JacketMilF02/Types/JacketMilF02_blue.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
1054	2149	{"_key": 2149, "typeID": 49668, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V0.type", "resGender": 0}
1055	2150	{"_key": 2150, "typeID": 49669, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V1.type", "resGender": 0}
1056	2151	{"_key": 2151, "typeID": 49670, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V2.type", "resGender": 0}
1057	2152	{"_key": 2152, "typeID": 49671, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V3.type", "resGender": 0}
1058	2153	{"_key": 2153, "typeID": 49672, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V4.type", "resGender": 0}
1059	2154	{"_key": 2154, "typeID": 49673, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V5.type", "resGender": 0}
1060	2155	{"_key": 2155, "typeID": 49674, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V6.type", "resGender": 0}
1061	2156	{"_key": 2156, "typeID": 49675, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V7.type", "resGender": 0}
1062	2157	{"_key": 2157, "typeID": 49676, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V8.type", "resGender": 0}
1063	2158	{"_key": 2158, "typeID": 49677, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V0.type", "resGender": 1}
1064	2159	{"_key": 2159, "typeID": 49678, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V1.type", "resGender": 1}
1065	2160	{"_key": 2160, "typeID": 49679, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V2.type", "resGender": 1}
1066	2161	{"_key": 2161, "typeID": 49680, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V3.type", "resGender": 1}
1067	2162	{"_key": 2162, "typeID": 49681, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V4.type", "resGender": 1}
1068	2163	{"_key": 2163, "typeID": 49682, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V5.type", "resGender": 1}
1069	2164	{"_key": 2164, "typeID": 49683, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V6.type", "resGender": 1}
1070	2165	{"_key": 2165, "typeID": 49684, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V7.type", "resGender": 1}
1071	2166	{"_key": 2166, "typeID": 49685, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V8.type", "resGender": 1}
1072	2167	{"_key": 2167, "typeID": 49978, "resPath": "outer/ExplorationSuit_M01/Types/ExplorationSuit_M01_W.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
1073	2168	{"_key": 2168, "typeID": 49980, "resPath": "Outer/ExplorationSuit_F01/Types/ExplorationSuit_F01_W.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
1074	2169	{"_key": 2169, "typeID": 49984, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V0_Blue.type", "resGender": 0}
1075	2170	{"_key": 2170, "typeID": 49985, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V10_W.type", "resGender": 0}
1076	2171	{"_key": 2171, "typeID": 49986, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V10_W.type", "resGender": 1}
1077	2172	{"_key": 2172, "typeID": 49987, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V6_Blue.type", "resGender": 1}
1078	2173	{"_key": 2173, "typeID": 50043, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V30_ChOper.type", "resGender": 0}
1079	2174	{"_key": 2174, "typeID": 50051, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V5_Purple.type", "resGender": 1}
1080	2175	{"_key": 2175, "typeID": 50052, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V5_Purple.type", "resGender": 0}
1081	2176	{"_key": 2176, "typeID": 50050, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V30_ChOper.type", "resGender": 1}
1082	2177	{"_key": 2177, "typeID": 50130, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_PWT.type", "resGender": 0}
1083	2178	{"_key": 2178, "typeID": 50131, "resPath": "topMiddle/TshirtM01/Types/TshirtM01_PWT.type", "resGender": 1}
1084	2179	{"_key": 2179, "typeID": 50132, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_PWT.type", "resGender": 0}
1085	2180	{"_key": 2180, "typeID": 50133, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_PWT.type", "resGender": 1}
1086	2181	{"_key": 2181, "typeID": 52188, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V31_XVI_FF.type", "resGender": 0}
1087	2182	{"_key": 2182, "typeID": 52189, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V32_XVI_FF.type", "resGender": 1}
1088	2183	{"_key": 2183, "typeID": 52198, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_XVI.type", "resGender": 0}
1089	2184	{"_key": 2184, "typeID": 52200, "resPath": "topMiddle/TshirtM01/Types/TshirtM01_XVI.type", "resGender": 1}
1090	2185	{"_key": 2185, "typeID": 52201, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_XVI.type", "resGender": 0}
1091	2186	{"_key": 2186, "typeID": 52202, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_XVI.type", "resGender": 1}
1092	2187	{"_key": 2187, "typeID": 53038, "resPath": "Makeup/BodyAugmentations/BodyAugmentation_M01/Types/BodyAugmentationM01_Black.type", "resGender": 1, "clothingAlsoCoversCategory": 10, "clothingAlsoCoversCategory2": 10}
1093	2188	{"_key": 2188, "typeID": 53039, "resPath": "Makeup/BodyAugmentations/BodyAugmentation_M01/Types/BodyAugmentationM01_Blue.type", "resGender": 1, "clothingAlsoCoversCategory": 10, "clothingAlsoCoversCategory2": 10}
1094	2189	{"_key": 2189, "typeID": 53040, "resPath": "Makeup/BodyAugmentations/BodyAugmentation_M01/Types/BodyAugmentationM01_GoldDesign.type", "resGender": 1, "clothingAlsoCoversCategory": 10, "clothingAlsoCoversCategory2": 10}
1095	2190	{"_key": 2190, "typeID": 53041, "resPath": "Makeup/BodyAugmentations/BodyAugmentation_M01/Types/BodyAugmentationM01_Red.type", "resGender": 1, "clothingAlsoCoversCategory": 10, "clothingAlsoCoversCategory2": 10}
1096	2191	{"_key": 2191, "typeID": 53042, "resPath": "Makeup/BodyAugmentations/BodyAugmentation_M01/Types/BodyAugmentationM01_WhiteDesign.type", "resGender": 1, "clothingAlsoCoversCategory": 10, "clothingAlsoCoversCategory2": 10}
1097	2192	{"_key": 2192, "typeID": 53043, "resPath": "Makeup/BodyAugmentations/BodyAugmentation_M01/Types/BodyAugmentationM01_YellowDesign.type", "resGender": 1, "clothingAlsoCoversCategory": 10, "clothingAlsoCoversCategory2": 10}
1098	2193	{"_key": 2193, "typeID": 53226, "resPath": "Makeup/BodyAugmentations/BodyAugmentation_F01/Types/BodyAugmentationF01_Black.type", "resGender": 0, "clothingAlsoCoversCategory": 10, "clothingAlsoCoversCategory2": 10}
1099	2194	{"_key": 2194, "typeID": 53227, "resPath": "Makeup/BodyAugmentations/BodyAugmentation_F01/Types/BodyAugmentationF01_Blue.type", "resGender": 0, "clothingAlsoCoversCategory": 10, "clothingAlsoCoversCategory2": 10}
1100	2195	{"_key": 2195, "typeID": 53228, "resPath": "Makeup/BodyAugmentations/BodyAugmentation_F01/Types/BodyAugmentationF01_GoldCamo.type", "resGender": 0, "clothingAlsoCoversCategory": 10, "clothingAlsoCoversCategory2": 10}
1101	2196	{"_key": 2196, "typeID": 53229, "resPath": "Makeup/BodyAugmentations/BodyAugmentation_F01/Types/BodyAugmentationF01_Red.type", "resGender": 0, "clothingAlsoCoversCategory": 10, "clothingAlsoCoversCategory2": 10}
1102	2197	{"_key": 2197, "typeID": 53230, "resPath": "Makeup/BodyAugmentations/BodyAugmentation_F01/Types/BodyAugmentationF01_WhiteCamo.type", "resGender": 0, "clothingAlsoCoversCategory": 10, "clothingAlsoCoversCategory2": 10}
1103	2198	{"_key": 2198, "typeID": 53231, "resPath": "Makeup/BodyAugmentations/BodyAugmentation_F01/Types/BodyAugmentationF01_YellowCamo.type", "resGender": 0, "clothingAlsoCoversCategory": 10, "clothingAlsoCoversCategory2": 10}
1104	2199	{"_key": 2199, "typeID": 53357, "resPath": "Outer/ExplorationSuit_F01/Types/ExplorationSuit_F01_Aurora.type", "resGender": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
1105	2200	{"_key": 2200, "typeID": 53380, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_Aurora.type", "resGender": 0}
1106	2201	{"_key": 2201, "typeID": 53381, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_Aurora.type", "resGender": 0}
1107	2202	{"_key": 2202, "typeID": 53382, "resPath": "outer/ExplorationSuit_M01/Types/ExplorationSuit_M01_ Aurora.type", "resGender": 1, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
1108	2203	{"_key": 2203, "typeID": 53383, "resPath": "topMiddle/TshirtM01/Types/TshirtM01_ Aurora.type", "resGender": 1}
1109	2204	{"_key": 2204, "typeID": 53384, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_ Aurora.type", "resGender": 1}
1110	2205	{"_key": 2205, "typeID": 53385, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V10_Red.type", "resGender": 0}
1111	2206	{"_key": 2206, "typeID": 53386, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V32_Aurora.type", "resGender": 0}
1112	2207	{"_key": 2207, "typeID": 53393, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V33_ Aurora.type", "resGender": 1}
1113	2208	{"_key": 2208, "typeID": 53394, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V10_Red.type", "resGender": 1}
1114	2209	{"_key": 2209, "typeID": 54158, "resPath": "Outer/LabCoatF01/Types/LabCoatF01_ConcordFF.type", "resGender": 0}
1115	2210	{"_key": 2210, "typeID": 54177, "resPath": "outer/LabCoatM01/Types/LabCoatM01_ConcordFF.type", "resGender": 1}
1116	2211	{"_key": 2211, "typeID": 54193, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_RFS.type", "resGender": 0}
1117	2212	{"_key": 2212, "typeID": 54194, "resPath": "topMiddle/TshirtM01/Types/TshirtM01_RFS.type", "resGender": 1}
1118	2213	{"_key": 2213, "typeID": 54299, "resPath": "Outer/JacketPrtF01/Types/JacketPrtF01_guristashunt.type", "resGender": 0}
1119	2214	{"_key": 2214, "typeID": 54303, "resPath": "Feet/BootsPrtF01/Types/BootsPrtF01_guristashunt.type", "resGender": 0}
1120	2215	{"_key": 2215, "typeID": 54304, "resPath": "hair/HeadWear_Beret_F01/Types/HeadWear_Beret_GuristasHuntF01.type", "resGender": 0}
1121	2216	{"_key": 2216, "typeID": 54306, "resPath": "bottomOuter/PantsPrtF01/Types/PantsPrtF01_guristashunt.type", "resGender": 0}
1122	2217	{"_key": 2217, "typeID": 54307, "resPath": "outer/JacketPrtm01/Types/JacketPrtm01_guristashunt.type", "resGender": 1}
1123	2218	{"_key": 2218, "typeID": 54308, "resPath": "bottomOuter/PantsPrtm01/Types/PantsPrtm01_guristashunt.type", "resGender": 1}
1124	2219	{"_key": 2219, "typeID": 54309, "resPath": "Feet/BootsPrtm01/Types/BootsPrtm01_guristashunt.type", "resGender": 1}
1125	2220	{"_key": 2220, "typeID": 54310, "resPath": "hair/HeadWear_Beret_M01/Types/HeadWear_Beret_GuristasHuntM01.type", "resGender": 1}
1126	2221	{"_key": 2221, "typeID": 54320, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_XVII.type", "resGender": 0}
1127	2222	{"_key": 2222, "typeID": 54322, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_XVII.type", "resGender": 0}
1128	2223	{"_key": 2223, "typeID": 54327, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_XVII.type", "resGender": 1}
1129	2224	{"_key": 2224, "typeID": 54328, "resPath": "topMiddle/TshirtM01/Types/TshirtM01_XVII.type", "resGender": 1}
1130	2225	{"_key": 2225, "typeID": 54359, "resPath": "Outer/JacketCorpBusinessF01/Types/JacketCorpBusinessF01_Black.type", "resGender": 0}
1131	2226	{"_key": 2226, "typeID": 54360, "resPath": "Outer/JacketCorpBusinessF01/Types/JacketCorpBusinessF01_Blue_Tie.type", "resGender": 0}
1132	2227	{"_key": 2227, "typeID": 54361, "resPath": "Outer/JacketCorpBusinessF01/Types/JacketCorpBusinessF01_BrownStripes.type", "resGender": 0}
1133	2228	{"_key": 2228, "typeID": 54362, "resPath": "Outer/JacketCorpBusinessF01/Types/JacketCorpBusinessF01_GrayDark_Tie.type", "resGender": 0}
1134	2229	{"_key": 2229, "typeID": 54363, "resPath": "Outer/JacketCorpBusinessF01/Types/JacketCorpBusinessF01_Red.type", "resGender": 0}
1135	2230	{"_key": 2230, "typeID": 54364, "resPath": "Outer/JacketCorpBusinessF01/Types/JacketCorpBusinessF01_White_Tie.type", "resGender": 0}
1136	2231	{"_key": 2231, "typeID": 54365, "resPath": "bottomOuter/PantsCorpBusinessF01/Types/PantsCorpBusinessF01_Black.type", "resGender": 0}
1137	2232	{"_key": 2232, "typeID": 54366, "resPath": "bottomOuter/PantsCorpBusinessF01/Types/PantsCorpBusinessF01_Blue.type", "resGender": 0}
1138	2233	{"_key": 2233, "typeID": 54367, "resPath": "bottomOuter/PantsCorpBusinessF01/Types/PantsCorpBusinessF01_BrownStripes.type", "resGender": 0}
1139	2234	{"_key": 2234, "typeID": 54368, "resPath": "bottomOuter/PantsCorpBusinessF01/Types/PantsCorpBusinessF01_GrayDark.type", "resGender": 0}
1140	2235	{"_key": 2235, "typeID": 54369, "resPath": "bottomOuter/PantsCorpBusinessF01/Types/PantsCorpBusinessF01_Red.type", "resGender": 0}
1141	2236	{"_key": 2236, "typeID": 54370, "resPath": "bottomOuter/PantsCorpBusinessF01/Types/PantsCorpBusinessF01_White.type", "resGender": 0}
1142	2237	{"_key": 2237, "typeID": 54371, "resPath": "bottomOuter/PantsCorpBusinessM01/Types/PantsCorpBusinessM01_Black.type", "resGender": 1}
1143	2238	{"_key": 2238, "typeID": 54372, "resPath": "bottomOuter/PantsCorpBusinessM01/Types/PantsCorpBusinessM01_Blue.type", "resGender": 1}
1144	2239	{"_key": 2239, "typeID": 54373, "resPath": "bottomOuter/PantsCorpBusinessM01/Types/PantsCorpBusinessM01_BrownStripes.type", "resGender": 1}
1145	2240	{"_key": 2240, "typeID": 54374, "resPath": "bottomOuter/PantsCorpBusinessM01/Types/PantsCorpBusinessM01_GrayDark.type", "resGender": 1}
1146	2241	{"_key": 2241, "typeID": 54375, "resPath": "bottomOuter/PantsCorpBusinessM01/Types/PantsCorpBusinessM01_Red.type", "resGender": 1}
1147	2242	{"_key": 2242, "typeID": 54376, "resPath": "bottomOuter/PantsCorpBusinessM01/Types/PantsCorpBusinessM01_White.type", "resGender": 1}
1148	2243	{"_key": 2243, "typeID": 54377, "resPath": "outer/JacketCorpBusinessM01/Types/JacketCorpBusinessM01_Black.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2}
1149	2244	{"_key": 2244, "typeID": 54378, "resPath": "outer/JacketCorpBusinessM01/Types/JacketCorpBusinessM01_Blue_Tie.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2}
1150	2245	{"_key": 2245, "typeID": 54379, "resPath": "outer/JacketCorpBusinessM01/Types/JacketCorpBusinessM01_BrownStripes.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2}
1151	2246	{"_key": 2246, "typeID": 54380, "resPath": "outer/JacketCorpBusinessM01/Types/JacketCorpBusinessM01_GreyDark_Tie.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2}
1152	2247	{"_key": 2247, "typeID": 54381, "resPath": "outer/JacketCorpBusinessM01/Types/JacketCorpBusinessM01_Red.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2}
1153	2248	{"_key": 2248, "typeID": 54382, "resPath": "outer/JacketCorpBusinessM01/Types/JacketCorpBusinessM01_White_Tie.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2}
1154	2249	{"_key": 2249, "typeID": 54383, "resPath": "Feet/ShoesCorpBusinessM01/Types/ShoesCorpBusinessM01_black.type", "resGender": 1}
1155	2250	{"_key": 2250, "typeID": 54384, "resPath": "Feet/ShoesCorpBusinessM01/Types/ShoesCorpBusinessM01_brown.type", "resGender": 1}
1156	2251	{"_key": 2251, "typeID": 54385, "resPath": "Feet/ShoesCorpBusinessM01/Types/ShoesCorpBusinessM01_darkbrown.type", "resGender": 1}
1157	2252	{"_key": 2252, "typeID": 54386, "resPath": "Feet/ShoesCorpBusinessM01/Types/ShoesCorpBusinessM01_white.type", "resGender": 1}
1158	2253	{"_key": 2253, "typeID": 54714, "resPath": "Accessories/Masks/Mask_F/Types/Mask_F_cyan.type", "resGender": 0}
1159	2254	{"_key": 2254, "typeID": 54715, "resPath": "Accessories/Masks/Mask_F/Types/Mask_F_blackredsoe.type", "resGender": 0}
1160	2255	{"_key": 2255, "typeID": 54716, "resPath": "Accessories/Masks/Mask_F/Types/Mask_F_darkblue.type", "resGender": 0}
1161	2256	{"_key": 2256, "typeID": 54719, "resPath": "Accessories/Masks/Mask_M/Types/Mask_M_blackredsoe.type", "resGender": 1}
1162	2257	{"_key": 2257, "typeID": 54718, "resPath": "Accessories/Masks/Mask_M/Types/Mask_M_blue.type", "resGender": 1}
1163	2258	{"_key": 2258, "typeID": 54720, "resPath": "Accessories/Masks/Mask_M/Types/Mask_M_darkblue.type", "resGender": 1}
1164	2259	{"_key": 2259, "typeID": 54830, "resPath": "Accessories/Masks/Mask_M/Types/Mask_M_cyan.type", "resGender": 1}
1165	2260	{"_key": 2260, "typeID": 54926, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V3_GoldBlue.type", "resGender": 1}
1166	2261	{"_key": 2261, "typeID": 54927, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V7_Blue.type", "resGender": 0}
1167	2263	{"_key": 2263, "typeID": 54943, "resPath": "topMiddle/TshirtM01/Types/TshirtM01_Covid.type", "resGender": 1}
1168	2264	{"_key": 2264, "typeID": 54944, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_Covid.type", "resGender": 0}
1169	2265	{"_key": 2265, "typeID": 54948, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_Covid.type", "resGender": 1}
1170	2266	{"_key": 2266, "typeID": 54949, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_Covid.type", "resGender": 0}
1171	3470	{"_key": 3470, "typeID": 4131, "resPath": "Feet/BootsMilF02/Types/BootsMilF02_red.type", "resGender": 0}
1172	3471	{"_key": 3471, "typeID": 34047, "resPath": "bottomMiddle/TightsF01/Types/TightsF01_pink.type", "resGender": 0}
1173	3472	{"_key": 3472, "typeID": 4144, "resPath": "Outer/JacketMilF02/Types/JacketMilF02_blackwhite.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
1174	3473	{"_key": 3473, "typeID": 4123, "resPath": "Feet/BootsMilF01/Types/BootsMilF01_matred.type", "resGender": 0}
1175	3474	{"_key": 3474, "typeID": 34007, "resPath": "Tattoo/ArmRight/Sleeve02/Type/Sleeve02_M_Right.type", "resGender": 1}
1176	3475	{"_key": 3475, "typeID": 33378, "resPath": "Tattoo/ArmLeft/Sleeve05/Types/Sleeve05_F_Left.type", "resGender": 0}
1177	3476	{"_key": 3476, "typeID": 4069, "resPath": "bottomOuter/SkirtMilF01/Types/SkirtMilF01_marine.type", "resGender": 0}
1178	3477	{"_key": 3477, "typeID": 4199, "resPath": "TopMiddle/TanktopM01/Types/TanktopM01_p04.type", "resGender": 1}
1179	3478	{"_key": 3478, "typeID": 4181, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_blue2.type", "resGender": 1}
1180	3479	{"_key": 3479, "typeID": 4193, "resPath": "TopMiddle/TanktopM01/Types/TanktopM01_brown.type", "resGender": 1}
1181	3480	{"_key": 3480, "typeID": 4165, "resPath": "bottomOuter/PantsMilM01/Types/PantsMilM01_black.type", "resGender": 1}
1182	3481	{"_key": 3481, "typeID": 34012, "resPath": "Tattoo/ArmRight/Sleeve10/Type/Sleeve10_M_Right.type", "resGender": 1}
1183	3482	{"_key": 3482, "typeID": 4216, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_black.type", "resGender": 0}
1184	3483	{"_key": 3483, "typeID": 4153, "resPath": "Outer/JacketMilF02/Types/JacketMilF02_red.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
1185	3484	{"_key": 3484, "typeID": 4070, "resPath": "bottomOuter/SkirtMilF01/Types/SkirtMilF01_matblack.type", "resGender": 0}
1186	3485	{"_key": 3485, "typeID": 34012, "resPath": "Tattoo/ArmRight/Sleeve10/Type/Sleeve10_F_Right.type", "resGender": 0}
1187	3486	{"_key": 3486, "typeID": 4175, "resPath": "Feet/BootsMilM02/Types/BootsMilM02_gray.type", "resGender": 1}
1188	3487	{"_key": 3487, "typeID": 33996, "resPath": "Tattoo/ArmLeft/Sleeve02/Types/Sleeve02_F_Left.type", "resGender": 0}
1189	3488	{"_key": 3488, "typeID": 4126, "resPath": "Feet/BootsMilF01/Types/BootsMilF01_turquoise.type", "resGender": 0}
1190	3489	{"_key": 3489, "typeID": 4205, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_darkblue.type", "resGender": 0}
1191	3490	{"_key": 3490, "typeID": 33380, "resPath": "Tattoo/ArmLeft/Sleeve08/Types/Sleeve08_M_Left.type", "resGender": 1}
1192	3491	{"_key": 3491, "typeID": 33384, "resPath": "Tattoo/ArmRight/Sleeve08/Type/Sleeve08_M_Right.type", "resGender": 1}
1193	3492	{"_key": 3492, "typeID": 4218, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_blue.type", "resGender": 0}
1194	3493	{"_key": 3493, "typeID": 4188, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_p_darkcaldari.type", "resGender": 1}
1195	3494	{"_key": 3494, "typeID": 4178, "resPath": "Feet/BootsMilM03/Types/BootsMilM03_gray.type", "resGender": 1}
1196	3495	{"_key": 3495, "typeID": 34010, "resPath": "Tattoo/ArmRight/Sleeve07/Type/Sleeve07_F_Right.type", "resGender": 0}
1197	3496	{"_key": 3496, "typeID": 33377, "resPath": "Tattoo/ArmLeft/Sleeve04/Types/Sleeve04_M_Left.type", "resGender": 1}
1198	3497	{"_key": 3497, "typeID": 4146, "resPath": "Outer/JacketMilF02/Types/JacketMilF02_goldblack.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
1199	3498	{"_key": 3498, "typeID": 33999, "resPath": "Tattoo/ArmLeft/Sleeve07/Types/Sleeve07_M_Left.type", "resGender": 1}
1200	3499	{"_key": 3499, "typeID": 33382, "resPath": "Tattoo/ArmRight/Sleeve05/Type/Sleeve05_M_Right.type", "resGender": 1}
1201	3500	{"_key": 3500, "typeID": 34001, "resPath": "Tattoo/ArmLeft/Sleeve10/Types/Sleeve10_F_Left.type", "resGender": 0}
1202	3501	{"_key": 3501, "typeID": 34002, "resPath": "Tattoo/ArmLeft/Sleeve11/Types/Sleeve11_F_Left.type", "resGender": 0}
1203	3502	{"_key": 3502, "typeID": 34050, "resPath": "bottomMiddle/TightsF01/Types/TightsF01_thickblue.type", "resGender": 0}
1204	3503	{"_key": 3503, "typeID": 33996, "resPath": "Tattoo/ArmLeft/Sleeve02/Types/Sleeve02_M_Left.type", "resGender": 1}
1205	3504	{"_key": 3504, "typeID": 4103, "resPath": "bottomOuter/SkirtMilF02/Types/SkirtMilF02_graphite.type", "resGender": 0}
1206	3505	{"_key": 3505, "typeID": 4139, "resPath": "Outer/JacketMilF01/Types/JacketMilF01_matblue.type", "resGender": 0}
1207	3506	{"_key": 3506, "typeID": 4167, "resPath": "bottomOuter/PantsMilM01/Types/PantsMilM01_goldblack.type", "resGender": 1}
1208	3507	{"_key": 3507, "typeID": 34000, "resPath": "Tattoo/ArmLeft/Sleeve09/Types/Sleeve09_F_Left.type", "resGender": 0}
1209	3508	{"_key": 3508, "typeID": 4108, "resPath": "bottomOuter/SkirtMilF02/Types/SkirtMilF02_greenstripes.type", "resGender": 0}
1210	3509	{"_key": 3509, "typeID": 4116, "resPath": "Feet/BootsMilF01/Types/BootsMilF01_blackgold.type", "resGender": 0}
1211	3510	{"_key": 3510, "typeID": 34014, "resPath": "Tattoo/ArmRight/Sleeve12/Type/Sleeve12_F_Right.type", "resGender": 0}
1212	3511	{"_key": 3511, "typeID": 34009, "resPath": "Tattoo/ArmRight/Sleeve06/Type/Sleeve06_M_Right.type", "resGender": 1}
1213	3512	{"_key": 3512, "typeID": 4202, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_blue2.type", "resGender": 0}
1214	3513	{"_key": 3513, "typeID": 34015, "resPath": "Tattoo/ArmRight/Sleeve13/Type/Sleeve13_F_Right.type", "resGender": 0}
1215	3514	{"_key": 3514, "typeID": 4173, "resPath": "Feet/BootsMilM01/Types/BootsMilM01_wornbrown.type", "resGender": 1}
1216	3515	{"_key": 3515, "typeID": 34015, "resPath": "Tattoo/ArmRight/Sleeve13/Type/Sleeve13_M_Right.type", "resGender": 1}
1217	3516	{"_key": 3516, "typeID": 4244, "resPath": "outer/JacketMilM01/Types/JacketMilM01_green.type", "resGender": 1}
1218	3517	{"_key": 3517, "typeID": 34006, "resPath": "Tattoo/ArmRight/Sleeve01/Type/Sleeve01_F_Right.type", "resGender": 0}
1219	3518	{"_key": 3518, "typeID": 4225, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_p03.type", "resGender": 0}
1220	3519	{"_key": 3519, "typeID": 4190, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_white.type", "resGender": 1}
1221	3520	{"_key": 3520, "typeID": 34011, "resPath": "Tattoo/ArmRight/Sleeve09/Type/Sleeve09_F_Right.type", "resGender": 0}
1222	3521	{"_key": 3521, "typeID": 4072, "resPath": "bottomOuter/SkirtMilF01/Types/SkirtMilF01_matred.type", "resGender": 0}
1223	3522	{"_key": 3522, "typeID": 33381, "resPath": "Tattoo/ArmRight/Sleeve04/Type/Sleeve04_M_Right.type", "resGender": 1}
1224	3523	{"_key": 3523, "typeID": 4033, "resPath": "bottomOuter/SkirtMilF01/Types/SkirtMilF01_blackleather.type", "resGender": 0}
1225	3524	{"_key": 3524, "typeID": 4197, "resPath": "TopMiddle/TanktopM01/Types/TanktopM01_p02.type", "resGender": 1}
1226	3525	{"_key": 3525, "typeID": 4228, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_p06.type", "resGender": 0}
1227	3526	{"_key": 3526, "typeID": 4115, "resPath": "bottomOuter/SkirtMilF02/Types/SkirtMilF02_whitestripes.type", "resGender": 0}
1228	3527	{"_key": 3527, "typeID": 4219, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_brown.type", "resGender": 0}
1229	3528	{"_key": 3528, "typeID": 4208, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_green.type", "resGender": 0}
1230	3529	{"_key": 3529, "typeID": 4214, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_red.type", "resGender": 0}
1231	3530	{"_key": 3530, "typeID": 4212, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_p_darkcaldari.type", "resGender": 0}
1232	3531	{"_key": 3531, "typeID": 4211, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_orange.type", "resGender": 0}
1233	3532	{"_key": 3532, "typeID": 34005, "resPath": "Tattoo/ArmLeft/Sleeve15/Types/Sleeve15_F_Left.type", "resGender": 0}
1234	3533	{"_key": 3533, "typeID": 4030, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_matred.type", "resGender": 0}
1235	3534	{"_key": 3534, "typeID": 34009, "resPath": "Tattoo/ArmRight/Sleeve06/Type/Sleeve06_F_Right.type", "resGender": 0}
1236	3535	{"_key": 3535, "typeID": 33998, "resPath": "Tattoo/ArmLeft/Sleeve06/Types/Sleeve06_M_Left.type", "resGender": 1}
1237	3536	{"_key": 3536, "typeID": 4158, "resPath": "TopOuter/ShirtMilF01/Types/ShirtMilF01_graphite.type", "resGender": 0}
1238	3537	{"_key": 3537, "typeID": 4155, "resPath": "TopOuter/ShirtMilF01/Types/ShirtMilF01_blackleather.type", "resGender": 0}
1239	3538	{"_key": 3538, "typeID": 4177, "resPath": "Feet/BootsMilM03/Types/BootsMilM03_brown.type", "resGender": 1}
1240	3539	{"_key": 3539, "typeID": 33382, "resPath": "Tattoo/ArmRight/Sleeve05/Type/Sleeve05_F_Right.type", "resGender": 0}
1241	3540	{"_key": 3540, "typeID": 4201, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_black.type", "resGender": 0}
1242	3541	{"_key": 3541, "typeID": 4021, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_blacksilver.type", "resGender": 0}
1243	3542	{"_key": 3542, "typeID": 4032, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_silver.type", "resGender": 0}
1244	3543	{"_key": 3543, "typeID": 4198, "resPath": "TopMiddle/TanktopM01/Types/TanktopM01_p03.type", "resGender": 1}
1245	3544	{"_key": 3544, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_blue.type", "resGender": 0}
1246	3545	{"_key": 3545, "typeID": 4168, "resPath": "bottomOuter/PantsMilM01/Types/PantsMilM01_grayblack.type", "resGender": 1}
1247	3546	{"_key": 3546, "typeID": 34004, "resPath": "Tattoo/ArmLeft/Sleeve13/Types/Sleeve13_F_Left.type", "resGender": 0}
1248	3547	{"_key": 3547, "typeID": 4161, "resPath": "TopOuter/ShirtMilF01/Types/ShirtMilF01_matblue.type", "resGender": 0}
1249	3548	{"_key": 3548, "typeID": 33383, "resPath": "Tattoo/ArmRight/Sleeve14/Type/Sleeve14_F_Right.type", "resGender": 0}
1250	3549	{"_key": 3549, "typeID": 4105, "resPath": "bottomOuter/SkirtMilF02/Types/SkirtMilF02_graystripes.type", "resGender": 0}
1251	3550	{"_key": 3550, "typeID": 4200, "resPath": "TopMiddle/TanktopM01/Types/TanktopM01_white.type", "resGender": 1}
1252	3551	{"_key": 3551, "typeID": 34016, "resPath": "Tattoo/ArmRight/Sleeve15/Type/Sleeve15_F_Right.type", "resGender": 0}
1253	3552	{"_key": 3552, "typeID": 4137, "resPath": "Outer/JacketMilF01/Types/JacketMilF01_graphite.type", "resGender": 0}
1254	3553	{"_key": 3553, "typeID": 34007, "resPath": "Tattoo/ArmRight/Sleeve02/Type/Sleeve02_F_Right.type", "resGender": 0}
1255	3554	{"_key": 3554, "typeID": 4184, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_darkred.type", "resGender": 1}
1256	3555	{"_key": 3555, "typeID": 4076, "resPath": "bottomOuter/SkirtMilF02/Types/SkirtMilF02_blackred.type", "resGender": 0}
1257	3556	{"_key": 3556, "typeID": 4232, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_white.type", "resGender": 0}
1258	3557	{"_key": 3557, "typeID": 4240, "resPath": "TopOuter/ShirtMilM01/Types/ShirtMilM01_goldleather.type", "resGender": 1}
1259	3558	{"_key": 3558, "typeID": 4186, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_lightgray.type", "resGender": 1}
1260	3559	{"_key": 3559, "typeID": 4136, "resPath": "Outer/JacketMilF01/Types/JacketMilF01_black.type", "resGender": 0}
1261	3560	{"_key": 3560, "typeID": 4227, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_p05.type", "resGender": 0}
1262	3561	{"_key": 3561, "typeID": 34051, "resPath": "bottomMiddle/TightsF01/Types/TightsF01_thickgray.type", "resGender": 0}
1263	3562	{"_key": 3562, "typeID": 4196, "resPath": "TopMiddle/TanktopM01/Types/TanktopM01_p01.type", "resGender": 1}
1264	3563	{"_key": 3563, "typeID": 4150, "resPath": "Outer/JacketMilF02/Types/JacketMilF02_green.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
1265	3564	{"_key": 3564, "typeID": 4238, "resPath": "outer/JacketMilM02/Types/JacketMilM02_redgold.type", "resGender": 1}
1266	3565	{"_key": 3565, "typeID": 4074, "resPath": "bottomOuter/SkirtMilF01/Types/SkirtMilF01_silver.type", "resGender": 0}
1267	3566	{"_key": 3566, "typeID": 4243, "resPath": "TopOuter/ShirtMilM01/Types/ShirtMilM01_whiteblue.type", "resGender": 1}
1268	3567	{"_key": 3567, "typeID": 4156, "resPath": "TopOuter/ShirtMilF01/Types/ShirtMilF01_blackwhite.type", "resGender": 0}
1269	3568	{"_key": 3568, "typeID": 4236, "resPath": "outer/JacketMilM02/Types/JacketMilM02_matgray.type", "resGender": 1}
1270	3569	{"_key": 3569, "typeID": 4135, "resPath": "Feet/BootsMilF03/Types/BootsMilF03_whiteblack.type", "resGender": 0}
1271	3570	{"_key": 3570, "typeID": 4113, "resPath": "bottomOuter/SkirtMilF02/Types/SkirtMilF02_redleather.type", "resGender": 0}
1272	3571	{"_key": 3571, "typeID": 34008, "resPath": "Tattoo/ArmRight/Sleeve03/Type/Sleeve03_F_Right.type", "resGender": 0}
1273	3572	{"_key": 3572, "typeID": 34054, "resPath": "bottomMiddle/TightsF01/Types/TightsF01_white.type", "resGender": 0}
1274	3573	{"_key": 3573, "typeID": 34011, "resPath": "Tattoo/ArmRight/Sleeve09/Type/Sleeve09_M_Right.type", "resGender": 1}
1275	3574	{"_key": 3574, "typeID": 34045, "resPath": "bottomMiddle/TightsF01/Types/TightsF01_light.type", "resGender": 0}
1276	3575	{"_key": 3575, "typeID": 4132, "resPath": "Feet/BootsMilF03/Types/BootsMilF03_blackwhite.type", "resGender": 0}
1277	3576	{"_key": 3576, "typeID": 4172, "resPath": "Feet/BootsMilM01/Types/BootsMilM01_trueblack.type", "resGender": 1}
1278	3577	{"_key": 3577, "typeID": 34014, "resPath": "Tattoo/ArmRight/Sleeve12/Type/Sleeve12_M_Right.type", "resGender": 1}
1279	3578	{"_key": 3578, "typeID": 4220, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_gray.type", "resGender": 0}
1280	3579	{"_key": 3579, "typeID": 4206, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_darkred.type", "resGender": 0}
1281	3580	{"_key": 3580, "typeID": 4019, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_blackgoldline.type", "resGender": 0}
1282	3581	{"_key": 3581, "typeID": 33379, "resPath": "Tattoo/ArmLeft/Sleeve14/Types/Sleeve14_M_Left.type", "resGender": 1}
1283	3582	{"_key": 3582, "typeID": 4101, "resPath": "bottomOuter/SkirtMilF02/Types/SkirtMilF02_blackwhite.type", "resGender": 0}
1284	3583	{"_key": 3583, "typeID": 4192, "resPath": "TopMiddle/TanktopM01/Types/TanktopM01_blue.type", "resGender": 1}
1285	3584	{"_key": 3584, "typeID": 33997, "resPath": "Tattoo/ArmLeft/Sleeve03/Types/Sleeve03_M_Left.type", "resGender": 1}
1286	3585	{"_key": 3585, "typeID": 4134, "resPath": "Feet/BootsMilF03/Types/BootsMilF03_red.type", "resGender": 0}
1287	3586	{"_key": 3586, "typeID": 4111, "resPath": "bottomOuter/SkirtMilF02/Types/SkirtMilF02_matblack.type", "resGender": 0}
1288	3587	{"_key": 3587, "typeID": 4207, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_gray.type", "resGender": 0}
1289	3588	{"_key": 3588, "typeID": 33380, "resPath": "Tattoo/ArmLeft/Sleeve08/Types/Sleeve08_F_Left.type", "resGender": 0}
1290	3589	{"_key": 3589, "typeID": 4242, "resPath": "TopOuter/ShirtMilM01/Types/ShirtMilM01_redblackleather.type", "resGender": 1}
1291	3590	{"_key": 3590, "typeID": 4191, "resPath": "TopMiddle/TanktopM01/Types/TanktopM01_black.type", "resGender": 1}
1292	3591	{"_key": 3591, "typeID": 4028, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_matgreen.type", "resGender": 0}
1293	3592	{"_key": 3592, "typeID": 4221, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_green.type", "resGender": 0}
1294	3593	{"_key": 3593, "typeID": 4073, "resPath": "bottomOuter/SkirtMilF01/Types/SkirtMilF01_redgold.type", "resGender": 0}
1295	3594	{"_key": 3594, "typeID": 4180, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_black.type", "resGender": 1}
1296	3595	{"_key": 3595, "typeID": 4020, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_blackredgold.type", "resGender": 0}
1297	3596	{"_key": 3596, "typeID": 4233, "resPath": "outer/JacketMilM02/Types/JacketMilM02_black.type", "resGender": 1}
1298	3597	{"_key": 3597, "typeID": 34046, "resPath": "bottomMiddle/TightsF01/Types/TightsF01_orange.type", "resGender": 0}
1299	3598	{"_key": 3598, "typeID": 4230, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_p08.type", "resGender": 0}
1300	3599	{"_key": 3599, "typeID": 4128, "resPath": "Feet/BootsMilF02/Types/BootsMilF02_brown.type", "resGender": 0}
1301	3600	{"_key": 3600, "typeID": 34016, "resPath": "Tattoo/ArmRight/Sleeve15/Type/Sleeve15_M_Right.type", "resGender": 1}
1302	3601	{"_key": 3601, "typeID": 4245, "resPath": "outer/JacketMilM01/Types/JacketMilM01_silver.type", "resGender": 1}
1303	3602	{"_key": 3602, "typeID": 4163, "resPath": "TopOuter/ShirtMilF01/Types/ShirtMilF01_orangesatin.type", "resGender": 0}
1304	3603	{"_key": 3603, "typeID": 34002, "resPath": "Tattoo/ArmLeft/Sleeve11/Types/Sleeve11_M_Left.type", "resGender": 1}
1305	3604	{"_key": 3604, "typeID": 4213, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_p_desertcamo.type", "resGender": 0}
1306	3605	{"_key": 3605, "typeID": 4169, "resPath": "bottomOuter/PantsMilM01/Types/PantsMilM01_p_browncamo.type", "resGender": 1}
1307	3606	{"_key": 3606, "typeID": 4174, "resPath": "Feet/BootsMilM02/Types/BootsMilM02_brown.type", "resGender": 1}
1308	3607	{"_key": 3607, "typeID": 34055, "resPath": "bottomMiddle/TightsF01/Types/TightsF01_yellow.type", "resGender": 0}
1309	3608	{"_key": 3608, "typeID": 33989, "resPath": "bottomMiddle/TightsF01/Types/TightsF01_black.type", "resGender": 0}
1310	3609	{"_key": 3609, "typeID": 4209, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_khaki.type", "resGender": 0}
1311	3610	{"_key": 3610, "typeID": 4145, "resPath": "Outer/JacketMilF02/Types/JacketMilF02_brown.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
1312	3611	{"_key": 3611, "typeID": 4222, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_orange.type", "resGender": 0}
1313	3612	{"_key": 3612, "typeID": 4157, "resPath": "TopOuter/ShirtMilF01/Types/ShirtMilF01_gold.type", "resGender": 0}
1314	3613	{"_key": 3613, "typeID": 4171, "resPath": "bottomOuter/PantsMilM01/Types/PantsMilM01_redblack.type", "resGender": 1}
1315	3614	{"_key": 3614, "typeID": 33384, "resPath": "Tattoo/ArmRight/Sleeve08/Type/Sleeve08_F_Right.type", "resGender": 0}
1316	3615	{"_key": 3615, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_x01.type", "resGender": 0}
1317	3616	{"_key": 3616, "typeID": 4189, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_p_desertcamo.type", "resGender": 1}
1318	3617	{"_key": 3617, "typeID": 33995, "resPath": "Tattoo/ArmLeft/Sleeve01/Types/Sleeve01_F_Left.type", "resGender": 0}
1319	3618	{"_key": 3618, "resPath": "TopOuter/ShirtMilM01/Types/ShirtMilM01_goldsilver.type", "resGender": 1}
1320	3619	{"_key": 3619, "typeID": 34003, "resPath": "Tattoo/ArmLeft/Sleeve12/Types/Sleeve12_M_Left.type", "resGender": 1}
1321	3620	{"_key": 3620, "typeID": 4138, "resPath": "Outer/JacketMilF01/Types/JacketMilF01_greengold.type", "resGender": 0}
1322	3621	{"_key": 3621, "typeID": 34053, "resPath": "bottomMiddle/TightsF01/Types/TightsF01_thickpurple.type", "resGender": 0}
1323	3622	{"_key": 3622, "typeID": 4203, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_brown.type", "resGender": 0}
1324	3623	{"_key": 3623, "typeID": 4149, "resPath": "Outer/JacketMilF02/Types/JacketMilF02_graphite.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
1325	3624	{"_key": 3624, "typeID": 4142, "resPath": "Outer/JacketMilF01/Types/JacketMilF01_silver.type", "resGender": 0}
1326	3625	{"_key": 3625, "typeID": 4235, "resPath": "outer/JacketMilM02/Types/JacketMilM02_matgraphite.type", "resGender": 1}
1327	3626	{"_key": 3626, "typeID": 4183, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_darkblue.type", "resGender": 1}
1328	3627	{"_key": 3627, "typeID": 34006, "resPath": "Tattoo/ArmRight/Sleeve01/Type/Sleeve01_M_Right.type", "resGender": 1}
1329	3628	{"_key": 3628, "typeID": 4215, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_white.type", "resGender": 0}
1330	3629	{"_key": 3629, "typeID": 33995, "resPath": "Tattoo/ArmLeft/Sleeve01/Types/Sleeve01_M_Left.type", "resGender": 1}
1331	3630	{"_key": 3630, "typeID": 4187, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_olive.type", "resGender": 1}
1332	3631	{"_key": 3631, "typeID": 4102, "resPath": "bottomOuter/SkirtMilF02/Types/SkirtMilF02_blue.type", "resGender": 0}
1333	3632	{"_key": 3632, "typeID": 4164, "resPath": "TopOuter/ShirtMilF01/Types/ShirtMilF01_redsatin.type", "resGender": 0}
1334	3633	{"_key": 3633, "typeID": 4125, "resPath": "Feet/BootsMilF01/Types/BootsMilF01_silver.type", "resGender": 0}
1335	3634	{"_key": 3634, "typeID": 4151, "resPath": "Outer/JacketMilF02/Types/JacketMilF02_matblue.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
1336	3635	{"_key": 3635, "typeID": 4231, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_red.type", "resGender": 0}
1337	3636	{"_key": 3636, "typeID": 34004, "resPath": "Tattoo/ArmLeft/Sleeve13/Types/Sleeve13_M_Left.type", "resGender": 1}
1338	3637	{"_key": 3637, "typeID": 4117, "resPath": "Feet/BootsMilF01/Types/BootsMilF01_blackred.type", "resGender": 0}
1339	3638	{"_key": 3638, "typeID": 4195, "resPath": "TopMiddle/TanktopM01/Types/TanktopM01_green.type", "resGender": 1}
1340	3639	{"_key": 3639, "typeID": 34008, "resPath": "Tattoo/ArmRight/Sleeve03/Type/Sleeve03_M_Right.type", "resGender": 1}
1341	3640	{"_key": 3640, "typeID": 4114, "resPath": "bottomOuter/SkirtMilF02/Types/SkirtMilF02_redstripes.type", "resGender": 0}
1342	3641	{"_key": 3641, "typeID": 33381, "resPath": "Tattoo/ArmRight/Sleeve04/Type/Sleeve04_F_Right.type", "resGender": 0}
1343	3642	{"_key": 3642, "typeID": 4130, "resPath": "Feet/BootsMilF02/Types/BootsMilF02_matgray.type", "resGender": 0}
1344	3643	{"_key": 3643, "typeID": 4241, "resPath": "TopOuter/ShirtMilM01/Types/ShirtMilM01_gray.type", "resGender": 1}
1345	3644	{"_key": 3644, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_x02.type", "resGender": 1}
1346	3645	{"_key": 3645, "typeID": 4124, "resPath": "Feet/BootsMilF01/Types/BootsMilF01_red.type", "resGender": 0}
1347	3646	{"_key": 3646, "typeID": 34048, "resPath": "bottomMiddle/TightsF01/Types/TightsF01_red.type", "resGender": 0}
1348	3647	{"_key": 3647, "typeID": 4018, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_blackgold.type", "resGender": 0}
1349	3648	{"_key": 3648, "typeID": 4140, "resPath": "Outer/JacketMilF01/Types/JacketMilF01_matred.type", "resGender": 0}
1350	3649	{"_key": 3649, "typeID": 4152, "resPath": "Outer/JacketMilF02/Types/JacketMilF02_matred.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
1351	3650	{"_key": 3650, "typeID": 4239, "resPath": "outer/JacketMilM02/Types/JacketMilM02_silver.type", "resGender": 1}
1352	3651	{"_key": 3651, "typeID": 4121, "resPath": "Feet/BootsMilF01/Types/BootsMilF01_greenblack.type", "resGender": 0}
1353	3652	{"_key": 3652, "typeID": 4141, "resPath": "Outer/JacketMilF01/Types/JacketMilF01_redgold.type", "resGender": 0}
1354	3653	{"_key": 3653, "typeID": 4162, "resPath": "TopOuter/ShirtMilF01/Types/ShirtMilF01_matolive.type", "resGender": 0}
1355	3654	{"_key": 3654, "typeID": 4022, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_gold.type", "resGender": 0}
1356	3655	{"_key": 3655, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_x02.type", "resGender": 0}
1357	3656	{"_key": 3656, "typeID": 4176, "resPath": "Feet/BootsMilM02/Types/BootsMilM02_tan.type", "resGender": 1}
1358	3657	{"_key": 3657, "typeID": 4170, "resPath": "bottomOuter/PantsMilM01/Types/PantsMilM01_p_greencamo.type", "resGender": 1}
1359	3658	{"_key": 3658, "typeID": 4118, "resPath": "Feet/BootsMilF01/Types/BootsMilF01_blue.type", "resGender": 0}
1360	3659	{"_key": 3659, "typeID": 4234, "resPath": "outer/JacketMilM02/Types/JacketMilM02_greengold.type", "resGender": 1}
1361	3660	{"_key": 3660, "typeID": 4026, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_matblue.type", "resGender": 0}
1362	3661	{"_key": 3661, "typeID": 4154, "resPath": "Outer/JacketMilF02/Types/JacketMilF02_turquoise.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
1363	3662	{"_key": 3662, "typeID": 34003, "resPath": "Tattoo/ArmLeft/Sleeve12/Types/Sleeve12_F_Left.type", "resGender": 0}
1364	3663	{"_key": 3663, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_x01.type", "resGender": 1}
1365	3664	{"_key": 3664, "typeID": 34049, "resPath": "bottomMiddle/TightsF01/Types/TightsF01_thickblack.type", "resGender": 0}
1366	3665	{"_key": 3665, "typeID": 4229, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_p07.type", "resGender": 0}
1367	3666	{"_key": 3666, "typeID": 34000, "resPath": "Tattoo/ArmLeft/Sleeve09/Types/Sleeve09_M_Left.type", "resGender": 1}
1368	3667	{"_key": 3667, "typeID": 4071, "resPath": "bottomOuter/SkirtMilF01/Types/SkirtMilF01_matblue.type", "resGender": 0}
1369	3668	{"_key": 3668, "typeID": 4017, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_blackbluegold.type", "resGender": 0}
1370	3669	{"_key": 3669, "typeID": 4129, "resPath": "Feet/BootsMilF02/Types/BootsMilF02_matbrown.type", "resGender": 0}
1371	3670	{"_key": 3670, "typeID": 34005, "resPath": "Tattoo/ArmLeft/Sleeve15/Types/Sleeve15_M_Left.type", "resGender": 1}
1372	3671	{"_key": 3671, "typeID": 4107, "resPath": "bottomOuter/SkirtMilF02/Types/SkirtMilF02_greenblack.type", "resGender": 0}
1373	3672	{"_key": 3672, "typeID": 4185, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_khaki.type", "resGender": 1}
1374	3673	{"_key": 3673, "typeID": 4143, "resPath": "Outer/JacketMilF02/Types/JacketMilF02_black.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
1375	3674	{"_key": 3674, "typeID": 4127, "resPath": "Feet/BootsMilF02/Types/BootsMilF02_blackgold.type", "resGender": 0}
1376	3675	{"_key": 3675, "typeID": 33998, "resPath": "Tattoo/ArmLeft/Sleeve06/Types/Sleeve06_F_Left.type", "resGender": 0}
1377	3676	{"_key": 3676, "typeID": 4122, "resPath": "Feet/BootsMilF01/Types/BootsMilF01_matblack.type", "resGender": 0}
1378	3677	{"_key": 3677, "typeID": 33383, "resPath": "Tattoo/ArmRight/Sleeve14/Type/Sleeve14_M_Right.type", "resGender": 1}
1379	3678	{"_key": 3678, "typeID": 33378, "resPath": "Tattoo/ArmLeft/Sleeve05/Types/Sleeve05_M_Left.type", "resGender": 1}
1380	3679	{"_key": 3679, "typeID": 4036, "resPath": "bottomOuter/SkirtMilF01/Types/SkirtMilF01_greengold.type", "resGender": 0}
1381	3680	{"_key": 3680, "typeID": 4210, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_olive.type", "resGender": 0}
1382	3681	{"_key": 3681, "typeID": 34013, "resPath": "Tattoo/ArmRight/Sleeve11/Type/Sleeve11_M_Right.type", "resGender": 1}
1383	3682	{"_key": 3682, "typeID": 4226, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_p04.type", "resGender": 0}
1384	3683	{"_key": 3683, "typeID": 34010, "resPath": "Tattoo/ArmRight/Sleeve07/Type/Sleeve07_M_Right.type", "resGender": 1}
1385	3684	{"_key": 3684, "typeID": 4035, "resPath": "bottomOuter/SkirtMilF01/Types/SkirtMilF01_graphite.type", "resGender": 0}
1386	3685	{"_key": 3685, "typeID": 4160, "resPath": "TopOuter/ShirtMilF01/Types/ShirtMilF01_matblack.type", "resGender": 0}
1387	3686	{"_key": 3686, "typeID": 4224, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_p02.type", "resGender": 0}
1388	3687	{"_key": 3687, "typeID": 4034, "resPath": "bottomOuter/SkirtMilF01/Types/SkirtMilF01_brownleather.type", "resGender": 0}
1389	3688	{"_key": 3688, "typeID": 4237, "resPath": "outer/JacketMilM02/Types/JacketMilM02_matgreen.type", "resGender": 1}
1390	3689	{"_key": 3689, "typeID": 4075, "resPath": "bottomOuter/SkirtMilF01/Types/SkirtMilF01_white.type", "resGender": 0}
1391	3690	{"_key": 3690, "typeID": 4133, "resPath": "Feet/BootsMilF03/Types/BootsMilF03_brownblack.type", "resGender": 0}
1392	3691	{"_key": 3691, "typeID": 4223, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_p01.type", "resGender": 0}
1393	3692	{"_key": 3692, "typeID": 33379, "resPath": "Tattoo/ArmLeft/Sleeve14/Types/Sleeve14_F_Left.type", "resGender": 0}
1394	3693	{"_key": 3693, "typeID": 4106, "resPath": "bottomOuter/SkirtMilF02/Types/SkirtMilF02_green.type", "resGender": 0}
1395	3694	{"_key": 3694, "typeID": 33377, "resPath": "Tattoo/ArmLeft/Sleeve04/Types/Sleeve04_F_Left.type", "resGender": 0}
1396	3695	{"_key": 3695, "typeID": 4159, "resPath": "TopOuter/ShirtMilF01/Types/ShirtMilF01_greensatin.type", "resGender": 0}
1397	3696	{"_key": 3696, "typeID": 4016, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_black.type", "resGender": 0}
1398	3697	{"_key": 3697, "typeID": 4120, "resPath": "Feet/BootsMilF01/Types/BootsMilF01_graphwhite.type", "resGender": 0}
1399	3698	{"_key": 3698, "typeID": 4109, "resPath": "bottomOuter/SkirtMilF02/Types/SkirtMilF02_khaki.type", "resGender": 0}
1400	3699	{"_key": 3699, "typeID": 34013, "resPath": "Tattoo/ArmRight/Sleeve11/Type/Sleeve11_F_Right.type", "resGender": 0}
1401	3700	{"_key": 3700, "typeID": 33999, "resPath": "Tattoo/ArmLeft/Sleeve07/Types/Sleeve07_F_Left.type", "resGender": 0}
1402	3701	{"_key": 3701, "typeID": 33997, "resPath": "Tattoo/ArmLeft/Sleeve03/Types/Sleeve03_F_Left.type", "resGender": 0}
1403	3702	{"_key": 3702, "typeID": 4112, "resPath": "bottomOuter/SkirtMilF02/Types/SkirtMilF02_red.type", "resGender": 0}
1404	3703	{"_key": 3703, "typeID": 4166, "resPath": "bottomOuter/PantsMilM01/Types/PantsMilM01_blue.type", "resGender": 1}
1405	3704	{"_key": 3704, "typeID": 4119, "resPath": "Feet/BootsMilF01/Types/BootsMilF01_gold.type", "resGender": 0}
1406	3705	{"_key": 3705, "typeID": 4194, "resPath": "TopMiddle/TanktopM01/Types/TanktopM01_gray.type", "resGender": 1}
1407	3706	{"_key": 3706, "typeID": 4110, "resPath": "bottomOuter/SkirtMilF02/Types/SkirtMilF02_marine.type", "resGender": 0}
1408	3707	{"_key": 3707, "typeID": 4104, "resPath": "bottomOuter/SkirtMilF02/Types/SkirtMilF02_gray.type", "resGender": 0}
1409	3708	{"_key": 3708, "typeID": 34001, "resPath": "Tattoo/ArmLeft/Sleeve10/Types/Sleeve10_M_Left.type", "resGender": 1}
1410	3709	{"_key": 3709, "typeID": 4179, "resPath": "Feet/BootsMilM03/Types/BootsMilM03_tan.type", "resGender": 1}
1411	3710	{"_key": 3710, "typeID": 34052, "resPath": "bottomMiddle/TightsF01/Types/TightsF01_thickmatblack.type", "resGender": 0}
1412	3734	{"_key": 3734, "typeID": 32853, "resPath": "Accessories/Glasses/Monocle_M_T02/Types/Monocle_M_T02_black_right.type", "resGender": 1}
1413	3735	{"_key": 3735, "resPath": "Makeup/Blemish/Light_06/Types/Light_06.type", "resGender": 0}
1414	3736	{"_key": 3736, "typeID": 33993, "resPath": "Accessories/Glasses/Monocle_F_T02/Types/Monocle_F_T02_black_left.type", "resGender": 0}
1415	3737	{"_key": 3737, "resPath": "Makeup/Blemish/Light_02/Types/Light_02.type", "resGender": 1}
1416	3738	{"_key": 3738, "typeID": 4217, "resPath": "TopMiddle/TanktopF01/Types/TanktopF01_blackleather.type", "resGender": 0}
1417	3739	{"_key": 3739, "resPath": "Makeup/Blemish/Light_06/Types/Light_06.type", "resGender": 1}
1418	3740	{"_key": 3740, "typeID": 33992, "resPath": "Accessories/Glasses/Monocle_01/Types/MonocleF01_RightBlack.type", "resGender": 0}
1419	3741	{"_key": 3741, "resPath": "Makeup/Blemish/Light_01/Types/Light_01.type", "resGender": 1}
1420	3742	{"_key": 3742, "typeID": 4204, "resPath": "TopMiddle/ShirtGF01/Types/ShirtGF01_cream.type", "resGender": 0}
1421	3743	{"_key": 3743, "resPath": "Makeup/Blemish/Light_03/Types/Light_03.type", "resGender": 0}
1422	3744	{"_key": 3744, "resPath": "Makeup/Blemish/Light_01/Types/Light_01.type", "resGender": 0}
1423	3745	{"_key": 3745, "resPath": "Makeup/Blemish/Light_03/Types/Light_03.type", "resGender": 1}
1424	3746	{"_key": 3746, "typeID": 4182, "resPath": "TopMiddle/ShirtGM01/Types/ShirtGM01_brown.type", "resGender": 1}
1425	3747	{"_key": 3747, "resPath": "Makeup/Blemish/Light_05/Types/Light_05.type", "resGender": 1}
1426	3748	{"_key": 3748, "resPath": "Makeup/Blemish/Light_05/Types/Light_05.type", "resGender": 0}
1427	3749	{"_key": 3749, "resPath": "Makeup/Blemish/Light_02/Types/Light_02.type", "resGender": 0}
1428	3750	{"_key": 3750, "typeID": 32853, "resPath": "Accessories/Glasses/Monocle_F_T02/Types/Monocle_F_T02_black_right.type", "resGender": 0}
1429	3751	{"_key": 3751, "resPath": "Makeup/Teeth/Teeth_01/Types/Teeth_01.type", "resGender": 0}
1430	3752	{"_key": 3752, "resPath": "Makeup/Blemish/Light_04/Types/Light_04.type", "resGender": 0}
1431	3753	{"_key": 3753, "typeID": 33993, "resPath": "Accessories/Glasses/Monocle_M_T02/Types/Monocle_M_T02_black_left.type", "resGender": 1}
1432	3754	{"_key": 3754, "typeID": 33992, "resPath": "Accessories/Glasses/Monocle_01/Types/MonocleM01_RightBlack.type", "resGender": 1}
1433	3755	{"_key": 3755, "resPath": "Makeup/Teeth/Teeth_01/Types/Teeth_01.type", "resGender": 1}
1434	3756	{"_key": 3756, "resPath": "Makeup/Blemish/Light_04/Types/Light_04.type", "resGender": 1}
1435	8254	{"_key": 8254, "typeID": 4366, "resPath": "TopMiddle/ShirtQF01/Types/shirtqf02.type", "resGender": 0}
1436	8256	{"_key": 8256, "typeID": 4368, "resPath": "TopOuter/ShirtMilF01/Types/ShirtMilF01_whiteblacknexon.type", "resGender": 0}
1437	8258	{"_key": 8258, "typeID": 4367, "resPath": "TopOuter/ShirtMilM01/Types/ShirtMilM01_whiteblacknexon.type", "resGender": 1}
1438	8261	{"_key": 8261, "typeID": 4365, "resPath": "TopMiddle/ShirtQM01/Types/shirtqm02.type", "resGender": 1}
1439	8263	{"_key": 8263, "resPath": "Skintype/MB/Types/skintype_f_brutor_10.type", "resGender": 0}
1440	8268	{"_key": 8268, "resPath": "Skintype/MB/Types/skintype_f_brutor_03.type", "resGender": 0}
1441	8269	{"_key": 8269, "resPath": "Skintype/MB/Types/skintype_f_brutor_07.type", "resGender": 0}
1442	8271	{"_key": 8271, "resPath": "Skintype/MB/Types/skintype_f_brutor_09.type", "resGender": 0}
1443	8275	{"_key": 8275, "resPath": "Skintype/MB/Types/skintype_f_brutor_08.type", "resGender": 0}
1444	8278	{"_key": 8278, "resPath": "Skintype/MB/Types/skintype_f_brutor_12.type", "resGender": 0}
1445	8279	{"_key": 8279, "resPath": "Skintype/MB/Types/skintype_f_brutor_13.type", "resGender": 0}
1446	8282	{"_key": 8282, "resPath": "Skintype/MB/Types/skintype_f_brutor_05.type", "resGender": 0}
1447	8284	{"_key": 8284, "resPath": "Skintype/MB/Types/skintype_f_brutor_06.type", "resGender": 0}
1448	8285	{"_key": 8285, "resPath": "Skintype/MB/Types/skintype_f_brutor_15.type", "resGender": 0}
1449	8291	{"_key": 8291, "resPath": "Skintype/MB/Types/skintype_f_brutor_02.type", "resGender": 0}
1450	8292	{"_key": 8292, "resPath": "Skintype/MB/Types/skintype_f_brutor_04.type", "resGender": 0}
1451	8294	{"_key": 8294, "resPath": "Skintype/MB/Types/skintype_f_brutor_14.type", "resGender": 0}
1452	8299	{"_key": 8299, "resPath": "Skintype/MB/Types/skintype_f_brutor_01.type", "resGender": 0}
1453	8305	{"_key": 8305, "resPath": "Skintype/MB/Types/skintype_f_brutor_11.type", "resGender": 0}
1454	8308	{"_key": 8308, "resPath": "Skintype/GJM/Types/skintype_f_jinmei_10.type", "resGender": 0}
1455	8309	{"_key": 8309, "resPath": "Skintype/MV/Types/skintype_f_vherokior_12.type", "resGender": 0}
1456	8310	{"_key": 8310, "resPath": "Skintype/CD/Types/skintype_f_deteis_14.type", "resGender": 0}
1457	8311	{"_key": 8311, "resPath": "Skintype/CD/Types/skintype_f_deteis_07.type", "resGender": 0}
1458	8312	{"_key": 8312, "resPath": "Skintype/MS/Types/skintype_f_sebiestor_05.type", "resGender": 0}
1459	8313	{"_key": 8313, "resPath": "Skintype/AK/Types/skintype_f_khanid_07.type", "resGender": 0}
1460	8314	{"_key": 8314, "resPath": "Skintype/AN/Types/skintype_f_nikunni_11.type", "resGender": 0}
1461	8315	{"_key": 8315, "resPath": "Skintype/AK/Types/skintype_f_khanid_04.type", "resGender": 0}
1462	8316	{"_key": 8316, "resPath": "Skintype/CA/Types/skintype_f_achura_07.type", "resGender": 0}
1463	8317	{"_key": 8317, "resPath": "Skintype/MV/Types/skintype_f_vherokior_06.type", "resGender": 0}
1464	8318	{"_key": 8318, "resPath": "Skintype/CA/Types/skintype_f_achura_06.type", "resGender": 0}
1465	8319	{"_key": 8319, "resPath": "Skintype/AA/Types/skintype_f_amarr_02.type", "resGender": 0}
1466	8320	{"_key": 8320, "resPath": "Skintype/CD/Types/skintype_f_deteis_02.type", "resGender": 0}
1467	8321	{"_key": 8321, "resPath": "Skintype/CC/Types/skintype_f_civire_08.type", "resGender": 0}
1468	8322	{"_key": 8322, "resPath": "Skintype/CA/Types/skintype_f_achura_09.type", "resGender": 0}
1469	8323	{"_key": 8323, "resPath": "Skintype/CD/Types/skintype_f_deteis_01.type", "resGender": 0}
1470	8324	{"_key": 8324, "resPath": "Skintype/GJM/Types/skintype_f_jinmei_11.type", "resGender": 0}
1471	8325	{"_key": 8325, "resPath": "Skintype/GG/Types/skintype_f_gallente_06.type", "resGender": 0}
1472	8326	{"_key": 8326, "resPath": "Skintype/GJM/Types/skintype_f_jinmei_07.type", "resGender": 0}
1473	8327	{"_key": 8327, "resPath": "Skintype/AK/Types/skintype_f_khanid_02.type", "resGender": 0}
1474	8328	{"_key": 8328, "resPath": "Skintype/AA/Types/skintype_f_amarr_12.type", "resGender": 0}
1475	8329	{"_key": 8329, "resPath": "Skintype/GJM/Types/skintype_f_jinmei_02.type", "resGender": 0}
1476	8330	{"_key": 8330, "resPath": "Skintype/GI/Types/skintype_f_intaki_09.type", "resGender": 0}
1477	8331	{"_key": 8331, "resPath": "Skintype/GG/Types/skintype_f_gallente_01.type", "resGender": 0}
1478	8332	{"_key": 8332, "resPath": "Skintype/MV/Types/skintype_f_vherokior_05.type", "resGender": 0}
1479	8333	{"_key": 8333, "resPath": "Skintype/CA/Types/skintype_f_achura_10.type", "resGender": 0}
1480	8334	{"_key": 8334, "resPath": "Skintype/CA/Types/skintype_f_achura_13.type", "resGender": 0}
1481	8335	{"_key": 8335, "resPath": "Skintype/AK/Types/skintype_f_khanid_05.type", "resGender": 0}
1482	8336	{"_key": 8336, "resPath": "Skintype/AA/Types/skintype_f_amarr_08.type", "resGender": 0}
1483	8337	{"_key": 8337, "resPath": "Skintype/AN/Types/skintype_f_nikunni_01.type", "resGender": 0}
1484	8338	{"_key": 8338, "resPath": "Skintype/CD/Types/skintype_f_deteis_11.type", "resGender": 0}
1485	8339	{"_key": 8339, "resPath": "Skintype/GG/Types/skintype_f_gallente_08.type", "resGender": 0}
1486	8340	{"_key": 8340, "resPath": "Skintype/MS/Types/skintype_f_sebiestor_14.type", "resGender": 0}
1487	8341	{"_key": 8341, "resPath": "Skintype/AK/Types/skintype_f_khanid_10.type", "resGender": 0}
1488	8342	{"_key": 8342, "resPath": "Skintype/MS/Types/skintype_f_sebiestor_11.type", "resGender": 0}
1489	8343	{"_key": 8343, "resPath": "Skintype/MV/Types/skintype_f_vherokior_02.type", "resGender": 0}
1490	8345	{"_key": 8345, "resPath": "Skintype/GJM/Types/skintype_f_jinmei_13.type", "resGender": 0}
1491	8346	{"_key": 8346, "resPath": "Skintype/CC/Types/skintype_f_civire_03.type", "resGender": 0}
1492	8347	{"_key": 8347, "resPath": "Skintype/AK/Types/skintype_f_khanid_14.type", "resGender": 0}
1493	8348	{"_key": 8348, "resPath": "Skintype/AN/Types/skintype_f_nikunni_12.type", "resGender": 0}
1494	8349	{"_key": 8349, "resPath": "Skintype/CA/Types/skintype_f_achura_12.type", "resGender": 0}
1495	8350	{"_key": 8350, "resPath": "Skintype/GG/Types/skintype_f_gallente_02.type", "resGender": 0}
1496	8351	{"_key": 8351, "resPath": "Skintype/GI/Types/skintype_f_intaki_05.type", "resGender": 0}
1497	8352	{"_key": 8352, "resPath": "Skintype/MV/Types/skintype_f_vherokior_01.type", "resGender": 0}
1498	8353	{"_key": 8353, "resPath": "Skintype/MV/Types/skintype_f_vherokior_13.type", "resGender": 0}
1499	8354	{"_key": 8354, "resPath": "Skintype/MV/Types/skintype_f_vherokior_03.type", "resGender": 0}
1500	8355	{"_key": 8355, "resPath": "Skintype/GJM/Types/skintype_f_jinmei_12.type", "resGender": 0}
1501	8356	{"_key": 8356, "resPath": "Skintype/CA/Types/skintype_f_achura_01.type", "resGender": 0}
1502	8357	{"_key": 8357, "resPath": "Skintype/GI/Types/skintype_f_intaki_03.type", "resGender": 0}
1503	8358	{"_key": 8358, "resPath": "Skintype/CA/Types/skintype_f_achura_08.type", "resGender": 0}
1504	8359	{"_key": 8359, "resPath": "Skintype/CC/Types/skintype_f_civire_04.type", "resGender": 0}
1505	8360	{"_key": 8360, "resPath": "Skintype/MV/Types/skintype_f_vherokior_14.type", "resGender": 0}
1506	8361	{"_key": 8361, "resPath": "Skintype/AA/Types/skintype_f_amarr_05.type", "resGender": 0}
1507	8362	{"_key": 8362, "resPath": "Skintype/GG/Types/skintype_f_gallente_10.type", "resGender": 0}
1508	8363	{"_key": 8363, "resPath": "Skintype/AK/Types/skintype_f_khanid_08.type", "resGender": 0}
1509	8364	{"_key": 8364, "resPath": "Skintype/GJM/Types/skintype_f_jinmei_03.type", "resGender": 0}
1510	8365	{"_key": 8365, "resPath": "Skintype/AK/Types/skintype_f_khanid_03.type", "resGender": 0}
1511	8366	{"_key": 8366, "resPath": "Skintype/GG/Types/skintype_f_gallente_11.type", "resGender": 0}
1512	8367	{"_key": 8367, "resPath": "Skintype/AA/Types/skintype_f_amarr_06.type", "resGender": 0}
1513	8368	{"_key": 8368, "resPath": "Skintype/MV/Types/skintype_f_vherokior_11.type", "resGender": 0}
1514	8369	{"_key": 8369, "resPath": "Skintype/AN/Types/skintype_f_nikunni_10.type", "resGender": 0}
1515	8370	{"_key": 8370, "resPath": "Skintype/CD/Types/skintype_f_deteis_06.type", "resGender": 0}
1516	8371	{"_key": 8371, "resPath": "Skintype/GI/Types/skintype_f_intaki_02.type", "resGender": 0}
1517	8372	{"_key": 8372, "resPath": "Skintype/CC/Types/skintype_f_civire_01.type", "resGender": 0}
1518	8373	{"_key": 8373, "resPath": "Skintype/AK/Types/skintype_f_khanid_09.type", "resGender": 0}
1519	8375	{"_key": 8375, "resPath": "Skintype/GI/Types/skintype_f_intaki_01.type", "resGender": 0}
1520	8376	{"_key": 8376, "resPath": "Skintype/CC/Types/skintype_f_civire_07.type", "resGender": 0}
1521	8377	{"_key": 8377, "resPath": "Skintype/MS/Types/skintype_f_sebiestor_04.type", "resGender": 0}
1522	8378	{"_key": 8378, "resPath": "Skintype/CC/Types/skintype_f_civire_05.type", "resGender": 0}
1523	8379	{"_key": 8379, "resPath": "Skintype/CD/Types/skintype_f_deteis_09.type", "resGender": 0}
1524	8380	{"_key": 8380, "resPath": "Skintype/GG/Types/skintype_f_gallente_03.type", "resGender": 0}
1525	8381	{"_key": 8381, "resPath": "Skintype/GG/Types/skintype_f_gallente_05.type", "resGender": 0}
1526	8382	{"_key": 8382, "resPath": "Skintype/GJM/Types/skintype_f_jinmei_04.type", "resGender": 0}
1527	8383	{"_key": 8383, "resPath": "Skintype/GG/Types/skintype_f_gallente_13.type", "resGender": 0}
1528	8384	{"_key": 8384, "resPath": "Skintype/AA/Types/skintype_f_amarr_10.type", "resGender": 0}
1529	8385	{"_key": 8385, "resPath": "Skintype/AN/Types/skintype_f_nikunni_05.type", "resGender": 0}
1530	8386	{"_key": 8386, "resPath": "Skintype/MV/Types/skintype_f_vherokior_07.type", "resGender": 0}
1531	8387	{"_key": 8387, "resPath": "Skintype/CA/Types/skintype_f_achura_14.type", "resGender": 0}
1532	8388	{"_key": 8388, "resPath": "Skintype/CA/Types/skintype_f_achura_03.type", "resGender": 0}
1533	8389	{"_key": 8389, "resPath": "Skintype/CD/Types/skintype_f_deteis_04.type", "resGender": 0}
1534	8390	{"_key": 8390, "resPath": "Skintype/AA/Types/skintype_f_amarr_03.type", "resGender": 0}
1535	8391	{"_key": 8391, "resPath": "Skintype/CD/Types/skintype_f_deteis_05.type", "resGender": 0}
1536	8392	{"_key": 8392, "resPath": "Skintype/AK/Types/skintype_f_khanid_13.type", "resGender": 0}
1537	8393	{"_key": 8393, "resPath": "Skintype/MS/Types/skintype_f_sebiestor_01.type", "resGender": 0}
1538	8394	{"_key": 8394, "resPath": "Skintype/CC/Types/skintype_f_civire_13.type", "resGender": 0}
1539	8395	{"_key": 8395, "resPath": "Skintype/CC/Types/skintype_f_civire_14.type", "resGender": 0}
1540	8396	{"_key": 8396, "resPath": "Skintype/CC/Types/skintype_f_civire_06.type", "resGender": 0}
1541	8397	{"_key": 8397, "resPath": "Skintype/GG/Types/skintype_f_gallente_04.type", "resGender": 0}
1542	8398	{"_key": 8398, "resPath": "Skintype/GG/Types/skintype_f_gallente_07.type", "resGender": 0}
1543	8399	{"_key": 8399, "resPath": "Skintype/CC/Types/skintype_f_civire_02.type", "resGender": 0}
1544	8400	{"_key": 8400, "resPath": "Skintype/MS/Types/skintype_f_sebiestor_03.type", "resGender": 0}
1545	8401	{"_key": 8401, "resPath": "Skintype/AA/Types/skintype_f_amarr_14.type", "resGender": 0}
1546	8402	{"_key": 8402, "resPath": "Skintype/AN/Types/skintype_f_nikunni_08.type", "resGender": 0}
1547	8403	{"_key": 8403, "resPath": "Skintype/AA/Types/skintype_f_amarr_07.type", "resGender": 0}
1548	8404	{"_key": 8404, "resPath": "Skintype/GI/Types/skintype_f_intaki_12.type", "resGender": 0}
1549	8405	{"_key": 8405, "resPath": "Skintype/GI/Types/skintype_f_intaki_14.type", "resGender": 0}
1550	8406	{"_key": 8406, "resPath": "Skintype/AA/Types/skintype_f_amarr_09.type", "resGender": 0}
1551	8407	{"_key": 8407, "resPath": "Skintype/AA/Types/skintype_f_amarr_13.type", "resGender": 0}
1552	8408	{"_key": 8408, "resPath": "Skintype/CC/Types/skintype_f_civire_11.type", "resGender": 0}
1553	8409	{"_key": 8409, "resPath": "Skintype/GJM/Types/skintype_f_jinmei_05.type", "resGender": 0}
1554	8410	{"_key": 8410, "resPath": "Skintype/GI/Types/skintype_f_intaki_06.type", "resGender": 0}
1555	8411	{"_key": 8411, "resPath": "Skintype/MS/Types/skintype_f_sebiestor_13.type", "resGender": 0}
1556	8412	{"_key": 8412, "resPath": "Skintype/MV/Types/skintype_f_vherokior_09.type", "resGender": 0}
1557	8413	{"_key": 8413, "resPath": "Skintype/CD/Types/skintype_f_deteis_10.type", "resGender": 0}
1558	8414	{"_key": 8414, "resPath": "Skintype/AN/Types/skintype_f_nikunni_03.type", "resGender": 0}
1559	8415	{"_key": 8415, "resPath": "Skintype/CA/Types/skintype_f_achura_05.type", "resGender": 0}
1560	8416	{"_key": 8416, "resPath": "Skintype/AN/Types/skintype_f_nikunni_04.type", "resGender": 0}
1561	8417	{"_key": 8417, "resPath": "Skintype/GI/Types/skintype_f_intaki_08.type", "resGender": 0}
1562	8418	{"_key": 8418, "resPath": "Skintype/MS/Types/skintype_f_sebiestor_02.type", "resGender": 0}
1563	8419	{"_key": 8419, "resPath": "Skintype/MS/Types/skintype_f_sebiestor_09.type", "resGender": 0}
1564	8420	{"_key": 8420, "resPath": "Skintype/CD/Types/skintype_f_deteis_08.type", "resGender": 0}
1565	8421	{"_key": 8421, "resPath": "Skintype/GG/Types/skintype_f_gallente_09.type", "resGender": 0}
1566	8422	{"_key": 8422, "resPath": "Skintype/AN/Types/skintype_f_nikunni_09.type", "resGender": 0}
1567	8423	{"_key": 8423, "resPath": "Skintype/AA/Types/skintype_f_amarr_11.type", "resGender": 0}
1568	8424	{"_key": 8424, "resPath": "Skintype/GI/Types/skintype_f_intaki_04.type", "resGender": 0}
1569	8425	{"_key": 8425, "resPath": "Skintype/CD/Types/skintype_f_deteis_13.type", "resGender": 0}
1570	8426	{"_key": 8426, "resPath": "Skintype/CD/Types/skintype_f_deteis_03.type", "resGender": 0}
1571	8427	{"_key": 8427, "resPath": "Skintype/AN/Types/skintype_f_nikunni_07.type", "resGender": 0}
1572	8428	{"_key": 8428, "resPath": "Skintype/MV/Types/skintype_f_vherokior_04.type", "resGender": 0}
1573	8429	{"_key": 8429, "resPath": "Skintype/CA/Types/skintype_f_achura_04.type", "resGender": 0}
1574	8430	{"_key": 8430, "resPath": "Skintype/MS/Types/skintype_f_sebiestor_06.type", "resGender": 0}
1575	8431	{"_key": 8431, "resPath": "Skintype/CA/Types/skintype_f_achura_02.type", "resGender": 0}
1576	8432	{"_key": 8432, "resPath": "Skintype/AN/Types/skintype_f_nikunni_06.type", "resGender": 0}
1577	8433	{"_key": 8433, "resPath": "Skintype/AA/Types/skintype_f_amarr_01.type", "resGender": 0}
1578	8434	{"_key": 8434, "resPath": "Skintype/GJM/Types/skintype_f_jinmei_14.type", "resGender": 0}
1579	8435	{"_key": 8435, "resPath": "Skintype/MS/Types/skintype_f_sebiestor_08.type", "resGender": 0}
1580	8436	{"_key": 8436, "resPath": "Skintype/GJM/Types/skintype_f_jinmei_09.type", "resGender": 0}
1581	8437	{"_key": 8437, "resPath": "Skintype/MS/Types/skintype_f_sebiestor_07.type", "resGender": 0}
1582	8438	{"_key": 8438, "resPath": "Skintype/AN/Types/skintype_f_nikunni_14.type", "resGender": 0}
1583	8439	{"_key": 8439, "resPath": "Skintype/MV/Types/skintype_f_vherokior_10.type", "resGender": 0}
1584	8440	{"_key": 8440, "resPath": "Skintype/AK/Types/skintype_f_khanid_01.type", "resGender": 0}
1585	8441	{"_key": 8441, "resPath": "Skintype/MV/Types/skintype_f_vherokior_08.type", "resGender": 0}
1586	8442	{"_key": 8442, "resPath": "Skintype/CC/Types/skintype_f_civire_12.type", "resGender": 0}
1587	8443	{"_key": 8443, "resPath": "Skintype/GI/Types/skintype_f_intaki_10.type", "resGender": 0}
1588	8444	{"_key": 8444, "resPath": "Skintype/CC/Types/skintype_f_civire_09.type", "resGender": 0}
1589	8445	{"_key": 8445, "resPath": "Skintype/CC/Types/skintype_f_civire_10.type", "resGender": 0}
1590	8446	{"_key": 8446, "resPath": "Skintype/AK/Types/skintype_f_khanid_12.type", "resGender": 0}
1591	8447	{"_key": 8447, "resPath": "Skintype/AA/Types/skintype_f_amarr_04.type", "resGender": 0}
1592	8448	{"_key": 8448, "resPath": "Skintype/GJM/Types/skintype_f_jinmei_01.type", "resGender": 0}
1593	8449	{"_key": 8449, "resPath": "Skintype/GG/Types/skintype_f_gallente_14.type", "resGender": 0}
1594	8450	{"_key": 8450, "resPath": "Skintype/AN/Types/skintype_f_nikunni_02.type", "resGender": 0}
1595	8451	{"_key": 8451, "resPath": "Skintype/CA/Types/skintype_f_achura_11.type", "resGender": 0}
1596	8452	{"_key": 8452, "resPath": "Skintype/AK/Types/skintype_f_khanid_06.type", "resGender": 0}
1597	8453	{"_key": 8453, "resPath": "Skintype/GG/Types/skintype_f_gallente_12.type", "resGender": 0}
1598	8454	{"_key": 8454, "resPath": "Skintype/GI/Types/skintype_f_intaki_13.type", "resGender": 0}
1599	8455	{"_key": 8455, "resPath": "Skintype/MS/Types/skintype_f_sebiestor_12.type", "resGender": 0}
1600	8456	{"_key": 8456, "resPath": "Skintype/CD/Types/skintype_f_deteis_12.type", "resGender": 0}
1601	8457	{"_key": 8457, "resPath": "Skintype/GI/Types/skintype_f_intaki_07.type", "resGender": 0}
1602	8458	{"_key": 8458, "resPath": "Skintype/MS/Types/skintype_f_sebiestor_10.type", "resGender": 0}
1603	8459	{"_key": 8459, "resPath": "Skintype/AN/Types/skintype_f_nikunni_13.type", "resGender": 0}
1604	8460	{"_key": 8460, "resPath": "Skintype/AK/Types/skintype_f_khanid_11.type", "resGender": 0}
1605	8461	{"_key": 8461, "resPath": "Skintype/GJM/Types/skintype_f_jinmei_08.type", "resGender": 0}
1606	8462	{"_key": 8462, "resPath": "Skintype/GI/Types/skintype_f_intaki_11.type", "resGender": 0}
1607	8463	{"_key": 8463, "resPath": "Skintype/GJM/Types/skintype_f_jinmei_06.type", "resGender": 0}
1608	8464	{"_key": 8464, "resPath": "Skintype/MB/Types/skintype_m_brutor_12.type", "resGender": 1}
1609	8465	{"_key": 8465, "resPath": "Skintype/MV/Types/skintype_m_vherokior_11.type", "resGender": 1}
1610	8466	{"_key": 8466, "resPath": "Skintype/GG/Types/skintype_m_gallente_01.type", "resGender": 1}
1611	8467	{"_key": 8467, "resPath": "Skintype/CC/Types/skintype_m_civire_03.type", "resGender": 1}
1612	8468	{"_key": 8468, "resPath": "Skintype/MV/Types/skintype_m_vherokior_10.type", "resGender": 1}
1613	8469	{"_key": 8469, "resPath": "Skintype/CA/Types/skintype_m_achura_05.type", "resGender": 1}
1614	8470	{"_key": 8470, "resPath": "Skintype/GJM/Types/skintype_m_jinmei_03.type", "resGender": 1}
1615	8471	{"_key": 8471, "resPath": "Skintype/MV/Types/skintype_m_vherokior_09.type", "resGender": 1}
1616	8472	{"_key": 8472, "resPath": "Skintype/CD/Types/skintype_m_deteis_07.type", "resGender": 1}
1617	8473	{"_key": 8473, "resPath": "Skintype/AA/Types/skintype_m_amarr_12.type", "resGender": 1}
1618	8474	{"_key": 8474, "resPath": "Skintype/GI/Types/skintype_m_intaki_08.type", "resGender": 1}
1619	8475	{"_key": 8475, "resPath": "Skintype/AK/Types/skintype_m_khanid_07.type", "resGender": 1}
1620	8476	{"_key": 8476, "resPath": "Skintype/CA/Types/skintype_m_achura_12.type", "resGender": 1}
1621	8477	{"_key": 8477, "resPath": "Skintype/AA/Types/skintype_m_amarr_07.type", "resGender": 1}
1622	8478	{"_key": 8478, "resPath": "Skintype/AN/Types/skintype_m_nikunni_07.type", "resGender": 1}
1623	8479	{"_key": 8479, "resPath": "Skintype/CC/Types/skintype_m_civire_06.type", "resGender": 1}
1624	8480	{"_key": 8480, "resPath": "Skintype/MS/Types/skintype_m_sebiestor_03.type", "resGender": 1}
1625	8481	{"_key": 8481, "resPath": "Skintype/AN/Types/skintype_m_nikunni_02.type", "resGender": 1}
1626	8482	{"_key": 8482, "resPath": "Skintype/CA/Types/skintype_m_achura_13.type", "resGender": 1}
1627	8483	{"_key": 8483, "resPath": "Skintype/MS/Types/skintype_m_sebiestor_11.type", "resGender": 1}
1628	8484	{"_key": 8484, "resPath": "Skintype/CD/Types/skintype_m_deteis_06.type", "resGender": 1}
1629	8485	{"_key": 8485, "resPath": "Skintype/CA/Types/skintype_m_achura_09.type", "resGender": 1}
1630	8486	{"_key": 8486, "resPath": "Skintype/AN/Types/skintype_m_nikunni_03.type", "resGender": 1}
1631	8487	{"_key": 8487, "resPath": "Skintype/GJM/Types/skintype_m_jinmei_04.type", "resGender": 1}
1632	8488	{"_key": 8488, "resPath": "Skintype/CC/Types/skintype_m_civire_05.type", "resGender": 1}
1633	8489	{"_key": 8489, "resPath": "Skintype/GG/Types/skintype_m_gallente_05.type", "resGender": 1}
1634	8490	{"_key": 8490, "resPath": "Skintype/AA/Types/skintype_m_amarr_02.type", "resGender": 1}
1635	8491	{"_key": 8491, "resPath": "Skintype/GJM/Types/skintype_m_jinmei_10.type", "resGender": 1}
1636	8492	{"_key": 8492, "resPath": "Skintype/GI/Types/skintype_m_intaki_09.type", "resGender": 1}
1637	8493	{"_key": 8493, "resPath": "Skintype/MS/Types/skintype_m_sebiestor_04.type", "resGender": 1}
1638	8494	{"_key": 8494, "resPath": "Skintype/GG/Types/skintype_m_gallente_14.type", "resGender": 1}
1639	8495	{"_key": 8495, "resPath": "Skintype/GI/Types/skintype_m_intaki_12.type", "resGender": 1}
1640	8496	{"_key": 8496, "resPath": "Skintype/GG/Types/skintype_m_gallente_10.type", "resGender": 1}
1641	8497	{"_key": 8497, "resPath": "Skintype/GI/Types/skintype_m_intaki_13.type", "resGender": 1}
1642	8498	{"_key": 8498, "resPath": "Skintype/AK/Types/skintype_m_khanid_03.type", "resGender": 1}
1643	8499	{"_key": 8499, "resPath": "Skintype/GI/Types/skintype_m_intaki_11.type", "resGender": 1}
1644	8500	{"_key": 8500, "resPath": "Skintype/MV/Types/skintype_m_vherokior_01.type", "resGender": 1}
1645	8502	{"_key": 8502, "resPath": "Skintype/MB/Types/skintype_m_brutor_06.type", "resGender": 1}
1646	8503	{"_key": 8503, "resPath": "Skintype/AN/Types/skintype_m_nikunni_04.type", "resGender": 1}
1647	8504	{"_key": 8504, "resPath": "Skintype/AK/Types/skintype_m_khanid_04.type", "resGender": 1}
1648	8505	{"_key": 8505, "resPath": "Skintype/AN/Types/skintype_m_nikunni_13.type", "resGender": 1}
1649	8506	{"_key": 8506, "resPath": "Skintype/MV/Types/skintype_m_vherokior_04.type", "resGender": 1}
1650	8507	{"_key": 8507, "resPath": "Skintype/MB/Types/skintype_m_brutor_14.type", "resGender": 1}
1651	8508	{"_key": 8508, "resPath": "Skintype/AN/Types/skintype_m_nikunni_10.type", "resGender": 1}
1652	8509	{"_key": 8509, "resPath": "Skintype/AN/Types/skintype_m_nikunni_05.type", "resGender": 1}
1653	8510	{"_key": 8510, "resPath": "Skintype/AK/Types/skintype_m_khanid_06.type", "resGender": 1}
1654	8511	{"_key": 8511, "resPath": "Skintype/MB/Types/skintype_m_brutor_13.type", "resGender": 1}
1655	8512	{"_key": 8512, "resPath": "Skintype/AK/Types/skintype_m_khanid_08.type", "resGender": 1}
1656	8513	{"_key": 8513, "resPath": "Skintype/GJM/Types/skintype_m_jinmei_09.type", "resGender": 1}
1657	8514	{"_key": 8514, "resPath": "Skintype/CA/Types/skintype_m_achura_07.type", "resGender": 1}
1658	8515	{"_key": 8515, "resPath": "Skintype/CD/Types/skintype_m_deteis_01.type", "resGender": 1}
1659	8516	{"_key": 8516, "resPath": "Skintype/MS/Types/skintype_m_sebiestor_13.type", "resGender": 1}
1660	8517	{"_key": 8517, "resPath": "Skintype/MV/Types/skintype_m_vherokior_05.type", "resGender": 1}
1661	8518	{"_key": 8518, "resPath": "Skintype/AA/Types/skintype_m_amarr_10.type", "resGender": 1}
1662	8519	{"_key": 8519, "resPath": "Skintype/GG/Types/skintype_m_gallente_11.type", "resGender": 1}
1663	8520	{"_key": 8520, "resPath": "Skintype/CD/Types/skintype_m_deteis_02.type", "resGender": 1}
1664	8521	{"_key": 8521, "resPath": "Skintype/AA/Types/skintype_m_amarr_08.type", "resGender": 1}
1665	8522	{"_key": 8522, "resPath": "Skintype/MS/Types/skintype_m_sebiestor_14.type", "resGender": 1}
1666	8523	{"_key": 8523, "resPath": "Skintype/AA/Types/skintype_m_amarr_06.type", "resGender": 1}
1667	8524	{"_key": 8524, "resPath": "Skintype/GJM/Types/skintype_m_jinmei_12.type", "resGender": 1}
1668	8525	{"_key": 8525, "resPath": "Skintype/GG/Types/skintype_m_gallente_13.type", "resGender": 1}
1669	8526	{"_key": 8526, "resPath": "Skintype/GG/Types/skintype_m_gallente_03.type", "resGender": 1}
1670	8527	{"_key": 8527, "resPath": "Skintype/GI/Types/skintype_m_intaki_04.type", "resGender": 1}
1671	8528	{"_key": 8528, "resPath": "Skintype/MB/Types/skintype_m_brutor_04.type", "resGender": 1}
1672	8529	{"_key": 8529, "resPath": "Skintype/GG/Types/skintype_m_gallente_09.type", "resGender": 1}
1673	8530	{"_key": 8530, "resPath": "Skintype/GJM/Types/skintype_m_jinmei_07.type", "resGender": 1}
1674	8531	{"_key": 8531, "resPath": "Skintype/AA/Types/skintype_m_amarr_04.type", "resGender": 1}
1675	8533	{"_key": 8533, "resPath": "Skintype/CD/Types/skintype_m_deteis_05.type", "resGender": 1}
1676	8534	{"_key": 8534, "resPath": "Skintype/MS/Types/skintype_m_sebiestor_05.type", "resGender": 1}
1677	8535	{"_key": 8535, "resPath": "Skintype/CD/Types/skintype_m_deteis_12.type", "resGender": 1}
1678	8536	{"_key": 8536, "resPath": "Skintype/CA/Types/skintype_m_achura_02.type", "resGender": 1}
1679	8537	{"_key": 8537, "resPath": "Skintype/AN/Types/skintype_m_nikunni_14.type", "resGender": 1}
1680	8538	{"_key": 8538, "resPath": "Skintype/CD/Types/skintype_m_deteis_09.type", "resGender": 1}
1681	8539	{"_key": 8539, "resPath": "Skintype/CC/Types/skintype_m_civire_11.type", "resGender": 1}
1682	8540	{"_key": 8540, "resPath": "Skintype/AN/Types/skintype_m_nikunni_01.type", "resGender": 1}
1683	8541	{"_key": 8541, "resPath": "Skintype/MV/Types/skintype_m_vherokior_13.type", "resGender": 1}
1684	8542	{"_key": 8542, "resPath": "Skintype/CC/Types/skintype_m_civire_08.type", "resGender": 1}
1685	8543	{"_key": 8543, "resPath": "Skintype/MS/Types/skintype_m_sebiestor_07.type", "resGender": 1}
1686	8544	{"_key": 8544, "resPath": "Skintype/CC/Types/skintype_m_civire_13.type", "resGender": 1}
1687	8545	{"_key": 8545, "resPath": "Skintype/CA/Types/skintype_m_achura_11.type", "resGender": 1}
1688	8546	{"_key": 8546, "resPath": "Skintype/AN/Types/skintype_m_nikunni_12.type", "resGender": 1}
1689	8547	{"_key": 8547, "resPath": "Skintype/AK/Types/skintype_m_khanid_13.type", "resGender": 1}
1690	8548	{"_key": 8548, "resPath": "Skintype/AA/Types/skintype_m_amarr_05.type", "resGender": 1}
1691	8549	{"_key": 8549, "resPath": "Skintype/CC/Types/skintype_m_civire_01.type", "resGender": 1}
1692	8550	{"_key": 8550, "resPath": "Skintype/GG/Types/skintype_m_gallente_02.type", "resGender": 1}
1693	8551	{"_key": 8551, "resPath": "Skintype/MB/Types/skintype_m_brutor_10.type", "resGender": 1}
1694	8552	{"_key": 8552, "resPath": "Skintype/GI/Types/skintype_m_intaki_01.type", "resGender": 1}
1695	8553	{"_key": 8553, "resPath": "Skintype/AA/Types/skintype_m_amarr_13.type", "resGender": 1}
1696	8554	{"_key": 8554, "resPath": "Skintype/AK/Types/skintype_m_khanid_02.type", "resGender": 1}
1697	8555	{"_key": 8555, "resPath": "Skintype/GI/Types/skintype_m_intaki_06.type", "resGender": 1}
1698	8556	{"_key": 8556, "resPath": "Skintype/GI/Types/skintype_m_intaki_10.type", "resGender": 1}
1699	8557	{"_key": 8557, "resPath": "Skintype/CC/Types/skintype_m_civire_09.type", "resGender": 1}
1700	8558	{"_key": 8558, "resPath": "Skintype/CA/Types/skintype_m_achura_04.type", "resGender": 1}
1701	8559	{"_key": 8559, "resPath": "Skintype/MV/Types/skintype_m_vherokior_02.type", "resGender": 1}
1702	8560	{"_key": 8560, "resPath": "Skintype/MB/Types/skintype_m_brutor_08.type", "resGender": 1}
1703	8561	{"_key": 8561, "resPath": "Skintype/CC/Types/skintype_m_civire_14.type", "resGender": 1}
1704	8562	{"_key": 8562, "resPath": "Skintype/MB/Types/skintype_m_brutor_07.type", "resGender": 1}
1705	8563	{"_key": 8563, "resPath": "Skintype/CC/Types/skintype_m_civire_07.type", "resGender": 1}
1706	8564	{"_key": 8564, "resPath": "Skintype/MV/Types/skintype_m_vherokior_08.type", "resGender": 1}
1707	8565	{"_key": 8565, "resPath": "Skintype/MV/Types/skintype_m_vherokior_14.type", "resGender": 1}
1708	8566	{"_key": 8566, "resPath": "Skintype/GJM/Types/skintype_m_jinmei_11.type", "resGender": 1}
1709	8567	{"_key": 8567, "resPath": "Skintype/GJM/Types/skintype_m_jinmei_13.type", "resGender": 1}
1710	8568	{"_key": 8568, "resPath": "Skintype/CD/Types/skintype_m_deteis_13.type", "resGender": 1}
1711	8569	{"_key": 8569, "resPath": "Skintype/AN/Types/skintype_m_nikunni_06.type", "resGender": 1}
1712	8570	{"_key": 8570, "resPath": "Skintype/AN/Types/skintype_m_nikunni_09.type", "resGender": 1}
1713	8571	{"_key": 8571, "resPath": "Skintype/CA/Types/skintype_m_achura_10.type", "resGender": 1}
1714	8572	{"_key": 8572, "resPath": "Skintype/MS/Types/skintype_m_sebiestor_01.type", "resGender": 1}
1715	8573	{"_key": 8573, "resPath": "Skintype/GG/Types/skintype_m_gallente_12.type", "resGender": 1}
1716	8574	{"_key": 8574, "resPath": "Skintype/CC/Types/skintype_m_civire_04.type", "resGender": 1}
1717	8575	{"_key": 8575, "resPath": "Skintype/GG/Types/skintype_m_gallente_06.type", "resGender": 1}
1718	8576	{"_key": 8576, "resPath": "Skintype/CC/Types/skintype_m_civire_10.type", "resGender": 1}
1719	8577	{"_key": 8577, "resPath": "Skintype/AA/Types/skintype_m_amarr_11.type", "resGender": 1}
1720	8578	{"_key": 8578, "resPath": "Skintype/CC/Types/skintype_m_civire_12.type", "resGender": 1}
1721	8579	{"_key": 8579, "resPath": "Skintype/GG/Types/skintype_m_gallente_07.type", "resGender": 1}
1722	8580	{"_key": 8580, "resPath": "Skintype/MV/Types/skintype_m_vherokior_12.type", "resGender": 1}
1723	8581	{"_key": 8581, "resPath": "Skintype/AA/Types/skintype_m_amarr_01.type", "resGender": 1}
1724	8582	{"_key": 8582, "resPath": "Skintype/GG/Types/skintype_m_gallente_08.type", "resGender": 1}
1725	8583	{"_key": 8583, "resPath": "Skintype/GI/Types/skintype_m_intaki_05.type", "resGender": 1}
1726	8584	{"_key": 8584, "resPath": "Skintype/GJM/Types/skintype_m_jinmei_05.type", "resGender": 1}
1727	8585	{"_key": 8585, "resPath": "Skintype/MB/Types/skintype_m_brutor_05.type", "resGender": 1}
1728	8586	{"_key": 8586, "resPath": "Skintype/MB/Types/skintype_m_brutor_09.type", "resGender": 1}
1729	8587	{"_key": 8587, "resPath": "Skintype/GJM/Types/skintype_m_jinmei_06.type", "resGender": 1}
1730	8588	{"_key": 8588, "resPath": "Skintype/MV/Types/skintype_m_vherokior_06.type", "resGender": 1}
1731	8589	{"_key": 8589, "resPath": "Skintype/MS/Types/skintype_m_sebiestor_08.type", "resGender": 1}
1732	8590	{"_key": 8590, "resPath": "Skintype/MS/Types/skintype_m_sebiestor_09.type", "resGender": 1}
1733	8591	{"_key": 8591, "resPath": "Skintype/CA/Types/skintype_m_achura_08.type", "resGender": 1}
1734	8592	{"_key": 8592, "resPath": "Skintype/GJM/Types/skintype_m_jinmei_08.type", "resGender": 1}
1735	8593	{"_key": 8593, "resPath": "Skintype/MB/Types/skintype_m_brutor_02.type", "resGender": 1}
1736	8594	{"_key": 8594, "resPath": "Skintype/GJM/Types/skintype_m_jinmei_14.type", "resGender": 1}
1737	8595	{"_key": 8595, "resPath": "Skintype/MB/Types/skintype_m_brutor_01.type", "resGender": 1}
1738	8596	{"_key": 8596, "resPath": "Skintype/MS/Types/skintype_m_sebiestor_06.type", "resGender": 1}
1739	8597	{"_key": 8597, "resPath": "Skintype/CA/Types/skintype_m_achura_06.type", "resGender": 1}
1740	8598	{"_key": 8598, "resPath": "Skintype/GJM/Types/skintype_m_jinmei_02.type", "resGender": 1}
1741	8599	{"_key": 8599, "resPath": "Skintype/CD/Types/skintype_m_deteis_04.type", "resGender": 1}
1742	8600	{"_key": 8600, "resPath": "Skintype/CD/Types/skintype_m_deteis_03.type", "resGender": 1}
1743	8601	{"_key": 8601, "resPath": "Skintype/GI/Types/skintype_m_intaki_07.type", "resGender": 1}
1744	8602	{"_key": 8602, "resPath": "Skintype/MV/Types/skintype_m_vherokior_07.type", "resGender": 1}
1745	8603	{"_key": 8603, "resPath": "Skintype/MV/Types/skintype_m_vherokior_03.type", "resGender": 1}
1746	8604	{"_key": 8604, "resPath": "Skintype/MB/Types/skintype_m_brutor_11.type", "resGender": 1}
1747	8605	{"_key": 8605, "resPath": "Skintype/AA/Types/skintype_m_amarr_14.type", "resGender": 1}
1748	8606	{"_key": 8606, "resPath": "Skintype/GI/Types/skintype_m_intaki_03.type", "resGender": 1}
1749	8607	{"_key": 8607, "resPath": "Skintype/CD/Types/skintype_m_deteis_08.type", "resGender": 1}
1750	8608	{"_key": 8608, "resPath": "Skintype/CA/Types/skintype_m_achura_14.type", "resGender": 1}
1751	8609	{"_key": 8609, "resPath": "Skintype/MS/Types/skintype_m_sebiestor_10.type", "resGender": 1}
1752	8610	{"_key": 8610, "resPath": "Skintype/CD/Types/skintype_m_deteis_11.type", "resGender": 1}
1753	8611	{"_key": 8611, "resPath": "Skintype/AA/Types/skintype_m_amarr_09.type", "resGender": 1}
1754	8612	{"_key": 8612, "resPath": "Skintype/AK/Types/skintype_m_khanid_01.type", "resGender": 1}
1755	8613	{"_key": 8613, "resPath": "Skintype/AK/Types/skintype_m_khanid_12.type", "resGender": 1}
1756	8614	{"_key": 8614, "resPath": "Skintype/AN/Types/skintype_m_nikunni_11.type", "resGender": 1}
1757	8615	{"_key": 8615, "resPath": "Skintype/AK/Types/skintype_m_khanid_11.type", "resGender": 1}
1758	8616	{"_key": 8616, "resPath": "Skintype/CD/Types/skintype_m_deteis_10.type", "resGender": 1}
1759	8617	{"_key": 8617, "resPath": "Skintype/CA/Types/skintype_m_achura_01.type", "resGender": 1}
1760	8618	{"_key": 8618, "resPath": "Skintype/MS/Types/skintype_m_sebiestor_02.type", "resGender": 1}
1761	8619	{"_key": 8619, "resPath": "Skintype/AK/Types/skintype_m_khanid_09.type", "resGender": 1}
1762	8620	{"_key": 8620, "resPath": "Skintype/AN/Types/skintype_m_nikunni_08.type", "resGender": 1}
1763	8621	{"_key": 8621, "resPath": "Skintype/CA/Types/skintype_m_achura_03.type", "resGender": 1}
1764	8622	{"_key": 8622, "resPath": "Skintype/GI/Types/skintype_m_intaki_14.type", "resGender": 1}
1765	8623	{"_key": 8623, "resPath": "Skintype/AK/Types/skintype_m_khanid_10.type", "resGender": 1}
1766	8624	{"_key": 8624, "resPath": "Skintype/AK/Types/skintype_m_khanid_05.type", "resGender": 1}
1767	8625	{"_key": 8625, "resPath": "Skintype/GG/Types/skintype_m_gallente_04.type", "resGender": 1}
1768	8626	{"_key": 8626, "resPath": "Skintype/CD/Types/skintype_m_deteis_14.type", "resGender": 1}
1769	8627	{"_key": 8627, "resPath": "Skintype/GI/Types/skintype_m_intaki_02.type", "resGender": 1}
1770	8628	{"_key": 8628, "resPath": "Skintype/CC/Types/skintype_m_civire_02.type", "resGender": 1}
1771	8629	{"_key": 8629, "resPath": "Skintype/AA/Types/skintype_m_amarr_03.type", "resGender": 1}
1772	8630	{"_key": 8630, "resPath": "Skintype/MS/Types/skintype_m_sebiestor_12.type", "resGender": 1}
1773	8631	{"_key": 8631, "resPath": "Skintype/MB/Types/skintype_m_brutor_03.type", "resGender": 1}
1774	8632	{"_key": 8632, "resPath": "Skintype/GJM/Types/skintype_m_jinmei_01.type", "resGender": 1}
1775	8633	{"_key": 8633, "resPath": "Skintype/AK/Types/skintype_m_khanid_14.type", "resGender": 1}
1776	8636	{"_key": 8636, "typeID": -1, "resPath": "Outer/Catsuit01/Types/catsuit01_black.type", "resGender": 0}
1777	8641	{"_key": 8641, "typeID": 34083, "resPath": "Feet/SpaceBoots01F/Types/spaceboots01f_greengold.type", "resGender": 0}
1778	8642	{"_key": 8642, "typeID": 34098, "resPath": "Outer/SpaceSuit_Top_01/Types/spacesuit_01_top_f_stealth.type", "resGender": 0, "clothingRuleException": 1, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1779	8643	{"_key": 8643, "typeID": 34100, "resPath": "Outer/SpaceSuit_Top_01/Types/spacesuit_01_top_f_yellow.type", "resGender": 0, "clothingRuleException": 1, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1780	8644	{"_key": 8644, "typeID": 34108, "resPath": "bottomOuter/SpaceSuit_01/Types/spacesuit_01_f_redblack.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 0, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 26, "clothingAlsoCoversCategory2": 0}
1781	8645	{"_key": 8645, "typeID": -1, "resPath": "Outer/Catsuit01/Types/catsuit01_redblackdark.type", "resGender": 0}
1782	8646	{"_key": 8646, "typeID": 34088, "resPath": "Feet/SpaceBoots01F/Types/spaceboots01f_white.type", "resGender": 0}
1783	8647	{"_key": 8647, "typeID": 34111, "resPath": "bottomOuter/SpaceSuit_01/Types/spacesuit_01_f_yellow.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 0, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 26, "clothingAlsoCoversCategory2": 0}
1784	8648	{"_key": 8648, "typeID": -1, "resPath": "Outer/Catsuit01/Types/catsuit01_blueblack.type", "resGender": 0}
1785	8649	{"_key": 8649, "typeID": -1, "resPath": "Outer/Catsuit01/Types/catsuit01_blackred.type", "resGender": 0}
1786	8650	{"_key": 8650, "typeID": 34084, "resPath": "Feet/SpaceBoots01F/Types/spaceboots01f_orange.type", "resGender": 0}
1787	8651	{"_key": 8651, "typeID": 34082, "resPath": "Feet/SpaceBoots01F/Types/spaceboots01f_brown.type", "resGender": 0}
1788	8652	{"_key": 8652, "typeID": 34103, "resPath": "bottomOuter/SpaceSuit_01/Types/spacesuit_01_f_blue.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 0, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 26, "clothingAlsoCoversCategory2": 0}
1789	8653	{"_key": 8653, "typeID": 34106, "resPath": "bottomOuter/SpaceSuit_01/Types/spacesuit_01_f_orange.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 0, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 26, "clothingAlsoCoversCategory2": 0}
1790	8654	{"_key": 8654, "typeID": 34109, "resPath": "bottomOuter/SpaceSuit_01/Types/spacesuit_01_f_stealth.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 0, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 26, "clothingAlsoCoversCategory2": 0}
1791	8655	{"_key": 8655, "typeID": 34102, "resPath": "bottomOuter/SpaceSuit_01/Types/spacesuit_01_f_blackgold.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 0, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 26, "clothingAlsoCoversCategory2": 0}
1792	8656	{"_key": 8656, "typeID": 34092, "resPath": "Outer/SpaceSuit_Top_01/Types/spacesuit_01_top_f_blue.type", "resGender": 0, "clothingRuleException": 1, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1793	8657	{"_key": 8657, "typeID": 34107, "resPath": "bottomOuter/SpaceSuit_01/Types/spacesuit_01_f_red.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 0, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 26, "clothingAlsoCoversCategory2": 0}
1794	8658	{"_key": 8658, "typeID": 34110, "resPath": "bottomOuter/SpaceSuit_01/Types/spacesuit_01_f_white.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 0, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 26, "clothingAlsoCoversCategory2": 0}
1795	8659	{"_key": 8659, "typeID": 34087, "resPath": "Feet/SpaceBoots01F/Types/spaceboots01f_stealth.type", "resGender": 0}
1796	8660	{"_key": 8660, "typeID": 34101, "resPath": "bottomOuter/SpaceSuit_01/Types/spacesuit_01_f_black.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 0, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 26, "clothingAlsoCoversCategory2": 0}
1797	8661	{"_key": 8661, "typeID": 34094, "resPath": "Outer/SpaceSuit_Top_01/Types/spacesuit_01_top_f_greengold.type", "resGender": 0, "clothingRuleException": 1, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1798	8662	{"_key": 8662, "typeID": 34086, "resPath": "Feet/SpaceBoots01F/Types/spaceboots01f_redblack.type", "resGender": 0}
1799	8663	{"_key": 8663, "typeID": 34093, "resPath": "Outer/SpaceSuit_Top_01/Types/spacesuit_01_top_f_brown.type", "resGender": 0, "clothingRuleException": 1, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1800	8664	{"_key": 8664, "typeID": 34085, "resPath": "Feet/SpaceBoots01F/Types/spaceboots01f_red.type", "resGender": 0}
1801	8665	{"_key": 8665, "typeID": -1, "resPath": "Outer/Catsuit01/Types/catsuit01_redblack.type", "resGender": 0}
1802	8666	{"_key": 8666, "typeID": 34097, "resPath": "Outer/SpaceSuit_Top_01/Types/spacesuit_01_top_f_redblack.type", "resGender": 0, "clothingRuleException": 1, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1803	8667	{"_key": 8667, "typeID": 34089, "resPath": "Feet/SpaceBoots01F/Types/spaceboots01f_yellow.type", "resGender": 0}
1804	8668	{"_key": 8668, "typeID": 34105, "resPath": "bottomOuter/SpaceSuit_01/Types/spacesuit_01_f_greengold.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 0, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 26, "clothingAlsoCoversCategory2": 0}
1805	8669	{"_key": 8669, "typeID": 34096, "resPath": "Outer/SpaceSuit_Top_01/Types/spacesuit_01_top_f_red.type", "resGender": 0, "clothingRuleException": 1, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1806	8670	{"_key": 8670, "typeID": 34099, "resPath": "Outer/SpaceSuit_Top_01/Types/spacesuit_01_top_f_white.type", "resGender": 0, "clothingRuleException": 1, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1807	8671	{"_key": 8671, "typeID": 34104, "resPath": "bottomOuter/SpaceSuit_01/Types/spacesuit_01_f_brown.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 0, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 26, "clothingAlsoCoversCategory2": 0}
1808	8672	{"_key": 8672, "typeID": 34090, "resPath": "Outer/SpaceSuit_Top_01/Types/spacesuit_01_top_f_black.type", "resGender": 0, "clothingRuleException": 1, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1809	8673	{"_key": 8673, "typeID": 34079, "resPath": "Feet/SpaceBoots01F/Types/spaceboots01f_black.type", "resGender": 0}
1810	8674	{"_key": 8674, "typeID": 34091, "resPath": "Outer/SpaceSuit_Top_01/Types/spacesuit_01_top_f_blackgold.type", "resGender": 0, "clothingRuleException": 1, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1811	8675	{"_key": 8675, "typeID": 34095, "resPath": "Outer/SpaceSuit_Top_01/Types/spacesuit_01_top_f_orange.type", "resGender": 0, "clothingRuleException": 1, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1812	8676	{"_key": 8676, "typeID": 34080, "resPath": "Feet/SpaceBoots01F/Types/spaceboots01f_blackgold.type", "resGender": 0}
1813	8677	{"_key": 8677, "typeID": 34081, "resPath": "Feet/SpaceBoots01F/Types/spaceboots01f_blue.type", "resGender": 0}
1814	10615	{"_key": 10615, "resPath": "Accessories/Glasses/Glasses_Pilot_01/Types/glasses_01_clear.type", "resGender": 1, "empireRestrictions": [4]}
1815	10616	{"_key": 10616, "resPath": "Accessories/Glasses/Glasses_Pilot_01/Types/glasses_01_clear.type", "resGender": 0, "empireRestrictions": [4]}
1816	14730	{"_key": 14730, "typeID": 33062, "resPath": "TopMiddle/ShirtQM01/Types/shirtredstarm01.type", "resGender": 1}
1817	14731	{"_key": 14731, "typeID": 33063, "resPath": "TopMiddle/ShirtQF01/Types/shirtredstarf01.type", "resGender": 0}
1818	14733	{"_key": 14733, "typeID": 33064, "resPath": "Feet/BootsMilF02/Types/BootsMilF02_bootini.type", "resGender": 0}
1819	14734	{"_key": 14734, "typeID": 33107, "resPath": "TopMiddle/ShirtQM01/Types/shirtqm03.type", "resGender": 1}
1820	14735	{"_key": 14735, "typeID": 33109, "resPath": "TopMiddle/ShirtQF01/Types/shirtqf03.type", "resGender": 0}
1821	14743	{"_key": 14743, "typeID": 33487, "resPath": "TopMiddle/ShirtQF01/Types/lvf01.type", "resGender": 0}
1822	14744	{"_key": 14744, "typeID": 33488, "resPath": "TopMiddle/ShirtQM01/Types/lvm01.type", "resGender": 1}
1823	14763	{"_key": 14763, "typeID": 34032, "resPath": "Makeup/ArmRight/CyborgArmF01_R/Types/CyborgArmF01_R_BlackOrangeMech.type", "resGender": 0}
1824	14764	{"_key": 14764, "typeID": 34035, "resPath": "Makeup/ArmRight/CyborgArmF01_R/Types/CyborgArmF01_R_BlueBlackShinyMech.type", "resGender": 0}
1825	14765	{"_key": 14765, "typeID": 34017, "resPath": "Makeup/ArmLeft/CyborgArmF01_L/Types/CyborgArmF01_L_Black.type", "resGender": 0}
1826	14766	{"_key": 14766, "typeID": 34031, "resPath": "Makeup/ArmRight/CyborgArmF01_R/Types/CyborgArmF01_R_Black.type", "resGender": 0}
1827	14767	{"_key": 14767, "typeID": 34036, "resPath": "Makeup/ArmRight/CyborgArmF01_R/Types/CyborgArmF01_R_BlueWhite.type", "resGender": 0}
1828	14768	{"_key": 14768, "typeID": 34020, "resPath": "Makeup/ArmLeft/CyborgArmF01_L/Types/CyborgArmF01_L_BlackYellow.type", "resGender": 0}
1829	14769	{"_key": 14769, "typeID": 34021, "resPath": "Makeup/ArmLeft/CyborgArmF01_L/Types/CyborgArmF01_L_BlueBlackShinyMech.type", "resGender": 0}
1830	14770	{"_key": 14770, "typeID": 34023, "resPath": "Makeup/ArmLeft/CyborgArmF01_L/Types/CyborgArmF01_L_WhiteGrayMech.type", "resGender": 0}
1831	14771	{"_key": 14771, "typeID": 34018, "resPath": "Makeup/ArmLeft/CyborgArmF01_L/Types/CyborgArmF01_L_BlackOrangeMech.type", "resGender": 0}
1832	14772	{"_key": 14772, "typeID": 34037, "resPath": "Makeup/ArmRight/CyborgArmF01_R/Types/CyborgArmF01_R_WhiteGrayMech.type", "resGender": 0}
1833	14773	{"_key": 14773, "typeID": 34022, "resPath": "Makeup/ArmLeft/CyborgArmF01_L/Types/CyborgArmF01_L_BlueWhite.type", "resGender": 0}
1834	14774	{"_key": 14774, "typeID": 34033, "resPath": "Makeup/ArmRight/CyborgArmF01_R/Types/CyborgArmF01_R_BlackShinyMech.type", "resGender": 0}
1835	14775	{"_key": 14775, "typeID": 34034, "resPath": "Makeup/ArmRight/CyborgArmF01_R/Types/CyborgArmF01_R_BlackYellow.type", "resGender": 0}
1836	14776	{"_key": 14776, "typeID": 34019, "resPath": "Makeup/ArmLeft/CyborgArmF01_L/Types/CyborgArmF01_L_BlackShinyMech.type", "resGender": 0}
1837	14777	{"_key": 14777, "typeID": 33550, "resPath": "Makeup/ArmRight/CyborgArmF01_R/Types/CyborgArmF01_R_WhiteGray.type", "resGender": 0}
1838	14778	{"_key": 14778, "typeID": 33549, "resPath": "Makeup/ArmLeft/CyborgArmF01_L/Types/CyborgArmF01_L_WhiteGray.type", "resGender": 0}
1839	14829	{"_key": 14829, "typeID": 34040, "resPath": "Makeup/ArmRight/CyborgArmM01_R/Types/CyborgArmM01_R_BlackYellow.type", "resGender": 1}
1840	14830	{"_key": 14830, "typeID": 34026, "resPath": "Makeup/ArmLeft/CyborgArmM01_L/Types/CyborgArmM01_L_BlackYellow.type", "resGender": 1}
1841	14831	{"_key": 14831, "typeID": 34029, "resPath": "Makeup/ArmLeft/CyborgArmM01_L/Types/CyborgArmM01_L_GreenYellow.type", "resGender": 1}
1842	14832	{"_key": 14832, "typeID": 34030, "resPath": "Makeup/ArmLeft/CyborgArmM01_L/Types/CyborgArmM01_L_Gunmetal.type", "resGender": 1}
1843	14833	{"_key": 14833, "typeID": 33551, "resPath": "Makeup/ArmLeft/CyborgArmM01_L/Types/CyborgArmM01_L_White.type", "resGender": 1}
1844	14834	{"_key": 14834, "typeID": 34027, "resPath": "Makeup/ArmLeft/CyborgArmM01_L/Types/CyborgArmM01_L_BlueWhite.type", "resGender": 1}
1845	14835	{"_key": 14835, "typeID": 33552, "resPath": "Makeup/ArmRight/CyborgArmM01_R/Types/CyborgArmM01_R_White.type", "resGender": 1}
1846	14836	{"_key": 14836, "typeID": 34039, "resPath": "Makeup/ArmRight/CyborgArmM01_R/Types/CyborgArmM01_R_BlackRed.type", "resGender": 1}
1847	14838	{"_key": 14838, "typeID": 34024, "resPath": "Makeup/ArmLeft/CyborgArmM01_L/Types/CyborgArmM01_L_BlackOrange.type", "resGender": 1}
1848	14839	{"_key": 14839, "typeID": 34038, "resPath": "Makeup/ArmRight/CyborgArmM01_R/Types/CyborgArmM01_R_BlackOrange.type", "resGender": 1}
1849	14841	{"_key": 14841, "typeID": 34043, "resPath": "Makeup/ArmRight/CyborgArmM01_R/Types/CyborgArmM01_R_GreenYellow.type", "resGender": 1}
1850	14842	{"_key": 14842, "typeID": 34028, "resPath": "Makeup/ArmLeft/CyborgArmM01_L/Types/CyborgArmM01_L_GreenCamo.type", "resGender": 1}
1851	14843	{"_key": 14843, "typeID": 34041, "resPath": "Makeup/ArmRight/CyborgArmM01_R/Types/CyborgArmM01_R_BlueWhite.type", "resGender": 1}
1852	14844	{"_key": 14844, "typeID": 34042, "resPath": "Makeup/ArmRight/CyborgArmM01_R/Types/CyborgArmM01_R_GreenCamo.type", "resGender": 1}
1853	14845	{"_key": 14845, "typeID": 34025, "resPath": "Makeup/ArmLeft/CyborgArmM01_L/Types/CyborgArmM01_L_BlackRed.type", "resGender": 1}
1854	14846	{"_key": 14846, "typeID": 34044, "resPath": "Makeup/ArmRight/CyborgArmM01_R/Types/CyborgArmM01_R_Gunmetal.type", "resGender": 1}
1855	14847	{"_key": 14847, "typeID": 33578, "resPath": "TopMiddle/ShirtQM01/Types/soerfm01.type", "resGender": 1}
1856	14848	{"_key": 14848, "typeID": 33579, "resPath": "TopMiddle/ShirtQF01/Types/soerff01.type", "resGender": 0}
1857	14862	{"_key": 14862, "typeID": 33725, "resPath": "Feet/BootsSLF_01/Types/BootsSLF_01_red.type", "resGender": 0}
1858	14863	{"_key": 14863, "typeID": 33730, "resPath": "Outer/JacketALF_01/Types/JacketALF_01_darkredgun.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
1859	14864	{"_key": 14864, "typeID": 33754, "resPath": "bottomOuter/PantsSLF_01/Types/PantsSLF_01_black.type", "resGender": 0}
1860	14865	{"_key": 14865, "typeID": 33728, "resPath": "Outer/JacketALF_01/Types/JacketALF_01_bluesilver.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
1861	14866	{"_key": 14866, "typeID": 33738, "resPath": "Outer/JacketSLF_01/Types/JacketSLF_01_copv1.type", "resGender": 0}
1862	14867	{"_key": 14867, "typeID": 33719, "resPath": "Feet/BootsALF_01/Types/BootsALF_01_red.type", "resGender": 0}
1863	14868	{"_key": 14868, "typeID": 33744, "resPath": "bottomOuter/PantsALF_01/Types/PantsALF_01_blackleather.type", "resGender": 0}
1864	14869	{"_key": 14869, "typeID": 33731, "resPath": "Outer/JacketALF_01/Types/JacketALF_01_greengold.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
1865	14870	{"_key": 14870, "typeID": 33714, "resPath": "Feet/BootsALF_01/Types/BootsALF_01_blackgold.type", "resGender": 0}
1866	14871	{"_key": 14871, "typeID": 33727, "resPath": "Outer/JacketALF_01/Types/JacketALF_01_brownpattern.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
1867	14872	{"_key": 14872, "typeID": 33752, "resPath": "bottomOuter/PantsALF_01/Types/PantsALF_01_red.type", "resGender": 0}
1868	14873	{"_key": 14873, "typeID": 33756, "resPath": "bottomOuter/PantsSLF_01/Types/PantsSLF_01_camo.type", "resGender": 0}
1869	14874	{"_key": 14874, "typeID": 33740, "resPath": "Outer/JacketSLF_01/Types/JacketSLF_01_movcircles.type", "resGender": 0}
1870	14875	{"_key": 14875, "typeID": 33747, "resPath": "bottomOuter/PantsALF_01/Types/PantsALF_01_cream.type", "resGender": 0}
1871	14876	{"_key": 14876, "typeID": 33741, "resPath": "Outer/JacketSLF_01/Types/JacketSLF_01_redv1.type", "resGender": 0}
1872	14877	{"_key": 14877, "typeID": 33757, "resPath": "bottomOuter/PantsSLF_01/Types/PantsSLF_01_greyflat.type", "resGender": 0}
1873	14878	{"_key": 14878, "typeID": 33746, "resPath": "bottomOuter/PantsALF_01/Types/PantsALF_01_brownpattern.type", "resGender": 0}
1874	14879	{"_key": 14879, "typeID": 33734, "resPath": "Outer/JacketSLF_01/Types/JacketSLF_01_blackv1.type", "resGender": 0}
1875	14880	{"_key": 14880, "typeID": 33755, "resPath": "bottomOuter/PantsSLF_01/Types/PantsSLF_01_blue.type", "resGender": 0}
1876	14881	{"_key": 14881, "typeID": 33753, "resPath": "bottomOuter/PantsALF_01/Types/PantsALF_01_redleather.type", "resGender": 0}
1877	14882	{"_key": 14882, "typeID": 33717, "resPath": "Feet/BootsALF_01/Types/BootsALF_01_cream.type", "resGender": 0}
1878	14883	{"_key": 14883, "typeID": 33760, "resPath": "bottomOuter/PantsSLF_01/Types/PantsSLF_01_reddark.type", "resGender": 0}
1879	14884	{"_key": 14884, "typeID": 33732, "resPath": "Outer/JacketALF_01/Types/JacketALF_01_redsilver.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
1880	14885	{"_key": 14885, "typeID": 33729, "resPath": "Outer/JacketALF_01/Types/JacketALF_01_darkgreen.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
1881	14886	{"_key": 14886, "typeID": 33739, "resPath": "Outer/JacketSLF_01/Types/JacketSLF_01_green.type", "resGender": 0}
1882	14887	{"_key": 14887, "typeID": 33736, "resPath": "Outer/JacketSLF_01/Types/JacketSLF_01_coppstars.type", "resGender": 0}
1883	14888	{"_key": 14888, "typeID": 33723, "resPath": "Feet/BootsSLF_01/Types/BootsSLF_01_felt.type", "resGender": 0}
1884	14889	{"_key": 14889, "typeID": 33748, "resPath": "bottomOuter/PantsALF_01/Types/PantsALF_01_green.type", "resGender": 0}
1885	14890	{"_key": 14890, "typeID": 33716, "resPath": "Feet/BootsALF_01/Types/BootsALF_01_brown.type", "resGender": 0}
1886	14891	{"_key": 14891, "typeID": 33751, "resPath": "bottomOuter/PantsALF_01/Types/PantsALF_01_navy.type", "resGender": 0}
1887	14892	{"_key": 14892, "typeID": 33743, "resPath": "Outer/JacketSLF_01/Types/JacketSLF_01_whitegreen.type", "resGender": 0}
1888	14893	{"_key": 14893, "typeID": 33750, "resPath": "bottomOuter/PantsALF_01/Types/PantsALF_01_gunshiny.type", "resGender": 0}
1889	14894	{"_key": 14894, "typeID": 33745, "resPath": "bottomOuter/PantsALF_01/Types/PantsALF_01_blackmatte.type", "resGender": 0}
1890	14895	{"_key": 14895, "typeID": 33715, "resPath": "Outer/JacketALF_01/Types/JacketALF_01_creamgold.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
1891	14896	{"_key": 14896, "typeID": 33735, "resPath": "Outer/JacketSLF_01/Types/JacketSLF_01_blue.type", "resGender": 0}
1892	14897	{"_key": 14897, "typeID": 33722, "resPath": "Feet/BootsSLF_01/Types/BootsSLF_01_brown.type", "resGender": 0}
1893	14898	{"_key": 14898, "typeID": 33733, "resPath": "Outer/JacketSLF_01/Types/JacketSLF_01_black.type", "resGender": 0}
1894	14899	{"_key": 14899, "typeID": 33726, "resPath": "Outer/JacketALF_01/Types/JacketALF_01_blackgold.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
1895	14900	{"_key": 14900, "typeID": 33761, "resPath": "bottomOuter/PantsSLF_01/Types/PantsSLF_01_yellowgloss.type", "resGender": 0}
1896	14901	{"_key": 14901, "typeID": 33724, "resPath": "Feet/BootsSLF_01/Types/BootsSLF_01_mouse.type", "resGender": 0}
1897	14902	{"_key": 14902, "typeID": 33742, "resPath": "Outer/JacketSLF_01/Types/JacketSLF_01_white.type", "resGender": 0}
1898	14903	{"_key": 14903, "typeID": 33759, "resPath": "bottomOuter/PantsSLF_01/Types/PantsSLF_01_red.type", "resGender": 0}
1899	14904	{"_key": 14904, "typeID": 33758, "resPath": "bottomOuter/PantsSLF_01/Types/PantsSLF_01_orangegloss.type", "resGender": 0}
1900	14905	{"_key": 14905, "typeID": 33718, "resPath": "Feet/BootsALF_01/Types/BootsALF_01_navy.type", "resGender": 0}
1901	14906	{"_key": 14906, "typeID": 33737, "resPath": "Outer/JacketSLF_01/Types/JacketSLF_01_darkgrey.type", "resGender": 0}
1902	14907	{"_key": 14907, "typeID": 33721, "resPath": "Feet/BootsSLF_01/Types/BootsSLF_01_blue.type", "resGender": 0}
1903	14908	{"_key": 14908, "typeID": 33749, "resPath": "bottomOuter/PantsALF_01/Types/PantsALF_01_gunpattern.type", "resGender": 0}
1904	14909	{"_key": 14909, "typeID": 33720, "resPath": "Feet/BootsSLF_01/Types/BootsSLF_01_black.type", "resGender": 0}
1905	14910	{"_key": 14910, "typeID": 33770, "resPath": "TopMiddle/ShirtQM01/Types/neom2014B.type", "resGender": 1}
1906	14926	{"_key": 14926, "typeID": 33768, "resPath": "TopMiddle/ShirtQF01/Types/neof2014B.type", "resGender": 0}
1907	14931	{"_key": 14931, "typeID": 33767, "resPath": "TopMiddle/ShirtQF01/Types/neof2014A.type", "resGender": 0}
1908	14933	{"_key": 14933, "typeID": 33769, "resPath": "TopMiddle/ShirtQM01/Types/neom2014A.type", "resGender": 1}
1909	14946	{"_key": 14946, "typeID": 33779, "resPath": "Feet/BootsALM01/Types/BootsALM01_DarkRedBlack.type", "resGender": 1}
1910	14947	{"_key": 14947, "typeID": 33780, "resPath": "Feet/BootsALM01/Types/BootsALM01_BrownGold.type", "resGender": 1}
1911	14948	{"_key": 14948, "typeID": 33776, "resPath": "Feet/BootsALM01/Types/BootsALM01_WhiteGold.type", "resGender": 1}
1912	14950	{"_key": 14950, "typeID": 33799, "resPath": "outer/JacketALM01/Types/JacketALM01_BrownBlackGold.type", "resGender": 1}
1913	14951	{"_key": 14951, "typeID": 33796, "resPath": "outer/JacketALM01/Types/JacketALM01_WhiteGold.type", "resGender": 1}
1914	14952	{"_key": 14952, "typeID": 33781, "resPath": "bottomOuter/PantsCLM01/Types/PantsCLM01_White.type", "resGender": 1}
1915	14953	{"_key": 14953, "typeID": 33783, "resPath": "bottomOuter/PantsCLM01/Types/PantsCLM01_Graphite.type", "resGender": 1}
1916	14954	{"_key": 14954, "typeID": 33798, "resPath": "outer/JacketALM01/Types/JacketALM01_RedGold.type", "resGender": 1}
1917	14955	{"_key": 14955, "typeID": 33794, "resPath": "outer/JacketCLM01/Types/JacketCLM01_DarkRed.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1918	14956	{"_key": 14956, "typeID": 33789, "resPath": "bottomOuter/PantsALM01/Types/PantsALM01_BlueShiny.type", "resGender": 1}
1919	14957	{"_key": 14957, "typeID": 33784, "resPath": "bottomOuter/PantsCLM01/Types/PantsCLM01_DarkRed.type", "resGender": 1}
1920	14958	{"_key": 14958, "typeID": 33800, "resPath": "outer/JacketALM01/Types/JacketALM01_BlackSilver.type", "resGender": 1}
1921	14959	{"_key": 14959, "typeID": 33773, "resPath": "Feet/BootsCLM01/Types/BootsCLM01_Brown.type", "resGender": 1}
1922	14960	{"_key": 14960, "typeID": 33777, "resPath": "Feet/BootsALM01/Types/BootsALM01_Royal.type", "resGender": 1}
1923	14962	{"_key": 14962, "typeID": 33791, "resPath": "outer/JacketCLM01/Types/JacketCLM01_White.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1924	14963	{"_key": 14963, "typeID": 33787, "resPath": "bottomOuter/PantsALM01/Types/PantsALM01_Royal.type", "resGender": 1}
1925	14964	{"_key": 14964, "typeID": 33772, "resPath": "Feet/BootsCLM01/Types/BootsCLM01_Graphite.type", "resGender": 1}
1926	14965	{"_key": 14965, "typeID": 33774, "resPath": "Feet/BootsCLM01/Types/BootsCLM01_BlueShiny.type", "resGender": 1}
1927	14966	{"_key": 14966, "typeID": 33793, "resPath": "outer/JacketCLM01/Types/JacketCLM01_Graphite.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1928	14967	{"_key": 14967, "typeID": 33771, "resPath": "Feet/BootsCLM01/Types/BootsCLM01_White.type", "resGender": 1}
1929	14968	{"_key": 14968, "typeID": 33778, "resPath": "Feet/BootsALM01/Types/BootsALM01_GreySilver.type", "resGender": 1}
1930	14969	{"_key": 14969, "typeID": 33792, "resPath": "outer/JacketCLM01/Types/JacketCLM01_GreenCamo.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1931	14970	{"_key": 14970, "typeID": 33790, "resPath": "bottomOuter/PantsALM01/Types/PantsALM01_BlackSilver.type", "resGender": 1}
1932	14971	{"_key": 14971, "typeID": 33788, "resPath": "bottomOuter/PantsALM01/Types/PantsALM01_DarkredBlackGold.type", "resGender": 1}
1933	14972	{"_key": 14972, "typeID": 33782, "resPath": "bottomOuter/PantsCLM01/Types/PantsCLM01_GreenCamo.type", "resGender": 1}
1934	14973	{"_key": 14973, "typeID": 33775, "resPath": "Feet/BootsCLM01/Types/BootsCLM01_Black.type", "resGender": 1}
1935	14974	{"_key": 14974, "typeID": 33786, "resPath": "bottomOuter/PantsALM01/Types/PantsALM01_WhiteBlackGold.type", "resGender": 1}
1936	14975	{"_key": 14975, "typeID": 33797, "resPath": "outer/JacketALM01/Types/JacketALM01_Royal.type", "resGender": 1}
1937	14976	{"_key": 14976, "typeID": 33785, "resPath": "bottomOuter/PantsCLM01/Types/PantsCLM01_BlackLeather.type", "resGender": 1}
1938	14977	{"_key": 14977, "typeID": 33795, "resPath": "outer/JacketCLM01/Types/JacketCLM01_BlueShiny.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1939	14979	{"_key": 14979, "typeID": 33804, "resPath": "Outer/JacketMilF01/Types/JacketMilF01_silverV2.type", "resGender": 0}
1940	14980	{"_key": 14980, "typeID": 33803, "resPath": "outer/JacketMilM02/Types/JacketMilM02_blackV2.type", "resGender": 1}
1941	14981	{"_key": 14981, "typeID": 33813, "resPath": "TopMiddle/ShirtQF01/Types/shirtqf04.type", "resGender": 0}
1942	14982	{"_key": 14982, "typeID": 33812, "resPath": "TopMiddle/ShirtQM01/Types/shirtqm04.type", "resGender": 1}
1943	14986	{"_key": 14986, "typeID": 34078, "resPath": "hair/Hair_Bun_Hp_02/Types/Hair_Bun_Hp_02_Black.type", "resGender": 0}
1944	14987	{"_key": 14987, "typeID": 34077, "resPath": "hair/Hair_Lace_01/Types/Hair_Lace_01_Gold.type", "resGender": 0}
1945	14989	{"_key": 14989, "typeID": 34076, "resPath": "hair/Hair_Bun_Hp_02/Types/Hair_Bun_Hp_02_Clear.type", "resGender": 0}
1946	14990	{"_key": 14990, "typeID": 34075, "resPath": "hair/Hair_Medium_Hp_01/Types/Hair_Medium_Hp_01_Simple.type", "resGender": 0}
1947	14991	{"_key": 14991, "typeID": 34074, "resPath": "hair/Hair_Medium_Hp_01/Types/Hair_Medium_Hp_01_Jade.type", "resGender": 0}
1948	14992	{"_key": 14992, "typeID": 34073, "resPath": "hair/Hair_Lace_01/Types/Hair_Lace_01_Metallic.type", "resGender": 0}
1949	14994	{"_key": 14994, "typeID": 34072, "resPath": "hair/Hair_Lace_01/Types/Hair_Lace_01_Copper.type", "resGender": 0}
1950	14995	{"_key": 14995, "typeID": 34071, "resPath": "hair/Hair_Medium_Hp_01/Types/Hair_Medium_Hp_01_Black.type", "resGender": 0}
1951	14998	{"_key": 14998, "typeID": 34070, "resPath": "hair/Hair_Bun_Hp_02/Types/Hair_Bun_Hp_02_Orange.type", "resGender": 0}
1952	14999	{"_key": 14999, "typeID": 34069, "resPath": "hair/Hair_Medium_Hp_01/Types/Hair_Medium_Hp_01_Gold.type", "resGender": 0}
1953	15001	{"_key": 15001, "typeID": 34068, "resPath": "hair/Hair_Lace_01/Types/Hair_Lace_01_Black.type", "resGender": 0}
1954	15002	{"_key": 15002, "typeID": 34067, "resPath": "hair/Hair_Medium_Hp_01/Types/Hair_Medium_Hp_01_Platinum.type", "resGender": 0}
1955	15003	{"_key": 15003, "typeID": 34066, "resPath": "hair/Hair_Bun_Hp_02/Types/Hair_Bun_Hp_02_Blue.type", "resGender": 0}
1956	15004	{"_key": 15004, "typeID": 34065, "resPath": "hair/Hair_Medium_Hp_01/Types/Hair_Medium_Hp_01_Gunmetal.type", "resGender": 0}
1957	15005	{"_key": 15005, "typeID": 34064, "resPath": "hair/Hair_Bun_Hp_02/Types/Hair_Bun_Hp_02_Cyan.type", "resGender": 0}
1958	15006	{"_key": 15006, "typeID": 34063, "resPath": "hair/HeadWear_Caldari/Types/HeadWear_Caldari_BlackShiny.type", "resGender": 1}
1959	15007	{"_key": 15007, "typeID": 34062, "resPath": "hair/HeadWear_Caldari/Types/HeadWear_Caldari_Metal.type", "resGender": 1}
1960	15008	{"_key": 15008, "typeID": 34061, "resPath": "hair/HeadWear_Amarr/Types/HeadWear_Amarr_Bronze.type", "resGender": 1}
1961	15009	{"_key": 15009, "typeID": 34060, "resPath": "hair/HeadWear_Amarr/Types/HeadWear_Amarr_Gold.type", "resGender": 1}
1962	15010	{"_key": 15010, "typeID": 34059, "resPath": "hair/HeadWear_Amarr/Types/HeadWear_Amarr_Silver.type", "resGender": 1}
1963	15011	{"_key": 15011, "typeID": 34058, "resPath": "hair/HeadWear_Caldari/Types/HeadWear_Caldari_White.type", "resGender": 1}
1964	15012	{"_key": 15012, "typeID": 34057, "resPath": "hair/HeadWear_Caldari/Types/HeadWear_Caldari_Black.type", "resGender": 1}
1965	15013	{"_key": 15013, "typeID": 34056, "resPath": "hair/HeadWear_Amarr/Types/HeadWear_Amarr_Black.type", "resGender": 1}
1966	15016	{"_key": 15016, "typeID": 34174, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_soe.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1967	15017	{"_key": 15017, "typeID": 34171, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_minmatar.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1968	15018	{"_key": 15018, "typeID": -1, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_red.type", "resGender": 0}
1969	15020	{"_key": 15020, "typeID": -1, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_creamblack.type", "resGender": 0}
1970	15021	{"_key": 15021, "typeID": 34173, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_ore.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1971	15022	{"_key": 15022, "typeID": -1, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_whiteblack.type", "resGender": 0}
1972	15023	{"_key": 15023, "typeID": -1, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_redblack.type", "resGender": 0}
1973	15024	{"_key": 15024, "typeID": 34178, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_sansha.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1974	15025	{"_key": 15025, "typeID": 34181, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_serpentis.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1975	15026	{"_key": 15026, "typeID": 34169, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_caldari.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1976	15027	{"_key": 15027, "typeID": -1, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_blackbluematte.type", "resGender": 0}
1977	15028	{"_key": 15028, "typeID": -1, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_brownblack.type", "resGender": 0}
1978	15030	{"_key": 15030, "typeID": -1, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_browngreymatte.type", "resGender": 0}
1979	15031	{"_key": 15031, "typeID": 34179, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_bloodraiders.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1980	15034	{"_key": 15034, "typeID": -1, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_white.type", "resGender": 0}
1981	15036	{"_key": 15036, "typeID": -1, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_greenmatte.type", "resGender": 0}
1982	15037	{"_key": 15037, "typeID": -1, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_black.type", "resGender": 0}
1983	15038	{"_key": 15038, "typeID": 34176, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_interbus.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1984	15039	{"_key": 15039, "typeID": 34177, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_angel.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1985	15040	{"_key": 15040, "typeID": 34180, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_guristas.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1986	15041	{"_key": 15041, "typeID": 34170, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_amarr.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1987	15042	{"_key": 15042, "typeID": 34172, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_gallente.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1988	15043	{"_key": 15043, "typeID": 34175, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_mordus.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1989	15044	{"_key": 15044, "typeID": -1, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_brown.type", "resGender": 0}
1990	15045	{"_key": 15045, "typeID": -1, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_blackred.type", "resGender": 0}
1991	15069	{"_key": 15069, "typeID": 34157, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_Amarr.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1992	15070	{"_key": 15070, "typeID": 34167, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_Guristas.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1993	15071	{"_key": 15071, "typeID": 34158, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_Minmatar.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1994	15072	{"_key": 15072, "typeID": 34168, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_Serpentis.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1995	15073	{"_key": 15073, "typeID": -1, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_Black.type", "resGender": 1}
1996	15074	{"_key": 15074, "typeID": -1, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_BlueShiny.type", "resGender": 1}
1997	15075	{"_key": 15075, "typeID": 34165, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_Sansha.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
1998	15076	{"_key": 15076, "typeID": -1, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_Red.type", "resGender": 1}
1999	15077	{"_key": 15077, "typeID": 34159, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_Gallente.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
2000	15078	{"_key": 15078, "typeID": 34162, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_Mordus.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
2001	15079	{"_key": 15079, "typeID": -1, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_Brown.type", "resGender": 1}
2002	15080	{"_key": 15080, "typeID": 34160, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_ORE.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
2003	15081	{"_key": 15081, "typeID": -1, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_BlackRedWhite.type", "resGender": 1}
2004	15082	{"_key": 15082, "typeID": 34156, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_Caldari.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
2005	15083	{"_key": 15083, "typeID": 34161, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_SOE.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
2006	15084	{"_key": 15084, "typeID": -1, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_GreenShiny.type", "resGender": 1}
2007	15085	{"_key": 15085, "typeID": -1, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_BrownOrange.type", "resGender": 1}
2008	15086	{"_key": 15086, "typeID": -1, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_Grey.type", "resGender": 1}
2009	15087	{"_key": 15087, "typeID": 34164, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_Angel.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
2010	15088	{"_key": 15088, "typeID": 34166, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_Bloodraiders.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
2011	15089	{"_key": 15089, "typeID": -1, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_BrownGreyMatte.type", "resGender": 1}
2012	15090	{"_key": 15090, "typeID": -1, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_White.type", "resGender": 1}
2013	15091	{"_key": 15091, "typeID": 34163, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_Interbus.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
2014	15092	{"_key": 15092, "typeID": 34211, "resPath": "TopMiddle/ShirtQF01/Types/lvf02.type", "resGender": 0}
2015	15093	{"_key": 15093, "typeID": 34210, "resPath": "TopMiddle/ShirtQM01/Types/lvm02.type", "resGender": 1}
2016	15102	{"_key": 15102, "typeID": 34361, "resPath": "Feet/BootsPrtm01/Types/BootsPrtm01_sansha.type", "resGender": 1}
2017	15105	{"_key": 15105, "typeID": 34354, "resPath": "bottomOuter/PantsPrtm01/Types/PantsPrtm01_bloodraiders.type", "resGender": 1}
2018	15109	{"_key": 15109, "typeID": 34355, "resPath": "bottomOuter/PantsPrtm01/Types/PantsPrtm01_sansha.type", "resGender": 1}
2019	15110	{"_key": 15110, "typeID": 34349, "resPath": "outer/JacketPrtm01/Types/JacketPrtm01_guristas.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
2020	15111	{"_key": 15111, "typeID": 34348, "resPath": "outer/JacketPrtm01/Types/JacketPrtm01_sansha.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
2021	15113	{"_key": 15113, "typeID": 34347, "resPath": "outer/JacketPrtm01/Types/JacketPrtm01_bloodraiders.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
2022	15114	{"_key": 15114, "typeID": 34356, "resPath": "bottomOuter/PantsPrtm01/Types/PantsPrtm01_guristas.type", "resGender": 1}
2023	15115	{"_key": 15115, "typeID": 34362, "resPath": "Feet/BootsPrtm01/Types/BootsPrtm01_guristas.type", "resGender": 1}
2024	15116	{"_key": 15116, "typeID": 34360, "resPath": "Feet/BootsPrtm01/Types/BootsPrtm01_bloodraiders.type", "resGender": 1}
2025	15118	{"_key": 15118, "typeID": 34363, "resPath": "Feet/BootsPrtF01/Types/BootsPrtF01_bloodraiders.type", "resGender": 0}
2026	15120	{"_key": 15120, "typeID": 34359, "resPath": "bottomOuter/PantsPrtF01/Types/PantsPrtF01_guristas.type", "resGender": 0}
2027	15123	{"_key": 15123, "typeID": 34364, "resPath": "Feet/BootsPrtF01/Types/BootsPrtF01_sansha.type", "resGender": 0}
2028	15124	{"_key": 15124, "typeID": 34350, "resPath": "Outer/JacketPrtF01/Types/JacketPrtF01_sansha.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
2029	15128	{"_key": 15128, "typeID": 34358, "resPath": "bottomOuter/PantsPrtF01/Types/PantsPrtF01_sansha.type", "resGender": 0}
2030	15129	{"_key": 15129, "typeID": 34357, "resPath": "bottomOuter/PantsPrtF01/Types/PantsPrtF01_bloodraiders.type", "resGender": 0}
2031	15130	{"_key": 15130, "typeID": 34351, "resPath": "Outer/JacketPrtF01/Types/JacketPrtF01_guristas.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
2032	15131	{"_key": 15131, "typeID": 34365, "resPath": "Feet/BootsPrtF01/Types/BootsPrtF01_guristas.type", "resGender": 0}
2033	15132	{"_key": 15132, "typeID": 34353, "resPath": "Outer/JacketPrtF01/Types/JacketPrtF01_bloodraiders.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
2034	15140	{"_key": 15140, "typeID": 34393, "resPath": "outer/JacketPrtm01/Types/JacketPrtm01_orange.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
2035	15149	{"_key": 15149, "typeID": 34394, "resPath": "Outer/JacketPrtF01/Types/JacketPrtF01_orange.type", "resGender": 0}
2036	15157	{"_key": 15157, "resPath": "Makeup/Eyes/Eyes_DR/Types/Eyes_Dr.type", "resGender": 0, "empireRestrictions": [1, 2, 4, 8]}
2037	15159	{"_key": 15159, "resPath": "Skintype/DR/Types/skintype_f_drifter_01.type", "resGender": 0, "empireRestrictions": [1, 2, 4, 8]}
2038	15161	{"_key": 15161, "resPath": "Makeup/Implants/DRSkull/Types/DrSkull.type", "empireRestrictions": [1, 2, 4, 8]}
2039	15199	{"_key": 15199, "resPath": "Skintype/DR/Types/skintype_m_drifter_01.type", "resGender": 1, "empireRestrictions": [1, 2, 4, 8]}
2040	15200	{"_key": 15200, "resPath": "Makeup/Eyes/Eyes_DR/Types/Eyes_DR.type", "resGender": 1, "empireRestrictions": [1, 2, 4, 8]}
2041	15201	{"_key": 15201, "resPath": "Makeup/Implants/DRSkull/Types/DRSkull.type", "resGender": 1, "empireRestrictions": [1, 2, 4, 8]}
2042	15208	{"_key": 15208, "typeID": 34825, "resPath": "TopMiddle/ShirtQF01/Types/ff2015f01.type", "resGender": 0}
2043	15209	{"_key": 15209, "typeID": 34824, "resPath": "topMiddle/ShirtQM01/Types/ff2015m01.type", "resGender": 1}
2044	15211	{"_key": 15211, "typeID": 35682, "resPath": "TopMiddle/ShirtQF01/Types/soerff02.type", "resGender": 0}
2045	15213	{"_key": 15213, "typeID": 35681, "resPath": "topMiddle/ShirtQM01/Types/soerfm02.type", "resGender": 1}
2046	15303	{"_key": 15303, "typeID": 36493, "resPath": "bottomOuter/PantsEngM01/Types/PantsEngM01_blueorange.type", "resGender": 1}
2047	15304	{"_key": 15304, "typeID": 36484, "resPath": "topMiddle/ShirtEngM01/Types/ShirtEngM01_oregreen.type", "resGender": 1}
2048	15305	{"_key": 15305, "typeID": 36495, "resPath": "bottomOuter/PantsEngM01/Types/PantsEngM01_camo.type", "resGender": 1}
2049	15306	{"_key": 15306, "typeID": 36497, "resPath": "bottomOuter/PantsEngM01/Types/PantsEngM01_oregreen.type", "resGender": 1}
2050	15307	{"_key": 15307, "typeID": 36506, "resPath": "Feet/ShoesEngM01/Types/ShoesEngM01_redwhite.type", "resGender": 1}
2051	15309	{"_key": 15309, "typeID": 36483, "resPath": "topMiddle/ShirtEngM01/Types/ShirtEngM01_cyan.type", "resGender": 1}
2052	15310	{"_key": 15310, "typeID": 36496, "resPath": "bottomOuter/PantsEngM01/Types/PantsEngM01_cyan.type", "resGender": 1}
2053	15311	{"_key": 15311, "typeID": 36510, "resPath": "Feet/ShoesEngM01/Types/ShoesEngM01_oreorange.type", "resGender": 1}
2054	15313	{"_key": 15313, "typeID": 36480, "resPath": "topMiddle/ShirtEngM01/Types/ShirtEngM01_blueorange.type", "resGender": 1}
2055	15315	{"_key": 15315, "typeID": 36482, "resPath": "topMiddle/ShirtEngM01/Types/ShirtEngM01_camo.type", "resGender": 1}
2056	15316	{"_key": 15316, "typeID": 36507, "resPath": "Feet/ShoesEngM01/Types/ShoesEngM01_camo.type", "resGender": 1}
2057	15317	{"_key": 15317, "typeID": 36505, "resPath": "Feet/ShoesEngM01/Types/ShoesEngM01_blueorange.type", "resGender": 1}
2058	15318	{"_key": 15318, "typeID": 36498, "resPath": "bottomOuter/PantsEngM01/Types/PantsEngM01_oreorange.type", "resGender": 1}
2059	15319	{"_key": 15319, "typeID": 36485, "resPath": "topMiddle/ShirtEngM01/Types/ShirtEngM01_oreorange.type", "resGender": 1}
2060	15320	{"_key": 15320, "typeID": 36481, "resPath": "topMiddle/ShirtEngM01/Types/ShirtEngM01_redwhite.type", "resGender": 1}
2061	15321	{"_key": 15321, "typeID": 36494, "resPath": "bottomOuter/PantsEngM01/Types/PantsEngM01_redwhite.type", "resGender": 1}
2062	15322	{"_key": 15322, "typeID": 36509, "resPath": "Feet/ShoesEngM01/Types/ShoesEngM01_oregreen.type", "resGender": 1}
2063	15323	{"_key": 15323, "typeID": 36508, "resPath": "Feet/ShoesEngM01/Types/ShoesEngM01_cyan.type", "resGender": 1}
2064	15499	{"_key": 15499, "typeID": 36502, "resPath": "bottomOuter/PantsEngF01/Types/PantsEngF01_Cyan.type", "resGender": 0}
2065	15500	{"_key": 15500, "typeID": 36500, "resPath": "bottomOuter/PantsEngF01/Types/PantsEngF01_RedWhite.type", "resGender": 0}
2066	15502	{"_key": 15502, "typeID": 36488, "resPath": "TopMiddle/ShirtEngF01/Types/ShirtEngF01_Camo.type", "resGender": 0}
2067	15503	{"_key": 15503, "typeID": 36503, "resPath": "bottomOuter/PantsEngF01/Types/PantsEngF01_OreGreen.type", "resGender": 0}
2068	15504	{"_key": 15504, "typeID": 36490, "resPath": "TopMiddle/ShirtEngF01/Types/ShirtEngF01_OreGreen.type", "resGender": 0}
2069	15506	{"_key": 15506, "typeID": 36501, "resPath": "bottomOuter/PantsEngF01/Types/PantsEngF01_Camo.type", "resGender": 0}
2070	15507	{"_key": 15507, "typeID": 36499, "resPath": "bottomOuter/PantsEngF01/Types/PantsEngF01_BlueOrange.type", "resGender": 0}
2071	15509	{"_key": 15509, "typeID": 36487, "resPath": "TopMiddle/ShirtEngF01/Types/ShirtEngF01_RedWhite.type", "resGender": 0}
2072	15511	{"_key": 15511, "typeID": 36489, "resPath": "TopMiddle/ShirtEngF01/Types/ShirtEngF01_Cyan.type", "resGender": 0}
2073	15512	{"_key": 15512, "typeID": 36486, "resPath": "TopMiddle/ShirtEngF01/Types/ShirtEngF01_BlueOrange.type", "resGender": 0}
2074	15513	{"_key": 15513, "typeID": 36514, "resPath": "Feet/ShoesEngF01/Types/ShoesEngF01_Cyan.type", "resGender": 0}
2075	15514	{"_key": 15514, "typeID": 36511, "resPath": "Feet/ShoesEngF01/Types/ShoesEngF01_BlueOrange.type", "resGender": 0}
2076	15515	{"_key": 15515, "typeID": 36513, "resPath": "Feet/ShoesEngF01/Types/ShoesEngF01_Camo.type", "resGender": 0}
2077	15516	{"_key": 15516, "typeID": 36504, "resPath": "bottomOuter/PantsEngF01/Types/PantsEngF01_OreOrange.type", "resGender": 0}
2078	15517	{"_key": 15517, "typeID": 36516, "resPath": "Feet/ShoesEngF01/Types/ShoesEngF01_OreOrange.type", "resGender": 0}
2079	15518	{"_key": 15518, "typeID": 36491, "resPath": "TopMiddle/ShirtEngF01/Types/ShirtEngF01_OreOrange.type", "resGender": 0}
2080	15519	{"_key": 15519, "typeID": 36515, "resPath": "Feet/ShoesEngF01/Types/ShoesEngF01_OreGreen.type", "resGender": 0}
2081	15521	{"_key": 15521, "typeID": 36512, "resPath": "Feet/ShoesEngF01/Types/ShoesEngF01_RedWhite.type", "resGender": 0}
2082	15525	{"_key": 15525, "typeID": 37600, "resPath": "Outer/ArmorSuitCF01/Types/ArmorSuitCF01_Black.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2083	15527	{"_key": 15527, "typeID": 37603, "resPath": "Outer/ArmorSuitCF01/Types/ArmorSuitCF01_SOERed.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2084	15529	{"_key": 15529, "typeID": 37602, "resPath": "Outer/ArmorSuitCF01/Types/ArmorSuitCF01_Copper.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2085	15531	{"_key": 15531, "typeID": 37601, "resPath": "Outer/ArmorSuitCF01/Types/ArmorSuitCF01_Blue.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2086	15537	{"_key": 15537, "typeID": 37809, "resPath": "topMiddle/ShirtQM01/Types/ShirtQM01_Concord.type", "resGender": 1}
2087	15538	{"_key": 15538, "typeID": 37808, "resPath": "TopMiddle/ShirtQF01/Types/ShirtQF01_Concord.type", "resGender": 0}
2088	15540	{"_key": 15540, "typeID": 37807, "resPath": "outer/JacketCLM01/Types/JacketCLM01_Concord.type", "resGender": 1}
2089	15541	{"_key": 15541, "typeID": 37806, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_concord.type", "resGender": 0}
2090	15547	{"_key": 15547, "typeID": 37817, "resPath": "outer/JacketALM01/Types/JacketALM01_PurpleGold.type", "resGender": 1}
2091	15548	{"_key": 15548, "typeID": 37816, "resPath": "Outer/JacketSLF_01/Types/JacketSLF_01_redcicles.type", "resGender": 0}
2092	15551	{"_key": 15551, "typeID": 37810, "resPath": "outer/ArmorSuitMM01/Types/ArmorSuitMM01_Black.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2093	15555	{"_key": 15555, "typeID": 37811, "resPath": "outer/ArmorSuitMM01/Types/ArmorSuitMM01_Copper.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2094	15558	{"_key": 15558, "typeID": 37818, "resPath": "outer/ArmorSuitMM01/Types/ArmorSuitMM01_Blue.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2095	15560	{"_key": 15560, "typeID": 37815, "resPath": "outer/ArmorSuitMM01/Types/ArmorSuitMM01_SOERed.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2096	15566	{"_key": 15566, "typeID": 37863, "resPath": "Outer/ArmorSuitCF01/Types/ArmorSuitCF01_BlueWhite.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2097	15568	{"_key": 15568, "typeID": 37865, "resPath": "TopMiddle/ShirtCF01/Types/ShirtF01_Serpentis.type", "resGender": 0}
2098	15574	{"_key": 15574, "typeID": 37866, "resPath": "topMiddle/ShirtCM01/Types/ShirtM01_Serpentis.type", "resGender": 1}
2099	15583	{"_key": 15583, "typeID": 37864, "resPath": "outer/ArmorSuitMM01/Types/ArmorSuitMM01_BlueWhite.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2100	15596	{"_key": 15596, "typeID": 40459, "resPath": "Outer/LabCoatF01/Types/LabCoatF01_Green.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 0, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
2101	15597	{"_key": 15597, "typeID": 40460, "resPath": "Outer/LabCoatF01/Types/LabCoatF01_Orange.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 0, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
2102	15598	{"_key": 15598, "typeID": 40458, "resPath": "Outer/LabCoatF01/Types/LabCoatF01_Cyan.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 0, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
2103	15600	{"_key": 15600, "typeID": 40457, "resPath": "Outer/LabCoatF01/Types/LabCoatF01_BlackRed.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 0, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
2104	15605	{"_key": 15605, "typeID": 40461, "resPath": "outer/LabCoatM01/Types/LabCoatM01_BlackRed.type", "resGender": 1}
2105	15608	{"_key": 15608, "typeID": 40462, "resPath": "outer/LabCoatM01/Types/LabCoatM01_Cyan.type", "resGender": 1}
2106	15609	{"_key": 15609, "typeID": 40463, "resPath": "outer/LabCoatM01/Types/LabCoatM01_Green.type", "resGender": 1}
2107	15614	{"_key": 15614, "typeID": 40464, "resPath": "outer/LabCoatM01/Types/LabCoatM01_Orange.type", "resGender": 1}
2108	15616	{"_key": 15616, "typeID": 40527, "resPath": "TopMiddle/ShirtQF01/Types/shirtqf01_upwell.type", "resGender": 0}
2109	15623	{"_key": 15623, "typeID": 40525, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_upwell.type", "resGender": 0}
2110	15626	{"_key": 15626, "typeID": 40524, "resPath": "bottomOuter/PantsMilM01/Types/PantsMilM01_upwell.type", "resGender": 1}
2111	15628	{"_key": 15628, "typeID": 40526, "resPath": "topMiddle/ShirtQM01/Types/shirtqm01_upwell.type", "resGender": 1}
2112	15629	{"_key": 15629, "typeID": 40523, "resPath": "Outer/JacketMilF01/Types/JacketMilF01_upwell.type", "resGender": 0}
2113	15631	{"_key": 15631, "typeID": 40522, "resPath": "outer/JacketMilM02/Types/JacketMilM02_upwell.type", "resGender": 1}
2114	15632	{"_key": 15632, "typeID": 41053, "resPath": "Makeup/Augmentations/Face_01/Types/Face_01_F_V5.type", "resGender": 0}
2115	15633	{"_key": 15633, "typeID": 41052, "resPath": "Makeup/Augmentations/Face_01/Types/Face_01_F_V1.type", "resGender": 0}
2116	15634	{"_key": 15634, "typeID": 41051, "resPath": "Makeup/Augmentations/Face_01/Types/Face_01_F_V3.type", "resGender": 0}
2117	15635	{"_key": 15635, "typeID": 41050, "resPath": "Makeup/Augmentations/Face_01/Types/Face_01_F_V4.type", "resGender": 0}
2118	15637	{"_key": 15637, "typeID": 41049, "resPath": "Makeup/Augmentations/Face_01/Types/Face_01_F_V0.type", "resGender": 0}
2119	15638	{"_key": 15638, "typeID": 41048, "resPath": "Makeup/Augmentations/Face_01/Types/Face_01_F_V2.type", "resGender": 0}
2120	15643	{"_key": 15643, "typeID": 41047, "resPath": "Makeup/Augmentations/Face_01/Types/Face_01_M_V1.type", "resGender": 1}
2121	15646	{"_key": 15646, "typeID": 41046, "resPath": "Makeup/Augmentations/Face_01/Types/Face_01_M_V5.type", "resGender": 1}
2122	15648	{"_key": 15648, "typeID": 41045, "resPath": "Makeup/Augmentations/Face_01/Types/Face_01_M_V0.type", "resGender": 1}
2123	15650	{"_key": 15650, "typeID": 41044, "resPath": "Makeup/Augmentations/Face_01/Types/Face_01_M_V3.type", "resGender": 1}
2124	15652	{"_key": 15652, "typeID": 41043, "resPath": "Makeup/Augmentations/Face_01/Types/Face_01_M_V4.type", "resGender": 1}
2125	15654	{"_key": 15654, "typeID": 41036, "resPath": "Makeup/Augmentations/Face_01/Types/Face_01_M_V2.type", "resGender": 1}
2126	15671	{"_key": 15671, "typeID": 41575, "resPath": "Accessories/Glasses/Glasses_Citadel_F01/Types/GlassesCitadelF01_black.type", "resGender": 0}
2127	15683	{"_key": 15683, "typeID": 41576, "resPath": "Accessories/Glasses/Glasses_Citadel_M01/Types/GlassesCitadelM01_black.type", "resGender": 1}
2128	15684	{"_key": 15684, "typeID": 42745, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_Gallente.type", "resGender": 0}
2129	15686	{"_key": 15686, "typeID": 42744, "resPath": "hair/HeadWear_Beret_F01/Types/HeadWear_Beret_AmarrF01.type", "resGender": 0}
2130	15687	{"_key": 15687, "typeID": 42743, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_Guristas.type", "resGender": 1}
2131	15688	{"_key": 15688, "typeID": 42742, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_Concord.type", "resGender": 0}
2132	15689	{"_key": 15689, "typeID": 42741, "resPath": "hair/HeadWear_Beret_M01/Types/HeadWear_Beret_AmarrM01.type", "resGender": 1}
2133	15691	{"_key": 15691, "typeID": 42740, "resPath": "hair/HeadWear_Beret_F01/Types/HeadWear_Beret_CaldariF01.type", "resGender": 0}
2134	15694	{"_key": 15694, "typeID": 42739, "resPath": "hair/HeadWear_Beret_M01/Types/HeadWear_Beret_GallenteM01.type", "resGender": 1}
2135	15697	{"_key": 15697, "typeID": 42738, "resPath": "hair/HeadWear_Beret_F01/Types/HeadWear_Beret_MinmatarF01.type", "resGender": 0}
2136	15698	{"_key": 15698, "typeID": 42737, "resPath": "hair/HeadWear_Beret_F01/Types/HeadWear_Beret_ConcordF01.type", "resGender": 0}
2137	15699	{"_key": 15699, "typeID": 42736, "resPath": "hair/HeadWear_Beret_M01/Types/HeadWear_Beret_CaldariM01.type", "resGender": 1}
2138	15701	{"_key": 15701, "typeID": 42735, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_Orange.type", "resGender": 0}
2139	15703	{"_key": 15703, "typeID": 42734, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_Black.type", "resGender": 0}
2140	15704	{"_key": 15704, "typeID": 42733, "resPath": "hair/HeadWear_Beret_F01/Types/HeadWear_Beret_BloodraidersF01.type", "resGender": 0}
2141	15705	{"_key": 15705, "typeID": 42732, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_Camo.type", "resGender": 1}
2142	15706	{"_key": 15706, "typeID": 42731, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_Caldari.type", "resGender": 1}
2143	15708	{"_key": 15708, "typeID": 42730, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_Minmatar.type", "resGender": 1}
2144	15709	{"_key": 15709, "typeID": 42729, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_Camo.type", "resGender": 0}
2145	15712	{"_key": 15712, "typeID": 42728, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_Amarr.type", "resGender": 1}
2146	15714	{"_key": 15714, "typeID": 42727, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_Green.type", "resGender": 0}
2147	15715	{"_key": 15715, "typeID": 42726, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_Blood.type", "resGender": 1}
2148	15716	{"_key": 15716, "typeID": 42725, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_Amarr.type", "resGender": 0}
2149	15717	{"_key": 15717, "typeID": 42724, "resPath": "hair/HeadWear_Beret_M01/Types/HeadWear_Beret_ConcordM01.type", "resGender": 1}
2150	15718	{"_key": 15718, "typeID": 42723, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_Black.type", "resGender": 1}
2151	15720	{"_key": 15720, "typeID": 42722, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_Guristas.type", "resGender": 0}
2152	15721	{"_key": 15721, "typeID": 42721, "resPath": "hair/HeadWear_Beret_M01/Types/HeadWear_Beret_GuristasM01.type", "resGender": 1}
2153	15722	{"_key": 15722, "typeID": 42720, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_Caldari.type", "resGender": 0}
2154	15723	{"_key": 15723, "typeID": 42719, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_Concord.type", "resGender": 1}
2155	15724	{"_key": 15724, "typeID": 42718, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_Blood.type", "resGender": 0}
2156	15726	{"_key": 15726, "typeID": 42717, "resPath": "hair/HeadWear_Beret_F01/Types/HeadWear_Beret_GuristasF01.type", "resGender": 0}
2157	15727	{"_key": 15727, "typeID": 42716, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_WhiteBlack.type", "resGender": 0}
2158	15728	{"_key": 15728, "typeID": 42715, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_Minmatar.type", "resGender": 0}
2159	15729	{"_key": 15729, "typeID": 42714, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_WhiteBlack.type", "resGender": 1}
2160	15730	{"_key": 15730, "typeID": 42713, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_Orange.type", "resGender": 1}
2161	15731	{"_key": 15731, "typeID": 42712, "resPath": "hair/HeadWear_Beret_M01/Types/HeadWear_Beret_MinmatarM01.type", "resGender": 1}
2162	15733	{"_key": 15733, "typeID": 42711, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_Green.type", "resGender": 1}
2163	15734	{"_key": 15734, "typeID": 42710, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_Gallente.type", "resGender": 1}
2164	15735	{"_key": 15735, "typeID": 42709, "resPath": "hair/HeadWear_Beret_F01/Types/HeadWear_Beret_GallenteF01.type", "resGender": 0}
2165	15736	{"_key": 15736, "typeID": 42708, "resPath": "hair/HeadWear_Beret_M01/Types/HeadWear_Beret_BloodraidersM01.type", "resGender": 1}
2166	15740	{"_key": 15740, "typeID": 42707, "resPath": "TopOuter/ShirtMilF01/Types/ShirtMilF01_bloodraiders.type", "resGender": 0}
2167	15741	{"_key": 15741, "typeID": 42706, "resPath": "Outer/JacketPrtF01/Types/JacketPrtF01_bloodraiders_spec.type", "resGender": 0}
2168	15746	{"_key": 15746, "typeID": 42705, "resPath": "outer/JacketPrtm01/Types/JacketPrtm01_bloodraiders_spec.type", "resGender": 1}
2169	15749	{"_key": 15749, "typeID": 42704, "resPath": "topMiddle/ShirtQM01/Types/ShirtBloodraidersM01.type", "resGender": 1}
2170	15750	{"_key": 15750, "typeID": 42703, "resPath": "Outer/JacketFBR01/Types/JacketFBR02_bloodraiders.type", "resGender": 0}
2171	15751	{"_key": 15751, "typeID": 42702, "resPath": "outer/JacketMFBR01/Types/JacketMFBR02_Bloodraiders.type", "resGender": 1}
2172	15752	{"_key": 15752, "typeID": 42701, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_bloodraiders.type", "resGender": 0}
2173	15758	{"_key": 15758, "typeID": 42700, "resPath": "TopMiddle/ShirtQF01/Types/ShirtBloodraidersF01.type", "resGender": 0}
2174	15768	{"_key": 15768, "typeID": 42699, "resPath": "hair/HeadWear_Beret_M01/Types/HeadWear_Beret_GuristasM01B.type", "resGender": 1}
2175	15772	{"_key": 15772, "typeID": 42698, "resPath": "hair/HeadWear_Beret_F01/Types/HeadWear_Beret_GuristasF01B.type", "resGender": 0}
2176	15776	{"_key": 15776, "typeID": 42906, "resPath": "Accessories/Glasses/Goggles_01/Types/goggles_01_orange.type", "resGender": 1}
2177	15787	{"_key": 15787, "typeID": 42905, "resPath": "Accessories/Glasses/Goggles_01/Types/goggles_01_orange.type", "resGender": 0}
2178	15795	{"_key": 15795, "typeID": 44122, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_C16.type", "resGender": 0}
2179	15796	{"_key": 15796, "typeID": 44125, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_C16.type", "resGender": 1}
2180	15800	{"_key": 15800, "typeID": 44121, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_C16.type", "resGender": 0}
2181	15802	{"_key": 15802, "typeID": 44123, "resPath": "topMiddle/TshirtM01/Types/TshirtM01_C16.type", "resGender": 1}
2182	15810	{"_key": 15810, "typeID": 44124, "resPath": "bottomOuter/PantsMilM01/Types/PantsMilM01_C16.type", "resGender": 1}
2183	15811	{"_key": 15811, "typeID": 44120, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_C16.type", "resGender": 0}
2184	15913	{"_key": 15913, "typeID": 45514, "resPath": "Outer/ExplorationSuit_F01/Types/ExplorationSuit_F01_SOE.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2185	15919	{"_key": 15919, "typeID": 45515, "resPath": "Outer/ExplorationSuit_F01/Types/ExplorationSuit_F01_Caldari.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2186	15921	{"_key": 15921, "typeID": 45516, "resPath": "Outer/ExplorationSuit_F01/Types/ExplorationSuit_F01_Minmatar.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2187	15924	{"_key": 15924, "typeID": 45517, "resPath": "Outer/ExplorationSuit_F01/Types/ExplorationSuit_F01_Gallente.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2188	15925	{"_key": 15925, "typeID": 45518, "resPath": "Outer/ExplorationSuit_F01/Types/ExplorationSuit_F01_Amarr.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2189	15927	{"_key": 15927, "typeID": 45519, "resPath": "Outer/ExplorationSuit_F01/Types/ExplorationSuit_F01_CaldariOrange.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2190	15929	{"_key": 15929, "typeID": 45520, "resPath": "Outer/ExplorationSuit_F01/Types/ExplorationSuit_F01_ORE.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2191	15951	{"_key": 15951, "typeID": 45521, "resPath": "outer/ExplorationSuit_M01/Types/ExplorationSuit_M01_Gallente.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2192	15952	{"_key": 15952, "typeID": 45522, "resPath": "outer/ExplorationSuit_M01/Types/ExplorationSuit_M01_ORE.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2193	15954	{"_key": 15954, "typeID": 45523, "resPath": "outer/ExplorationSuit_M01/Types/ExplorationSuit_M01_SOE.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2194	15956	{"_key": 15956, "typeID": 45524, "resPath": "outer/ExplorationSuit_M01/Types/ExplorationSuit_M01_Caldari.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2195	15957	{"_key": 15957, "typeID": 45525, "resPath": "outer/ExplorationSuit_M01/Types/ExplorationSuit_M01_Minmatar.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2196	15958	{"_key": 15958, "typeID": 45526, "resPath": "outer/ExplorationSuit_M01/Types/ExplorationSuit_M01_Amarr.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2197	15961	{"_key": 15961, "typeID": 45527, "resPath": "outer/ExplorationSuit_M01/Types/ExplorationSuit_M01_CaldariOrange.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2198	15962	{"_key": 15962, "typeID": 45734, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_Exo.type", "resGender": 0}
2199	15964	{"_key": 15964, "typeID": 45740, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_Exo.type", "resGender": 1}
2200	15968	{"_key": 15968, "typeID": 45735, "resPath": "Outer/ExplorationSuit_F01/Types/ExplorationSuit_F01_Exo.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2201	15970	{"_key": 15970, "typeID": 45741, "resPath": "outer/ExplorationSuit_M01/Types/ExplorationSuit_M01_Exo.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2202	15971	{"_key": 15971, "typeID": 45736, "resPath": "Accessories/Glasses/Glasses_Exo_F01/Types/Glasses_Exo_F01_clear.type", "resGender": 0}
2203	15972	{"_key": 15972, "typeID": 45742, "resPath": "outer/JacketMilM02/Types/JacketMilM02_exo.type", "resGender": 1}
2204	15976	{"_key": 15976, "typeID": 45737, "resPath": "Outer/LabCoatF01/Types/LabCoatF01_Exo.type", "resGender": 0}
2205	15977	{"_key": 15977, "typeID": 45743, "resPath": "TopMiddle/TshirtM01/Types/TshirtM01_Exo.type", "resGender": 1}
2206	15979	{"_key": 15979, "typeID": 45744, "resPath": "outer/LabCoatM01/Types/LabCoatM01_Exo.type", "resGender": 1}
2207	15980	{"_key": 15980, "typeID": 45738, "resPath": "Outer/JacketMilF01/Types/JacketMilF01_exo.type", "resGender": 0}
2208	15981	{"_key": 15981, "typeID": 45745, "resPath": "Accessories/Glasses/Glasses_Exo_M01/Types/Glasses_Exo_M01_clear.type", "resGender": 1}
2209	15983	{"_key": 15983, "typeID": 45739, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_Exo.type", "resGender": 0}
2210	15986	{"_key": 15986, "typeID": 46039, "resPath": "Outer/ExplorationSuit_F01/Types/ExplorationSuit_F01_IGC.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2211	15993	{"_key": 15993, "typeID": 46038, "resPath": "outer/ExplorationSuit_M01/Types/ExplorationSuit_M01_IGC.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2212	16002	{"_key": 16002, "typeID": 46274, "resPath": "outer/JacketPrtm01/Types/JacketPrtm01_valkyrie.type", "resGender": 1}
2213	16017	{"_key": 16017, "typeID": 46273, "resPath": "Outer/JacketPrtF01/Types/JacketPrtF01_valkyrie.type", "resGender": 0}
2214	16046	{"_key": 16046, "typeID": 46658, "resPath": "Outer/JacketAGF01/Types/JacketAGF01_Gallente_RW.type", "resGender": 0}
2215	16048	{"_key": 16048, "typeID": 46659, "resPath": "outer/JacketCMM01/Types/JacketCMM01_Caldari.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26}
2216	16050	{"_key": 16050, "typeID": 46660, "resPath": "Outer/JacketAGF01/Types/JacketAGF01_Gallente.type", "resGender": 0}
2217	16052	{"_key": 16052, "typeID": 46661, "resPath": "Outer/JacketCMF01/Types/JacketCMF01_Minmatar_RW.type", "resGender": 0}
2218	16053	{"_key": 16053, "typeID": 46662, "resPath": "outer/JacketAGM01/Types/JacketAGM01_Amarr.type", "resGender": 1}
2219	16056	{"_key": 16056, "typeID": 46663, "resPath": "Outer/JacketAGF01/Types/JacketAGF01_Amarr.type", "resGender": 0}
2220	16058	{"_key": 16058, "typeID": 46664, "resPath": "outer/JacketCMM01/Types/JacketCMM01_Minmatar.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26}
2221	16060	{"_key": 16060, "typeID": 46665, "resPath": "outer/JacketAGM01/Types/JacketAGM01_Gallente.type", "resGender": 1}
2222	16063	{"_key": 16063, "typeID": 46666, "resPath": "outer/JacketAGM01/Types/JacketAGM01_Amarr_RW.type", "resGender": 1}
2223	16064	{"_key": 16064, "typeID": 46667, "resPath": "outer/JacketAGM01/Types/JacketAGM01_Gallente_RW.type", "resGender": 1}
2224	16065	{"_key": 16065, "typeID": 46668, "resPath": "Outer/JacketAGF01/Types/JacketAGF01_Amarr_RW.type", "resGender": 0}
2225	16066	{"_key": 16066, "typeID": 46669, "resPath": "Outer/JacketCMF01/Types/JacketCMF01_Caldari.type", "resGender": 0}
2226	16067	{"_key": 16067, "typeID": 46674, "resPath": "outer/JacketCMM01/Types/JacketCMM01_Minmatar_RW.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26}
2227	16068	{"_key": 16068, "typeID": 46671, "resPath": "Outer/JacketCMF01/Types/JacketCMF01_Caldari_RW.type", "resGender": 0}
2228	16069	{"_key": 16069, "typeID": 46672, "resPath": "outer/JacketCMM01/Types/JacketCMM01_Caldari_RW.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26}
2229	16070	{"_key": 16070, "typeID": 46673, "resPath": "Outer/JacketCMF01/Types/JacketCMF01_Minmatar.type", "resGender": 0}
2230	16081	{"_key": 16081, "typeID": 47182, "resPath": "TopMiddle/TshirtM01/Types/TshirtM01_XV_Amarr.type", "resGender": 1}
2231	16082	{"_key": 16082, "typeID": 47189, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_XV_Caldari.type", "resGender": 0}
2232	16083	{"_key": 16083, "typeID": 47183, "resPath": "TopMiddle/TshirtM01/Types/TshirtM01_XV_Minmatar.type", "resGender": 1}
2233	16088	{"_key": 16088, "typeID": 47184, "resPath": "TopMiddle/TshirtM01/Types/TshirtM01_XV_Gallente.type", "resGender": 1}
2234	16093	{"_key": 16093, "typeID": 47185, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_XV_Gallente.type", "resGender": 0}
2235	16096	{"_key": 16096, "typeID": 47186, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_XV_Amarr.type", "resGender": 0}
2236	16097	{"_key": 16097, "typeID": 47187, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_XV_Minmatar.type", "resGender": 0}
2237	16098	{"_key": 16098, "typeID": 47188, "resPath": "TopMiddle/TshirtM01/Types/TshirtM01_XV_Caldari.type", "resGender": 1}
2238	16112	{"_key": 16112, "typeID": 47031, "resPath": "Outer/JacketSLF_01/Types/JacketSLF_01_JinMeiOpera.type", "resGender": 0}
2239	16113	{"_key": 16113, "typeID": 47032, "resPath": "outer/JacketALM01/Types/JacketALM01_JinMeiOpera.type", "resGender": 1}
2240	16116	{"_key": 16116, "typeID": 47191, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_XV_BlackOrange.type", "resGender": 1}
2241	16119	{"_key": 16119, "typeID": 47190, "resPath": "TopMiddle/TshirtM01/Types/TshirtM01_XV_StarOrange.type", "resGender": 1}
2242	16123	{"_key": 16123, "typeID": 47193, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_XV_BlackOrange.type", "resGender": 0}
2243	16128	{"_key": 16128, "typeID": 47192, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_XV_StarOrange.type", "resGender": 0}
2244	16139	{"_key": 16139, "typeID": 47287, "resPath": "Outer/ArmorSuitCF01/Types/ArmorSuitCF01_SWAT.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2245	16140	{"_key": 16140, "typeID": 47286, "resPath": "outer/ArmorSuitMM01/Types/ArmorSuitMM01_SWAT.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2246	16143	{"_key": 16143, "typeID": 47475, "resPath": "Outer/ExplorationSuit_F01/Types/ExplorationSuit_F01_XV.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2247	16146	{"_key": 16146, "typeID": 47476, "resPath": "outer/ExplorationSuit_M01/Types/ExplorationSuit_M01_XV.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2248	16149	{"_key": 16149, "typeID": 47477, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_XV_FF.type", "resGender": 0}
2249	16151	{"_key": 16151, "typeID": 47479, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_XV_FF.type", "resGender": 0}
2250	16154	{"_key": 16154, "typeID": 47478, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_XV_FF.type", "resGender": 1}
2251	16160	{"_key": 16160, "typeID": 47480, "resPath": "TopMiddle/TshirtM01/Types/TshirtM01_XV_FF.type", "resGender": 1}
2252	16165	{"_key": 16165, "typeID": 48082, "resPath": "outer/VanguardM01/Types/VanguardM01_TG.type", "resGender": 1}
2253	16169	{"_key": 16169, "typeID": 48083, "resPath": "bottomOuter/PantsEngM01/Types/PantsEngM01_silver.type", "resGender": 1}
2254	16173	{"_key": 16173, "typeID": 48081, "resPath": "Outer/VanguardF01/Types/VanguardF01_TG.type", "resGender": 0}
2255	16174	{"_key": 16174, "typeID": 48387, "resPath": "outer/VanguardM01/Types/VanguardM01_RED.type", "resGender": 1}
2256	16175	{"_key": 16175, "typeID": 48386, "resPath": "Outer/VanguardF01/Types/VanguardF01_RED.type", "resGender": 0}
2257	16176	{"_key": 16176, "typeID": 48385, "resPath": "outer/VanguardM01/Types/VanguardM01_BLUE.type", "resGender": 1}
2258	16177	{"_key": 16177, "typeID": 48384, "resPath": "outer/VanguardM01/Types/VanguardM01_GOLD.type", "resGender": 1}
2259	16178	{"_key": 16178, "typeID": 48383, "resPath": "outer/VanguardM01/Types/VanguardM01_GREEN.type", "resGender": 1}
2260	16179	{"_key": 16179, "typeID": 48382, "resPath": "Outer/VanguardF01/Types/VanguardF01_BLUE.type", "resGender": 0}
2261	16180	{"_key": 16180, "typeID": 48381, "resPath": "Outer/VanguardF01/Types/VanguardF01_GOLD.type", "resGender": 0}
2262	16181	{"_key": 16181, "typeID": 48380, "resPath": "Outer/VanguardF01/Types/VanguardF01_GREEN.type", "resGender": 0}
2263	16182	{"_key": 16182, "resPath": "TopUnderwear/TopZH/Types/topzh.type", "resGender": 1}
2264	16183	{"_key": 16183, "typeID": 54966, "resPath": "Accessories/Glasses/Glasses_Slick_01/Types/Glasses_Slick_01_clear.type", "resGender": 1}
2265	16184	{"_key": 16184, "typeID": 54965, "resPath": "Accessories/Glasses/Glasses_Slick_01/Types/Glasses_Slick_01_clear.type", "resGender": 0}
2266	16185	{"_key": 16185, "typeID": 55627, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V6_White.type", "resGender": 0}
2267	16186	{"_key": 16186, "typeID": 55636, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V7_White.type", "resGender": 1}
2268	16187	{"_key": 16187, "typeID": 55751, "resPath": "hair/HeadWear_Beret_F01/Types/HeadWear_Beret_AmarrFoundationF01.type", "resGender": 0}
2269	16188	{"_key": 16188, "typeID": 55752, "resPath": "hair/HeadWear_Beret_F01/Types/HeadWear_Beret_CaldariUnionF01.type", "resGender": 0}
2270	16189	{"_key": 16189, "typeID": 55753, "resPath": "hair/HeadWear_Beret_F01/Types/HeadWear_Beret_GallenteFederationF01.type", "resGender": 0}
2271	16190	{"_key": 16190, "typeID": 55754, "resPath": "hair/HeadWear_Beret_F01/Types/HeadWear_Beret_MinmatarLiberationF01.type", "resGender": 0}
2272	16191	{"_key": 16191, "typeID": 55755, "resPath": "hair/HeadWear_Beret_M01/Types/HeadWear_Beret_AmarrFoundationM01.type", "resGender": 1}
2273	16192	{"_key": 16192, "typeID": 55756, "resPath": "hair/HeadWear_Beret_M01/Types/HeadWear_Beret_CaldariUnionM01.type", "resGender": 1}
2274	16193	{"_key": 16193, "typeID": 55757, "resPath": "hair/HeadWear_Beret_M01/Types/HeadWear_Beret_GallenteFederationM01.type", "resGender": 1}
2275	16194	{"_key": 16194, "typeID": 55758, "resPath": "hair/HeadWear_Beret_M01/Types/HeadWear_Beret_MinmatarLiberationM01.type", "resGender": 1}
2276	16195	{"_key": 16195, "typeID": 55855, "resPath": "Outer/VanguardF01/Types/VanguardF01_TG_PVP_Arena.type", "resGender": 0}
2277	16196	{"_key": 16196, "typeID": 55856, "resPath": "Outer/ArmorSuitCF01/Types/ArmorSuitCF01_TG_PVP_Arena.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2278	16197	{"_key": 16197, "typeID": 55857, "resPath": "outer/ArmorSuitMM01/Types/ArmorSuitMM01_TG_PVP_Arena.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2279	16198	{"_key": 16198, "typeID": 55858, "resPath": "outer/VanguardM01/Types/VanguardM01_TG_PVP_Arena.type", "resGender": 1}
2280	16199	{"_key": 16199, "typeID": 56144, "resPath": "hair/HeadWear_Beret_F01/Types/HeadWear_Beret_EdencomF01.type", "resGender": 0}
2281	16200	{"_key": 16200, "typeID": 56145, "resPath": "hair/HeadWear_Beret_M01/Types/HeadWear_Beret_EdencomM01.type", "resGender": 1}
2282	16201	{"_key": 16201, "typeID": 56146, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_Edencom.type", "resGender": 0}
2283	16202	{"_key": 16202, "typeID": 56147, "resPath": "topMiddle/TshirtM01/Types/TshirtM01_Edencom.type", "resGender": 1}
2284	16203	{"_key": 16203, "typeID": 56209, "resPath": "hair/HeadWear_Beret_F01/Types/HeadWear_Beret_TriglavianF01.type", "resGender": 0}
2285	16204	{"_key": 16204, "typeID": 56210, "resPath": "hair/HeadWear_Beret_M01/Types/HeadWear_Beret_TriglavianM01.type", "resGender": 1}
2286	16205	{"_key": 16205, "typeID": 56211, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_Triglavian.type", "resGender": 0}
2287	16206	{"_key": 16206, "typeID": 56212, "resPath": "topMiddle/TshirtM01/Types/TshirtM01_Triglavian.type", "resGender": 1}
2288	16207	{"_key": 16207, "typeID": 56223, "resPath": "Outer/JacketCMF01/Types/JacketCMF01_Edencom.type", "resGender": 0}
2289	16208	{"_key": 16208, "typeID": 56224, "resPath": "outer/JacketCMM01/Types/JacketCMM01_Edencom.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26}
2290	16209	{"_key": 16209, "typeID": 56225, "resPath": "Outer/VanguardF01/Types/VanguardF01_TG_LP.type", "resGender": 0}
2291	16210	{"_key": 16210, "typeID": 56226, "resPath": "outer/VanguardM01/Types/VanguardM01_TG_LP.type", "resGender": 1}
2292	16211	{"_key": 16211, "typeID": 56264, "resPath": "Outer/ArmorSuitCF01/Types/ArmorSuitCF01_TG_LP.type", "resGender": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2293	16212	{"_key": 16212, "typeID": 56265, "resPath": "Outer/ArmorSuitCF01/Types/ArmorSuitCF01_Edencom.type", "resGender": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2294	16213	{"_key": 16213, "typeID": 56266, "resPath": "outer/ArmorSuitMM01/Types/ArmorSuitMM01_TG_LP.type", "resGender": 1, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2295	16214	{"_key": 16214, "typeID": 56267, "resPath": "outer/ArmorSuitMM01/Types/ArmorSuitMM01_Edencom.type", "resGender": 1, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2296	16215	{"_key": 16215, "typeID": 56634, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_BR_CrimonHarvest.type", "resGender": 0}
2297	16216	{"_key": 16216, "typeID": 56635, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_BR_CrimsonHarvest.type", "resGender": 0}
2298	16217	{"_key": 16217, "typeID": 56636, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_BR_CrimsonHarvest.type", "resGender": 0}
2299	16218	{"_key": 16218, "typeID": 56637, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_BR_CrimsonHarvest.type", "resGender": 1}
2300	16219	{"_key": 16219, "typeID": 56638, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_BR_CrimsonHarvest.type", "resGender": 1}
2301	16220	{"_key": 16220, "typeID": 56639, "resPath": "topMiddle/TshirtM01/Types/TshirtM01_BR_CrimsonHarvest.type", "resGender": 1}
2302	16221	{"_key": 16221, "typeID": 56844, "resPath": "Feet/ShoesEngF01/Types/ShoesEngF01_Jita.type", "resGender": 0}
2303	16222	{"_key": 16222, "typeID": 56845, "resPath": "TopMiddle/ShirtEngF01/Types/ShirtEngF01_Jita.type", "resGender": 0}
2304	16223	{"_key": 16223, "typeID": 56846, "resPath": "bottomOuter/PantsEngF01/Types/PantsEngF01_Jita.type", "resGender": 0}
2305	16224	{"_key": 16224, "typeID": 56847, "resPath": "Feet/ShoesEngM01/Types/ShoesEngM01_jita.type", "resGender": 1}
2306	16225	{"_key": 16225, "typeID": 56848, "resPath": "topMiddle/ShirtEngM01/Types/ShirtEngM01_jita.type", "resGender": 1}
2307	16226	{"_key": 16226, "typeID": 56849, "resPath": "bottomOuter/PantsEngM01/Types/PantsEngM01_jita.type", "resGender": 1}
2308	16227	{"_key": 16227, "typeID": 56850, "resPath": "bottomOuter/PantsCorpBusinessM01/Types/PantsCorpBusinessM01_Jita.type", "resGender": 1}
2309	16228	{"_key": 16228, "typeID": 56851, "resPath": "outer/JacketCorpBusinessM01/Types/JacketCorpBusinessM01_Jita_Tie.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2}
2310	16229	{"_key": 16229, "typeID": 56852, "resPath": "Outer/JacketCorpBusinessF01/Types/JacketCorpBusinessF01_Jita_Tie.type", "resGender": 0}
2311	16230	{"_key": 16230, "typeID": 56853, "resPath": "bottomOuter/PantsCorpBusinessF01/Types/PantsCorpBusinessF01_Jita.type", "resGender": 0}
2312	16231	{"_key": 16231, "typeID": 56854, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V33_Japan.type", "resGender": 0}
2313	16232	{"_key": 16232, "typeID": 56855, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V34_Japan.type", "resGender": 1}
2314	16233	{"_key": 16233, "typeID": 56856, "resPath": "outer/ExplorationSuit_M01/Types/ExplorationSuit_M01_Japan.type", "resGender": 1}
2315	16234	{"_key": 16234, "typeID": 56857, "resPath": "Outer/ExplorationSuit_F01/Types/ExplorationSuit_F01_Japan.type", "resGender": 0}
2316	16235	{"_key": 16235, "typeID": 57073, "resPath": "topMiddle/TshirtM01/Types/TshirtM01_Yoiul.type", "resGender": 1}
2317	16236	{"_key": 16236, "typeID": 57074, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_Yoiul.type", "resGender": 1}
2318	16237	{"_key": 16237, "typeID": 57075, "resPath": "bottomOuter/PantsMilM01/Types/PantsMilM01_Yoiul.type", "resGender": 1}
2319	16238	{"_key": 16238, "typeID": 57076, "resPath": "outer/ExplorationSuit_M01/Types/ExplorationSuit_M01_Yoiul.type", "resGender": 1, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2320	16239	{"_key": 16239, "typeID": 57077, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_Yoiul.type", "resGender": 0}
2321	16240	{"_key": 16240, "typeID": 57078, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_Yoiul.type", "resGender": 0}
2322	16241	{"_key": 16241, "typeID": 57079, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_Yoiul.type", "resGender": 0}
2323	16242	{"_key": 16242, "typeID": 57080, "resPath": "Outer/ExplorationSuit_F01/Types/ExplorationSuit_F01_Yoiul.type", "resGender": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2324	16275	{"_key": 16275, "typeID": -1, "resPath": "TopOuter/BodySuitAU/Types/BodySuit_AU.type", "resGender": 0}
2325	16276	{"_key": 16276, "typeID": -1, "resPath": "outer/DrapeAU/Types/Drape_AU.type", "resGender": 0}
2326	16277	{"_key": 16277, "typeID": -1, "resPath": "Makeup/Eyes/Eyes_AU/Types/Eyes_AU.type", "resGender": 0}
2327	16278	{"_key": 16278, "typeID": -1, "resPath": "hair/Aura_HP/Types/Aura_HP.type", "resGender": 0}
2328	16279	{"_key": 16279, "typeID": -1, "resPath": "Skintype/AU/Types/skintype_f_aura.type", "resGender": 0}
2329	16280	{"_key": 16280, "typeID": 58757, "resPath": "topMiddle/TshirtM01/Types/TshirtM01_XVIII.type", "resGender": 1}
2330	16281	{"_key": 16281, "typeID": 58767, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_XVIII.type", "resGender": 1}
2331	16282	{"_key": 16282, "typeID": 58768, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_XVIII.type", "resGender": 0}
2332	16283	{"_key": 16283, "typeID": 58769, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_XVIII.type", "resGender": 0}
2333	16284	{"_key": 16284, "typeID": 58785, "resPath": "bottomOuter/PantsEngF01/Types/PantsEngF01_amarr.type", "resGender": 0}
2334	16285	{"_key": 16285, "typeID": 58786, "resPath": "bottomOuter/PantsEngF01/Types/PantsEngF01_caldari.type", "resGender": 0}
2335	16286	{"_key": 16286, "typeID": 58787, "resPath": "bottomOuter/PantsEngF01/Types/PantsEngF01_gallente.type", "resGender": 0}
2336	16287	{"_key": 16287, "typeID": 58788, "resPath": "bottomOuter/PantsEngF01/Types/PantsEngF01_minmatar.type", "resGender": 0}
2337	16288	{"_key": 16288, "typeID": 58791, "resPath": "bottomOuter/PantsEngM01/Types/PantsEngM01_amarr.type", "resGender": 1}
2338	16289	{"_key": 16289, "typeID": 58792, "resPath": "bottomOuter/PantsEngM01/Types/PantsEngM01_caldari.type", "resGender": 1}
2339	16290	{"_key": 16290, "typeID": 58793, "resPath": "bottomOuter/PantsEngM01/Types/PantsEngM01_gallente.type", "resGender": 1}
2340	16291	{"_key": 16291, "typeID": 58794, "resPath": "bottomOuter/PantsEngM01/Types/PantsEngM01_minmatar.type", "resGender": 1}
2341	16292	{"_key": 16292, "typeID": 58809, "resPath": "TopMiddle/ShirtEngF01/Types/ShirtEngF01_amarr.type", "resGender": 0}
2342	16293	{"_key": 16293, "typeID": 58810, "resPath": "TopMiddle/ShirtEngF01/Types/ShirtEngF01_caldari.type", "resGender": 0}
2343	16294	{"_key": 16294, "typeID": 58811, "resPath": "TopMiddle/ShirtEngF01/Types/ShirtEngF01_gallente.type", "resGender": 0}
2344	16295	{"_key": 16295, "typeID": 58812, "resPath": "TopMiddle/ShirtEngF01/Types/ShirtEngF01_minmatar.type", "resGender": 0}
2345	16296	{"_key": 16296, "typeID": 58813, "resPath": "topMiddle/ShirtEngM01/Types/ShirtEngM01_amarr.type", "resGender": 1}
2346	16297	{"_key": 16297, "typeID": 58814, "resPath": "topMiddle/ShirtEngM01/Types/ShirtEngM01_caldari.type", "resGender": 1}
2347	16298	{"_key": 16298, "typeID": 58815, "resPath": "topMiddle/ShirtEngM01/Types/ShirtEngM01_gallente.type", "resGender": 1}
2348	16299	{"_key": 16299, "typeID": 58816, "resPath": "topMiddle/ShirtEngM01/Types/ShirtEngM01_minmatar.type", "resGender": 1}
2349	16300	{"_key": 16300, "typeID": 58817, "resPath": "Feet/ShoesEngF01/Types/ShoesEngF01_amarr.type", "resGender": 0}
2350	16301	{"_key": 16301, "typeID": 58818, "resPath": "Feet/ShoesEngF01/Types/ShoesEngF01_caldari.type", "resGender": 0}
2351	16302	{"_key": 16302, "typeID": 58819, "resPath": "Feet/ShoesEngF01/Types/ShoesEngF01_gallente.type", "resGender": 0}
2352	16303	{"_key": 16303, "typeID": 58820, "resPath": "Feet/ShoesEngF01/Types/ShoesEngF01_minmatar.type", "resGender": 0}
2353	16304	{"_key": 16304, "typeID": 58821, "resPath": "Feet/ShoesEngF01/Types/ShoesEngF01_redblack.type", "resGender": 0}
2354	16305	{"_key": 16305, "typeID": 58825, "resPath": "Feet/ShoesEngM01/Types/ShoesEngM01_amarr.type", "resGender": 1}
2355	16306	{"_key": 16306, "typeID": 58826, "resPath": "Feet/ShoesEngM01/Types/ShoesEngM01_caldari.type", "resGender": 1}
2356	16307	{"_key": 16307, "typeID": 58827, "resPath": "Feet/ShoesEngM01/Types/ShoesEngM01_gallente.type", "resGender": 1}
2357	16308	{"_key": 16308, "typeID": 58828, "resPath": "Feet/ShoesEngM01/Types/ShoesEngM01_minmatar.type", "resGender": 1}
2358	16309	{"_key": 16309, "typeID": 58829, "resPath": "Feet/ShoesEngM01/Types/ShoesEngM01_redblack.type", "resGender": 1}
2359	16310	{"_key": 16310, "typeID": 58933, "resPath": "outer/JacketFormalMilM01/Types/JacketFormalMilM01_BlueCal.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26}
2360	16311	{"_key": 16311, "typeID": 58934, "resPath": "outer/JacketFormalMilM01/Types/JacketFormalMilM01_BrownAmarr.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26}
2361	16312	{"_key": 16312, "typeID": 58935, "resPath": "outer/JacketFormalMilM01/Types/JacketFormalMilM01_GreenGallente.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26}
2362	16313	{"_key": 16313, "typeID": 58936, "resPath": "outer/JacketFormalMilM01/Types/JacketFormalMilM01_BrownMinmatar.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26}
2363	16314	{"_key": 16314, "typeID": 58941, "resPath": "Outer/JacketFormalMilF01/Types/JacketFormalMilF01_Caldari.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26}
2364	16315	{"_key": 16315, "typeID": 58942, "resPath": "Outer/JacketFormalMilF01/Types/JacketFormalMilF01_Amarr.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26}
2365	16316	{"_key": 16316, "typeID": 58943, "resPath": "Outer/JacketFormalMilF01/Types/JacketFormalMilF01_Gallente.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26}
2366	16317	{"_key": 16317, "typeID": 58944, "resPath": "Outer/JacketFormalMilF01/Types/JacketFormalMilF01_Minmatar.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26}
2367	16318	{"_key": 16318, "typeID": 58946, "resPath": "bottomOuter/PantsCorpBusinessF01/Types/PantsCorpBusinessF01_CaldariMil.type", "resGender": 0}
2368	16319	{"_key": 16319, "typeID": 58947, "resPath": "bottomOuter/PantsCorpBusinessF01/Types/PantsCorpBusinessF01_AmarrMil.type", "resGender": 0}
2369	16320	{"_key": 16320, "typeID": 58948, "resPath": "bottomOuter/PantsCorpBusinessF01/Types/PantsCorpBusinessF01_GallenteMil.type", "resGender": 0}
2370	16321	{"_key": 16321, "typeID": 58949, "resPath": "bottomOuter/PantsCorpBusinessF01/Types/PantsCorpBusinessF01_MinmatarMil.type", "resGender": 0}
2371	16322	{"_key": 16322, "typeID": 58951, "resPath": "bottomOuter/PantsCorpBusinessM01/Types/PantsCorpBusinessM01_BlueCalMil.type", "resGender": 1}
2372	16323	{"_key": 16323, "typeID": 58952, "resPath": "bottomOuter/PantsCorpBusinessM01/Types/PantsCorpBusinessM01_BrownAmarrMil.type", "resGender": 1}
2373	16324	{"_key": 16324, "typeID": 58953, "resPath": "bottomOuter/PantsCorpBusinessM01/Types/PantsCorpBusinessM01_GreenGallenteMil.type", "resGender": 1}
2374	16325	{"_key": 16325, "typeID": 58954, "resPath": "bottomOuter/PantsCorpBusinessM01/Types/PantsCorpBusinessM01_BrownMinmatarMil.type", "resGender": 1}
2375	16326	{"_key": 16326, "typeID": 59178, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_MinmatarLiberation.type", "resGender": 1}
2376	16327	{"_key": 16327, "typeID": 59179, "resPath": "bottomOuter/PantsMilM01/Types/PantsMilM01_MinmatarLiberation.type", "resGender": 1}
2377	16328	{"_key": 16328, "typeID": 59180, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_MinmatarLiberation.type", "resGender": 0}
2378	16329	{"_key": 16329, "typeID": 59181, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_MinmatarLiberation.type", "resGender": 0}
2379	16330	{"_key": 16330, "typeID": 59185, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_GallenteFederation.type", "resGender": 1}
2380	16332	{"_key": 16332, "typeID": 59187, "resPath": "bottomOuter/PantsMilM01/Types/PantsMilM01_GallenteFederation.type", "resGender": 1}
2381	16333	{"_key": 16333, "typeID": 59196, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_GallenteFederation.type", "resGender": 0}
2382	16334	{"_key": 16334, "typeID": 59198, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_GallenteFederation.type", "resGender": 0}
2383	16335	{"_key": 16335, "typeID": 59199, "resPath": "Tattoo/Head/TattooElabM_LD_01/Types/TattooElabM_LD_01.type", "resGender": 1}
2384	16336	{"_key": 16336, "typeID": 59200, "resPath": "Tattoo/Head/TattooElabM_LD_01/Types/TattooElabM_LD_01.type", "resGender": 0}
2385	16337	{"_key": 16337, "typeID": 59201, "resPath": "Tattoo/Head/TattooElabM_LD_02/Types/TattooElabM_LD_02.type", "resGender": 1}
2386	16338	{"_key": 16338, "typeID": 59202, "resPath": "Tattoo/Head/TattooElabM_LD_02/Types/TattooElabM_LD_02.type", "resGender": 0}
2387	16339	{"_key": 16339, "typeID": 59221, "resPath": "Tattoo/Head/TattooElabM_LD_03/Types/TattooElabM_LD_03.type", "resGender": 1}
2388	16340	{"_key": 16340, "typeID": 59223, "resPath": "Tattoo/Head/TattooElabM_LD_03/Types/TattooElabM_LD_03.type", "resGender": 0}
2389	16341	{"_key": 16341, "typeID": 59226, "resPath": "Tattoo/Head/TattooElabM_LD_04/Types/TattooElabM_LD_04.type", "resGender": 1}
2390	16342	{"_key": 16342, "typeID": 59227, "resPath": "Tattoo/Head/TattooElabM_LD_04/Types/TattooElabM_LD_04.type", "resGender": 0}
2391	16343	{"_key": 16343, "typeID": 59228, "resPath": "Tattoo/Head/TattooElabM_LD_05/Types/TattooElabM_LD_05.type", "resGender": 1}
2392	16344	{"_key": 16344, "typeID": 59229, "resPath": "Tattoo/Head/TattooElabM_LD_05/Types/TattooElabM_LD_05.type", "resGender": 0}
2393	16345	{"_key": 16345, "typeID": 59230, "resPath": "Tattoo/Head/TattooElabM_LD_06/Types/TattooElabM_LD_06.type", "resGender": 1}
2394	16346	{"_key": 16346, "typeID": 59231, "resPath": "Tattoo/Head/TattooElabM_LD_06/Types/TattooElabM_LD_06.type", "resGender": 0}
2395	16347	{"_key": 16347, "typeID": 59232, "resPath": "Tattoo/Head/TattooElabM_LD_07/Types/TattooElabM_LD_07.type", "resGender": 1}
2396	16348	{"_key": 16348, "typeID": 59233, "resPath": "Tattoo/Head/TattooElabM_LD_07/Types/TattooElabM_LD_07.type", "resGender": 0}
2397	16349	{"_key": 16349, "typeID": 59366, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_AmarrFoundation.type", "resGender": 1}
2398	16350	{"_key": 16350, "typeID": 59367, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_AmarrFoundation.type", "resGender": 0}
2399	16351	{"_key": 16351, "typeID": 59368, "resPath": "bottomOuter/PantsMilM01/Types/PantsMilM01_AmarrFoundation.type", "resGender": 1}
2400	16352	{"_key": 16352, "typeID": 59370, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_AmarrFoundation.type", "resGender": 0}
2401	16353	{"_key": 16353, "typeID": 59405, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_CaldariUnion.type", "resGender": 1}
2402	16354	{"_key": 16354, "typeID": 59406, "resPath": "bottomOuter/PantsMilM01/Types/PantsMilM01_CaldariUnion.type", "resGender": 1}
2403	16355	{"_key": 16355, "typeID": 59407, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_CaldariUnion.type", "resGender": 0}
2404	16356	{"_key": 16356, "typeID": 59408, "resPath": "bottomOuter/PantsMilF01/Types/PantsMilF01_CaldariUnion.type", "resGender": 0}
2405	16365	{"_key": 16365, "typeID": 60160, "resPath": "Accessories/Glasses/EyeImp01/Types/EyeImpM01_Right_Ep.type", "resGender": 1}
2406	16366	{"_key": 16366, "typeID": 60161, "resPath": "bottomOuter/PantsEngM01/Types/PantsEngM01_Ep.type", "resGender": 1}
2407	16367	{"_key": 16367, "typeID": 60162, "resPath": "Feet/ShoesEngM01/Types/ShoesEngM01_Ep.type", "resGender": 1}
2408	16368	{"_key": 16368, "typeID": 60163, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V7_Ep.type", "resGender": 1}
2409	16369	{"_key": 16369, "typeID": 60164, "resPath": "Makeup/BodyAugmentations/BodyAugmentation_M01/Types/BodyAugmentationM01_Ep.type", "resGender": 1, "clothingAlsoCoversCategory": 10, "clothingAlsoCoversCategory2": 10}
2410	16370	{"_key": 16370, "typeID": 60165, "resPath": "Accessories/Glasses/Monocle_01/Types/MonocleM01_Right_Ep.type", "resGender": 1}
2411	16371	{"_key": 16371, "typeID": 60166, "resPath": "Accessories/Glasses/EyeImp01/Types/EyeImpF01_Right_Ep.type", "resGender": 0}
2412	16372	{"_key": 16372, "typeID": 60167, "resPath": "bottomOuter/PantsEngF01/Types/PantsEngF01_Ep.type", "resGender": 0}
2413	16373	{"_key": 16373, "typeID": 60168, "resPath": "Feet/ShoesEngF01/Types/ShoesEngF01_Ep.type", "resGender": 0}
2414	16374	{"_key": 16374, "typeID": 60169, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_Ep.type", "resGender": 0}
2415	16375	{"_key": 16375, "typeID": 60170, "resPath": "Makeup/BodyAugmentations/BodyAugmentation_F01/Types/BodyAugmentationF01_Ep.type", "resGender": 0, "clothingAlsoCoversCategory": 10, "clothingAlsoCoversCategory2": 10}
2416	16376	{"_key": 16376, "typeID": 60171, "resPath": "Accessories/Glasses/Monocle_01/Types/MonocleF01_Right_EP.type", "resGender": 0}
2417	16377	{"_key": 16377, "typeID": -1, "resPath": "outer/JacketMilM02/Types/JacketMilM02_AIR.type", "resGender": 1}
2418	16378	{"_key": 16378, "typeID": -1, "resPath": "Outer/JacketSLF_01/Types/JacketSLF_01_air.type", "resGender": 0}
2419	16388	{"_key": 16388, "typeID": 60432, "resPath": "bottomOuter/PantsPrtm01/Types/PantsPrtm01_redblack.type", "resGender": 1}
2420	16390	{"_key": 16390, "typeID": 60434, "resPath": "bottomOuter/PantsPrtF01/Types/PantsPrtF01_redblack.type", "resGender": 0}
2421	16391	{"_key": 16391, "typeID": 60435, "resPath": "topMiddle/TshirtM01/Types/TshirtM01_BR_CH.type", "resGender": 1}
2422	16392	{"_key": 16392, "typeID": 60436, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_BR_CH.type", "resGender": 0}
2423	16408	{"_key": 16408, "typeID": 60639, "resPath": "Accessories/Glasses/Goggles_01/Types/goggles_01_min.type", "resGender": 1}
2424	16414	{"_key": 16414, "typeID": 60645, "resPath": "Accessories/Glasses/Goggles_01/Types/goggles_01_min.type", "resGender": 0}
2425	16416	{"_key": 16416, "typeID": 60647, "resPath": "outer/ExplorationSuit_M01/Types/ExplorationSuit_M01_Min.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2426	16424	{"_key": 16424, "typeID": 60655, "resPath": "Outer/ExplorationSuit_F01/Types/ExplorationSuit_F01_Min.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2427	16425	{"_key": 16425, "typeID": 61532, "resPath": "TopMiddle/ShirtQF01/Types/shirtqf01_drw.type", "resGender": 0}
2428	16426	{"_key": 16426, "typeID": 61533, "resPath": "topMiddle/ShirtQM01/Types/shirtqm01_drw.type", "resGender": 1}
2429	16428	{"_key": 16428, "typeID": 61535, "resPath": "Outer/ScarfF01/Types/ScarfF01_drw.type", "resGender": 0, "clothingRuleException": 1, "clothingRemovesCategory": 2}
2430	16429	{"_key": 16429, "typeID": 61536, "resPath": "outer/ScarfM01/Types/ScarfM01_drw.type", "resGender": 1, "clothingRuleException": 1, "clothingRemovesCategory": 2}
2431	16431	{"_key": 16431, "typeID": 61848, "resPath": "Outer/OutfitDW_F01/Types/OutfitDW_F01.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2432	16437	{"_key": 16437, "typeID": 61949, "resPath": "outer/OutfitDW_M01/Types/OutfitDW_M01.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2433	16438	{"_key": 16438, "typeID": 62750, "resPath": "outer/ExplorationSuit_M01/Types/ExplorationSuit_M01_AIR.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2434	16439	{"_key": 16439, "typeID": 63051, "resPath": "outer/JacketCMM01/Types/JacketCMM01_ep.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26}
2435	16440	{"_key": 16440, "typeID": 63052, "resPath": "Outer/JacketCMF01/Types/JacketCMF01_ep.type", "resGender": 0}
2436	16442	{"_key": 16442, "typeID": 63054, "resPath": "bottomOuter/PantsPrtm01/Types/PantsPrtm01_ep.type", "resGender": 1}
2437	16443	{"_key": 16443, "typeID": 63055, "resPath": "bottomOuter/PantsPrtF01/Types/PantsPrtF01_ep.type", "resGender": 0}
2438	16444	{"_key": 16444, "typeID": 63056, "resPath": "Outer/ExplorationSuit_F01/Types/ExplorationSuit_F01_Air.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2439	16446	{"_key": 16446, "typeID": 63058, "resPath": "Accessories/Glasses/Glasses_Slick_01/Types/Glasses_Slick_01_Ep.type", "resGender": 1}
2440	16449	{"_key": 16449, "typeID": 63061, "resPath": "Accessories/Glasses/Glasses_Slick_01/Types/Glasses_Slick_01_Ep.type", "resGender": 0}
2441	16450	{"_key": 16450, "typeID": 63112, "resPath": "outer/JacketPrtm01/Types/JacketPrtm01_guristashunt_b.type", "resGender": 1}
2442	16451	{"_key": 16451, "typeID": 63113, "resPath": "Feet/BootsPrtm01/Types/BootsPrtm01_guristashunt_b.type", "resGender": 1}
2443	16452	{"_key": 16452, "typeID": 63114, "resPath": "bottomOuter/PantsPrtm01/Types/PantsPrtm01_guristashunt_b.type", "resGender": 1}
2444	16453	{"_key": 16453, "typeID": 63115, "resPath": "Outer/JacketPrtF01/Types/JacketPrtF01_guristashunt_b.type", "resGender": 0}
2445	16461	{"_key": 16461, "typeID": 63123, "resPath": "Feet/BootsPrtF01/Types/BootsPrtF01_guristashunt_b.type", "resGender": 0}
2446	16462	{"_key": 16462, "typeID": 63124, "resPath": "bottomOuter/PantsPrtF01/Types/PantsPrtF01_guristashunt_b.type", "resGender": 0}
2447	16467	{"_key": 16467, "typeID": 63135, "resPath": "Accessories/Masks/Mask_Cyberpunk_M01/Types/Mask_Cyberpunk_M01.type", "resGender": 1}
2448	16470	{"_key": 16470, "typeID": 63138, "resPath": "Accessories/Masks/Mask_Cyberpunk_F01/Types/Mask_Cyberpunk_F01.type", "resGender": 0}
2449	16474	{"_key": 16474, "typeID": 63246, "resPath": "outer/Hoodie_M01/Types/Hoodie_M01_XIX.type", "resGender": 1, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26, "clothingAlsoCoversCategory": 2, "clothingAlsoCoversCategory2": 26}
2450	16481	{"_key": 16481, "typeID": 63253, "resPath": "outer/Hoodie_M01/Types/Hoodie_M01_XIX_HQ.type", "resGender": 1, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26, "clothingAlsoCoversCategory": 2, "clothingAlsoCoversCategory2": 26}
2451	16485	{"_key": 16485, "typeID": 63257, "resPath": "Outer/Hoodie_F01/Types/Hoodie_F01_XIX.type", "resGender": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26, "clothingAlsoCoversCategory": 2, "clothingAlsoCoversCategory2": 26}
2452	16488	{"_key": 16488, "typeID": 63260, "resPath": "Outer/Hoodie_F01/Types/Hoodie_F01_XIX_HQ.type", "resGender": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26, "clothingAlsoCoversCategory": 2, "clothingAlsoCoversCategory2": 26}
2453	16489	{"_key": 16489, "typeID": 63747, "resPath": "outer/JacketFormalMilM01/Types/JacketFormalMilM01_Caldari_FF.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26}
2454	16490	{"_key": 16490, "typeID": 63748, "resPath": "bottomOuter/PantsCorpBusinessM01/Types/PantsCorpBusinessM01_BlackFF.type", "resGender": 1}
2455	16491	{"_key": 16491, "typeID": 63749, "resPath": "Outer/JacketFormalMilF01/Types/JacketFormalMilF01_Caldari_FF.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 26}
2456	16492	{"_key": 16492, "typeID": 63750, "resPath": "bottomOuter/PantsCorpBusinessF01/Types/PantsCorpBusinessF01_BlackFF.type", "resGender": 0}
2457	16493	{"_key": 16493, "typeID": 63789, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_Race.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
2458	16494	{"_key": 16494, "typeID": 63790, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_race.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
2459	16501	{"_key": 16501, "typeID": 64195, "resPath": "Outer/JacketFBR01/Types/JacketFBR01_race_hq.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
2460	16502	{"_key": 16502, "typeID": 64196, "resPath": "outer/JacketMFBR01/Types/JacketMFBR01_Race_HQ.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 0, "clothingAlsoCoversCategory2": 0}
2461	16507	{"_key": 16507, "typeID": 64201, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_Lib_HQ.type", "resGender": 1}
2462	16508	{"_key": 16508, "typeID": 64202, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_Lib_HQ.type", "resGender": 0}
2463	16509	{"_key": 16509, "typeID": 64203, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_Lib_HQ.type", "resGender": 0}
2464	16510	{"_key": 16510, "typeID": 64204, "resPath": "topMiddle/TshirtM01/Types/TshirtM01_Lib_HQ.type", "resGender": 1}
2465	16511	{"_key": 16511, "typeID": 64268, "resPath": "topMiddle/TshirtM01/Types/TshirtM01_Lib.type", "resGender": 1}
2466	16512	{"_key": 16512, "typeID": 64269, "resPath": "TopMiddle/TshirtF01/Types/TshirtF01_Lib.type", "resGender": 0}
2467	16513	{"_key": 16513, "typeID": 64270, "resPath": "hair/HeadWear_Cap_M01/Types/HeadWear_Cap_M01_Lib.type", "resGender": 1}
2468	16514	{"_key": 16514, "typeID": 64271, "resPath": "hair/HeadWear_Cap_F01/Types/HeadWear_Cap_F01_Lib.type", "resGender": 0}
2469	16515	{"_key": 16515, "typeID": 64377, "resPath": "Outer/RobeF01/Types/RobeAF01_AmarrFoundation.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingAlsoCoversCategory": 26, "clothingAlsoCoversCategory2": 2}
2470	16516	{"_key": 16516, "typeID": 64378, "resPath": "Outer/RobeF01/Types/RobeAF01_AmarrFoundation_HQ.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 2, "clothingAlsoCoversCategory": 26, "clothingAlsoCoversCategory2": 2}
2471	16517	{"_key": 16517, "typeID": 64379, "resPath": "outer/RobeAM01/Types/RobeAM01_AmarrFoundation.type", "resGender": 1}
2472	16518	{"_key": 16518, "typeID": 64380, "resPath": "outer/RobeAM01/Types/RobeAM01_AmarrFoundation_HQ.type", "resGender": 1}
2473	16519	{"_key": 16519, "typeID": 70838, "resPath": "outer/JacketCM01_R/Types/JacketCM01_R_Commerce.type", "resGender": 1}
2474	16520	{"_key": 16520, "typeID": 70839, "resPath": "outer/JacketCM01_R/Types/JacketCM01_R_Ishukone.type", "resGender": 1}
2475	16521	{"_key": 16521, "typeID": 70840, "resPath": "outer/JacketCM01_R/Types/JacketCM01_R_CBD.type", "resGender": 1}
2476	16522	{"_key": 16522, "typeID": 70841, "resPath": "outer/JacketCM01_R/Types/JacketCM01_R_Hyasyoda.type", "resGender": 1}
2477	16523	{"_key": 16523, "typeID": 70842, "resPath": "outer/JacketCM01_R/Types/JacketCM01_R_Kaalakiota.type", "resGender": 1}
2478	16524	{"_key": 16524, "typeID": 70843, "resPath": "outer/JacketCM01_R/Types/JacketCM01_R_Wiyrkomi.type", "resGender": 1}
2479	16525	{"_key": 16525, "typeID": 70844, "resPath": "outer/JacketCM01_R/Types/JacketCM01_R_LaiDai.type", "resGender": 1}
2480	16526	{"_key": 16526, "typeID": 70845, "resPath": "outer/JacketCM01_R/Types/JacketCM01_R_Sukuuvestaa.type", "resGender": 1}
2481	16527	{"_key": 16527, "typeID": 70846, "resPath": "outer/JacketCM01_R/Types/JacketCM01_R_Nugoeihuvi.type", "resGender": 1}
2482	16528	{"_key": 16528, "typeID": 70847, "resPath": "Outer/JacketCF01_R/Types/JacketCF01_R_Commerce.type", "resGender": 0}
2483	16529	{"_key": 16529, "typeID": 70848, "resPath": "Outer/JacketCF01_R/Types/JacketCF01_R_Ishukone.type", "resGender": 0}
2484	16530	{"_key": 16530, "typeID": 70849, "resPath": "Outer/JacketCF01_R/Types/JacketCF01_R_CBD.type", "resGender": 0}
2485	16531	{"_key": 16531, "typeID": 70850, "resPath": "Outer/JacketCF01_R/Types/JacketCF01_R_Hyasyoda.type", "resGender": 0}
2486	16532	{"_key": 16532, "typeID": 70851, "resPath": "Outer/JacketCF01_R/Types/JacketCF01_R_Kaalakiota.type", "resGender": 0}
2487	16533	{"_key": 16533, "typeID": 70852, "resPath": "Outer/JacketCF01_R/Types/JacketCF01_R_Wiyrkomi.type", "resGender": 0}
2488	16534	{"_key": 16534, "typeID": 70853, "resPath": "Outer/JacketCF01_R/Types/JacketCF01_R_LaiDai.type", "resGender": 0}
2489	16535	{"_key": 16535, "typeID": 70854, "resPath": "Outer/JacketCF01_R/Types/JacketCF01_R_Sukuuvestaa.type", "resGender": 0}
2490	16536	{"_key": 16536, "typeID": 70855, "resPath": "Outer/JacketCF01_R/Types/JacketCF01_R_Nugoeihuvi.type", "resGender": 0}
2491	16546	{"_key": 16546, "typeID": 73395, "resPath": "bottomOuter/PantsCorpBusinessM01/Types/PantsCorpBusinessM01_DarkTurquoise.type", "resGender": 1}
2492	16547	{"_key": 16547, "typeID": 73396, "resPath": "outer/JacketCorpBusinessM01/Types/JacketCorpBusinessM01_DarkTurquoise.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 2}
2493	16550	{"_key": 16550, "typeID": 73407, "resPath": "Outer/JacketMilF02/Types/JacketMilF02_WhiteTurquoise.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 0, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 0}
2494	16551	{"_key": 16551, "typeID": 73423, "resPath": "Accessories/Masks/Mask_Cyberpunk_F01/Types/Mask_Cyberpunk_F01_Tan_Worn.type", "resGender": 0}
2495	16552	{"_key": 16552, "typeID": 73424, "resPath": "Accessories/Glasses/Goggles_01/Types/goggles_01_tan_worn.type", "resGender": 0}
2496	16553	{"_key": 16553, "typeID": 73425, "resPath": "Accessories/Masks/Mask_Cyberpunk_M01/Types/Mask_Cyberpunk_M01_Tan_Worn.type", "resGender": 1}
2497	16554	{"_key": 16554, "typeID": 73426, "resPath": "Accessories/Glasses/Goggles_01/Types/goggles_01_tan_worn.type", "resGender": 1}
2498	16555	{"_key": 16555, "typeID": 73436, "resPath": "Makeup/Augmentations/Face_Paint_M01/Types/Face_Paint_M01_V7_Red.type", "resGender": 1}
2499	16556	{"_key": 16556, "typeID": 73437, "resPath": "Makeup/Augmentations/Face_Paint_F01/Types/Face_Paint_F01_V3_Red.type", "resGender": 0}
2500	16583	{"_key": 16583, "typeID": 82040, "resPath": "bottomOuter/PantsALF_01/Types/PantsALF_01_jeansblue.type", "resGender": 0}
2501	16584	{"_key": 16584, "typeID": 82041, "resPath": "bottomOuter/PantsMilM01/Types/PantsMilM01_jeansblue.type", "resGender": 1}
2502	16600	{"_key": 16600, "typeID": 87572, "resPath": "Outer/CostumeJF01/Types/CostumeJF01_Drifter.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2503	16601	{"_key": 16601, "typeID": 87573, "resPath": "outer/CostumeJM01/Types/CostumeJM01_Drifter.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2504	16608	{"_key": 16608, "typeID": 88186, "resPath": "outer/AugmentationSuitM01/Types/AugmentationSuitM01_Black.type", "resGender": 1, "clothingAlsoCoversCategory": 10, "clothingAlsoCoversCategory2": 10}
2505	16609	{"_key": 16609, "typeID": 88187, "resPath": "Outer/AugmentationSuitF01/Types/AugmentationSuitF01_Black.type", "resGender": 0, "clothingAlsoCoversCategory": 10, "clothingAlsoCoversCategory2": 10}
2506	16610	{"_key": 16610, "typeID": 92308, "resPath": "Outer/JacketCorpBusinessF01/Types/JacketCorpBusinessF01_Green_Tie.type", "resGender": 0}
2507	16611	{"_key": 16611, "typeID": 92317, "resPath": "bottomOuter/PantsCorpBusinessF01/Types/PantsCorpBusinessF01_Green.type", "resGender": 0}
2508	16639	{"_key": 16639, "typeID": 92631, "resPath": "Outer/ArmorSuitCF01/Types/ArmorSuitCF01_Glam.type", "resGender": 0, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2509	16640	{"_key": 16640, "typeID": 92644, "resPath": "outer/ArmorSuitMM01/Types/ArmorSuitMM01_Glem.type", "resGender": 1, "clothingRuleException": 0, "clothingRemovesCategory": 25, "clothingRemovesCategory2": 22, "clothingAlsoCoversCategory": 25, "clothingAlsoCoversCategory2": 22}
2510	16646	{"_key": 16646, "typeID": 93589, "resPath": "TopMiddle/ShirtQF01/Types/soerff03.type", "resGender": 0}
2511	16647	{"_key": 16647, "typeID": 93590, "resPath": "topMiddle/ShirtQM01/Types/soerfm03.type", "resGender": 1}
2512	16648	{"_key": 16648, "typeID": 93725, "resPath": "Outer/LabCoatF01/Types/LabCoatF01_WhiteRed.type", "resGender": 0}
2513	16649	{"_key": 16649, "typeID": 93737, "resPath": "outer/LabCoatM01/Types/LabCoatM01_WhiteRed.type", "resGender": 1}
\.


--
-- Name: character_resources character_resources_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.character_resources
    ADD CONSTRAINT character_resources_pkey PRIMARY KEY (row_no);


--
-- Name: character_resources_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX character_resources_key_idx ON sde_native.character_resources USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict CPLD8NhnRSclOzj5hbmJzL1fkq3BYsRhTVjAKualDitkIumH3hOMEReLYkofacS

