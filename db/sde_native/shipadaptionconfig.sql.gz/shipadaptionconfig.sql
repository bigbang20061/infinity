--
-- PostgreSQL database dump
--

\restrict HUkm4SHn9KXmd86uFcc1NZ68N0JynQAzz6jhgpnaFotg2rtJdhdjdYI1AwUKVJs

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: shipadaptionconfig; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.shipadaptionconfig (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: shipadaptionconfig; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.shipadaptionconfig (row_no, key, data) FROM stdin;
0	\N	{"factions": [{"faction_id": 500003, "ship_groups": [{"tree_id": 1, "group_id": 8}]}, {"faction_id": 500001, "ship_groups": [{"tree_id": 7, "group_id": 8}]}, {"faction_id": 500004, "ship_groups": [{"tree_id": 8, "group_id": 8}]}, {"faction_id": 500002, "ship_groups": [{"tree_id": 9, "group_id": 8}]}, {"faction_id": 500003, "ship_groups": [{"tree_id": 10, "group_id": 14}]}, {"faction_id": 500001, "ship_groups": [{"tree_id": 11, "group_id": 14}]}, {"faction_id": 500004, "ship_groups": [{"tree_id": 12, "group_id": 14}]}, {"faction_id": 500002, "ship_groups": [{"tree_id": 13, "group_id": 14}]}, {"faction_id": 500003, "ship_groups": [{"tree_id": 14, "group_id": 16}]}, {"faction_id": 500001, "ship_groups": [{"tree_id": 15, "group_id": 16}]}, {"faction_id": 500004, "ship_groups": [{"tree_id": 16, "group_id": 16}]}, {"faction_id": 500002, "ship_groups": [{"tree_id": 17, "group_id": 16}]}, {"faction_id": 500003, "ship_groups": [{"tree_id": 18, "group_id": 23}]}, {"faction_id": 500001, "ship_groups": [{"tree_id": 19, "group_id": 23}]}, {"faction_id": 500004, "ship_groups": [{"tree_id": 20, "group_id": 23}]}, {"faction_id": 500002, "ship_groups": [{"tree_id": 21, "group_id": 23}]}, {"faction_id": 500003, "ship_groups": [{"tree_id": 25, "group_id": 26}]}, {"faction_id": 500001, "ship_groups": [{"tree_id": 22, "group_id": 26}]}, {"faction_id": 500004, "ship_groups": [{"tree_id": 23, "group_id": 26}]}, {"faction_id": 500002, "ship_groups": [{"tree_id": 24, "group_id": 26}]}, {"faction_id": 500003, "ship_groups": [{"tree_id": 26, "group_id": 34}]}, {"faction_id": 500001, "ship_groups": [{"tree_id": 27, "group_id": 34}]}, {"faction_id": 500004, "ship_groups": [{"tree_id": 28, "group_id": 34}]}, {"faction_id": 500002, "ship_groups": [{"tree_id": 29, "group_id": 34}]}]}
\.


--
-- Name: shipadaptionconfig shipadaptionconfig_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.shipadaptionconfig
    ADD CONSTRAINT shipadaptionconfig_pkey PRIMARY KEY (row_no);


--
-- Name: shipadaptionconfig_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX shipadaptionconfig_key_idx ON sde_native.shipadaptionconfig USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict HUkm4SHn9KXmd86uFcc1NZ68N0JynQAzz6jhgpnaFotg2rtJdhdjdYI1AwUKVJs

