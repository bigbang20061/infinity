--
-- PostgreSQL database dump
--

\restrict lVcj1JctLcs5kM17guqjfILCHHpX0N6PGID3r5Q8E0J9z6BLMop7vu1yNWqCbMB

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: contenttags; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.contenttags (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: contenttags; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.contenttags (row_no, key, data) FROM stdin;
0	activity_combat	{"_key": "activity_combat", "icon": "engage_target", "title": 656027, "description": 660922, "contentTagType": "activity"}
1	activity_donation	{"_key": "activity_donation", "title": 658031, "description": 660923, "contentTagType": "activity"}
2	activity_fleet	{"_key": "activity_fleet", "title": 658032, "description": 660924, "contentTagType": "activity"}
3	activity_gas_harvesting	{"_key": "activity_gas_harvesting", "title": 658033, "description": 660925, "contentTagType": "activity"}
4	activity_hacking	{"_key": "activity_hacking", "icon": "hacking", "title": 658034, "description": 660926, "contentTagType": "activity"}
5	activity_hauling	{"_key": "activity_hauling", "title": 658035, "description": 660927, "contentTagType": "activity"}
6	activity_ice_harvesting	{"_key": "activity_ice_harvesting", "title": 658037, "description": 660928, "contentTagType": "activity"}
7	activity_logistics	{"_key": "activity_logistics", "title": 658038, "description": 660929, "contentTagType": "activity"}
8	activity_manufacturing	{"_key": "activity_manufacturing", "title": 662703, "description": 662702, "contentTagType": "activity"}
9	activity_mining	{"_key": "activity_mining", "icon": "mining", "title": 656026, "description": 660930, "contentTagType": "activity"}
10	activity_salvaging	{"_key": "activity_salvaging", "title": 662705, "description": 662704, "contentTagType": "activity"}
11	activity_trading	{"_key": "activity_trading", "title": 658042, "description": 660933, "contentTagType": "activity"}
12	activity_travel	{"_key": "activity_travel", "title": 658043, "description": 660934, "contentTagType": "activity"}
13	career_path_enforcer	{"_key": "career_path_enforcer", "icon": "enforcer", "title": 656025, "description": 660935, "contentTagType": "career_path"}
14	career_path_explorer	{"_key": "career_path_explorer", "icon": "explorer", "title": 656028, "description": 660937, "contentTagType": "career_path"}
15	career_path_industrialist	{"_key": "career_path_industrialist", "icon": "industrialist", "title": 656029, "description": 660938, "contentTagType": "career_path"}
16	career_path_soldier_of_fortune	{"_key": "career_path_soldier_of_fortune", "icon": "soldier_of_fortune", "title": 656030, "description": 660939, "contentTagType": "career_path"}
17	feature_acp	{"_key": "feature_acp", "title": 666943, "contentTagType": "feature"}
18	feature_agent_missions	{"_key": "feature_agent_missions", "icon": "agent_mission", "title": 656032, "description": 696798, "contentTagType": "feature"}
19	feature_campaigns	{"_key": "feature_campaigns", "icon": "campaign", "title": 1034931, "description": 1034930, "contentTagType": "feature"}
20	feature_capsuleer_day	{"_key": "feature_capsuleer_day", "title": 711413, "description": 711412, "contentTagType": "feature"}
21	feature_combat_anomalies	{"_key": "feature_combat_anomalies", "icon": "combat_sites", "title": 657133, "description": 660940, "contentTagType": "feature"}
22	feature_corporation_projects	{"_key": "feature_corporation_projects", "icon": "corporation_management", "title": 656031, "description": 660942, "contentTagType": "feature"}
23	feature_cosmic_anomalies	{"_key": "feature_cosmic_anomalies", "icon": "warp_to", "title": 658017, "description": 660943, "contentTagType": "feature"}
24	feature_cosmic_signatures	{"_key": "feature_cosmic_signatures", "icon": "pinpoint_probe_formation", "title": 658077, "description": 660944, "contentTagType": "feature"}
25	feature_crimson_harvest	{"_key": "feature_crimson_harvest", "icon": "pirates", "title": 1019504, "description": 1019503, "contentTagType": "feature"}
26	feature_daily_goals	{"_key": "feature_daily_goals", "icon": "air_daily_goals", "title": 697265, "contentTagType": "feature"}
27	feature_dungeons	{"_key": "feature_dungeons", "icon": "location", "title": 656033, "description": 660945, "contentTagType": "feature"}
28	feature_epic_arcs	{"_key": "feature_epic_arcs", "icon": "epic_arc", "title": 658076, "description": 660946, "contentTagType": "feature"}
29	feature_escalation_dungeon	{"_key": "feature_escalation_dungeon", "icon": "escalations", "title": 666942, "description": 696799, "contentTagType": "feature"}
30	feature_ess	{"_key": "feature_ess", "title": 658026, "description": 660948, "contentTagType": "feature"}
31	feature_factional_warfare	{"_key": "feature_factional_warfare", "icon": "flag", "title": 658012, "description": 660949, "contentTagType": "feature"}
32	feature_freelance_projects	{"_key": "feature_freelance_projects", "icon": "freelance_projects", "title": 1009218, "description": 1009221, "contentTagType": "feature"}
33	feature_gallente_election	{"_key": "feature_gallente_election", "icon": "gallente_logo", "title": 1035994, "description": 1035993, "contentTagType": "feature"}
34	feature_homefront_operations	{"_key": "feature_homefront_operations", "icon": "homefront_operations", "title": 657134, "description": 660950, "contentTagType": "feature"}
35	feature_ice_belts	{"_key": "feature_ice_belts", "icon": "ice_field", "title": 672163, "description": 696800, "contentTagType": "feature"}
36	feature_introductions	{"_key": "feature_introductions", "icon": "introduction", "title": 666944, "description": 696801, "contentTagType": "feature"}
37	feature_landmarks	{"_key": "feature_landmarks", "icon": "location", "title": 658027, "description": 660951, "contentTagType": "feature"}
38	feature_mercenary_tactical_ops	{"_key": "feature_mercenary_tactical_ops", "icon": "mercenary_den", "title": 871812, "description": 871811, "contentTagType": "feature"}
39	feature_nexus_reckoning	{"_key": "feature_nexus_reckoning", "icon": "wormholes", "title": 1012106, "description": 1012105, "contentTagType": "feature"}
40	feature_operation_avalon	{"_key": "feature_operation_avalon", "icon": "edencom_logo", "title": 1048007, "description": 1048008, "contentTagType": "feature"}
41	feature_ore_anomalies	{"_key": "feature_ore_anomalies", "icon": "ore_anomalies", "title": 672164, "description": 696802, "contentTagType": "feature"}
42	feature_paragon_missions	{"_key": "feature_paragon_missions", "title": 658025, "description": 660952, "contentTagType": "feature"}
43	feature_pirate_insurgencies	{"_key": "feature_pirate_insurgencies", "icon": "pirate_insurgencies", "title": 697274, "description": 706064, "contentTagType": "feature"}
44	feature_sansha_incursions	{"_key": "feature_sansha_incursions", "icon": "", "title": 658024, "description": 660953, "contentTagType": "feature"}
45	feature_seasons	{"_key": "feature_seasons", "title": 659154, "description": 660956, "contentTagType": "feature"}
46	feature_triglavian	{"_key": "feature_triglavian", "icon": "triglavian_logo", "title": 658029, "description": 660954, "contentTagType": "feature"}
47	feature_warpath	{"_key": "feature_warpath", "icon": "empires", "title": 1042608, "description": 1042607, "contentTagType": "feature"}
48	feature_winter_nexus	{"_key": "feature_winter_nexus", "icon": "superionic_ice", "title": 896308, "description": 896307, "contentTagType": "feature"}
49	feature_world_events	{"_key": "feature_world_events", "icon": "constellation", "title": 1008452, "description": 1008588, "contentTagType": "feature"}
\.


--
-- Name: contenttags contenttags_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.contenttags
    ADD CONSTRAINT contenttags_pkey PRIMARY KEY (row_no);


--
-- Name: contenttags_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX contenttags_key_idx ON sde_native.contenttags USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict lVcj1JctLcs5kM17guqjfILCHHpX0N6PGID3r5Q8E0J9z6BLMop7vu1yNWqCbMB

