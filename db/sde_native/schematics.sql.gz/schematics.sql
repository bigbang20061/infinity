--
-- PostgreSQL database dump
--

\restrict c7cJxW6i1DOjzdtccBmCmhDBp4Kr9bafK645r9of0lqQG0tS3fyJpOy0y1bGQUC

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: schematics; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.schematics (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: schematics; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.schematics (row_no, key, data) FROM stdin;
0	65	{"_key": 65, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2389": {"isInput": 1, "quantity": 40}, "3645": {"isInput": 1, "quantity": 40}, "9838": {"isInput": 0, "quantity": 5}}, "nameID": 66748, "cycleTime": 3600}
1	66	{"_key": 66, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2390": {"isInput": 1, "quantity": 40}, "3645": {"isInput": 1, "quantity": 40}, "9832": {"isInput": 0, "quantity": 5}}, "nameID": 66711, "cycleTime": 3600}
2	67	{"_key": 67, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2389": {"isInput": 1, "quantity": 40}, "2390": {"isInput": 1, "quantity": 40}, "9830": {"isInput": 0, "quantity": 5}}, "nameID": 66744, "cycleTime": 3600}
3	68	{"_key": 68, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2390": {"isInput": 1, "quantity": 40}, "3683": {"isInput": 1, "quantity": 40}, "3691": {"isInput": 0, "quantity": 5}}, "nameID": 66751, "cycleTime": 3600}
4	69	{"_key": 69, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2317": {"isInput": 0, "quantity": 5}, "2392": {"isInput": 1, "quantity": 40}, "3683": {"isInput": 1, "quantity": 40}}, "nameID": 66733, "cycleTime": 3600}
5	70	{"_key": 70, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2392": {"isInput": 1, "quantity": 40}, "3697": {"isInput": 0, "quantity": 5}, "9828": {"isInput": 1, "quantity": 40}}, "nameID": 66745, "cycleTime": 3600}
6	71	{"_key": 71, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2389": {"isInput": 1, "quantity": 40}, "2401": {"isInput": 1, "quantity": 40}, "9840": {"isInput": 0, "quantity": 5}}, "nameID": 66756, "cycleTime": 3600}
7	72	{"_key": 72, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2328": {"isInput": 0, "quantity": 5}, "2398": {"isInput": 1, "quantity": 40}, "3645": {"isInput": 1, "quantity": 40}}, "nameID": 66761, "cycleTime": 3600}
8	73	{"_key": 73, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2398": {"isInput": 1, "quantity": 40}, "2399": {"isInput": 1, "quantity": 40}, "3689": {"isInput": 0, "quantity": 5}}, "nameID": 66726, "cycleTime": 3600}
9	74	{"_key": 74, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2398": {"isInput": 1, "quantity": 40}, "2400": {"isInput": 1, "quantity": 40}, "3828": {"isInput": 0, "quantity": 5}}, "nameID": 66709, "cycleTime": 3600}
10	75	{"_key": 75, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"44": {"isInput": 0, "quantity": 5}, "2399": {"isInput": 1, "quantity": 40}, "2400": {"isInput": 1, "quantity": 40}}, "nameID": 66715, "cycleTime": 3600}
11	76	{"_key": 76, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2400": {"isInput": 1, "quantity": 40}, "2401": {"isInput": 1, "quantity": 40}, "9836": {"isInput": 0, "quantity": 5}}, "nameID": 66710, "cycleTime": 3600}
12	77	{"_key": 77, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2401": {"isInput": 1, "quantity": 40}, "9828": {"isInput": 1, "quantity": 40}, "9842": {"isInput": 0, "quantity": 5}}, "nameID": 66728, "cycleTime": 3600}
13	78	{"_key": 78, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2393": {"isInput": 1, "quantity": 40}, "2398": {"isInput": 1, "quantity": 40}, "2463": {"isInput": 0, "quantity": 5}}, "nameID": 66729, "cycleTime": 3600}
14	79	{"_key": 79, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2329": {"isInput": 0, "quantity": 5}, "2396": {"isInput": 1, "quantity": 40}, "2399": {"isInput": 1, "quantity": 40}}, "nameID": 66702, "cycleTime": 3600}
15	80	{"_key": 80, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2327": {"isInput": 0, "quantity": 5}, "2397": {"isInput": 1, "quantity": 40}, "9828": {"isInput": 1, "quantity": 40}}, "nameID": 66727, "cycleTime": 3600}
16	81	{"_key": 81, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2393": {"isInput": 1, "quantity": 40}, "3775": {"isInput": 0, "quantity": 5}, "3779": {"isInput": 1, "quantity": 40}}, "nameID": 66759, "cycleTime": 3600}
17	82	{"_key": 82, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2393": {"isInput": 1, "quantity": 40}, "2395": {"isInput": 1, "quantity": 40}, "3693": {"isInput": 0, "quantity": 5}}, "nameID": 66716, "cycleTime": 3600}
18	83	{"_key": 83, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2395": {"isInput": 1, "quantity": 40}, "3779": {"isInput": 1, "quantity": 40}, "15317": {"isInput": 0, "quantity": 5}}, "nameID": 66718, "cycleTime": 3600}
19	84	{"_key": 84, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2395": {"isInput": 1, "quantity": 40}, "2396": {"isInput": 1, "quantity": 40}, "3725": {"isInput": 0, "quantity": 5}}, "nameID": 66725, "cycleTime": 3600}
20	85	{"_key": 85, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2396": {"isInput": 1, "quantity": 40}, "2397": {"isInput": 1, "quantity": 40}, "3695": {"isInput": 0, "quantity": 5}}, "nameID": 66739, "cycleTime": 3600}
21	86	{"_key": 86, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2319": {"isInput": 0, "quantity": 5}, "2393": {"isInput": 1, "quantity": 40}, "3645": {"isInput": 1, "quantity": 40}}, "nameID": 66753, "cycleTime": 3600}
22	87	{"_key": 87, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2312": {"isInput": 0, "quantity": 5}, "3683": {"isInput": 1, "quantity": 40}, "3779": {"isInput": 1, "quantity": 40}}, "nameID": 66750, "cycleTime": 3600}
23	88	{"_key": 88, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2321": {"isInput": 0, "quantity": 5}, "2392": {"isInput": 1, "quantity": 40}, "2397": {"isInput": 1, "quantity": 40}}, "nameID": 66738, "cycleTime": 3600}
24	89	{"_key": 89, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"3691": {"isInput": 1, "quantity": 10}, "9838": {"isInput": 1, "quantity": 10}, "17136": {"isInput": 0, "quantity": 3}}, "nameID": 66757, "cycleTime": 3600}
25	90	{"_key": 90, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2317": {"isInput": 1, "quantity": 10}, "2344": {"isInput": 0, "quantity": 3}, "9832": {"isInput": 1, "quantity": 10}}, "nameID": 66708, "cycleTime": 3600}
26	91	{"_key": 91, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2345": {"isInput": 0, "quantity": 3}, "3697": {"isInput": 1, "quantity": 10}, "9830": {"isInput": 1, "quantity": 10}}, "nameID": 66706, "cycleTime": 3600}
27	92	{"_key": 92, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2312": {"isInput": 1, "quantity": 10}, "2319": {"isInput": 1, "quantity": 10}, "2346": {"isInput": 0, "quantity": 3}}, "nameID": 66752, "cycleTime": 3600}
28	94	{"_key": 94, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2321": {"isInput": 1, "quantity": 10}, "9840": {"isInput": 1, "quantity": 10}, "17898": {"isInput": 0, "quantity": 3}}, "nameID": 66722, "cycleTime": 3600}
29	95	{"_key": 95, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2317": {"isInput": 1, "quantity": 10}, "2329": {"isInput": 1, "quantity": 10}, "2348": {"isInput": 0, "quantity": 3}, "9838": {"isInput": 1, "quantity": 10}}, "nameID": 66717, "cycleTime": 3600}
30	96	{"_key": 96, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2328": {"isInput": 1, "quantity": 10}, "2349": {"isInput": 0, "quantity": 3}, "9832": {"isInput": 1, "quantity": 10}, "9836": {"isInput": 1, "quantity": 10}}, "nameID": 66749, "cycleTime": 3600}
31	97	{"_key": 97, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"3689": {"isInput": 1, "quantity": 10}, "9836": {"isInput": 1, "quantity": 10}, "9848": {"isInput": 0, "quantity": 3}}, "nameID": 66743, "cycleTime": 3600}
32	98	{"_key": 98, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2351": {"isInput": 0, "quantity": 3}, "3828": {"isInput": 1, "quantity": 10}, "9842": {"isInput": 1, "quantity": 10}}, "nameID": 66747, "cycleTime": 3600}
33	99	{"_key": 99, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"44": {"isInput": 1, "quantity": 10}, "2327": {"isInput": 1, "quantity": 10}, "2352": {"isInput": 0, "quantity": 3}}, "nameID": 66732, "cycleTime": 3600}
34	100	{"_key": 100, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2328": {"isInput": 1, "quantity": 10}, "9834": {"isInput": 0, "quantity": 3}, "9840": {"isInput": 1, "quantity": 10}}, "nameID": 66719, "cycleTime": 3600}
35	102	{"_key": 102, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2329": {"isInput": 1, "quantity": 10}, "2354": {"isInput": 0, "quantity": 3}, "3697": {"isInput": 1, "quantity": 10}}, "nameID": 66731, "cycleTime": 3600}
36	103	{"_key": 103, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2312": {"isInput": 1, "quantity": 10}, "3689": {"isInput": 1, "quantity": 10}, "9842": {"isInput": 1, "quantity": 10}, "9846": {"isInput": 0, "quantity": 3}}, "nameID": 66736, "cycleTime": 3600}
37	104	{"_key": 104, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2358": {"isInput": 0, "quantity": 3}, "2463": {"isInput": 1, "quantity": 10}, "3725": {"isInput": 1, "quantity": 10}, "3828": {"isInput": 1, "quantity": 10}}, "nameID": 66705, "cycleTime": 3600}
38	105	{"_key": 105, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"3725": {"isInput": 1, "quantity": 10}, "3775": {"isInput": 1, "quantity": 10}, "28974": {"isInput": 0, "quantity": 3}}, "nameID": 66758, "cycleTime": 3600}
39	106	{"_key": 106, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2360": {"isInput": 0, "quantity": 3}, "3693": {"isInput": 1, "quantity": 10}, "3695": {"isInput": 1, "quantity": 10}}, "nameID": 66723, "cycleTime": 3600}
40	107	{"_key": 107, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2321": {"isInput": 1, "quantity": 10}, "2361": {"isInput": 0, "quantity": 3}, "15317": {"isInput": 1, "quantity": 10}}, "nameID": 66721, "cycleTime": 3600}
41	108	{"_key": 108, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2329": {"isInput": 1, "quantity": 10}, "2463": {"isInput": 1, "quantity": 10}, "12836": {"isInput": 0, "quantity": 3}}, "nameID": 66755, "cycleTime": 3600}
42	109	{"_key": 109, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2312": {"isInput": 1, "quantity": 10}, "2327": {"isInput": 1, "quantity": 10}, "17392": {"isInput": 0, "quantity": 3}}, "nameID": 66713, "cycleTime": 3600}
43	110	{"_key": 110, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2366": {"isInput": 0, "quantity": 3}, "3695": {"isInput": 1, "quantity": 10}, "3775": {"isInput": 1, "quantity": 10}, "9840": {"isInput": 1, "quantity": 10}}, "nameID": 66720, "cycleTime": 3600}
44	111	{"_key": 111, "pins": [2470, 2472, 2474, 2480, 2484, 2485, 2491, 2494], "types": {"2319": {"isInput": 1, "quantity": 10}, "2367": {"isInput": 0, "quantity": 3}, "3691": {"isInput": 1, "quantity": 10}, "3693": {"isInput": 1, "quantity": 10}}, "nameID": 66712, "cycleTime": 3600}
45	112	{"_key": 112, "pins": [2475, 2482], "types": {"2344": {"isInput": 1, "quantity": 6}, "2393": {"isInput": 1, "quantity": 40}, "2870": {"isInput": 0, "quantity": 1}, "9848": {"isInput": 1, "quantity": 6}}, "nameID": 66765, "cycleTime": 3600}
46	113	{"_key": 113, "pins": [2475, 2482], "types": {"2351": {"isInput": 1, "quantity": 6}, "2875": {"isInput": 0, "quantity": 1}, "3645": {"isInput": 1, "quantity": 40}, "28974": {"isInput": 1, "quantity": 6}}, "nameID": 66768, "cycleTime": 3600}
47	114	{"_key": 114, "pins": [2475, 2482], "types": {"2360": {"isInput": 1, "quantity": 6}, "2398": {"isInput": 1, "quantity": 40}, "2869": {"isInput": 0, "quantity": 1}, "17136": {"isInput": 1, "quantity": 6}}, "nameID": 66730, "cycleTime": 3600}
48	115	{"_key": 115, "pins": [2475, 2482], "types": {"2345": {"isInput": 1, "quantity": 6}, "2352": {"isInput": 1, "quantity": 6}, "2361": {"isInput": 1, "quantity": 6}, "2872": {"isInput": 0, "quantity": 1}}, "nameID": 66767, "cycleTime": 3600}
49	116	{"_key": 116, "pins": [2475, 2482], "types": {"2346": {"isInput": 1, "quantity": 6}, "2871": {"isInput": 0, "quantity": 1}, "9834": {"isInput": 1, "quantity": 6}, "12836": {"isInput": 1, "quantity": 6}}, "nameID": 66766, "cycleTime": 3600}
50	117	{"_key": 117, "pins": [2475, 2482], "types": {"2354": {"isInput": 1, "quantity": 6}, "2867": {"isInput": 0, "quantity": 1}, "17392": {"isInput": 1, "quantity": 6}, "17898": {"isInput": 1, "quantity": 6}}, "nameID": 66763, "cycleTime": 3600}
51	118	{"_key": 118, "pins": [2475, 2482], "types": {"2348": {"isInput": 1, "quantity": 6}, "2366": {"isInput": 1, "quantity": 6}, "2868": {"isInput": 0, "quantity": 1}, "9846": {"isInput": 1, "quantity": 6}}, "nameID": 66764, "cycleTime": 3600}
52	119	{"_key": 119, "pins": [2475, 2482], "types": {"2349": {"isInput": 1, "quantity": 6}, "2358": {"isInput": 1, "quantity": 6}, "2367": {"isInput": 1, "quantity": 6}, "2876": {"isInput": 0, "quantity": 1}}, "nameID": 66762, "cycleTime": 3600}
53	121	{"_key": 121, "pins": [2469, 2471, 2473, 2481, 2483, 2490, 2492, 2493], "types": {"2268": {"isInput": 1, "quantity": 3000}, "3645": {"isInput": 0, "quantity": 20}}, "nameID": 66760, "cycleTime": 1800}
54	122	{"_key": 122, "pins": [2469, 2471, 2473, 2481, 2483, 2490, 2492, 2493], "types": {"2308": {"isInput": 1, "quantity": 3000}, "2389": {"isInput": 0, "quantity": 20}}, "nameID": 66737, "cycleTime": 1800}
55	123	{"_key": 123, "pins": [2469, 2471, 2473, 2481, 2483, 2490, 2492, 2493], "types": {"2309": {"isInput": 1, "quantity": 3000}, "2390": {"isInput": 0, "quantity": 20}}, "nameID": 66714, "cycleTime": 1800}
56	124	{"_key": 124, "pins": [2469, 2471, 2473, 2481, 2483, 2490, 2492, 2493], "types": {"2310": {"isInput": 1, "quantity": 3000}, "3683": {"isInput": 0, "quantity": 20}}, "nameID": 66735, "cycleTime": 1800}
57	125	{"_key": 125, "pins": [2469, 2471, 2473, 2481, 2483, 2490, 2492, 2493], "types": {"2311": {"isInput": 1, "quantity": 3000}, "2392": {"isInput": 0, "quantity": 20}}, "nameID": 66734, "cycleTime": 1800}
58	126	{"_key": 126, "pins": [2469, 2471, 2473, 2481, 2483, 2490, 2492, 2493], "types": {"2267": {"isInput": 1, "quantity": 3000}, "2398": {"isInput": 0, "quantity": 20}}, "nameID": 66742, "cycleTime": 1800}
59	127	{"_key": 127, "pins": [2469, 2471, 2473, 2481, 2483, 2490, 2492, 2493], "types": {"2270": {"isInput": 1, "quantity": 3000}, "2399": {"isInput": 0, "quantity": 20}}, "nameID": 66740, "cycleTime": 1800}
60	128	{"_key": 128, "pins": [2469, 2471, 2473, 2481, 2483, 2490, 2492, 2493], "types": {"2272": {"isInput": 1, "quantity": 3000}, "2400": {"isInput": 0, "quantity": 20}}, "nameID": 66754, "cycleTime": 1800}
61	129	{"_key": 129, "pins": [2469, 2471, 2473, 2481, 2483, 2490, 2492, 2493], "types": {"2306": {"isInput": 1, "quantity": 3000}, "2401": {"isInput": 0, "quantity": 20}}, "nameID": 66707, "cycleTime": 1800}
62	130	{"_key": 130, "pins": [2469, 2471, 2473, 2481, 2483, 2490, 2492, 2493], "types": {"2307": {"isInput": 1, "quantity": 3000}, "9828": {"isInput": 0, "quantity": 20}}, "nameID": 66746, "cycleTime": 1800}
63	131	{"_key": 131, "pins": [2469, 2471, 2473, 2481, 2483, 2490, 2492, 2493], "types": {"2073": {"isInput": 1, "quantity": 3000}, "2393": {"isInput": 0, "quantity": 20}}, "nameID": 66701, "cycleTime": 1800}
64	132	{"_key": 132, "pins": [2469, 2471, 2473, 2481, 2483, 2490, 2492, 2493], "types": {"2286": {"isInput": 1, "quantity": 3000}, "3779": {"isInput": 0, "quantity": 20}}, "nameID": 66704, "cycleTime": 1800}
65	133	{"_key": 133, "pins": [2469, 2471, 2473, 2481, 2483, 2490, 2492, 2493], "types": {"2287": {"isInput": 1, "quantity": 3000}, "2395": {"isInput": 0, "quantity": 20}}, "nameID": 66741, "cycleTime": 1800}
66	134	{"_key": 134, "pins": [2469, 2471, 2473, 2481, 2483, 2490, 2492, 2493], "types": {"2288": {"isInput": 1, "quantity": 3000}, "2396": {"isInput": 0, "quantity": 20}}, "nameID": 66703, "cycleTime": 1800}
67	135	{"_key": 135, "pins": [2469, 2471, 2473, 2481, 2483, 2490, 2492, 2493], "types": {"2305": {"isInput": 1, "quantity": 3000}, "2397": {"isInput": 0, "quantity": 20}}, "nameID": 66724, "cycleTime": 1800}
\.


--
-- Name: schematics schematics_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.schematics
    ADD CONSTRAINT schematics_pkey PRIMARY KEY (row_no);


--
-- Name: schematics_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX schematics_key_idx ON sde_native.schematics USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict c7cJxW6i1DOjzdtccBmCmhDBp4Kr9bafK645r9of0lqQG0tS3fyJpOy0y1bGQUC

