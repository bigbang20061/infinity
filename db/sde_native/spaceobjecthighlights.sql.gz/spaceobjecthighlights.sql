--
-- PostgreSQL database dump
--

\restrict uphRCOgqdV7g9aGNYVC4mrNKF6U4OnqGO51mZhx3Yq36j4SE1Pnt8Z0lHMadlGY

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: spaceobjecthighlights; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.spaceobjecthighlights (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: spaceobjecthighlights; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.spaceobjecthighlights (row_no, key, data) FROM stdin;
0	155	{"_key": 155, "hint": 534287, "name": "AS0101", "message": 534286, "spaceObjectID": 1057385, "spaceObjectType": "objectID"}
1	156	{"_key": 156, "hint": 534317, "name": "AS0105", "message": 534316, "spaceObjectID": 42692, "spaceObjectType": "typeID"}
2	160	{"_key": 160, "hint": 534347, "name": "AS0201", "message": 534346, "spaceObjectID": 15, "spaceObjectType": "groupID", "disableBracketHighlight": 0}
3	161	{"_key": 161, "hint": 534818, "name": "AS0106", "message": 534817, "spaceObjectID": 42692, "spaceObjectType": "typeID"}
4	162	{"_key": 162, "hint": 534820, "name": "AS0107", "message": 534819, "spaceObjectID": 42692, "spaceObjectType": "typeID"}
5	163	{"_key": 163, "hint": 534822, "name": "AS0108", "message": 534821, "spaceObjectID": 42692, "spaceObjectType": "typeID"}
6	165	{"_key": 165, "hint": 539243, "name": "Near tower range tutorial", "message": 539242, "spaceObjectID": 48594, "spaceObjectType": "typeID", "disableBracketHighlight": 1}
7	166	{"_key": 166, "hint": 539384, "name": "AccelerationGate", "message": 539383, "spaceObjectID": 1060209, "spaceObjectType": "objectID"}
8	167	{"_key": 167, "hint": 539528, "name": "RangeNPCGroup", "message": 539527, "spaceObjectID": 48545, "spaceObjectType": "typeID"}
9	168	{"_key": 168, "hint": 539562, "name": "Fleeing NPC Highlight", "message": 539561, "spaceObjectID": 48640, "spaceObjectType": "typeID", "disableBracketHighlight": 1}
10	169	{"_key": 169, "hint": 539866, "name": "Malfunctioning Sleeper Station", "message": 539865, "spaceObjectID": 48652, "spaceObjectType": "typeID", "disableBracketHighlight": 1}
11	170	{"_key": 170, "hint": 539869, "name": "Prop Site 2", "message": 539868, "spaceObjectID": 42692, "spaceObjectType": "typeID", "disableBracketHighlight": 1}
12	171	{"_key": 171, "hint": 542095, "name": "AS01B02: Locate Wreck", "message": 542094, "spaceObjectID": 34190, "spaceObjectType": "typeID"}
13	172	{"_key": 172, "hint": 543683, "name": "AS01B03: Approach Wreck", "message": 543682, "spaceObjectID": 34190, "spaceObjectType": "typeID"}
14	2175	{"_key": 2175, "hint": 553688, "name": "Seeker Pacekeeper", "message": 553687, "spaceObjectID": 47492, "spaceObjectType": "typeID", "disableBracketHighlight": 1}
15	2176	{"_key": 2176, "hint": 553752, "name": "Circadian Seeker", "message": 553751, "spaceObjectID": 42692, "spaceObjectType": "typeID", "disableBracketHighlight": 1}
16	2177	{"_key": 2177, "hint": 553754, "name": "Seeker Wreck", "message": 553753, "spaceObjectID": 34440, "spaceObjectType": "typeID", "disableBracketHighlight": 1}
17	2178	{"_key": 2178, "hint": 553756, "name": "Far Tower", "message": 553755, "spaceObjectID": 47488, "spaceObjectType": "typeID", "disableBracketHighlight": 1}
18	2179	{"_key": 2179, "hint": 553758, "name": "Station", "message": 553757, "spaceObjectID": 15, "spaceObjectType": "groupID", "disableBracketHighlight": 1}
19	2181	{"_key": 2181, "hint": 554102, "name": "Next Item in Autopilot Route", "message": 554101, "spaceObjectID": 1, "spaceObjectType": "nextItemInRoute", "disableBracketHighlight": 1}
20	2185	{"_key": 2185, "hint": 554416, "name": "Seeker Eluder", "message": 554415, "spaceObjectID": 47489, "spaceObjectType": "typeID", "disableBracketHighlight": 1}
21	2187	{"_key": 2187, "hint": 563257, "name": "Approaching Wreck", "message": 563256, "spaceObjectID": 34190, "spaceObjectType": "typeID"}
22	2188	{"_key": 2188, "hint": 573451, "name": "ORE Faded Volatile Ice Processor", "message": 573450, "spaceObjectID": 57042, "spaceObjectType": "typeID", "secondsTilFadeout": 10}
23	2189	{"_key": 2189, "hint": 573453, "name": "ORE Faded Volatile Ice Processor", "message": 573452, "spaceObjectID": 57047, "spaceObjectType": "typeID", "secondsTilFadeout": 10}
24	2190	{"_key": 2190, "hint": 573455, "name": "ORE Faded Volatile Ice Processor", "message": 573454, "spaceObjectID": 57048, "spaceObjectType": "typeID", "secondsTilFadeout": 10}
25	2191	{"_key": 2191, "hint": 577062, "name": "OdysseyExperience Scene 2 - Anomaly", "message": 577063, "spaceObjectID": 1107862, "spaceObjectType": "objectID"}
26	2192	{"_key": 2192, "hint": 577303, "name": "[AIR] Scene 2 - Unidentified Frigates", "message": 577304, "spaceObjectID": 57801, "spaceObjectType": "typeID"}
27	2193	{"_key": 2193, "hint": 577425, "name": "[AIR] Balin Ferrus Ship", "message": 577426, "spaceObjectID": 57788, "spaceObjectType": "typeID"}
28	2194	{"_key": 2194, "hint": 577428, "name": "[AIR] Scene 2 - Unidentified Cruiser", "message": 577429, "spaceObjectID": 57802, "spaceObjectType": "typeID"}
29	2195	{"_key": 2195, "hint": 577431, "name": "[AIR] Scene 2 - Unidentified Battleships", "message": 577432, "spaceObjectID": 57803, "spaceObjectType": "typeID"}
30	2196	{"_key": 2196, "hint": 580725, "name": "[Air] Astero", "message": 580726, "spaceObjectID": 58745, "spaceObjectType": "typeID"}
31	2197	{"_key": 2197, "name": "Test OFF", "disableBox": 1, "spaceObjectID": 15, "spaceObjectType": "groupID"}
32	2200	{"_key": 2200, "name": "[AIR NPE] Station", "message": 585314, "spaceObjectID": 15, "spaceObjectType": "groupID"}
33	2201	{"_key": 2201, "name": "[AIR NPE] Stargate", "message": 585315, "spaceObjectID": 10, "spaceObjectType": "groupID"}
34	2202	{"_key": 2202, "name": "[AIR] Scene 2 - Frigates - Orbit", "message": 585692, "spaceObjectID": 57801, "spaceObjectType": "typeID"}
35	2203	{"_key": 2203, "name": "[AIR] Scene 2 - Frigates - Lock", "message": 585693, "spaceObjectID": 57801, "spaceObjectType": "typeID"}
36	2204	{"_key": 2204, "name": "[AIR] Scene 2 - Battleships - Orbit", "message": 585989, "spaceObjectID": 57803, "spaceObjectType": "typeID"}
37	2205	{"_key": 2205, "name": "[AIR] Scene 2 - Cruiser - Orbit", "message": 585990, "spaceObjectID": 57802, "spaceObjectType": "typeID"}
38	2206	{"_key": 2206, "name": "[AIR] Scene 2 - Cruiser - Lock", "message": 585991, "spaceObjectID": 57802, "spaceObjectType": "typeID"}
39	2207	{"_key": 2207, "name": "[AIR] Scene 2 - Battleships - Lock", "message": 585992, "spaceObjectID": 57803, "spaceObjectType": "typeID"}
40	2208	{"_key": 2208, "name": "[AIR NPE] First Asteroid (Mining Adventure)", "message": 589240, "spaceObjectID": 1114285, "spaceObjectType": "objectID"}
41	2209	{"_key": 2209, "name": "[AIR NPE] Wrecked Dramiel", "message": 595861, "spaceObjectID": 1114288, "spaceObjectType": "objectID"}
42	2215	{"_key": 2215, "name": "tutorial container", "message": 656379, "spaceObjectID": 74846, "spaceObjectType": "typeID"}
43	2217	{"_key": 2217, "name": "tutorial cloud", "message": 657269, "spaceObjectID": 74294, "spaceObjectType": "typeID"}
44	2223	{"_key": 2223, "name": "[GREAD] M1 - Final Asteroid", "spaceObjectID": 1348032, "spaceObjectType": "objectID"}
45	2224	{"_key": 2224, "name": "[GREAD] M1 - Hackable Structure", "spaceObjectID": 1347607, "spaceObjectType": "objectID"}
46	2225	{"_key": 2225, "name": "[GREAD] M3 - Structure", "spaceObjectID": 1350293, "spaceObjectType": "objectID"}
47	2226	{"_key": 2226, "name": "[GREAD] M1 - Veldspar", "spaceObjectID": 1230, "spaceObjectType": "typeID"}
\.


--
-- Name: spaceobjecthighlights spaceobjecthighlights_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.spaceobjecthighlights
    ADD CONSTRAINT spaceobjecthighlights_pkey PRIMARY KEY (row_no);


--
-- Name: spaceobjecthighlights_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX spaceobjecthighlights_key_idx ON sde_native.spaceobjecthighlights USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict uphRCOgqdV7g9aGNYVC4mrNKF6U4OnqGO51mZhx3Yq36j4SE1Pnt8Z0lHMadlGY

