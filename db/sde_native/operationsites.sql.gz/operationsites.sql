--
-- PostgreSQL database dump
--

\restrict cuIEGIjFIgTp0uNjPseQjOq2dBWgmjXfny8xCdObnKeTwUvzKz0TUMQtguizoBc

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: operationsites; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.operationsites (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: operationsites; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.operationsites (row_no, key, data) FROM stdin;
0	15	{"id": 15, "_key": 15, "name": "Combat Site 6", "title": 536169, "spawning": "sameSolarSystem", "dungeonIDs": {"amarr": 6423, "caldari": 6423, "gallente": 6423, "minmatar": 6423}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
1	27	{"id": 27, "_key": 27, "name": "Additional Advanced Site 1", "title": 539404, "spawning": "sameSolarSystem", "dungeonIDs": {"amarr": 6424, "caldari": 6424, "gallente": 6424, "minmatar": 6424}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
2	28	{"id": 28, "_key": 28, "name": "Additional Advanced Site 2", "title": 539405, "spawning": "sameSolarSystem", "dungeonIDs": {"amarr": 6425, "caldari": 6425, "gallente": 6425, "minmatar": 6425}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
3	36	{"id": 36, "_key": 36, "name": "Starter Site", "title": 541525, "spawning": "schoolStartingSystem", "dungeonIDs": {"amarr": 6433, "caldari": 6433, "gallente": 6433, "minmatar": 6433}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
4	37	{"id": 37, "_key": 37, "name": "Additional Propulsion Site 1", "title": 542450, "spawning": "sameSolarSystem", "dungeonIDs": {"amarr": 6421, "caldari": 6421, "gallente": 6421, "minmatar": 6421}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
5	38	{"id": 38, "_key": 38, "name": "Additional Range Site 1", "title": 542452, "spawning": "sameSolarSystem", "dungeonIDs": {"amarr": 6415, "caldari": 6415, "gallente": 6415, "minmatar": 6415}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
6	39	{"id": 39, "_key": 39, "name": "Combat Site 1", "title": 542602, "spawning": "sameSolarSystem", "dungeonIDs": {"amarr": 6411, "caldari": 6411, "gallente": 6411, "minmatar": 6411}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
7	40	{"id": 40, "_key": 40, "name": "Combat Site 2", "title": 542671, "spawning": "sameSolarSystem", "dungeonIDs": {"amarr": 6414, "caldari": 6414, "gallente": 6414, "minmatar": 6414}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
8	41	{"id": 41, "_key": 41, "name": "Combat Site 3", "title": 542672, "spawning": "sameSolarSystem", "dungeonIDs": {"amarr": 6417, "caldari": 6417, "gallente": 6417, "minmatar": 6417}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
9	42	{"id": 42, "_key": 42, "name": "Combat Site 4", "title": 542673, "spawning": "sameSolarSystem", "dungeonIDs": {"amarr": 6420, "caldari": 6420, "gallente": 6420, "minmatar": 6420}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
10	43	{"id": 43, "_key": 43, "name": "Additional Basic Combat Site 1", "title": 542711, "spawning": "sameSolarSystem", "dungeonIDs": {"amarr": 6412, "caldari": 6412, "gallente": 6412, "minmatar": 6412}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
11	44	{"id": 44, "_key": 44, "name": "Additional Basic Combat Site 2", "title": 542856, "spawning": "sameSolarSystem", "dungeonIDs": {"amarr": 6413, "caldari": 6413, "gallente": 6413, "minmatar": 6413}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
12	45	{"id": 45, "_key": 45, "name": "Additional Tracking Site 1", "title": 543110, "spawning": "sameSolarSystem", "dungeonIDs": {"amarr": 6418, "caldari": 6418, "gallente": 6418, "minmatar": 6418}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
13	46	{"id": 46, "_key": 46, "name": "Additional Tracking Site 2", "title": 543111, "spawning": "sameSolarSystem", "dungeonIDs": {"amarr": 6419, "caldari": 6419, "gallente": 6419, "minmatar": 6419}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
14	47	{"id": 47, "_key": 47, "name": "Additional Range Site 2", "title": 543112, "spawning": "sameSolarSystem", "dungeonIDs": {"amarr": 6416, "caldari": 6416, "gallente": 6416, "minmatar": 6416}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
15	48	{"id": 48, "_key": 48, "name": "Additional Propulsion Site 2", "title": 543113, "spawning": "sameSolarSystem", "dungeonIDs": {"amarr": 6422, "caldari": 6422, "gallente": 6422, "minmatar": 6422}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
16	50	{"id": 50, "_key": 50, "name": "Historical Battle: Amarr", "title": 545157, "spawning": "schoolStartingSystem", "dungeonIDs": {"amarr": 6470, "caldari": 5748, "gallente": 5749, "minmatar": 5750}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
17	2056	{"id": 2056, "_key": 2056, "name": "Combat Site 1b", "title": 564047, "spawning": "sameSolarSystem", "dungeonIDs": {"amarr": 8812, "caldari": 8812, "gallente": 8812, "minmatar": 8812}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
18	2059	{"id": 2059, "_key": 2059, "name": "Battle in the Ruins (new)", "title": 565963, "spawning": "sameSolarSystem", "dungeonIDs": {"amarr": 8832, "caldari": 8832, "gallente": 8832, "minmatar": 8832}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
19	2063	{"id": 2063, "_key": 2063, "name": "[AIR]Scene 1", "title": 576770, "spawning": "sameSolarSystem", "dungeonIDs": {"amarr": 9103, "caldari": 9103, "gallente": 9103, "minmatar": 9103}, "shouldSpawn": 0, "disableWarpToEntryPointRedirect": 0}
20	2064	{"id": 2064, "_key": 2064, "name": "[AIR] 2 - Fight Encounter", "title": 577053, "spawning": "sameSolarSystem", "dungeonIDs": {"amarr": 9105, "caldari": 9105, "gallente": 9105, "minmatar": 9105}, "shouldSpawn": 1, "disableWarpToEntryPointRedirect": 1}
\.


--
-- Name: operationsites operationsites_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.operationsites
    ADD CONSTRAINT operationsites_pkey PRIMARY KEY (row_no);


--
-- Name: operationsites_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX operationsites_key_idx ON sde_native.operationsites USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict cuIEGIjFIgTp0uNjPseQjOq2dBWgmjXfny8xCdObnKeTwUvzKz0TUMQtguizoBc

