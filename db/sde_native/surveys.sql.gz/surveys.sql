--
-- PostgreSQL database dump
--

\restrict kSEmbLcNhvgi4BSZUfZ6OEx4gsTCgrgaUMZU5KaPiY03FptD8fPCdFUODaZeRmp

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: surveys; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.surveys (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: surveys; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.surveys (row_no, key, data) FROM stdin;
0	28	{"url": "https://surveys.12traits.com/s3/CCP-EVE-Online?playerid=%s", "_key": 28, "name": "12traits 2021", "endDate": "25/04/2021", "resPath": "res:/UI/Texture/classes/Surveys/survey2021.jpg", "startDate": "8/04/2021", "vgsRewards": [5003], "description": "A psychological traits survey for 2021", "gracePeriod": 30, "itemRewards": [], "apiClassName": "TwelveTraitsAPI", "claimLabelID": 577342, "minAccountAgeHours": 24}
\.


--
-- Name: surveys surveys_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.surveys
    ADD CONSTRAINT surveys_pkey PRIMARY KEY (row_no);


--
-- Name: surveys_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX surveys_key_idx ON sde_native.surveys USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict kSEmbLcNhvgi4BSZUfZ6OEx4gsTCgrgaUMZU5KaPiY03FptD8fPCdFUODaZeRmp

