--
-- PostgreSQL database dump
--

\restrict Mr6kmuFxb1zIFZf9Xmx6ac4Iau3LuzONH943MRihGDDi3Y5unUdtsfASyIYpVsC

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agenttypes; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.agenttypes (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: agenttypes; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.agenttypes (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "value": "NonAgent"}
1	2	{"_key": 2, "value": "BasicAgent"}
2	3	{"_key": 3, "value": "TutorialAgent"}
3	4	{"_key": 4, "value": "ResearchAgent"}
4	5	{"_key": 5, "value": "CONCORDAgent"}
5	6	{"_key": 6, "value": "GenericStorylineMissionAgent"}
6	7	{"_key": 7, "value": "StorylineMissionAgent"}
7	8	{"_key": 8, "value": "EventMissionAgent"}
8	9	{"_key": 9, "value": "FactionalWarfareAgent"}
9	10	{"_key": 10, "value": "EpicArcAgent"}
10	11	{"_key": 11, "value": "AuraAgent"}
11	12	{"_key": 12, "value": "CareerAgent"}
12	13	{"_key": 13, "value": "HeraldryAgent"}
\.


--
-- Name: agenttypes agenttypes_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.agenttypes
    ADD CONSTRAINT agenttypes_pkey PRIMARY KEY (row_no);


--
-- Name: agenttypes_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX agenttypes_key_idx ON sde_native.agenttypes USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict Mr6kmuFxb1zIFZf9Xmx6ac4Iau3LuzONH943MRihGDDi3Y5unUdtsfASyIYpVsC

