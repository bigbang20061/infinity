--
-- PostgreSQL database dump
--

\restrict 7ta8KFNt9j5idngECYfco1Lwu1cKGiwNtIwrNgBrWWaWkreKfGQydIFuhiLZ3Ej

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: brawlachievements; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.brawlachievements (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: brawlachievements; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.brawlachievements (row_no, key, data) FROM stdin;
0	10001	{"_key": 10001, "group": 10000, "score": 5, "title": 646612, "quality": 1, "rewards": [{"amount": 1, "item_type": 54650, "is_soul_bound": 1}], "conditions": [], "event_type": 10100, "description": 646611, "record_type": 10104, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
1	10002	{"_key": 10002, "group": 10000, "score": 10, "title": 646648, "quality": 2, "rewards": [{"amount": 1, "item_type": 77109, "is_soul_bound": 1}], "conditions": [], "event_type": 10100, "description": 646647, "record_type": 10104, "max_progress": 10, "abort_conditions": [], "contrast_conditions": []}
2	10003	{"_key": 10003, "group": 10000, "score": 15, "title": 646650, "quality": 3, "rewards": [], "conditions": [], "event_type": 10100, "description": 646649, "record_type": 10104, "max_progress": 100, "abort_conditions": [], "contrast_conditions": []}
3	10004	{"_key": 10004, "group": 10000, "score": 20, "title": 646652, "quality": 4, "rewards": [], "conditions": [], "event_type": 10100, "description": 646651, "record_type": 10104, "max_progress": 1000, "abort_conditions": [], "contrast_conditions": []}
4	10101	{"_key": 10101, "group": 10100, "score": 5, "title": 646654, "quality": 1, "rewards": [], "conditions": [], "event_type": 10100, "description": 646653, "record_type": 10104, "max_progress": 2, "abort_conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 2}], "contrast_conditions": []}
5	10102	{"_key": 10102, "group": 10100, "score": 10, "title": 646656, "quality": 2, "rewards": [{"amount": 1, "item_type": 54373, "is_soul_bound": 1}], "conditions": [], "event_type": 10100, "description": 646655, "record_type": 10104, "max_progress": 5, "abort_conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 2}], "contrast_conditions": []}
6	10103	{"_key": 10103, "group": 10100, "score": 15, "title": 646658, "quality": 2, "rewards": [{"amount": 1, "item_type": 54379, "is_soul_bound": 1}], "conditions": [], "event_type": 10100, "description": 646657, "record_type": 10104, "max_progress": 8, "abort_conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 2}], "contrast_conditions": []}
7	10104	{"_key": 10104, "group": 10100, "score": 20, "title": 646660, "quality": 2, "rewards": [], "conditions": [], "event_type": 10100, "description": 646659, "record_type": 10104, "max_progress": 15, "abort_conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 2}], "contrast_conditions": []}
8	10201	{"_key": 10201, "group": 10200, "score": 5, "title": 646662, "quality": 1, "rewards": [{"amount": 1, "item_type": 54650, "is_soul_bound": 1}], "conditions": [{"value": 6, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646661, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
9	10202	{"_key": 10202, "group": 10200, "score": 10, "title": 646664, "quality": 2, "rewards": [{"amount": 1, "item_type": 77111, "is_soul_bound": 1}], "conditions": [{"value": 6, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646663, "max_progress": 5, "abort_conditions": [], "contrast_conditions": []}
10	10203	{"_key": 10203, "group": 10200, "score": 15, "title": 646666, "quality": 3, "rewards": [], "conditions": [{"value": 6, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646665, "max_progress": 20, "abort_conditions": [], "contrast_conditions": []}
11	10204	{"_key": 10204, "group": 10200, "score": 20, "title": 646668, "quality": 4, "rewards": [{"amount": 1, "item_type": 47476, "is_soul_bound": 1}], "conditions": [{"value": 6, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646667, "max_progress": 100, "abort_conditions": [], "contrast_conditions": []}
12	10301	{"_key": 10301, "group": 10300, "score": 5, "title": 646678, "quality": 1, "rewards": [], "conditions": [{"value": 3, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646677, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
13	10302	{"_key": 10302, "group": 10300, "score": 10, "title": 646680, "quality": 2, "rewards": [], "conditions": [{"value": 3, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646679, "max_progress": 5, "abort_conditions": [], "contrast_conditions": []}
14	10303	{"_key": 10303, "group": 10300, "score": 15, "title": 646682, "quality": 3, "rewards": [{"amount": 1, "item_type": 47475, "is_soul_bound": 0}], "conditions": [{"value": 3, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646681, "max_progress": 20, "abort_conditions": [], "contrast_conditions": []}
15	10304	{"_key": 10304, "group": 10300, "score": 20, "title": 646684, "quality": 4, "rewards": [], "conditions": [{"value": 3, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646683, "max_progress": 100, "abort_conditions": [], "contrast_conditions": []}
16	10401	{"_key": 10401, "group": 10400, "score": 5, "title": 646686, "quality": 1, "rewards": [{"amount": 1, "item_type": 52520, "is_soul_bound": 1}], "conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 1}], "event_type": 10100, "description": 646685, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
17	10402	{"_key": 10402, "group": 10400, "score": 10, "title": 646688, "quality": 2, "rewards": [{"amount": 1, "item_type": 77110, "is_soul_bound": 1}], "conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 1}], "event_type": 10100, "description": 646687, "max_progress": 5, "abort_conditions": [], "contrast_conditions": []}
18	10403	{"_key": 10403, "group": 10400, "score": 15, "title": 646690, "quality": 3, "rewards": [], "conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 1}], "event_type": 10100, "description": 646689, "max_progress": 20, "abort_conditions": [], "contrast_conditions": []}
19	10404	{"_key": 10404, "group": 10400, "score": 20, "title": 646692, "quality": 4, "rewards": [], "conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 1}], "event_type": 10100, "description": 646691, "max_progress": 100, "abort_conditions": [], "contrast_conditions": []}
20	10501	{"_key": 10501, "group": 10500, "score": 5, "title": 646694, "quality": 1, "rewards": [{"amount": 1, "item_type": 77112, "is_soul_bound": 1}], "conditions": [{"value": 6, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646693, "max_progress": 4, "abort_conditions": [{"value": 6, "event_param": 10105, "param_value": 0, "condition_type": 2}], "contrast_conditions": []}
21	10502	{"_key": 10502, "group": 10500, "score": 10, "title": 646696, "quality": 2, "rewards": [], "conditions": [{"value": 6, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646695, "max_progress": 6, "abort_conditions": [{"value": 6, "event_param": 10105, "param_value": 0, "condition_type": 2}], "contrast_conditions": []}
22	10503	{"_key": 10503, "group": 10500, "score": 15, "title": 646698, "quality": 3, "rewards": [], "conditions": [{"value": 6, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646697, "max_progress": 8, "abort_conditions": [{"value": 6, "event_param": 10105, "param_value": 0, "condition_type": 2}], "contrast_conditions": []}
23	10504	{"_key": 10504, "group": 10500, "score": 20, "title": 646700, "quality": 4, "rewards": [], "conditions": [{"value": 6, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646699, "max_progress": 10, "abort_conditions": [{"value": 6, "event_param": 10105, "param_value": 0, "condition_type": 1}], "contrast_conditions": []}
24	10601	{"_key": 10601, "group": 10600, "score": 5, "title": 646702, "quality": 1, "rewards": [{"amount": 1, "item_type": 77108, "is_soul_bound": 1}], "conditions": [{"value": 3, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646701, "max_progress": 3, "abort_conditions": [{"value": 3, "event_param": 10105, "param_value": 0, "condition_type": 2}], "contrast_conditions": []}
25	10602	{"_key": 10602, "group": 10600, "score": 10, "title": 646704, "quality": 2, "rewards": [], "conditions": [{"value": 3, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646703, "max_progress": 5, "abort_conditions": [{"value": 3, "event_param": 10105, "param_value": 0, "condition_type": 2}], "contrast_conditions": []}
26	10603	{"_key": 10603, "group": 10600, "score": 15, "title": 646706, "quality": 3, "rewards": [], "conditions": [{"value": 3, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646705, "max_progress": 7, "abort_conditions": [{"value": 3, "event_param": 10105, "param_value": 0, "condition_type": 2}], "contrast_conditions": []}
27	10604	{"_key": 10604, "group": 10600, "score": 20, "title": 646708, "quality": 4, "rewards": [], "conditions": [{"value": 3, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646707, "max_progress": 9, "abort_conditions": [{"value": 3, "event_param": 10105, "param_value": 0, "condition_type": 2}], "contrast_conditions": []}
28	10701	{"_key": 10701, "group": 10700, "score": 5, "title": 646710, "quality": 1, "rewards": [{"amount": 1, "item_type": 54367, "is_soul_bound": 1}], "conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 1}], "event_type": 10100, "description": 646709, "max_progress": 2, "abort_conditions": [{"value": 1, "event_param": 10101, "param_value": 0, "condition_type": 2}], "contrast_conditions": []}
29	10702	{"_key": 10702, "group": 10700, "score": 10, "title": 646712, "quality": 2, "rewards": [{"amount": 1, "item_type": 49810, "is_soul_bound": 1}], "conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 1}], "event_type": 10100, "description": 646711, "max_progress": 3, "abort_conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 2}], "contrast_conditions": []}
30	10703	{"_key": 10703, "group": 10700, "score": 15, "title": 646714, "quality": 3, "rewards": [{"amount": 1, "item_type": 54361, "is_soul_bound": 1}], "conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 1}], "event_type": 10100, "description": 646713, "max_progress": 4, "abort_conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 2}], "contrast_conditions": []}
31	10704	{"_key": 10704, "group": 10700, "score": 20, "title": 646716, "quality": 4, "rewards": [], "conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 1}], "event_type": 10100, "description": 646715, "max_progress": 5, "abort_conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 2}], "contrast_conditions": []}
32	10801	{"_key": 10801, "group": 10800, "score": 5, "title": 646718, "quality": 1, "rewards": [{"amount": 1, "item_type": 54650, "is_soul_bound": 1}], "conditions": [{"value": 3000, "event_param": 10106, "param_value": 0, "condition_type": 4}], "event_type": 10100, "description": 646717, "record_type": 10106, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
33	10802	{"_key": 10802, "group": 10800, "score": 10, "title": 646720, "quality": 2, "rewards": [], "conditions": [{"value": 10000, "event_param": 10106, "param_value": 0, "condition_type": 4}], "event_type": 10100, "description": 646719, "record_type": 10106, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
34	10803	{"_key": 10803, "group": 10800, "score": 15, "title": 646722, "quality": 3, "rewards": [{"amount": 1, "item_type": 77106, "is_soul_bound": 1}], "conditions": [{"value": 30000, "event_param": 10106, "param_value": 0, "condition_type": 4}], "event_type": 10100, "description": 646721, "record_type": 10106, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
35	10804	{"_key": 10804, "group": 10800, "score": 20, "title": 646724, "quality": 4, "rewards": [], "conditions": [{"value": 60000, "event_param": 10106, "param_value": 0, "condition_type": 4}], "event_type": 10100, "description": 646723, "record_type": 10106, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
36	10901	{"_key": 10901, "group": 10900, "score": 5, "title": 646726, "quality": 1, "rewards": [], "conditions": [{"value": 6000, "event_param": 10107, "param_value": 0, "condition_type": 4}], "event_type": 10100, "description": 646725, "record_type": 10107, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
37	10902	{"_key": 10902, "group": 10900, "score": 10, "title": 646728, "quality": 2, "rewards": [], "conditions": [{"value": 15000, "event_param": 10107, "param_value": 0, "condition_type": 4}], "event_type": 10100, "description": 646727, "record_type": 10107, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
38	10903	{"_key": 10903, "group": 10900, "score": 15, "title": 646730, "quality": 3, "rewards": [], "conditions": [{"value": 30000, "event_param": 10107, "param_value": 0, "condition_type": 4}], "event_type": 10100, "description": 646729, "record_type": 10107, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
39	10904	{"_key": 10904, "group": 10900, "score": 20, "title": 646732, "quality": 4, "rewards": [{"amount": 1, "item_type": 52520, "is_soul_bound": 1}], "conditions": [{"value": 50000, "event_param": 10107, "param_value": 0, "condition_type": 4}], "event_type": 10100, "description": 646731, "record_type": 10107, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
40	11001	{"_key": 11001, "group": 11000, "score": 5, "title": 646734, "quality": 1, "rewards": [], "conditions": [], "event_type": 10100, "description": 646733, "record_type": 10106, "max_progress": 20000, "abort_conditions": [], "contrast_conditions": []}
41	11002	{"_key": 11002, "group": 11000, "score": 10, "title": 646736, "quality": 2, "rewards": [{"amount": 1, "item_type": 52520, "is_soul_bound": 1}], "conditions": [], "event_type": 10100, "description": 646735, "record_type": 10106, "max_progress": 100000, "abort_conditions": [], "contrast_conditions": []}
42	11003	{"_key": 11003, "group": 11000, "score": 15, "title": 646738, "quality": 3, "rewards": [{"amount": 1, "item_type": 77107, "is_soul_bound": 1}], "conditions": [], "event_type": 10100, "description": 646737, "record_type": 10106, "max_progress": 500000, "abort_conditions": [], "contrast_conditions": []}
43	11004	{"_key": 11004, "group": 11000, "score": 20, "title": 646740, "quality": 4, "rewards": [], "conditions": [], "event_type": 10100, "description": 646739, "record_type": 10106, "max_progress": 2000000, "abort_conditions": [], "contrast_conditions": []}
44	11101	{"_key": 11101, "group": 11100, "score": 5, "title": 646742, "quality": 1, "rewards": [], "conditions": [], "event_type": 10100, "description": 646741, "record_type": 10107, "max_progress": 20000, "abort_conditions": [], "contrast_conditions": []}
45	11102	{"_key": 11102, "group": 11100, "score": 10, "title": 646744, "quality": 2, "rewards": [{"amount": 1, "item_type": 52520, "is_soul_bound": 1}], "conditions": [], "event_type": 10100, "description": 646743, "record_type": 10107, "max_progress": 100000, "abort_conditions": [], "contrast_conditions": []}
46	11103	{"_key": 11103, "group": 11100, "score": 15, "title": 646746, "quality": 3, "rewards": [{"amount": 1, "item_type": 77105, "is_soul_bound": 1}], "conditions": [], "event_type": 10100, "description": 646745, "record_type": 10107, "max_progress": 500000, "abort_conditions": [], "contrast_conditions": []}
47	11104	{"_key": 11104, "group": 11100, "score": 20, "title": 646748, "quality": 4, "rewards": [], "conditions": [], "event_type": 10100, "description": 646747, "record_type": 10107, "max_progress": 2000000, "abort_conditions": [], "contrast_conditions": []}
48	11201	{"_key": 11201, "group": 11200, "score": 10, "title": 646750, "quality": 2, "rewards": [{"amount": 1, "item_type": 52520, "is_soul_bound": 1}], "conditions": [{"value": 3, "event_param": 10104, "param_value": 0, "condition_type": 4}], "event_type": 10100, "description": 646749, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
49	11202	{"_key": 11202, "group": 11200, "score": 15, "title": 646752, "quality": 3, "rewards": [], "conditions": [{"value": 6, "event_param": 10104, "param_value": 0, "condition_type": 4}], "event_type": 10100, "description": 646751, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
50	11301	{"_key": 11301, "group": 11300, "score": 5, "title": 646754, "quality": 1, "rewards": [], "conditions": [], "event_type": 10100, "description": 646753, "record_type": 10117, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
51	11401	{"_key": 11401, "group": 11400, "score": 5, "title": 646757, "quality": 1, "rewards": [], "conditions": [{"value": 6, "event_param": 10110, "param_value": 0, "condition_type": 4}], "event_type": 10100, "description": 646756, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
52	11402	{"_key": 11402, "group": 11400, "score": 15, "title": 646759, "quality": 3, "rewards": [], "conditions": [{"value": 6, "event_param": 10111, "param_value": 0, "condition_type": 4}], "event_type": 10100, "description": 646758, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
53	11501	{"_key": 11501, "group": 11500, "score": 10, "title": 646761, "quality": 2, "rewards": [], "conditions": [{"value": 0, "event_param": 10112, "param_value": 0, "condition_type": 1}, {"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 1}], "event_type": 10100, "description": 646760, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
54	11601	{"_key": 11601, "group": 11600, "score": 5, "title": 646763, "quality": 1, "rewards": [], "conditions": [{"value": 2, "event_param": 10113, "param_value": 0, "condition_type": 4}], "event_type": 10100, "description": 646762, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
55	11602	{"_key": 11602, "group": 11600, "score": 15, "title": 646765, "quality": 3, "rewards": [{"amount": 1, "item_type": 52520, "is_soul_bound": 1}], "conditions": [{"value": 4, "event_param": 10113, "param_value": 0, "condition_type": 4}], "event_type": 10100, "description": 646764, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
56	11701	{"_key": 11701, "group": 11700, "score": 5, "title": 646767, "quality": 1, "rewards": [{"amount": 1, "item_type": 52520, "is_soul_bound": 1}], "conditions": [], "event_type": 10100, "description": 646766, "record_type": 10116, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
57	11801	{"_key": 11801, "group": 11800, "score": 5, "title": 646769, "quality": 1, "rewards": [], "conditions": [{"value": 0, "event_param": 10109, "param_value": 0, "condition_type": 1}, {"value": 6, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646768, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
58	11802	{"_key": 11802, "group": 11800, "score": 10, "title": 646771, "quality": 2, "rewards": [], "conditions": [{"value": 0, "event_param": 10109, "param_value": 0, "condition_type": 1}, {"value": 3, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646770, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
59	11803	{"_key": 11803, "group": 11800, "score": 20, "title": 646773, "quality": 4, "rewards": [{"amount": 1, "item_type": 49809, "is_soul_bound": 1}], "conditions": [{"value": 0, "event_param": 10109, "param_value": 0, "condition_type": 1}, {"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 1}], "event_type": 10100, "description": 646772, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
60	11901	{"_key": 11901, "group": 11900, "score": 10, "title": 646775, "quality": 2, "rewards": [], "conditions": [{"value": 9, "event_param": 10115, "param_value": 0, "condition_type": 4}], "event_type": 10100, "description": 646774, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
61	12001	{"_key": 12001, "group": 12000, "score": 5, "title": 646777, "quality": 1, "rewards": [], "conditions": [{"value": 0, "event_param": 10106, "param_value": 0, "condition_type": 1}, {"value": 6, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646776, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
62	12002	{"_key": 12002, "group": 12000, "score": 10, "title": 646779, "quality": 2, "rewards": [], "conditions": [{"value": 0, "event_param": 10106, "param_value": 0, "condition_type": 1}, {"value": 3, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646778, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
63	12003	{"_key": 12003, "group": 12000, "score": 20, "title": 646781, "quality": 4, "rewards": [{"amount": 1, "item_type": 49809, "is_soul_bound": 1}], "conditions": [{"value": 0, "event_param": 10106, "param_value": 0, "condition_type": 1}, {"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 1}], "event_type": 10100, "description": 646780, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
64	12101	{"_key": 12101, "group": 12100, "score": 5, "title": 646783, "quality": 1, "rewards": [{"amount": 1, "item_type": 54650, "is_soul_bound": 1}], "conditions": [], "event_type": 10100, "description": 646782, "max_progress": 1, "abort_conditions": [], "contrast_conditions": [{"value": 3, "event_param": 10103}]}
65	12102	{"_key": 12102, "group": 12100, "score": 10, "title": 646785, "quality": 2, "rewards": [{"amount": 1, "item_type": 52520, "is_soul_bound": 1}], "conditions": [{"value": 6, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646784, "max_progress": 1, "abort_conditions": [], "contrast_conditions": [{"value": 3, "event_param": 10103}]}
66	12103	{"_key": 12103, "group": 12100, "score": 15, "title": 646788, "quality": 3, "rewards": [], "conditions": [{"value": 3, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646787, "max_progress": 1, "abort_conditions": [], "contrast_conditions": [{"value": 3, "event_param": 10103}]}
67	12104	{"_key": 12104, "group": 12100, "score": 20, "title": 646790, "quality": 4, "rewards": [], "conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 1}], "event_type": 10100, "description": 646789, "max_progress": 1, "abort_conditions": [], "contrast_conditions": [{"value": 3, "event_param": 10103}]}
68	12201	{"_key": 12201, "group": 12200, "score": 5, "title": 646792, "quality": 1, "rewards": [], "conditions": [{"value": 1, "event_param": 10114, "param_value": 24563, "condition_type": 4}], "event_type": 10100, "description": 646791, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
69	12202	{"_key": 12202, "group": 12200, "score": 15, "title": 646794, "quality": 3, "rewards": [], "conditions": [{"value": 3, "event_param": 10114, "param_value": 24563, "condition_type": 4}], "event_type": 10100, "description": 646793, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
70	12301	{"_key": 12301, "group": 12300, "score": 5, "title": 646796, "quality": 1, "rewards": [], "conditions": [{"value": 1, "event_param": 10114, "param_value": 3421, "condition_type": 4}], "event_type": 10100, "description": 646795, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
71	12302	{"_key": 12302, "group": 12300, "score": 15, "title": 646798, "quality": 3, "rewards": [], "conditions": [{"value": 3, "event_param": 10114, "param_value": 3421, "condition_type": 4}], "event_type": 10100, "description": 646797, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
72	12401	{"_key": 12401, "group": 12400, "score": 10, "title": 646800, "quality": 2, "rewards": [], "conditions": [{"value": 1, "event_param": 10108, "param_value": 0, "condition_type": 1}, {"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 1}], "event_type": 10100, "description": 646799, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
73	12501	{"_key": 12501, "group": 12500, "score": 5, "title": 648423, "quality": 1, "rewards": [], "conditions": [], "event_type": 10100, "description": 648422, "max_progress": 1, "abort_conditions": [], "contrast_conditions": []}
74	12601	{"_key": 12601, "group": 12600, "score": 125, "title": 655905, "quality": 1, "rewards": [{"amount": 1, "item_type": 54650, "is_soul_bound": 1}], "conditions": [], "event_type": 10100, "description": 655904, "max_progress": 0, "abort_conditions": [], "contrast_conditions": []}
\.


--
-- Name: brawlachievements brawlachievements_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.brawlachievements
    ADD CONSTRAINT brawlachievements_pkey PRIMARY KEY (row_no);


--
-- Name: brawlachievements_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX brawlachievements_key_idx ON sde_native.brawlachievements USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 7ta8KFNt9j5idngECYfco1Lwu1cKGiwNtIwrNgBrWWaWkreKfGQydIFuhiLZ3Ej

