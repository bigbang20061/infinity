--
-- PostgreSQL database dump
--

\restrict s4a6Nma4CVCKMZSpTJENNhc3SjjRTqruPGcNKuhdoq1knhX5DqQDbaVBR8KVDZT

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: recruitmenttypes; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.recruitmenttypes (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: recruitmenttypes; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.recruitmenttypes (row_no, key, data) FROM stdin;
0	0	{"_key": 0, "nameID": 233764, "descriptionID": 233779, "recruitmentGroupID": 80}
1	1	{"_key": 1, "nameID": 263166, "descriptionID": 263167, "recruitmentGroupID": 10}
2	2	{"_key": 2, "nameID": 282451, "recruitmentGroupID": 11}
3	3	{"_key": 3, "nameID": 59696, "descriptionID": 59669, "recruitmentGroupID": 8}
4	4	{"_key": 4, "nameID": 59699, "descriptionID": 59672, "recruitmentGroupID": 8}
5	5	{"_key": 5, "nameID": 59697, "descriptionID": 59670, "recruitmentGroupID": 8}
6	6	{"_key": 6, "nameID": 59698, "descriptionID": 59671, "recruitmentGroupID": 8}
7	7	{"_key": 7, "nameID": 59673, "recruitmentGroupID": 10}
8	8	{"_key": 8, "nameID": 59674, "recruitmentGroupID": 10}
9	9	{"_key": 9, "nameID": 59675, "recruitmentGroupID": 10}
10	10	{"_key": 10, "nameID": 59676, "recruitmentGroupID": 10}
11	11	{"_key": 11, "nameID": 59677, "recruitmentGroupID": 10}
12	12	{"_key": 12, "nameID": 59688, "recruitmentGroupID": 6}
13	13	{"_key": 13, "nameID": 282452, "recruitmentGroupID": 11}
14	14	{"_key": 14, "nameID": 282453, "descriptionID": 588591, "recruitmentGroupID": 79}
15	15	{"_key": 15, "nameID": 286795, "descriptionID": 588592, "recruitmentGroupID": 79}
16	16	{"_key": 16, "nameID": 588595, "recruitmentGroupID": 11}
17	17	{"_key": 17, "nameID": 588596, "recruitmentGroupID": 11}
18	18	{"_key": 18, "nameID": 588597, "recruitmentGroupID": 11}
19	19	{"_key": 19, "nameID": 588598, "recruitmentGroupID": 11}
20	20	{"_key": 20, "nameID": 588599, "recruitmentGroupID": 11}
21	21	{"_key": 21, "nameID": 588600, "recruitmentGroupID": 11}
22	22	{"_key": 22, "nameID": 588601, "recruitmentGroupID": 11}
23	23	{"_key": 23, "nameID": 588602, "recruitmentGroupID": 80}
24	24	{"_key": 24, "nameID": 59678, "recruitmentGroupID": 11}
25	25	{"_key": 25, "nameID": 59679, "recruitmentGroupID": 11}
26	26	{"_key": 26, "nameID": 59680, "recruitmentGroupID": 11}
27	27	{"_key": 27, "nameID": 59687, "descriptionID": 59668, "recruitmentGroupID": 12}
28	28	{"_key": 28, "nameID": 59681, "recruitmentGroupID": 11}
29	29	{"_key": 29, "nameID": 59682, "recruitmentGroupID": 11}
30	30	{"_key": 30, "nameID": 59686, "descriptionID": 59667, "recruitmentGroupID": 12}
31	31	{"_key": 31, "nameID": 59683, "recruitmentGroupID": 11}
32	32	{"_key": 32, "nameID": 59684, "descriptionID": 588593, "recruitmentGroupID": 79}
33	33	{"_key": 33, "nameID": 59685, "descriptionID": 588594, "recruitmentGroupID": 79}
34	34	{"_key": 34, "nameID": 59695, "recruitmentGroupID": 80}
35	35	{"_key": 35, "nameID": 588603, "recruitmentGroupID": 11}
36	36	{"_key": 36, "nameID": 588604, "recruitmentGroupID": 11}
37	37	{"_key": 37, "nameID": 59692, "recruitmentGroupID": 6}
38	38	{"_key": 38, "nameID": 59693, "recruitmentGroupID": 6}
39	39	{"_key": 39, "nameID": 59694, "recruitmentGroupID": 6}
40	40	{"_key": 40, "nameID": 588605, "recruitmentGroupID": 11}
41	41	{"_key": 41, "nameID": 588606, "recruitmentGroupID": 11}
42	42	{"_key": 42, "nameID": 588607, "recruitmentGroupID": 10}
43	43	{"_key": 43, "nameID": 588608, "recruitmentGroupID": 11}
44	44	{"_key": 44, "nameID": 588609, "recruitmentGroupID": 11}
\.


--
-- Name: recruitmenttypes recruitmenttypes_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.recruitmenttypes
    ADD CONSTRAINT recruitmenttypes_pkey PRIMARY KEY (row_no);


--
-- Name: recruitmenttypes_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX recruitmenttypes_key_idx ON sde_native.recruitmenttypes USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict s4a6Nma4CVCKMZSpTJENNhc3SjjRTqruPGcNKuhdoq1knhX5DqQDbaVBR8KVDZT

