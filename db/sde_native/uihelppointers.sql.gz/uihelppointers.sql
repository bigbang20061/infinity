--
-- PostgreSQL database dump
--

\restrict bWDC4c24FMfl0x6wmCWttxQV0j1NMRwdIz824U4cKXREHZou3U9OG6smcnA0mg1

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: uihelppointers; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.uihelppointers (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: uihelppointers; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.uihelppointers (row_no, key, data) FROM stdin;
0	4	{"_key": 4, "title": 571259, "texturePath": "res:/UI/Texture/classes/Fleet/Broadcast/32/needShield.png", "internalName": "pointerBroadcastNeedShield", "isMenuOption": 0, "pointerScope": ["Fleet"], "uiElementName": "unique_UI_broadcastNeedShield"}
1	5	{"_key": 5, "title": 571424, "internalName": "pointerOverview", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_overviewWnd"}
2	6	{"_key": 6, "title": 571425, "iconDataName": "eveicon.more_vertical", "internalName": "pointerOverviewSettings", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_overviewHeaderIcon"}
3	7	{"_key": 7, "title": 571426, "internalName": "pointerCapacitor", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_CapacitorContainer"}
4	8	{"_key": 8, "title": 571427, "offset": -40, "internalName": "pointerModuleSlots", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_slotsContainer"}
5	9	{"_key": 9, "title": 571428, "texturePath": "res:/UI/Texture/classes/ShipUI/minus.png", "internalName": "pointerStopShip", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_StopButton"}
6	10	{"_key": 10, "title": 571429, "iconID": 26275, "internalName": "pointerUndockBtn", "isMenuOption": 0, "pointerScope": ["Docked"], "uiElementName": "unique_UI_undockBtn"}
7	11	{"_key": 11, "title": 571430, "internalName": "pointerInfoPanel", "isMenuOption": 0, "uiElementName": "unique_UI_infoPanelContainer"}
8	12	{"_key": 12, "title": 571431, "texturePath": "res:/UI/Texture/icons/79_64_11.png", "internalName": "pointerNeocomeMenu", "isMenuOption": 0, "uiElementName": "eveMenuBtn"}
9	13	{"_key": 13, "title": 571432, "internalName": "pointerNeocom", "isMenuOption": 0, "uiElementName": "unique_UI_Neocom", "defaultDirection": 3}
10	14	{"_key": 14, "title": 571433, "iconID": 26278, "internalName": "pointerChat", "isMenuOption": 0, "uiElementName": "unique_UI_localChat", "defaultDirection": 2}
11	15	{"_key": 15, "title": 571434, "offset": 10, "internalName": "pointerStationServices", "isMenuOption": 0, "pointerScope": ["Docked"], "uiElementName": "serviceButtons", "defaultDirection": 1}
12	16	{"_key": 16, "title": 571435, "texturePath": "res:/UI/Texture/Icons/44_32_12.png", "internalName": "pointerAutopilot", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_inFlightAutopilotBtn"}
13	17	{"_key": 17, "title": 571436, "texturePath": "res:/UI/Texture/Classes/InfoPanels/Route.png", "internalName": "pointerAutopilotSettings", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_autopilotSettings"}
14	18	{"_key": 18, "title": 571437, "texturePath": "res:/UI/Texture/classes/SensorSuite/radar.png", "internalName": "pointerScanners", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_inFlightScannerBtn"}
15	19	{"_key": 19, "title": 571438, "texturePath": "res:/UI/Texture/Icons/44_32_42.png", "internalName": "pointerTacticalOverlay", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_inFlightTacticalBtn"}
16	20	{"_key": 20, "title": 571439, "texturePath": "res:/UI/Texture/icons/44_32_10.png", "internalName": "pointerCargoHoldButton", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_inFlightCargoBtn"}
17	21	{"_key": 21, "title": 571440, "texturePath": "res:/UI/Texture/classes/ShipUI/iconCameraGrid.png", "internalName": "pointerTacticalCamera", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_cameraButtonTactical"}
18	22	{"_key": 22, "title": 571441, "texturePath": "res:/UI/Texture/classes/ShipUI/iconCameraOrbit.png", "internalName": "pointerOrbitCamera", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_cameraButtonOrbit"}
19	23	{"_key": 23, "title": 571442, "texturePath": "res:/UI/Texture/classes/ShipUI/iconCameraFirstPerson.png", "internalName": "pointerFirstPersonCamera", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_cameraButtonPOV"}
20	24	{"_key": 24, "title": 571443, "iconID": 24655, "internalName": "pointerHudSettings", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_hudSettingsMenu"}
21	25	{"_key": 25, "title": 571444, "internalName": "pointerSafety", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_SafetyButton"}
22	26	{"_key": 26, "title": 571445, "texturePath": "res:/UI/Texture/classes/Notifications/widgetIcon.png", "internalName": "pointerNotificationFeed", "isMenuOption": 0, "uiElementName": "unique_UI_notificationFeed"}
23	27	{"_key": 27, "title": 571446, "iconDataName": "eveicon.more_vertical", "internalName": "pointerFleetSettings", "isMenuOption": 0, "uiElementName": "unique_UI_fleetSettings"}
24	28	{"_key": 28, "title": 571447, "internalName": "pointerDroneWindow", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_droneView"}
25	29	{"_key": 29, "title": 571448, "iconDataName": "eveicon.more_vertical", "internalName": "pointerDroneSettings", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_droneSettingIcon"}
26	30	{"_key": 30, "title": 571449, "internalName": "pointerFleetBroadcastingIcons", "isMenuOption": 0, "pointerScope": ["Fleet"], "uiElementName": "unique_UI_fleetBroadcastIcons"}
27	31	{"_key": 31, "title": 571450, "internalName": "pointerEffectsBar", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_buffBarContainer"}
28	32	{"_key": 32, "title": 571451, "internalName": "pointerClockAndCalendar", "isMenuOption": 0, "uiElementName": "unique_UI_clockAndCalendar"}
29	33	{"_key": 33, "title": 571452, "iconDataName": "eveicon.add", "internalName": "pointerChannelWindow", "isMenuOption": 0, "uiElementName": "unique_UI_channelWindow"}
30	34	{"_key": 34, "title": 571454, "message": 571453, "internalName": "pointerCurrentFit", "isMenuOption": 0, "uiElementName": "unique_UI_currentFit"}
31	35	{"_key": 35, "title": 571455, "internalName": "pointerSkillqueue", "isMenuOption": 0, "uiElementName": "unique_UI_skillqueue"}
32	36	{"_key": 36, "title": 571456, "iconID": 26278, "internalName": "pointerPilotServices", "isMenuOption": 0, "uiElementName": "unique_UI_pilotServicesTab", "defaultDirection": 2}
33	37	{"_key": 37, "title": 571457, "iconID": 26278, "internalName": "pointerAugmentationsTab", "isMenuOption": 0, "uiElementName": "unique_UI_augmentationsTab", "defaultDirection": 2}
34	38	{"_key": 38, "title": 571458, "iconID": 26278, "internalName": "pointerStandingsTabInCharactersheet", "isMenuOption": 0, "uiElementName": "unique_UI_standingsTabInCharactersheet", "defaultDirection": 2}
35	39	{"_key": 39, "title": 571459, "texturePath": "res:/UI/Texture/Icons/44_32_17.png", "internalName": "pointerTargetAnchor", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_targetAnchor"}
36	40	{"_key": 40, "title": 571460, "texturePath": "res:/UI/Texture/eveicon/system_icons/grid_view_16px.png", "internalName": "pointerInventoryListView", "isMenuOption": 0, "uiElementName": "unique_UI_inventoryListView"}
37	41	{"_key": 41, "title": 571461, "iconID": 26275, "internalName": "pointerFitsInFittingWnd", "isMenuOption": 0, "uiElementName": "unique_UI_fitsInFittingWnd", "defaultDirection": 2}
38	43	{"_key": 43, "title": 571463, "internalName": "pointerMyApplications", "isMenuOption": 0, "uiElementName": "unique_UI_myApplications"}
39	44	{"_key": 44, "title": 571464, "texturePath": "res:/UI/Texture/Icons/44_32_4.png", "iconDataName": "eveicon.tune", "internalName": "pointerMapColorSettings", "isMenuOption": 0, "uiElementName": "unique_UI_mapColorSettings"}
40	45	{"_key": 45, "title": 571465, "iconID": 26278, "internalName": "pointerAvailableContractsTab", "isMenuOption": 0, "uiElementName": "unique_UI_availableContractsTab", "defaultDirection": 2}
41	46	{"_key": 46, "title": 571466, "internalName": "pointerContractAvailabilitySetting", "isMenuOption": 0, "uiElementName": "unique_UI_contractAvailabilitySetting"}
42	47	{"_key": 47, "title": 571467, "internalName": "pointerVariationTab", "isMenuOption": 0, "uiElementName": "unique_UI_variationTab", "defaultDirection": 2}
43	48	{"_key": 48, "title": 571468, "iconID": 26278, "internalName": "pointerFleetFinderTab", "isMenuOption": 0, "uiElementName": "unique_UI_fleetFinderTab", "defaultDirection": 2}
44	49	{"_key": 49, "title": 571469, "internalName": "pointerFleetFinderSettings", "isMenuOption": 0, "uiElementName": "unique_UI_fleetFinderSettings"}
45	50	{"_key": 50, "title": 571470, "internalName": "pointerRouteInInfoPanel", "isMenuOption": 0, "uiElementName": "unique_UI_routeInInfoPanel"}
46	51	{"_key": 51, "title": 571472, "internalName": "pointerNextInRoute", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_nextInRoute"}
47	52	{"_key": 52, "title": 571474, "texturePath": "res:/UI/Texture/Classes/ProbeScanner/16/recoverProbesIcon.png", "internalName": "pointerRecoverProbes", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_recoverProbes"}
48	53	{"_key": 53, "title": 571476, "internalName": "pointerFilterScanResults", "isMenuOption": 0, "uiElementName": "unique_UI_filterScanResults"}
49	54	{"_key": 54, "title": 571477, "internalName": "pointerProbeSizeModifier", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_probeSizeModifier"}
50	55	{"_key": 55, "title": 571480, "texturePath": "res:/UI/Texture/WindowIcons/corporation.png", "internalName": "pointerCorpFitFilter", "isMenuOption": 0, "uiElementName": "unique_UI_corpFitFilter"}
51	56	{"_key": 56, "title": 571482, "iconID": 26278, "internalName": "pointerFleetHistoryTab", "isMenuOption": 0, "pointerScope": ["Fleet"], "uiElementName": "unique_UI_fleetHistoryTab", "defaultDirection": 2}
52	57	{"_key": 57, "title": 571486, "internalName": "pointerFleetHistoryFilter", "isMenuOption": 0, "pointerScope": ["Fleet"], "uiElementName": "unique_UI_fleetHistoryFilter"}
53	58	{"_key": 58, "title": 571487, "texturePath": "res:/UI/Texture/classes/ShipUI/Fighters/toggleModules_Up.png", "internalName": "pointerFighterToggle", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_fighterToggle"}
54	59	{"_key": 59, "title": 571488, "texturePath": "res:/UI/Texture/classes/ShipUI/Fighters/positionFighters_Up.png", "internalName": "pointerFighterDetach", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_fighterDetach"}
55	60	{"_key": 60, "title": 571489, "texturePath": "res:/UI/Texture/classes/Fitting/tabCommunityFits.png", "internalName": "pointerCommunityFitFilter", "isMenuOption": 0, "uiElementName": "unique_UI_communityFitFilter"}
56	61	{"_key": 61, "title": 571490, "iconID": 24665, "internalName": "pointerFittingBrowser", "isMenuOption": 0, "uiElementName": "unique_UI_fittingBrowser"}
57	62	{"_key": 62, "title": 571491, "iconID": 26275, "internalName": "pointerCorvetteBtn", "isMenuOption": 0, "pointerScope": ["Docked"], "uiElementName": "unique_UI_corvetteBtn"}
58	63	{"_key": 63, "title": 571492, "internalName": "pointerSensorOverlay", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_sensorOverlay", "defaultDirection": 2}
59	64	{"_key": 64, "title": 571493, "internalName": "pointerInfoPanelBtns", "isMenuOption": 0, "uiElementName": "unique_UI_infoPanelBtns"}
60	65	{"_key": 65, "title": 571494, "texturePath": "res:/UI/Texture/Classes/InfoPanels/search.png", "internalName": "pointerSearchInfoPanel", "isMenuOption": 0, "uiElementName": "unique_UI_searchInfoPanel"}
61	66	{"_key": 66, "title": 571495, "internalName": "pointerInfoPanelLocation", "isMenuOption": 0, "uiElementName": "unique_UI_locationInfoPanel"}
62	67	{"_key": 67, "title": 571496, "internalName": "pointerMissionInfoPanel", "isMenuOption": 0, "uiElementName": "unique_UI_agentMissionInfoPanel"}
63	68	{"_key": 68, "title": 571497, "internalName": "pointerProbeFormations", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_probeFormationCont"}
64	69	{"_key": 69, "title": 571498, "texturePath": "res:/UI/Texture/Classes/InfoPanels/LocationInfo.png", "internalName": "pointerItemsInSystem", "isMenuOption": 0, "uiElementName": "unique_UI_itemsInSystem"}
65	70	{"_key": 70, "title": 571499, "offset": -12, "texturePath": "res:/UI/Texture/Icons/73_16_252.png", "internalName": "pointerGroupWeapons", "isMenuOption": 0, "uiElementName": "unique_UI_groupWeapons"}
66	71	{"_key": 71, "title": 571500, "internalName": "pointerSimulateShip", "isMenuOption": 0, "uiElementName": "unique_UI_simulateShip"}
67	73	{"_key": 73, "title": 571502, "iconID": 26278, "internalName": "pointerCharactersheetCharacterTab", "isMenuOption": 0, "uiElementName": "unique_UI_charactersheetCharacterTab", "defaultDirection": 2}
68	75	{"_key": 75, "title": 571504, "iconID": 26278, "internalName": " pointerCharactersheetInteractionTab", "isMenuOption": 0, "uiElementName": "unique_UI_charactersheetInteractionTab", "defaultDirection": 2}
69	76	{"_key": 76, "title": 572422, "texturePath": "res:/UI/Texture/classes/Fleet/Broadcast/32/needArmor.png", "internalName": "pointerBroadcastNeedArmor", "isMenuOption": 0, "pointerScope": ["Fleet"], "uiElementName": "unique_UI_broadcastNeedArmor"}
70	79	{"_key": 79, "title": 576686, "iconID": 26278, "internalName": "pointerIndustryFacilitiesTab", "isMenuOption": 0, "uiElementName": "unique_UI_industryFacilitiesTab", "defaultDirection": 2}
71	80	{"_key": 80, "title": 576687, "iconID": 26278, "internalName": "pointerIndustryJobsTab", "isMenuOption": 0, "uiElementName": "unique_UI_industryJobsTab", "defaultDirection": 2}
72	81	{"_key": 81, "title": 576688, "iconID": 24657, "internalName": "pointerIndustryCopyBtn", "isMenuOption": 0, "uiElementName": "unique_UI_industryCopyBtn", "defaultDirection": 2}
73	82	{"_key": 82, "title": 576689, "iconID": 24656, "internalName": "pointerManufacturingBtn", "isMenuOption": 0, "uiElementName": "unique_UI_manufacturingBtn", "defaultDirection": 2}
74	83	{"_key": 83, "title": 576690, "iconID": 24658, "internalName": "pointerMaterialEfficiencyBtn", "isMenuOption": 0, "uiElementName": "unique_UI_materialEfficiencyBtn", "defaultDirection": 2}
75	84	{"_key": 84, "title": 576691, "iconID": 24659, "internalName": "pointerTimeEfficiencyBtn", "isMenuOption": 0, "uiElementName": "unique_UI_timeEfficiencyBtn", "defaultDirection": 2}
76	85	{"_key": 85, "title": 576692, "iconID": 24660, "internalName": "pointerInventionBtn", "isMenuOption": 0, "uiElementName": "unique_UI_inventionBtn", "defaultDirection": 2}
77	86	{"_key": 86, "title": 576693, "iconID": 26278, "internalName": "pointerMyFleetTab", "isMenuOption": 0, "pointerScope": ["Fleet"], "uiElementName": "unique_UI_myFleetTab", "defaultDirection": 2}
78	87	{"_key": 87, "title": 576694, "iconID": 26278, "internalName": "pointerActiveReclonersTab", "isMenuOption": 0, "pointerScope": ["Fleet"], "uiElementName": "unique_UI_activeReclonersTab", "defaultDirection": 2}
79	88	{"_key": 88, "title": 576695, "iconDataName": "eveicon.tune", "internalName": "pointerMarketBrowseSettings", "isMenuOption": 0, "uiElementName": "unique_UI_marketBrowseSettings", "defaultDirection": 2}
80	89	{"_key": 89, "title": 576696, "internalName": "pointerOrderDuration", "isMenuOption": 0, "uiElementName": "unique_UI_orderDuration", "defaultDirection": 2}
81	90	{"_key": 90, "title": 576697, "iconID": 24663, "internalName": "pointerFindTypeInBrowser", "isMenuOption": 0, "uiElementName": "unique_UI_findTypeInBrowser", "defaultDirection": 2}
82	91	{"_key": 91, "title": 576698, "internalName": "pointerBuyersList", "isMenuOption": 0, "uiElementName": "unique_UI_buyersList"}
83	92	{"_key": 92, "title": 576699, "internalName": "pointerSellersList", "isMenuOption": 0, "uiElementName": "unique_UI_sellersList"}
84	93	{"_key": 93, "title": 576700, "iconID": 26278, "internalName": "pointerFittingSkins", "isMenuOption": 0, "uiElementName": "unique_UI_fittingSkins", "defaultDirection": 2}
85	94	{"_key": 94, "title": 576701, "iconID": 24666, "internalName": "pointerDscanWnd", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_DscanWnd"}
86	95	{"_key": 95, "title": 576702, "iconID": 24667, "internalName": "pointerProbeScanner", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_probeScanner"}
87	96	{"_key": 96, "title": 576703, "iconID": 26278, "internalName": "pointerBookmarkLocations", "isMenuOption": 0, "uiElementName": "unique_UI_bookmarkLocations", "defaultDirection": 2}
88	98	{"_key": 98, "title": 588501, "internalName": "corp home", "isMenuOption": 0, "uiElementName": "unique_UI_corpHome", "defaultDirection": 2}
89	99	{"_key": 99, "title": 588502, "iconDataName": "eveicon.bulletins", "internalName": "pointerCorpBulletin", "isMenuOption": 0, "uiElementName": "unique_UI_corpBulletin", "defaultDirection": 2}
90	100	{"_key": 100, "title": 588503, "iconID": 26278, "internalName": "pointerJumpClones", "isMenuOption": 0, "uiElementName": "unique_UI_jumpClonesTab", "defaultDirection": 2}
91	101	{"_key": 101, "title": 588504, "internalName": "pointerReleaseControl", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_releaseControl"}
92	102	{"_key": 102, "title": 588505, "internalName": "pointerMarketSellersJumps", "isMenuOption": 0, "uiElementName": "unique_UI_marketSellersJumpsColumn", "defaultDirection": 2}
93	103	{"_key": 103, "title": 588506, "internalName": "pointerMarketSellersQty", "isMenuOption": 0, "uiElementName": "unique_UI_marketSellersQtyColumn", "defaultDirection": 2}
94	104	{"_key": 104, "title": 588507, "internalName": "pointerMarketSellersPrice", "isMenuOption": 0, "uiElementName": "unique_UI_marketSellersPriceColumn", "defaultDirection": 2}
95	105	{"_key": 105, "title": 588509, "internalName": "pointerMarketBuyersJumps", "isMenuOption": 0, "uiElementName": "unique_UI_marketBuyersJumpsColumn", "defaultDirection": 2}
96	106	{"_key": 106, "title": 588510, "internalName": "pointerMarketBuyersQty", "isMenuOption": 0, "uiElementName": "unique_UI_marketBuyersQtyColumn", "defaultDirection": 2}
97	107	{"_key": 107, "title": 588511, "internalName": "pointerMarketBuyersPrice", "isMenuOption": 0, "uiElementName": "unique_UI_marketBuyersPriceColumn", "defaultDirection": 2}
98	108	{"_key": 108, "title": 588512, "iconID": 26278, "internalName": "pointerMarketDetails", "isMenuOption": 0, "uiElementName": "unique_UI_marketDetailsTab", "defaultDirection": 2}
99	109	{"_key": 109, "title": 588513, "iconID": 26278, "internalName": "pointerMarketPriceHistory", "isMenuOption": 0, "uiElementName": "unique_UI_marketPriceHistoryTab", "defaultDirection": 2}
100	110	{"_key": 110, "title": 588514, "iconID": 26278, "internalName": "pointerMarketData", "isMenuOption": 0, "uiElementName": "unique_UI_marketDataTab", "defaultDirection": 2}
101	111	{"_key": 111, "title": 588515, "internalName": "pointerPreferShorter", "isMenuOption": 1, "uiElementName": "unique_UI_routePreferShorter"}
102	112	{"_key": 112, "title": 588524, "internalName": "pointerPreferShorter", "isMenuOption": 1, "uiElementName": "unique_UI_routePreferSafer"}
103	113	{"_key": 113, "title": 588525, "internalName": "pointerRouteIncludeJumpGates", "isMenuOption": 1, "uiElementName": "unique_UI_routeIncludeJumpGates"}
104	114	{"_key": 114, "title": 588698, "texturePath": "res:/UI/Texture/Shared/DarkStyle/forward.png", "internalName": "pointerExpandCharacterSheet", "isMenuOption": 0, "uiElementName": "unique_UI_expandCharacterSheet", "defaultDirection": 2}
105	116	{"_key": 116, "title": 636502, "iconID": 26278, "internalName": "home station tab", "isMenuOption": 0, "uiElementName": "unique_UI_homeTab", "defaultDirection": 2}
106	117	{"_key": 117, "title": 636503, "iconID": 26278, "internalName": "security status tab", "isMenuOption": 0, "uiElementName": "unique_UI_securityStatusTab", "defaultDirection": 2}
107	118	{"_key": 118, "title": 636504, "iconID": 26278, "internalName": "combat log tab", "isMenuOption": 0, "uiElementName": "unique_UI_combatLogTab", "defaultDirection": 2}
108	119	{"_key": 119, "title": 636505, "iconID": 26278, "internalName": "Show kills/losses", "isMenuOption": 0, "uiElementName": "unique_UI_showKillsLosses"}
109	120	{"_key": 120, "title": 636506, "iconID": 26278, "internalName": "kill rights tab", "isMenuOption": 0, "uiElementName": "unique_UI_killRightsTab", "defaultDirection": 2}
110	121	{"_key": 121, "title": 636507, "iconID": 26278, "internalName": "charactersheetSkinsTab", "isMenuOption": 0, "uiElementName": "unique_UI_charactersheetSkinsTab", "defaultDirection": 2}
111	122	{"_key": 122, "title": 636508, "texturePath": "res:/UI/Texture/classes/MultiSell/multiBuy.png", "internalName": "buyAllBtn", "isMenuOption": 0, "uiElementName": "unique_UI_buyAllBtn"}
112	123	{"_key": 123, "title": 636509, "texturePath": "res:/UI/Texture/classes/ShipUI/plus.png", "internalName": "setFullspeed", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_setFullspeed"}
113	124	{"_key": 124, "title": 636510, "iconID": 26278, "internalName": "stationSvcHangars", "isMenuOption": 0, "pointerScope": ["Docked"], "uiElementName": "unique_UI_stationSvcHangars", "defaultDirection": 2}
114	125	{"_key": 125, "title": 636511, "iconID": 26278, "internalName": "stationSvcAgents", "isMenuOption": 0, "pointerScope": ["Docked"], "uiElementName": "unique_UI_stationSvcAgents", "defaultDirection": 2}
115	126	{"_key": 126, "title": 636512, "iconID": 26278, "internalName": "stationSvcOffices", "isMenuOption": 0, "pointerScope": ["Docked"], "uiElementName": "unique_UI_stationSvcOffices", "defaultDirection": 2}
116	127	{"_key": 127, "title": 636513, "iconID": 26278, "internalName": "industryBlueprintsBtn", "isMenuOption": 0, "uiElementName": "unique_UI_industryBlueprintsTab", "defaultDirection": 2}
117	129	{"_key": 129, "title": 636514, "iconID": 26275, "internalName": "createChatChannelBtn", "isMenuOption": 0, "uiElementName": "unique_UI_createChatChannelBtn"}
118	130	{"_key": 130, "title": 636515, "iconID": 26278, "internalName": "expertSystemsTab", "isMenuOption": 0, "uiElementName": "unique_UI_expertSystemsTab", "defaultDirection": 2}
119	131	{"_key": 131, "title": 636516, "internalName": "resumePauseTrainingBtn", "isMenuOption": 0, "uiElementName": "unique_UI_resumePauseTrainingBtn"}
120	132	{"_key": 132, "title": 636517, "texturePath": "res:/UI/Texture/classes/skilltrading/marketSkillinjector.png", "internalName": "applySkillPointsBtn", "isMenuOption": 0, "uiElementName": "unique_UI_applySkillPointsBtn"}
121	134	{"_key": 134, "title": 636518, "iconDataName": "eveicon.inventory", "internalName": "corpAssetsTab", "isMenuOption": 0, "uiElementName": "unique_UI_corpAssetsTab", "defaultDirection": 2}
122	135	{"_key": 135, "title": 636519, "internalName": "systemNameLabel", "isMenuOption": 0, "uiElementName": "unique_UI_systemNameLabel", "defaultDirection": 2}
123	136	{"_key": 136, "title": 636520, "internalName": "systemSecurityLabel", "isMenuOption": 0, "uiElementName": "unique_UI_systemSecurityLabel", "defaultDirection": 2}
124	137	{"_key": 137, "title": 636521, "internalName": "sensorOverlaySetting", "isMenuOption": 1, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_sensorOverlaySetting"}
125	138	{"_key": 138, "title": 639169, "iconID": 26278, "internalName": "fittingEquipment", "isMenuOption": 0, "uiElementName": "unique_UI_fittingEquipment", "defaultDirection": 2}
126	139	{"_key": 139, "title": 639170, "iconID": 26278, "internalName": "fittingPersonalization", "isMenuOption": 0, "uiElementName": "unique_UI_fittingPersonalization", "defaultDirection": 2}
127	140	{"_key": 140, "title": 639711, "iconID": 26278, "internalName": "charactersheetPersonalizationTab", "isMenuOption": 0, "uiElementName": "unique_UI_charactersheetPersonalizationTab", "defaultDirection": 2}
128	141	{"_key": 141, "title": 639712, "iconID": 26278, "internalName": "charactersheetEmblemsTab", "isMenuOption": 0, "uiElementName": "unique_UI_charactersheetEmblemsTab", "defaultDirection": 2}
129	142	{"_key": 142, "title": 642542, "internalName": "showHideBroadcasts", "isMenuOption": 0, "pointerScope": ["Fleet"], "uiElementName": "unique_UI_showHideBroadcasts", "defaultDirection": 2}
130	143	{"_key": 143, "title": 642552, "internalName": "fleetBroadcastScope", "isMenuOption": 0, "pointerScope": ["Fleet"], "uiElementName": "unique_UI_fleetBroadcastScope", "defaultDirection": 2}
131	144	{"_key": 144, "title": 642553, "internalName": "showHideContractOptions", "isMenuOption": 0, "uiElementName": "unique_UI_showHideContractOptions"}
132	145	{"_key": 145, "title": 644216, "iconDataName": "eveicon.stack", "internalName": "pointerInventoryStackAll", "isMenuOption": 0, "uiElementName": "unique_UI_inventoryStackAll"}
133	146	{"_key": 146, "title": 644241, "internalName": "pointerNewEdenStorePlexAmount", "isMenuOption": 0, "uiElementName": "unique_UI_newEdenStorePlexAmount"}
134	147	{"_key": 147, "title": 644900, "texturePath": "res:/UI/Texture/classes/Fitting/tabAllianceFits.png", "internalName": "pointerAllianceFitFilter", "isMenuOption": 0, "uiElementName": "unique_UI_allianceFitFilter"}
135	148	{"_key": 148, "title": 644901, "internalName": "pointerIndustryInputLocation", "isMenuOption": 0, "uiElementName": "unique_UI_industryInputLocation", "defaultDirection": 2}
136	149	{"_key": 149, "title": 644902, "internalName": "pointerIndustryOutputLocation", "isMenuOption": 0, "uiElementName": "unique_UI_industryOutputLocation", "defaultDirection": 4}
137	151	{"_key": 151, "title": 645379, "texturePath": "res:/UI/Texture/classes/Fitting/filterIconResources.png", "internalName": "pointerFittingStats", "isMenuOption": 0, "uiElementName": "unique_UI_fittingStats"}
138	152	{"_key": 152, "title": 645380, "internalName": "pointerFittingCap", "isMenuOption": 0, "uiElementName": "unique_UI_fittingCap"}
139	153	{"_key": 153, "title": 645381, "internalName": "pointerFittingOffense", "isMenuOption": 0, "uiElementName": "unique_UI_fittingOffense"}
140	154	{"_key": 154, "title": 645382, "internalName": "pointerFittingDefense", "isMenuOption": 0, "uiElementName": "unique_UI_fittingDefense"}
141	155	{"_key": 155, "title": 645383, "internalName": "pointerFittingCap", "isMenuOption": 0, "uiElementName": "unique_UI_fittingCap"}
142	156	{"_key": 156, "title": 645384, "internalName": "pointerFittingTargeting", "isMenuOption": 0, "uiElementName": "unique_UI_fittingTargeting"}
143	157	{"_key": 157, "title": 645385, "internalName": "pointerFittingNavigation", "isMenuOption": 0, "uiElementName": "unique_UI_fittingNavigation"}
144	158	{"_key": 158, "title": 645386, "internalName": "pointerFittingDrones", "isMenuOption": 0, "uiElementName": "unique_UI_fittingDrones"}
145	159	{"_key": 159, "title": 645387, "internalName": "pointerFittingFighters", "isMenuOption": 0, "uiElementName": "unique_UI_fittingFighters"}
146	160	{"_key": 160, "title": 645388, "internalName": "pointerShipHealth", "isMenuOption": 0, "uiElementName": "unique_UI_shipHealth"}
147	161	{"_key": 161, "title": 645389, "internalName": "pointerHelpCenterBtn", "isMenuOption": 0, "uiElementName": "unique_UI_helpCenterBtn"}
148	162	{"_key": 162, "title": 646405, "iconID": 26275, "internalName": "pointerSillplans_certified_tab", "isMenuOption": 0, "uiElementName": "unique_UI_skillplans_certified_tab", "defaultDirection": 2}
149	163	{"_key": 163, "title": 646406, "iconID": 26275, "internalName": "pointerSkillplans_personal_tab", "isMenuOption": 0, "uiElementName": "unique_UI_skillplans_personal_tab", "defaultDirection": 2}
150	164	{"_key": 164, "title": 646407, "iconID": 26275, "internalName": "pointerSkillplans_corp_tab", "isMenuOption": 0, "uiElementName": "unique_UI_skillplans_corp_tab", "defaultDirection": 2}
151	165	{"_key": 165, "title": 646408, "iconID": 26278, "internalName": "pointerSkill_plans_tab", "isMenuOption": 0, "uiElementName": "unique_UI_skill_plans_tab", "defaultDirection": 2}
152	166	{"_key": 166, "title": 646409, "iconID": 26278, "internalName": "pointerSkill_catalogue_tab", "isMenuOption": 0, "uiElementName": "unique_UI_skill_catalogue_tab", "defaultDirection": 2}
153	168	{"_key": 168, "title": 663302, "iconID": 26278, "internalName": "pointerIndustryResearchTab", "isMenuOption": 0, "uiElementName": "unique_UI_industryResearchTab", "defaultDirection": 2}
154	170	{"_key": 170, "title": 709251, "iconID": 26278, "internalName": "corpWindowCorporationTab", "isMenuOption": 0, "uiElementName": "unique_UI_corpCorporationTab"}
155	171	{"_key": 171, "title": 709252, "iconID": 26278, "internalName": "corpWindowAdministrationTab", "isMenuOption": 0, "uiElementName": "unique_UI_corpAdminTab"}
156	172	{"_key": 172, "title": 709253, "iconID": 26278, "internalName": "corpWindowAlliancesTab", "isMenuOption": 0, "uiElementName": "unique_UI_corpAlliancesTab"}
157	173	{"_key": 173, "title": 721906, "internalName": "AutoLockChkBox", "isMenuOption": 0, "uiElementName": "unique_UI_autolockCheckbox"}
158	174	{"_key": 174, "title": 721905, "internalName": "AutoFireChkBox", "isMenuOption": 0, "uiElementName": "unique_UI_autofireCheckbox"}
159	175	{"_key": 175, "title": 721914, "internalName": "AutoLockBtn", "isMenuOption": 0, "uiElementName": "unique_UI_quicklockButton"}
160	176	{"_key": 176, "title": 721913, "internalName": "AutoFireBtn", "isMenuOption": 0, "uiElementName": "unique_UI_focusfireButton"}
161	179	{"_key": 179, "title": 727459, "internalName": "pointerSkinrStudio", "isMenuOption": 0, "uiElementName": "unique_UI_skinrStudio", "defaultDirection": 2}
162	180	{"_key": 180, "title": 727460, "internalName": "pointerParagonHub", "isMenuOption": 0, "uiElementName": "unique_UI_skinrParagonHub", "defaultDirection": 2}
163	181	{"_key": 181, "title": 727461, "internalName": "pointerSkinrCollection", "isMenuOption": 0, "uiElementName": "unique_UI_skinrCollection", "defaultDirection": 2}
164	184	{"_key": 184, "title": 729026, "iconID": 26278, "internalName": "corpChannelWnd", "isMenuOption": 0, "uiElementName": "unique_UI_corpChannelWnd", "defaultDirection": 2}
165	185	{"_key": 185, "title": 729028, "iconDataName": "eveicon.more_vertical", "internalName": "pointerCorpChatSettings", "isMenuOption": 0, "uiElementName": "unique_UI_corpChatSettings", "defaultDirection": 2}
166	186	{"_key": 186, "title": 729029, "iconDataName": "eveicon.more_vertical", "internalName": "pointerCorpChatReloadMotd", "isMenuOption": 0, "uiElementName": "unique_UI_corpChatReloadMotd"}
167	187	{"_key": 187, "title": 729030, "iconID": 26278, "internalName": "pointerFleetChat", "isMenuOption": 0, "pointerScope": ["Fleet"], "uiElementName": "unique_UI_fleetChat", "defaultDirection": 2}
168	188	{"_key": 188, "title": 729031, "iconDataName": "eveicon.more_vertical", "internalName": "pointerFleetChatReloadMotd", "isMenuOption": 0, "pointerScope": ["Fleet"], "uiElementName": "unique_UI_fleetChatReloadMotd"}
169	189	{"_key": 189, "title": 729032, "iconDataName": "eveicon.more_vertical", "internalName": "pointerFleetChatSettings", "isMenuOption": 0, "pointerScope": ["Fleet"], "uiElementName": "unique_UI_fleetChatSettings", "defaultDirection": 2}
170	191	{"_key": 191, "title": 729033, "iconID": 26278, "internalName": "pointerMyWallet", "isMenuOption": 0, "uiElementName": "unique_UI_myWallet", "defaultDirection": 2}
171	192	{"_key": 192, "title": 729034, "iconID": 26278, "internalName": "pointerWalletTransactions", "isMenuOption": 0, "uiElementName": "unique_UI_walletTransactions", "defaultDirection": 2}
172	193	{"_key": 193, "title": 729035, "iconID": 26278, "internalName": "pointerWalletMarketTransactions", "isMenuOption": 0, "uiElementName": "unique_UI_walletMarketTransactions", "defaultDirection": 2}
173	194	{"_key": 194, "title": 872576, "internalName": "opportunitiesBrowser", "isMenuOption": 0, "uiElementName": "unique_UI_opportunitiesBrowser", "defaultDirection": 2}
174	195	{"_key": 195, "title": 872577, "iconID": 26278, "internalName": "activeOpportunities", "isMenuOption": 0, "uiElementName": "unique_UI_activeOpportunities", "defaultDirection": 2}
175	196	{"_key": 196, "title": 872578, "iconID": 26278, "internalName": "opportunityRewards", "isMenuOption": 0, "uiElementName": "unique_UI_opportunityRewards", "defaultDirection": 2}
176	197	{"_key": 197, "title": 872579, "iconDataName": "eveicon.search", "internalName": "findNewCorp", "isMenuOption": 0, "uiElementName": "unique_UI_findNewCorp", "defaultDirection": 2}
177	198	{"_key": 198, "title": 872580, "iconDataName": "eveicon.projects", "internalName": "corpProjects", "isMenuOption": 0, "pointerScope": ["PlayerCorp"], "uiElementName": "unique_UI_corpProjects", "defaultDirection": 2}
178	199	{"_key": 199, "title": 872581, "iconDataName": "eveicon.settings", "internalName": "opportunityFilters", "isMenuOption": 0, "uiElementName": "unique_UI_opportunityFilters", "defaultDirection": 2}
179	200	{"_key": 200, "title": 895207, "texturePath": "res:/UI/Texture/WindowIcons/items.png", "internalName": "fittingInventoryBrowser", "isMenuOption": 0, "uiElementName": "unique_UI_fittingInventoryBrowser"}
180	201	{"_key": 201, "title": 1010612, "iconDataName": "eveicon.freelance_projects", "internalName": "freelanceProjects", "isMenuOption": 0, "pointerScope": ["PlayerCorp"], "uiElementName": "unique_UI_freelanceProjects", "defaultDirection": 2}
181	202	{"_key": 202, "title": 1015213, "iconID": 26275, "internalName": "pointerModulesInFittingWnd", "isMenuOption": 0, "uiElementName": "unique_UI_modulesInFittingWnd", "defaultDirection": 2}
182	203	{"_key": 203, "title": 1015214, "iconID": 26275, "internalName": "pointerChargesInFittingWnd", "isMenuOption": 0, "uiElementName": "unique_UI_chargesInFittingWnd", "defaultDirection": 2}
183	204	{"_key": 204, "title": 1021770, "iconDataName": "eveicon.mining_overlay_toggle_default", "internalName": "pointerminingScanBtn", "isMenuOption": 0, "pointerScope": ["InSpace"], "uiElementName": "unique_UI_miningScanBtn", "defaultDirection": 2}
184	205	{"_key": 205, "title": 1031540, "iconDataName": "eveicon.jump_range_map", "internalName": "pointerMapJumpRangeToggle", "isMenuOption": 0, "uiElementName": "unique_UI_mapJumpRangeToggle"}
185	206	{"_key": 206, "title": 1031541, "iconDataName": "eveicon.focus_viewfinder", "internalName": "pointerMapFocusCurrentLocation", "isMenuOption": 0, "uiElementName": "unique_UI_mapFocusCurrentLocation"}
186	207	{"_key": 207, "title": 1031542, "iconDataName": "eveicon.find_home_station", "internalName": "pointerMapFocusHomeStation", "isMenuOption": 0, "uiElementName": "unique_UI_mapFocusHomeStation"}
187	208	{"_key": 208, "title": 1031543, "iconDataName": "eveicon.abstract_layout", "internalName": "pointerMap2DLayoutToggle", "isMenuOption": 0, "uiElementName": "unique_UI_map2DLayoutToggle"}
188	209	{"_key": 209, "title": 1031544, "iconDataName": "eveicon.universe_layout", "internalName": "pointerMapLayout", "isMenuOption": 0, "uiElementName": "unique_UI_mapLayout"}
189	211	{"_key": 211, "title": 1031546, "iconDataName": "eveicon.eye", "internalName": "pointerMapDataViewToggle", "isMenuOption": 0, "uiElementName": "unique_UI_mapDataViewToggle"}
190	212	{"_key": 212, "title": 1031953, "iconID": 26278, "internalName": "stationSvcGuests", "isMenuOption": 0, "pointerScope": ["Docked"], "uiElementName": "unique_UI_stationSvcGuests", "defaultDirection": 2}
191	213	{"_key": 213, "title": 1045782, "iconDataName": "eveicon.factional_warfare", "internalName": "pointerFactionalWarfare", "isMenuOption": 0, "uiElementName": "unique_UI_towFactionalWarfare", "defaultDirection": 3}
192	214	{"_key": 214, "title": 1045783, "iconDataName": "eveicon.map_insurgency", "internalName": "pointerInsurgencies", "isMenuOption": 0, "uiElementName": "unique_UI_towInsurgencies", "defaultDirection": 3}
193	215	{"_key": 215, "title": 1045790, "iconDataName": "eveicon.faction_warfare", "internalName": "pointerEnlistment", "isMenuOption": 0, "uiElementName": "unique_UI_towEnlistment", "defaultDirection": 3}
194	216	{"_key": 216, "title": 1045791, "internalName": "pointerCampaigns", "isMenuOption": 0, "uiElementName": "unique_UI_towCampaigns", "defaultDirection": 3}
195	217	{"_key": 217, "title": 1047720, "iconID": 26278, "internalName": "pointerDecorations", "isMenuOption": 0, "uiElementName": "unique_UI_decorationsTab", "defaultDirection": 2}
196	218	{"_key": 218, "title": 1047721, "iconID": 26278, "internalName": "pointerTitles", "isMenuOption": 0, "uiElementName": "unique_UI_titlesTab", "defaultDirection": 2}
\.


--
-- Name: uihelppointers uihelppointers_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.uihelppointers
    ADD CONSTRAINT uihelppointers_pkey PRIMARY KEY (row_no);


--
-- Name: uihelppointers_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX uihelppointers_key_idx ON sde_native.uihelppointers USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict bWDC4c24FMfl0x6wmCWttxQV0j1NMRwdIz824U4cKXREHZou3U9OG6smcnA0mg1

