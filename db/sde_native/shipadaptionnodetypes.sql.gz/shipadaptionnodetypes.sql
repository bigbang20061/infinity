--
-- PostgreSQL database dump
--

\restrict BCuD4fymWHWRQOCPtezcIwtdIQzT3T55voBfplj2eFkufe2fWq85ek9FXcPRKnN

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: shipadaptionnodetypes; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.shipadaptionnodetypes (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: shipadaptionnodetypes; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.shipadaptionnodetypes (row_no, key, data) FROM stdin;
0	0	{"_key": 0, "name": "Root"}
1	1	{"_key": 1, "name": "T1"}
2	2	{"_key": 2, "name": "T2"}
3	3	{"_key": 3, "name": "Ship"}
4	4	{"_key": 4, "name": "T3"}
\.


--
-- Name: shipadaptionnodetypes shipadaptionnodetypes_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.shipadaptionnodetypes
    ADD CONSTRAINT shipadaptionnodetypes_pkey PRIMARY KEY (row_no);


--
-- Name: shipadaptionnodetypes_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX shipadaptionnodetypes_key_idx ON sde_native.shipadaptionnodetypes USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict BCuD4fymWHWRQOCPtezcIwtdIQzT3T55voBfplj2eFkufe2fWq85ek9FXcPRKnN

