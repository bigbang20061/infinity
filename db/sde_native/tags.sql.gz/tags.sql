--
-- PostgreSQL database dump
--

\restrict vMmkAYiuS0w4CfYzhDhzRw0Vw4p4kktftgAkQu46SNwezatqTEH8ogYhFxCy0ed

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tags; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.tags (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: tags; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.tags (row_no, key, data) FROM stdin;
0	7	{"_key": 7, "texturePath": "res:/UI/Texture/classes/Treatments/tagIcons/mining.png", "internalName": "Mining tag", "titleLabelID": 577105}
1	9	{"_key": 9, "internalName": "ore tag", "titleLabelID": 577123}
2	11	{"_key": 11, "texturePath": "res:/UI/Texture/classes/Treatments/tagIcons/combat.png", "internalName": "combat tag", "titleLabelID": 577745}
3	12	{"_key": 12, "texturePath": "res:/UI/Texture/classes/Treatments/tagIcons/distribution.png", "internalName": "Distribution tag", "titleLabelID": 577746}
4	13	{"_key": 13, "texturePath": "res:/UI/Texture/classes/Treatments/tagIcons/epicArc.png", "internalName": "Epic Arc tag", "titleLabelID": 577747}
5	14	{"_key": 14, "texturePath": "res:/UI/Texture/classes/Treatments/tagIcons/exploration.png", "internalName": "Exploration tag", "titleLabelID": 577748}
6	15	{"_key": 15, "texturePath": "res:/UI/Texture/classes/Treatments/tagIcons/industry.png", "internalName": "Industry tag", "titleLabelID": 577749}
7	16	{"_key": 16, "texturePath": "res:/UI/Texture/classes/Treatments/tagIcons/market.png", "internalName": "Market tag", "titleLabelID": 577750}
8	17	{"_key": 17, "texturePath": "res:/UI/Texture/classes/Treatments/tagIcons/salvaging.png", "internalName": "Salvaging tag", "titleLabelID": 577751}
9	18	{"_key": 18, "texturePath": "res:/UI/Texture/classes/Treatments/tagIcons/social.png", "internalName": "Social tag", "titleLabelID": 577752}
10	21	{"_key": 21, "internalName": "PvE tag", "titleLabelID": 584379}
11	22	{"_key": 22, "internalName": "PvP tag", "titleLabelID": 584380}
12	23	{"_key": 23, "internalName": "Missions tag", "titleLabelID": 584381}
13	24	{"_key": 24, "internalName": "Security tag", "titleLabelID": 584382}
14	25	{"_key": 25, "internalName": "Faction Warfare tag", "titleLabelID": 584383}
15	26	{"_key": 26, "internalName": "Abyssal Deadspace tag", "titleLabelID": 584384}
16	27	{"_key": 27, "internalName": "Scanning tag", "titleLabelID": 584385}
17	28	{"_key": 28, "internalName": "Hacking tag", "titleLabelID": 584386}
18	29	{"_key": 29, "internalName": "Project Discovery tag", "titleLabelID": 584387}
19	30	{"_key": 30, "internalName": "Reprocessing tag", "titleLabelID": 584390}
20	31	{"_key": 31, "internalName": "Manufacture tag", "titleLabelID": 584391}
21	32	{"_key": 32, "internalName": "Navigation tag", "titleLabelID": 584392}
22	33	{"_key": 33, "internalName": "Logistics tag", "titleLabelID": 584393}
23	34	{"_key": 34, "internalName": "Support tag", "titleLabelID": 584394}
24	35	{"_key": 35, "internalName": "Electronic Warfare tag", "titleLabelID": 584395}
25	36	{"_key": 36, "internalName": "ESS tag", "titleLabelID": 584396}
26	37	{"_key": 37, "internalName": "Corporation tag", "titleLabelID": 584397}
27	38	{"_key": 38, "internalName": "Bounties tag", "titleLabelID": 584398}
28	39	{"_key": 39, "texturePath": "res:/UI/Texture/classes/Treatments/tagIcons/landmarks.png", "internalName": "Landmarks tag", "titleLabelID": 584399}
29	40	{"_key": 40, "internalName": "Level 1 tag", "titleLabelID": 584400}
30	41	{"_key": 41, "internalName": "Level 2 tag", "titleLabelID": 584401}
31	42	{"_key": 42, "internalName": "Level 3 tag", "titleLabelID": 584402}
32	43	{"_key": 43, "internalName": "Level 4 tag", "titleLabelID": 584403}
33	44	{"_key": 44, "internalName": "High Sec tag", "titleLabelID": 584404}
34	45	{"_key": 45, "internalName": "Low Sec tag", "titleLabelID": 584405}
35	46	{"_key": 46, "internalName": "Null Sec tag", "titleLabelID": 584406}
36	47	{"_key": 47, "internalName": "Wormholes tag", "titleLabelID": 584407}
37	48	{"_key": 48, "internalName": "Ships tag", "titleLabelID": 584408}
38	49	{"_key": 49, "internalName": "Destruction tag", "titleLabelID": 584409}
39	50	{"_key": 50, "internalName": "Buy tag", "titleLabelID": 584410}
40	51	{"_key": 51, "internalName": "Sell tag", "titleLabelID": 584411}
41	52	{"_key": 52, "internalName": "Fleet tag", "titleLabelID": 584412}
42	53	{"_key": 53, "internalName": "Chat tag", "titleLabelID": 584413}
43	54	{"_key": 54, "internalName": "Charges tag", "titleLabelID": 584414}
44	55	{"_key": 55, "internalName": "Modules tag", "titleLabelID": 584415}
45	56	{"_key": 56, "internalName": "Rigs tag", "titleLabelID": 584416}
46	57	{"_key": 57, "internalName": "Deployables tag", "titleLabelID": 584417}
47	58	{"_key": 58, "internalName": "Drones tag", "titleLabelID": 584418}
48	59	{"_key": 59, "internalName": "Skills tag", "titleLabelID": 584598}
\.


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (row_no);


--
-- Name: tags_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX tags_key_idx ON sde_native.tags USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict vMmkAYiuS0w4CfYzhDhzRw0Vw4p4kktftgAkQu46SNwezatqTEH8ogYhFxCy0ed

