--
-- PostgreSQL database dump
--

\restrict pfB8K3CJaXcRMWBXRYt4zrPCUVKpwj1ioZVJINUTPLbuKWEAur2pwtkwOOTGenM

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: skyboxeffects; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.skyboxeffects (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: skyboxeffects; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.skyboxeffects (row_no, key, data) FROM stdin;
0	1	{"far": {"scale": 0.0, "distInLightYears": 1.25}, "_key": 1, "name": "EVE GATE", "near": {"scale": 0.0455, "distInLightYears": 0.1}, "path": "res:/dx9/model/celestial/landmark/Landmark_EVEGATE_01a.red", "source": {"worldPosition": [-514684853363782900, 749851676471366.0, -78390639768319790]}}
1	2	{"far": {"scale": 0.012, "distInLightYears": 43.333}, "_key": 2, "name": "Carolines Star", "near": {"scale": 0.2686, "distInLightYears": 13.74207}, "path": "res:/dx9/model/celestial/landmark/Landmark_CarolinesStar_01a.red", "source": {"solarSystemID": 30000367}}
2	3	{"far": {"scale": 0.0, "distInLightYears": 1.01}, "_key": 3, "name": "Cord of the Elements", "near": {"scale": 1.0, "distInLightYears": 1.0}, "path": "res:/dx9/model/celestial/landmark/Landmark_CordOfTheElements_01a.red", "source": {"worldPosition": [-483036990388576600, 46685170535500530, -40050745299063260]}}
3	4	{"far": {"scale": 0.0, "distInLightYears": 1.5}, "_key": 4, "name": "Pool of Radiance", "near": {"scale": 0.0925, "distInLightYears": 0.5}, "path": "res:/dx9/model/celestial/landmark/Landmark_PoolOfRadiance_01a.red", "source": {"worldPosition": [-265298585202786200, 78981024003687040, -192948163239565400]}}
4	5	{"far": {"scale": 0.0, "distInLightYears": 0.62}, "_key": 5, "name": "Trace Cosmos", "near": {"scale": 1.0, "distInLightYears": 0.61}, "path": "res:/dx9/model/celestial/landmark/Landmark_TraceCosmos_01a.red", "source": {"worldPosition": [-626704472287198200, 30938960150097560, 28281421192286220]}}
5	6	{"far": {"scale": 0.0, "distInLightYears": 3.25}, "_key": 6, "name": "Inciting Event Landmark", "near": {"scale": 0.5, "distInLightYears": 1.0}, "path": "res:/dx9/model/celestial/landmark/landmark_incitingevent_fracture_01a.red", "source": {"solarSystemID": 30000142}}
\.


--
-- Name: skyboxeffects skyboxeffects_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.skyboxeffects
    ADD CONSTRAINT skyboxeffects_pkey PRIMARY KEY (row_no);


--
-- Name: skyboxeffects_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX skyboxeffects_key_idx ON sde_native.skyboxeffects USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict pfB8K3CJaXcRMWBXRYt4zrPCUVKpwj1ioZVJINUTPLbuKWEAur2pwtkwOOTGenM

