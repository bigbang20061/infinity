--
-- PostgreSQL database dump
--

\restrict XF4JHD2GzrUIqfkhFD8jvvSrOYT6MeDb64xxFMUYFujgvmhygqURZd71srHFeZL

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: objectivetasktypes; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.objectivetasktypes (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: objectivetasktypes; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.objectivetasktypes (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "icon": "location", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "location_id", "parameterType": "locationIdType"}]}
1	2	{"_key": 2, "icon": "cargo_inventory", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "items", "parameterType": "unionListType"}]}
2	3	{"_key": 3, "icon": "inventory", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "items", "parameterType": "unionListType"}, {"isRequired": 0, "parameterKey": "location_id", "parameterType": "locationIdType"}]}
3	4	{"_key": 4, "icon": "inventory", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "items", "parameterType": "unionListType"}, {"isRequired": 0, "parameterKey": "location_id", "parameterType": "locationIdType"}]}
4	5	{"_key": 5, "icon": "target", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "targets", "parameterType": "unionListType"}]}
5	6	{"_key": 6, "icon": "shield_plus", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "targets", "parameterType": "unionListType"}]}
6	7	{"_key": 7, "icon": "approach", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "target", "parameterType": "unionDictType"}, {"isRequired": 0, "parameterKey": "distance", "parameterType": "integerType"}]}
7	8	{"_key": 8, "icon": "person", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "agent_id", "parameterType": "npcCharacterIdType"}]}
8	9	{"_key": 9, "icon": "more_horizontal", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "current_value", "parameterType": "floatType"}, {"isRequired": 1, "parameterKey": "goal_value", "parameterType": "floatType"}, {"isRequired": 0, "parameterKey": "display_percentage", "parameterType": "boolType"}, {"isRequired": 0, "parameterKey": "progress_bar_hex_color", "parameterType": "stringType"}]}
9	10	{"_key": 10, "icon": "board", "tags": [], "inputParameters": [{"isRequired": 0, "parameterKey": "type_id", "parameterType": "eveTypeIdType"}, {"isRequired": 0, "parameterKey": "group_id", "parameterType": "eveTypeGroupIdType"}]}
10	11	{"_key": 11, "icon": "location", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "character_id", "parameterType": "npcCharacterIdType"}]}
11	12	{"_key": 12, "icon": "warp_to", "tags": [], "title": "UI/Objectives/Titles/WarpToSite", "inputParameters": [{"isRequired": 1, "parameterKey": "dungeon_id", "parameterType": "dungeonIdType"}, {"isRequired": 0, "parameterKey": "bookmark", "parameterType": "objectType"}, {"isRequired": 0, "parameterKey": "scan_result", "parameterType": "objectType"}]}
12	13	{"_key": 13, "icon": "fitting", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "modules", "parameterType": "unionListType"}]}
13	14	{"_key": 14, "icon": "target", "tags": [], "title": "UI/Objectives/Titles/HostilesRemaining", "inputParameters": []}
14	15	{"_key": 15, "icon": "jump_to", "tags": [], "inputParameters": [{"isRequired": 0, "parameterKey": "gate_id", "parameterType": "integerType"}]}
15	16	{"_key": 16, "icon": "open_cargo", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "target", "parameterType": "objectType"}]}
16	17	{"_key": 17, "icon": "salvage", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "target", "parameterType": "objectType"}]}
17	18	{"_key": 18, "icon": "hacking", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "target", "parameterType": "objectType"}, {"isRequired": 0, "parameterKey": "personal_only", "parameterType": "boolType"}]}
18	19	{"_key": 19, "icon": "scanners", "tags": [], "inputParameters": [{"isRequired": 0, "parameterKey": "dungeon_id", "parameterType": "dungeonIdType"}]}
19	20	{"_key": 20, "icon": "warp_to", "tags": [], "title": "UI/Objectives/Titles/WarpToSite", "inputParameters": [{"isRequired": 1, "parameterKey": "scan_result", "parameterType": "objectType"}]}
20	21	{"_key": 21, "icon": "mining", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "asteroid_info", "parameterType": "unionDictType"}]}
21	22	{"_key": 22, "icon": "target", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "target", "parameterType": "objectType"}, {"isRequired": 1, "parameterKey": "module_info", "parameterType": "unionDictType"}, {"isRequired": 0, "parameterKey": "show_module", "parameterType": "boolType"}]}
22	23	{"_key": 23, "icon": "target", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "module_info", "parameterType": "unionDictType"}]}
23	24	{"_key": 24, "icon": "target", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "target", "parameterType": "objectType"}]}
24	25	{"_key": 25, "icon": "fitting", "tags": [], "title": "UI/Objectives/Titles/FitAnyWeapon", "inputParameters": []}
25	26	{"_key": 26, "icon": "fitting", "tags": [], "title": "UI/Objectives/Titles/FitAnyMiningLaser", "inputParameters": []}
26	28	{"_key": 28, "icon": "drone", "tags": [], "title": "UI/Objectives/Titles/LoadAnyCombatDrone", "inputParameters": []}
27	29	{"_key": 29, "icon": "scanners", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "dungeon_id", "parameterType": "dungeonIdType"}]}
28	30	{"_key": 30, "icon": "hourglass", "tags": [], "title": "UI/Objectives/Titles/TimeRemaining", "inputParameters": [{"isRequired": 1, "parameterKey": "timer", "parameterType": "unionDictType"}]}
29	32	{"_key": 32, "icon": "target", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "target", "parameterType": "objectType"}, {"isRequired": 1, "parameterKey": "current_value", "parameterType": "floatType"}, {"isRequired": 1, "parameterKey": "goal_value", "parameterType": "floatType"}, {"isRequired": 0, "parameterKey": "display_percentage", "parameterType": "boolType"}]}
30	33	{"_key": 33, "tags": [], "inputParameters": [{"isRequired": 0, "parameterKey": "objective_target_groups", "parameterType": "stringListType"}, {"isRequired": 0, "parameterKey": "type_list_id", "parameterType": "eveTypeListIdType"}, {"isRequired": 0, "parameterKey": "type_ids", "parameterType": "integerListType"}, {"isRequired": 0, "parameterKey": "group_ids", "parameterType": "integerListType"}, {"isRequired": 0, "parameterKey": "item_ids", "parameterType": "integerListType"}, {"isRequired": 0, "parameterKey": "dungeon_object_ids", "parameterType": "integerListType"}]}
31	35	{"_key": 35, "icon": "more_horizontal", "tags": [], "inputParameters": [{"isRequired": 0, "parameterKey": "value", "parameterType": "stringType"}]}
32	36	{"_key": 36, "icon": "warp_to", "tags": [], "title": "UI/Objectives/Titles/WarpToSite", "inputParameters": [{"isRequired": 1, "parameterKey": "dungeon_id", "parameterType": "dungeonIdType"}, {"isRequired": 1, "parameterKey": "instance_id", "parameterType": "integerType"}]}
33	37	{"_key": 37, "icon": "open_window", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "window_id", "parameterType": "stringType"}]}
34	38	{"_key": 38, "tags": [], "inputParameters": []}
35	39	{"_key": 39, "icon": "block_ban", "tags": ["dungeon"], "title": "UI/Objectives/Titles/ShipRestrictions", "inputParameters": [{"isRequired": 0, "parameterKey": "dungeon_id", "parameterType": "dungeonIdType"}, {"isRequired": 0, "parameterKey": "gate_id", "parameterType": "integerType"}]}
36	40	{"_key": 40, "icon": "target", "tags": ["dungeon"], "inputParameters": [{"isRequired": 1, "parameterKey": "dungeon_object_ids", "parameterType": "integerListType"}]}
37	41	{"_key": 41, "icon": "target", "tags": ["dungeon"], "inputParameters": [{"isRequired": 1, "parameterKey": "entity_group_ids", "parameterType": "integerListType"}]}
38	42	{"_key": 42, "icon": "more_horizontal", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "current_value", "parameterType": "floatType"}, {"isRequired": 1, "parameterKey": "max_value", "parameterType": "floatType"}, {"isRequired": 1, "parameterKey": "min_goal_value", "parameterType": "floatType"}, {"isRequired": 1, "parameterKey": "max_goal_value", "parameterType": "floatType"}, {"isRequired": 0, "parameterKey": "display_percentage", "parameterType": "boolType"}]}
39	43	{"_key": 43, "icon": "target", "tags": [], "inputParameters": [{"isRequired": 1, "parameterKey": "target", "parameterType": "objectType"}, {"isRequired": 1, "parameterKey": "current_value", "parameterType": "floatType"}, {"isRequired": 1, "parameterKey": "max_value", "parameterType": "floatType"}, {"isRequired": 1, "parameterKey": "min_goal_value", "parameterType": "floatType"}, {"isRequired": 1, "parameterKey": "max_goal_value", "parameterType": "floatType"}, {"isRequired": 0, "parameterKey": "display_percentage", "parameterType": "boolType"}]}
40	45	{"_key": 45, "icon": "target", "tags": [], "title": "UI/Objectives/Titles/targetsRemaining", "inputParameters": [{"isRequired": 0, "parameterKey": "objective_target_groups", "parameterType": "stringListType"}, {"isRequired": 0, "parameterKey": "type_ids", "parameterType": "integerListType"}, {"isRequired": 0, "parameterKey": "group_ids", "parameterType": "integerListType"}, {"isRequired": 0, "parameterKey": "entity_group_ids", "parameterType": "integerListType"}, {"isRequired": 0, "parameterKey": "type_list_id", "parameterType": "eveTypeListIdType"}]}
41	46	{"_key": 46, "tags": ["mto"], "inputParameters": [{"isRequired": 1, "parameterKey": "activity_id", "parameterType": "stringType"}, {"isRequired": 1, "parameterKey": "den_id", "parameterType": "locationIdType"}]}
42	47	{"_key": 47, "icon": "warp_to", "tags": ["dungeon", "mto"], "title": "UI/Objectives/Titles/WarpToSite", "inputParameters": [{"isRequired": 1, "parameterKey": "instance_id", "parameterType": "stringType"}]}
43	48	{"_key": 48, "icon": "target", "tags": ["dungeon"], "inputParameters": [{"isRequired": 1, "parameterKey": "type_ids", "parameterType": "integerListType"}]}
44	52	{"_key": 52, "icon": "target", "tags": [], "inputParameters": [{"isRequired": 0, "parameterKey": "objective_target_groups", "parameterType": "stringListType"}, {"isRequired": 0, "parameterKey": "type_list_id", "parameterType": "eveTypeListIdType"}, {"isRequired": 0, "parameterKey": "type_ids", "parameterType": "integerListType"}, {"isRequired": 0, "parameterKey": "group_ids", "parameterType": "integerListType"}, {"isRequired": 0, "parameterKey": "item_ids", "parameterType": "integerListType"}, {"isRequired": 0, "parameterKey": "dungeon_object_ids", "parameterType": "integerListType"}]}
45	53	{"_key": 53, "icon": "shield_plus", "tags": [], "inputParameters": [{"isRequired": 0, "parameterKey": "objective_target_groups", "parameterType": "stringListType"}, {"isRequired": 0, "parameterKey": "type_list_id", "parameterType": "eveTypeListIdType"}, {"isRequired": 0, "parameterKey": "type_ids", "parameterType": "integerListType"}, {"isRequired": 0, "parameterKey": "group_ids", "parameterType": "integerListType"}, {"isRequired": 0, "parameterKey": "item_ids", "parameterType": "integerListType"}, {"isRequired": 0, "parameterKey": "dungeon_object_ids", "parameterType": "integerListType"}]}
46	54	{"_key": 54, "icon": "hacking", "tags": [], "inputParameters": [{"isRequired": 0, "parameterKey": "objective_target_groups", "parameterType": "stringListType"}, {"isRequired": 0, "parameterKey": "type_list_id", "parameterType": "eveTypeListIdType"}, {"isRequired": 0, "parameterKey": "type_ids", "parameterType": "integerListType"}, {"isRequired": 0, "parameterKey": "group_ids", "parameterType": "integerListType"}, {"isRequired": 0, "parameterKey": "item_ids", "parameterType": "integerListType"}, {"isRequired": 0, "parameterKey": "dungeon_object_ids", "parameterType": "integerListType"}, {"isRequired": 0, "parameterKey": "personal_only", "parameterType": "boolType"}]}
47	55	{"_key": 55, "icon": "hacking", "tags": [], "inputParameters": [{"isRequired": 0, "parameterKey": "personal_only", "parameterType": "boolType"}]}
48	56	{"_key": 56, "icon": "jump_to", "tags": ["abyss"], "inputParameters": []}
49	57	{"_key": 57, "icon": "hacking", "tags": [], "title": "UI/Objectives/Titles/ContainersHacked", "inputParameters": []}
50	65	{"_key": 65, "tags": [], "inputParameters": [{"isRequired": 0, "parameterKey": "job_id", "parameterType": "integerType"}]}
51	69	{"_key": 69, "icon": "hourglass", "tags": [], "title": "UI/Objectives/Titles/Duration", "inputParameters": [{"isRequired": 1, "parameterKey": "start_time", "parameterType": "integerType"}, {"isRequired": 0, "parameterKey": "stop_time", "parameterType": "integerType"}]}
52	74	{"_key": 74, "tags": [], "inputParameters": [{"isRequired": 0, "parameterKey": "hide", "parameterType": "boolType"}, {"isRequired": 0, "parameterKey": "complete", "parameterType": "boolType"}]}
\.


--
-- Name: objectivetasktypes objectivetasktypes_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.objectivetasktypes
    ADD CONSTRAINT objectivetasktypes_pkey PRIMARY KEY (row_no);


--
-- Name: objectivetasktypes_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX objectivetasktypes_key_idx ON sde_native.objectivetasktypes USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict XF4JHD2GzrUIqfkhFD8jvvSrOYT6MeDb64xxFMUYFujgvmhygqURZd71srHFeZL

