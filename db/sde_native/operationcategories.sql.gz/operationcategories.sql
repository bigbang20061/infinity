--
-- PostgreSQL database dump
--

\restrict P42LJif1F0ESaaeowoYX3xG20zZetmnx2gOSn5aCGG7b3iYUBDMamvo2RNFlyWV

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: operationcategories; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.operationcategories (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: operationcategories; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.operationcategories (row_no, key, data) FROM stdin;
0	31	{"_key": 31, "name": "Death Ship", "title": 523038, "iconPath": "res:/UI/Texture/defaultFace.jpg", "iskReward": 0, "description": 523039, "operationTrees": [171], "notificationTitle": 523040, "notificationDescription": 523041}
1	32	{"_key": 32, "name": "Death Pod", "title": 523042, "iconPath": "res:/UI/Texture/defaultFace.jpg", "iskReward": 0, "description": 523043, "operationTrees": [172], "notificationTitle": 523044, "notificationDescription": 523045}
2	2113	{"_key": 2113, "name": "Decluttered Start", "title": 560399, "iconPath": "res:/UI/Texture/defaultFace.jpg", "iskReward": 0, "description": 560397, "operationTrees": [2437], "notificationTitle": 560396, "notificationDescription": 560398}
3	2115	{"_key": 2115, "name": "Combat Career Path (1)", "title": 560479, "iconPath": "res:/UI/Texture/classes/agency/Icons/resourceWars.png", "iskReward": 0, "description": 560477, "operationTrees": [2438, 2439, 2440, 2441, 2442, 2443, 2444], "notificationTitle": 560476, "notificationDescription": 560478}
4	2122	{"_key": 2122, "name": "[AIR NPE] Experience", "title": 576775, "iconPath": "res:/UI/Texture/defaultFace.jpg", "iskReward": 0, "description": 576776, "operationTrees": [2460], "notificationTitle": 576777, "notificationDescription": 576778}
5	2125	{"_key": 2125, "name": "OdysseyExperience Scene 2", "title": 577089, "iconPath": "res:/UI/Texture/Corps/1.png", "iskReward": 0, "description": 577086, "operationTrees": [2465], "notificationTitle": 577088, "notificationDescription": 577087}
6	2126	{"_key": 2126, "name": "TreatmentCategory", "title": 577314, "iconPath": "res:/UI/Texture/classes/agency/Icons/resourceWars.png", "iskReward": 0, "description": 577311, "operationTrees": [2480, 2481, 2482, 2468, 2470, 2472, 2474, 2476, 2477, 2479, 2484, 2485], "notificationTitle": 577313, "notificationDescription": 577312}
7	2132	{"_key": 2132, "name": "User Test Treatments", "title": 584163, "iconPath": "res:/UI/Texture/classes/agency/Icons/resourceWars.png", "iskReward": 0, "description": 584160, "operationTrees": [2478], "notificationTitle": 584162, "notificationDescription": 584161}
\.


--
-- Name: operationcategories operationcategories_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.operationcategories
    ADD CONSTRAINT operationcategories_pkey PRIMARY KEY (row_no);


--
-- Name: operationcategories_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX operationcategories_key_idx ON sde_native.operationcategories USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict P42LJif1F0ESaaeowoYX3xG20zZetmnx2gOSn5aCGG7b3iYUBDMamvo2RNFlyWV

