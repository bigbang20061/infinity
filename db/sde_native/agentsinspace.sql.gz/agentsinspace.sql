--
-- PostgreSQL database dump
--

\restrict vNZaxe6699wGbVe2qiZkSbp2nOEivCEnhuWaRK2cHPkcefHHK08LD76A7IsMsPZ

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agentsinspace; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.agentsinspace (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: agentsinspace; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.agentsinspace (row_no, key, data) FROM stdin;
0	3018343	{"_key": 3018343, "typeID": 20520, "dungeonID": 416, "spawnPointID": 4239, "solarSystemID": 30000165}
1	3018344	{"_key": 3018344, "typeID": 20529, "dungeonID": 422, "spawnPointID": 4271, "solarSystemID": 30000165}
2	3018345	{"_key": 3018345, "typeID": 20534, "dungeonID": 416, "spawnPointID": 4239, "solarSystemID": 30000165}
3	3018346	{"_key": 3018346, "typeID": 20535, "dungeonID": 422, "spawnPointID": 4271, "solarSystemID": 30000165}
4	3018347	{"_key": 3018347, "typeID": 20536, "dungeonID": 416, "spawnPointID": 4239, "solarSystemID": 30000165}
5	3018350	{"_key": 3018350, "typeID": 20643, "dungeonID": 423, "spawnPointID": 4280, "solarSystemID": 30000166}
6	3018351	{"_key": 3018351, "typeID": 20644, "dungeonID": 423, "spawnPointID": 4280, "solarSystemID": 30000166}
7	3018352	{"_key": 3018352, "typeID": 20645, "dungeonID": 423, "spawnPointID": 4280, "solarSystemID": 30000166}
8	3018353	{"_key": 3018353, "typeID": 20646, "dungeonID": 424, "spawnPointID": 4281, "solarSystemID": 30000166}
9	3018357	{"_key": 3018357, "typeID": 20650, "dungeonID": 425, "spawnPointID": 4263, "solarSystemID": 30000167}
10	3018358	{"_key": 3018358, "typeID": 20651, "dungeonID": 425, "spawnPointID": 4263, "solarSystemID": 30000167}
11	3018359	{"_key": 3018359, "typeID": 20652, "dungeonID": 426, "spawnPointID": 4276, "solarSystemID": 30000167}
12	3018361	{"_key": 3018361, "typeID": 20654, "dungeonID": 426, "spawnPointID": 4276, "solarSystemID": 30000167}
13	3018363	{"_key": 3018363, "typeID": 20656, "dungeonID": 426, "spawnPointID": 4276, "solarSystemID": 30000167}
14	3018364	{"_key": 3018364, "typeID": 20657, "dungeonID": 426, "spawnPointID": 4276, "solarSystemID": 30000167}
15	3018365	{"_key": 3018365, "typeID": 20658, "dungeonID": 426, "spawnPointID": 4276, "solarSystemID": 30000167}
16	3018366	{"_key": 3018366, "typeID": 20521, "dungeonID": 436, "spawnPointID": 4243, "solarSystemID": 30000172}
17	3018367	{"_key": 3018367, "typeID": 20659, "dungeonID": 427, "spawnPointID": 4362, "solarSystemID": 30000170}
18	3018368	{"_key": 3018368, "typeID": 20660, "dungeonID": 428, "spawnPointID": 4270, "solarSystemID": 30000170}
19	3018369	{"_key": 3018369, "typeID": 20661, "dungeonID": 427, "spawnPointID": 4362, "solarSystemID": 30000170}
20	3018370	{"_key": 3018370, "typeID": 20662, "dungeonID": 428, "spawnPointID": 4270, "solarSystemID": 30000170}
21	3018371	{"_key": 3018371, "typeID": 20663, "dungeonID": 428, "spawnPointID": 4270, "solarSystemID": 30000170}
22	3018372	{"_key": 3018372, "typeID": 20664, "dungeonID": 427, "spawnPointID": 4362, "solarSystemID": 30000170}
23	3018374	{"_key": 3018374, "typeID": 20666, "dungeonID": 430, "spawnPointID": 4249, "solarSystemID": 30000168}
24	3018375	{"_key": 3018375, "typeID": 20667, "dungeonID": 495, "spawnPointID": 4275, "solarSystemID": 30000168}
25	3018376	{"_key": 3018376, "typeID": 20668, "dungeonID": 430, "spawnPointID": 4249, "solarSystemID": 30000168}
26	3018377	{"_key": 3018377, "typeID": 20669, "dungeonID": 432, "spawnPointID": 4363, "solarSystemID": 30000168}
27	3018378	{"_key": 3018378, "typeID": 20670, "dungeonID": 432, "spawnPointID": 4363, "solarSystemID": 30000168}
28	3018379	{"_key": 3018379, "typeID": 20671, "dungeonID": 430, "spawnPointID": 4249, "solarSystemID": 30000168}
29	3018381	{"_key": 3018381, "typeID": 20673, "dungeonID": 495, "spawnPointID": 4275, "solarSystemID": 30000168}
30	3018385	{"_key": 3018385, "typeID": 20677, "dungeonID": 435, "spawnPointID": 4364, "solarSystemID": 30000169}
31	3018386	{"_key": 3018386, "typeID": 20678, "dungeonID": 435, "spawnPointID": 4364, "solarSystemID": 30000169}
32	3018387	{"_key": 3018387, "typeID": 20679, "dungeonID": 435, "spawnPointID": 4364, "solarSystemID": 30000169}
33	3018388	{"_key": 3018388, "typeID": 20680, "dungeonID": 433, "spawnPointID": 4277, "solarSystemID": 30000169}
34	3018389	{"_key": 3018389, "typeID": 20681, "dungeonID": 433, "spawnPointID": 4277, "solarSystemID": 30000169}
35	3018391	{"_key": 3018391, "typeID": 22319, "dungeonID": 437, "spawnPointID": 4251, "solarSystemID": 30000172}
36	3018392	{"_key": 3018392, "typeID": 20684, "dungeonID": 437, "spawnPointID": 4251, "solarSystemID": 30000172}
37	3018394	{"_key": 3018394, "typeID": 20686, "dungeonID": 437, "spawnPointID": 4251, "solarSystemID": 30000172}
38	3018395	{"_key": 3018395, "typeID": 20687, "dungeonID": 438, "spawnPointID": 4257, "solarSystemID": 30000172}
39	3018396	{"_key": 3018396, "typeID": 20688, "dungeonID": 436, "spawnPointID": 4243, "solarSystemID": 30000172}
40	3018398	{"_key": 3018398, "typeID": 20690, "dungeonID": 438, "spawnPointID": 4257, "solarSystemID": 30000172}
41	3018399	{"_key": 3018399, "typeID": 20691, "dungeonID": 439, "spawnPointID": 4242, "solarSystemID": 30000171}
42	3018400	{"_key": 3018400, "typeID": 20692, "dungeonID": 440, "spawnPointID": 4237, "solarSystemID": 30000171}
43	3018401	{"_key": 3018401, "typeID": 20693, "dungeonID": 439, "spawnPointID": 4242, "solarSystemID": 30000171}
44	3018402	{"_key": 3018402, "typeID": 20694, "dungeonID": 439, "spawnPointID": 4242, "solarSystemID": 30000171}
45	3018404	{"_key": 3018404, "typeID": 20696, "dungeonID": 439, "spawnPointID": 4242, "solarSystemID": 30000171}
46	3018405	{"_key": 3018405, "typeID": 20697, "dungeonID": 440, "spawnPointID": 4237, "solarSystemID": 30000171}
47	3018408	{"_key": 3018408, "typeID": 20683, "dungeonID": 436, "spawnPointID": 4243, "solarSystemID": 30000172}
48	3018409	{"_key": 3018409, "typeID": 21132, "dungeonID": 453, "spawnPointID": 4329, "solarSystemID": 30002068}
49	3018410	{"_key": 3018410, "typeID": 21133, "dungeonID": 453, "spawnPointID": 4329, "solarSystemID": 30002068}
50	3018411	{"_key": 3018411, "typeID": 21134, "dungeonID": 453, "spawnPointID": 4329, "solarSystemID": 30002068}
51	3018412	{"_key": 3018412, "typeID": 21135, "dungeonID": 453, "spawnPointID": 4329, "solarSystemID": 30002068}
52	3018413	{"_key": 3018413, "typeID": 21136, "dungeonID": 454, "spawnPointID": 4330, "solarSystemID": 30002068}
53	3018414	{"_key": 3018414, "typeID": 21137, "dungeonID": 454, "spawnPointID": 4330, "solarSystemID": 30002068}
54	3018415	{"_key": 3018415, "typeID": 21138, "dungeonID": 455, "spawnPointID": 4357, "solarSystemID": 30002072}
55	3018416	{"_key": 3018416, "typeID": 21139, "dungeonID": 455, "spawnPointID": 4357, "solarSystemID": 30002072}
56	3018417	{"_key": 3018417, "typeID": 21145, "dungeonID": 458, "spawnPointID": 4297, "solarSystemID": 30002074}
57	3018418	{"_key": 3018418, "typeID": 21149, "dungeonID": 459, "spawnPointID": 4295, "solarSystemID": 30002074}
58	3018419	{"_key": 3018419, "typeID": 21150, "dungeonID": 460, "spawnPointID": 4298, "solarSystemID": 30002073}
59	3018420	{"_key": 3018420, "typeID": 21151, "dungeonID": 460, "spawnPointID": 4298, "solarSystemID": 30002073}
60	3018421	{"_key": 3018421, "typeID": 21153, "dungeonID": 461, "spawnPointID": 4299, "solarSystemID": 30002073}
61	3018422	{"_key": 3018422, "typeID": 21156, "dungeonID": 462, "spawnPointID": 4325, "solarSystemID": 30002070}
62	3018423	{"_key": 3018423, "typeID": 21161, "dungeonID": 465, "spawnPointID": 4292, "solarSystemID": 30002071}
63	3018424	{"_key": 3018424, "typeID": 21169, "dungeonID": 469, "spawnPointID": 4286, "solarSystemID": 30002069}
64	3018425	{"_key": 3018425, "typeID": 21170, "dungeonID": 469, "spawnPointID": 4286, "solarSystemID": 30002069}
65	3018426	{"_key": 3018426, "typeID": 21171, "dungeonID": 469, "spawnPointID": 4286, "solarSystemID": 30002069}
66	3018427	{"_key": 3018427, "typeID": 21174, "dungeonID": 471, "spawnPointID": 4301, "solarSystemID": 30002075}
67	3018428	{"_key": 3018428, "typeID": 21176, "dungeonID": 471, "spawnPointID": 4301, "solarSystemID": 30002075}
68	3018429	{"_key": 3018429, "typeID": 21177, "dungeonID": 472, "spawnPointID": 4306, "solarSystemID": 30002075}
69	3018430	{"_key": 3018430, "typeID": 21178, "dungeonID": 472, "spawnPointID": 4306, "solarSystemID": 30002075}
70	3018432	{"_key": 3018432, "typeID": 21147, "dungeonID": 458, "spawnPointID": 4297, "solarSystemID": 30002074}
71	3018433	{"_key": 3018433, "typeID": 21152, "dungeonID": 460, "spawnPointID": 4298, "solarSystemID": 30002073}
72	3018434	{"_key": 3018434, "typeID": 21155, "dungeonID": 462, "spawnPointID": 4325, "solarSystemID": 30002070}
73	3018435	{"_key": 3018435, "typeID": 21157, "dungeonID": 463, "spawnPointID": 4326, "solarSystemID": 30002070}
74	3018436	{"_key": 3018436, "typeID": 21158, "dungeonID": 463, "spawnPointID": 4326, "solarSystemID": 30002070}
75	3018437	{"_key": 3018437, "typeID": 21162, "dungeonID": 465, "spawnPointID": 4292, "solarSystemID": 30002071}
76	3018438	{"_key": 3018438, "typeID": 21163, "dungeonID": 466, "spawnPointID": 4293, "solarSystemID": 30002071}
77	3018439	{"_key": 3018439, "typeID": 21164, "dungeonID": 466, "spawnPointID": 4293, "solarSystemID": 30002071}
78	3018440	{"_key": 3018440, "typeID": 21167, "dungeonID": 468, "spawnPointID": 4285, "solarSystemID": 30002069}
79	3018441	{"_key": 3018441, "typeID": 21168, "dungeonID": 468, "spawnPointID": 4285, "solarSystemID": 30002069}
80	3018442	{"_key": 3018442, "typeID": 21179, "dungeonID": 472, "spawnPointID": 4306, "solarSystemID": 30002075}
81	3018443	{"_key": 3018443, "typeID": 21140, "dungeonID": 455, "spawnPointID": 4357, "solarSystemID": 30002072}
82	3018444	{"_key": 3018444, "typeID": 21141, "dungeonID": 456, "spawnPointID": 4358, "solarSystemID": 30002072}
83	3018445	{"_key": 3018445, "typeID": 21143, "dungeonID": 456, "spawnPointID": 4358, "solarSystemID": 30002072}
84	3018447	{"_key": 3018447, "typeID": 21146, "dungeonID": 458, "spawnPointID": 4297, "solarSystemID": 30002074}
85	3018448	{"_key": 3018448, "typeID": 21148, "dungeonID": 459, "spawnPointID": 4295, "solarSystemID": 30002074}
86	3018449	{"_key": 3018449, "typeID": 21154, "dungeonID": 461, "spawnPointID": 4299, "solarSystemID": 30002073}
87	3018450	{"_key": 3018450, "typeID": 21159, "dungeonID": 464, "spawnPointID": 4327, "solarSystemID": 30002070}
88	3018451	{"_key": 3018451, "typeID": 21160, "dungeonID": 464, "spawnPointID": 4327, "solarSystemID": 30002070}
89	3018453	{"_key": 3018453, "typeID": 24664, "dungeonID": 465, "spawnPointID": 4292, "solarSystemID": 30002071}
90	3018454	{"_key": 3018454, "typeID": 21172, "dungeonID": 470, "spawnPointID": 4287, "solarSystemID": 30002069}
91	3018455	{"_key": 3018455, "typeID": 21173, "dungeonID": 470, "spawnPointID": 4287, "solarSystemID": 30002069}
92	3018456	{"_key": 3018456, "typeID": 21175, "dungeonID": 471, "spawnPointID": 4301, "solarSystemID": 30002075}
93	3018458	{"_key": 3018458, "typeID": 21598, "dungeonID": 473, "spawnPointID": 4254, "solarSystemID": 30000172}
94	3018459	{"_key": 3018459, "typeID": 21844, "dungeonID": 508, "spawnPointID": 4283, "solarSystemID": 30004583}
95	3018460	{"_key": 3018460, "typeID": 23952, "dungeonID": 511, "spawnPointID": 4290, "solarSystemID": 30001159}
96	3018479	{"_key": 3018479, "typeID": 22081, "dungeonID": 466, "spawnPointID": 4293, "solarSystemID": 30002071}
97	3018480	{"_key": 3018480, "typeID": 22180, "dungeonID": 1063, "spawnPointID": 4543, "solarSystemID": 30002548}
98	3018481	{"_key": 3018481, "typeID": 22179, "dungeonID": 1062, "spawnPointID": 4542, "solarSystemID": 30003454}
99	3018482	{"_key": 3018482, "typeID": 22181, "dungeonID": 1064, "spawnPointID": 4544, "solarSystemID": 30003374}
100	3018485	{"_key": 3018485, "typeID": 22187, "dungeonID": 1069, "spawnPointID": 4549, "solarSystemID": 30003056}
101	3018486	{"_key": 3018486, "typeID": 22188, "dungeonID": 1068, "spawnPointID": 4548, "solarSystemID": 30005317}
102	3018487	{"_key": 3018487, "typeID": 22186, "dungeonID": 1070, "spawnPointID": 4550, "solarSystemID": 30002713}
103	3018488	{"_key": 3018488, "typeID": 22190, "dungeonID": 1065, "spawnPointID": 4545, "solarSystemID": 30005048}
104	3018489	{"_key": 3018489, "typeID": 22390, "dungeonID": 1066, "spawnPointID": 4546, "solarSystemID": 30003501}
105	3018490	{"_key": 3018490, "typeID": 22192, "dungeonID": 1067, "spawnPointID": 4547, "solarSystemID": 30001709}
106	3018491	{"_key": 3018491, "typeID": 22197, "dungeonID": 1060, "spawnPointID": 4540, "solarSystemID": 30000125}
107	3018492	{"_key": 3018492, "typeID": 22196, "dungeonID": 1061, "spawnPointID": 4541, "solarSystemID": 30002745}
108	3018493	{"_key": 3018493, "typeID": 22195, "dungeonID": 1058, "spawnPointID": 4538, "solarSystemID": 30001406}
109	3018494	{"_key": 3018494, "typeID": 22625, "dungeonID": 575, "spawnPointID": 4383, "solarSystemID": 30000171}
110	3018495	{"_key": 3018495, "typeID": 22629, "dungeonID": 575, "spawnPointID": 4383, "solarSystemID": 30000171}
111	3018496	{"_key": 3018496, "typeID": 22630, "dungeonID": 575, "spawnPointID": 4383, "solarSystemID": 30000171}
112	3018497	{"_key": 3018497, "typeID": 22631, "dungeonID": 577, "spawnPointID": 4384, "solarSystemID": 30002071}
113	3018499	{"_key": 3018499, "typeID": 22633, "dungeonID": 577, "spawnPointID": 4384, "solarSystemID": 30002071}
114	3018500	{"_key": 3018500, "typeID": 22632, "dungeonID": 577, "spawnPointID": 4384, "solarSystemID": 30002071}
115	3018501	{"_key": 3018501, "typeID": 22635, "dungeonID": 578, "spawnPointID": 4393, "solarSystemID": 30002679}
116	3018502	{"_key": 3018502, "typeID": 22637, "dungeonID": 578, "spawnPointID": 4393, "solarSystemID": 30002679}
117	3018503	{"_key": 3018503, "typeID": 22639, "dungeonID": 578, "spawnPointID": 4393, "solarSystemID": 30002679}
118	3018504	{"_key": 3018504, "typeID": 22640, "dungeonID": 579, "spawnPointID": 4394, "solarSystemID": 30004125}
119	3018505	{"_key": 3018505, "typeID": 22641, "dungeonID": 579, "spawnPointID": 4394, "solarSystemID": 30004125}
120	3018506	{"_key": 3018506, "typeID": 22643, "dungeonID": 579, "spawnPointID": 4394, "solarSystemID": 30004125}
121	3018508	{"_key": 3018508, "typeID": 22644, "dungeonID": 580, "spawnPointID": 4388, "solarSystemID": 30001046}
122	3018509	{"_key": 3018509, "typeID": 22645, "dungeonID": 580, "spawnPointID": 4388, "solarSystemID": 30001046}
123	3018510	{"_key": 3018510, "typeID": 22646, "dungeonID": 580, "spawnPointID": 4388, "solarSystemID": 30001046}
124	3018511	{"_key": 3018511, "typeID": 22647, "dungeonID": 581, "spawnPointID": 4389, "solarSystemID": 30001267}
125	3018512	{"_key": 3018512, "typeID": 22648, "dungeonID": 581, "spawnPointID": 4389, "solarSystemID": 30001267}
126	3018513	{"_key": 3018513, "typeID": 22649, "dungeonID": 581, "spawnPointID": 4389, "solarSystemID": 30001267}
127	3018514	{"_key": 3018514, "typeID": 22650, "dungeonID": 582, "spawnPointID": 4390, "solarSystemID": 30004618}
128	3018515	{"_key": 3018515, "typeID": 22651, "dungeonID": 582, "spawnPointID": 4390, "solarSystemID": 30004618}
129	3018516	{"_key": 3018516, "typeID": 22652, "dungeonID": 582, "spawnPointID": 4390, "solarSystemID": 30004618}
130	3018517	{"_key": 3018517, "typeID": 22653, "dungeonID": 583, "spawnPointID": 4391, "solarSystemID": 30001837}
131	3018518	{"_key": 3018518, "typeID": 22654, "dungeonID": 583, "spawnPointID": 4391, "solarSystemID": 30001837}
132	3018519	{"_key": 3018519, "typeID": 22655, "dungeonID": 583, "spawnPointID": 4391, "solarSystemID": 30001837}
133	3018520	{"_key": 3018520, "typeID": 22656, "dungeonID": 584, "spawnPointID": 4392, "solarSystemID": 30004709}
134	3018521	{"_key": 3018521, "typeID": 22657, "dungeonID": 584, "spawnPointID": 4392, "solarSystemID": 30004709}
135	3018522	{"_key": 3018522, "typeID": 22658, "dungeonID": 584, "spawnPointID": 4392, "solarSystemID": 30004709}
136	3018523	{"_key": 3018523, "typeID": 22693, "dungeonID": 585, "spawnPointID": 4395, "solarSystemID": 30000034}
137	3018524	{"_key": 3018524, "typeID": 22694, "dungeonID": 586, "spawnPointID": 4396, "solarSystemID": 30003862}
138	3018525	{"_key": 3018525, "typeID": 22695, "dungeonID": 587, "spawnPointID": 4397, "solarSystemID": 30004504}
139	3018526	{"_key": 3018526, "typeID": 22696, "dungeonID": 588, "spawnPointID": 4398, "solarSystemID": 30002005}
140	3018527	{"_key": 3018527, "typeID": 22699, "dungeonID": 589, "spawnPointID": 4399, "solarSystemID": 30003297}
141	3018528	{"_key": 3018528, "typeID": 22700, "dungeonID": 590, "spawnPointID": 4400, "solarSystemID": 30000965}
142	3018529	{"_key": 3018529, "typeID": 22719, "dungeonID": 591, "spawnPointID": 4403, "solarSystemID": 30000116}
143	3018531	{"_key": 3018531, "typeID": 22735, "dungeonID": 591, "spawnPointID": 4403, "solarSystemID": 30000116}
144	3018532	{"_key": 3018532, "typeID": 22736, "dungeonID": 591, "spawnPointID": 4403, "solarSystemID": 30000116}
145	3018534	{"_key": 3018534, "typeID": 22734, "dungeonID": 591, "spawnPointID": 4403, "solarSystemID": 30000116}
146	3018535	{"_key": 3018535, "typeID": 22762, "dungeonID": 594, "spawnPointID": 4401, "solarSystemID": 30002395}
147	3018536	{"_key": 3018536, "typeID": 22763, "dungeonID": 591, "spawnPointID": 4403, "solarSystemID": 30000116}
148	3018537	{"_key": 3018537, "typeID": 22769, "dungeonID": 594, "spawnPointID": 4401, "solarSystemID": 30002395}
149	3018538	{"_key": 3018538, "typeID": 22768, "dungeonID": 594, "spawnPointID": 4401, "solarSystemID": 30002395}
150	3018539	{"_key": 3018539, "typeID": 22767, "dungeonID": 594, "spawnPointID": 4401, "solarSystemID": 30002395}
151	3018540	{"_key": 3018540, "typeID": 23065, "dungeonID": 611, "spawnPointID": 4419, "solarSystemID": 30002684}
152	3018541	{"_key": 3018541, "typeID": 23066, "dungeonID": 611, "spawnPointID": 4419, "solarSystemID": 30002684}
153	3018542	{"_key": 3018542, "typeID": 23063, "dungeonID": 610, "spawnPointID": 4418, "solarSystemID": 30002678}
154	3018543	{"_key": 3018543, "typeID": 23070, "dungeonID": 608, "spawnPointID": 4414, "solarSystemID": 30002680}
155	3018544	{"_key": 3018544, "typeID": 23122, "dungeonID": 605, "spawnPointID": 4409, "solarSystemID": 30002681}
156	3018545	{"_key": 3018545, "typeID": 23088, "dungeonID": 608, "spawnPointID": 4414, "solarSystemID": 30002680}
157	3018551	{"_key": 3018551, "typeID": 23127, "dungeonID": 606, "spawnPointID": 4413, "solarSystemID": 30002676}
158	3018552	{"_key": 3018552, "typeID": 23067, "dungeonID": 612, "spawnPointID": 4420, "solarSystemID": 30002683}
159	3018553	{"_key": 3018553, "typeID": 23064, "dungeonID": 610, "spawnPointID": 4418, "solarSystemID": 30002678}
160	3018554	{"_key": 3018554, "typeID": 23068, "dungeonID": 612, "spawnPointID": 4420, "solarSystemID": 30002683}
161	3018555	{"_key": 3018555, "typeID": 23126, "dungeonID": 606, "spawnPointID": 4413, "solarSystemID": 30002676}
162	3018556	{"_key": 3018556, "typeID": 23125, "dungeonID": 605, "spawnPointID": 4409, "solarSystemID": 30002681}
163	3018558	{"_key": 3018558, "typeID": 22844, "dungeonID": 594, "spawnPointID": 4401, "solarSystemID": 30002395}
164	3018559	{"_key": 3018559, "typeID": 22845, "dungeonID": 591, "spawnPointID": 4403, "solarSystemID": 30000116}
165	3018561	{"_key": 3018561, "typeID": 23238, "dungeonID": 591, "spawnPointID": 4403, "solarSystemID": 30000116}
166	3018562	{"_key": 3018562, "typeID": 23239, "dungeonID": 594, "spawnPointID": 4401, "solarSystemID": 30002395}
167	3018563	{"_key": 3018563, "typeID": 23304, "dungeonID": 604, "spawnPointID": 4410, "solarSystemID": 30002682}
168	3018564	{"_key": 3018564, "typeID": 23311, "dungeonID": 607, "spawnPointID": 4415, "solarSystemID": 30002677}
169	3018565	{"_key": 3018565, "typeID": 23456, "dungeonID": 609, "spawnPointID": 4416, "solarSystemID": 30002679}
170	3018567	{"_key": 3018567, "typeID": 23565, "dungeonID": 609, "spawnPointID": 4416, "solarSystemID": 30002679}
171	3018568	{"_key": 3018568, "typeID": 23603, "dungeonID": 607, "spawnPointID": 4415, "solarSystemID": 30002677}
172	3018569	{"_key": 3018569, "typeID": 23608, "dungeonID": 636, "spawnPointID": 4424, "solarSystemID": 30002677}
173	3018570	{"_key": 3018570, "typeID": 23613, "dungeonID": 607, "spawnPointID": 4415, "solarSystemID": 30002677}
174	3018571	{"_key": 3018571, "typeID": 23620, "dungeonID": 604, "spawnPointID": 4410, "solarSystemID": 30002682}
175	3018572	{"_key": 3018572, "typeID": 23625, "dungeonID": 622, "spawnPointID": 4411, "solarSystemID": 30002682}
176	3018573	{"_key": 3018573, "typeID": 23636, "dungeonID": 651, "spawnPointID": 4428, "solarSystemID": 30004123}
177	3018574	{"_key": 3018574, "typeID": 23637, "dungeonID": 654, "spawnPointID": 4431, "solarSystemID": 30004122}
178	3018575	{"_key": 3018575, "typeID": 23666, "dungeonID": 665, "spawnPointID": 4434, "solarSystemID": 30002676}
179	3018576	{"_key": 3018576, "typeID": 23697, "dungeonID": 653, "spawnPointID": 4430, "solarSystemID": 30004122}
180	3018577	{"_key": 3018577, "typeID": 23698, "dungeonID": 653, "spawnPointID": 4430, "solarSystemID": 30004122}
181	3018578	{"_key": 3018578, "typeID": 23746, "dungeonID": 666, "spawnPointID": 4433, "solarSystemID": 30004129}
182	3018579	{"_key": 3018579, "typeID": 23765, "dungeonID": 652, "spawnPointID": 4429, "solarSystemID": 30004125}
183	3018580	{"_key": 3018580, "typeID": 23768, "dungeonID": 1058, "spawnPointID": 4538, "solarSystemID": 30001406}
184	3018581	{"_key": 3018581, "typeID": 23769, "dungeonID": 1060, "spawnPointID": 4540, "solarSystemID": 30000125}
185	3018582	{"_key": 3018582, "typeID": 23770, "dungeonID": 1061, "spawnPointID": 4541, "solarSystemID": 30002745}
186	3018583	{"_key": 3018583, "typeID": 23771, "dungeonID": 672, "spawnPointID": 4435, "solarSystemID": 30000140}
187	3018586	{"_key": 3018586, "typeID": 23772, "dungeonID": 673, "spawnPointID": 4436, "solarSystemID": 30001404}
188	3018592	{"_key": 3018592, "typeID": 23831, "dungeonID": 678, "spawnPointID": 4454, "solarSystemID": 30004127}
189	3018593	{"_key": 3018593, "typeID": 23832, "dungeonID": 678, "spawnPointID": 4454, "solarSystemID": 30004127}
190	3018604	{"_key": 3018604, "typeID": 23881, "dungeonID": 682, "spawnPointID": 4453, "solarSystemID": 30004126}
191	3018621	{"_key": 3018621, "typeID": 23947, "dungeonID": 693, "spawnPointID": 4445, "solarSystemID": 30004128}
192	3018622	{"_key": 3018622, "typeID": 23946, "dungeonID": 700, "spawnPointID": 4446, "solarSystemID": 30004129}
193	3018633	{"_key": 3018633, "typeID": 24240, "dungeonID": 700, "spawnPointID": 4446, "solarSystemID": 30004129}
194	3018634	{"_key": 3018634, "typeID": 24239, "dungeonID": 693, "spawnPointID": 4445, "solarSystemID": 30004128}
195	3018638	{"_key": 3018638, "typeID": 24295, "dungeonID": 720, "spawnPointID": 4452, "solarSystemID": 30004124}
196	3018639	{"_key": 3018639, "typeID": 24294, "dungeonID": 724, "spawnPointID": 4457, "solarSystemID": 30004126}
197	3018640	{"_key": 3018640, "typeID": 24290, "dungeonID": 724, "spawnPointID": 4457, "solarSystemID": 30004126}
198	3018641	{"_key": 3018641, "typeID": 24296, "dungeonID": 720, "spawnPointID": 4452, "solarSystemID": 30004124}
199	3018642	{"_key": 3018642, "typeID": 24350, "dungeonID": 726, "spawnPointID": 4455, "solarSystemID": 30002681}
200	3018643	{"_key": 3018643, "typeID": 24463, "dungeonID": 740, "spawnPointID": 4461, "solarSystemID": 30004127}
201	3018644	{"_key": 3018644, "typeID": 24467, "dungeonID": 740, "spawnPointID": 4461, "solarSystemID": 30004127}
202	3018645	{"_key": 3018645, "typeID": 24709, "dungeonID": 1058, "spawnPointID": 4538, "solarSystemID": 30001406}
203	3018646	{"_key": 3018646, "typeID": 24710, "dungeonID": 1060, "spawnPointID": 4540, "solarSystemID": 30000125}
204	3018647	{"_key": 3018647, "typeID": 24711, "dungeonID": 1061, "spawnPointID": 4541, "solarSystemID": 30002745}
205	3018648	{"_key": 3018648, "typeID": 24712, "dungeonID": 799, "spawnPointID": 4481, "solarSystemID": 30001411}
206	3018650	{"_key": 3018650, "typeID": 24723, "dungeonID": 804, "spawnPointID": 4490, "solarSystemID": 30003025}
207	3018656	{"_key": 3018656, "typeID": 24732, "dungeonID": 811, "spawnPointID": 4803, "solarSystemID": 30003491}
208	3018659	{"_key": 3018659, "typeID": 24737, "dungeonID": 1067, "spawnPointID": 4547, "solarSystemID": 30001709}
209	3018660	{"_key": 3018660, "typeID": 24738, "dungeonID": 1066, "spawnPointID": 4546, "solarSystemID": 30003501}
210	3018661	{"_key": 3018661, "typeID": 24739, "dungeonID": 1065, "spawnPointID": 4545, "solarSystemID": 30005048}
211	3018662	{"_key": 3018662, "typeID": 24740, "dungeonID": 1068, "spawnPointID": 4548, "solarSystemID": 30005317}
212	3018663	{"_key": 3018663, "typeID": 24741, "dungeonID": 1070, "spawnPointID": 4550, "solarSystemID": 30002713}
213	3018664	{"_key": 3018664, "typeID": 24742, "dungeonID": 1069, "spawnPointID": 4549, "solarSystemID": 30003056}
214	3018669	{"_key": 3018669, "typeID": 24746, "dungeonID": 1063, "spawnPointID": 4543, "solarSystemID": 30002548}
215	3018670	{"_key": 3018670, "typeID": 24747, "dungeonID": 1062, "spawnPointID": 4542, "solarSystemID": 30003454}
216	3018671	{"_key": 3018671, "typeID": 24748, "dungeonID": 1064, "spawnPointID": 4544, "solarSystemID": 30003374}
217	3018674	{"_key": 3018674, "typeID": 24758, "dungeonID": 836, "spawnPointID": 4494, "solarSystemID": 30003413}
218	3018713	{"_key": 3018713, "typeID": 25368, "dungeonID": 887, "spawnPointID": 4968, "solarSystemID": 30000309}
219	3018714	{"_key": 3018714, "typeID": 25365, "dungeonID": 917, "spawnPointID": 4505, "solarSystemID": 30000310}
220	3018715	{"_key": 3018715, "typeID": 25371, "dungeonID": 892, "spawnPointID": 4503, "solarSystemID": 30000310}
221	3018717	{"_key": 3018717, "typeID": 25392, "dungeonID": 1012, "spawnPointID": 4507, "solarSystemID": 30000310}
222	3018718	{"_key": 3018718, "typeID": 25351, "dungeonID": 889, "spawnPointID": 4967, "solarSystemID": 30000311}
223	3018720	{"_key": 3018720, "typeID": 25396, "dungeonID": 1020, "spawnPointID": 4951, "solarSystemID": 30000313}
224	3018721	{"_key": 3018721, "typeID": 25403, "dungeonID": 1025, "spawnPointID": 4509, "solarSystemID": 30000311}
225	3018722	{"_key": 3018722, "typeID": 25404, "dungeonID": 1026, "spawnPointID": 4510, "solarSystemID": 30000313}
226	3018723	{"_key": 3018723, "typeID": 25405, "dungeonID": 1027, "spawnPointID": 4511, "solarSystemID": 30000308}
227	3018724	{"_key": 3018724, "typeID": 25406, "dungeonID": 1028, "spawnPointID": 4512, "solarSystemID": 30000307}
228	3018725	{"_key": 3018725, "typeID": 25409, "dungeonID": 1029, "spawnPointID": 4513, "solarSystemID": 30000308}
229	3018726	{"_key": 3018726, "typeID": 25415, "dungeonID": 1031, "spawnPointID": 4514, "solarSystemID": 30003617}
230	3018727	{"_key": 3018727, "typeID": 25416, "dungeonID": 1032, "spawnPointID": 4515, "solarSystemID": 30003621}
231	3018728	{"_key": 3018728, "typeID": 25417, "dungeonID": 1033, "spawnPointID": 4516, "solarSystemID": 30003620}
232	3018729	{"_key": 3018729, "typeID": 25418, "dungeonID": 1037, "spawnPointID": 4520, "solarSystemID": 30001203}
233	3018730	{"_key": 3018730, "typeID": 25419, "dungeonID": 1035, "spawnPointID": 4518, "solarSystemID": 30001202}
234	3018731	{"_key": 3018731, "typeID": 25420, "dungeonID": 1034, "spawnPointID": 4517, "solarSystemID": 30001200}
235	3018732	{"_key": 3018732, "typeID": 25421, "dungeonID": 1036, "spawnPointID": 4519, "solarSystemID": 30001198}
236	3018733	{"_key": 3018733, "typeID": 25422, "dungeonID": 1038, "spawnPointID": 4521, "solarSystemID": 30004801}
237	3018734	{"_key": 3018734, "typeID": 25423, "dungeonID": 1040, "spawnPointID": 4523, "solarSystemID": 30004798}
238	3018735	{"_key": 3018735, "typeID": 25424, "dungeonID": 1041, "spawnPointID": 4524, "solarSystemID": 30004796}
239	3018736	{"_key": 3018736, "typeID": 25425, "dungeonID": 1039, "spawnPointID": 4522, "solarSystemID": 30004800}
240	3018737	{"_key": 3018737, "typeID": 25430, "dungeonID": 1042, "spawnPointID": 4525, "solarSystemID": 30004557}
241	3018738	{"_key": 3018738, "typeID": 25431, "dungeonID": 1043, "spawnPointID": 4526, "solarSystemID": 30004557}
242	3018739	{"_key": 3018739, "typeID": 25432, "dungeonID": 1044, "spawnPointID": 4527, "solarSystemID": 30004556}
243	3018740	{"_key": 3018740, "typeID": 25433, "dungeonID": 1045, "spawnPointID": 4528, "solarSystemID": 30004554}
244	3018741	{"_key": 3018741, "typeID": 25434, "dungeonID": 1046, "spawnPointID": 4529, "solarSystemID": 30004552}
245	3018742	{"_key": 3018742, "typeID": 25436, "dungeonID": 1048, "spawnPointID": 4531, "solarSystemID": 30004069}
246	3018743	{"_key": 3018743, "typeID": 25435, "dungeonID": 1047, "spawnPointID": 4530, "solarSystemID": 30004065}
247	3018744	{"_key": 3018744, "typeID": 25437, "dungeonID": 1049, "spawnPointID": 4532, "solarSystemID": 30004070}
248	3018745	{"_key": 3018745, "typeID": 25440, "dungeonID": 1052, "spawnPointID": 4533, "solarSystemID": 30004424}
249	3018746	{"_key": 3018746, "typeID": 25439, "dungeonID": 1051, "spawnPointID": 4537, "solarSystemID": 30004419}
250	3018747	{"_key": 3018747, "typeID": 25438, "dungeonID": 1050, "spawnPointID": 4536, "solarSystemID": 30004418}
251	3018748	{"_key": 3018748, "typeID": 25449, "dungeonID": 1053, "spawnPointID": 4534, "solarSystemID": 30004422}
252	3018749	{"_key": 3018749, "typeID": 25450, "dungeonID": 1054, "spawnPointID": 4535, "solarSystemID": 30004423}
253	3018750	{"_key": 3018750, "typeID": 25455, "dungeonID": 1055, "spawnPointID": 4993, "solarSystemID": 30004421}
254	3018751	{"_key": 3018751, "typeID": 25456, "dungeonID": 1055, "spawnPointID": 4993, "solarSystemID": 30004421}
255	3018752	{"_key": 3018752, "typeID": 25457, "dungeonID": 1055, "spawnPointID": 4993, "solarSystemID": 30004421}
256	3018753	{"_key": 3018753, "typeID": 25458, "dungeonID": 1055, "spawnPointID": 4993, "solarSystemID": 30004421}
257	3018761	{"_key": 3018761, "typeID": 25464, "dungeonID": 1071, "spawnPointID": 4551, "solarSystemID": 30000594}
258	3018762	{"_key": 3018762, "typeID": 25466, "dungeonID": 1073, "spawnPointID": 4553, "solarSystemID": 30000598}
259	3018763	{"_key": 3018763, "typeID": 25465, "dungeonID": 1072, "spawnPointID": 4554, "solarSystemID": 30000596}
260	3018764	{"_key": 3018764, "typeID": 25518, "dungeonID": 1075, "spawnPointID": 4964, "solarSystemID": 30003618}
261	3018766	{"_key": 3018766, "typeID": 25519, "dungeonID": 1075, "spawnPointID": 4964, "solarSystemID": 30003618}
262	3018767	{"_key": 3018767, "typeID": 25520, "dungeonID": 1075, "spawnPointID": 4964, "solarSystemID": 30003618}
263	3018768	{"_key": 3018768, "typeID": 25582, "dungeonID": 1075, "spawnPointID": 4964, "solarSystemID": 30003618}
264	3018769	{"_key": 3018769, "typeID": 25583, "dungeonID": 1075, "spawnPointID": 4964, "solarSystemID": 30003618}
265	3018771	{"_key": 3018771, "typeID": 25531, "dungeonID": 1091, "spawnPointID": 4965, "solarSystemID": 30001202}
266	3018772	{"_key": 3018772, "typeID": 25532, "dungeonID": 1091, "spawnPointID": 4965, "solarSystemID": 30001202}
267	3018773	{"_key": 3018773, "typeID": 25533, "dungeonID": 1091, "spawnPointID": 4965, "solarSystemID": 30001202}
268	3018774	{"_key": 3018774, "typeID": 25534, "dungeonID": 1091, "spawnPointID": 4965, "solarSystemID": 30001202}
269	3018775	{"_key": 3018775, "typeID": 25535, "dungeonID": 1091, "spawnPointID": 4965, "solarSystemID": 30001202}
270	3018849	{"_key": 3018849, "typeID": 25722, "dungeonID": 1109, "spawnPointID": 4966, "solarSystemID": 30004799}
271	3018850	{"_key": 3018850, "typeID": 25830, "dungeonID": 1109, "spawnPointID": 4966, "solarSystemID": 30004799}
272	3018851	{"_key": 3018851, "typeID": 25831, "dungeonID": 1109, "spawnPointID": 4966, "solarSystemID": 30004799}
273	3018852	{"_key": 3018852, "typeID": 25832, "dungeonID": 1109, "spawnPointID": 4966, "solarSystemID": 30004799}
274	3018853	{"_key": 3018853, "typeID": 25740, "dungeonID": 1124, "spawnPointID": 4969, "solarSystemID": 30004558}
275	3018854	{"_key": 3018854, "typeID": 25741, "dungeonID": 1124, "spawnPointID": 4969, "solarSystemID": 30004558}
276	3018855	{"_key": 3018855, "typeID": 25742, "dungeonID": 1124, "spawnPointID": 4969, "solarSystemID": 30004558}
277	3018856	{"_key": 3018856, "typeID": 25743, "dungeonID": 1124, "spawnPointID": 4969, "solarSystemID": 30004558}
278	3018857	{"_key": 3018857, "typeID": 25744, "dungeonID": 1124, "spawnPointID": 4969, "solarSystemID": 30004558}
279	3018858	{"_key": 3018858, "typeID": 25749, "dungeonID": 1132, "spawnPointID": 4979, "solarSystemID": 30004065}
280	3018860	{"_key": 3018860, "typeID": 25747, "dungeonID": 1132, "spawnPointID": 4979, "solarSystemID": 30004065}
281	3018861	{"_key": 3018861, "typeID": 25745, "dungeonID": 1132, "spawnPointID": 4979, "solarSystemID": 30004065}
282	3018862	{"_key": 3018862, "typeID": 25746, "dungeonID": 1132, "spawnPointID": 4979, "solarSystemID": 30004065}
283	3018863	{"_key": 3018863, "typeID": 25750, "dungeonID": 1198, "spawnPointID": 4994, "solarSystemID": 30000595}
284	3018864	{"_key": 3018864, "typeID": 25751, "dungeonID": 1198, "spawnPointID": 4994, "solarSystemID": 30000595}
285	3018865	{"_key": 3018865, "typeID": 25752, "dungeonID": 1198, "spawnPointID": 4994, "solarSystemID": 30000595}
286	3018866	{"_key": 3018866, "typeID": 25753, "dungeonID": 1198, "spawnPointID": 4994, "solarSystemID": 30000595}
287	3018867	{"_key": 3018867, "typeID": 25754, "dungeonID": 1198, "spawnPointID": 4994, "solarSystemID": 30000595}
288	3018868	{"_key": 3018868, "typeID": 25833, "dungeonID": 1109, "spawnPointID": 4966, "solarSystemID": 30004799}
289	3018869	{"_key": 3018869, "typeID": 25846, "dungeonID": 1055, "spawnPointID": 4993, "solarSystemID": 30004421}
290	3018870	{"_key": 3018870, "typeID": 26176, "dungeonID": 1063, "spawnPointID": 4543, "solarSystemID": 30002548}
291	3018871	{"_key": 3018871, "typeID": 26177, "dungeonID": 1063, "spawnPointID": 4543, "solarSystemID": 30002548}
292	3018872	{"_key": 3018872, "typeID": 26178, "dungeonID": 1063, "spawnPointID": 4543, "solarSystemID": 30002548}
293	3018873	{"_key": 3018873, "typeID": 26179, "dungeonID": 1063, "spawnPointID": 4543, "solarSystemID": 30002548}
294	3018874	{"_key": 3018874, "typeID": 26180, "dungeonID": 1063, "spawnPointID": 4543, "solarSystemID": 30002548}
295	3018875	{"_key": 3018875, "typeID": 26181, "dungeonID": 1063, "spawnPointID": 4543, "solarSystemID": 30002548}
296	3018876	{"_key": 3018876, "typeID": 26182, "dungeonID": 1063, "spawnPointID": 4543, "solarSystemID": 30002548}
297	3018877	{"_key": 3018877, "typeID": 26183, "dungeonID": 1063, "spawnPointID": 4543, "solarSystemID": 30002548}
298	3018878	{"_key": 3018878, "typeID": 26184, "dungeonID": 1063, "spawnPointID": 4543, "solarSystemID": 30002548}
299	3018879	{"_key": 3018879, "typeID": 26185, "dungeonID": 1069, "spawnPointID": 4549, "solarSystemID": 30003056}
300	3018880	{"_key": 3018880, "typeID": 26186, "dungeonID": 1069, "spawnPointID": 4549, "solarSystemID": 30003056}
301	3018881	{"_key": 3018881, "typeID": 26187, "dungeonID": 1069, "spawnPointID": 4549, "solarSystemID": 30003056}
302	3018882	{"_key": 3018882, "typeID": 26188, "dungeonID": 1069, "spawnPointID": 4549, "solarSystemID": 30003056}
303	3018883	{"_key": 3018883, "typeID": 26189, "dungeonID": 1069, "spawnPointID": 4549, "solarSystemID": 30003056}
304	3018884	{"_key": 3018884, "typeID": 26190, "dungeonID": 1069, "spawnPointID": 4549, "solarSystemID": 30003056}
305	3018885	{"_key": 3018885, "typeID": 26191, "dungeonID": 1069, "spawnPointID": 4549, "solarSystemID": 30003056}
306	3018886	{"_key": 3018886, "typeID": 26192, "dungeonID": 1069, "spawnPointID": 4549, "solarSystemID": 30003056}
307	3018887	{"_key": 3018887, "typeID": 26193, "dungeonID": 1069, "spawnPointID": 4549, "solarSystemID": 30003056}
308	3018888	{"_key": 3018888, "typeID": 26194, "dungeonID": 1066, "spawnPointID": 4546, "solarSystemID": 30003501}
309	3018889	{"_key": 3018889, "typeID": 26195, "dungeonID": 1066, "spawnPointID": 4546, "solarSystemID": 30003501}
310	3018890	{"_key": 3018890, "typeID": 26196, "dungeonID": 1066, "spawnPointID": 4546, "solarSystemID": 30003501}
311	3018891	{"_key": 3018891, "typeID": 26197, "dungeonID": 1066, "spawnPointID": 4546, "solarSystemID": 30003501}
312	3018892	{"_key": 3018892, "typeID": 26198, "dungeonID": 1066, "spawnPointID": 4546, "solarSystemID": 30003501}
313	3018893	{"_key": 3018893, "typeID": 26199, "dungeonID": 1066, "spawnPointID": 4546, "solarSystemID": 30003501}
314	3018894	{"_key": 3018894, "typeID": 26200, "dungeonID": 1066, "spawnPointID": 4546, "solarSystemID": 30003501}
315	3018895	{"_key": 3018895, "typeID": 26201, "dungeonID": 1066, "spawnPointID": 4546, "solarSystemID": 30003501}
316	3018896	{"_key": 3018896, "typeID": 26202, "dungeonID": 1066, "spawnPointID": 4546, "solarSystemID": 30003501}
317	3018897	{"_key": 3018897, "typeID": 26203, "dungeonID": 1058, "spawnPointID": 4538, "solarSystemID": 30001406}
318	3018898	{"_key": 3018898, "typeID": 26204, "dungeonID": 1058, "spawnPointID": 4538, "solarSystemID": 30001406}
319	3018899	{"_key": 3018899, "typeID": 26205, "dungeonID": 1058, "spawnPointID": 4538, "solarSystemID": 30001406}
320	3018900	{"_key": 3018900, "typeID": 26206, "dungeonID": 1058, "spawnPointID": 4538, "solarSystemID": 30001406}
321	3018901	{"_key": 3018901, "typeID": 26207, "dungeonID": 1058, "spawnPointID": 4538, "solarSystemID": 30001406}
322	3018902	{"_key": 3018902, "typeID": 26208, "dungeonID": 1058, "spawnPointID": 4538, "solarSystemID": 30001406}
323	3018903	{"_key": 3018903, "typeID": 26209, "dungeonID": 1058, "spawnPointID": 4538, "solarSystemID": 30001406}
324	3018904	{"_key": 3018904, "typeID": 26210, "dungeonID": 1058, "spawnPointID": 4538, "solarSystemID": 30001406}
325	3018905	{"_key": 3018905, "typeID": 26211, "dungeonID": 1058, "spawnPointID": 4538, "solarSystemID": 30001406}
326	3018906	{"_key": 3018906, "typeID": 26213, "dungeonID": 1067, "spawnPointID": 4547, "solarSystemID": 30001709}
327	3018907	{"_key": 3018907, "typeID": 26214, "dungeonID": 1067, "spawnPointID": 4547, "solarSystemID": 30001709}
328	3018908	{"_key": 3018908, "typeID": 26215, "dungeonID": 1067, "spawnPointID": 4547, "solarSystemID": 30001709}
329	3018909	{"_key": 3018909, "typeID": 26217, "dungeonID": 1067, "spawnPointID": 4547, "solarSystemID": 30001709}
330	3018910	{"_key": 3018910, "typeID": 26218, "dungeonID": 1067, "spawnPointID": 4547, "solarSystemID": 30001709}
331	3018911	{"_key": 3018911, "typeID": 26219, "dungeonID": 1067, "spawnPointID": 4547, "solarSystemID": 30001709}
332	3018912	{"_key": 3018912, "typeID": 26220, "dungeonID": 1067, "spawnPointID": 4547, "solarSystemID": 30001709}
333	3018913	{"_key": 3018913, "typeID": 26221, "dungeonID": 1067, "spawnPointID": 4547, "solarSystemID": 30001709}
334	3018914	{"_key": 3018914, "typeID": 26222, "dungeonID": 1067, "spawnPointID": 4547, "solarSystemID": 30001709}
335	3018915	{"_key": 3018915, "typeID": 26262, "dungeonID": 1276, "spawnPointID": 4996, "solarSystemID": 30004112}
336	3019365	{"_key": 3019365, "typeID": 30830, "dungeonID": 3734, "spawnPointID": 5035, "solarSystemID": 30005217}
337	3019366	{"_key": 3019366, "typeID": 30838, "dungeonID": 3738, "spawnPointID": 5036, "solarSystemID": 30005215}
338	3019367	{"_key": 3019367, "typeID": 30841, "dungeonID": 3742, "spawnPointID": 5037, "solarSystemID": 30005201}
339	3019368	{"_key": 3019368, "typeID": 30821, "dungeonID": 3733, "spawnPointID": 5034, "solarSystemID": 30005218}
340	3019369	{"_key": 3019369, "typeID": 30887, "dungeonID": 3750, "spawnPointID": 5038, "solarSystemID": 30005199}
341	3019396	{"_key": 3019396, "typeID": 30957, "dungeonID": 3827, "spawnPointID": 5039, "solarSystemID": 30000156}
342	3019400	{"_key": 3019400, "typeID": 30992, "dungeonID": 3876, "spawnPointID": 5075, "solarSystemID": 30045323}
343	3019402	{"_key": 3019402, "typeID": 32195, "dungeonID": 3947, "spawnPointID": 5073, "solarSystemID": 30003878}
344	3019408	{"_key": 3019408, "typeID": 32196, "dungeonID": 3949, "spawnPointID": 5072, "solarSystemID": 30005068}
345	3019409	{"_key": 3019409, "typeID": 31103, "dungeonID": 3889, "spawnPointID": 5042, "solarSystemID": 30003052}
346	3019411	{"_key": 3019411, "typeID": 32098, "dungeonID": 3919, "spawnPointID": 5048, "solarSystemID": 30002526}
347	3019412	{"_key": 3019412, "typeID": 32138, "dungeonID": 3933, "spawnPointID": 5043, "solarSystemID": 30002659}
348	3019414	{"_key": 3019414, "typeID": 32139, "dungeonID": 3932, "spawnPointID": 5074, "solarSystemID": 30005018}
349	3019415	{"_key": 3019415, "typeID": 32140, "dungeonID": 3934, "spawnPointID": 5044, "solarSystemID": 30005038}
350	3019441	{"_key": 3019441, "typeID": 32304, "dungeonID": 4019, "spawnPointID": 5078, "solarSystemID": 30005051}
351	3019442	{"_key": 3019442, "typeID": 32244, "dungeonID": 3974, "spawnPointID": 5076, "solarSystemID": 30003416}
352	3019443	{"_key": 3019443, "typeID": 32278, "dungeonID": 3988, "spawnPointID": 5077, "solarSystemID": 30000001}
353	3019462	{"_key": 3019462, "typeID": 32395, "dungeonID": 4131, "spawnPointID": 5083, "solarSystemID": 30000205}
354	3019463	{"_key": 3019463, "typeID": 32396, "dungeonID": 4132, "spawnPointID": 5082, "solarSystemID": 30003830}
355	3019464	{"_key": 3019464, "typeID": 32397, "dungeonID": 4133, "spawnPointID": 5081, "solarSystemID": 30001447}
356	3019465	{"_key": 3019465, "typeID": 32409, "dungeonID": 4143, "spawnPointID": 5084, "solarSystemID": 30002420}
357	3019466	{"_key": 3019466, "typeID": 32410, "dungeonID": 4141, "spawnPointID": 5086, "solarSystemID": 30000015}
358	3019467	{"_key": 3019467, "typeID": 32411, "dungeonID": 4142, "spawnPointID": 5085, "solarSystemID": 30003471}
359	3019501	{"_key": 3019501, "typeID": 2840, "dungeonID": 5294, "spawnPointID": 5899, "solarSystemID": 30000427}
360	3020059	{"_key": 3020059, "typeID": 84295, "dungeonID": 12001, "spawnPointID": 7536, "solarSystemID": 30000380}
361	3020060	{"_key": 3020060, "typeID": 84296, "dungeonID": 12001, "spawnPointID": 7536, "solarSystemID": 30000380}
362	3020061	{"_key": 3020061, "typeID": 84476, "dungeonID": 12001, "spawnPointID": 7536, "solarSystemID": 30000380}
\.


--
-- Name: agentsinspace agentsinspace_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.agentsinspace
    ADD CONSTRAINT agentsinspace_pkey PRIMARY KEY (row_no);


--
-- Name: agentsinspace_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX agentsinspace_key_idx ON sde_native.agentsinspace USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict vNZaxe6699wGbVe2qiZkSbp2nOEivCEnhuWaRK2cHPkcefHHK08LD76A7IsMsPZ

