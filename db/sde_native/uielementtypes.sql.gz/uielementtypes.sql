--
-- PostgreSQL database dump
--

\restrict AVRkKDt5PdvgX1ZN9elAduhVG47KEUYC8kWd0eAbaidjcL4nrE14cPfxiFKGZYe

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: uielementtypes; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.uielementtypes (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: uielementtypes; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.uielementtypes (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "name": "Overview", "description": "In-space Overview panel", "uiElementID": "unique_UI_overviewWnd"}
1	2	{"_key": 2, "name": "Neocom", "description": "Full NEOCOM menu", "uiElementID": "unique_UI_Neocom"}
2	3	{"_key": 3, "name": "Station Services", "description": "In-station Station Services panel", "uiElementID": "unique_UI_lobbyWnd"}
3	4	{"_key": 4, "name": "Selected Item", "description": "Selected Item window", "uiElementID": "unique_UI_selectedItemView"}
4	5	{"_key": 5, "name": "Chat", "description": "Chat window", "uiElementID": "unique_UI_chatStack"}
5	6	{"_key": 6, "name": "HUD Center", "description": "HP/capacitor display in center of Ship HUD", "uiElementID": "unique_UI_hudCenter"}
6	7	{"_key": 7, "name": "HUD Buttons", "description": "Action buttons panel on left side of Ship UI", "uiElementID": "unique_UI_hudButtons"}
7	8	{"_key": 8, "name": "HUD Slots", "description": "Module slots panel in right side of Ship HUD", "uiElementID": "unique_UI_slotsContainer"}
8	9	{"_key": 9, "name": "Notification Container", "description": "Notifications panel on the bottom-right corner of the screen", "uiElementID": "unique_UI_notificationContainer"}
9	10	{"_key": 10, "name": "Notification Popup", "description": "Popups from received notifications", "uiElementID": "unique_UI_notificationPopup"}
10	11	{"_key": 11, "name": "Notification Badges", "description": "Badges from received notifications", "uiElementID": "unique_UI_badgeMaster"}
11	12	{"_key": 12, "name": "Info Panel Location", "description": "Info Panel displaying current location", "uiElementID": "unique_UI_locationInfoPanel"}
12	13	{"_key": 13, "name": "Info Panel Buttons", "description": "Button controls to show/hide the available Info Panels", "uiElementID": "unique_UI_infoPanelBtns"}
13	14	{"_key": 14, "name": "Info Panel Route", "description": "Info Panel displaying active route", "uiElementID": "unique_UI_routeInInfoPanel"}
14	15	{"_key": 15, "name": "Info Panel Search", "description": "Info Panel that lets players search for content, etc. by string input", "uiElementID": "unique_UI_searchInfoPanel"}
15	16	{"_key": 16, "name": "Info Panel Operations", "description": "Info Panel displaying quest data from the Operations system", "uiElementID": "unique_UI_operationsInfoPanel"}
16	17	{"_key": 17, "name": "Info Panel Daily Challenge", "description": "Info Panel displaying daily challenge data", "uiElementID": "unique_UI_dailyChallengeInfoPanel"}
17	19	{"_key": 19, "name": "Info Panel Recommendations", "description": "Info Panel displaying quest data from the Recommendations system", "uiElementID": "unique_UI_recommendationsInfoPanel"}
18	20	{"_key": 20, "name": "System Wide Effects", "description": "Section of the buff/debuff bar where system-wide effects are displayed", "uiElementID": "unique_UI_systemEffects"}
19	22	{"_key": 22, "name": "Aura", "description": "Conversations dialog window (TaskConversationWindow)", "uiElementID": "ConversationWindow"}
20	24	{"_key": 24, "name": "Crimewatch Timers", "description": "Disable/Enable the Non-Capsuleer Log-Off Timer", "uiElementID": "unique_UI_crimewatchTimers"}
21	25	{"_key": 25, "name": "HUD Readout", "description": "Ship HUD health stats readout display", "uiElementID": "unique_UI_hudReadout"}
22	26	{"_key": 26, "name": "Info Panel Seasons", "description": "Info panel displaying seasons challenges", "uiElementID": "unique_UI_seasonsInfoPanel"}
23	27	{"_key": 27, "name": "Info Panel AIR NPE", "description": "Info Panel displaying objective data from the AIR NPE", "uiElementID": "unique_UI_airNpeInfoPanel"}
24	28	{"_key": 28, "name": "Info Panels", "description": "Container of all the Info Panels", "uiElementID": "unique_UI_infoPanelContainer"}
25	29	{"_key": 29, "name": "HUD Mining Scan Buttons", "description": "Mining scan button that appears for mining ships in ship HUD", "uiElementID": "unique_UI_miningScanBtn"}
26	31	{"_key": 31, "name": "Buff Bar", "description": "The buff bar that appears above the ship hud", "uiElementID": "unique_UI_buffBarContainer"}
\.


--
-- Name: uielementtypes uielementtypes_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.uielementtypes
    ADD CONSTRAINT uielementtypes_pkey PRIMARY KEY (row_no);


--
-- Name: uielementtypes_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX uielementtypes_key_idx ON sde_native.uielementtypes USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict AVRkKDt5PdvgX1ZN9elAduhVG47KEUYC8kWd0eAbaidjcL4nrE14cPfxiFKGZYe

