--
-- PostgreSQL database dump
--

\restrict aYzpB97Fn6SpuKagq8KZKClHxfGIn8puNzjab5cy99hLIxuzeAtn8gaciubd1Id

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: challengeconditions; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.challengeconditions (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: challengeconditions; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.challengeconditions (row_no, key, data) FROM stdin;
0	attackerShipGroupID	{"_key": "attackerShipGroupID", "value": 25}
1	attackerShipTypeID	{"_key": "attackerShipTypeID", "value": 24}
2	categoryID	{"_key": "categoryID", "value": 6}
3	chargeTypeID	{"_key": "chargeTypeID", "value": 29}
4	defenderCategoryID	{"_key": "defenderCategoryID", "value": 30}
5	defenderShipGroupID	{"_key": "defenderShipGroupID", "value": 26}
6	difficultyTier	{"_key": "difficultyTier", "value": 9}
7	dungeonID	{"_key": "dungeonID", "value": 3}
8	factionID	{"_key": "factionID", "value": 2}
9	groupID	{"_key": "groupID", "value": 4}
10	isPiloted	{"_key": "isPiloted", "value": 31}
11	locationOfOriginGroupID	{"_key": "locationOfOriginGroupID", "value": 8}
12	moduleGroupID	{"_key": "moduleGroupID", "value": 28}
13	moduleTypeID	{"_key": "moduleTypeID", "value": 27}
14	mutatorTypeID	{"_key": "mutatorTypeID", "value": 14}
15	npcGroupID	{"_key": "npcGroupID", "value": 1}
16	npcTypeID	{"_key": "npcTypeID", "value": 13}
17	pocketID	{"_key": "pocketID", "value": 11}
18	rewardID	{"_key": "rewardID", "value": 33}
19	rewardLevel	{"_key": "rewardLevel", "value": 32}
20	roomID	{"_key": "roomID", "value": 20}
21	shipGroupID	{"_key": "shipGroupID", "value": 5}
22	shipTypeID	{"_key": "shipTypeID", "value": 21}
23	sourceTypeGroupID	{"_key": "sourceTypeGroupID", "value": 16}
24	sourceTypeID	{"_key": "sourceTypeID", "value": 15}
25	sourceTypeMetaLevel	{"_key": "sourceTypeMetaLevel", "value": 17}
26	spawnTableID	{"_key": "spawnTableID", "value": 12}
27	targetGroupID	{"_key": "targetGroupID", "value": 19}
28	targetTypeID	{"_key": "targetTypeID", "value": 18}
29	typeID	{"_key": "typeID", "value": 7}
30	weaponGroupID	{"_key": "weaponGroupID", "value": 23}
31	weaponTypeID	{"_key": "weaponTypeID", "value": 22}
32	weatherTypeID	{"_key": "weatherTypeID", "value": 10}
\.


--
-- Name: challengeconditions challengeconditions_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.challengeconditions
    ADD CONSTRAINT challengeconditions_pkey PRIMARY KEY (row_no);


--
-- Name: challengeconditions_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX challengeconditions_key_idx ON sde_native.challengeconditions USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict aYzpB97Fn6SpuKagq8KZKClHxfGIn8puNzjab5cy99hLIxuzeAtn8gaciubd1Id

