--
-- PostgreSQL database dump
--

\restrict rRADathMDoXuSyE1FNYvn65MKeR0mkl4EeAwMmmlyrxnYPA5Z9roaA8yXCl3COk

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: unrepairableitemsconfig; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.unrepairableitemsconfig (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: unrepairableitemsconfig; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.unrepairableitemsconfig (row_no, key, data) FROM stdin;
0	\N	{"unrepairableTypes": [], "unrepairableGroups": [513, 902, 485, 547, 659, 1538, 30, 883, 4594, 5120], "unrepairableCategories": [87]}
\.


--
-- Name: unrepairableitemsconfig unrepairableitemsconfig_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.unrepairableitemsconfig
    ADD CONSTRAINT unrepairableitemsconfig_pkey PRIMARY KEY (row_no);


--
-- Name: unrepairableitemsconfig_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX unrepairableitemsconfig_key_idx ON sde_native.unrepairableitemsconfig USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict rRADathMDoXuSyE1FNYvn65MKeR0mkl4EeAwMmmlyrxnYPA5Z9roaA8yXCl3COk

