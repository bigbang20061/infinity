--
-- PostgreSQL database dump
--

\restrict N8TLsWCUEQKFcWlFgvdJxcsdvqyjLZuxxtWWwsPDR2cbVOgfGBkIYyAe1K8lmGx

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: corporationrolegroups; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.corporationrolegroups (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: corporationrolegroups; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.corporationrolegroups (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "roleMask": 6895013280067096961, "appliesTo": "roles", "isDivisional": 0, "isLocational": 0, "roleGroupName": "General", "roleGroupNameID": 60117, "appliesToGrantable": "grantableRoles"}
1	2	{"_key": 2, "roleMask": 21955048183434752, "appliesTo": "roles", "isDivisional": 0, "isLocational": 0, "roleGroupName": "Station Service", "roleGroupNameID": 60118, "appliesToGrantable": "grantableRoles"}
2	3	{"_key": 3, "roleMask": 2147349430272, "appliesTo": "roles", "isDivisional": 1, "isLocational": 0, "roleGroupName": "Accounting (Divisional)", "roleGroupNameID": 60119, "appliesToGrantable": "grantableRoles"}
3	4	{"_key": 4, "roleMask": 134209542, "appliesTo": "rolesAtHQ", "isDivisional": 1, "isLocational": 1, "roleGroupName": "Hangar Access (Headquarters)", "roleGroupNameID": 60120, "appliesToGrantable": "grantableRolesAtHQ"}
4	5	{"_key": 5, "roleMask": 558551906910216, "appliesTo": "rolesAtHQ", "isDivisional": 1, "isLocational": 1, "roleGroupName": "Container Access (Headquarters)", "roleGroupNameID": 60121, "appliesToGrantable": "grantableRolesAtHQ"}
5	6	{"_key": 6, "roleMask": 134209542, "appliesTo": "rolesAtBase", "isDivisional": 1, "isLocational": 1, "roleGroupName": "Hangar Access (Based at)", "roleGroupNameID": 60122, "appliesToGrantable": "grantableRolesAtBase"}
6	7	{"_key": 7, "roleMask": 558551906910216, "appliesTo": "rolesAtBase", "isDivisional": 1, "isLocational": 1, "roleGroupName": "Container Access (Based at)", "roleGroupNameID": 60123, "appliesToGrantable": "grantableRolesAtBase"}
7	8	{"_key": 8, "roleMask": 134209542, "appliesTo": "rolesAtOther", "isDivisional": 1, "isLocational": 1, "roleGroupName": "Hangar Access (Other)", "roleGroupNameID": 60124, "appliesToGrantable": "grantableRolesAtOther"}
8	9	{"_key": 9, "roleMask": 558551906910216, "appliesTo": "rolesAtOther", "isDivisional": 1, "isLocational": 1, "roleGroupName": "Container Access (Other)", "roleGroupNameID": 60125, "appliesToGrantable": "grantableRolesAtOther"}
\.


--
-- Name: corporationrolegroups corporationrolegroups_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.corporationrolegroups
    ADD CONSTRAINT corporationrolegroups_pkey PRIMARY KEY (row_no);


--
-- Name: corporationrolegroups_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX corporationrolegroups_key_idx ON sde_native.corporationrolegroups USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict N8TLsWCUEQKFcWlFgvdJxcsdvqyjLZuxxtWWwsPDR2cbVOgfGBkIYyAe1K8lmGx

