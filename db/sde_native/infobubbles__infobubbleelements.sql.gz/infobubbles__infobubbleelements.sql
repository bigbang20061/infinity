--
-- PostgreSQL database dump
--

\restrict 6g1UME46QrfSnSC3iTjJUAoctcpgqu7vIUf8qapn2zS4U8Yu4I6h89mOkFQbFKC

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: infobubbles__infobubbleelements; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.infobubbles__infobubbleelements (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: infobubbles__infobubbleelements; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.infobubbles__infobubbleelements (row_no, key, data) FROM stdin;
0	7	{"_key": 7, "icon": "armor", "nameID": 500538, "descriptionID": 500537}
1	8	{"_key": 8, "icon": "energy_turrets", "nameID": 500541, "descriptionID": 500540}
2	9	{"_key": 9, "icon": "missiles", "nameID": 500543, "descriptionID": 500542}
3	10	{"_key": 10, "icon": "gunnery", "nameID": 500545, "descriptionID": 500544}
4	11	{"_key": 11, "icon": "drones", "nameID": 500547, "descriptionID": 500546}
5	12	{"_key": 12, "icon": "hybrid_turrets", "nameID": 500549, "descriptionID": 500548}
6	13	{"_key": 13, "icon": "capacitor_warfare", "nameID": 500551, "descriptionID": 500550}
7	14	{"_key": 14, "icon": "sensor_dampening", "nameID": 500553, "descriptionID": 500552}
8	15	{"_key": 15, "icon": "ecm", "nameID": 500555, "descriptionID": 500554}
9	16	{"_key": 16, "icon": "target_painting", "nameID": 500557, "descriptionID": 500556}
10	17	{"_key": 17, "icon": "tracking_disruption", "nameID": 500559, "descriptionID": 500558}
11	18	{"_key": 18, "icon": "stasis_webifying", "nameID": 500561, "descriptionID": 500560}
12	19	{"_key": 19, "icon": "warp_prevention", "nameID": 500563, "descriptionID": 500562}
13	20	{"_key": 20, "icon": "shields", "nameID": 500565, "descriptionID": 500564}
14	22	{"_key": 22, "icon": "attack", "nameID": 500567, "descriptionID": 500566}
15	23	{"_key": 23, "icon": "combat", "nameID": 500569, "descriptionID": 500568}
16	24	{"_key": 24, "icon": "disruption", "nameID": 500571, "descriptionID": 500570}
17	25	{"_key": 25, "icon": "fleet_support", "nameID": 500573, "descriptionID": 500572}
18	26	{"_key": 26, "icon": "hauling", "nameID": 500575, "descriptionID": 500574}
19	27	{"_key": 27, "icon": "resource_harvesting", "nameID": 500577, "descriptionID": 500576}
20	28	{"_key": 28, "icon": "explorer", "nameID": 500580, "descriptionID": 500579}
21	29	{"_key": 29, "icon": "tackling", "nameID": 500582, "descriptionID": 500581}
22	30	{"_key": 30, "icon": "small", "nameID": 500584, "descriptionID": 500583}
23	31	{"_key": 31, "icon": "medium", "nameID": 500586, "descriptionID": 500585}
24	32	{"_key": 32, "icon": "large", "nameID": 500588, "descriptionID": 500587}
25	33	{"_key": 33, "icon": "extra_large", "nameID": 500590, "descriptionID": 500589}
26	45	{"_key": 45, "icon": "precursor", "nameID": 536317, "descriptionID": 536318}
27	2046	{"_key": 2046, "icon": "shields_armor", "nameID": 551447, "descriptionID": 551448}
28	2048	{"_key": 2048, "icon": "vorton_projector", "nameID": 564589, "descriptionID": 564590}
29	2055	{"_key": 2055, "icon": "res:/UI/Texture/classes/shipTree/attributes/smartBomb.png", "nameID": 708863, "descriptionID": 708864}
30	2056	{"_key": 2056, "icon": "damage_over_time", "nameID": 728342, "descriptionID": 728343}
\.


--
-- Name: infobubbles__infobubbleelements infobubbles__infobubbleelements_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.infobubbles__infobubbleelements
    ADD CONSTRAINT infobubbles__infobubbleelements_pkey PRIMARY KEY (row_no);


--
-- Name: infobubbles__infobubbleelements_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX infobubbles__infobubbleelements_key_idx ON sde_native.infobubbles__infobubbleelements USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 6g1UME46QrfSnSC3iTjJUAoctcpgqu7vIUf8qapn2zS4U8Yu4I6h89mOkFQbFKC

