--
-- PostgreSQL database dump
--

\restrict BcW5COmi3isro7V7uifDj05HxCPyJnsOwfjfpE44TkwV1tEpG99IpIw5V3TNIbX

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: npccorporationdivisions; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.npccorporationdivisions (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: npccorporationdivisions; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.npccorporationdivisions (row_no, key, data) FROM stdin;
0	18	{"_key": 18, "nameID": 60109, "description": "Research and development division", "internalName": "R&D", "leaderTypeNameID": 60085}
1	22	{"_key": 22, "nameID": 60113, "description": "New distribution division", "internalName": "Distribution", "leaderTypeNameID": 60089}
2	23	{"_key": 23, "nameID": 60114, "description": "New mining division", "internalName": "Mining", "leaderTypeNameID": 60090}
3	24	{"_key": 24, "nameID": 60115, "description": "New security division", "internalName": "Security", "leaderTypeNameID": 60091}
4	25	{"_key": 25, "nameID": 62733, "description": "Business career", "internalName": "Industrialist - Entrepreneur", "descriptionID": 62734, "leaderTypeNameID": 60070}
5	26	{"_key": 26, "nameID": 62737, "description": "Exploration career", "internalName": "Explorer", "descriptionID": 62738, "leaderTypeNameID": 60070}
6	27	{"_key": 27, "nameID": 62731, "description": "Industry career", "internalName": "Industrialist - Producer", "descriptionID": 62732, "leaderTypeNameID": 60070}
7	28	{"_key": 28, "nameID": 62735, "description": "Military career", "internalName": "Enforcer", "descriptionID": 62736, "leaderTypeNameID": 60070}
8	29	{"_key": 29, "nameID": 62739, "description": "Advanced Military career", "internalName": "Soldier of Fortune", "descriptionID": 62740, "leaderTypeNameID": 60070}
9	37	{"_key": 37, "nameID": 631045, "internalName": "Heraldry", "leaderTypeNameID": 631044}
\.


--
-- Name: npccorporationdivisions npccorporationdivisions_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.npccorporationdivisions
    ADD CONSTRAINT npccorporationdivisions_pkey PRIMARY KEY (row_no);


--
-- Name: npccorporationdivisions_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX npccorporationdivisions_key_idx ON sde_native.npccorporationdivisions USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict BcW5COmi3isro7V7uifDj05HxCPyJnsOwfjfpE44TkwV1tEpG99IpIw5V3TNIbX

