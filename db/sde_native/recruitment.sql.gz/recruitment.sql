--
-- PostgreSQL database dump
--

\restrict VIZQ2cPNcmnYL5FnHvhjaVzLrxT3Z7EnhcadUt1oSGho9JZx6V1Aq3VchIUTIKm

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: recruitment; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.recruitment (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: recruitment; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.recruitment (row_no, key, data) FROM stdin;
0	\N	{"tasks": [{"info": [{"bonusID": 75894, "bonusType": "TYPEID", "bonusCount": 1, "bonusLevel": 2, "description": 640508}, {"bonusID": 2975, "bonusType": "OMEGA", "bonusCount": 1, "bonusLevel": 5, "description": 640509}, {"bonusID": 75893, "bonusType": "TYPEID", "bonusCount": 1, "bonusLevel": 1, "description": 640510}, {"bonusID": 75895, "bonusType": "TYPEID", "bonusCount": 1, "bonusLevel": 10, "description": 644401}, {"bonusID": 2976, "bonusType": "PLEX", "bonusCount": 1, "bonusLevel": 20, "description": 644402}], "maxLevel": 20, "task_type": 1, "task_category": "TASK_CATEGORY_RECRUITER"}, {"info": [{"bonusID": 2971, "bonusType": "OMEGA", "bonusCount": 1, "bonusLevel": 1, "description": 641446}], "maxLevel": 1, "task_type": 2, "task_category": "TASK_CATEGORY_RECRUITER"}, {"info": [{"bonusID": 63624, "bonusType": "TYPEID", "bonusCount": 1, "bonusLevel": 3, "description": 642483}], "maxLevel": 3, "task_type": 3, "task_category": "TASK_CATEGORY_RECRUITED_TARGET"}, {"info": [{"bonusID": 63624, "bonusType": "TYPEID", "bonusCount": 1, "bonusLevel": 10, "description": 642483}], "maxLevel": 10, "task_type": 4, "task_category": "TASK_CATEGORY_RECRUITED_TARGET"}, {"info": [{"bonusID": 63624, "bonusType": "TYPEID", "bonusCount": 1, "bonusLevel": 1, "description": 642483}], "maxLevel": 1, "task_type": 5, "task_category": "TASK_CATEGORY_RECRUITED_TARGET"}, {"info": [{"bonusID": 63624, "bonusType": "TYPEID", "bonusCount": 1, "bonusLevel": 30, "description": 642486}], "maxLevel": 30, "task_type": 6, "task_category": "TASK_CATEGORY_RECRUITED_TARGET"}, {"info": [{"bonusID": 63624, "bonusType": "TYPEID", "bonusCount": 1, "bonusLevel": 1, "description": 643680}], "maxLevel": 1, "task_type": 7, "task_category": "TASK_CATEGORY_RECRUITED_TARGET"}]}
\.


--
-- Name: recruitment recruitment_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.recruitment
    ADD CONSTRAINT recruitment_pkey PRIMARY KEY (row_no);


--
-- Name: recruitment_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX recruitment_key_idx ON sde_native.recruitment USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict VIZQ2cPNcmnYL5FnHvhjaVzLrxT3Z7EnhcadUt1oSGho9JZx6V1Aq3VchIUTIKm

