--
-- PostgreSQL database dump
--

\restrict d2Tnh6YnxOb3CQOdUK5ooHsZMnaY1b0f4pn9xZDL2UXbYBNgdqanSjI1CADM0oW

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: fighterabilities; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.fighterabilities (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: fighterabilities; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.fighterabilities (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "iconID": 1386, "targetMode": "itemTargeted", "displayNameID": 513536, "disallowInLowSec": false, "disallowInHighSec": false}
1	2	{"_key": 2, "iconID": 1284, "targetMode": "itemTargeted", "displayNameID": 513537, "tooltipTextID": 516650, "disallowInLowSec": false, "disallowInHighSec": false}
2	3	{"_key": 3, "iconID": 2983, "targetMode": "itemTargeted", "displayNameID": 513538, "disallowInLowSec": false, "disallowInHighSec": false}
3	4	{"_key": 4, "iconID": 10149, "targetMode": "untargeted", "displayNameID": 513542, "tooltipTextID": 516651, "disallowInLowSec": false, "disallowInHighSec": false}
4	5	{"_key": 5, "iconID": 20971, "targetMode": "pointTargeted", "displayNameID": 513540, "tooltipTextID": 516652, "disallowInLowSec": false, "disallowInHighSec": false}
5	6	{"_key": 6, "iconID": 10934, "targetMode": "untargeted", "displayNameID": 513541, "disallowInLowSec": false, "disallowInHighSec": false}
6	7	{"_key": 7, "iconID": 3282, "targetMode": "pointTargeted", "displayNameID": 513544, "tooltipTextID": 516653, "disallowInLowSec": true, "disallowInHighSec": true}
7	9	{"_key": 9, "iconID": 96, "targetMode": "untargeted", "displayNameID": 514051, "tooltipTextID": 516654, "disallowInLowSec": false, "disallowInHighSec": false}
8	10	{"_key": 10, "iconID": 111, "targetMode": "itemTargeted", "displayNameID": 514052, "tooltipTextID": 516655, "disallowInLowSec": false, "disallowInHighSec": false}
9	11	{"_key": 11, "iconID": 1283, "targetMode": "itemTargeted", "displayNameID": 514053, "tooltipTextID": 516656, "disallowInLowSec": false, "disallowInHighSec": false}
10	12	{"_key": 12, "iconID": 109, "targetMode": "itemTargeted", "displayNameID": 514054, "tooltipTextID": 516657, "disallowInLowSec": false, "disallowInHighSec": false}
11	13	{"_key": 13, "iconID": 84, "targetMode": "untargeted", "displayNameID": 514055, "tooltipTextID": 516658, "disallowInLowSec": false, "disallowInHighSec": false}
12	14	{"_key": 14, "iconID": 191, "targetMode": "itemTargeted", "displayNameID": 514056, "disallowInLowSec": false, "disallowInHighSec": false}
13	16	{"_key": 16, "iconID": 3433, "targetMode": "itemTargeted", "displayNameID": 514167, "tooltipTextID": 516659, "disallowInLowSec": false, "disallowInHighSec": false}
14	17	{"_key": 17, "iconID": 1386, "targetMode": "itemTargeted", "displayNameID": 514168, "disallowInLowSec": false, "disallowInHighSec": false}
15	18	{"_key": 18, "iconID": 1349, "targetMode": "itemTargeted", "displayNameID": 514396, "tooltipTextID": 516660, "turretGraphicID": 11515, "disallowInLowSec": false, "disallowInHighSec": false}
16	19	{"_key": 19, "iconID": 1347, "targetMode": "itemTargeted", "displayNameID": 514397, "tooltipTextID": 516661, "turretGraphicID": 11517, "disallowInLowSec": false, "disallowInHighSec": false}
17	20	{"_key": 20, "iconID": 1346, "targetMode": "itemTargeted", "displayNameID": 514398, "tooltipTextID": 516662, "turretGraphicID": 11516, "disallowInLowSec": false, "disallowInHighSec": false}
18	21	{"_key": 21, "iconID": 1348, "targetMode": "itemTargeted", "displayNameID": 514399, "tooltipTextID": 516663, "turretGraphicID": 11518, "disallowInLowSec": false, "disallowInHighSec": false}
19	22	{"_key": 22, "iconID": 1139, "targetMode": "itemTargeted", "displayNameID": 514400, "tooltipTextID": 516666, "turretGraphicID": 21843, "disallowInLowSec": false, "disallowInHighSec": false}
20	23	{"_key": 23, "iconID": 1145, "targetMode": "itemTargeted", "displayNameID": 514401, "tooltipTextID": 516669, "turretGraphicID": 21842, "disallowInLowSec": false, "disallowInHighSec": false}
21	24	{"_key": 24, "iconID": 1047, "targetMode": "itemTargeted", "displayNameID": 514402, "tooltipTextID": 516667, "turretGraphicID": 21846, "disallowInLowSec": false, "disallowInHighSec": false}
22	25	{"_key": 25, "iconID": 1311, "targetMode": "itemTargeted", "displayNameID": 514403, "tooltipTextID": 516664, "turretGraphicID": 21847, "disallowInLowSec": false, "disallowInHighSec": false}
23	26	{"_key": 26, "iconID": 1287, "targetMode": "itemTargeted", "displayNameID": 514404, "tooltipTextID": 516665, "turretGraphicID": 21849, "disallowInLowSec": false, "disallowInHighSec": false}
24	27	{"_key": 27, "iconID": 1288, "targetMode": "itemTargeted", "displayNameID": 514405, "tooltipTextID": 516668, "turretGraphicID": 21848, "disallowInLowSec": false, "disallowInHighSec": false}
25	29	{"_key": 29, "iconID": 1352, "targetMode": "itemTargeted", "displayNameID": 514412, "tooltipTextID": 516670, "turretGraphicID": 11515, "disallowInLowSec": false, "disallowInHighSec": false}
26	30	{"_key": 30, "iconID": 1351, "targetMode": "itemTargeted", "displayNameID": 514413, "tooltipTextID": 516671, "turretGraphicID": 11517, "disallowInLowSec": false, "disallowInHighSec": false}
27	31	{"_key": 31, "iconID": 1350, "targetMode": "itemTargeted", "displayNameID": 514414, "tooltipTextID": 516672, "turretGraphicID": 11516, "disallowInLowSec": false, "disallowInHighSec": false}
28	32	{"_key": 32, "iconID": 1353, "targetMode": "itemTargeted", "displayNameID": 514415, "tooltipTextID": 516673, "turretGraphicID": 11518, "disallowInLowSec": false, "disallowInHighSec": false}
29	33	{"_key": 33, "iconID": 187, "targetMode": "itemTargeted", "displayNameID": 514417, "tooltipTextID": 516674, "turretGraphicID": 11515, "disallowInLowSec": false, "disallowInHighSec": false}
30	34	{"_key": 34, "iconID": 188, "targetMode": "itemTargeted", "displayNameID": 514418, "tooltipTextID": 516675, "turretGraphicID": 11517, "disallowInLowSec": false, "disallowInHighSec": false}
31	35	{"_key": 35, "iconID": 189, "targetMode": "itemTargeted", "displayNameID": 514419, "tooltipTextID": 516676, "turretGraphicID": 11516, "disallowInLowSec": false, "disallowInHighSec": false}
32	36	{"_key": 36, "iconID": 186, "targetMode": "itemTargeted", "displayNameID": 514420, "tooltipTextID": 516677, "turretGraphicID": 11518, "disallowInLowSec": false, "disallowInHighSec": false}
33	38	{"_key": 38, "iconID": 1386, "targetMode": "itemTargeted", "displayNameID": 515664, "tooltipTextID": 516678, "disallowInLowSec": false, "disallowInHighSec": false}
34	44	{"_key": 44, "iconID": 1047, "targetMode": "itemTargeted", "displayNameID": 529305, "tooltipTextID": 529306, "turretGraphicID": 21844, "disallowInLowSec": false, "disallowInHighSec": false}
35	45	{"_key": 45, "iconID": 1311, "targetMode": "itemTargeted", "displayNameID": 529307, "tooltipTextID": 529308, "turretGraphicID": 21845, "disallowInLowSec": false, "disallowInHighSec": false}
\.


--
-- Name: fighterabilities fighterabilities_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.fighterabilities
    ADD CONSTRAINT fighterabilities_pkey PRIMARY KEY (row_no);


--
-- Name: fighterabilities_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX fighterabilities_key_idx ON sde_native.fighterabilities USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict d2Tnh6YnxOb3CQOdUK5ooHsZMnaY1b0f4pn9xZDL2UXbYBNgdqanSjI1CADM0oW

