--
-- PostgreSQL database dump
--

\restrict Z4UMZFRM1niZP3W2XtM8j1qVRf6Ku3vzxAsl5DQLeBbczVHlv8H9dHfzkpG2GUm

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: podguidegroups; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.podguidegroups (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: podguidegroups; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.podguidegroups (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "groupID": 1, "groupName": 502815, "groupType": "group", "belongsToGroup": 11}
1	2	{"_key": 2, "groupID": 2, "groupName": 502816, "groupType": "group", "belongsToGroup": 11}
2	3	{"_key": 3, "groupID": 3, "groupName": 502817, "groupType": "group", "belongsToGroup": 11}
3	4	{"_key": 4, "groupID": 4, "groupName": 502818, "groupType": "group", "belongsToGroup": 12}
4	5	{"_key": 5, "groupID": 5, "groupName": 502819, "groupType": "group", "belongsToGroup": 12}
5	6	{"_key": 6, "groupID": 6, "groupName": 502820, "groupType": "group", "belongsToGroup": 14}
6	7	{"_key": 7, "groupID": 7, "groupName": 502821, "groupType": "group", "belongsToGroup": 14}
7	8	{"_key": 8, "groupID": 8, "groupName": 502822, "groupType": "group", "belongsToGroup": 14}
8	9	{"_key": 9, "groupID": 9, "groupName": 502823, "groupType": "group", "belongsToGroup": 13}
9	10	{"_key": 10, "groupID": 10, "groupName": 502824, "groupType": "group", "belongsToGroup": 13}
10	11	{"_key": 11, "groupID": 11, "groupName": 502825, "groupType": "category", "belongsToGroup": -1}
11	12	{"_key": 12, "groupID": 12, "groupName": 502826, "groupType": "category", "belongsToGroup": -1}
12	13	{"_key": 13, "groupID": 13, "groupName": 502827, "groupType": "category", "belongsToGroup": -1}
13	14	{"_key": 14, "groupID": 14, "groupName": 502828, "groupType": "category", "belongsToGroup": -1}
\.


--
-- Name: podguidegroups podguidegroups_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.podguidegroups
    ADD CONSTRAINT podguidegroups_pkey PRIMARY KEY (row_no);


--
-- Name: podguidegroups_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX podguidegroups_key_idx ON sde_native.podguidegroups USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict Z4UMZFRM1niZP3W2XtM8j1qVRf6Ku3vzxAsl5DQLeBbczVHlv8H9dHfzkpG2GUm

