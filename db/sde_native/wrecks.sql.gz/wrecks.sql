--
-- PostgreSQL database dump
--

\restrict jVIQLt1FXgCfk1PixfDhWhqjdMy7ayYEOGg4IWFUrdHhaKnNFOzpRXGZHGoHkKS

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: wrecks; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.wrecks (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: wrecks; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.wrecks (row_no, key, data) FROM stdin;
0	25	{"_key": 25, "raceIdToWreckTypeId": {"1": 26506, "2": 26550, "4": 26484, "8": 26528, "128": 26528}}
1	26	{"_key": 26, "raceIdToWreckTypeId": {"1": 26495, "2": 26539, "4": 26473, "8": 26517}}
2	27	{"_key": 27, "raceIdToWreckTypeId": {"1": 26492, "2": 26536, "4": 26470, "8": 26514}}
3	28	{"_key": 28, "raceIdToWreckTypeId": {"1": 26507, "2": 26551, "4": 26485, "8": 26529, "128": 26529}}
4	30	{"_key": 30, "raceIdToWreckTypeId": {"1": 26512, "2": 26556, "4": 26490, "8": 26534}}
5	31	{"_key": 31, "raceIdToWreckTypeId": {"1": 26511, "2": 26555, "4": 26489, "8": 26533, "16": 26489}}
6	185	{"_key": 185, "raceIdToWreckTypeId": {"0": 27286}}
7	237	{"_key": 237, "raceIdToWreckTypeId": {"1": 26510, "2": 26554, "4": 26488, "8": 26532}}
8	286	{"_key": 286, "raceIdToWreckTypeId": {"0": 26557}}
9	287	{"_key": 287, "raceIdToWreckTypeId": {"0": 26591}}
10	288	{"_key": 288, "raceIdToWreckTypeId": {"0": 26972}}
11	297	{"_key": 297, "raceIdToWreckTypeId": {"0": 27202}}
12	324	{"_key": 324, "raceIdToWreckTypeId": {"1": 26502, "2": 26546, "4": 26480, "8": 26524}}
13	358	{"_key": 358, "raceIdToWreckTypeId": {"1": 26500, "2": 26544, "4": 26478, "8": 26522}}
14	363	{"_key": 363, "raceIdToWreckTypeId": {"0": 33489, "128": 33490}}
15	380	{"_key": 380, "raceIdToWreckTypeId": {"1": 26503, "2": 26547, "4": 26481, "8": 26525}}
16	381	{"_key": 381, "raceIdToWreckTypeId": {"1": 26499, "2": 26543, "4": 26477, "8": 26521}}
17	419	{"_key": 419, "raceIdToWreckTypeId": {"1": 26491, "2": 26535, "4": 26469, "8": 26513, "16": 26469}}
18	420	{"_key": 420, "raceIdToWreckTypeId": {"1": 26496, "2": 26540, "4": 26474, "8": 26518}}
19	463	{"_key": 463, "raceIdToWreckTypeId": {"1": 26508, "2": 26552, "4": 26486, "8": 26530, "128": 26530}}
20	485	{"_key": 485, "raceIdToWreckTypeId": {"1": 26497, "2": 26541, "4": 26475, "8": 26519}}
21	513	{"_key": 513, "raceIdToWreckTypeId": {"1": 26505, "2": 26549, "4": 26483, "8": 26527, "128": 34884}}
22	520	{"_key": 520, "raceIdToWreckTypeId": {"0": 26557}}
23	522	{"_key": 522, "raceIdToWreckTypeId": {"0": 26558}}
24	523	{"_key": 523, "raceIdToWreckTypeId": {"0": 26559}}
25	527	{"_key": 527, "raceIdToWreckTypeId": {"0": 26557}}
26	533	{"_key": 533, "raceIdToWreckTypeId": {"0": 26558}}
27	534	{"_key": 534, "raceIdToWreckTypeId": {"0": 26559}}
28	540	{"_key": 540, "raceIdToWreckTypeId": {"1": 26498, "2": 26542, "4": 26476, "8": 26520}}
29	541	{"_key": 541, "raceIdToWreckTypeId": {"1": 26501, "2": 26545, "4": 26479, "8": 26523}}
30	543	{"_key": 543, "raceIdToWreckTypeId": {"1": 26504, "2": 26548, "4": 26482, "8": 26526, "128": 26526}}
31	547	{"_key": 547, "raceIdToWreckTypeId": {"1": 26494, "2": 26538, "4": 26472, "8": 26516}}
32	550	{"_key": 550, "raceIdToWreckTypeId": {"0": 26561}}
33	551	{"_key": 551, "raceIdToWreckTypeId": {"0": 26562}}
34	552	{"_key": 552, "raceIdToWreckTypeId": {"0": 26563}}
35	553	{"_key": 553, "raceIdToWreckTypeId": {"0": 26566}}
36	554	{"_key": 554, "raceIdToWreckTypeId": {"0": 26562}}
37	555	{"_key": 555, "raceIdToWreckTypeId": {"0": 26568}}
38	556	{"_key": 556, "raceIdToWreckTypeId": {"0": 26569}}
39	557	{"_key": 557, "raceIdToWreckTypeId": {"0": 26567}}
40	558	{"_key": 558, "raceIdToWreckTypeId": {"0": 26568}}
41	559	{"_key": 559, "raceIdToWreckTypeId": {"0": 26572}}
42	560	{"_key": 560, "raceIdToWreckTypeId": {"0": 26575}}
43	561	{"_key": 561, "raceIdToWreckTypeId": {"0": 26574}}
44	562	{"_key": 562, "raceIdToWreckTypeId": {"0": 26573}}
45	563	{"_key": 563, "raceIdToWreckTypeId": {"0": 26574}}
46	564	{"_key": 564, "raceIdToWreckTypeId": {"0": 26578}}
47	565	{"_key": 565, "raceIdToWreckTypeId": {"0": 26581}}
48	566	{"_key": 566, "raceIdToWreckTypeId": {"0": 26580}}
49	567	{"_key": 567, "raceIdToWreckTypeId": {"0": 26579}}
50	568	{"_key": 568, "raceIdToWreckTypeId": {"0": 26580}}
51	569	{"_key": 569, "raceIdToWreckTypeId": {"0": 26584}}
52	570	{"_key": 570, "raceIdToWreckTypeId": {"0": 26587}}
53	571	{"_key": 571, "raceIdToWreckTypeId": {"0": 26586}}
54	572	{"_key": 572, "raceIdToWreckTypeId": {"0": 26585}}
55	573	{"_key": 573, "raceIdToWreckTypeId": {"0": 26586}}
56	574	{"_key": 574, "raceIdToWreckTypeId": {"0": 26590}}
57	575	{"_key": 575, "raceIdToWreckTypeId": {"0": 26561}}
58	576	{"_key": 576, "raceIdToWreckTypeId": {"0": 26562, "2": 26562}}
59	577	{"_key": 577, "raceIdToWreckTypeId": {"0": 26567}}
60	578	{"_key": 578, "raceIdToWreckTypeId": {"0": 26568}}
61	579	{"_key": 579, "raceIdToWreckTypeId": {"0": 26573}}
62	580	{"_key": 580, "raceIdToWreckTypeId": {"0": 26574}}
63	581	{"_key": 581, "raceIdToWreckTypeId": {"0": 26579}}
64	582	{"_key": 582, "raceIdToWreckTypeId": {"0": 26580}}
65	583	{"_key": 583, "raceIdToWreckTypeId": {"0": 26585}}
66	584	{"_key": 584, "raceIdToWreckTypeId": {"0": 26586}}
67	593	{"_key": 593, "raceIdToWreckTypeId": {"0": 26562}}
68	594	{"_key": 594, "raceIdToWreckTypeId": {"0": 26563}}
69	595	{"_key": 595, "raceIdToWreckTypeId": {"0": 26562}}
70	596	{"_key": 596, "raceIdToWreckTypeId": {"0": 26561}}
71	597	{"_key": 597, "raceIdToWreckTypeId": {"0": 26561}}
72	602	{"_key": 602, "raceIdToWreckTypeId": {"0": 26568}}
73	603	{"_key": 603, "raceIdToWreckTypeId": {"0": 26569}}
74	604	{"_key": 604, "raceIdToWreckTypeId": {"0": 26568}}
75	605	{"_key": 605, "raceIdToWreckTypeId": {"0": 26567}}
76	606	{"_key": 606, "raceIdToWreckTypeId": {"0": 26567}}
77	611	{"_key": 611, "raceIdToWreckTypeId": {"0": 26574}}
78	612	{"_key": 612, "raceIdToWreckTypeId": {"0": 26575}}
79	613	{"_key": 613, "raceIdToWreckTypeId": {"0": 26574}}
80	614	{"_key": 614, "raceIdToWreckTypeId": {"0": 26573}}
81	615	{"_key": 615, "raceIdToWreckTypeId": {"0": 26573}}
82	620	{"_key": 620, "raceIdToWreckTypeId": {"0": 26580}}
83	621	{"_key": 621, "raceIdToWreckTypeId": {"0": 26581}}
84	622	{"_key": 622, "raceIdToWreckTypeId": {"0": 26580}}
85	623	{"_key": 623, "raceIdToWreckTypeId": {"0": 26579}}
86	624	{"_key": 624, "raceIdToWreckTypeId": {"0": 26579}}
87	629	{"_key": 629, "raceIdToWreckTypeId": {"0": 26586}}
88	630	{"_key": 630, "raceIdToWreckTypeId": {"0": 26587}}
89	631	{"_key": 631, "raceIdToWreckTypeId": {"0": 26586}}
90	632	{"_key": 632, "raceIdToWreckTypeId": {"0": 26585}}
91	633	{"_key": 633, "raceIdToWreckTypeId": {"0": 26585}}
92	659	{"_key": 659, "raceIdToWreckTypeId": {"1": 26509, "2": 26553, "4": 26487, "8": 26531, "32": 3260}}
93	665	{"_key": 665, "raceIdToWreckTypeId": {"0": 27052}}
94	666	{"_key": 666, "raceIdToWreckTypeId": {"0": 27051}}
95	667	{"_key": 667, "raceIdToWreckTypeId": {"0": 27050}}
96	668	{"_key": 668, "raceIdToWreckTypeId": {"0": 27051}}
97	669	{"_key": 669, "raceIdToWreckTypeId": {"0": 27052}}
98	670	{"_key": 670, "raceIdToWreckTypeId": {"0": 26560}}
99	671	{"_key": 671, "raceIdToWreckTypeId": {"0": 27049}}
100	672	{"_key": 672, "raceIdToWreckTypeId": {"0": 27048}}
101	673	{"_key": 673, "raceIdToWreckTypeId": {"0": 27048}}
102	674	{"_key": 674, "raceIdToWreckTypeId": {"0": 27047}}
103	675	{"_key": 675, "raceIdToWreckTypeId": {"0": 26560}}
104	676	{"_key": 676, "raceIdToWreckTypeId": {"0": 27049}}
105	677	{"_key": 677, "raceIdToWreckTypeId": {"0": 27055}}
106	678	{"_key": 678, "raceIdToWreckTypeId": {"0": 27054}}
107	679	{"_key": 679, "raceIdToWreckTypeId": {"0": 27055}}
108	680	{"_key": 680, "raceIdToWreckTypeId": {"0": 27053}}
109	681	{"_key": 681, "raceIdToWreckTypeId": {"0": 27054}}
110	682	{"_key": 682, "raceIdToWreckTypeId": {"0": 26560}}
111	683	{"_key": 683, "raceIdToWreckTypeId": {"0": 27043}}
112	684	{"_key": 684, "raceIdToWreckTypeId": {"0": 27043}}
113	685	{"_key": 685, "raceIdToWreckTypeId": {"0": 27042}}
114	686	{"_key": 686, "raceIdToWreckTypeId": {"0": 26560}}
115	687	{"_key": 687, "raceIdToWreckTypeId": {"0": 27046}}
116	688	{"_key": 688, "raceIdToWreckTypeId": {"0": 27046}}
117	689	{"_key": 689, "raceIdToWreckTypeId": {"0": 27045}}
118	690	{"_key": 690, "raceIdToWreckTypeId": {"0": 27045}}
119	691	{"_key": 691, "raceIdToWreckTypeId": {"0": 27044}}
120	692	{"_key": 692, "raceIdToWreckTypeId": {"0": 26560}}
121	693	{"_key": 693, "raceIdToWreckTypeId": {"0": 26557}}
122	694	{"_key": 694, "raceIdToWreckTypeId": {"0": 26557}}
123	695	{"_key": 695, "raceIdToWreckTypeId": {"0": 26558}}
124	696	{"_key": 696, "raceIdToWreckTypeId": {"0": 26558}}
125	697	{"_key": 697, "raceIdToWreckTypeId": {"0": 26559}}
126	699	{"_key": 699, "raceIdToWreckTypeId": {"0": 27062}}
127	700	{"_key": 700, "raceIdToWreckTypeId": {"0": 27062}}
128	701	{"_key": 701, "raceIdToWreckTypeId": {"0": 27061}}
129	702	{"_key": 702, "raceIdToWreckTypeId": {"0": 27061}}
130	703	{"_key": 703, "raceIdToWreckTypeId": {"0": 27060}}
131	704	{"_key": 704, "raceIdToWreckTypeId": {"0": 26560}}
132	705	{"_key": 705, "raceIdToWreckTypeId": {"0": 27042}}
133	706	{"_key": 706, "raceIdToWreckTypeId": {"0": 27041}}
134	755	{"_key": 755, "raceIdToWreckTypeId": {"0": 26592}}
135	756	{"_key": 756, "raceIdToWreckTypeId": {"0": 26593}}
136	757	{"_key": 757, "raceIdToWreckTypeId": {"0": 26592}}
137	758	{"_key": 758, "raceIdToWreckTypeId": {"0": 26591}}
138	759	{"_key": 759, "raceIdToWreckTypeId": {"0": 26591}}
139	760	{"_key": 760, "raceIdToWreckTypeId": {"0": 26592}}
140	761	{"_key": 761, "raceIdToWreckTypeId": {"0": 26591}}
141	789	{"_key": 789, "raceIdToWreckTypeId": {"0": 26564}}
142	790	{"_key": 790, "raceIdToWreckTypeId": {"0": 26699}}
143	791	{"_key": 791, "raceIdToWreckTypeId": {"0": 26571}}
144	792	{"_key": 792, "raceIdToWreckTypeId": {"0": 26570}}
145	793	{"_key": 793, "raceIdToWreckTypeId": {"0": 26699}}
146	794	{"_key": 794, "raceIdToWreckTypeId": {"0": 26564}}
147	795	{"_key": 795, "raceIdToWreckTypeId": {"0": 26571}}
148	796	{"_key": 796, "raceIdToWreckTypeId": {"0": 26570}}
149	797	{"_key": 797, "raceIdToWreckTypeId": {"0": 26577}}
150	798	{"_key": 798, "raceIdToWreckTypeId": {"0": 26577}}
151	799	{"_key": 799, "raceIdToWreckTypeId": {"0": 26576}}
152	800	{"_key": 800, "raceIdToWreckTypeId": {"0": 26576}}
153	801	{"_key": 801, "raceIdToWreckTypeId": {"0": 26592}}
154	802	{"_key": 802, "raceIdToWreckTypeId": {"0": 26593}}
155	803	{"_key": 803, "raceIdToWreckTypeId": {"0": 26592}}
156	804	{"_key": 804, "raceIdToWreckTypeId": {"0": 26591}}
157	805	{"_key": 805, "raceIdToWreckTypeId": {"0": 26591}}
158	806	{"_key": 806, "raceIdToWreckTypeId": {"0": 26591}}
159	807	{"_key": 807, "raceIdToWreckTypeId": {"0": 26583}}
160	808	{"_key": 808, "raceIdToWreckTypeId": {"0": 26583}}
161	809	{"_key": 809, "raceIdToWreckTypeId": {"0": 26582}}
162	810	{"_key": 810, "raceIdToWreckTypeId": {"0": 26582}}
163	811	{"_key": 811, "raceIdToWreckTypeId": {"0": 26589}}
164	812	{"_key": 812, "raceIdToWreckTypeId": {"0": 26589}}
165	813	{"_key": 813, "raceIdToWreckTypeId": {"0": 26588}}
166	814	{"_key": 814, "raceIdToWreckTypeId": {"0": 26588}}
167	816	{"_key": 816, "raceIdToWreckTypeId": {"0": 26933}}
168	817	{"_key": 817, "raceIdToWreckTypeId": {"0": 26934}}
169	818	{"_key": 818, "raceIdToWreckTypeId": {"0": 26935}}
170	819	{"_key": 819, "raceIdToWreckTypeId": {"0": 26918}}
171	820	{"_key": 820, "raceIdToWreckTypeId": {"0": 26919}}
172	821	{"_key": 821, "raceIdToWreckTypeId": {"0": 26920}}
173	822	{"_key": 822, "raceIdToWreckTypeId": {"0": 27057}}
174	823	{"_key": 823, "raceIdToWreckTypeId": {"0": 27056}}
175	824	{"_key": 824, "raceIdToWreckTypeId": {"0": 27057}}
176	825	{"_key": 825, "raceIdToWreckTypeId": {"0": 27058}}
177	826	{"_key": 826, "raceIdToWreckTypeId": {"0": 27058}}
178	827	{"_key": 827, "raceIdToWreckTypeId": {"0": 26560}}
179	828	{"_key": 828, "raceIdToWreckTypeId": {"0": 26934}}
180	829	{"_key": 829, "raceIdToWreckTypeId": {"0": 26935}}
181	830	{"_key": 830, "raceIdToWreckTypeId": {"1": 26502, "2": 26546, "4": 26480, "8": 26524}}
182	831	{"_key": 831, "raceIdToWreckTypeId": {"1": 26502, "2": 26546, "4": 26480, "8": 26524}}
183	832	{"_key": 832, "raceIdToWreckTypeId": {"1": 26500, "2": 26544, "4": 26478, "8": 26522}}
184	833	{"_key": 833, "raceIdToWreckTypeId": {"1": 26500, "2": 26544, "4": 26478, "8": 26522}}
185	834	{"_key": 834, "raceIdToWreckTypeId": {"1": 26502, "2": 26546, "4": 26480, "8": 26524}}
186	843	{"_key": 843, "raceIdToWreckTypeId": {"0": 28222}}
187	844	{"_key": 844, "raceIdToWreckTypeId": {"0": 28221}}
188	845	{"_key": 845, "raceIdToWreckTypeId": {"0": 28222}}
189	846	{"_key": 846, "raceIdToWreckTypeId": {"0": 28223}}
190	847	{"_key": 847, "raceIdToWreckTypeId": {"0": 28223}}
191	848	{"_key": 848, "raceIdToWreckTypeId": {"0": 26565}}
192	849	{"_key": 849, "raceIdToWreckTypeId": {"0": 26700}}
193	850	{"_key": 850, "raceIdToWreckTypeId": {"0": 26701}}
194	851	{"_key": 851, "raceIdToWreckTypeId": {"0": 26702}}
195	852	{"_key": 852, "raceIdToWreckTypeId": {"0": 26703}}
196	865	{"_key": 865, "raceIdToWreckTypeId": {"0": 27927}}
197	866	{"_key": 866, "raceIdToWreckTypeId": {"0": 27926}}
198	867	{"_key": 867, "raceIdToWreckTypeId": {"0": 27929}}
199	868	{"_key": 868, "raceIdToWreckTypeId": {"0": 27928}}
200	875	{"_key": 875, "raceIdToWreckTypeId": {"0": 28255, "128": 28255}}
201	883	{"_key": 883, "raceIdToWreckTypeId": {"1": 28603, "8": 33765, "128": 28603}}
202	893	{"_key": 893, "raceIdToWreckTypeId": {"1": 26502, "2": 26546, "4": 26480, "8": 26524}}
203	894	{"_key": 894, "raceIdToWreckTypeId": {"1": 26500, "2": 26544, "4": 26478, "8": 26522}}
204	898	{"_key": 898, "raceIdToWreckTypeId": {"1": 26499, "2": 26543, "4": 26477, "8": 26521}}
205	900	{"_key": 900, "raceIdToWreckTypeId": {"1": 26499, "2": 26543, "4": 26477, "8": 26521}}
206	902	{"_key": 902, "raceIdToWreckTypeId": {"1": 29034, "2": 29036, "4": 29033, "8": 29035}}
207	906	{"_key": 906, "raceIdToWreckTypeId": {"1": 26500, "2": 26544, "4": 26478, "8": 26522}}
208	924	{"_key": 924, "raceIdToWreckTypeId": {"0": 29347}}
209	927	{"_key": 927, "raceIdToWreckTypeId": {"0": 29365}}
210	941	{"_key": 941, "raceIdToWreckTypeId": {"1": 29639, "8": 33766, "128": 29639}}
211	959	{"_key": 959, "raceIdToWreckTypeId": {"0": 30496}}
212	960	{"_key": 960, "raceIdToWreckTypeId": {"0": 30458}}
213	961	{"_key": 961, "raceIdToWreckTypeId": {"0": 30457}}
214	963	{"_key": 963, "raceIdToWreckTypeId": {"1": 30823, "2": 30825, "4": 30822, "8": 30824}}
215	982	{"_key": 982, "raceIdToWreckTypeId": {"0": 30495}}
216	983	{"_key": 983, "raceIdToWreckTypeId": {"0": 30494}}
217	984	{"_key": 984, "raceIdToWreckTypeId": {"0": 30493}}
218	985	{"_key": 985, "raceIdToWreckTypeId": {"0": 30492}}
219	986	{"_key": 986, "raceIdToWreckTypeId": {"0": 30485}}
220	987	{"_key": 987, "raceIdToWreckTypeId": {"0": 30484}}
221	1006	{"_key": 1006, "raceIdToWreckTypeId": {"0": 29347}}
222	1007	{"_key": 1007, "raceIdToWreckTypeId": {"0": 29347}}
223	1022	{"_key": 1022, "raceIdToWreckTypeId": {"8": 26533}}
224	1052	{"_key": 1052, "raceIdToWreckTypeId": {"0": 3260}}
225	1053	{"_key": 1053, "raceIdToWreckTypeId": {"0": 26579}}
226	1054	{"_key": 1054, "raceIdToWreckTypeId": {"0": 26580}}
227	1056	{"_key": 1056, "raceIdToWreckTypeId": {"0": 26581}}
228	1166	{"_key": 1166, "raceIdToWreckTypeId": {"0": 27043, "2": 27043}}
229	1167	{"_key": 1167, "raceIdToWreckTypeId": {"0": 27049, "1": 27049}}
230	1168	{"_key": 1168, "raceIdToWreckTypeId": {"0": 27055, "8": 27055}}
231	1169	{"_key": 1169, "raceIdToWreckTypeId": {"0": 27052, "4": 27052}}
232	1174	{"_key": 1174, "raceIdToWreckTypeId": {"0": 26596}}
233	1175	{"_key": 1175, "raceIdToWreckTypeId": {"0": 27052, "4": 27052}}
234	1176	{"_key": 1176, "raceIdToWreckTypeId": {"0": 27049, "1": 27049}}
235	1177	{"_key": 1177, "raceIdToWreckTypeId": {"0": 27055, "8": 27055}}
236	1178	{"_key": 1178, "raceIdToWreckTypeId": {"0": 27043, "2": 27043}}
237	1179	{"_key": 1179, "raceIdToWreckTypeId": {"0": 27051, "4": 27051}}
238	1180	{"_key": 1180, "raceIdToWreckTypeId": {"0": 27048, "1": 27048}}
239	1181	{"_key": 1181, "raceIdToWreckTypeId": {"0": 27054, "8": 27054}}
240	1182	{"_key": 1182, "raceIdToWreckTypeId": {"0": 27042, "2": 27042}}
241	1183	{"_key": 1183, "raceIdToWreckTypeId": {"0": 27051, "4": 27051}}
242	1184	{"_key": 1184, "raceIdToWreckTypeId": {"0": 27048, "1": 27048}}
243	1185	{"_key": 1185, "raceIdToWreckTypeId": {"0": 27054, "8": 27054}}
244	1186	{"_key": 1186, "raceIdToWreckTypeId": {"0": 27042, "2": 27042}}
245	1201	{"_key": 1201, "raceIdToWreckTypeId": {"1": 26491, "2": 26535, "4": 26469, "8": 26513}}
246	1202	{"_key": 1202, "raceIdToWreckTypeId": {"1": 26503, "2": 26547, "4": 26481, "8": 26525}}
247	1246	{"_key": 1246, "raceIdToWreckTypeId": {"0": 33538}}
248	1247	{"_key": 1247, "raceIdToWreckTypeId": {"0": 33538}}
249	1249	{"_key": 1249, "raceIdToWreckTypeId": {"0": 33538}}
250	1250	{"_key": 1250, "raceIdToWreckTypeId": {"0": 33538}}
251	1252	{"_key": 1252, "raceIdToWreckTypeId": {"0": 26562}}
252	1255	{"_key": 1255, "raceIdToWreckTypeId": {"0": 26568}}
253	1259	{"_key": 1259, "raceIdToWreckTypeId": {"0": 26574}}
254	1262	{"_key": 1262, "raceIdToWreckTypeId": {"0": 26586}}
255	1265	{"_key": 1265, "raceIdToWreckTypeId": {"0": 26580}}
256	1283	{"_key": 1283, "raceIdToWreckTypeId": {"128": 26524}}
257	1285	{"_key": 1285, "raceIdToWreckTypeId": {"1": 33909}}
258	1286	{"_key": 1286, "raceIdToWreckTypeId": {"1": 33908}}
259	1287	{"_key": 1287, "raceIdToWreckTypeId": {"1": 33907}}
260	1288	{"_key": 1288, "raceIdToWreckTypeId": {"0": 27060}}
261	1305	{"_key": 1305, "raceIdToWreckTypeId": {"1": 37861, "2": 34584, "4": 34395, "8": 37862}}
262	1307	{"_key": 1307, "raceIdToWreckTypeId": {"0": 34440}}
263	1310	{"_key": 1310, "raceIdToWreckTypeId": {"0": 34768}}
264	1402	{"_key": 1402, "raceIdToWreckTypeId": {"4": 27050}}
265	1411	{"_key": 1411, "raceIdToWreckTypeId": {"4": 27051}}
266	1412	{"_key": 1412, "raceIdToWreckTypeId": {"4": 27927}}
267	1413	{"_key": 1413, "raceIdToWreckTypeId": {"4": 27051}}
268	1414	{"_key": 1414, "raceIdToWreckTypeId": {"4": 27052}}
269	1465	{"_key": 1465, "raceIdToWreckTypeId": {"1": 26509}}
270	1527	{"_key": 1527, "raceIdToWreckTypeId": {"1": 26502, "2": 26546, "4": 26480, "8": 26524}}
271	1529	{"_key": 1529, "raceIdToWreckTypeId": {"0": 37596}}
272	1530	{"_key": 1530, "raceIdToWreckTypeId": {"0": 37531}}
273	1534	{"_key": 1534, "raceIdToWreckTypeId": {"1": 26501, "2": 26545, "4": 26479, "8": 26523}}
274	1538	{"_key": 1538, "raceIdToWreckTypeId": {"1": 40640, "2": 40642, "4": 40639, "8": 40641}}
275	1566	{"_key": 1566, "raceIdToWreckTypeId": {"0": 26585}}
276	1567	{"_key": 1567, "raceIdToWreckTypeId": {"0": 26586}}
277	1568	{"_key": 1568, "raceIdToWreckTypeId": {"0": 26586}}
278	1657	{"_key": 1657, "raceIdToWreckTypeId": {"0": 40644, "1": 40645, "2": 40644, "4": 40646, "8": 40647}}
279	1681	{"_key": 1681, "raceIdToWreckTypeId": {"0": 41688}}
280	1682	{"_key": 1682, "raceIdToWreckTypeId": {"0": 41689}}
281	1683	{"_key": 1683, "raceIdToWreckTypeId": {"0": 41690}}
282	1684	{"_key": 1684, "raceIdToWreckTypeId": {"0": 41691}}
283	1685	{"_key": 1685, "raceIdToWreckTypeId": {"0": 41692}}
284	1686	{"_key": 1686, "raceIdToWreckTypeId": {"0": 41693}}
285	1687	{"_key": 1687, "raceIdToWreckTypeId": {"0": 41696}}
286	1688	{"_key": 1688, "raceIdToWreckTypeId": {"0": 3260}}
287	1689	{"_key": 1689, "raceIdToWreckTypeId": {"0": 41699}}
288	1690	{"_key": 1690, "raceIdToWreckTypeId": {"0": 41700}}
289	1691	{"_key": 1691, "raceIdToWreckTypeId": {"0": 41694}}
290	1692	{"_key": 1692, "raceIdToWreckTypeId": {"0": 41695}}
291	1724	{"_key": 1724, "raceIdToWreckTypeId": {"0": 26561}}
292	1725	{"_key": 1725, "raceIdToWreckTypeId": {"0": 26562}}
293	1726	{"_key": 1726, "raceIdToWreckTypeId": {"0": 26562}}
\.


--
-- Name: wrecks wrecks_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.wrecks
    ADD CONSTRAINT wrecks_pkey PRIMARY KEY (row_no);


--
-- Name: wrecks_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX wrecks_key_idx ON sde_native.wrecks USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict jVIQLt1FXgCfk1PixfDhWhqjdMy7ayYEOGg4IWFUrdHhaKnNFOzpRXGZHGoHkKS

