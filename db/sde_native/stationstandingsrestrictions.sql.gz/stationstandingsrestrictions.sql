--
-- PostgreSQL database dump
--

\restrict 2L6Z8mdrFg0HSVNJwRitbjSIsmOJe4i2IXtx7tdafC1LMb00rZ2oXbNEEYEjvhd

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: stationstandingsrestrictions; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.stationstandingsrestrictions (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: stationstandingsrestrictions; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.stationstandingsrestrictions (row_no, key, data) FROM stdin;
0	500026	{"_key": 500026, "services": {"5": 3.0, "13": -0.05, "14": 3.0, "17": -0.05, "22": -0.05, "23": 3.0, "24": 3.0}}
1	1000438	{"_key": 1000438, "services": {}}
\.


--
-- Name: stationstandingsrestrictions stationstandingsrestrictions_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.stationstandingsrestrictions
    ADD CONSTRAINT stationstandingsrestrictions_pkey PRIMARY KEY (row_no);


--
-- Name: stationstandingsrestrictions_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX stationstandingsrestrictions_key_idx ON sde_native.stationstandingsrestrictions USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 2L6Z8mdrFg0HSVNJwRitbjSIsmOJe4i2IXtx7tdafC1LMb00rZ2oXbNEEYEjvhd

