--
-- PostgreSQL database dump
--

\restrict ZByYGoeEXKvRJeEdvJli0rWmHjRrgzj9EVVPT6zvi7aSI1xZNBY2a3V7uHb1FeI

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: achievements; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.achievements (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: achievements; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.achievements (row_no, key, data) FROM stdin;
0	2	{"_key": 2, "nameID": 502374, "isEnabled": true, "achievementID": 2, "descriptionID": 502373, "simpleConditions": {"0": {"statistic": 86, "targetValue": 3}}, "notificationTextID": 505218, "isClientAchievement": false}
1	3	{"_key": 3, "nameID": 502376, "isEnabled": false, "achievementID": 3, "descriptionID": 502375, "simpleConditions": {"0": {"statistic": 3, "targetValue": 2000}}, "notificationTextID": 505219, "isClientAchievement": false}
2	4	{"_key": 4, "nameID": 502372, "isEnabled": false, "achievementID": 4, "descriptionID": 502371, "simpleConditions": {"0": {"statistic": 86, "targetValue": 50}}, "notificationTextID": 505220, "isClientAchievement": false}
3	9	{"_key": 9, "nameID": 504077, "isEnabled": true, "achievementID": 9, "descriptionID": 504076, "simpleConditions": {"0": {"statistic": 74, "targetValue": 1}}, "notificationTextID": 504750, "isClientAchievement": false}
4	10	{"_key": 10, "nameID": 504079, "isEnabled": true, "achievementID": 10, "descriptionID": 504078, "simpleConditions": {"0": {"statistic": 90, "targetValue": 1}}, "notificationTextID": 505140, "isClientAchievement": false}
5	12	{"_key": 12, "nameID": 504082, "isEnabled": true, "achievementID": 12, "descriptionID": 504081, "simpleConditions": {"0": {"statistic": 1, "targetValue": 1}}, "notificationTextID": 505135, "isClientAchievement": false}
6	13	{"_key": 13, "nameID": 504083, "isEnabled": true, "achievementID": 13, "descriptionID": 504086, "simpleConditions": {"0": {"statistic": 92, "targetValue": 1}}, "notificationTextID": 505221, "isClientAchievement": false}
7	14	{"_key": 14, "nameID": 504084, "isEnabled": false, "achievementID": 14, "descriptionID": 504087, "simpleConditions": {"0": {"statistic": 94, "targetValue": 1}}, "notificationTextID": 505222, "isClientAchievement": false}
8	15	{"_key": 15, "nameID": 504085, "isEnabled": true, "achievementID": 15, "descriptionID": 504088, "simpleConditions": {"0": {"statistic": 93, "targetValue": 1}}, "notificationTextID": 505224, "isClientAchievement": false}
9	16	{"_key": 16, "nameID": 504092, "isEnabled": true, "achievementID": 16, "descriptionID": 504091, "simpleConditions": {"0": {"statistic": 95, "targetValue": 1}}, "notificationTextID": 505139, "isClientAchievement": false}
10	17	{"_key": 17, "nameID": 504094, "isEnabled": true, "achievementID": 17, "descriptionID": 504093, "simpleConditions": {"0": {"statistic": 96, "targetValue": 1}}, "notificationTextID": 504749, "isClientAchievement": false}
11	18	{"_key": 18, "nameID": 504096, "isEnabled": true, "achievementID": 18, "descriptionID": 504095, "simpleConditions": {"0": {"statistic": 97, "targetValue": 1}}, "notificationTextID": 505225, "isClientAchievement": false}
12	19	{"_key": 19, "nameID": 504099, "isEnabled": true, "achievementID": 19, "descriptionID": 504098, "simpleConditions": {"0": {"statistic": 11, "targetValue": 1}}, "notificationTextID": 505204, "isClientAchievement": false}
13	20	{"_key": 20, "nameID": 504101, "isEnabled": true, "achievementID": 20, "descriptionID": 504100, "simpleConditions": {"0": {"statistic": 99, "targetValue": 1}}, "notificationTextID": 505227, "isClientAchievement": false}
14	23	{"_key": 23, "nameID": 505047, "isEnabled": true, "achievementID": 23, "descriptionID": 505046, "simpleConditions": {"0": {"statistic": 110, "targetValue": 1}}, "notificationTextID": 505048, "isClientAchievement": true}
15	24	{"_key": 24, "nameID": 505050, "isEnabled": true, "achievementID": 24, "descriptionID": 505049, "simpleConditions": {"0": {"statistic": 34, "targetValue": 1}}, "notificationTextID": 505051, "isClientAchievement": false}
16	25	{"_key": 25, "nameID": 505053, "isEnabled": true, "achievementID": 25, "descriptionID": 505052, "simpleConditions": {"0": {"statistic": 120, "targetValue": 1}}, "notificationTextID": 505054, "isClientAchievement": false}
17	26	{"_key": 26, "nameID": 505056, "isEnabled": true, "achievementID": 26, "descriptionID": 505055, "simpleConditions": {"0": {"statistic": 119, "targetValue": 1}}, "notificationTextID": 505057, "isClientAchievement": true}
18	27	{"_key": 27, "nameID": 505059, "isEnabled": true, "achievementID": 27, "descriptionID": 505058, "simpleConditions": {"0": {"statistic": 113, "targetValue": 1}}, "notificationTextID": 505060, "isClientAchievement": true}
19	28	{"_key": 28, "nameID": 505062, "isEnabled": true, "achievementID": 28, "descriptionID": 505061, "simpleConditions": {"0": {"statistic": 112, "targetValue": 1}}, "notificationTextID": 505063, "isClientAchievement": true}
20	29	{"_key": 29, "nameID": 505065, "isEnabled": true, "achievementID": 29, "descriptionID": 505064, "simpleConditions": {"0": {"statistic": 118, "targetValue": 1}}, "notificationTextID": 505066, "isClientAchievement": true}
21	30	{"_key": 30, "nameID": 505068, "isEnabled": true, "achievementID": 30, "descriptionID": 505067, "simpleConditions": {"0": {"statistic": 117, "targetValue": 1}}, "notificationTextID": 505069, "isClientAchievement": true}
22	31	{"_key": 31, "nameID": 505071, "isEnabled": true, "achievementID": 31, "descriptionID": 505070, "simpleConditions": {"0": {"statistic": 116, "targetValue": 1}}, "notificationTextID": 505072, "isClientAchievement": true}
23	32	{"_key": 32, "nameID": 505074, "isEnabled": true, "achievementID": 32, "descriptionID": 505073, "simpleConditions": {"0": {"statistic": 106, "targetValue": 1}}, "notificationTextID": 505075, "isClientAchievement": false}
24	36	{"_key": 36, "nameID": 505133, "isEnabled": true, "achievementID": 36, "descriptionID": 505132, "simpleConditions": {"0": {"statistic": 115, "targetValue": 1}}, "notificationTextID": 505134, "isClientAchievement": true}
25	37	{"_key": 37, "nameID": 505137, "isEnabled": false, "achievementID": 37, "descriptionID": 505136, "simpleConditions": {"0": {"statistic": 87, "targetValue": 1}}, "notificationTextID": 505138, "isClientAchievement": false}
26	38	{"_key": 38, "nameID": 505206, "isEnabled": true, "achievementID": 38, "descriptionID": 505205, "simpleConditions": {"0": {"statistic": 18, "targetValue": 1}}, "notificationTextID": 505207, "isClientAchievement": true}
27	39	{"_key": 39, "nameID": 505317, "isEnabled": true, "achievementID": 39, "descriptionID": 505316, "simpleConditions": {"0": {"statistic": 122, "targetValue": 1}}, "notificationTextID": 505318, "isClientAchievement": false}
28	41	{"_key": 41, "nameID": 505383, "isEnabled": true, "achievementID": 41, "descriptionID": 505382, "simpleConditions": {"0": {"statistic": 102, "targetValue": 1}}, "notificationTextID": 505384, "isClientAchievement": false}
29	42	{"_key": 42, "nameID": 505386, "isEnabled": true, "achievementID": 42, "descriptionID": 505385, "simpleConditions": {"0": {"statistic": 103, "targetValue": 1}}, "notificationTextID": 505387, "isClientAchievement": false}
30	43	{"_key": 43, "nameID": 505389, "isEnabled": true, "achievementID": 43, "descriptionID": 505388, "simpleConditions": {"0": {"statistic": 123, "targetValue": 1}}, "notificationTextID": 505390, "isClientAchievement": true}
31	44	{"_key": 44, "nameID": 505392, "isEnabled": true, "achievementID": 44, "descriptionID": 505391, "simpleConditions": {"0": {"statistic": 127, "targetValue": 1}}, "notificationTextID": 505393, "isClientAchievement": true}
32	45	{"_key": 45, "nameID": 505395, "isEnabled": true, "achievementID": 45, "descriptionID": 505394, "simpleConditions": {"0": {"statistic": 129, "targetValue": 1}}, "notificationTextID": 505396, "isClientAchievement": true}
33	46	{"_key": 46, "nameID": 505398, "isEnabled": true, "achievementID": 46, "descriptionID": 505397, "simpleConditions": {"0": {"statistic": 128, "targetValue": 1}}, "notificationTextID": 505399, "isClientAchievement": true}
34	47	{"_key": 47, "nameID": 505401, "isEnabled": true, "achievementID": 47, "descriptionID": 505400, "simpleConditions": {"0": {"statistic": 130, "targetValue": 1}}, "notificationTextID": 505402, "isClientAchievement": true}
35	48	{"_key": 48, "nameID": 505404, "isEnabled": true, "achievementID": 48, "descriptionID": 505403, "simpleConditions": {"0": {"statistic": 135, "targetValue": 1}}, "notificationTextID": 505405, "isClientAchievement": false}
36	49	{"_key": 49, "nameID": 505407, "isEnabled": true, "achievementID": 49, "descriptionID": 505406, "simpleConditions": {"0": {"statistic": 136, "targetValue": 1}}, "notificationTextID": 505408, "isClientAchievement": false}
37	50	{"_key": 50, "nameID": 505410, "isEnabled": true, "achievementID": 50, "descriptionID": 505409, "simpleConditions": {"0": {"statistic": 137, "targetValue": 1}}, "notificationTextID": 505411, "isClientAchievement": false}
38	51	{"_key": 51, "nameID": 505413, "isEnabled": false, "achievementID": 51, "descriptionID": 505412, "simpleConditions": {"0": {"statistic": 134, "targetValue": 1}}, "notificationTextID": 505414, "isClientAchievement": false}
39	52	{"_key": 52, "nameID": 505416, "isEnabled": true, "achievementID": 52, "descriptionID": 505415, "simpleConditions": {"0": {"statistic": 131, "targetValue": 1}}, "notificationTextID": 505417, "isClientAchievement": false}
40	53	{"_key": 53, "nameID": 505419, "isEnabled": true, "achievementID": 53, "descriptionID": 505418, "simpleConditions": {"0": {"statistic": 126, "targetValue": 1}}, "notificationTextID": 505420, "isClientAchievement": true}
41	54	{"_key": 54, "nameID": 505422, "isEnabled": false, "achievementID": 54, "descriptionID": 505421, "simpleConditions": {"0": {"statistic": 132, "targetValue": 1}}, "notificationTextID": 505423, "isClientAchievement": false}
42	55	{"_key": 55, "nameID": 505425, "isEnabled": true, "achievementID": 55, "descriptionID": 505424, "simpleConditions": {"0": {"statistic": 125, "targetValue": 1}}, "notificationTextID": 505426, "isClientAchievement": true}
43	56	{"_key": 56, "nameID": 505434, "isEnabled": false, "achievementID": 56, "descriptionID": 505433, "simpleConditions": {"0": {"statistic": 133, "targetValue": 1}}, "notificationTextID": 505435, "isClientAchievement": false}
44	57	{"_key": 57, "nameID": 505440, "isEnabled": true, "achievementID": 57, "descriptionID": 505439, "simpleConditions": {"0": {"statistic": 101, "targetValue": 1}}, "notificationTextID": 505441, "isClientAchievement": false}
45	58	{"_key": 58, "nameID": 505446, "isEnabled": true, "achievementID": 58, "descriptionID": 505445, "simpleConditions": {"0": {"statistic": 104, "targetValue": 1}}, "notificationTextID": 505447, "isClientAchievement": false}
46	59	{"_key": 59, "nameID": 505449, "isEnabled": true, "achievementID": 59, "descriptionID": 505448, "simpleConditions": {"0": {"statistic": 107, "targetValue": 1}}, "notificationTextID": 505450, "isClientAchievement": false}
47	60	{"_key": 60, "nameID": 505456, "isEnabled": true, "achievementID": 60, "descriptionID": 505455, "simpleConditions": {"0": {"statistic": 138, "targetValue": 1}, "1": {"statistic": 124, "targetValue": 1}}, "notificationTextID": 505457, "isClientAchievement": true}
48	61	{"_key": 61, "nameID": 505459, "isEnabled": true, "achievementID": 61, "descriptionID": 505458, "simpleConditions": {"0": {"statistic": 139, "targetValue": 1}}, "notificationTextID": 505460, "isClientAchievement": true}
49	62	{"_key": 62, "nameID": 505467, "isEnabled": true, "achievementID": 62, "descriptionID": 505466, "simpleConditions": {"0": {"statistic": 140, "targetValue": 1}}, "notificationTextID": 505468, "isClientAchievement": false}
50	63	{"_key": 63, "nameID": 505528, "isEnabled": true, "achievementID": 63, "descriptionID": 505527, "simpleConditions": {"0": {"statistic": 15, "targetValue": 1}}, "notificationTextID": 505529, "isClientAchievement": true}
51	64	{"_key": 64, "nameID": 505531, "isEnabled": true, "achievementID": 64, "descriptionID": 505530, "simpleConditions": {"0": {"statistic": 142, "targetValue": 1}}, "notificationTextID": 505532, "isClientAchievement": true}
52	65	{"_key": 65, "nameID": 505534, "isEnabled": false, "achievementID": 65, "descriptionID": 505533, "simpleConditions": {"0": {"statistic": 120, "targetValue": 1}}, "notificationTextID": 505535, "isClientAchievement": false}
53	66	{"_key": 66, "nameID": 505537, "isEnabled": true, "achievementID": 66, "descriptionID": 505536, "simpleConditions": {"0": {"statistic": 45, "targetValue": 1}}, "notificationTextID": 505538, "isClientAchievement": false}
54	70	{"_key": 70, "nameID": 505609, "isEnabled": true, "achievementID": 70, "descriptionID": 505608, "simpleConditions": {"0": {"statistic": 59, "targetValue": 1}}, "notificationTextID": 505610, "isClientAchievement": false}
55	71	{"_key": 71, "nameID": 505612, "isEnabled": true, "achievementID": 71, "descriptionID": 505611, "simpleConditions": {"0": {"statistic": 145, "targetValue": 1}}, "notificationTextID": 505613, "isClientAchievement": false}
56	72	{"_key": 72, "nameID": 505615, "isEnabled": true, "achievementID": 72, "descriptionID": 505614, "simpleConditions": {"0": {"statistic": 146, "targetValue": 1}}, "notificationTextID": 505616, "isClientAchievement": false}
57	73	{"_key": 73, "nameID": 505618, "isEnabled": true, "achievementID": 73, "descriptionID": 505617, "simpleConditions": {"0": {"statistic": 147, "targetValue": 1}}, "notificationTextID": 505619, "isClientAchievement": true}
58	74	{"_key": 74, "nameID": 505621, "isEnabled": true, "achievementID": 74, "descriptionID": 505620, "simpleConditions": {"0": {"statistic": 148, "targetValue": 1}}, "notificationTextID": 505622, "isClientAchievement": true}
59	75	{"_key": 75, "nameID": 505624, "isEnabled": true, "achievementID": 75, "descriptionID": 505623, "simpleConditions": {"0": {"statistic": 149, "targetValue": 1}}, "notificationTextID": 505625, "isClientAchievement": true}
60	76	{"_key": 76, "nameID": 505627, "isEnabled": true, "achievementID": 76, "descriptionID": 505626, "simpleConditions": {"0": {"statistic": 150, "targetValue": 1}}, "notificationTextID": 505628, "isClientAchievement": true}
61	77	{"_key": 77, "nameID": 505630, "isEnabled": true, "achievementID": 77, "descriptionID": 505629, "simpleConditions": {"0": {"statistic": 151, "targetValue": 1}}, "notificationTextID": 505631, "isClientAchievement": false}
62	78	{"_key": 78, "nameID": 505647, "isEnabled": true, "achievementID": 78, "descriptionID": 505646, "simpleConditions": {"0": {"statistic": 152, "targetValue": 1}}, "notificationTextID": 505648, "isClientAchievement": false}
63	79	{"_key": 79, "nameID": 505650, "isEnabled": true, "achievementID": 79, "descriptionID": 505649, "simpleConditions": {"0": {"statistic": 153, "targetValue": 1}}, "notificationTextID": 505651, "isClientAchievement": true}
64	81	{"_key": 81, "nameID": 507623, "isEnabled": true, "achievementID": 81, "descriptionID": 507624, "simpleConditions": {"0": {"statistic": 92, "targetValue": 1}}, "notificationTextID": 507625, "isClientAchievement": false}
65	93	{"_key": 93, "nameID": 517656, "isEnabled": true, "achievementID": 93, "descriptionID": 517657, "simpleConditions": {"0": {"statistic": 1, "targetValue": 6}}, "notificationTextID": 517658, "isClientAchievement": false}
66	94	{"_key": 94, "nameID": 517663, "isEnabled": true, "achievementID": 94, "descriptionID": 517664, "simpleConditions": {"0": {"statistic": 116, "targetValue": 6}}, "notificationTextID": 517665, "isClientAchievement": true}
67	102	{"_key": 102, "nameID": 531287, "isEnabled": true, "achievementID": 102, "descriptionID": 531288, "simpleConditions": {"0": {"statistic": 154, "targetValue": 1}}, "notificationTextID": null, "isClientAchievement": true}
\.


--
-- Name: achievements achievements_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.achievements
    ADD CONSTRAINT achievements_pkey PRIMARY KEY (row_no);


--
-- Name: achievements_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX achievements_key_idx ON sde_native.achievements USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict ZByYGoeEXKvRJeEdvJli0rWmHjRrgzj9EVVPT6zvi7aSI1xZNBY2a3V7uHb1FeI

