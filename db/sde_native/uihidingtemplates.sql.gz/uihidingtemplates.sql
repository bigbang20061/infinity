--
-- PostgreSQL database dump
--

\restrict SjAMrPb3HmYDf3zOwqt8CZY6yodOYjFPIgTeAxc0yS9cl3eJUbgVKEOtVBas5SW

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: uihidingtemplates; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.uihidingtemplates (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: uihidingtemplates; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.uihidingtemplates (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "name": "Hide All UI", "uiElements": {"1": "hide", "2": "hide", "3": "hide", "4": "hide", "5": "hide", "6": "hide", "7": "hide", "8": "hide", "9": "hide", "10": "hide", "11": "hide", "12": "hide", "13": "hide", "14": "hide", "15": "hide", "16": "hide", "17": "hide", "19": "hide", "20": "hide", "24": "hide", "25": "hide", "26": "hide", "27": "hide", "28": "hide", "29": "hide", "31": "hide"}, "description": "Hides all UI Elements"}
1	2	{"_key": 2, "name": "AIR NPE - Reveal Aura", "uiElements": {"22": "reveal"}}
2	4	{"_key": 4, "name": "AIR NPE - Reveal Selected Item", "uiElements": {"4": "reveal", "22": "reveal"}}
3	5	{"_key": 5, "name": "AIR NPE - Reveal HUD Center", "uiElements": {"4": "reveal", "6": "reveal", "22": "reveal", "31": "reveal"}}
4	6	{"_key": 6, "name": "AIR NPE - Reveal Overview", "uiElements": {"1": "reveal", "4": "reveal", "6": "reveal", "22": "reveal", "31": "reveal"}}
5	7	{"_key": 7, "name": "AIR NPE - Reveal module slots", "uiElements": {"1": "reveal", "4": "reveal", "6": "reveal", "8": "reveal", "22": "reveal", "31": "reveal"}}
6	9	{"_key": 9, "name": "AIR NPE - Reveal NEOCOM", "uiElements": {"1": "reveal", "2": "reveal", "3": "reveal", "4": "reveal", "6": "reveal", "8": "reveal", "22": "reveal", "31": "reveal"}}
7	10	{"_key": 10, "name": "AIR NPE - Reveal Station Services", "uiElements": {"1": "reveal", "3": "reveal", "4": "reveal", "6": "reveal", "8": "reveal", "22": "reveal", "31": "reveal"}}
8	11	{"_key": 11, "name": "AIR NPE - Reveal UI For Mining Dungeon", "uiElements": {"1": "reveal", "2": "reveal", "3": "reveal", "4": "reveal", "6": "reveal", "8": "reveal", "12": "reveal", "22": "reveal", "27": "reveal", "28": "reveal", "31": "reveal"}}
9	13	{"_key": 13, "name": "AIR NPE - Reveal Auto Pilot", "uiElements": {"1": "reveal", "2": "reveal", "3": "reveal", "4": "reveal", "6": "reveal", "8": "reveal", "12": "reveal", "14": "reveal", "16": "reveal", "22": "reveal", "28": "reveal", "31": "reveal"}}
10	15	{"_key": 15, "name": "[AIR] 1.3.01 - Wake-up", "uiElements": {"1": "reveal", "4": "reveal", "6": "reveal", "8": "reveal", "22": "reveal", "28": "reveal", "31": "reveal"}}
11	16	{"_key": 16, "name": "[AIR] 1.3.02 - ACP Reward Introduction", "uiElements": {"1": "reveal", "2": "reveal", "4": "reveal", "6": "reveal", "8": "reveal", "22": "reveal", "28": "reveal", "31": "reveal"}}
12	17	{"_key": 17, "name": "[AIR] 1.3.04 - Board Corvette", "uiElements": {"1": "reveal", "2": "reveal", "3": "reveal", "4": "reveal", "6": "reveal", "8": "reveal", "22": "reveal", "28": "reveal", "31": "reveal"}}
\.


--
-- Name: uihidingtemplates uihidingtemplates_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.uihidingtemplates
    ADD CONSTRAINT uihidingtemplates_pkey PRIMARY KEY (row_no);


--
-- Name: uihidingtemplates_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX uihidingtemplates_key_idx ON sde_native.uihidingtemplates USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict SjAMrPb3HmYDf3zOwqt8CZY6yodOYjFPIgTeAxc0yS9cl3eJUbgVKEOtVBas5SW

