--
-- PostgreSQL database dump
--

\restrict oMC6hPI1waDveabvKOXybbJEA9c5g708J0HV68CyZqDDb275qJhOLqn5MhcdBOB

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: operationtreestructures; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.operationtreestructures (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: operationtreestructures; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.operationtreestructures (row_no, key, data) FROM stdin;
0	171	{"_key": 171, "name": "Death - Ship", "connections": {"157": []}, "description": "Global ship death category created for Brave New NPE (to activate on ship death at any point of the tutorial)"}
1	172	{"_key": 172, "name": "Death - Pod", "connections": {"158": []}, "description": "Global pod death category created for Brave New NPE (to activate on pod death at any point of the tutorial)"}
2	2437	{"_key": 2437, "name": "Decluttered Starting Tree", "connections": {"2395": [2396], "2397": [2395], "2401": [2397]}, "description": ""}
3	2438	{"_key": 2438, "name": "Combat 1 Tree (1)", "connections": {"2402": []}, "description": "Operations in the Combat 1 Career Path"}
4	2439	{"_key": 2439, "name": "Combat 2 Tree (1)", "connections": {"2403": []}, "description": "Operations in the Combat 2 Career Path"}
5	2440	{"_key": 2440, "name": "Combat 3 Tree (1)", "connections": {"2404": []}, "description": "Combat 3 Tree"}
6	2441	{"_key": 2441, "name": "Combat 4 Tree (1)", "connections": {"2405": []}, "description": "Operations in the Combat 4 Career Path"}
7	2442	{"_key": 2442, "name": "Combat 5 Tree (1)", "connections": {"2406": []}, "description": "Operations in the Combat 5 Career Path"}
8	2443	{"_key": 2443, "name": "Combat 6 Tree (1)", "connections": {"2407": []}, "description": "Operations in the Combat 6 Career Path"}
9	2444	{"_key": 2444, "name": "Handoff: Any Career Agent (1)", "connections": {"2408": []}, "description": "Hands the player off to choose their career agent"}
10	2460	{"_key": 2460, "name": "[AIR NPE]", "connections": {"2423": [2433], "2433": [2594], "2594": [2674]}, "description": "[AIR NPE] Tree"}
11	2465	{"_key": 2465, "name": "Odyssey Experience Scene 2", "connections": {"2433": []}, "description": ""}
12	2467	{"_key": 2467, "name": "Resource Harvesting", "connections": {"2436": [2437, 2439, 2440, 2441, 2442, 2443, 2444, 2445, 2446, 2447, 2448, 2449, 2450, 2451, 2453, 2454, 2452, 2455, 2456, 2457, 2556, 2557, 2558, 2559, 2560, 2562, 2563, 2564, 2565, 2566, 2567, 2568, 2569, 2570, 2571, 2764, 2765, 2766, 2767, 2768, 2769, 2770, 2771, 2772, 2773, 2774, 2775, 2776, 2777]}, "description": "Treatments"}
13	2468	{"_key": 2468, "name": "Reprocessing", "connections": {"2667": [2460, 2462, 2463, 2464, 2465, 2466, 2467, 2468, 2469, 2470, 2471, 2472, 2473, 2474, 2475, 2476, 2477, 2478, 2479, 2480, 2481, 2778, 2779, 2780, 2781, 2784, 2785, 2786, 2787, 2788, 2789, 2790, 2791, 2792, 2793]}, "description": "Treatments"}
14	2469	{"_key": 2469, "name": "Manufacturing", "connections": {"2482": [2484, 2485, 2486, 2487, 2489, 2490, 2491, 2492, 2493, 2494, 2495, 2496, 2497]}, "description": "Treatments"}
15	2470	{"_key": 2470, "name": "Salvaging", "connections": {"2668": [2657, 2658, 2659, 2660, 2661, 2662, 2498, 2499, 2500, 2501, 2502, 2503, 2504, 2505, 2506, 2507, 2508, 2509]}, "description": "Treatments"}
16	2471	{"_key": 2471, "name": "Combat", "connections": {"2510": [2511, 2512, 2513, 2514, 2551, 2552, 2553, 2554, 2555, 2642]}, "description": "Treatments"}
17	2472	{"_key": 2472, "name": "Security Agent", "connections": {"2669": [2520, 2521, 2522, 2523, 2524, 2525, 2526, 2527, 2528, 2529, 2530, 2531, 2532, 2533, 2534]}, "description": "Treatments"}
18	2474	{"_key": 2474, "name": "Distribution Agent", "connections": {"2670": [2536, 2537, 2538, 2539, 2540, 2541, 2542, 2543, 2544, 2545, 2546, 2547, 2548, 2549, 2550]}, "description": "Treatments"}
19	2476	{"_key": 2476, "name": "Market", "connections": {"2671": [2574, 2575, 2576, 2577, 2578, 2579, 2580, 2581, 2582, 2592, 2584, 2585, 2586, 2587, 2588, 2593, 2590, 2591]}, "description": "Treatments"}
20	2477	{"_key": 2477, "name": "Exploration", "connections": {"2672": [2595, 2596, 2597, 2598, 2599, 2612, 2614, 2617, 2615, 2616, 2623, 2624, 2625, 2626, 2627]}, "description": "Treatments"}
21	2478	{"_key": 2478, "name": "Treatments USER TEST", "connections": {"2629": [2630, 2520, 2632, 2631, 2628]}, "description": "Simplified Treatments for user testing"}
22	2479	{"_key": 2479, "name": "Social", "connections": {"2673": [2635, 2636, 2637, 2638, 2639, 2640, 2641]}, "description": "Treatments"}
23	2480	{"_key": 2480, "name": "Resource Harvesting 02", "connections": {"2663": [2443, 2444, 2445, 2441, 2442, 2436, 2437, 2439, 2440, 2446, 2447, 2448, 2449, 2450, 2451, 2453, 2454, 2452, 2455, 2456, 2457, 2556, 2557, 2558, 2559, 2560, 2562, 2563, 2564, 2565, 2566, 2567, 2568, 2569, 2570, 2571, 2764, 2765, 2766, 2767, 2768, 2769, 2770, 2771, 2772, 2773, 2774, 2775, 2776, 2777]}, "description": "Treatments"}
24	2481	{"_key": 2481, "name": "Manufacturing 02", "connections": {"2664": [2482, 2484, 2485, 2486, 2487, 2489, 2490, 2491, 2492, 2493, 2494, 2495, 2496, 2497]}, "description": "Treatments"}
25	2482	{"_key": 2482, "name": "Combat 02", "connections": {"2666": [2510, 2511, 2512, 2513, 2514, 2551, 2552, 2553, 2554, 2555, 2642]}, "description": "Treatments"}
26	2484	{"_key": 2484, "name": "Mining & Reprocessing", "connections": {"2663": [2675, 2676, 2677, 2679, 2680, 2681, 2682, 2683, 2684, 2685, 2686, 2687, 2688, 2689, 2690, 2691, 2692, 2693, 2694, 2695, 2696, 2794, 2795, 2796, 2797, 2798, 2799, 2800, 2801, 2802, 2803, 2804, 2805, 2806, 2807]}, "description": "Treatments"}
27	2485	{"_key": 2485, "name": "Landmarks", "connections": {"2672": [2698, 2699, 2704, 2705, 2706, 2707, 2708, 2709, 2710, 2711, 2712, 2713, 2714, 2715, 2716, 2717, 2720, 2718, 2721, 2722, 2723, 2724, 2725, 2726, 2727, 2728, 2729, 2730, 2731, 2732, 2733, 2734, 2735, 2736, 2737, 2738, 2739, 2740, 2741, 2742, 2743, 2744, 2745, 2746, 2747, 2748, 2749, 2750, 2751, 2752, 2753, 2754, 2755, 2756, 2757, 2758, 2759, 2760, 2761, 2762]}, "description": "Treatments"}
\.


--
-- Name: operationtreestructures operationtreestructures_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.operationtreestructures
    ADD CONSTRAINT operationtreestructures_pkey PRIMARY KEY (row_no);


--
-- Name: operationtreestructures_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX operationtreestructures_key_idx ON sde_native.operationtreestructures USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict oMC6hPI1waDveabvKOXybbJEA9c5g708J0HV68CyZqDDb275qJhOLqn5MhcdBOB

