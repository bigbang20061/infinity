--
-- PostgreSQL database dump
--

\restrict clBi0CwhbkYHUvxMHGGxa6PpBTnl1pk8lFvJxhEp6Y0z6wzZQg4x5h2PaucT2mu

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: groups; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.groups (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: groups; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.groups (row_no, key, data) FROM stdin;
0	0	{"_key": 0, "groupID": 0, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 0, "groupNameID": 63576, "useBasePrice": 0, "fittableNonSingleton": 0}
1	1	{"_key": 1, "groupID": 1, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 1, "groupNameID": 63577, "useBasePrice": 0, "fittableNonSingleton": 0}
2	2	{"_key": 2, "groupID": 2, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 1, "groupNameID": 63578, "useBasePrice": 0, "fittableNonSingleton": 0}
3	3	{"_key": 3, "groupID": 3, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63579, "useBasePrice": 0, "fittableNonSingleton": 0}
4	4	{"_key": 4, "groupID": 4, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63580, "useBasePrice": 0, "fittableNonSingleton": 0}
5	5	{"_key": 5, "groupID": 5, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63581, "useBasePrice": 0, "fittableNonSingleton": 0}
6	6	{"_key": 6, "groupID": 6, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63582, "useBasePrice": 0, "fittableNonSingleton": 0}
7	7	{"_key": 7, "groupID": 7, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63583, "useBasePrice": 0, "fittableNonSingleton": 0}
8	8	{"_key": 8, "groupID": 8, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63584, "useBasePrice": 0, "fittableNonSingleton": 0}
9	9	{"_key": 9, "iconID": 15, "groupID": 9, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63585, "useBasePrice": 0, "fittableNonSingleton": 0}
10	10	{"_key": 10, "groupID": 10, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63586, "useBasePrice": 0, "fittableNonSingleton": 0}
11	11	{"_key": 11, "iconID": 15, "groupID": 11, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63587, "useBasePrice": 0, "fittableNonSingleton": 0}
12	12	{"_key": 12, "iconID": 16, "groupID": 12, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2, "groupNameID": 64289, "useBasePrice": 1, "fittableNonSingleton": 0}
13	13	{"_key": 13, "iconID": 0, "groupID": 13, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63588, "useBasePrice": 0, "fittableNonSingleton": 0}
14	14	{"_key": 14, "iconID": 0, "groupID": 14, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2, "groupNameID": 63589, "useBasePrice": 0, "fittableNonSingleton": 0}
15	15	{"_key": 15, "groupID": 15, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 3, "groupNameID": 63590, "useBasePrice": 0, "fittableNonSingleton": 0}
16	16	{"_key": 16, "groupID": 16, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 3, "groupNameID": 63591, "useBasePrice": 0, "fittableNonSingleton": 0}
17	17	{"_key": 17, "iconID": 21, "groupID": 17, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 4, "groupNameID": 63592, "useBasePrice": 0, "fittableNonSingleton": 0}
18	18	{"_key": 18, "iconID": 22, "groupID": 18, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 4, "groupNameID": 63593, "useBasePrice": 1, "fittableNonSingleton": 0}
19	19	{"_key": 19, "groupID": 19, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 1, "groupNameID": 63594, "useBasePrice": 0, "fittableNonSingleton": 0}
20	20	{"_key": 20, "iconID": 31, "groupID": 20, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 4, "groupNameID": 63595, "useBasePrice": 0, "fittableNonSingleton": 0}
21	23	{"_key": 23, "iconID": 34, "groupID": 23, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 5, "groupNameID": 64284, "useBasePrice": 1, "fittableNonSingleton": 0}
22	24	{"_key": 24, "groupID": 24, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 5, "groupNameID": 63596, "useBasePrice": 0, "fittableNonSingleton": 0}
23	25	{"_key": 25, "groupID": 25, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63597, "useBasePrice": 0, "fittableNonSingleton": 0}
24	26	{"_key": 26, "groupID": 26, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63598, "useBasePrice": 0, "fittableNonSingleton": 0}
25	27	{"_key": 27, "groupID": 27, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63599, "useBasePrice": 0, "fittableNonSingleton": 0}
26	28	{"_key": 28, "groupID": 28, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63600, "useBasePrice": 0, "fittableNonSingleton": 0}
27	29	{"_key": 29, "iconID": 73, "groupID": 29, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63601, "useBasePrice": 0, "fittableNonSingleton": 0}
28	30	{"_key": 30, "groupID": 30, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63602, "useBasePrice": 0, "fittableNonSingleton": 0}
29	31	{"_key": 31, "iconID": 0, "groupID": 31, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63603, "useBasePrice": 0, "fittableNonSingleton": 0}
30	32	{"_key": 32, "groupID": 32, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 1, "groupNameID": 63604, "useBasePrice": 0, "fittableNonSingleton": 0}
31	38	{"_key": 38, "iconID": 82, "groupID": 38, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63605, "useBasePrice": 0, "fittableNonSingleton": 0}
32	39	{"_key": 39, "iconID": 26451, "groupID": 39, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63606, "useBasePrice": 0, "fittableNonSingleton": 0}
33	40	{"_key": 40, "iconID": 84, "groupID": 40, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63607, "useBasePrice": 0, "fittableNonSingleton": 0}
34	41	{"_key": 41, "iconID": 86, "groupID": 41, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63608, "useBasePrice": 0, "fittableNonSingleton": 0}
35	43	{"_key": 43, "iconID": 26457, "groupID": 43, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63609, "useBasePrice": 0, "fittableNonSingleton": 0}
36	46	{"_key": 46, "iconID": 96, "groupID": 46, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63610, "useBasePrice": 0, "fittableNonSingleton": 0}
37	47	{"_key": 47, "iconID": 106, "groupID": 47, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63611, "useBasePrice": 0, "fittableNonSingleton": 0}
38	48	{"_key": 48, "iconID": 107, "groupID": 48, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63612, "useBasePrice": 0, "fittableNonSingleton": 0}
39	49	{"_key": 49, "iconID": 107, "groupID": 49, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63613, "useBasePrice": 0, "fittableNonSingleton": 0}
40	52	{"_key": 52, "iconID": 111, "groupID": 52, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63614, "useBasePrice": 0, "fittableNonSingleton": 0}
41	53	{"_key": 53, "iconID": 355, "groupID": 53, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63615, "useBasePrice": 0, "fittableNonSingleton": 0}
42	54	{"_key": 54, "iconID": 138, "groupID": 54, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63616, "useBasePrice": 0, "fittableNonSingleton": 0}
43	55	{"_key": 55, "iconID": 384, "groupID": 55, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63617, "useBasePrice": 0, "fittableNonSingleton": 0}
44	56	{"_key": 56, "iconID": 168, "groupID": 56, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 63618, "useBasePrice": 0, "fittableNonSingleton": 0}
45	57	{"_key": 57, "iconID": 26450, "groupID": 57, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63619, "useBasePrice": 0, "fittableNonSingleton": 0}
46	59	{"_key": 59, "iconID": 26452, "groupID": 59, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63620, "useBasePrice": 0, "fittableNonSingleton": 0}
47	60	{"_key": 60, "iconID": 0, "groupID": 60, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63621, "useBasePrice": 0, "fittableNonSingleton": 0}
48	61	{"_key": 61, "iconID": 0, "groupID": 61, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63622, "useBasePrice": 0, "fittableNonSingleton": 0}
49	62	{"_key": 62, "iconID": 0, "groupID": 62, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63623, "useBasePrice": 1, "fittableNonSingleton": 0}
50	63	{"_key": 63, "iconID": 0, "groupID": 63, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63624, "useBasePrice": 0, "fittableNonSingleton": 0}
51	65	{"_key": 65, "iconID": 0, "groupID": 65, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63625, "useBasePrice": 0, "fittableNonSingleton": 0}
52	67	{"_key": 67, "iconID": 0, "groupID": 67, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63626, "useBasePrice": 0, "fittableNonSingleton": 0}
53	68	{"_key": 68, "iconID": 0, "groupID": 68, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63627, "useBasePrice": 0, "fittableNonSingleton": 0}
54	71	{"_key": 71, "iconID": 0, "groupID": 71, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63628, "useBasePrice": 0, "fittableNonSingleton": 0}
55	72	{"_key": 72, "iconID": 0, "groupID": 72, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63629, "useBasePrice": 0, "fittableNonSingleton": 0}
56	74	{"_key": 74, "iconID": 370, "groupID": 74, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63630, "useBasePrice": 0, "fittableNonSingleton": 0}
57	76	{"_key": 76, "iconID": 1031, "groupID": 76, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63631, "useBasePrice": 0, "fittableNonSingleton": 0}
58	77	{"_key": 77, "iconID": 0, "groupID": 77, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63632, "useBasePrice": 0, "fittableNonSingleton": 0}
59	78	{"_key": 78, "iconID": 0, "groupID": 78, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63633, "useBasePrice": 0, "fittableNonSingleton": 0}
60	80	{"_key": 80, "iconID": 0, "groupID": 80, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63634, "useBasePrice": 0, "fittableNonSingleton": 0}
61	82	{"_key": 82, "iconID": 0, "groupID": 82, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63635, "useBasePrice": 0, "fittableNonSingleton": 0}
62	83	{"_key": 83, "iconID": 1296, "groupID": 83, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64402, "useBasePrice": 0, "fittableNonSingleton": 1}
63	85	{"_key": 85, "iconID": 1325, "groupID": 85, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63637, "useBasePrice": 0, "fittableNonSingleton": 1}
64	86	{"_key": 86, "iconID": 1142, "groupID": 86, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63638, "useBasePrice": 0, "fittableNonSingleton": 1}
65	87	{"_key": 87, "iconID": 1033, "groupID": 87, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63639, "useBasePrice": 0, "fittableNonSingleton": 1}
66	88	{"_key": 88, "iconID": 192, "groupID": 88, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63640, "useBasePrice": 0, "fittableNonSingleton": 1}
67	89	{"_key": 89, "iconID": 1349, "groupID": 89, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63641, "useBasePrice": 0, "fittableNonSingleton": 1}
68	90	{"_key": 90, "iconID": 3278, "groupID": 90, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63642, "useBasePrice": 0, "fittableNonSingleton": 1}
69	92	{"_key": 92, "iconID": 0, "groupID": 92, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 8, "groupNameID": 63643, "useBasePrice": 0, "fittableNonSingleton": 0}
70	94	{"_key": 94, "groupID": 94, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 10, "groupNameID": 63644, "useBasePrice": 0, "fittableNonSingleton": 0}
71	95	{"_key": 95, "groupID": 95, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 10, "groupNameID": 63645, "useBasePrice": 0, "fittableNonSingleton": 0}
72	96	{"_key": 96, "iconID": 0, "groupID": 96, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63646, "useBasePrice": 0, "fittableNonSingleton": 0}
73	97	{"_key": 97, "iconID": 0, "groupID": 97, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 18, "groupNameID": 63647, "useBasePrice": 0, "fittableNonSingleton": 0}
74	98	{"_key": 98, "iconID": 0, "groupID": 98, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63648, "useBasePrice": 0, "fittableNonSingleton": 0}
75	99	{"_key": 99, "iconID": 0, "groupID": 99, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63649, "useBasePrice": 0, "fittableNonSingleton": 0}
76	100	{"_key": 100, "iconID": 0, "groupID": 100, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 18, "groupNameID": 63650, "useBasePrice": 0, "fittableNonSingleton": 0}
77	101	{"_key": 101, "iconID": 0, "groupID": 101, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 18, "groupNameID": 63651, "useBasePrice": 0, "fittableNonSingleton": 0}
78	104	{"_key": 104, "iconID": 34, "groupID": 104, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63652, "useBasePrice": 1, "fittableNonSingleton": 0}
79	105	{"_key": 105, "groupID": 105, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63653, "useBasePrice": 1, "fittableNonSingleton": 0}
80	106	{"_key": 106, "groupID": 106, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63654, "useBasePrice": 1, "fittableNonSingleton": 0}
81	107	{"_key": 107, "groupID": 107, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63655, "useBasePrice": 1, "fittableNonSingleton": 0}
82	108	{"_key": 108, "groupID": 108, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63656, "useBasePrice": 1, "fittableNonSingleton": 0}
83	109	{"_key": 109, "iconID": 73, "groupID": 109, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63657, "useBasePrice": 1, "fittableNonSingleton": 0}
84	110	{"_key": 110, "groupID": 110, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63658, "useBasePrice": 1, "fittableNonSingleton": 0}
85	111	{"_key": 111, "iconID": 0, "groupID": 111, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63659, "useBasePrice": 1, "fittableNonSingleton": 0}
86	118	{"_key": 118, "iconID": 82, "groupID": 118, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63660, "useBasePrice": 1, "fittableNonSingleton": 0}
87	119	{"_key": 119, "iconID": 26451, "groupID": 119, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63661, "useBasePrice": 1, "fittableNonSingleton": 0}
88	120	{"_key": 120, "iconID": 84, "groupID": 120, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63662, "useBasePrice": 1, "fittableNonSingleton": 0}
89	121	{"_key": 121, "iconID": 86, "groupID": 121, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63663, "useBasePrice": 1, "fittableNonSingleton": 0}
90	123	{"_key": 123, "iconID": 26457, "groupID": 123, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63664, "useBasePrice": 1, "fittableNonSingleton": 0}
91	126	{"_key": 126, "iconID": 96, "groupID": 126, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63665, "useBasePrice": 1, "fittableNonSingleton": 0}
92	127	{"_key": 127, "iconID": 106, "groupID": 127, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63666, "useBasePrice": 1, "fittableNonSingleton": 0}
93	128	{"_key": 128, "iconID": 107, "groupID": 128, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63667, "useBasePrice": 1, "fittableNonSingleton": 0}
94	129	{"_key": 129, "iconID": 107, "groupID": 129, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63668, "useBasePrice": 1, "fittableNonSingleton": 0}
95	130	{"_key": 130, "iconID": 109, "groupID": 130, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63669, "useBasePrice": 1, "fittableNonSingleton": 0}
96	131	{"_key": 131, "iconID": 110, "groupID": 131, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63670, "useBasePrice": 1, "fittableNonSingleton": 0}
97	132	{"_key": 132, "iconID": 111, "groupID": 132, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63671, "useBasePrice": 1, "fittableNonSingleton": 0}
98	133	{"_key": 133, "groupID": 133, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63672, "useBasePrice": 1, "fittableNonSingleton": 0}
99	134	{"_key": 134, "iconID": 138, "groupID": 134, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63673, "useBasePrice": 1, "fittableNonSingleton": 0}
100	135	{"_key": 135, "groupID": 135, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63674, "useBasePrice": 1, "fittableNonSingleton": 0}
101	136	{"_key": 136, "iconID": 168, "groupID": 136, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63675, "useBasePrice": 1, "fittableNonSingleton": 0}
102	137	{"_key": 137, "iconID": 0, "groupID": 137, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63676, "useBasePrice": 1, "fittableNonSingleton": 0}
103	139	{"_key": 139, "iconID": 0, "groupID": 139, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63677, "useBasePrice": 1, "fittableNonSingleton": 0}
104	140	{"_key": 140, "iconID": 0, "groupID": 140, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63678, "useBasePrice": 1, "fittableNonSingleton": 0}
105	141	{"_key": 141, "iconID": 0, "groupID": 141, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63679, "useBasePrice": 1, "fittableNonSingleton": 0}
106	142	{"_key": 142, "iconID": 0, "groupID": 142, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63680, "useBasePrice": 1, "fittableNonSingleton": 0}
107	143	{"_key": 143, "iconID": 0, "groupID": 143, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63681, "useBasePrice": 1, "fittableNonSingleton": 0}
108	145	{"_key": 145, "iconID": 0, "groupID": 145, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63682, "useBasePrice": 1, "fittableNonSingleton": 0}
109	147	{"_key": 147, "iconID": 0, "groupID": 147, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63683, "useBasePrice": 1, "fittableNonSingleton": 0}
110	148	{"_key": 148, "iconID": 0, "groupID": 148, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63684, "useBasePrice": 1, "fittableNonSingleton": 0}
111	151	{"_key": 151, "iconID": 0, "groupID": 151, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63685, "useBasePrice": 1, "fittableNonSingleton": 0}
112	152	{"_key": 152, "iconID": 0, "groupID": 152, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63686, "useBasePrice": 1, "fittableNonSingleton": 0}
113	154	{"_key": 154, "iconID": 0, "groupID": 154, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63687, "useBasePrice": 1, "fittableNonSingleton": 0}
114	156	{"_key": 156, "iconID": 0, "groupID": 156, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63688, "useBasePrice": 1, "fittableNonSingleton": 0}
115	157	{"_key": 157, "iconID": 0, "groupID": 157, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63689, "useBasePrice": 1, "fittableNonSingleton": 0}
116	158	{"_key": 158, "iconID": 0, "groupID": 158, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63690, "useBasePrice": 1, "fittableNonSingleton": 0}
117	160	{"_key": 160, "iconID": 0, "groupID": 160, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63691, "useBasePrice": 1, "fittableNonSingleton": 0}
118	161	{"_key": 161, "iconID": 0, "groupID": 161, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63692, "useBasePrice": 1, "fittableNonSingleton": 0}
119	162	{"_key": 162, "iconID": 0, "groupID": 162, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63693, "useBasePrice": 1, "fittableNonSingleton": 0}
120	163	{"_key": 163, "iconID": 0, "groupID": 163, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63694, "useBasePrice": 1, "fittableNonSingleton": 0}
121	165	{"_key": 165, "groupID": 165, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63695, "useBasePrice": 1, "fittableNonSingleton": 0}
122	166	{"_key": 166, "iconID": 182, "groupID": 166, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63696, "useBasePrice": 1, "fittableNonSingleton": 0}
123	167	{"_key": 167, "groupID": 167, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63697, "useBasePrice": 1, "fittableNonSingleton": 0}
124	168	{"_key": 168, "iconID": 0, "groupID": 168, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63698, "useBasePrice": 1, "fittableNonSingleton": 0}
125	169	{"_key": 169, "iconID": 0, "groupID": 169, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63699, "useBasePrice": 1, "fittableNonSingleton": 0}
126	170	{"_key": 170, "iconID": 0, "groupID": 170, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63700, "useBasePrice": 1, "fittableNonSingleton": 0}
127	172	{"_key": 172, "iconID": 0, "groupID": 172, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63701, "useBasePrice": 1, "fittableNonSingleton": 0}
128	174	{"_key": 174, "iconID": 0, "groupID": 174, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63702, "useBasePrice": 1, "fittableNonSingleton": 0}
129	175	{"_key": 175, "iconID": 0, "groupID": 175, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63703, "useBasePrice": 1, "fittableNonSingleton": 0}
130	176	{"_key": 176, "iconID": 0, "groupID": 176, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63704, "useBasePrice": 1, "fittableNonSingleton": 0}
131	177	{"_key": 177, "iconID": 0, "groupID": 177, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63705, "useBasePrice": 1, "fittableNonSingleton": 0}
132	178	{"_key": 178, "iconID": 21, "groupID": 178, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63706, "useBasePrice": 1, "fittableNonSingleton": 0}
133	180	{"_key": 180, "groupID": 180, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63707, "useBasePrice": 0, "fittableNonSingleton": 0}
134	182	{"_key": 182, "groupID": 182, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63708, "useBasePrice": 0, "fittableNonSingleton": 0}
135	185	{"_key": 185, "iconID": 0, "groupID": 185, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63709, "useBasePrice": 0, "fittableNonSingleton": 0}
136	186	{"_key": 186, "iconID": 0, "groupID": 186, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63710, "useBasePrice": 0, "fittableNonSingleton": 0}
137	190	{"_key": 190, "iconID": 0, "groupID": 190, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 14, "groupNameID": 63711, "useBasePrice": 0, "fittableNonSingleton": 0}
138	191	{"_key": 191, "iconID": 0, "groupID": 191, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 14, "groupNameID": 63712, "useBasePrice": 0, "fittableNonSingleton": 0}
139	192	{"_key": 192, "iconID": 0, "groupID": 192, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 14, "groupNameID": 63713, "useBasePrice": 0, "fittableNonSingleton": 0}
140	193	{"_key": 193, "iconID": 0, "groupID": 193, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 14, "groupNameID": 63714, "useBasePrice": 0, "fittableNonSingleton": 0}
141	194	{"_key": 194, "iconID": 0, "groupID": 194, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 14, "groupNameID": 63715, "useBasePrice": 0, "fittableNonSingleton": 0}
142	195	{"_key": 195, "iconID": 0, "groupID": 195, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 14, "groupNameID": 63716, "useBasePrice": 0, "fittableNonSingleton": 0}
143	196	{"_key": 196, "iconID": 0, "groupID": 196, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 14, "groupNameID": 63717, "useBasePrice": 0, "fittableNonSingleton": 0}
144	197	{"_key": 197, "iconID": 0, "groupID": 197, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 14, "groupNameID": 63718, "useBasePrice": 0, "fittableNonSingleton": 0}
145	198	{"_key": 198, "iconID": 0, "groupID": 198, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 14, "groupNameID": 63719, "useBasePrice": 0, "fittableNonSingleton": 0}
146	199	{"_key": 199, "iconID": 0, "groupID": 199, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 14, "groupNameID": 63720, "useBasePrice": 0, "fittableNonSingleton": 0}
147	201	{"_key": 201, "iconID": 0, "groupID": 201, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63721, "useBasePrice": 0, "fittableNonSingleton": 0}
148	202	{"_key": 202, "iconID": 0, "groupID": 202, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63722, "useBasePrice": 0, "fittableNonSingleton": 0}
149	203	{"_key": 203, "iconID": 0, "groupID": 203, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63723, "useBasePrice": 0, "fittableNonSingleton": 0}
150	205	{"_key": 205, "iconID": 26453, "groupID": 205, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63724, "useBasePrice": 0, "fittableNonSingleton": 0}
151	208	{"_key": 208, "iconID": 105, "groupID": 208, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63725, "useBasePrice": 0, "fittableNonSingleton": 0}
152	209	{"_key": 209, "iconID": 3346, "groupID": 209, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63726, "useBasePrice": 0, "fittableNonSingleton": 0}
153	210	{"_key": 210, "iconID": 0, "groupID": 210, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63727, "useBasePrice": 0, "fittableNonSingleton": 0}
154	211	{"_key": 211, "iconID": 0, "groupID": 211, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63728, "useBasePrice": 0, "fittableNonSingleton": 0}
155	212	{"_key": 212, "iconID": 74, "groupID": 212, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63729, "useBasePrice": 0, "fittableNonSingleton": 0}
156	213	{"_key": 213, "iconID": 3346, "groupID": 213, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63730, "useBasePrice": 0, "fittableNonSingleton": 0}
157	218	{"_key": 218, "iconID": 26453, "groupID": 218, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63731, "useBasePrice": 1, "fittableNonSingleton": 0}
158	223	{"_key": 223, "iconID": 0, "groupID": 223, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63732, "useBasePrice": 1, "fittableNonSingleton": 0}
159	224	{"_key": 224, "iconID": 0, "groupID": 224, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63733, "useBasePrice": 1, "fittableNonSingleton": 0}
160	225	{"_key": 225, "iconID": 0, "groupID": 225, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 63734, "useBasePrice": 0, "fittableNonSingleton": 0}
161	226	{"_key": 226, "groupID": 226, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63735, "useBasePrice": 0, "fittableNonSingleton": 0}
162	227	{"_key": 227, "iconID": 0, "groupID": 227, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63736, "useBasePrice": 0, "fittableNonSingleton": 0}
163	237	{"_key": 237, "iconID": 0, "groupID": 237, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63737, "useBasePrice": 0, "fittableNonSingleton": 0}
164	255	{"_key": 255, "groupID": 255, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 63738, "useBasePrice": 1, "fittableNonSingleton": 0}
165	256	{"_key": 256, "groupID": 256, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 63739, "useBasePrice": 1, "fittableNonSingleton": 0}
166	257	{"_key": 257, "groupID": 257, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 63740, "useBasePrice": 1, "fittableNonSingleton": 0}
167	258	{"_key": 258, "groupID": 258, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 63741, "useBasePrice": 1, "fittableNonSingleton": 0}
168	266	{"_key": 266, "groupID": 266, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 63742, "useBasePrice": 1, "fittableNonSingleton": 0}
169	267	{"_key": 267, "groupID": 267, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 17, "groupNameID": 64401, "useBasePrice": 1, "fittableNonSingleton": 0}
170	268	{"_key": 268, "groupID": 268, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 63743, "useBasePrice": 1, "fittableNonSingleton": 0}
171	269	{"_key": 269, "groupID": 269, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 64437, "useBasePrice": 1, "fittableNonSingleton": 0}
172	270	{"_key": 270, "groupID": 270, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 63744, "useBasePrice": 1, "fittableNonSingleton": 0}
173	272	{"_key": 272, "groupID": 272, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 63746, "useBasePrice": 1, "fittableNonSingleton": 0}
174	273	{"_key": 273, "groupID": 273, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 63747, "useBasePrice": 1, "fittableNonSingleton": 0}
175	274	{"_key": 274, "groupID": 274, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 63748, "useBasePrice": 1, "fittableNonSingleton": 0}
176	275	{"_key": 275, "groupID": 275, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 63749, "useBasePrice": 1, "fittableNonSingleton": 0}
177	278	{"_key": 278, "groupID": 278, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 63750, "useBasePrice": 1, "fittableNonSingleton": 0}
178	279	{"_key": 279, "iconID": 0, "groupID": 279, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63751, "useBasePrice": 0, "fittableNonSingleton": 0}
179	280	{"_key": 280, "iconID": 0, "groupID": 280, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63752, "useBasePrice": 1, "fittableNonSingleton": 0}
180	281	{"_key": 281, "iconID": 0, "groupID": 281, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63753, "useBasePrice": 1, "fittableNonSingleton": 0}
181	282	{"_key": 282, "iconID": 0, "groupID": 282, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63754, "useBasePrice": 1, "fittableNonSingleton": 0}
182	283	{"_key": 283, "iconID": 0, "groupID": 283, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63755, "useBasePrice": 1, "fittableNonSingleton": 0}
183	284	{"_key": 284, "iconID": 0, "groupID": 284, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63756, "useBasePrice": 1, "fittableNonSingleton": 0}
184	285	{"_key": 285, "iconID": 0, "groupID": 285, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63757, "useBasePrice": 0, "fittableNonSingleton": 0}
185	286	{"_key": 286, "iconID": 0, "groupID": 286, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63758, "useBasePrice": 0, "fittableNonSingleton": 0}
186	287	{"_key": 287, "groupID": 287, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63759, "useBasePrice": 0, "fittableNonSingleton": 0}
187	288	{"_key": 288, "iconID": 0, "groupID": 288, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63760, "useBasePrice": 0, "fittableNonSingleton": 0}
188	289	{"_key": 289, "groupID": 289, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63761, "useBasePrice": 0, "fittableNonSingleton": 0}
189	290	{"_key": 290, "iconID": 74, "groupID": 290, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63762, "useBasePrice": 0, "fittableNonSingleton": 0}
190	291	{"_key": 291, "iconID": 1639, "groupID": 291, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64295, "useBasePrice": 0, "fittableNonSingleton": 0}
191	295	{"_key": 295, "iconID": 82, "groupID": 295, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63763, "useBasePrice": 0, "fittableNonSingleton": 0}
192	296	{"_key": 296, "iconID": 82, "groupID": 296, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63764, "useBasePrice": 1, "fittableNonSingleton": 0}
193	297	{"_key": 297, "iconID": 0, "groupID": 297, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63765, "useBasePrice": 0, "fittableNonSingleton": 0}
194	298	{"_key": 298, "iconID": 0, "groupID": 298, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63766, "useBasePrice": 0, "fittableNonSingleton": 0}
195	299	{"_key": 299, "iconID": 0, "groupID": 299, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 18, "groupNameID": 64344, "useBasePrice": 0, "fittableNonSingleton": 0}
196	300	{"_key": 300, "iconID": 0, "groupID": 300, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 63767, "useBasePrice": 1, "fittableNonSingleton": 0}
197	301	{"_key": 301, "iconID": 0, "groupID": 301, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63768, "useBasePrice": 0, "fittableNonSingleton": 0}
198	302	{"_key": 302, "iconID": 26454, "groupID": 302, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63769, "useBasePrice": 0, "fittableNonSingleton": 0}
199	303	{"_key": 303, "iconID": 0, "groupID": 303, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 63770, "useBasePrice": 0, "fittableNonSingleton": 0}
200	304	{"_key": 304, "iconID": 0, "groupID": 304, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 20, "groupNameID": 63771, "useBasePrice": 0, "fittableNonSingleton": 0}
201	305	{"_key": 305, "iconID": 0, "groupID": 305, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63772, "useBasePrice": 0, "fittableNonSingleton": 0}
202	306	{"_key": 306, "iconID": 0, "groupID": 306, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63773, "useBasePrice": 0, "fittableNonSingleton": 0}
203	307	{"_key": 307, "iconID": 0, "groupID": 307, "anchored": 0, "published": 1, "anchorable": 1, "categoryID": 2, "groupNameID": 63774, "useBasePrice": 0, "fittableNonSingleton": 0}
204	308	{"_key": 308, "iconID": 0, "groupID": 308, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 63775, "useBasePrice": 0, "fittableNonSingleton": 0}
205	309	{"_key": 309, "iconID": 0, "groupID": 309, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 63776, "useBasePrice": 0, "fittableNonSingleton": 0}
206	310	{"_key": 310, "iconID": 0, "groupID": 310, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63777, "useBasePrice": 0, "fittableNonSingleton": 0}
207	311	{"_key": 311, "iconID": 0, "groupID": 311, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63778, "useBasePrice": 1, "fittableNonSingleton": 0}
208	312	{"_key": 312, "iconID": 0, "groupID": 312, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63779, "useBasePrice": 0, "fittableNonSingleton": 0}
209	313	{"_key": 313, "iconID": 0, "groupID": 313, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63780, "useBasePrice": 1, "fittableNonSingleton": 0}
210	314	{"_key": 314, "iconID": 0, "groupID": 314, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63781, "useBasePrice": 1, "fittableNonSingleton": 0}
211	315	{"_key": 315, "iconID": 0, "groupID": 315, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63782, "useBasePrice": 0, "fittableNonSingleton": 0}
212	316	{"_key": 316, "iconID": 0, "groupID": 316, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 63783, "useBasePrice": 0, "fittableNonSingleton": 0}
213	317	{"_key": 317, "iconID": 0, "groupID": 317, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 63784, "useBasePrice": 0, "fittableNonSingleton": 0}
214	318	{"_key": 318, "iconID": 0, "groupID": 318, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63785, "useBasePrice": 0, "fittableNonSingleton": 0}
215	319	{"_key": 319, "iconID": 0, "groupID": 319, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63786, "useBasePrice": 0, "fittableNonSingleton": 0}
216	321	{"_key": 321, "iconID": 0, "groupID": 321, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63787, "useBasePrice": 0, "fittableNonSingleton": 0}
217	323	{"_key": 323, "iconID": 0, "groupID": 323, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63788, "useBasePrice": 0, "fittableNonSingleton": 0}
218	324	{"_key": 324, "iconID": 0, "groupID": 324, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63789, "useBasePrice": 0, "fittableNonSingleton": 0}
219	325	{"_key": 325, "iconID": 0, "groupID": 325, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63790, "useBasePrice": 0, "fittableNonSingleton": 0}
220	326	{"_key": 326, "iconID": 0, "groupID": 326, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63791, "useBasePrice": 0, "fittableNonSingleton": 0}
221	328	{"_key": 328, "iconID": 0, "groupID": 328, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63792, "useBasePrice": 0, "fittableNonSingleton": 0}
222	329	{"_key": 329, "iconID": 0, "groupID": 329, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63793, "useBasePrice": 0, "fittableNonSingleton": 0}
223	330	{"_key": 330, "iconID": 0, "groupID": 330, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63794, "useBasePrice": 0, "fittableNonSingleton": 0}
224	332	{"_key": 332, "iconID": 0, "groupID": 332, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63795, "useBasePrice": 0, "fittableNonSingleton": 0}
225	333	{"_key": 333, "iconID": 0, "groupID": 333, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63796, "useBasePrice": 0, "fittableNonSingleton": 0}
226	334	{"_key": 334, "iconID": 0, "groupID": 334, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63797, "useBasePrice": 0, "fittableNonSingleton": 0}
227	335	{"_key": 335, "iconID": 0, "groupID": 335, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63798, "useBasePrice": 0, "fittableNonSingleton": 0}
228	336	{"_key": 336, "iconID": 0, "groupID": 336, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 2, "groupNameID": 63799, "useBasePrice": 0, "fittableNonSingleton": 0}
229	337	{"_key": 337, "iconID": 0, "groupID": 337, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63800, "useBasePrice": 0, "fittableNonSingleton": 0}
230	338	{"_key": 338, "iconID": 0, "groupID": 338, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63801, "useBasePrice": 0, "fittableNonSingleton": 0}
231	339	{"_key": 339, "iconID": 0, "groupID": 339, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63802, "useBasePrice": 0, "fittableNonSingleton": 0}
232	340	{"_key": 340, "iconID": 0, "groupID": 340, "anchored": 0, "published": 1, "anchorable": 1, "categoryID": 2, "groupNameID": 64288, "useBasePrice": 1, "fittableNonSingleton": 0}
233	341	{"_key": 341, "iconID": 0, "groupID": 341, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 63803, "useBasePrice": 0, "fittableNonSingleton": 0}
234	342	{"_key": 342, "iconID": 0, "groupID": 342, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63804, "useBasePrice": 1, "fittableNonSingleton": 0}
235	343	{"_key": 343, "iconID": 0, "groupID": 343, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63805, "useBasePrice": 1, "fittableNonSingleton": 0}
236	344	{"_key": 344, "iconID": 0, "groupID": 344, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63806, "useBasePrice": 1, "fittableNonSingleton": 0}
237	345	{"_key": 345, "iconID": 0, "groupID": 345, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63807, "useBasePrice": 1, "fittableNonSingleton": 0}
238	346	{"_key": 346, "iconID": 0, "groupID": 346, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63808, "useBasePrice": 1, "fittableNonSingleton": 0}
239	347	{"_key": 347, "iconID": 0, "groupID": 347, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63809, "useBasePrice": 1, "fittableNonSingleton": 0}
240	348	{"_key": 348, "iconID": 0, "groupID": 348, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63810, "useBasePrice": 1, "fittableNonSingleton": 0}
241	349	{"_key": 349, "iconID": 0, "groupID": 349, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63811, "useBasePrice": 1, "fittableNonSingleton": 0}
242	350	{"_key": 350, "iconID": 0, "groupID": 350, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63812, "useBasePrice": 1, "fittableNonSingleton": 0}
243	352	{"_key": 352, "iconID": 0, "groupID": 352, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63813, "useBasePrice": 1, "fittableNonSingleton": 0}
244	353	{"_key": 353, "iconID": 0, "groupID": 353, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 63814, "useBasePrice": 0, "fittableNonSingleton": 0}
245	355	{"_key": 355, "iconID": 0, "groupID": 355, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63815, "useBasePrice": 0, "fittableNonSingleton": 0}
246	356	{"_key": 356, "iconID": 0, "groupID": 356, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63816, "useBasePrice": 1, "fittableNonSingleton": 0}
247	357	{"_key": 357, "iconID": 0, "groupID": 357, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 63817, "useBasePrice": 0, "fittableNonSingleton": 0}
248	358	{"_key": 358, "iconID": 0, "groupID": 358, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63818, "useBasePrice": 0, "fittableNonSingleton": 0}
249	360	{"_key": 360, "iconID": 0, "groupID": 360, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63819, "useBasePrice": 1, "fittableNonSingleton": 0}
250	361	{"_key": 361, "iconID": 0, "groupID": 361, "anchored": 0, "published": 1, "anchorable": 1, "categoryID": 22, "groupNameID": 63820, "useBasePrice": 0, "fittableNonSingleton": 0}
251	363	{"_key": 363, "iconID": 0, "groupID": 363, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63821, "useBasePrice": 1, "fittableNonSingleton": 0}
252	364	{"_key": 364, "iconID": 0, "groupID": 364, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63822, "useBasePrice": 0, "fittableNonSingleton": 0}
253	365	{"_key": 365, "iconID": 0, "groupID": 365, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63823, "useBasePrice": 1, "fittableNonSingleton": 0}
254	366	{"_key": 366, "iconID": 0, "groupID": 366, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63824, "useBasePrice": 0, "fittableNonSingleton": 0}
255	367	{"_key": 367, "iconID": 0, "groupID": 367, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63825, "useBasePrice": 0, "fittableNonSingleton": 0}
256	368	{"_key": 368, "iconID": 0, "groupID": 368, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63826, "useBasePrice": 0, "fittableNonSingleton": 0}
257	369	{"_key": 369, "iconID": 0, "groupID": 369, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63827, "useBasePrice": 1, "fittableNonSingleton": 0}
258	370	{"_key": 370, "iconID": 0, "groupID": 370, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63828, "useBasePrice": 1, "fittableNonSingleton": 0}
259	371	{"_key": 371, "iconID": 0, "groupID": 371, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63829, "useBasePrice": 1, "fittableNonSingleton": 0}
260	372	{"_key": 372, "iconID": 1296, "groupID": 372, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63830, "useBasePrice": 0, "fittableNonSingleton": 1}
261	373	{"_key": 373, "iconID": 1321, "groupID": 373, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63831, "useBasePrice": 0, "fittableNonSingleton": 1}
262	374	{"_key": 374, "iconID": 1145, "groupID": 374, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63832, "useBasePrice": 0, "fittableNonSingleton": 1}
263	375	{"_key": 375, "iconID": 1140, "groupID": 375, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63833, "useBasePrice": 0, "fittableNonSingleton": 1}
264	376	{"_key": 376, "iconID": 1292, "groupID": 376, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63834, "useBasePrice": 0, "fittableNonSingleton": 1}
265	377	{"_key": 377, "iconID": 1317, "groupID": 377, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63835, "useBasePrice": 0, "fittableNonSingleton": 1}
266	378	{"_key": 378, "iconID": 0, "groupID": 378, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 63836, "useBasePrice": 0, "fittableNonSingleton": 0}
267	379	{"_key": 379, "iconID": 0, "groupID": 379, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63837, "useBasePrice": 0, "fittableNonSingleton": 0}
268	380	{"_key": 380, "iconID": 0, "groupID": 380, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63838, "useBasePrice": 0, "fittableNonSingleton": 0}
269	381	{"_key": 381, "iconID": 0, "groupID": 381, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 6, "groupNameID": 63839, "useBasePrice": 1, "fittableNonSingleton": 0}
270	382	{"_key": 382, "iconID": 0, "groupID": 382, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63840, "useBasePrice": 0, "fittableNonSingleton": 0}
271	383	{"_key": 383, "iconID": 0, "groupID": 383, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63841, "useBasePrice": 0, "fittableNonSingleton": 0}
272	384	{"_key": 384, "iconID": 192, "groupID": 384, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63842, "useBasePrice": 0, "fittableNonSingleton": 1}
273	385	{"_key": 385, "iconID": 188, "groupID": 385, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63843, "useBasePrice": 0, "fittableNonSingleton": 1}
274	386	{"_key": 386, "iconID": 182, "groupID": 386, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63844, "useBasePrice": 0, "fittableNonSingleton": 1}
275	387	{"_key": 387, "iconID": 1352, "groupID": 387, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63845, "useBasePrice": 0, "fittableNonSingleton": 1}
276	394	{"_key": 394, "iconID": 1336, "groupID": 394, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63846, "useBasePrice": 0, "fittableNonSingleton": 1}
277	395	{"_key": 395, "iconID": 1339, "groupID": 395, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63847, "useBasePrice": 0, "fittableNonSingleton": 1}
278	396	{"_key": 396, "iconID": 1344, "groupID": 396, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63848, "useBasePrice": 0, "fittableNonSingleton": 1}
279	397	{"_key": 397, "iconID": 0, "groupID": 397, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63849, "useBasePrice": 1, "fittableNonSingleton": 0}
280	400	{"_key": 400, "iconID": 0, "groupID": 400, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63850, "useBasePrice": 1, "fittableNonSingleton": 0}
281	401	{"_key": 401, "iconID": 0, "groupID": 401, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63851, "useBasePrice": 1, "fittableNonSingleton": 0}
282	404	{"_key": 404, "iconID": 0, "groupID": 404, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63852, "useBasePrice": 1, "fittableNonSingleton": 0}
283	405	{"_key": 405, "iconID": 0, "groupID": 405, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 63853, "useBasePrice": 0, "fittableNonSingleton": 0}
284	406	{"_key": 406, "iconID": 0, "groupID": 406, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 63854, "useBasePrice": 0, "fittableNonSingleton": 0}
285	407	{"_key": 407, "iconID": 0, "groupID": 407, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63855, "useBasePrice": 0, "fittableNonSingleton": 0}
286	408	{"_key": 408, "iconID": 0, "groupID": 408, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63856, "useBasePrice": 1, "fittableNonSingleton": 0}
287	409	{"_key": 409, "iconID": 0, "groupID": 409, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63857, "useBasePrice": 1, "fittableNonSingleton": 0}
288	410	{"_key": 410, "iconID": 0, "groupID": 410, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 9, "groupNameID": 64334, "useBasePrice": 1, "fittableNonSingleton": 0}
289	411	{"_key": 411, "iconID": 0, "groupID": 411, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63858, "useBasePrice": 0, "fittableNonSingleton": 0}
290	413	{"_key": 413, "iconID": 0, "groupID": 413, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63859, "useBasePrice": 1, "fittableNonSingleton": 0}
291	414	{"_key": 414, "iconID": 0, "groupID": 414, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63860, "useBasePrice": 0, "fittableNonSingleton": 0}
292	416	{"_key": 416, "iconID": 0, "groupID": 416, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63861, "useBasePrice": 1, "fittableNonSingleton": 0}
293	417	{"_key": 417, "iconID": 0, "groupID": 417, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63862, "useBasePrice": 1, "fittableNonSingleton": 0}
294	418	{"_key": 418, "iconID": 0, "groupID": 418, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63863, "useBasePrice": 0, "fittableNonSingleton": 0}
295	419	{"_key": 419, "iconID": 0, "groupID": 419, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63864, "useBasePrice": 0, "fittableNonSingleton": 0}
296	420	{"_key": 420, "iconID": 0, "groupID": 420, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63865, "useBasePrice": 0, "fittableNonSingleton": 0}
297	422	{"_key": 422, "iconID": 0, "groupID": 422, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 4, "groupNameID": 63866, "useBasePrice": 0, "fittableNonSingleton": 0}
298	423	{"_key": 423, "iconID": 0, "groupID": 423, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 4, "groupNameID": 63867, "useBasePrice": 1, "fittableNonSingleton": 0}
299	425	{"_key": 425, "iconID": 0, "groupID": 425, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 8, "groupNameID": 63868, "useBasePrice": 0, "fittableNonSingleton": 1}
300	426	{"_key": 426, "iconID": 0, "groupID": 426, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63869, "useBasePrice": 1, "fittableNonSingleton": 0}
301	427	{"_key": 427, "iconID": 0, "groupID": 427, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 4, "groupNameID": 63870, "useBasePrice": 1, "fittableNonSingleton": 0}
302	428	{"_key": 428, "iconID": 0, "groupID": 428, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 4, "groupNameID": 63871, "useBasePrice": 1, "fittableNonSingleton": 0}
303	429	{"_key": 429, "iconID": 0, "groupID": 429, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 4, "groupNameID": 63872, "useBasePrice": 1, "fittableNonSingleton": 0}
304	430	{"_key": 430, "iconID": 0, "groupID": 430, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63873, "useBasePrice": 1, "fittableNonSingleton": 0}
305	435	{"_key": 435, "iconID": 0, "groupID": 435, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63874, "useBasePrice": 0, "fittableNonSingleton": 0}
306	436	{"_key": 436, "iconID": 2665, "groupID": 436, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 24, "groupNameID": 63875, "useBasePrice": 1, "fittableNonSingleton": 0}
307	438	{"_key": 438, "iconID": 0, "groupID": 438, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63876, "useBasePrice": 1, "fittableNonSingleton": 0}
308	439	{"_key": 439, "iconID": 0, "groupID": 439, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63877, "useBasePrice": 1, "fittableNonSingleton": 0}
309	440	{"_key": 440, "iconID": 0, "groupID": 440, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63878, "useBasePrice": 1, "fittableNonSingleton": 0}
310	441	{"_key": 441, "iconID": 0, "groupID": 441, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63879, "useBasePrice": 1, "fittableNonSingleton": 0}
311	443	{"_key": 443, "iconID": 0, "groupID": 443, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63880, "useBasePrice": 1, "fittableNonSingleton": 0}
312	444	{"_key": 444, "iconID": 0, "groupID": 444, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63881, "useBasePrice": 1, "fittableNonSingleton": 0}
313	445	{"_key": 445, "iconID": 0, "groupID": 445, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63882, "useBasePrice": 1, "fittableNonSingleton": 0}
314	446	{"_key": 446, "iconID": 0, "groupID": 446, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63883, "useBasePrice": 0, "fittableNonSingleton": 0}
315	447	{"_key": 447, "groupID": 447, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63884, "useBasePrice": 1, "fittableNonSingleton": 0}
316	448	{"_key": 448, "groupID": 448, "anchored": 0, "published": 1, "anchorable": 1, "categoryID": 2, "groupNameID": 63885, "useBasePrice": 1, "fittableNonSingleton": 0}
317	449	{"_key": 449, "iconID": 0, "groupID": 449, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63886, "useBasePrice": 1, "fittableNonSingleton": 0}
318	450	{"_key": 450, "iconID": 15, "groupID": 450, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 63887, "useBasePrice": 0, "fittableNonSingleton": 0}
319	451	{"_key": 451, "iconID": 15, "groupID": 451, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 63888, "useBasePrice": 0, "fittableNonSingleton": 0}
320	452	{"_key": 452, "iconID": 15, "groupID": 452, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 63889, "useBasePrice": 0, "fittableNonSingleton": 0}
321	453	{"_key": 453, "iconID": 15, "groupID": 453, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 63890, "useBasePrice": 0, "fittableNonSingleton": 0}
322	454	{"_key": 454, "iconID": 15, "groupID": 454, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 63891, "useBasePrice": 0, "fittableNonSingleton": 0}
323	455	{"_key": 455, "iconID": 15, "groupID": 455, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 63892, "useBasePrice": 0, "fittableNonSingleton": 0}
324	456	{"_key": 456, "iconID": 15, "groupID": 456, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 63893, "useBasePrice": 0, "fittableNonSingleton": 0}
325	457	{"_key": 457, "iconID": 15, "groupID": 457, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 63894, "useBasePrice": 0, "fittableNonSingleton": 0}
326	458	{"_key": 458, "iconID": 15, "groupID": 458, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 63895, "useBasePrice": 0, "fittableNonSingleton": 0}
327	459	{"_key": 459, "iconID": 15, "groupID": 459, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 63896, "useBasePrice": 0, "fittableNonSingleton": 0}
328	460	{"_key": 460, "iconID": 15, "groupID": 460, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 63897, "useBasePrice": 0, "fittableNonSingleton": 0}
329	461	{"_key": 461, "iconID": 15, "groupID": 461, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 63898, "useBasePrice": 0, "fittableNonSingleton": 0}
330	462	{"_key": 462, "iconID": 15, "groupID": 462, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 63899, "useBasePrice": 0, "fittableNonSingleton": 0}
331	463	{"_key": 463, "iconID": 0, "groupID": 463, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63900, "useBasePrice": 0, "fittableNonSingleton": 0}
332	464	{"_key": 464, "iconID": 0, "groupID": 464, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63901, "useBasePrice": 0, "fittableNonSingleton": 0}
333	465	{"_key": 465, "iconID": 15, "groupID": 465, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 63902, "useBasePrice": 0, "fittableNonSingleton": 0}
334	467	{"_key": 467, "iconID": 15, "groupID": 467, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 63903, "useBasePrice": 0, "fittableNonSingleton": 0}
335	468	{"_key": 468, "iconID": 15, "groupID": 468, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 63904, "useBasePrice": 0, "fittableNonSingleton": 0}
336	469	{"_key": 469, "iconID": 15, "groupID": 469, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 63905, "useBasePrice": 0, "fittableNonSingleton": 0}
337	470	{"_key": 470, "iconID": 0, "groupID": 470, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 18, "groupNameID": 63906, "useBasePrice": 0, "fittableNonSingleton": 0}
338	471	{"_key": 471, "iconID": 0, "groupID": 471, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63907, "useBasePrice": 1, "fittableNonSingleton": 0}
339	472	{"_key": 472, "iconID": 0, "groupID": 472, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63908, "useBasePrice": 0, "fittableNonSingleton": 0}
340	473	{"_key": 473, "iconID": 0, "groupID": 473, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63909, "useBasePrice": 1, "fittableNonSingleton": 0}
341	474	{"_key": 474, "iconID": 0, "groupID": 474, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63910, "useBasePrice": 1, "fittableNonSingleton": 0}
342	475	{"_key": 475, "iconID": 96, "groupID": 475, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 63911, "useBasePrice": 0, "fittableNonSingleton": 0}
343	476	{"_key": 476, "iconID": 1349, "groupID": 476, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63912, "useBasePrice": 0, "fittableNonSingleton": 1}
344	477	{"_key": 477, "iconID": 0, "groupID": 477, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63913, "useBasePrice": 1, "fittableNonSingleton": 0}
345	478	{"_key": 478, "iconID": 0, "groupID": 478, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63914, "useBasePrice": 0, "fittableNonSingleton": 0}
346	479	{"_key": 479, "iconID": 2222, "groupID": 479, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63915, "useBasePrice": 0, "fittableNonSingleton": 1}
347	480	{"_key": 480, "iconID": 0, "groupID": 480, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 63916, "useBasePrice": 0, "fittableNonSingleton": 0}
348	481	{"_key": 481, "iconID": 2677, "groupID": 481, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63917, "useBasePrice": 0, "fittableNonSingleton": 0}
349	482	{"_key": 482, "iconID": 24968, "groupID": 482, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63918, "useBasePrice": 0, "fittableNonSingleton": 1}
350	483	{"_key": 483, "iconID": 138, "groupID": 483, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63919, "useBasePrice": 0, "fittableNonSingleton": 0}
351	484	{"_key": 484, "iconID": 2666, "groupID": 484, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 24, "groupNameID": 63920, "useBasePrice": 1, "fittableNonSingleton": 0}
352	485	{"_key": 485, "iconID": 0, "groupID": 485, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63921, "useBasePrice": 0, "fittableNonSingleton": 0}
353	486	{"_key": 486, "iconID": 0, "groupID": 486, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63922, "useBasePrice": 1, "fittableNonSingleton": 0}
354	487	{"_key": 487, "iconID": 0, "groupID": 487, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63923, "useBasePrice": 1, "fittableNonSingleton": 0}
355	489	{"_key": 489, "iconID": 0, "groupID": 489, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63924, "useBasePrice": 1, "fittableNonSingleton": 0}
356	490	{"_key": 490, "iconID": 0, "groupID": 490, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63925, "useBasePrice": 1, "fittableNonSingleton": 0}
357	492	{"_key": 492, "iconID": 2663, "groupID": 492, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64298, "useBasePrice": 1, "fittableNonSingleton": 1}
358	493	{"_key": 493, "iconID": 0, "groupID": 493, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63926, "useBasePrice": 1, "fittableNonSingleton": 0}
359	494	{"_key": 494, "iconID": 0, "groupID": 494, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63927, "useBasePrice": 0, "fittableNonSingleton": 0}
360	495	{"_key": 495, "iconID": 0, "groupID": 495, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63928, "useBasePrice": 0, "fittableNonSingleton": 0}
361	496	{"_key": 496, "iconID": 0, "groupID": 496, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63929, "useBasePrice": 0, "fittableNonSingleton": 0}
362	497	{"_key": 497, "iconID": 0, "groupID": 497, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 8, "groupNameID": 63930, "useBasePrice": 0, "fittableNonSingleton": 1}
363	498	{"_key": 498, "iconID": 0, "groupID": 498, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 8, "groupNameID": 63931, "useBasePrice": 0, "fittableNonSingleton": 1}
364	499	{"_key": 499, "iconID": 0, "groupID": 499, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 63932, "useBasePrice": 0, "fittableNonSingleton": 0}
365	500	{"_key": 500, "iconID": 0, "groupID": 500, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 63933, "useBasePrice": 0, "fittableNonSingleton": 1}
366	501	{"_key": 501, "iconID": 0, "groupID": 501, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63934, "useBasePrice": 0, "fittableNonSingleton": 0}
367	502	{"_key": 502, "iconID": 0, "groupID": 502, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63935, "useBasePrice": 0, "fittableNonSingleton": 0}
368	503	{"_key": 503, "iconID": 0, "groupID": 503, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63936, "useBasePrice": 0, "fittableNonSingleton": 0}
369	504	{"_key": 504, "iconID": 0, "groupID": 504, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63937, "useBasePrice": 1, "fittableNonSingleton": 0}
370	505	{"_key": 505, "iconID": 0, "groupID": 505, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 16, "groupNameID": 63938, "useBasePrice": 0, "fittableNonSingleton": 0}
371	506	{"_key": 506, "iconID": 2530, "groupID": 506, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63939, "useBasePrice": 0, "fittableNonSingleton": 0}
372	507	{"_key": 507, "iconID": 1345, "groupID": 507, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63940, "useBasePrice": 0, "fittableNonSingleton": 0}
373	508	{"_key": 508, "iconID": 170, "groupID": 508, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63941, "useBasePrice": 0, "fittableNonSingleton": 0}
374	509	{"_key": 509, "iconID": 168, "groupID": 509, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63942, "useBasePrice": 0, "fittableNonSingleton": 0}
375	510	{"_key": 510, "iconID": 169, "groupID": 510, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63943, "useBasePrice": 0, "fittableNonSingleton": 0}
376	511	{"_key": 511, "iconID": 1345, "groupID": 511, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63944, "useBasePrice": 0, "fittableNonSingleton": 0}
377	512	{"_key": 512, "iconID": 0, "groupID": 512, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63945, "useBasePrice": 0, "fittableNonSingleton": 0}
378	513	{"_key": 513, "iconID": 0, "groupID": 513, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63946, "useBasePrice": 0, "fittableNonSingleton": 0}
379	514	{"_key": 514, "iconID": 0, "groupID": 514, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63947, "useBasePrice": 0, "fittableNonSingleton": 0}
380	515	{"_key": 515, "iconID": 0, "groupID": 515, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63948, "useBasePrice": 0, "fittableNonSingleton": 0}
381	516	{"_key": 516, "iconID": 0, "groupID": 516, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63949, "useBasePrice": 1, "fittableNonSingleton": 0}
382	517	{"_key": 517, "iconID": 0, "groupID": 517, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 63950, "useBasePrice": 0, "fittableNonSingleton": 0}
383	518	{"_key": 518, "iconID": 0, "groupID": 518, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 63951, "useBasePrice": 0, "fittableNonSingleton": 0}
384	519	{"_key": 519, "iconID": 0, "groupID": 519, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 25, "groupNameID": 63952, "useBasePrice": 1, "fittableNonSingleton": 0}
385	520	{"_key": 520, "iconID": 0, "groupID": 520, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63953, "useBasePrice": 0, "fittableNonSingleton": 0}
386	521	{"_key": 521, "iconID": 0, "groupID": 521, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63954, "useBasePrice": 0, "fittableNonSingleton": 0}
387	522	{"_key": 522, "iconID": 0, "groupID": 522, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63955, "useBasePrice": 0, "fittableNonSingleton": 0}
388	523	{"_key": 523, "iconID": 0, "groupID": 523, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63956, "useBasePrice": 0, "fittableNonSingleton": 0}
389	524	{"_key": 524, "iconID": 2839, "groupID": 524, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63957, "useBasePrice": 0, "fittableNonSingleton": 0}
390	525	{"_key": 525, "iconID": 0, "groupID": 525, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63958, "useBasePrice": 1, "fittableNonSingleton": 0}
391	526	{"_key": 526, "iconID": 0, "groupID": 526, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63959, "useBasePrice": 0, "fittableNonSingleton": 0}
392	527	{"_key": 527, "iconID": 0, "groupID": 527, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63960, "useBasePrice": 0, "fittableNonSingleton": 0}
393	528	{"_key": 528, "iconID": 0, "groupID": 528, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63961, "useBasePrice": 0, "fittableNonSingleton": 0}
394	530	{"_key": 530, "iconID": 0, "groupID": 530, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63962, "useBasePrice": 0, "fittableNonSingleton": 0}
395	532	{"_key": 532, "iconID": 0, "groupID": 532, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63963, "useBasePrice": 1, "fittableNonSingleton": 0}
396	533	{"_key": 533, "iconID": 0, "groupID": 533, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63964, "useBasePrice": 0, "fittableNonSingleton": 0}
397	534	{"_key": 534, "iconID": 0, "groupID": 534, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63965, "useBasePrice": 0, "fittableNonSingleton": 0}
398	535	{"_key": 535, "iconID": 0, "groupID": 535, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63966, "useBasePrice": 1, "fittableNonSingleton": 0}
399	536	{"_key": 536, "iconID": 0, "groupID": 536, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 63967, "useBasePrice": 1, "fittableNonSingleton": 0}
400	537	{"_key": 537, "iconID": 0, "groupID": 537, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 63968, "useBasePrice": 1, "fittableNonSingleton": 0}
401	538	{"_key": 538, "iconID": 0, "groupID": 538, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63969, "useBasePrice": 0, "fittableNonSingleton": 0}
402	540	{"_key": 540, "iconID": 0, "groupID": 540, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63970, "useBasePrice": 0, "fittableNonSingleton": 0}
403	541	{"_key": 541, "iconID": 0, "groupID": 541, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63971, "useBasePrice": 0, "fittableNonSingleton": 0}
404	543	{"_key": 543, "iconID": 0, "groupID": 543, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63972, "useBasePrice": 0, "fittableNonSingleton": 0}
405	544	{"_key": 544, "iconID": 0, "groupID": 544, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 18, "groupNameID": 63973, "useBasePrice": 0, "fittableNonSingleton": 0}
406	545	{"_key": 545, "iconID": 0, "groupID": 545, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 18, "groupNameID": 64343, "useBasePrice": 0, "fittableNonSingleton": 0}
407	546	{"_key": 546, "iconID": 0, "groupID": 546, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 63974, "useBasePrice": 0, "fittableNonSingleton": 0}
408	547	{"_key": 547, "iconID": 0, "groupID": 547, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 63975, "useBasePrice": 0, "fittableNonSingleton": 0}
409	548	{"_key": 548, "iconID": 1721, "groupID": 548, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64427, "useBasePrice": 0, "fittableNonSingleton": 1}
410	549	{"_key": 549, "iconID": 0, "groupID": 549, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 18, "groupNameID": 63976, "useBasePrice": 0, "fittableNonSingleton": 0}
411	550	{"_key": 550, "iconID": 0, "groupID": 550, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63977, "useBasePrice": 0, "fittableNonSingleton": 0}
412	551	{"_key": 551, "iconID": 0, "groupID": 551, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63978, "useBasePrice": 0, "fittableNonSingleton": 0}
413	552	{"_key": 552, "iconID": 0, "groupID": 552, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63979, "useBasePrice": 0, "fittableNonSingleton": 0}
414	553	{"_key": 553, "iconID": 0, "groupID": 553, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63980, "useBasePrice": 0, "fittableNonSingleton": 0}
415	554	{"_key": 554, "iconID": 0, "groupID": 554, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63981, "useBasePrice": 0, "fittableNonSingleton": 0}
416	555	{"_key": 555, "iconID": 0, "groupID": 555, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63982, "useBasePrice": 0, "fittableNonSingleton": 0}
417	556	{"_key": 556, "iconID": 0, "groupID": 556, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63983, "useBasePrice": 0, "fittableNonSingleton": 0}
418	557	{"_key": 557, "iconID": 0, "groupID": 557, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63984, "useBasePrice": 0, "fittableNonSingleton": 0}
419	558	{"_key": 558, "iconID": 0, "groupID": 558, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63985, "useBasePrice": 0, "fittableNonSingleton": 0}
420	559	{"_key": 559, "iconID": 0, "groupID": 559, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63986, "useBasePrice": 0, "fittableNonSingleton": 0}
421	560	{"_key": 560, "iconID": 0, "groupID": 560, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63987, "useBasePrice": 0, "fittableNonSingleton": 0}
422	561	{"_key": 561, "iconID": 0, "groupID": 561, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63988, "useBasePrice": 0, "fittableNonSingleton": 0}
423	562	{"_key": 562, "iconID": 0, "groupID": 562, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63989, "useBasePrice": 0, "fittableNonSingleton": 0}
424	563	{"_key": 563, "iconID": 0, "groupID": 563, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63990, "useBasePrice": 0, "fittableNonSingleton": 0}
425	564	{"_key": 564, "iconID": 0, "groupID": 564, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63991, "useBasePrice": 0, "fittableNonSingleton": 0}
426	565	{"_key": 565, "iconID": 0, "groupID": 565, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63992, "useBasePrice": 0, "fittableNonSingleton": 0}
427	566	{"_key": 566, "iconID": 0, "groupID": 566, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63993, "useBasePrice": 0, "fittableNonSingleton": 0}
428	567	{"_key": 567, "iconID": 0, "groupID": 567, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63994, "useBasePrice": 0, "fittableNonSingleton": 0}
429	568	{"_key": 568, "iconID": 0, "groupID": 568, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63995, "useBasePrice": 0, "fittableNonSingleton": 0}
430	569	{"_key": 569, "iconID": 0, "groupID": 569, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63996, "useBasePrice": 0, "fittableNonSingleton": 0}
431	570	{"_key": 570, "iconID": 0, "groupID": 570, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63997, "useBasePrice": 0, "fittableNonSingleton": 0}
432	571	{"_key": 571, "iconID": 0, "groupID": 571, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63998, "useBasePrice": 0, "fittableNonSingleton": 0}
433	572	{"_key": 572, "iconID": 0, "groupID": 572, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 63999, "useBasePrice": 0, "fittableNonSingleton": 0}
434	573	{"_key": 573, "iconID": 0, "groupID": 573, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64000, "useBasePrice": 0, "fittableNonSingleton": 0}
435	574	{"_key": 574, "iconID": 0, "groupID": 574, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64001, "useBasePrice": 0, "fittableNonSingleton": 0}
436	575	{"_key": 575, "iconID": 0, "groupID": 575, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64002, "useBasePrice": 0, "fittableNonSingleton": 0}
437	576	{"_key": 576, "iconID": 0, "groupID": 576, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64003, "useBasePrice": 0, "fittableNonSingleton": 0}
438	577	{"_key": 577, "iconID": 0, "groupID": 577, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64004, "useBasePrice": 0, "fittableNonSingleton": 0}
439	578	{"_key": 578, "iconID": 0, "groupID": 578, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64005, "useBasePrice": 0, "fittableNonSingleton": 0}
440	579	{"_key": 579, "iconID": 0, "groupID": 579, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64006, "useBasePrice": 0, "fittableNonSingleton": 0}
441	580	{"_key": 580, "iconID": 0, "groupID": 580, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64007, "useBasePrice": 0, "fittableNonSingleton": 0}
442	581	{"_key": 581, "iconID": 0, "groupID": 581, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64008, "useBasePrice": 0, "fittableNonSingleton": 0}
443	582	{"_key": 582, "iconID": 0, "groupID": 582, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64009, "useBasePrice": 0, "fittableNonSingleton": 0}
444	583	{"_key": 583, "iconID": 0, "groupID": 583, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64010, "useBasePrice": 0, "fittableNonSingleton": 0}
445	584	{"_key": 584, "iconID": 0, "groupID": 584, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64011, "useBasePrice": 0, "fittableNonSingleton": 0}
446	585	{"_key": 585, "iconID": 0, "groupID": 585, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64012, "useBasePrice": 0, "fittableNonSingleton": 0}
447	586	{"_key": 586, "iconID": 0, "groupID": 586, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 64013, "useBasePrice": 0, "fittableNonSingleton": 0}
448	588	{"_key": 588, "iconID": 0, "groupID": 588, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64014, "useBasePrice": 0, "fittableNonSingleton": 0}
449	589	{"_key": 589, "iconID": 2990, "groupID": 589, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64342, "useBasePrice": 0, "fittableNonSingleton": 0}
450	590	{"_key": 590, "iconID": 0, "groupID": 590, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64015, "useBasePrice": 0, "fittableNonSingleton": 0}
451	593	{"_key": 593, "iconID": 0, "groupID": 593, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64016, "useBasePrice": 0, "fittableNonSingleton": 0}
452	594	{"_key": 594, "iconID": 0, "groupID": 594, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64017, "useBasePrice": 0, "fittableNonSingleton": 0}
453	595	{"_key": 595, "iconID": 0, "groupID": 595, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64018, "useBasePrice": 0, "fittableNonSingleton": 0}
454	596	{"_key": 596, "iconID": 0, "groupID": 596, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64019, "useBasePrice": 0, "fittableNonSingleton": 0}
455	597	{"_key": 597, "iconID": 0, "groupID": 597, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64020, "useBasePrice": 0, "fittableNonSingleton": 0}
456	602	{"_key": 602, "iconID": 0, "groupID": 602, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64021, "useBasePrice": 0, "fittableNonSingleton": 0}
457	603	{"_key": 603, "iconID": 0, "groupID": 603, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64022, "useBasePrice": 0, "fittableNonSingleton": 0}
458	604	{"_key": 604, "iconID": 0, "groupID": 604, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64023, "useBasePrice": 0, "fittableNonSingleton": 0}
459	605	{"_key": 605, "iconID": 0, "groupID": 605, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64024, "useBasePrice": 0, "fittableNonSingleton": 0}
460	606	{"_key": 606, "iconID": 0, "groupID": 606, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64025, "useBasePrice": 0, "fittableNonSingleton": 0}
461	611	{"_key": 611, "iconID": 0, "groupID": 611, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64026, "useBasePrice": 0, "fittableNonSingleton": 0}
462	612	{"_key": 612, "iconID": 0, "groupID": 612, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64027, "useBasePrice": 0, "fittableNonSingleton": 0}
463	613	{"_key": 613, "iconID": 0, "groupID": 613, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64028, "useBasePrice": 0, "fittableNonSingleton": 0}
464	614	{"_key": 614, "iconID": 0, "groupID": 614, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64029, "useBasePrice": 0, "fittableNonSingleton": 0}
465	615	{"_key": 615, "iconID": 0, "groupID": 615, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64030, "useBasePrice": 0, "fittableNonSingleton": 0}
466	620	{"_key": 620, "iconID": 0, "groupID": 620, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64031, "useBasePrice": 0, "fittableNonSingleton": 0}
467	621	{"_key": 621, "iconID": 0, "groupID": 621, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64032, "useBasePrice": 0, "fittableNonSingleton": 0}
468	622	{"_key": 622, "iconID": 0, "groupID": 622, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64033, "useBasePrice": 0, "fittableNonSingleton": 0}
469	623	{"_key": 623, "iconID": 0, "groupID": 623, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64034, "useBasePrice": 0, "fittableNonSingleton": 0}
470	624	{"_key": 624, "iconID": 0, "groupID": 624, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64035, "useBasePrice": 0, "fittableNonSingleton": 0}
471	629	{"_key": 629, "iconID": 0, "groupID": 629, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64036, "useBasePrice": 0, "fittableNonSingleton": 0}
472	630	{"_key": 630, "iconID": 0, "groupID": 630, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64037, "useBasePrice": 0, "fittableNonSingleton": 0}
473	631	{"_key": 631, "iconID": 0, "groupID": 631, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64038, "useBasePrice": 0, "fittableNonSingleton": 0}
474	632	{"_key": 632, "iconID": 0, "groupID": 632, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64039, "useBasePrice": 0, "fittableNonSingleton": 0}
475	633	{"_key": 633, "iconID": 0, "groupID": 633, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64040, "useBasePrice": 0, "fittableNonSingleton": 0}
476	638	{"_key": 638, "iconID": 0, "groupID": 638, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 64041, "useBasePrice": 0, "fittableNonSingleton": 0}
477	639	{"_key": 639, "iconID": 0, "groupID": 639, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 18, "groupNameID": 64042, "useBasePrice": 0, "fittableNonSingleton": 0}
478	640	{"_key": 640, "iconID": 0, "groupID": 640, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 18, "groupNameID": 64043, "useBasePrice": 0, "fittableNonSingleton": 0}
479	641	{"_key": 641, "iconID": 0, "groupID": 641, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 18, "groupNameID": 64044, "useBasePrice": 0, "fittableNonSingleton": 0}
480	642	{"_key": 642, "iconID": 0, "groupID": 642, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 64045, "useBasePrice": 0, "fittableNonSingleton": 0}
481	643	{"_key": 643, "iconID": 0, "groupID": 643, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64046, "useBasePrice": 1, "fittableNonSingleton": 0}
482	644	{"_key": 644, "iconID": 0, "groupID": 644, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64047, "useBasePrice": 0, "fittableNonSingleton": 0}
483	645	{"_key": 645, "iconID": 0, "groupID": 645, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64048, "useBasePrice": 0, "fittableNonSingleton": 0}
484	646	{"_key": 646, "iconID": 0, "groupID": 646, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64049, "useBasePrice": 0, "fittableNonSingleton": 0}
485	647	{"_key": 647, "iconID": 0, "groupID": 647, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64050, "useBasePrice": 0, "fittableNonSingleton": 0}
486	648	{"_key": 648, "iconID": 1351, "groupID": 648, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64051, "useBasePrice": 0, "fittableNonSingleton": 1}
487	649	{"_key": 649, "iconID": 1174, "groupID": 649, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2, "groupNameID": 64052, "useBasePrice": 1, "fittableNonSingleton": 0}
488	650	{"_key": 650, "iconID": 0, "groupID": 650, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64053, "useBasePrice": 0, "fittableNonSingleton": 0}
489	651	{"_key": 651, "iconID": 0, "groupID": 651, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64054, "useBasePrice": 1, "fittableNonSingleton": 0}
490	652	{"_key": 652, "iconID": 0, "groupID": 652, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 17, "groupNameID": 64055, "useBasePrice": 1, "fittableNonSingleton": 0}
491	653	{"_key": 653, "iconID": 191, "groupID": 653, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64056, "useBasePrice": 0, "fittableNonSingleton": 1}
492	654	{"_key": 654, "iconID": 3235, "groupID": 654, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64057, "useBasePrice": 0, "fittableNonSingleton": 1}
493	655	{"_key": 655, "iconID": 188, "groupID": 655, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64058, "useBasePrice": 0, "fittableNonSingleton": 1}
494	656	{"_key": 656, "iconID": 184, "groupID": 656, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64059, "useBasePrice": 0, "fittableNonSingleton": 1}
495	657	{"_key": 657, "iconID": 1347, "groupID": 657, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64060, "useBasePrice": 0, "fittableNonSingleton": 1}
496	658	{"_key": 658, "iconID": 0, "groupID": 658, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64061, "useBasePrice": 0, "fittableNonSingleton": 0}
497	659	{"_key": 659, "iconID": 0, "groupID": 659, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 64360, "useBasePrice": 0, "fittableNonSingleton": 0}
498	660	{"_key": 660, "iconID": 0, "groupID": 660, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 64062, "useBasePrice": 0, "fittableNonSingleton": 0}
499	661	{"_key": 661, "iconID": 2665, "groupID": 661, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 24, "groupNameID": 64063, "useBasePrice": 0, "fittableNonSingleton": 0}
500	662	{"_key": 662, "iconID": 2665, "groupID": 662, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 24, "groupNameID": 64064, "useBasePrice": 0, "fittableNonSingleton": 0}
501	663	{"_key": 663, "iconID": 24969, "groupID": 663, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64065, "useBasePrice": 0, "fittableNonSingleton": 1}
502	665	{"_key": 665, "iconID": 0, "groupID": 665, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64066, "useBasePrice": 0, "fittableNonSingleton": 0}
503	666	{"_key": 666, "iconID": 0, "groupID": 666, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64067, "useBasePrice": 0, "fittableNonSingleton": 0}
504	667	{"_key": 667, "iconID": 0, "groupID": 667, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64068, "useBasePrice": 0, "fittableNonSingleton": 0}
505	668	{"_key": 668, "iconID": 0, "groupID": 668, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64069, "useBasePrice": 0, "fittableNonSingleton": 0}
506	669	{"_key": 669, "iconID": 0, "groupID": 669, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64070, "useBasePrice": 0, "fittableNonSingleton": 0}
507	670	{"_key": 670, "iconID": 0, "groupID": 670, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64071, "useBasePrice": 0, "fittableNonSingleton": 0}
508	671	{"_key": 671, "iconID": 0, "groupID": 671, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64072, "useBasePrice": 0, "fittableNonSingleton": 0}
509	672	{"_key": 672, "iconID": 0, "groupID": 672, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64073, "useBasePrice": 0, "fittableNonSingleton": 0}
510	673	{"_key": 673, "iconID": 0, "groupID": 673, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64074, "useBasePrice": 0, "fittableNonSingleton": 0}
511	674	{"_key": 674, "iconID": 0, "groupID": 674, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64075, "useBasePrice": 0, "fittableNonSingleton": 0}
512	675	{"_key": 675, "iconID": 0, "groupID": 675, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64076, "useBasePrice": 0, "fittableNonSingleton": 0}
513	676	{"_key": 676, "iconID": 0, "groupID": 676, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64077, "useBasePrice": 0, "fittableNonSingleton": 0}
514	677	{"_key": 677, "iconID": 0, "groupID": 677, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64078, "useBasePrice": 0, "fittableNonSingleton": 0}
515	678	{"_key": 678, "iconID": 0, "groupID": 678, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64079, "useBasePrice": 0, "fittableNonSingleton": 0}
516	679	{"_key": 679, "iconID": 0, "groupID": 679, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64080, "useBasePrice": 0, "fittableNonSingleton": 0}
517	680	{"_key": 680, "iconID": 0, "groupID": 680, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64081, "useBasePrice": 0, "fittableNonSingleton": 0}
518	681	{"_key": 681, "iconID": 0, "groupID": 681, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64082, "useBasePrice": 0, "fittableNonSingleton": 0}
519	682	{"_key": 682, "iconID": 0, "groupID": 682, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64083, "useBasePrice": 0, "fittableNonSingleton": 0}
520	683	{"_key": 683, "iconID": 0, "groupID": 683, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64084, "useBasePrice": 0, "fittableNonSingleton": 0}
521	684	{"_key": 684, "iconID": 0, "groupID": 684, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64085, "useBasePrice": 0, "fittableNonSingleton": 0}
522	685	{"_key": 685, "iconID": 0, "groupID": 685, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64086, "useBasePrice": 0, "fittableNonSingleton": 0}
523	686	{"_key": 686, "iconID": 0, "groupID": 686, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64087, "useBasePrice": 0, "fittableNonSingleton": 0}
524	687	{"_key": 687, "iconID": 0, "groupID": 687, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64088, "useBasePrice": 0, "fittableNonSingleton": 0}
525	688	{"_key": 688, "iconID": 0, "groupID": 688, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64089, "useBasePrice": 0, "fittableNonSingleton": 0}
526	689	{"_key": 689, "iconID": 0, "groupID": 689, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64090, "useBasePrice": 0, "fittableNonSingleton": 0}
527	690	{"_key": 690, "iconID": 0, "groupID": 690, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64091, "useBasePrice": 0, "fittableNonSingleton": 0}
528	691	{"_key": 691, "iconID": 0, "groupID": 691, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64092, "useBasePrice": 0, "fittableNonSingleton": 0}
529	692	{"_key": 692, "iconID": 0, "groupID": 692, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64093, "useBasePrice": 0, "fittableNonSingleton": 0}
530	693	{"_key": 693, "iconID": 0, "groupID": 693, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64094, "useBasePrice": 0, "fittableNonSingleton": 0}
531	694	{"_key": 694, "iconID": 0, "groupID": 694, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64095, "useBasePrice": 0, "fittableNonSingleton": 0}
532	695	{"_key": 695, "iconID": 0, "groupID": 695, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64096, "useBasePrice": 0, "fittableNonSingleton": 0}
533	696	{"_key": 696, "iconID": 0, "groupID": 696, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64097, "useBasePrice": 0, "fittableNonSingleton": 0}
534	697	{"_key": 697, "iconID": 0, "groupID": 697, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64098, "useBasePrice": 0, "fittableNonSingleton": 0}
535	698	{"_key": 698, "iconID": 0, "groupID": 698, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64099, "useBasePrice": 0, "fittableNonSingleton": 0}
536	699	{"_key": 699, "iconID": 0, "groupID": 699, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64100, "useBasePrice": 0, "fittableNonSingleton": 0}
537	700	{"_key": 700, "iconID": 0, "groupID": 700, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64101, "useBasePrice": 0, "fittableNonSingleton": 0}
538	701	{"_key": 701, "iconID": 0, "groupID": 701, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64102, "useBasePrice": 0, "fittableNonSingleton": 0}
539	702	{"_key": 702, "iconID": 0, "groupID": 702, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64103, "useBasePrice": 0, "fittableNonSingleton": 0}
540	703	{"_key": 703, "iconID": 0, "groupID": 703, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64104, "useBasePrice": 0, "fittableNonSingleton": 0}
541	704	{"_key": 704, "iconID": 0, "groupID": 704, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64105, "useBasePrice": 0, "fittableNonSingleton": 0}
542	705	{"_key": 705, "iconID": 0, "groupID": 705, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64106, "useBasePrice": 0, "fittableNonSingleton": 0}
543	706	{"_key": 706, "iconID": 0, "groupID": 706, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64107, "useBasePrice": 0, "fittableNonSingleton": 0}
544	707	{"_key": 707, "iconID": 0, "groupID": 707, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 64108, "useBasePrice": 1, "fittableNonSingleton": 0}
545	709	{"_key": 709, "iconID": 0, "groupID": 709, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 64109, "useBasePrice": 1, "fittableNonSingleton": 0}
546	710	{"_key": 710, "iconID": 0, "groupID": 710, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 64110, "useBasePrice": 1, "fittableNonSingleton": 0}
547	711	{"_key": 711, "iconID": 0, "groupID": 711, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2, "groupNameID": 64111, "useBasePrice": 0, "fittableNonSingleton": 0}
548	712	{"_key": 712, "iconID": 0, "groupID": 712, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 4, "groupNameID": 64112, "useBasePrice": 0, "fittableNonSingleton": 0}
549	715	{"_key": 715, "iconID": 0, "groupID": 715, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64113, "useBasePrice": 0, "fittableNonSingleton": 0}
550	716	{"_key": 716, "iconID": 0, "groupID": 716, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 64114, "useBasePrice": 0, "fittableNonSingleton": 0}
551	718	{"_key": 718, "iconID": 0, "groupID": 718, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64115, "useBasePrice": 0, "fittableNonSingleton": 0}
552	721	{"_key": 721, "iconID": 0, "groupID": 721, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 20, "groupNameID": 64116, "useBasePrice": 0, "fittableNonSingleton": 0}
553	722	{"_key": 722, "groupID": 722, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64117, "useBasePrice": 1, "fittableNonSingleton": 0}
554	723	{"_key": 723, "iconID": 349, "groupID": 723, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64118, "useBasePrice": 1, "fittableNonSingleton": 0}
555	724	{"_key": 724, "iconID": 0, "groupID": 724, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64119, "useBasePrice": 1, "fittableNonSingleton": 0}
556	725	{"_key": 725, "groupID": 725, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64120, "useBasePrice": 1, "fittableNonSingleton": 0}
557	726	{"_key": 726, "iconID": 0, "groupID": 726, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64121, "useBasePrice": 1, "fittableNonSingleton": 0}
558	727	{"_key": 727, "iconID": 0, "groupID": 727, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64122, "useBasePrice": 1, "fittableNonSingleton": 0}
559	728	{"_key": 728, "iconID": 0, "groupID": 728, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 35, "groupNameID": 64305, "useBasePrice": 0, "fittableNonSingleton": 0}
560	729	{"_key": 729, "iconID": 0, "groupID": 729, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 35, "groupNameID": 64308, "useBasePrice": 0, "fittableNonSingleton": 0}
561	730	{"_key": 730, "iconID": 0, "groupID": 730, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 35, "groupNameID": 64307, "useBasePrice": 0, "fittableNonSingleton": 0}
562	731	{"_key": 731, "iconID": 0, "groupID": 731, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 35, "groupNameID": 64306, "useBasePrice": 0, "fittableNonSingleton": 0}
563	732	{"_key": 732, "iconID": 0, "groupID": 732, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 64123, "useBasePrice": 0, "fittableNonSingleton": 0}
564	733	{"_key": 733, "iconID": 0, "groupID": 733, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 64124, "useBasePrice": 0, "fittableNonSingleton": 0}
565	734	{"_key": 734, "iconID": 0, "groupID": 734, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 64125, "useBasePrice": 0, "fittableNonSingleton": 0}
566	735	{"_key": 735, "iconID": 0, "groupID": 735, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 64126, "useBasePrice": 0, "fittableNonSingleton": 0}
567	737	{"_key": 737, "iconID": 0, "groupID": 737, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64127, "useBasePrice": 0, "fittableNonSingleton": 0}
568	738	{"_key": 738, "iconID": 0, "groupID": 738, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 64128, "useBasePrice": 1, "fittableNonSingleton": 0}
569	739	{"_key": 739, "iconID": 0, "groupID": 739, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 64129, "useBasePrice": 1, "fittableNonSingleton": 0}
570	740	{"_key": 740, "iconID": 0, "groupID": 740, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 64130, "useBasePrice": 1, "fittableNonSingleton": 0}
571	741	{"_key": 741, "iconID": 0, "groupID": 741, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 64131, "useBasePrice": 1, "fittableNonSingleton": 0}
572	742	{"_key": 742, "iconID": 0, "groupID": 742, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 64132, "useBasePrice": 1, "fittableNonSingleton": 0}
573	743	{"_key": 743, "iconID": 0, "groupID": 743, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 64133, "useBasePrice": 1, "fittableNonSingleton": 0}
574	744	{"_key": 744, "iconID": 0, "groupID": 744, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 64134, "useBasePrice": 1, "fittableNonSingleton": 0}
575	745	{"_key": 745, "iconID": 0, "groupID": 745, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 64135, "useBasePrice": 1, "fittableNonSingleton": 0}
576	746	{"_key": 746, "iconID": 0, "groupID": 746, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 64136, "useBasePrice": 1, "fittableNonSingleton": 0}
577	747	{"_key": 747, "iconID": 0, "groupID": 747, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 64137, "useBasePrice": 1, "fittableNonSingleton": 0}
578	748	{"_key": 748, "iconID": 0, "groupID": 748, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 64138, "useBasePrice": 1, "fittableNonSingleton": 0}
579	749	{"_key": 749, "iconID": 0, "groupID": 749, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 64139, "useBasePrice": 1, "fittableNonSingleton": 0}
580	750	{"_key": 750, "iconID": 0, "groupID": 750, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 64140, "useBasePrice": 1, "fittableNonSingleton": 0}
581	751	{"_key": 751, "iconID": 0, "groupID": 751, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 64141, "useBasePrice": 1, "fittableNonSingleton": 0}
582	753	{"_key": 753, "iconID": 0, "groupID": 753, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 64142, "useBasePrice": 0, "fittableNonSingleton": 0}
583	754	{"_key": 754, "iconID": 0, "groupID": 754, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 4, "groupNameID": 64143, "useBasePrice": 0, "fittableNonSingleton": 0}
584	755	{"_key": 755, "iconID": 0, "groupID": 755, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64144, "useBasePrice": 0, "fittableNonSingleton": 0}
585	756	{"_key": 756, "iconID": 0, "groupID": 756, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64145, "useBasePrice": 0, "fittableNonSingleton": 0}
586	757	{"_key": 757, "iconID": 0, "groupID": 757, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64146, "useBasePrice": 0, "fittableNonSingleton": 0}
587	758	{"_key": 758, "iconID": 0, "groupID": 758, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64147, "useBasePrice": 0, "fittableNonSingleton": 0}
588	759	{"_key": 759, "iconID": 0, "groupID": 759, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64148, "useBasePrice": 0, "fittableNonSingleton": 0}
589	760	{"_key": 760, "iconID": 0, "groupID": 760, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64149, "useBasePrice": 0, "fittableNonSingleton": 0}
590	761	{"_key": 761, "iconID": 0, "groupID": 761, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64150, "useBasePrice": 0, "fittableNonSingleton": 0}
591	762	{"_key": 762, "iconID": 0, "groupID": 762, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64151, "useBasePrice": 0, "fittableNonSingleton": 0}
592	763	{"_key": 763, "iconID": 0, "groupID": 763, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64152, "useBasePrice": 0, "fittableNonSingleton": 0}
593	764	{"_key": 764, "iconID": 0, "groupID": 764, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64153, "useBasePrice": 0, "fittableNonSingleton": 0}
594	765	{"_key": 765, "iconID": 0, "groupID": 765, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64154, "useBasePrice": 0, "fittableNonSingleton": 0}
595	766	{"_key": 766, "iconID": 0, "groupID": 766, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64155, "useBasePrice": 0, "fittableNonSingleton": 0}
596	767	{"_key": 767, "iconID": 26455, "groupID": 767, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64156, "useBasePrice": 0, "fittableNonSingleton": 0}
597	768	{"_key": 768, "iconID": 26456, "groupID": 768, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64157, "useBasePrice": 0, "fittableNonSingleton": 0}
598	769	{"_key": 769, "iconID": 0, "groupID": 769, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64158, "useBasePrice": 0, "fittableNonSingleton": 0}
599	770	{"_key": 770, "iconID": 26449, "groupID": 770, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64159, "useBasePrice": 0, "fittableNonSingleton": 0}
600	771	{"_key": 771, "iconID": 3241, "groupID": 771, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64160, "useBasePrice": 0, "fittableNonSingleton": 0}
601	772	{"_key": 772, "iconID": 3237, "groupID": 772, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64161, "useBasePrice": 0, "fittableNonSingleton": 1}
602	773	{"_key": 773, "iconID": 0, "groupID": 773, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64162, "useBasePrice": 0, "fittableNonSingleton": 0}
603	774	{"_key": 774, "iconID": 0, "groupID": 774, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64163, "useBasePrice": 0, "fittableNonSingleton": 0}
604	775	{"_key": 775, "iconID": 0, "groupID": 775, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64164, "useBasePrice": 0, "fittableNonSingleton": 0}
605	776	{"_key": 776, "iconID": 0, "groupID": 776, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64165, "useBasePrice": 0, "fittableNonSingleton": 0}
606	777	{"_key": 777, "iconID": 0, "groupID": 777, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64166, "useBasePrice": 0, "fittableNonSingleton": 0}
607	778	{"_key": 778, "iconID": 0, "groupID": 778, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64167, "useBasePrice": 0, "fittableNonSingleton": 0}
608	779	{"_key": 779, "iconID": 0, "groupID": 779, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64168, "useBasePrice": 0, "fittableNonSingleton": 0}
609	781	{"_key": 781, "iconID": 0, "groupID": 781, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64170, "useBasePrice": 0, "fittableNonSingleton": 0}
610	782	{"_key": 782, "iconID": 0, "groupID": 782, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64171, "useBasePrice": 0, "fittableNonSingleton": 0}
611	783	{"_key": 783, "iconID": 0, "groupID": 783, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 64172, "useBasePrice": 1, "fittableNonSingleton": 0}
612	784	{"_key": 784, "iconID": 0, "groupID": 784, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64408, "useBasePrice": 0, "fittableNonSingleton": 0}
613	786	{"_key": 786, "iconID": 0, "groupID": 786, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64173, "useBasePrice": 0, "fittableNonSingleton": 0}
614	787	{"_key": 787, "iconID": 76, "groupID": 787, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64174, "useBasePrice": 1, "fittableNonSingleton": 0}
615	789	{"_key": 789, "iconID": 0, "groupID": 789, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64175, "useBasePrice": 0, "fittableNonSingleton": 0}
616	790	{"_key": 790, "iconID": 0, "groupID": 790, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64176, "useBasePrice": 0, "fittableNonSingleton": 0}
617	791	{"_key": 791, "iconID": 0, "groupID": 791, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64177, "useBasePrice": 0, "fittableNonSingleton": 0}
618	792	{"_key": 792, "iconID": 0, "groupID": 792, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64178, "useBasePrice": 0, "fittableNonSingleton": 0}
619	793	{"_key": 793, "iconID": 0, "groupID": 793, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64179, "useBasePrice": 0, "fittableNonSingleton": 0}
620	794	{"_key": 794, "iconID": 0, "groupID": 794, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64180, "useBasePrice": 0, "fittableNonSingleton": 0}
621	795	{"_key": 795, "iconID": 0, "groupID": 795, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64181, "useBasePrice": 0, "fittableNonSingleton": 0}
622	796	{"_key": 796, "iconID": 0, "groupID": 796, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64182, "useBasePrice": 0, "fittableNonSingleton": 0}
623	797	{"_key": 797, "iconID": 0, "groupID": 797, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64183, "useBasePrice": 0, "fittableNonSingleton": 0}
624	798	{"_key": 798, "iconID": 0, "groupID": 798, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64184, "useBasePrice": 0, "fittableNonSingleton": 0}
625	799	{"_key": 799, "iconID": 0, "groupID": 799, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64185, "useBasePrice": 0, "fittableNonSingleton": 0}
626	800	{"_key": 800, "iconID": 0, "groupID": 800, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64186, "useBasePrice": 0, "fittableNonSingleton": 0}
627	801	{"_key": 801, "iconID": 0, "groupID": 801, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64187, "useBasePrice": 0, "fittableNonSingleton": 0}
628	802	{"_key": 802, "iconID": 0, "groupID": 802, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64188, "useBasePrice": 0, "fittableNonSingleton": 0}
629	803	{"_key": 803, "iconID": 0, "groupID": 803, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64189, "useBasePrice": 0, "fittableNonSingleton": 0}
630	804	{"_key": 804, "iconID": 0, "groupID": 804, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64190, "useBasePrice": 0, "fittableNonSingleton": 0}
631	805	{"_key": 805, "iconID": 0, "groupID": 805, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64191, "useBasePrice": 0, "fittableNonSingleton": 0}
632	806	{"_key": 806, "iconID": 0, "groupID": 806, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64192, "useBasePrice": 0, "fittableNonSingleton": 0}
633	807	{"_key": 807, "iconID": 0, "groupID": 807, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64193, "useBasePrice": 0, "fittableNonSingleton": 0}
634	808	{"_key": 808, "iconID": 0, "groupID": 808, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64194, "useBasePrice": 0, "fittableNonSingleton": 0}
635	809	{"_key": 809, "iconID": 0, "groupID": 809, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64195, "useBasePrice": 0, "fittableNonSingleton": 0}
636	810	{"_key": 810, "iconID": 0, "groupID": 810, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64196, "useBasePrice": 0, "fittableNonSingleton": 0}
637	811	{"_key": 811, "iconID": 0, "groupID": 811, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64197, "useBasePrice": 0, "fittableNonSingleton": 0}
638	812	{"_key": 812, "iconID": 0, "groupID": 812, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64198, "useBasePrice": 0, "fittableNonSingleton": 0}
639	813	{"_key": 813, "iconID": 0, "groupID": 813, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64199, "useBasePrice": 0, "fittableNonSingleton": 0}
640	814	{"_key": 814, "iconID": 0, "groupID": 814, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64200, "useBasePrice": 0, "fittableNonSingleton": 0}
641	815	{"_key": 815, "iconID": 0, "groupID": 815, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64201, "useBasePrice": 0, "fittableNonSingleton": 0}
642	816	{"_key": 816, "iconID": 0, "groupID": 816, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64202, "useBasePrice": 0, "fittableNonSingleton": 0}
643	817	{"_key": 817, "iconID": 0, "groupID": 817, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64203, "useBasePrice": 0, "fittableNonSingleton": 0}
644	818	{"_key": 818, "iconID": 0, "groupID": 818, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64204, "useBasePrice": 0, "fittableNonSingleton": 0}
645	819	{"_key": 819, "iconID": 0, "groupID": 819, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64205, "useBasePrice": 0, "fittableNonSingleton": 0}
646	820	{"_key": 820, "iconID": 0, "groupID": 820, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64206, "useBasePrice": 0, "fittableNonSingleton": 0}
647	821	{"_key": 821, "iconID": 0, "groupID": 821, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64207, "useBasePrice": 0, "fittableNonSingleton": 0}
648	822	{"_key": 822, "iconID": 0, "groupID": 822, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64208, "useBasePrice": 0, "fittableNonSingleton": 0}
649	823	{"_key": 823, "iconID": 0, "groupID": 823, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64209, "useBasePrice": 0, "fittableNonSingleton": 0}
650	824	{"_key": 824, "iconID": 0, "groupID": 824, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64210, "useBasePrice": 0, "fittableNonSingleton": 0}
651	825	{"_key": 825, "iconID": 0, "groupID": 825, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64211, "useBasePrice": 0, "fittableNonSingleton": 0}
652	826	{"_key": 826, "iconID": 0, "groupID": 826, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64212, "useBasePrice": 0, "fittableNonSingleton": 0}
653	827	{"_key": 827, "iconID": 0, "groupID": 827, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64213, "useBasePrice": 0, "fittableNonSingleton": 0}
654	828	{"_key": 828, "iconID": 0, "groupID": 828, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64214, "useBasePrice": 0, "fittableNonSingleton": 0}
655	829	{"_key": 829, "iconID": 0, "groupID": 829, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64215, "useBasePrice": 0, "fittableNonSingleton": 0}
656	830	{"_key": 830, "iconID": 0, "groupID": 830, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 64216, "useBasePrice": 0, "fittableNonSingleton": 0}
657	831	{"_key": 831, "iconID": 0, "groupID": 831, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 64217, "useBasePrice": 0, "fittableNonSingleton": 0}
658	832	{"_key": 832, "iconID": 0, "groupID": 832, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 64218, "useBasePrice": 0, "fittableNonSingleton": 0}
659	833	{"_key": 833, "iconID": 0, "groupID": 833, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 64219, "useBasePrice": 0, "fittableNonSingleton": 0}
660	834	{"_key": 834, "iconID": 0, "groupID": 834, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 64220, "useBasePrice": 0, "fittableNonSingleton": 0}
661	835	{"_key": 835, "iconID": 0, "groupID": 835, "anchored": 0, "published": 1, "anchorable": 1, "categoryID": 2, "groupNameID": 64221, "useBasePrice": 1, "fittableNonSingleton": 0}
662	836	{"_key": 836, "iconID": 0, "groupID": 836, "anchored": 0, "published": 1, "anchorable": 1, "categoryID": 2, "groupNameID": 64222, "useBasePrice": 1, "fittableNonSingleton": 0}
663	837	{"_key": 837, "iconID": 0, "groupID": 837, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 64223, "useBasePrice": 1, "fittableNonSingleton": 0}
664	838	{"_key": 838, "iconID": 0, "groupID": 838, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 64224, "useBasePrice": 1, "fittableNonSingleton": 0}
665	839	{"_key": 839, "iconID": 0, "groupID": 839, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 64225, "useBasePrice": 1, "fittableNonSingleton": 0}
666	840	{"_key": 840, "iconID": 0, "groupID": 840, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 23, "groupNameID": 64345, "useBasePrice": 0, "fittableNonSingleton": 0}
667	841	{"_key": 841, "iconID": 0, "groupID": 841, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64384, "useBasePrice": 1, "fittableNonSingleton": 0}
668	842	{"_key": 842, "iconID": 0, "groupID": 842, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64226, "useBasePrice": 0, "fittableNonSingleton": 0}
669	843	{"_key": 843, "iconID": 0, "groupID": 843, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64227, "useBasePrice": 0, "fittableNonSingleton": 0}
670	844	{"_key": 844, "iconID": 0, "groupID": 844, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64228, "useBasePrice": 0, "fittableNonSingleton": 0}
671	845	{"_key": 845, "iconID": 0, "groupID": 845, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64229, "useBasePrice": 0, "fittableNonSingleton": 0}
672	846	{"_key": 846, "iconID": 0, "groupID": 846, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64230, "useBasePrice": 0, "fittableNonSingleton": 0}
673	847	{"_key": 847, "iconID": 0, "groupID": 847, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64231, "useBasePrice": 0, "fittableNonSingleton": 0}
674	848	{"_key": 848, "iconID": 0, "groupID": 848, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64232, "useBasePrice": 0, "fittableNonSingleton": 0}
675	849	{"_key": 849, "iconID": 0, "groupID": 849, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64233, "useBasePrice": 0, "fittableNonSingleton": 0}
676	850	{"_key": 850, "iconID": 0, "groupID": 850, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64234, "useBasePrice": 0, "fittableNonSingleton": 0}
677	851	{"_key": 851, "iconID": 0, "groupID": 851, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64235, "useBasePrice": 0, "fittableNonSingleton": 0}
678	852	{"_key": 852, "iconID": 0, "groupID": 852, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64236, "useBasePrice": 0, "fittableNonSingleton": 0}
679	853	{"_key": 853, "iconID": 0, "groupID": 853, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64388, "useBasePrice": 1, "fittableNonSingleton": 0}
680	854	{"_key": 854, "iconID": 0, "groupID": 854, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64390, "useBasePrice": 1, "fittableNonSingleton": 0}
681	855	{"_key": 855, "iconID": 0, "groupID": 855, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64387, "useBasePrice": 1, "fittableNonSingleton": 0}
682	856	{"_key": 856, "iconID": 0, "groupID": 856, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64385, "useBasePrice": 1, "fittableNonSingleton": 0}
683	857	{"_key": 857, "iconID": 0, "groupID": 857, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64393, "useBasePrice": 1, "fittableNonSingleton": 0}
684	858	{"_key": 858, "iconID": 0, "groupID": 858, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64392, "useBasePrice": 1, "fittableNonSingleton": 0}
685	859	{"_key": 859, "iconID": 0, "groupID": 859, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64391, "useBasePrice": 1, "fittableNonSingleton": 0}
686	860	{"_key": 860, "iconID": 0, "groupID": 860, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64386, "useBasePrice": 1, "fittableNonSingleton": 0}
687	861	{"_key": 861, "iconID": 0, "groupID": 861, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64237, "useBasePrice": 0, "fittableNonSingleton": 0}
688	862	{"_key": 862, "iconID": 2677, "groupID": 862, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64238, "useBasePrice": 0, "fittableNonSingleton": 0}
689	863	{"_key": 863, "iconID": 3283, "groupID": 863, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64239, "useBasePrice": 0, "fittableNonSingleton": 1}
690	864	{"_key": 864, "iconID": 3282, "groupID": 864, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64240, "useBasePrice": 0, "fittableNonSingleton": 1}
691	865	{"_key": 865, "iconID": 0, "groupID": 865, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64241, "useBasePrice": 0, "fittableNonSingleton": 0}
692	866	{"_key": 866, "iconID": 0, "groupID": 866, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64242, "useBasePrice": 0, "fittableNonSingleton": 0}
693	867	{"_key": 867, "iconID": 0, "groupID": 867, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64243, "useBasePrice": 0, "fittableNonSingleton": 0}
694	868	{"_key": 868, "iconID": 0, "groupID": 868, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64244, "useBasePrice": 0, "fittableNonSingleton": 0}
695	870	{"_key": 870, "iconID": 0, "groupID": 870, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64245, "useBasePrice": 1, "fittableNonSingleton": 0}
696	871	{"_key": 871, "iconID": 0, "groupID": 871, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64389, "useBasePrice": 1, "fittableNonSingleton": 0}
697	872	{"_key": 872, "iconID": 0, "groupID": 872, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 5, "groupNameID": 64246, "useBasePrice": 1, "fittableNonSingleton": 0}
698	873	{"_key": 873, "iconID": 0, "groupID": 873, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 64247, "useBasePrice": 0, "fittableNonSingleton": 0}
699	874	{"_key": 874, "iconID": 0, "groupID": 874, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 64248, "useBasePrice": 0, "fittableNonSingleton": 0}
700	875	{"_key": 875, "iconID": 0, "groupID": 875, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64285, "useBasePrice": 0, "fittableNonSingleton": 0}
701	876	{"_key": 876, "iconID": 0, "groupID": 876, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 5, "groupNameID": 64249, "useBasePrice": 0, "fittableNonSingleton": 0}
702	877	{"_key": 877, "iconID": 0, "groupID": 877, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 23, "groupNameID": 64250, "useBasePrice": 0, "fittableNonSingleton": 0}
703	878	{"_key": 878, "iconID": 0, "groupID": 878, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 64251, "useBasePrice": 0, "fittableNonSingleton": 0}
704	879	{"_key": 879, "iconID": 0, "groupID": 879, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 64252, "useBasePrice": 0, "fittableNonSingleton": 0}
705	880	{"_key": 880, "iconID": 0, "groupID": 880, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 64314, "useBasePrice": 1, "fittableNonSingleton": 0}
706	881	{"_key": 881, "iconID": 0, "groupID": 881, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 24, "groupNameID": 64253, "useBasePrice": 0, "fittableNonSingleton": 0}
707	882	{"_key": 882, "iconID": 0, "groupID": 882, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 24, "groupNameID": 64254, "useBasePrice": 0, "fittableNonSingleton": 0}
708	883	{"_key": 883, "iconID": 0, "groupID": 883, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 64255, "useBasePrice": 0, "fittableNonSingleton": 0}
709	884	{"_key": 884, "iconID": 0, "groupID": 884, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 17, "groupNameID": 64256, "useBasePrice": 0, "fittableNonSingleton": 0}
710	885	{"_key": 885, "iconID": 0, "groupID": 885, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 64257, "useBasePrice": 0, "fittableNonSingleton": 0}
711	886	{"_key": 886, "iconID": 0, "groupID": 886, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 4, "groupNameID": 64258, "useBasePrice": 0, "fittableNonSingleton": 0}
712	888	{"_key": 888, "iconID": 0, "groupID": 888, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64259, "useBasePrice": 1, "fittableNonSingleton": 0}
713	889	{"_key": 889, "iconID": 0, "groupID": 889, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 9, "groupNameID": 64260, "useBasePrice": 0, "fittableNonSingleton": 0}
714	890	{"_key": 890, "iconID": 0, "groupID": 890, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64261, "useBasePrice": 1, "fittableNonSingleton": 0}
715	891	{"_key": 891, "iconID": 0, "groupID": 891, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64383, "useBasePrice": 1, "fittableNonSingleton": 0}
716	892	{"_key": 892, "iconID": 0, "groupID": 892, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 8, "groupNameID": 64371, "useBasePrice": 0, "fittableNonSingleton": 0}
717	893	{"_key": 893, "groupID": 893, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 64262, "useBasePrice": 0, "fittableNonSingleton": 0}
718	894	{"_key": 894, "groupID": 894, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 64263, "useBasePrice": 0, "fittableNonSingleton": 0}
719	896	{"_key": 896, "iconID": 0, "groupID": 896, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 64264, "useBasePrice": 0, "fittableNonSingleton": 0}
720	897	{"_key": 897, "iconID": 0, "groupID": 897, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 64265, "useBasePrice": 0, "fittableNonSingleton": 0}
721	898	{"_key": 898, "groupID": 898, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 64266, "useBasePrice": 0, "fittableNonSingleton": 0}
722	899	{"_key": 899, "iconID": 0, "groupID": 899, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64267, "useBasePrice": 0, "fittableNonSingleton": 0}
723	900	{"_key": 900, "groupID": 900, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 64268, "useBasePrice": 0, "fittableNonSingleton": 0}
724	901	{"_key": 901, "iconID": 0, "groupID": 901, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 64269, "useBasePrice": 0, "fittableNonSingleton": 0}
725	902	{"_key": 902, "iconID": 0, "groupID": 902, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 64270, "useBasePrice": 0, "fittableNonSingleton": 0}
726	903	{"_key": 903, "iconID": 0, "groupID": 903, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 25, "groupNameID": 64271, "useBasePrice": 0, "fittableNonSingleton": 0}
727	904	{"_key": 904, "iconID": 0, "groupID": 904, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 64272, "useBasePrice": 0, "fittableNonSingleton": 0}
728	905	{"_key": 905, "iconID": 0, "groupID": 905, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 64346, "useBasePrice": 0, "fittableNonSingleton": 0}
729	906	{"_key": 906, "iconID": 0, "groupID": 906, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 64273, "useBasePrice": 0, "fittableNonSingleton": 0}
730	907	{"_key": 907, "iconID": 3346, "groupID": 907, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64274, "useBasePrice": 0, "fittableNonSingleton": 1}
731	908	{"_key": 908, "iconID": 111, "groupID": 908, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64275, "useBasePrice": 0, "fittableNonSingleton": 1}
732	909	{"_key": 909, "iconID": 1639, "groupID": 909, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64276, "useBasePrice": 0, "fittableNonSingleton": 1}
733	910	{"_key": 910, "iconID": 74, "groupID": 910, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64277, "useBasePrice": 0, "fittableNonSingleton": 1}
734	911	{"_key": 911, "iconID": 105, "groupID": 911, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64278, "useBasePrice": 0, "fittableNonSingleton": 1}
735	912	{"_key": 912, "iconID": 0, "groupID": 912, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64279, "useBasePrice": 1, "fittableNonSingleton": 0}
736	913	{"_key": 913, "iconID": 0, "groupID": 913, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 64280, "useBasePrice": 0, "fittableNonSingleton": 0}
737	914	{"_key": 914, "iconID": 0, "groupID": 914, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64281, "useBasePrice": 1, "fittableNonSingleton": 0}
738	915	{"_key": 915, "iconID": 0, "groupID": 915, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64282, "useBasePrice": 1, "fittableNonSingleton": 0}
739	916	{"_key": 916, "iconID": 0, "groupID": 916, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64283, "useBasePrice": 1, "fittableNonSingleton": 1}
740	917	{"_key": 917, "groupID": 917, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64287, "useBasePrice": 1, "fittableNonSingleton": 0}
741	918	{"_key": 918, "groupID": 918, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64286, "useBasePrice": 1, "fittableNonSingleton": 0}
742	920	{"_key": 920, "groupID": 920, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 64400, "useBasePrice": 0, "fittableNonSingleton": 0}
743	922	{"_key": 922, "groupID": 922, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64292, "useBasePrice": 0, "fittableNonSingleton": 0}
744	924	{"_key": 924, "groupID": 924, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64348, "useBasePrice": 0, "fittableNonSingleton": 0}
745	925	{"_key": 925, "groupID": 925, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64293, "useBasePrice": 0, "fittableNonSingleton": 0}
746	927	{"_key": 927, "groupID": 927, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64290, "useBasePrice": 0, "fittableNonSingleton": 0}
747	934	{"_key": 934, "groupID": 934, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64291, "useBasePrice": 0, "fittableNonSingleton": 0}
748	935	{"_key": 935, "groupID": 935, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 26, "groupNameID": 64403, "useBasePrice": 0, "fittableNonSingleton": 0}
749	937	{"_key": 937, "groupID": 937, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 29, "groupNameID": 64294, "useBasePrice": 0, "fittableNonSingleton": 0}
750	940	{"_key": 940, "groupID": 940, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 49, "groupNameID": 64409, "useBasePrice": 0, "fittableNonSingleton": 0}
751	941	{"_key": 941, "groupID": 941, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 64296, "useBasePrice": 0, "fittableNonSingleton": 0}
752	943	{"_key": 943, "iconID": 3001, "groupID": 943, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 5, "groupNameID": 64297, "useBasePrice": 0, "fittableNonSingleton": 0}
753	944	{"_key": 944, "groupID": 944, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64299, "useBasePrice": 1, "fittableNonSingleton": 0}
754	945	{"_key": 945, "groupID": 945, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64300, "useBasePrice": 1, "fittableNonSingleton": 0}
755	952	{"_key": 952, "iconID": 0, "groupID": 952, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64301, "useBasePrice": 0, "fittableNonSingleton": 0}
756	954	{"_key": 954, "iconID": 3631, "groupID": 954, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 32, "groupNameID": 64324, "useBasePrice": 0, "fittableNonSingleton": 0}
757	955	{"_key": 955, "groupID": 955, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 17, "groupNameID": 64325, "useBasePrice": 0, "fittableNonSingleton": 0}
758	956	{"_key": 956, "iconID": 3641, "groupID": 956, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 32, "groupNameID": 64327, "useBasePrice": 0, "fittableNonSingleton": 0}
759	957	{"_key": 957, "iconID": 3646, "groupID": 957, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 32, "groupNameID": 64328, "useBasePrice": 0, "fittableNonSingleton": 0}
760	958	{"_key": 958, "iconID": 3636, "groupID": 958, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 32, "groupNameID": 64326, "useBasePrice": 0, "fittableNonSingleton": 0}
761	959	{"_key": 959, "iconID": 0, "groupID": 959, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64315, "useBasePrice": 0, "fittableNonSingleton": 0}
762	960	{"_key": 960, "iconID": 0, "groupID": 960, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64320, "useBasePrice": 0, "fittableNonSingleton": 0}
763	961	{"_key": 961, "iconID": 0, "groupID": 961, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64323, "useBasePrice": 0, "fittableNonSingleton": 0}
764	963	{"_key": 963, "groupID": 963, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 64312, "useBasePrice": 0, "fittableNonSingleton": 0}
765	964	{"_key": 964, "groupID": 964, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 64331, "useBasePrice": 1, "fittableNonSingleton": 0}
766	965	{"_key": 965, "groupID": 965, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64335, "useBasePrice": 1, "fittableNonSingleton": 0}
767	966	{"_key": 966, "groupID": 966, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 4, "groupNameID": 64330, "useBasePrice": 0, "fittableNonSingleton": 0}
768	967	{"_key": 967, "groupID": 967, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 4, "groupNameID": 64302, "useBasePrice": 0, "fittableNonSingleton": 0}
769	971	{"_key": 971, "groupID": 971, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 34, "groupNameID": 64341, "useBasePrice": 0, "fittableNonSingleton": 0}
770	972	{"_key": 972, "groupID": 972, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 8, "groupNameID": 64303, "useBasePrice": 0, "fittableNonSingleton": 1}
771	973	{"_key": 973, "groupID": 973, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64333, "useBasePrice": 0, "fittableNonSingleton": 0}
772	974	{"_key": 974, "groupID": 974, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 4, "groupNameID": 64313, "useBasePrice": 0, "fittableNonSingleton": 0}
773	976	{"_key": 976, "groupID": 976, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 63, "groupNameID": 64304, "useBasePrice": 0, "fittableNonSingleton": 0}
774	977	{"_key": 977, "groupID": 977, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 24, "groupNameID": 64332, "useBasePrice": 1, "fittableNonSingleton": 0}
775	979	{"_key": 979, "groupID": 979, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 35, "groupNameID": 64347, "useBasePrice": 0, "fittableNonSingleton": 0}
776	982	{"_key": 982, "iconID": 0, "groupID": 982, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64316, "useBasePrice": 0, "fittableNonSingleton": 0}
777	983	{"_key": 983, "iconID": 0, "groupID": 983, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64317, "useBasePrice": 0, "fittableNonSingleton": 0}
778	984	{"_key": 984, "iconID": 0, "groupID": 984, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64319, "useBasePrice": 0, "fittableNonSingleton": 0}
779	985	{"_key": 985, "iconID": 0, "groupID": 985, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64318, "useBasePrice": 0, "fittableNonSingleton": 0}
780	986	{"_key": 986, "iconID": 0, "groupID": 986, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64322, "useBasePrice": 0, "fittableNonSingleton": 0}
781	987	{"_key": 987, "iconID": 0, "groupID": 987, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64321, "useBasePrice": 0, "fittableNonSingleton": 0}
782	988	{"_key": 988, "groupID": 988, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 64309, "useBasePrice": 0, "fittableNonSingleton": 0}
783	990	{"_key": 990, "groupID": 990, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 34, "groupNameID": 64338, "useBasePrice": 0, "fittableNonSingleton": 0}
784	991	{"_key": 991, "groupID": 991, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 34, "groupNameID": 64340, "useBasePrice": 0, "fittableNonSingleton": 0}
785	992	{"_key": 992, "groupID": 992, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 34, "groupNameID": 64339, "useBasePrice": 0, "fittableNonSingleton": 0}
786	993	{"_key": 993, "groupID": 993, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 34, "groupNameID": 64336, "useBasePrice": 0, "fittableNonSingleton": 0}
787	995	{"_key": 995, "groupID": 995, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 64311, "useBasePrice": 0, "fittableNonSingleton": 0}
788	996	{"_key": 996, "groupID": 996, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64310, "useBasePrice": 0, "fittableNonSingleton": 0}
789	997	{"_key": 997, "groupID": 997, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 34, "groupNameID": 64337, "useBasePrice": 0, "fittableNonSingleton": 0}
790	1003	{"_key": 1003, "groupID": 1003, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 40, "groupNameID": 64357, "useBasePrice": 1, "fittableNonSingleton": 0}
791	1004	{"_key": 1004, "groupID": 1004, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 40, "groupNameID": 64353, "useBasePrice": 0, "fittableNonSingleton": 0}
792	1005	{"_key": 1005, "groupID": 1005, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 40, "groupNameID": 64359, "useBasePrice": 1, "fittableNonSingleton": 0}
793	1006	{"_key": 1006, "groupID": 1006, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64349, "useBasePrice": 0, "fittableNonSingleton": 0}
794	1007	{"_key": 1007, "groupID": 1007, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64350, "useBasePrice": 0, "fittableNonSingleton": 0}
795	1010	{"_key": 1010, "groupID": 1010, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 8, "groupNameID": 64351, "useBasePrice": 0, "fittableNonSingleton": 1}
796	1012	{"_key": 1012, "groupID": 1012, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 40, "groupNameID": 64358, "useBasePrice": 1, "fittableNonSingleton": 0}
797	1013	{"_key": 1013, "groupID": 1013, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64361, "useBasePrice": 1, "fittableNonSingleton": 0}
798	1016	{"_key": 1016, "groupID": 1016, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 39, "groupNameID": 64356, "useBasePrice": 1, "fittableNonSingleton": 0}
799	1019	{"_key": 1019, "iconID": 182, "groupID": 1019, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 64352, "useBasePrice": 0, "fittableNonSingleton": 1}
800	1020	{"_key": 1020, "groupID": 1020, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 39, "groupNameID": 64354, "useBasePrice": 1, "fittableNonSingleton": 0}
801	1021	{"_key": 1021, "groupID": 1021, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 39, "groupNameID": 64355, "useBasePrice": 1, "fittableNonSingleton": 0}
802	1022	{"_key": 1022, "groupID": 1022, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 64362, "useBasePrice": 0, "fittableNonSingleton": 0}
803	1023	{"_key": 1023, "groupID": 1023, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 18, "groupNameID": 64363, "useBasePrice": 0, "fittableNonSingleton": 0}
804	1025	{"_key": 1025, "groupID": 1025, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 46, "groupNameID": 64428, "useBasePrice": 0, "fittableNonSingleton": 0}
805	1026	{"_key": 1026, "groupID": 1026, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 41, "groupNameID": 64375, "useBasePrice": 1, "fittableNonSingleton": 0}
806	1027	{"_key": 1027, "groupID": 1027, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 41, "groupNameID": 64365, "useBasePrice": 1, "fittableNonSingleton": 0}
807	1028	{"_key": 1028, "groupID": 1028, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 41, "groupNameID": 64376, "useBasePrice": 1, "fittableNonSingleton": 0}
808	1029	{"_key": 1029, "groupID": 1029, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 41, "groupNameID": 64378, "useBasePrice": 1, "fittableNonSingleton": 0}
809	1030	{"_key": 1030, "groupID": 1030, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 41, "groupNameID": 64377, "useBasePrice": 1, "fittableNonSingleton": 0}
810	1031	{"_key": 1031, "groupID": 1031, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 64364, "useBasePrice": 0, "fittableNonSingleton": 0}
811	1032	{"_key": 1032, "groupID": 1032, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 42, "groupNameID": 64368, "useBasePrice": 0, "fittableNonSingleton": 0}
812	1033	{"_key": 1033, "groupID": 1033, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 42, "groupNameID": 64369, "useBasePrice": 0, "fittableNonSingleton": 0}
813	1034	{"_key": 1034, "groupID": 1034, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 43, "groupNameID": 64372, "useBasePrice": 1, "fittableNonSingleton": 0}
814	1035	{"_key": 1035, "groupID": 1035, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 42, "groupNameID": 64367, "useBasePrice": 0, "fittableNonSingleton": 0}
815	1036	{"_key": 1036, "groupID": 1036, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 41, "groupNameID": 64366, "useBasePrice": 1, "fittableNonSingleton": 0}
816	1040	{"_key": 1040, "groupID": 1040, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 43, "groupNameID": 64373, "useBasePrice": 1, "fittableNonSingleton": 0}
817	1041	{"_key": 1041, "groupID": 1041, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 43, "groupNameID": 64370, "useBasePrice": 0, "fittableNonSingleton": 0}
818	1042	{"_key": 1042, "groupID": 1042, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 43, "groupNameID": 64374, "useBasePrice": 1, "fittableNonSingleton": 0}
819	1045	{"_key": 1045, "groupID": 1045, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64380, "useBasePrice": 1, "fittableNonSingleton": 0}
820	1046	{"_key": 1046, "groupID": 1046, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64381, "useBasePrice": 1, "fittableNonSingleton": 0}
821	1048	{"_key": 1048, "groupID": 1048, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64382, "useBasePrice": 1, "fittableNonSingleton": 0}
822	1051	{"_key": 1051, "groupID": 1051, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64398, "useBasePrice": 0, "fittableNonSingleton": 0}
823	1052	{"_key": 1052, "groupID": 1052, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64395, "useBasePrice": 0, "fittableNonSingleton": 0}
824	1053	{"_key": 1053, "groupID": 1053, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64397, "useBasePrice": 0, "fittableNonSingleton": 0}
825	1054	{"_key": 1054, "groupID": 1054, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64396, "useBasePrice": 0, "fittableNonSingleton": 0}
826	1056	{"_key": 1056, "groupID": 1056, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 64394, "useBasePrice": 0, "fittableNonSingleton": 0}
827	1063	{"_key": 1063, "groupID": 1063, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 41, "groupNameID": 64399, "useBasePrice": 1, "fittableNonSingleton": 0}
828	1067	{"_key": 1067, "groupID": 1067, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 26, "groupNameID": 64405, "useBasePrice": 0, "fittableNonSingleton": 0}
829	1068	{"_key": 1068, "groupID": 1068, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 26, "groupNameID": 64404, "useBasePrice": 0, "fittableNonSingleton": 0}
830	1071	{"_key": 1071, "groupID": 1071, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 2, "groupNameID": 64406, "useBasePrice": 0, "fittableNonSingleton": 0}
831	1073	{"_key": 1073, "groupID": 1073, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 46, "groupNameID": 64407, "useBasePrice": 1, "fittableNonSingleton": 0}
832	1079	{"_key": 1079, "groupID": 1079, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 49, "groupNameID": 64410, "useBasePrice": 0, "fittableNonSingleton": 0}
833	1081	{"_key": 1081, "groupID": 1081, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 41, "groupNameID": 64412, "useBasePrice": 0, "fittableNonSingleton": 0}
834	1082	{"_key": 1082, "groupID": 1082, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 41, "groupNameID": 64413, "useBasePrice": 0, "fittableNonSingleton": 0}
835	1083	{"_key": 1083, "groupID": 1083, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 30, "groupNameID": 64417, "useBasePrice": 0, "fittableNonSingleton": 0}
836	1084	{"_key": 1084, "groupID": 1084, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 30, "groupNameID": 64435, "useBasePrice": 0, "fittableNonSingleton": 0}
837	1085	{"_key": 1085, "groupID": 1085, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 30, "groupNameID": 64433, "useBasePrice": 0, "fittableNonSingleton": 0}
838	1086	{"_key": 1086, "groupID": 1086, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 30, "groupNameID": 64434, "useBasePrice": 0, "fittableNonSingleton": 0}
839	1087	{"_key": 1087, "groupID": 1087, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 30, "groupNameID": 64432, "useBasePrice": 0, "fittableNonSingleton": 0}
840	1088	{"_key": 1088, "groupID": 1088, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 30, "groupNameID": 64414, "useBasePrice": 0, "fittableNonSingleton": 0}
841	1089	{"_key": 1089, "groupID": 1089, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 30, "groupNameID": 64418, "useBasePrice": 0, "fittableNonSingleton": 0}
842	1090	{"_key": 1090, "groupID": 1090, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 30, "groupNameID": 64419, "useBasePrice": 0, "fittableNonSingleton": 0}
843	1091	{"_key": 1091, "groupID": 1091, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 30, "groupNameID": 64416, "useBasePrice": 0, "fittableNonSingleton": 0}
844	1092	{"_key": 1092, "groupID": 1092, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 30, "groupNameID": 64431, "useBasePrice": 0, "fittableNonSingleton": 0}
845	1093	{"_key": 1093, "groupID": 1093, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 30, "groupNameID": 64430, "useBasePrice": 0, "fittableNonSingleton": 0}
846	1105	{"_key": 1105, "groupID": 1105, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 53, "groupNameID": 64421, "useBasePrice": 0, "fittableNonSingleton": 0}
847	1106	{"_key": 1106, "groupID": 1106, "anchored": 0, "published": 1, "anchorable": 1, "categoryID": 46, "groupNameID": 64415, "useBasePrice": 1, "fittableNonSingleton": 0}
848	1107	{"_key": 1107, "groupID": 1107, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 53, "groupNameID": 64422, "useBasePrice": 0, "fittableNonSingleton": 0}
849	1108	{"_key": 1108, "groupID": 1108, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 53, "groupNameID": 64420, "useBasePrice": 0, "fittableNonSingleton": 0}
850	1109	{"_key": 1109, "groupID": 1109, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 29, "groupNameID": 64423, "useBasePrice": 0, "fittableNonSingleton": 0}
851	1110	{"_key": 1110, "groupID": 1110, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 54, "groupNameID": 64424, "useBasePrice": 0, "fittableNonSingleton": 0}
852	1111	{"_key": 1111, "groupID": 1111, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 54, "groupNameID": 64425, "useBasePrice": 0, "fittableNonSingleton": 0}
853	1112	{"_key": 1112, "groupID": 1112, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 54, "groupNameID": 64426, "useBasePrice": 0, "fittableNonSingleton": 0}
854	1118	{"_key": 1118, "groupID": 1118, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 17, "groupNameID": 64429, "useBasePrice": 0, "fittableNonSingleton": 0}
855	1121	{"_key": 1121, "groupID": 1121, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 29, "groupNameID": 64436, "useBasePrice": 0, "fittableNonSingleton": 0}
856	1122	{"_key": 1122, "groupID": 1122, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 64438, "useBasePrice": 0, "fittableNonSingleton": 0}
857	1123	{"_key": 1123, "groupID": 1123, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 64439, "useBasePrice": 1, "fittableNonSingleton": 0}
858	1126	{"_key": 1126, "groupID": 1126, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 59, "groupNameID": 235966, "useBasePrice": 0, "fittableNonSingleton": 0}
859	1136	{"_key": 1136, "groupID": 1136, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 4, "groupNameID": 263520, "useBasePrice": 1, "fittableNonSingleton": 0}
860	1137	{"_key": 1137, "groupID": 1137, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 263521, "useBasePrice": 1, "fittableNonSingleton": 0}
861	1139	{"_key": 1139, "groupID": 1139, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 263644, "useBasePrice": 1, "fittableNonSingleton": 0}
862	1141	{"_key": 1141, "iconID": 0, "groupID": 1141, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 263706, "useBasePrice": 0, "fittableNonSingleton": 0}
863	1142	{"_key": 1142, "groupID": 1142, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 267565, "useBasePrice": 1, "fittableNonSingleton": 0}
864	1143	{"_key": 1143, "groupID": 1143, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 267566, "useBasePrice": 1, "fittableNonSingleton": 0}
865	1144	{"_key": 1144, "groupID": 1144, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 267567, "useBasePrice": 1, "fittableNonSingleton": 0}
866	1145	{"_key": 1145, "groupID": 1145, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 267568, "useBasePrice": 1, "fittableNonSingleton": 0}
867	1146	{"_key": 1146, "groupID": 1146, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 267569, "useBasePrice": 1, "fittableNonSingleton": 0}
868	1147	{"_key": 1147, "groupID": 1147, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 267570, "useBasePrice": 1, "fittableNonSingleton": 0}
869	1149	{"_key": 1149, "iconID": 0, "groupID": 1149, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 22, "groupNameID": 277374, "useBasePrice": 0, "fittableNonSingleton": 0}
870	1150	{"_key": 1150, "groupID": 1150, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 277777, "useBasePrice": 0, "fittableNonSingleton": 0}
871	1151	{"_key": 1151, "groupID": 1151, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 278152, "useBasePrice": 1, "fittableNonSingleton": 0}
872	1152	{"_key": 1152, "groupID": 1152, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 278182, "useBasePrice": 1, "fittableNonSingleton": 0}
873	1153	{"_key": 1153, "groupID": 1153, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 8, "groupNameID": 278184, "useBasePrice": 0, "fittableNonSingleton": 1}
874	1154	{"_key": 1154, "groupID": 1154, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 278323, "useBasePrice": 0, "fittableNonSingleton": 0}
875	1155	{"_key": 1155, "groupID": 1155, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 278329, "useBasePrice": 1, "fittableNonSingleton": 0}
876	1156	{"_key": 1156, "iconID": 10935, "groupID": 1156, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 278395, "useBasePrice": 0, "fittableNonSingleton": 0}
877	1157	{"_key": 1157, "groupID": 1157, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 278405, "useBasePrice": 1, "fittableNonSingleton": 0}
878	1158	{"_key": 1158, "iconID": 192, "groupID": 1158, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 8, "groupNameID": 278461, "useBasePrice": 0, "fittableNonSingleton": 1}
879	1159	{"_key": 1159, "groupID": 1159, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 18, "groupNameID": 278654, "useBasePrice": 0, "fittableNonSingleton": 0}
880	1160	{"_key": 1160, "groupID": 1160, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 281035, "useBasePrice": 1, "fittableNonSingleton": 0}
881	1162	{"_key": 1162, "groupID": 1162, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 281234, "useBasePrice": 1, "fittableNonSingleton": 0}
882	1165	{"_key": 1165, "groupID": 1165, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2, "groupNameID": 282854, "useBasePrice": 0, "fittableNonSingleton": 0}
883	1166	{"_key": 1166, "groupID": 1166, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 283244, "useBasePrice": 0, "fittableNonSingleton": 0}
884	1167	{"_key": 1167, "groupID": 1167, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 283255, "useBasePrice": 0, "fittableNonSingleton": 0}
885	1168	{"_key": 1168, "groupID": 1168, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 283260, "useBasePrice": 0, "fittableNonSingleton": 0}
886	1169	{"_key": 1169, "groupID": 1169, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 283263, "useBasePrice": 0, "fittableNonSingleton": 0}
887	1174	{"_key": 1174, "groupID": 1174, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 283414, "useBasePrice": 0, "fittableNonSingleton": 0}
888	1175	{"_key": 1175, "groupID": 1175, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 283415, "useBasePrice": 0, "fittableNonSingleton": 0}
889	1176	{"_key": 1176, "groupID": 1176, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 283416, "useBasePrice": 0, "fittableNonSingleton": 0}
890	1177	{"_key": 1177, "groupID": 1177, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 283417, "useBasePrice": 0, "fittableNonSingleton": 0}
891	1178	{"_key": 1178, "groupID": 1178, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 283418, "useBasePrice": 0, "fittableNonSingleton": 0}
892	1179	{"_key": 1179, "groupID": 1179, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 283424, "useBasePrice": 0, "fittableNonSingleton": 0}
893	1180	{"_key": 1180, "groupID": 1180, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 283425, "useBasePrice": 0, "fittableNonSingleton": 0}
894	1181	{"_key": 1181, "groupID": 1181, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 283426, "useBasePrice": 0, "fittableNonSingleton": 0}
895	1182	{"_key": 1182, "groupID": 1182, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 283427, "useBasePrice": 0, "fittableNonSingleton": 0}
896	1183	{"_key": 1183, "groupID": 1183, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 283434, "useBasePrice": 0, "fittableNonSingleton": 0}
897	1184	{"_key": 1184, "groupID": 1184, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 283435, "useBasePrice": 0, "fittableNonSingleton": 0}
898	1185	{"_key": 1185, "groupID": 1185, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 283436, "useBasePrice": 0, "fittableNonSingleton": 0}
899	1186	{"_key": 1186, "groupID": 1186, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 283437, "useBasePrice": 0, "fittableNonSingleton": 0}
900	1189	{"_key": 1189, "iconID": 0, "groupID": 1189, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 283654, "useBasePrice": 1, "fittableNonSingleton": 0}
901	1190	{"_key": 1190, "groupID": 1190, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 283655, "useBasePrice": 1, "fittableNonSingleton": 0}
902	1191	{"_key": 1191, "groupID": 1191, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 283702, "useBasePrice": 1, "fittableNonSingleton": 0}
903	1194	{"_key": 1194, "groupID": 1194, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 63, "groupNameID": 285071, "useBasePrice": 0, "fittableNonSingleton": 0}
904	1195	{"_key": 1195, "groupID": 1195, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 63, "groupNameID": 285103, "useBasePrice": 0, "fittableNonSingleton": 0}
905	1197	{"_key": 1197, "groupID": 1197, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 285267, "useBasePrice": 0, "fittableNonSingleton": 0}
906	1198	{"_key": 1198, "groupID": 1198, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2, "groupNameID": 285507, "useBasePrice": 0, "fittableNonSingleton": 0}
907	1199	{"_key": 1199, "groupID": 1199, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 286328, "useBasePrice": 0, "fittableNonSingleton": 0}
908	1200	{"_key": 1200, "groupID": 1200, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 286440, "useBasePrice": 0, "fittableNonSingleton": 0}
909	1201	{"_key": 1201, "groupID": 1201, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 286659, "useBasePrice": 0, "fittableNonSingleton": 0}
910	1202	{"_key": 1202, "groupID": 1202, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 286698, "useBasePrice": 0, "fittableNonSingleton": 0}
911	1206	{"_key": 1206, "groupID": 1206, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 287123, "useBasePrice": 1, "fittableNonSingleton": 0}
912	1207	{"_key": 1207, "groupID": 1207, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 287802, "useBasePrice": 0, "fittableNonSingleton": 0}
913	1209	{"_key": 1209, "groupID": 1209, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 287834, "useBasePrice": 1, "fittableNonSingleton": 0}
914	1210	{"_key": 1210, "groupID": 1210, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 287835, "useBasePrice": 1, "fittableNonSingleton": 0}
915	1212	{"_key": 1212, "iconID": 0, "groupID": 1212, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 287837, "useBasePrice": 0, "fittableNonSingleton": 0}
916	1213	{"_key": 1213, "groupID": 1213, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 287841, "useBasePrice": 1, "fittableNonSingleton": 0}
917	1216	{"_key": 1216, "groupID": 1216, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 287846, "useBasePrice": 1, "fittableNonSingleton": 0}
918	1217	{"_key": 1217, "groupID": 1217, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 287847, "useBasePrice": 1, "fittableNonSingleton": 0}
919	1218	{"_key": 1218, "groupID": 1218, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 287848, "useBasePrice": 1, "fittableNonSingleton": 0}
920	1220	{"_key": 1220, "groupID": 1220, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 287849, "useBasePrice": 1, "fittableNonSingleton": 0}
921	1222	{"_key": 1222, "groupID": 1222, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 288144, "useBasePrice": 1, "fittableNonSingleton": 0}
922	1223	{"_key": 1223, "iconID": 0, "groupID": 1223, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 288148, "useBasePrice": 0, "fittableNonSingleton": 0}
923	1224	{"_key": 1224, "groupID": 1224, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 288158, "useBasePrice": 1, "fittableNonSingleton": 0}
924	1225	{"_key": 1225, "groupID": 1225, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 63, "groupNameID": 288338, "useBasePrice": 0, "fittableNonSingleton": 0}
925	1226	{"_key": 1226, "iconID": 2677, "groupID": 1226, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 288482, "useBasePrice": 0, "fittableNonSingleton": 0}
926	1227	{"_key": 1227, "groupID": 1227, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 288490, "useBasePrice": 1, "fittableNonSingleton": 0}
927	1228	{"_key": 1228, "groupID": 1228, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 288909, "useBasePrice": 0, "fittableNonSingleton": 0}
928	1229	{"_key": 1229, "groupID": 1229, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 288910, "useBasePrice": 0, "fittableNonSingleton": 0}
929	1230	{"_key": 1230, "groupID": 1230, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 288911, "useBasePrice": 0, "fittableNonSingleton": 0}
930	1231	{"_key": 1231, "groupID": 1231, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 288912, "useBasePrice": 0, "fittableNonSingleton": 0}
931	1232	{"_key": 1232, "groupID": 1232, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 288913, "useBasePrice": 0, "fittableNonSingleton": 0}
932	1233	{"_key": 1233, "groupID": 1233, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 288914, "useBasePrice": 0, "fittableNonSingleton": 0}
933	1234	{"_key": 1234, "groupID": 1234, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 288915, "useBasePrice": 0, "fittableNonSingleton": 0}
934	1238	{"_key": 1238, "groupID": 1238, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 289110, "useBasePrice": 0, "fittableNonSingleton": 0}
935	1239	{"_key": 1239, "groupID": 1239, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 289111, "useBasePrice": 1, "fittableNonSingleton": 0}
936	1240	{"_key": 1240, "groupID": 1240, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 289820, "useBasePrice": 1, "fittableNonSingleton": 0}
937	1241	{"_key": 1241, "groupID": 1241, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 289821, "useBasePrice": 1, "fittableNonSingleton": 0}
938	1245	{"_key": 1245, "groupID": 1245, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 290236, "useBasePrice": 0, "fittableNonSingleton": 0}
939	1246	{"_key": 1246, "groupID": 1246, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 22, "groupNameID": 290544, "useBasePrice": 0, "fittableNonSingleton": 0}
940	1247	{"_key": 1247, "groupID": 1247, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 22, "groupNameID": 290551, "useBasePrice": 0, "fittableNonSingleton": 0}
941	1248	{"_key": 1248, "groupID": 1248, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 292063, "useBasePrice": 1, "fittableNonSingleton": 0}
942	1249	{"_key": 1249, "groupID": 1249, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 22, "groupNameID": 292103, "useBasePrice": 0, "fittableNonSingleton": 0}
943	1250	{"_key": 1250, "groupID": 1250, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 22, "groupNameID": 292104, "useBasePrice": 0, "fittableNonSingleton": 0}
944	1252	{"_key": 1252, "groupID": 1252, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 292196, "useBasePrice": 0, "fittableNonSingleton": 0}
945	1255	{"_key": 1255, "groupID": 1255, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 292199, "useBasePrice": 0, "fittableNonSingleton": 0}
946	1259	{"_key": 1259, "groupID": 1259, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 292202, "useBasePrice": 0, "fittableNonSingleton": 0}
947	1262	{"_key": 1262, "groupID": 1262, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 292205, "useBasePrice": 0, "fittableNonSingleton": 0}
948	1265	{"_key": 1265, "groupID": 1265, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 292208, "useBasePrice": 0, "fittableNonSingleton": 0}
949	1267	{"_key": 1267, "iconID": 0, "groupID": 1267, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 292374, "useBasePrice": 1, "fittableNonSingleton": 0}
950	1268	{"_key": 1268, "groupID": 1268, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 292399, "useBasePrice": 1, "fittableNonSingleton": 0}
951	1269	{"_key": 1269, "groupID": 1269, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 292398, "useBasePrice": 1, "fittableNonSingleton": 0}
952	1270	{"_key": 1270, "groupID": 1270, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 292400, "useBasePrice": 1, "fittableNonSingleton": 0}
953	1271	{"_key": 1271, "groupID": 1271, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 30, "groupNameID": 292529, "useBasePrice": 0, "fittableNonSingleton": 0}
954	1273	{"_key": 1273, "groupID": 1273, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 22, "groupNameID": 294008, "useBasePrice": 1, "fittableNonSingleton": 0}
955	1274	{"_key": 1274, "groupID": 1274, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 22, "groupNameID": 294017, "useBasePrice": 0, "fittableNonSingleton": 0}
956	1275	{"_key": 1275, "groupID": 1275, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 22, "groupNameID": 294018, "useBasePrice": 0, "fittableNonSingleton": 0}
957	1276	{"_key": 1276, "groupID": 1276, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 22, "groupNameID": 294019, "useBasePrice": 0, "fittableNonSingleton": 0}
958	1277	{"_key": 1277, "iconID": 0, "groupID": 1277, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 294226, "useBasePrice": 1, "fittableNonSingleton": 0}
959	1282	{"_key": 1282, "groupID": 1282, "anchored": 0, "published": 0, "anchorable": 1, "categoryID": 23, "groupNameID": 294898, "useBasePrice": 1, "fittableNonSingleton": 0}
960	1283	{"_key": 1283, "groupID": 1283, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 295174, "useBasePrice": 0, "fittableNonSingleton": 0}
961	1285	{"_key": 1285, "groupID": 1285, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 295431, "useBasePrice": 0, "fittableNonSingleton": 0}
962	1286	{"_key": 1286, "groupID": 1286, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 295432, "useBasePrice": 0, "fittableNonSingleton": 0}
963	1287	{"_key": 1287, "groupID": 1287, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 295433, "useBasePrice": 0, "fittableNonSingleton": 0}
964	1288	{"_key": 1288, "groupID": 1288, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 295439, "useBasePrice": 0, "fittableNonSingleton": 0}
965	1289	{"_key": 1289, "groupID": 1289, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 295684, "useBasePrice": 0, "fittableNonSingleton": 0}
966	1292	{"_key": 1292, "groupID": 1292, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 295847, "useBasePrice": 0, "fittableNonSingleton": 0}
967	1293	{"_key": 1293, "groupID": 1293, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 295885, "useBasePrice": 1, "fittableNonSingleton": 0}
968	1294	{"_key": 1294, "groupID": 1294, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 295886, "useBasePrice": 1, "fittableNonSingleton": 0}
969	1295	{"_key": 1295, "groupID": 1295, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 295887, "useBasePrice": 0, "fittableNonSingleton": 0}
970	1297	{"_key": 1297, "groupID": 1297, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 22, "groupNameID": 296195, "useBasePrice": 0, "fittableNonSingleton": 0}
971	1299	{"_key": 1299, "groupID": 1299, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 296270, "useBasePrice": 0, "fittableNonSingleton": 0}
972	1301	{"_key": 1301, "groupID": 1301, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 5, "groupNameID": 296307, "useBasePrice": 0, "fittableNonSingleton": 0}
973	1304	{"_key": 1304, "groupID": 1304, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 35, "groupNameID": 296724, "useBasePrice": 0, "fittableNonSingleton": 0}
974	1305	{"_key": 1305, "groupID": 1305, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 297285, "useBasePrice": 0, "fittableNonSingleton": 0}
975	1306	{"_key": 1306, "groupID": 1306, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 297286, "useBasePrice": 0, "fittableNonSingleton": 0}
976	1307	{"_key": 1307, "groupID": 1307, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 297412, "useBasePrice": 0, "fittableNonSingleton": 0}
977	1308	{"_key": 1308, "groupID": 1308, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 297415, "useBasePrice": 0, "fittableNonSingleton": 0}
978	1309	{"_key": 1309, "groupID": 1309, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 298107, "useBasePrice": 1, "fittableNonSingleton": 0}
979	1310	{"_key": 1310, "groupID": 1310, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 299806, "useBasePrice": 0, "fittableNonSingleton": 0}
980	1311	{"_key": 1311, "groupID": 1311, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 5, "groupNameID": 305267, "useBasePrice": 0, "fittableNonSingleton": 0}
981	1312	{"_key": 1312, "groupID": 1312, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 22, "groupNameID": 305351, "useBasePrice": 0, "fittableNonSingleton": 0}
982	1313	{"_key": 1313, "groupID": 1313, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 305457, "useBasePrice": 0, "fittableNonSingleton": 0}
983	1314	{"_key": 1314, "iconID": 0, "groupID": 1314, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 306049, "useBasePrice": 1, "fittableNonSingleton": 0}
984	1316	{"_key": 1316, "groupID": 1316, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 306492, "useBasePrice": 0, "fittableNonSingleton": 0}
985	1317	{"_key": 1317, "groupID": 1317, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 306768, "useBasePrice": 1, "fittableNonSingleton": 0}
986	1318	{"_key": 1318, "iconID": 107, "groupID": 1318, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 306840, "useBasePrice": 1, "fittableNonSingleton": 0}
987	1319	{"_key": 1319, "groupID": 1319, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 29, "groupNameID": 306931, "useBasePrice": 0, "fittableNonSingleton": 0}
988	1321	{"_key": 1321, "groupID": 1321, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 308385, "useBasePrice": 0, "fittableNonSingleton": 0}
989	1322	{"_key": 1322, "groupID": 1322, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 308386, "useBasePrice": 0, "fittableNonSingleton": 0}
990	1323	{"_key": 1323, "groupID": 1323, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 308387, "useBasePrice": 0, "fittableNonSingleton": 0}
991	1324	{"_key": 1324, "groupID": 1324, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 308388, "useBasePrice": 0, "fittableNonSingleton": 0}
992	1325	{"_key": 1325, "groupID": 1325, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 308389, "useBasePrice": 0, "fittableNonSingleton": 0}
993	1326	{"_key": 1326, "groupID": 1326, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 308412, "useBasePrice": 0, "fittableNonSingleton": 0}
994	1327	{"_key": 1327, "groupID": 1327, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 308413, "useBasePrice": 0, "fittableNonSingleton": 0}
995	1328	{"_key": 1328, "groupID": 1328, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 308477, "useBasePrice": 0, "fittableNonSingleton": 0}
996	1329	{"_key": 1329, "groupID": 1329, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 308478, "useBasePrice": 0, "fittableNonSingleton": 0}
997	1330	{"_key": 1330, "groupID": 1330, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 308479, "useBasePrice": 0, "fittableNonSingleton": 0}
998	1331	{"_key": 1331, "groupID": 1331, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 308480, "useBasePrice": 0, "fittableNonSingleton": 0}
999	1332	{"_key": 1332, "groupID": 1332, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 308481, "useBasePrice": 0, "fittableNonSingleton": 0}
1000	1333	{"_key": 1333, "groupID": 1333, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 308482, "useBasePrice": 0, "fittableNonSingleton": 0}
1001	1395	{"_key": 1395, "iconID": 0, "groupID": 1395, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 505982, "useBasePrice": 0, "fittableNonSingleton": 0}
1002	1396	{"_key": 1396, "groupID": 1396, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 505983, "useBasePrice": 0, "fittableNonSingleton": 0}
1003	1397	{"_key": 1397, "iconID": 0, "groupID": 1397, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 505988, "useBasePrice": 1, "fittableNonSingleton": 0}
1004	1399	{"_key": 1399, "iconID": 0, "groupID": 1399, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 506029, "useBasePrice": 1, "fittableNonSingleton": 0}
1005	1400	{"_key": 1400, "iconID": 0, "groupID": 1400, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 506042, "useBasePrice": 0, "fittableNonSingleton": 0}
1006	1402	{"_key": 1402, "groupID": 1402, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 506077, "useBasePrice": 0, "fittableNonSingleton": 0}
1007	1404	{"_key": 1404, "groupID": 1404, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 65, "groupNameID": 506142, "useBasePrice": 0, "fittableNonSingleton": 0}
1008	1405	{"_key": 1405, "groupID": 1405, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 65, "groupNameID": 506143, "useBasePrice": 0, "fittableNonSingleton": 0}
1009	1406	{"_key": 1406, "groupID": 1406, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 65, "groupNameID": 506144, "useBasePrice": 0, "fittableNonSingleton": 0}
1010	1407	{"_key": 1407, "groupID": 1407, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 65, "groupNameID": 506145, "useBasePrice": 0, "fittableNonSingleton": 0}
1011	1408	{"_key": 1408, "groupID": 1408, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 65, "groupNameID": 506146, "useBasePrice": 0, "fittableNonSingleton": 0}
1012	1409	{"_key": 1409, "groupID": 1409, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 65, "groupNameID": 506147, "useBasePrice": 0, "fittableNonSingleton": 0}
1013	1410	{"_key": 1410, "groupID": 1410, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 65, "groupNameID": 506148, "useBasePrice": 0, "fittableNonSingleton": 0}
1014	1411	{"_key": 1411, "groupID": 1411, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 506208, "useBasePrice": 0, "fittableNonSingleton": 0}
1015	1412	{"_key": 1412, "groupID": 1412, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 506210, "useBasePrice": 0, "fittableNonSingleton": 0}
1016	1413	{"_key": 1413, "groupID": 1413, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 506211, "useBasePrice": 0, "fittableNonSingleton": 0}
1017	1414	{"_key": 1414, "groupID": 1414, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 506212, "useBasePrice": 0, "fittableNonSingleton": 0}
1018	1415	{"_key": 1415, "groupID": 1415, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 506262, "useBasePrice": 0, "fittableNonSingleton": 0}
1019	1416	{"_key": 1416, "groupID": 1416, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 506263, "useBasePrice": 0, "fittableNonSingleton": 0}
1020	1429	{"_key": 1429, "groupID": 1429, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 506276, "useBasePrice": 0, "fittableNonSingleton": 0}
1021	1430	{"_key": 1430, "groupID": 1430, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 506277, "useBasePrice": 0, "fittableNonSingleton": 0}
1022	1441	{"_key": 1441, "groupID": 1441, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 506446, "useBasePrice": 0, "fittableNonSingleton": 0}
1023	1442	{"_key": 1442, "groupID": 1442, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 506455, "useBasePrice": 0, "fittableNonSingleton": 0}
1024	1452	{"_key": 1452, "groupID": 1452, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 508813, "useBasePrice": 0, "fittableNonSingleton": 0}
1025	1453	{"_key": 1453, "groupID": 1453, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 508814, "useBasePrice": 0, "fittableNonSingleton": 0}
1026	1454	{"_key": 1454, "groupID": 1454, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 508815, "useBasePrice": 0, "fittableNonSingleton": 0}
1027	1455	{"_key": 1455, "groupID": 1455, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 508816, "useBasePrice": 0, "fittableNonSingleton": 0}
1028	1461	{"_key": 1461, "iconID": 2703, "groupID": 1461, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 9, "groupNameID": 508891, "useBasePrice": 0, "fittableNonSingleton": 0}
1029	1462	{"_key": 1462, "groupID": 1462, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 508924, "useBasePrice": 1, "fittableNonSingleton": 0}
1030	1465	{"_key": 1465, "iconID": 0, "groupID": 1465, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 508996, "useBasePrice": 0, "fittableNonSingleton": 0}
1031	1527	{"_key": 1527, "iconID": 0, "groupID": 1527, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 510079, "useBasePrice": 0, "fittableNonSingleton": 0}
1032	1529	{"_key": 1529, "groupID": 1529, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 510145, "useBasePrice": 0, "fittableNonSingleton": 0}
1033	1530	{"_key": 1530, "groupID": 1530, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 510146, "useBasePrice": 0, "fittableNonSingleton": 0}
1034	1533	{"_key": 1533, "groupID": 1533, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 510190, "useBasePrice": 0, "fittableNonSingleton": 0}
1035	1534	{"_key": 1534, "iconID": 0, "groupID": 1534, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 510191, "useBasePrice": 0, "fittableNonSingleton": 0}
1036	1535	{"_key": 1535, "groupID": 1535, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 510273, "useBasePrice": 0, "fittableNonSingleton": 0}
1037	1537	{"_key": 1537, "groupID": 1537, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 87, "groupNameID": 510385, "useBasePrice": 0, "fittableNonSingleton": 0}
1038	1538	{"_key": 1538, "iconID": 0, "groupID": 1538, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 510410, "useBasePrice": 0, "fittableNonSingleton": 0}
1039	1542	{"_key": 1542, "groupID": 1542, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 510424, "useBasePrice": 0, "fittableNonSingleton": 0}
1040	1543	{"_key": 1543, "groupID": 1543, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 510425, "useBasePrice": 1, "fittableNonSingleton": 0}
1041	1545	{"_key": 1545, "groupID": 1545, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 510630, "useBasePrice": 1, "fittableNonSingleton": 0}
1042	1546	{"_key": 1546, "groupID": 1546, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 510635, "useBasePrice": 0, "fittableNonSingleton": 1}
1043	1547	{"_key": 1547, "groupID": 1547, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 510636, "useBasePrice": 0, "fittableNonSingleton": 1}
1044	1548	{"_key": 1548, "groupID": 1548, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 510637, "useBasePrice": 0, "fittableNonSingleton": 1}
1045	1549	{"_key": 1549, "groupID": 1549, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 510638, "useBasePrice": 0, "fittableNonSingleton": 1}
1046	1550	{"_key": 1550, "groupID": 1550, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 8, "groupNameID": 510639, "useBasePrice": 0, "fittableNonSingleton": 1}
1047	1551	{"_key": 1551, "groupID": 1551, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 510640, "useBasePrice": 0, "fittableNonSingleton": 1}
1048	1559	{"_key": 1559, "groupID": 1559, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 8, "groupNameID": 510648, "useBasePrice": 0, "fittableNonSingleton": 1}
1049	1562	{"_key": 1562, "groupID": 1562, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 510929, "useBasePrice": 0, "fittableNonSingleton": 0}
1050	1566	{"_key": 1566, "groupID": 1566, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 511820, "useBasePrice": 0, "fittableNonSingleton": 0}
1051	1567	{"_key": 1567, "groupID": 1567, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 511821, "useBasePrice": 0, "fittableNonSingleton": 0}
1052	1568	{"_key": 1568, "groupID": 1568, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 511822, "useBasePrice": 0, "fittableNonSingleton": 0}
1053	1569	{"_key": 1569, "iconID": 1639, "groupID": 1569, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 513663, "useBasePrice": 0, "fittableNonSingleton": 1}
1054	1570	{"_key": 1570, "groupID": 1570, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513669, "useBasePrice": 0, "fittableNonSingleton": 0}
1055	1579	{"_key": 1579, "groupID": 1579, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513670, "useBasePrice": 0, "fittableNonSingleton": 0}
1056	1580	{"_key": 1580, "groupID": 1580, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513671, "useBasePrice": 0, "fittableNonSingleton": 0}
1057	1581	{"_key": 1581, "groupID": 1581, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513672, "useBasePrice": 0, "fittableNonSingleton": 0}
1058	1582	{"_key": 1582, "groupID": 1582, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513673, "useBasePrice": 0, "fittableNonSingleton": 0}
1059	1583	{"_key": 1583, "groupID": 1583, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513674, "useBasePrice": 0, "fittableNonSingleton": 0}
1060	1584	{"_key": 1584, "groupID": 1584, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513675, "useBasePrice": 0, "fittableNonSingleton": 0}
1061	1585	{"_key": 1585, "groupID": 1585, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513676, "useBasePrice": 0, "fittableNonSingleton": 0}
1062	1586	{"_key": 1586, "groupID": 1586, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513677, "useBasePrice": 0, "fittableNonSingleton": 0}
1063	1587	{"_key": 1587, "groupID": 1587, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513678, "useBasePrice": 0, "fittableNonSingleton": 0}
1064	1588	{"_key": 1588, "groupID": 1588, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513679, "useBasePrice": 0, "fittableNonSingleton": 0}
1065	1589	{"_key": 1589, "groupID": 1589, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513680, "useBasePrice": 0, "fittableNonSingleton": 0}
1066	1590	{"_key": 1590, "groupID": 1590, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513681, "useBasePrice": 0, "fittableNonSingleton": 0}
1067	1591	{"_key": 1591, "groupID": 1591, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513682, "useBasePrice": 0, "fittableNonSingleton": 0}
1068	1592	{"_key": 1592, "groupID": 1592, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513683, "useBasePrice": 0, "fittableNonSingleton": 0}
1069	1593	{"_key": 1593, "groupID": 1593, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513684, "useBasePrice": 0, "fittableNonSingleton": 0}
1070	1594	{"_key": 1594, "groupID": 1594, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513685, "useBasePrice": 0, "fittableNonSingleton": 0}
1071	1595	{"_key": 1595, "groupID": 1595, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513686, "useBasePrice": 0, "fittableNonSingleton": 0}
1072	1596	{"_key": 1596, "groupID": 1596, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513687, "useBasePrice": 0, "fittableNonSingleton": 0}
1073	1598	{"_key": 1598, "groupID": 1598, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513689, "useBasePrice": 0, "fittableNonSingleton": 0}
1074	1599	{"_key": 1599, "groupID": 1599, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513690, "useBasePrice": 0, "fittableNonSingleton": 0}
1075	1600	{"_key": 1600, "groupID": 1600, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513691, "useBasePrice": 0, "fittableNonSingleton": 0}
1076	1601	{"_key": 1601, "groupID": 1601, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513692, "useBasePrice": 0, "fittableNonSingleton": 0}
1077	1602	{"_key": 1602, "groupID": 1602, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513693, "useBasePrice": 0, "fittableNonSingleton": 0}
1078	1603	{"_key": 1603, "groupID": 1603, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513694, "useBasePrice": 0, "fittableNonSingleton": 0}
1079	1604	{"_key": 1604, "groupID": 1604, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513695, "useBasePrice": 0, "fittableNonSingleton": 0}
1080	1605	{"_key": 1605, "groupID": 1605, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513696, "useBasePrice": 0, "fittableNonSingleton": 0}
1081	1606	{"_key": 1606, "groupID": 1606, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513697, "useBasePrice": 0, "fittableNonSingleton": 0}
1082	1607	{"_key": 1607, "groupID": 1607, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513698, "useBasePrice": 0, "fittableNonSingleton": 0}
1083	1608	{"_key": 1608, "groupID": 1608, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513699, "useBasePrice": 0, "fittableNonSingleton": 0}
1084	1609	{"_key": 1609, "groupID": 1609, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513700, "useBasePrice": 0, "fittableNonSingleton": 0}
1085	1610	{"_key": 1610, "groupID": 1610, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513701, "useBasePrice": 0, "fittableNonSingleton": 0}
1086	1611	{"_key": 1611, "groupID": 1611, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513702, "useBasePrice": 0, "fittableNonSingleton": 0}
1087	1612	{"_key": 1612, "groupID": 1612, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513703, "useBasePrice": 0, "fittableNonSingleton": 0}
1088	1613	{"_key": 1613, "groupID": 1613, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 513704, "useBasePrice": 0, "fittableNonSingleton": 0}
1089	1614	{"_key": 1614, "groupID": 1614, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 513705, "useBasePrice": 0, "fittableNonSingleton": 0}
1090	1615	{"_key": 1615, "groupID": 1615, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 513706, "useBasePrice": 0, "fittableNonSingleton": 0}
1091	1616	{"_key": 1616, "groupID": 1616, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 513707, "useBasePrice": 0, "fittableNonSingleton": 0}
1092	1617	{"_key": 1617, "groupID": 1617, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513708, "useBasePrice": 0, "fittableNonSingleton": 0}
1093	1618	{"_key": 1618, "groupID": 1618, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513709, "useBasePrice": 0, "fittableNonSingleton": 0}
1094	1619	{"_key": 1619, "groupID": 1619, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 513710, "useBasePrice": 0, "fittableNonSingleton": 0}
1095	1620	{"_key": 1620, "groupID": 1620, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 513711, "useBasePrice": 0, "fittableNonSingleton": 0}
1096	1621	{"_key": 1621, "groupID": 1621, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 513712, "useBasePrice": 0, "fittableNonSingleton": 0}
1097	1622	{"_key": 1622, "groupID": 1622, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 513713, "useBasePrice": 0, "fittableNonSingleton": 0}
1098	1629	{"_key": 1629, "groupID": 1629, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 513720, "useBasePrice": 0, "fittableNonSingleton": 0}
1099	1630	{"_key": 1630, "groupID": 1630, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 513721, "useBasePrice": 0, "fittableNonSingleton": 0}
1100	1631	{"_key": 1631, "groupID": 1631, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513722, "useBasePrice": 0, "fittableNonSingleton": 0}
1101	1632	{"_key": 1632, "groupID": 1632, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 513723, "useBasePrice": 0, "fittableNonSingleton": 0}
1102	1633	{"_key": 1633, "groupID": 1633, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 513724, "useBasePrice": 0, "fittableNonSingleton": 0}
1103	1634	{"_key": 1634, "groupID": 1634, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 513725, "useBasePrice": 0, "fittableNonSingleton": 0}
1104	1635	{"_key": 1635, "groupID": 1635, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 513726, "useBasePrice": 0, "fittableNonSingleton": 0}
1105	1639	{"_key": 1639, "groupID": 1639, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 513730, "useBasePrice": 0, "fittableNonSingleton": 0}
1106	1640	{"_key": 1640, "groupID": 1640, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513731, "useBasePrice": 0, "fittableNonSingleton": 0}
1107	1641	{"_key": 1641, "groupID": 1641, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 513732, "useBasePrice": 0, "fittableNonSingleton": 0}
1108	1642	{"_key": 1642, "groupID": 1642, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 513733, "useBasePrice": 0, "fittableNonSingleton": 0}
1109	1647	{"_key": 1647, "groupID": 1647, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513736, "useBasePrice": 0, "fittableNonSingleton": 0}
1110	1648	{"_key": 1648, "groupID": 1648, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513737, "useBasePrice": 0, "fittableNonSingleton": 0}
1111	1649	{"_key": 1649, "groupID": 1649, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 513738, "useBasePrice": 0, "fittableNonSingleton": 0}
1112	1652	{"_key": 1652, "groupID": 1652, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 87, "groupNameID": 514086, "useBasePrice": 0, "fittableNonSingleton": 0}
1113	1653	{"_key": 1653, "groupID": 1653, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 87, "groupNameID": 514087, "useBasePrice": 0, "fittableNonSingleton": 0}
1114	1657	{"_key": 1657, "groupID": 1657, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 65, "groupNameID": 514422, "useBasePrice": 0, "fittableNonSingleton": 0}
1115	1664	{"_key": 1664, "groupID": 1664, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 514632, "useBasePrice": 0, "fittableNonSingleton": 0}
1116	1665	{"_key": 1665, "groupID": 1665, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 514633, "useBasePrice": 0, "fittableNonSingleton": 0}
1117	1666	{"_key": 1666, "groupID": 1666, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 514634, "useBasePrice": 0, "fittableNonSingleton": 0}
1118	1667	{"_key": 1667, "groupID": 1667, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 514635, "useBasePrice": 0, "fittableNonSingleton": 0}
1119	1670	{"_key": 1670, "groupID": 1670, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 30, "groupNameID": 515056, "useBasePrice": 0, "fittableNonSingleton": 0}
1120	1672	{"_key": 1672, "iconID": 0, "groupID": 1672, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 515060, "useBasePrice": 0, "fittableNonSingleton": 0}
1121	1673	{"_key": 1673, "iconID": 2839, "groupID": 1673, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 515475, "useBasePrice": 0, "fittableNonSingleton": 0}
1122	1674	{"_key": 1674, "iconID": 2839, "groupID": 1674, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 515476, "useBasePrice": 0, "fittableNonSingleton": 0}
1123	1676	{"_key": 1676, "groupID": 1676, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 4, "groupNameID": 515483, "useBasePrice": 0, "fittableNonSingleton": 0}
1124	1677	{"_key": 1677, "iconID": 1349, "groupID": 1677, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 515499, "useBasePrice": 0, "fittableNonSingleton": 1}
1125	1678	{"_key": 1678, "iconID": 182, "groupID": 1678, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 515500, "useBasePrice": 0, "fittableNonSingleton": 1}
1126	1679	{"_key": 1679, "groupID": 1679, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 515623, "useBasePrice": 1, "fittableNonSingleton": 0}
1127	1681	{"_key": 1681, "groupID": 1681, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 515700, "useBasePrice": 0, "fittableNonSingleton": 0}
1128	1682	{"_key": 1682, "groupID": 1682, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 515701, "useBasePrice": 0, "fittableNonSingleton": 0}
1129	1683	{"_key": 1683, "groupID": 1683, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 515702, "useBasePrice": 0, "fittableNonSingleton": 0}
1130	1684	{"_key": 1684, "groupID": 1684, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 515703, "useBasePrice": 0, "fittableNonSingleton": 0}
1131	1685	{"_key": 1685, "groupID": 1685, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 515704, "useBasePrice": 0, "fittableNonSingleton": 0}
1132	1686	{"_key": 1686, "groupID": 1686, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 515705, "useBasePrice": 0, "fittableNonSingleton": 0}
1133	1687	{"_key": 1687, "groupID": 1687, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 515706, "useBasePrice": 0, "fittableNonSingleton": 0}
1134	1688	{"_key": 1688, "groupID": 1688, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 515707, "useBasePrice": 0, "fittableNonSingleton": 0}
1135	1689	{"_key": 1689, "groupID": 1689, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 515708, "useBasePrice": 0, "fittableNonSingleton": 0}
1136	1690	{"_key": 1690, "groupID": 1690, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 515710, "useBasePrice": 0, "fittableNonSingleton": 0}
1137	1691	{"_key": 1691, "groupID": 1691, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 515711, "useBasePrice": 0, "fittableNonSingleton": 0}
1138	1692	{"_key": 1692, "groupID": 1692, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 515712, "useBasePrice": 0, "fittableNonSingleton": 0}
1139	1693	{"_key": 1693, "groupID": 1693, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 515795, "useBasePrice": 0, "fittableNonSingleton": 0}
1140	1694	{"_key": 1694, "groupID": 1694, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 515796, "useBasePrice": 0, "fittableNonSingleton": 0}
1141	1695	{"_key": 1695, "groupID": 1695, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 515797, "useBasePrice": 0, "fittableNonSingleton": 0}
1142	1696	{"_key": 1696, "groupID": 1696, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 515798, "useBasePrice": 0, "fittableNonSingleton": 0}
1143	1697	{"_key": 1697, "groupID": 1697, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 516084, "useBasePrice": 0, "fittableNonSingleton": 0}
1144	1698	{"_key": 1698, "groupID": 1698, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 516085, "useBasePrice": 0, "fittableNonSingleton": 0}
1145	1699	{"_key": 1699, "groupID": 1699, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 516110, "useBasePrice": 0, "fittableNonSingleton": 0}
1146	1700	{"_key": 1700, "groupID": 1700, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 516111, "useBasePrice": 0, "fittableNonSingleton": 0}
1147	1701	{"_key": 1701, "groupID": 1701, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 516116, "useBasePrice": 0, "fittableNonSingleton": 1}
1148	1702	{"_key": 1702, "groupID": 1702, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 516117, "useBasePrice": 0, "fittableNonSingleton": 1}
1149	1703	{"_key": 1703, "iconID": 0, "groupID": 1703, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 516332, "useBasePrice": 1, "fittableNonSingleton": 0}
1150	1704	{"_key": 1704, "iconID": 0, "groupID": 1704, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 516410, "useBasePrice": 0, "fittableNonSingleton": 0}
1151	1706	{"_key": 1706, "iconID": 0, "groupID": 1706, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 516574, "useBasePrice": 0, "fittableNonSingleton": 0}
1152	1707	{"_key": 1707, "groupID": 1707, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 516592, "useBasePrice": 1, "fittableNonSingleton": 0}
1153	1708	{"_key": 1708, "groupID": 1708, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 516593, "useBasePrice": 1, "fittableNonSingleton": 0}
1154	1709	{"_key": 1709, "groupID": 1709, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 9, "groupNameID": 516594, "useBasePrice": 1, "fittableNonSingleton": 0}
1155	1717	{"_key": 1717, "groupID": 1717, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 516606, "useBasePrice": 0, "fittableNonSingleton": 0}
1156	1718	{"_key": 1718, "iconID": 0, "groupID": 1718, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 516608, "useBasePrice": 1, "fittableNonSingleton": 0}
1157	1719	{"_key": 1719, "groupID": 1719, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 516879, "useBasePrice": 0, "fittableNonSingleton": 0}
1158	1720	{"_key": 1720, "groupID": 1720, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 517302, "useBasePrice": 0, "fittableNonSingleton": 0}
1159	1721	{"_key": 1721, "groupID": 1721, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 517303, "useBasePrice": 0, "fittableNonSingleton": 0}
1160	1722	{"_key": 1722, "groupID": 1722, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 517304, "useBasePrice": 0, "fittableNonSingleton": 0}
1161	1723	{"_key": 1723, "groupID": 1723, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 517329, "useBasePrice": 1, "fittableNonSingleton": 0}
1162	1724	{"_key": 1724, "groupID": 1724, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 517365, "useBasePrice": 0, "fittableNonSingleton": 0}
1163	1725	{"_key": 1725, "groupID": 1725, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 517366, "useBasePrice": 0, "fittableNonSingleton": 0}
1164	1726	{"_key": 1726, "groupID": 1726, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 517367, "useBasePrice": 0, "fittableNonSingleton": 0}
1165	1727	{"_key": 1727, "groupID": 1727, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 517494, "useBasePrice": 0, "fittableNonSingleton": 0}
1166	1728	{"_key": 1728, "groupID": 1728, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 517495, "useBasePrice": 0, "fittableNonSingleton": 0}
1167	1729	{"_key": 1729, "groupID": 1729, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 517496, "useBasePrice": 0, "fittableNonSingleton": 0}
1168	1730	{"_key": 1730, "groupID": 1730, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 517638, "useBasePrice": 1, "fittableNonSingleton": 0}
1169	1731	{"_key": 1731, "groupID": 1731, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 517715, "useBasePrice": 0, "fittableNonSingleton": 0}
1170	1734	{"_key": 1734, "groupID": 1734, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 517755, "useBasePrice": 0, "fittableNonSingleton": 0}
1171	1735	{"_key": 1735, "groupID": 1735, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 517756, "useBasePrice": 0, "fittableNonSingleton": 0}
1172	1736	{"_key": 1736, "groupID": 1736, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 517757, "useBasePrice": 0, "fittableNonSingleton": 0}
1173	1737	{"_key": 1737, "groupID": 1737, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 517758, "useBasePrice": 0, "fittableNonSingleton": 0}
1174	1739	{"_key": 1739, "groupID": 1739, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 5, "groupNameID": 518135, "useBasePrice": 0, "fittableNonSingleton": 0}
1175	1759	{"_key": 1759, "groupID": 1759, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518175, "useBasePrice": 0, "fittableNonSingleton": 0}
1176	1761	{"_key": 1761, "groupID": 1761, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518176, "useBasePrice": 0, "fittableNonSingleton": 0}
1177	1762	{"_key": 1762, "groupID": 1762, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518177, "useBasePrice": 0, "fittableNonSingleton": 0}
1178	1764	{"_key": 1764, "groupID": 1764, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518357, "useBasePrice": 0, "fittableNonSingleton": 0}
1179	1765	{"_key": 1765, "groupID": 1765, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518600, "useBasePrice": 0, "fittableNonSingleton": 0}
1180	1766	{"_key": 1766, "groupID": 1766, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518601, "useBasePrice": 0, "fittableNonSingleton": 0}
1181	1767	{"_key": 1767, "groupID": 1767, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518602, "useBasePrice": 0, "fittableNonSingleton": 0}
1182	1768	{"_key": 1768, "groupID": 1768, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518607, "useBasePrice": 0, "fittableNonSingleton": 0}
1183	1769	{"_key": 1769, "groupID": 1769, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 518625, "useBasePrice": 0, "fittableNonSingleton": 1}
1184	1770	{"_key": 1770, "groupID": 1770, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 518819, "useBasePrice": 0, "fittableNonSingleton": 0}
1185	1771	{"_key": 1771, "groupID": 1771, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 518824, "useBasePrice": 0, "fittableNonSingleton": 1}
1186	1772	{"_key": 1772, "groupID": 1772, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 518822, "useBasePrice": 0, "fittableNonSingleton": 1}
1187	1773	{"_key": 1773, "groupID": 1773, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 518821, "useBasePrice": 0, "fittableNonSingleton": 1}
1188	1774	{"_key": 1774, "groupID": 1774, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 518820, "useBasePrice": 0, "fittableNonSingleton": 1}
1189	1788	{"_key": 1788, "groupID": 1788, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518827, "useBasePrice": 0, "fittableNonSingleton": 0}
1190	1789	{"_key": 1789, "groupID": 1789, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518828, "useBasePrice": 0, "fittableNonSingleton": 0}
1191	1790	{"_key": 1790, "groupID": 1790, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518829, "useBasePrice": 0, "fittableNonSingleton": 0}
1192	1791	{"_key": 1791, "groupID": 1791, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518830, "useBasePrice": 0, "fittableNonSingleton": 0}
1193	1792	{"_key": 1792, "groupID": 1792, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518831, "useBasePrice": 0, "fittableNonSingleton": 0}
1194	1793	{"_key": 1793, "groupID": 1793, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518832, "useBasePrice": 0, "fittableNonSingleton": 0}
1195	1794	{"_key": 1794, "groupID": 1794, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518833, "useBasePrice": 0, "fittableNonSingleton": 0}
1196	1795	{"_key": 1795, "groupID": 1795, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518834, "useBasePrice": 0, "fittableNonSingleton": 0}
1197	1796	{"_key": 1796, "groupID": 1796, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518835, "useBasePrice": 0, "fittableNonSingleton": 0}
1198	1797	{"_key": 1797, "groupID": 1797, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518836, "useBasePrice": 0, "fittableNonSingleton": 0}
1199	1798	{"_key": 1798, "groupID": 1798, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518837, "useBasePrice": 0, "fittableNonSingleton": 0}
1200	1799	{"_key": 1799, "groupID": 1799, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518838, "useBasePrice": 0, "fittableNonSingleton": 0}
1201	1800	{"_key": 1800, "groupID": 1800, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518839, "useBasePrice": 0, "fittableNonSingleton": 0}
1202	1803	{"_key": 1803, "groupID": 1803, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518967, "useBasePrice": 0, "fittableNonSingleton": 0}
1203	1804	{"_key": 1804, "groupID": 1804, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518975, "useBasePrice": 0, "fittableNonSingleton": 0}
1204	1805	{"_key": 1805, "groupID": 1805, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518976, "useBasePrice": 0, "fittableNonSingleton": 0}
1205	1806	{"_key": 1806, "groupID": 1806, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518977, "useBasePrice": 0, "fittableNonSingleton": 0}
1206	1807	{"_key": 1807, "groupID": 1807, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 518978, "useBasePrice": 0, "fittableNonSingleton": 0}
1207	1810	{"_key": 1810, "groupID": 1810, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 519234, "useBasePrice": 1, "fittableNonSingleton": 0}
1208	1812	{"_key": 1812, "groupID": 1812, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 520609, "useBasePrice": 1, "fittableNonSingleton": 0}
1209	1813	{"_key": 1813, "groupID": 1813, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 521274, "useBasePrice": 0, "fittableNonSingleton": 0}
1210	1814	{"_key": 1814, "groupID": 1814, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 521275, "useBasePrice": 0, "fittableNonSingleton": 0}
1211	1815	{"_key": 1815, "groupID": 1815, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 521648, "useBasePrice": 0, "fittableNonSingleton": 0}
1212	1816	{"_key": 1816, "groupID": 1816, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521978, "useBasePrice": 0, "fittableNonSingleton": 0}
1213	1818	{"_key": 1818, "iconID": 0, "groupID": 1818, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 521973, "useBasePrice": 0, "fittableNonSingleton": 0}
1214	1819	{"_key": 1819, "groupID": 1819, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521979, "useBasePrice": 0, "fittableNonSingleton": 0}
1215	1820	{"_key": 1820, "groupID": 1820, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521980, "useBasePrice": 0, "fittableNonSingleton": 0}
1216	1821	{"_key": 1821, "groupID": 1821, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521981, "useBasePrice": 0, "fittableNonSingleton": 0}
1217	1822	{"_key": 1822, "groupID": 1822, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521982, "useBasePrice": 0, "fittableNonSingleton": 0}
1218	1823	{"_key": 1823, "groupID": 1823, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521983, "useBasePrice": 0, "fittableNonSingleton": 0}
1219	1824	{"_key": 1824, "groupID": 1824, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521984, "useBasePrice": 0, "fittableNonSingleton": 0}
1220	1825	{"_key": 1825, "groupID": 1825, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521985, "useBasePrice": 0, "fittableNonSingleton": 0}
1221	1826	{"_key": 1826, "groupID": 1826, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521986, "useBasePrice": 0, "fittableNonSingleton": 0}
1222	1827	{"_key": 1827, "groupID": 1827, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521987, "useBasePrice": 0, "fittableNonSingleton": 0}
1223	1828	{"_key": 1828, "groupID": 1828, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521988, "useBasePrice": 0, "fittableNonSingleton": 0}
1224	1829	{"_key": 1829, "groupID": 1829, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521989, "useBasePrice": 0, "fittableNonSingleton": 0}
1225	1830	{"_key": 1830, "groupID": 1830, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521990, "useBasePrice": 0, "fittableNonSingleton": 0}
1226	1831	{"_key": 1831, "groupID": 1831, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521991, "useBasePrice": 0, "fittableNonSingleton": 0}
1227	1832	{"_key": 1832, "groupID": 1832, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521992, "useBasePrice": 0, "fittableNonSingleton": 0}
1228	1833	{"_key": 1833, "groupID": 1833, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521993, "useBasePrice": 0, "fittableNonSingleton": 0}
1229	1834	{"_key": 1834, "groupID": 1834, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521994, "useBasePrice": 0, "fittableNonSingleton": 0}
1230	1835	{"_key": 1835, "groupID": 1835, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521995, "useBasePrice": 0, "fittableNonSingleton": 0}
1231	1836	{"_key": 1836, "groupID": 1836, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521998, "useBasePrice": 0, "fittableNonSingleton": 0}
1232	1837	{"_key": 1837, "groupID": 1837, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 521999, "useBasePrice": 0, "fittableNonSingleton": 0}
1233	1838	{"_key": 1838, "groupID": 1838, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522000, "useBasePrice": 0, "fittableNonSingleton": 0}
1234	1839	{"_key": 1839, "groupID": 1839, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522001, "useBasePrice": 0, "fittableNonSingleton": 0}
1235	1840	{"_key": 1840, "groupID": 1840, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522002, "useBasePrice": 0, "fittableNonSingleton": 0}
1236	1841	{"_key": 1841, "groupID": 1841, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522003, "useBasePrice": 0, "fittableNonSingleton": 0}
1237	1842	{"_key": 1842, "groupID": 1842, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522026, "useBasePrice": 0, "fittableNonSingleton": 0}
1238	1843	{"_key": 1843, "groupID": 1843, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522035, "useBasePrice": 0, "fittableNonSingleton": 0}
1239	1844	{"_key": 1844, "groupID": 1844, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522036, "useBasePrice": 0, "fittableNonSingleton": 0}
1240	1845	{"_key": 1845, "groupID": 1845, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522037, "useBasePrice": 0, "fittableNonSingleton": 0}
1241	1846	{"_key": 1846, "groupID": 1846, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522038, "useBasePrice": 0, "fittableNonSingleton": 0}
1242	1847	{"_key": 1847, "groupID": 1847, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522039, "useBasePrice": 0, "fittableNonSingleton": 0}
1243	1848	{"_key": 1848, "groupID": 1848, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522040, "useBasePrice": 0, "fittableNonSingleton": 0}
1244	1849	{"_key": 1849, "groupID": 1849, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522041, "useBasePrice": 0, "fittableNonSingleton": 0}
1245	1850	{"_key": 1850, "groupID": 1850, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522042, "useBasePrice": 0, "fittableNonSingleton": 0}
1246	1851	{"_key": 1851, "groupID": 1851, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522054, "useBasePrice": 0, "fittableNonSingleton": 0}
1247	1852	{"_key": 1852, "groupID": 1852, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522057, "useBasePrice": 0, "fittableNonSingleton": 0}
1248	1853	{"_key": 1853, "groupID": 1853, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522058, "useBasePrice": 0, "fittableNonSingleton": 0}
1249	1854	{"_key": 1854, "groupID": 1854, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522059, "useBasePrice": 0, "fittableNonSingleton": 0}
1250	1855	{"_key": 1855, "groupID": 1855, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522062, "useBasePrice": 0, "fittableNonSingleton": 0}
1251	1856	{"_key": 1856, "groupID": 1856, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522063, "useBasePrice": 0, "fittableNonSingleton": 0}
1252	1857	{"_key": 1857, "groupID": 1857, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522064, "useBasePrice": 0, "fittableNonSingleton": 0}
1253	1858	{"_key": 1858, "groupID": 1858, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522065, "useBasePrice": 0, "fittableNonSingleton": 0}
1254	1859	{"_key": 1859, "groupID": 1859, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522066, "useBasePrice": 0, "fittableNonSingleton": 0}
1255	1860	{"_key": 1860, "groupID": 1860, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522067, "useBasePrice": 0, "fittableNonSingleton": 0}
1256	1861	{"_key": 1861, "groupID": 1861, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522068, "useBasePrice": 0, "fittableNonSingleton": 0}
1257	1862	{"_key": 1862, "groupID": 1862, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522069, "useBasePrice": 0, "fittableNonSingleton": 0}
1258	1863	{"_key": 1863, "groupID": 1863, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522070, "useBasePrice": 0, "fittableNonSingleton": 0}
1259	1864	{"_key": 1864, "groupID": 1864, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522071, "useBasePrice": 0, "fittableNonSingleton": 0}
1260	1865	{"_key": 1865, "groupID": 1865, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522072, "useBasePrice": 0, "fittableNonSingleton": 0}
1261	1866	{"_key": 1866, "groupID": 1866, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522073, "useBasePrice": 0, "fittableNonSingleton": 0}
1262	1867	{"_key": 1867, "groupID": 1867, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522074, "useBasePrice": 0, "fittableNonSingleton": 0}
1263	1868	{"_key": 1868, "groupID": 1868, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522075, "useBasePrice": 0, "fittableNonSingleton": 0}
1264	1869	{"_key": 1869, "groupID": 1869, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522076, "useBasePrice": 0, "fittableNonSingleton": 0}
1265	1870	{"_key": 1870, "groupID": 1870, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 522077, "useBasePrice": 0, "fittableNonSingleton": 0}
1266	1872	{"_key": 1872, "groupID": 1872, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 523854, "useBasePrice": 0, "fittableNonSingleton": 0}
1267	1875	{"_key": 1875, "groupID": 1875, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 5, "groupNameID": 525202, "useBasePrice": 0, "fittableNonSingleton": 0}
1268	1876	{"_key": 1876, "groupID": 1876, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 65, "groupNameID": 525289, "useBasePrice": 0, "fittableNonSingleton": 0}
1269	1878	{"_key": 1878, "groupID": 1878, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 526125, "useBasePrice": 0, "fittableNonSingleton": 0}
1270	1879	{"_key": 1879, "groupID": 1879, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 526124, "useBasePrice": 0, "fittableNonSingleton": 0}
1271	1880	{"_key": 1880, "groupID": 1880, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 526123, "useBasePrice": 0, "fittableNonSingleton": 0}
1272	1882	{"_key": 1882, "groupID": 1882, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 526235, "useBasePrice": 0, "fittableNonSingleton": 0}
1273	1884	{"_key": 1884, "iconID": 15, "groupID": 1884, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 526296, "useBasePrice": 0, "fittableNonSingleton": 0}
1274	1886	{"_key": 1886, "iconID": 0, "groupID": 1886, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 526463, "useBasePrice": 0, "fittableNonSingleton": 0}
1275	1887	{"_key": 1887, "groupID": 1887, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 526632, "useBasePrice": 0, "fittableNonSingleton": 0}
1276	1888	{"_key": 1888, "groupID": 1888, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 526843, "useBasePrice": 1, "fittableNonSingleton": 0}
1277	1889	{"_key": 1889, "groupID": 1889, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 526844, "useBasePrice": 1, "fittableNonSingleton": 0}
1278	1890	{"_key": 1890, "groupID": 1890, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 526846, "useBasePrice": 1, "fittableNonSingleton": 0}
1279	1891	{"_key": 1891, "groupID": 1891, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 9, "groupNameID": 527146, "useBasePrice": 0, "fittableNonSingleton": 0}
1280	1894	{"_key": 1894, "iconID": 0, "groupID": 1894, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 527203, "useBasePrice": 0, "fittableNonSingleton": 0}
1281	1895	{"_key": 1895, "groupID": 1895, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 527940, "useBasePrice": 0, "fittableNonSingleton": 0}
1282	1896	{"_key": 1896, "groupID": 1896, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 528285, "useBasePrice": 0, "fittableNonSingleton": 0}
1283	1909	{"_key": 1909, "groupID": 1909, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 528350, "useBasePrice": 0, "fittableNonSingleton": 0}
1284	1911	{"_key": 1911, "groupID": 1911, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 25, "groupNameID": 528621, "useBasePrice": 0, "fittableNonSingleton": 0}
1285	1912	{"_key": 1912, "groupID": 1912, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 529224, "useBasePrice": 0, "fittableNonSingleton": 0}
1286	1913	{"_key": 1913, "groupID": 1913, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 529225, "useBasePrice": 0, "fittableNonSingleton": 0}
1287	1914	{"_key": 1914, "groupID": 1914, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 529230, "useBasePrice": 0, "fittableNonSingleton": 0}
1288	1915	{"_key": 1915, "groupID": 1915, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 529250, "useBasePrice": 0, "fittableNonSingleton": 0}
1289	1920	{"_key": 1920, "iconID": 15, "groupID": 1920, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 529385, "useBasePrice": 0, "fittableNonSingleton": 0}
1290	1921	{"_key": 1921, "iconID": 15, "groupID": 1921, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 529386, "useBasePrice": 0, "fittableNonSingleton": 0}
1291	1922	{"_key": 1922, "iconID": 15, "groupID": 1922, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 529387, "useBasePrice": 0, "fittableNonSingleton": 0}
1292	1923	{"_key": 1923, "iconID": 15, "groupID": 1923, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 529388, "useBasePrice": 0, "fittableNonSingleton": 0}
1293	1924	{"_key": 1924, "groupID": 1924, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 65, "groupNameID": 529405, "useBasePrice": 0, "fittableNonSingleton": 0}
1294	1925	{"_key": 1925, "groupID": 1925, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 529459, "useBasePrice": 0, "fittableNonSingleton": 0}
1295	1926	{"_key": 1926, "groupID": 1926, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 529460, "useBasePrice": 0, "fittableNonSingleton": 0}
1296	1927	{"_key": 1927, "groupID": 1927, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 529461, "useBasePrice": 0, "fittableNonSingleton": 0}
1297	1928	{"_key": 1928, "groupID": 1928, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 529462, "useBasePrice": 0, "fittableNonSingleton": 0}
1298	1929	{"_key": 1929, "groupID": 1929, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 529463, "useBasePrice": 0, "fittableNonSingleton": 0}
1299	1933	{"_key": 1933, "groupID": 1933, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 529745, "useBasePrice": 0, "fittableNonSingleton": 0}
1300	1934	{"_key": 1934, "groupID": 1934, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 529746, "useBasePrice": 0, "fittableNonSingleton": 0}
1301	1935	{"_key": 1935, "groupID": 1935, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 529747, "useBasePrice": 0, "fittableNonSingleton": 0}
1302	1936	{"_key": 1936, "groupID": 1936, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 529748, "useBasePrice": 0, "fittableNonSingleton": 0}
1303	1937	{"_key": 1937, "groupID": 1937, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 529749, "useBasePrice": 0, "fittableNonSingleton": 0}
1304	1938	{"_key": 1938, "groupID": 1938, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 529750, "useBasePrice": 0, "fittableNonSingleton": 0}
1305	1939	{"_key": 1939, "groupID": 1939, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 529751, "useBasePrice": 0, "fittableNonSingleton": 0}
1306	1940	{"_key": 1940, "groupID": 1940, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 529956, "useBasePrice": 0, "fittableNonSingleton": 0}
1307	1941	{"_key": 1941, "groupID": 1941, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 530204, "useBasePrice": 0, "fittableNonSingleton": 0}
1308	1942	{"_key": 1942, "groupID": 1942, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 530205, "useBasePrice": 0, "fittableNonSingleton": 0}
1309	1943	{"_key": 1943, "groupID": 1943, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 530206, "useBasePrice": 0, "fittableNonSingleton": 0}
1310	1944	{"_key": 1944, "groupID": 1944, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 530207, "useBasePrice": 0, "fittableNonSingleton": 0}
1311	1945	{"_key": 1945, "groupID": 1945, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 530208, "useBasePrice": 0, "fittableNonSingleton": 0}
1312	1948	{"_key": 1948, "iconID": 0, "groupID": 1948, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 531101, "useBasePrice": 0, "fittableNonSingleton": 0}
1313	1950	{"_key": 1950, "groupID": 1950, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 91, "groupNameID": 531346, "useBasePrice": 0, "fittableNonSingleton": 0}
1314	1951	{"_key": 1951, "groupID": 1951, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 91, "groupNameID": 531348, "useBasePrice": 0, "fittableNonSingleton": 0}
1315	1952	{"_key": 1952, "groupID": 1952, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 91, "groupNameID": 531349, "useBasePrice": 0, "fittableNonSingleton": 0}
1316	1953	{"_key": 1953, "groupID": 1953, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 91, "groupNameID": 531350, "useBasePrice": 0, "fittableNonSingleton": 0}
1317	1954	{"_key": 1954, "groupID": 1954, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 91, "groupNameID": 531351, "useBasePrice": 0, "fittableNonSingleton": 0}
1318	1955	{"_key": 1955, "groupID": 1955, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 91, "groupNameID": 531352, "useBasePrice": 0, "fittableNonSingleton": 0}
1319	1956	{"_key": 1956, "groupID": 1956, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 531454, "useBasePrice": 0, "fittableNonSingleton": 0}
1320	1962	{"_key": 1962, "groupID": 1962, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 532364, "useBasePrice": 0, "fittableNonSingleton": 0}
1321	1964	{"_key": 1964, "groupID": 1964, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 532367, "useBasePrice": 0, "fittableNonSingleton": 0}
1322	1966	{"_key": 1966, "groupID": 1966, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 532473, "useBasePrice": 0, "fittableNonSingleton": 0}
1323	1967	{"_key": 1967, "iconID": 26455, "groupID": 1967, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 532474, "useBasePrice": 0, "fittableNonSingleton": 0}
1324	1968	{"_key": 1968, "groupID": 1968, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 532475, "useBasePrice": 0, "fittableNonSingleton": 0}
1325	1969	{"_key": 1969, "groupID": 1969, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 532741, "useBasePrice": 0, "fittableNonSingleton": 0}
1326	1971	{"_key": 1971, "groupID": 1971, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 532779, "useBasePrice": 0, "fittableNonSingleton": 0}
1327	1972	{"_key": 1972, "groupID": 1972, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 532793, "useBasePrice": 0, "fittableNonSingleton": 0}
1328	1973	{"_key": 1973, "groupID": 1973, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 532858, "useBasePrice": 0, "fittableNonSingleton": 0}
1329	1974	{"_key": 1974, "groupID": 1974, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 532880, "useBasePrice": 0, "fittableNonSingleton": 0}
1330	1975	{"_key": 1975, "groupID": 1975, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 532897, "useBasePrice": 0, "fittableNonSingleton": 0}
1331	1976	{"_key": 1976, "groupID": 1976, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 533138, "useBasePrice": 0, "fittableNonSingleton": 1}
1332	1977	{"_key": 1977, "groupID": 1977, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 17, "groupNameID": 533608, "useBasePrice": 0, "fittableNonSingleton": 0}
1333	1978	{"_key": 1978, "groupID": 1978, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 534589, "useBasePrice": 0, "fittableNonSingleton": 0}
1334	1979	{"_key": 1979, "groupID": 1979, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 534967, "useBasePrice": 0, "fittableNonSingleton": 0}
1335	1980	{"_key": 1980, "groupID": 1980, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 534978, "useBasePrice": 0, "fittableNonSingleton": 0}
1336	1981	{"_key": 1981, "groupID": 1981, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 535050, "useBasePrice": 0, "fittableNonSingleton": 0}
1337	1982	{"_key": 1982, "groupID": 1982, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 535182, "useBasePrice": 0, "fittableNonSingleton": 0}
1338	1983	{"_key": 1983, "groupID": 1983, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 535250, "useBasePrice": 0, "fittableNonSingleton": 0}
1339	1984	{"_key": 1984, "groupID": 1984, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 535351, "useBasePrice": 0, "fittableNonSingleton": 0}
1340	1986	{"_key": 1986, "groupID": 1986, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 535357, "useBasePrice": 0, "fittableNonSingleton": 0}
1341	1987	{"_key": 1987, "groupID": 1987, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 535358, "useBasePrice": 0, "fittableNonSingleton": 0}
1342	1988	{"_key": 1988, "groupID": 1988, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 535393, "useBasePrice": 0, "fittableNonSingleton": 0}
1343	1989	{"_key": 1989, "groupID": 1989, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 535425, "useBasePrice": 0, "fittableNonSingleton": 0}
1344	1990	{"_key": 1990, "groupID": 1990, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 535694, "useBasePrice": 1, "fittableNonSingleton": 0}
1345	1991	{"_key": 1991, "groupID": 1991, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 536427, "useBasePrice": 0, "fittableNonSingleton": 0}
1346	1992	{"_key": 1992, "groupID": 1992, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 536430, "useBasePrice": 1, "fittableNonSingleton": 0}
1347	1993	{"_key": 1993, "groupID": 1993, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 536432, "useBasePrice": 1, "fittableNonSingleton": 0}
1348	1994	{"_key": 1994, "groupID": 1994, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 536433, "useBasePrice": 1, "fittableNonSingleton": 0}
1349	1995	{"_key": 1995, "groupID": 1995, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 536625, "useBasePrice": 1, "fittableNonSingleton": 0}
1350	1996	{"_key": 1996, "groupID": 1996, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 4, "groupNameID": 536626, "useBasePrice": 0, "fittableNonSingleton": 0}
1351	1997	{"_key": 1997, "groupID": 1997, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 536644, "useBasePrice": 0, "fittableNonSingleton": 0}
1352	1998	{"_key": 1998, "groupID": 1998, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 537031, "useBasePrice": 0, "fittableNonSingleton": 0}
1353	2001	{"_key": 2001, "groupID": 2001, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 6, "groupNameID": 539344, "useBasePrice": 0, "fittableNonSingleton": 0}
1354	2002	{"_key": 2002, "groupID": 2002, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 17, "groupNameID": 540058, "useBasePrice": 0, "fittableNonSingleton": 0}
1355	2003	{"_key": 2003, "groupID": 2003, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 540203, "useBasePrice": 0, "fittableNonSingleton": 0}
1356	2004	{"_key": 2004, "groupID": 2004, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 540917, "useBasePrice": 0, "fittableNonSingleton": 0}
1357	2005	{"_key": 2005, "groupID": 2005, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 22, "groupNameID": 540934, "useBasePrice": 0, "fittableNonSingleton": 0}
1358	2006	{"_key": 2006, "groupID": 2006, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 25, "groupNameID": 540968, "useBasePrice": 0, "fittableNonSingleton": 0}
1359	2008	{"_key": 2008, "iconID": 97, "groupID": 2008, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 541740, "useBasePrice": 0, "fittableNonSingleton": 0}
1360	2009	{"_key": 2009, "iconID": 0, "groupID": 2009, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 541741, "useBasePrice": 0, "fittableNonSingleton": 0}
1361	2010	{"_key": 2010, "iconID": 0, "groupID": 2010, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 541742, "useBasePrice": 1, "fittableNonSingleton": 0}
1362	2013	{"_key": 2013, "groupID": 2013, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 542675, "useBasePrice": 0, "fittableNonSingleton": 0}
1363	2015	{"_key": 2015, "groupID": 2015, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 65, "groupNameID": 542786, "useBasePrice": 0, "fittableNonSingleton": 0}
1364	2016	{"_key": 2016, "groupID": 2016, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 65, "groupNameID": 542787, "useBasePrice": 0, "fittableNonSingleton": 0}
1365	2017	{"_key": 2017, "groupID": 2017, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 65, "groupNameID": 542788, "useBasePrice": 0, "fittableNonSingleton": 0}
1366	2018	{"_key": 2018, "iconID": 0, "groupID": 2018, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 543772, "useBasePrice": 0, "fittableNonSingleton": 0}
1367	2019	{"_key": 2019, "iconID": 0, "groupID": 2019, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 543773, "useBasePrice": 1, "fittableNonSingleton": 0}
1368	2020	{"_key": 2020, "groupID": 2020, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 543951, "useBasePrice": 0, "fittableNonSingleton": 0}
1369	2022	{"_key": 2022, "groupID": 2022, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 25, "groupNameID": 544772, "useBasePrice": 1, "fittableNonSingleton": 0}
1370	2023	{"_key": 2023, "iconID": 0, "groupID": 2023, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 545577, "useBasePrice": 0, "fittableNonSingleton": 0}
1371	2024	{"_key": 2024, "groupID": 2024, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 25, "groupNameID": 545621, "useBasePrice": 0, "fittableNonSingleton": 0}
1372	2026	{"_key": 2026, "groupID": 2026, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 17, "groupNameID": 546328, "useBasePrice": 0, "fittableNonSingleton": 0}
1373	4028	{"_key": 4028, "groupID": 4028, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 549007, "useBasePrice": 0, "fittableNonSingleton": 0}
1374	4029	{"_key": 4029, "groupID": 4029, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 549008, "useBasePrice": 0, "fittableNonSingleton": 0}
1375	4030	{"_key": 4030, "groupID": 4030, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 549009, "useBasePrice": 0, "fittableNonSingleton": 0}
1376	4031	{"_key": 4031, "groupID": 4031, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 549010, "useBasePrice": 0, "fittableNonSingleton": 0}
1377	4033	{"_key": 4033, "groupID": 4033, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 551791, "useBasePrice": 0, "fittableNonSingleton": 0}
1378	4034	{"_key": 4034, "groupID": 4034, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 552396, "useBasePrice": 0, "fittableNonSingleton": 0}
1379	4035	{"_key": 4035, "groupID": 4035, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 552397, "useBasePrice": 0, "fittableNonSingleton": 0}
1380	4036	{"_key": 4036, "groupID": 4036, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 552398, "useBasePrice": 0, "fittableNonSingleton": 0}
1381	4037	{"_key": 4037, "groupID": 4037, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 552399, "useBasePrice": 0, "fittableNonSingleton": 0}
1382	4040	{"_key": 4040, "groupID": 4040, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 91, "groupNameID": 553262, "useBasePrice": 0, "fittableNonSingleton": 0}
1383	4041	{"_key": 4041, "groupID": 4041, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 553695, "useBasePrice": 0, "fittableNonSingleton": 0}
1384	4050	{"_key": 4050, "groupID": 4050, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 17, "groupNameID": 559431, "useBasePrice": 0, "fittableNonSingleton": 0}
1385	4052	{"_key": 4052, "groupID": 4052, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 560666, "useBasePrice": 0, "fittableNonSingleton": 0}
1386	4053	{"_key": 4053, "groupID": 4053, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 561629, "useBasePrice": 0, "fittableNonSingleton": 0}
1387	4055	{"_key": 4055, "groupID": 4055, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 562903, "useBasePrice": 0, "fittableNonSingleton": 0}
1388	4057	{"_key": 4057, "groupID": 4057, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 30, "groupNameID": 563630, "useBasePrice": 0, "fittableNonSingleton": 0}
1389	4060	{"_key": 4060, "groupID": 4060, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 563701, "useBasePrice": 0, "fittableNonSingleton": 0}
1390	4061	{"_key": 4061, "groupID": 4061, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 563793, "useBasePrice": 0, "fittableNonSingleton": 0}
1391	4062	{"_key": 4062, "groupID": 4062, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 563792, "useBasePrice": 0, "fittableNonSingleton": 0}
1392	4064	{"_key": 4064, "groupID": 4064, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 564057, "useBasePrice": 0, "fittableNonSingleton": 0}
1393	4065	{"_key": 4065, "groupID": 4065, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 564058, "useBasePrice": 0, "fittableNonSingleton": 0}
1394	4066	{"_key": 4066, "groupID": 4066, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 564059, "useBasePrice": 0, "fittableNonSingleton": 0}
1395	4067	{"_key": 4067, "groupID": 4067, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 564488, "useBasePrice": 0, "fittableNonSingleton": 0}
1396	4069	{"_key": 4069, "groupID": 4069, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 564489, "useBasePrice": 0, "fittableNonSingleton": 0}
1397	4070	{"_key": 4070, "groupID": 4070, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2, "groupNameID": 564553, "useBasePrice": 0, "fittableNonSingleton": 0}
1398	4071	{"_key": 4071, "groupID": 4071, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 29, "groupNameID": 567090, "useBasePrice": 0, "fittableNonSingleton": 0}
1399	4072	{"_key": 4072, "groupID": 4072, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 567348, "useBasePrice": 0, "fittableNonSingleton": 0}
1400	4073	{"_key": 4073, "iconID": 0, "groupID": 4073, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 567507, "useBasePrice": 0, "fittableNonSingleton": 0}
1401	4079	{"_key": 4079, "groupID": 4079, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 2, "groupNameID": 567933, "useBasePrice": 0, "fittableNonSingleton": 0}
1402	4081	{"_key": 4081, "groupID": 4081, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 568254, "useBasePrice": 0, "fittableNonSingleton": 0}
1403	4086	{"_key": 4086, "groupID": 4086, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 66, "groupNameID": 569641, "useBasePrice": 1, "fittableNonSingleton": 0}
1404	4087	{"_key": 4087, "groupID": 4087, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 571069, "useBasePrice": 1, "fittableNonSingleton": 0}
1405	4088	{"_key": 4088, "iconID": 1721, "groupID": 4088, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 571813, "useBasePrice": 0, "fittableNonSingleton": 1}
1406	4090	{"_key": 4090, "groupID": 4090, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2100, "groupNameID": 573417, "useBasePrice": 0, "fittableNonSingleton": 0}
1407	4091	{"_key": 4091, "groupID": 4091, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2100, "groupNameID": 573608, "useBasePrice": 0, "fittableNonSingleton": 0}
1408	4093	{"_key": 4093, "groupID": 4093, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 22, "groupNameID": 574152, "useBasePrice": 0, "fittableNonSingleton": 0}
1409	4094	{"_key": 4094, "groupID": 4094, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 25, "groupNameID": 574662, "useBasePrice": 0, "fittableNonSingleton": 0}
1410	4095	{"_key": 4095, "groupID": 4095, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 574835, "useBasePrice": 1, "fittableNonSingleton": 0}
1411	4096	{"_key": 4096, "groupID": 4096, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 4, "groupNameID": 575002, "useBasePrice": 1, "fittableNonSingleton": 0}
1412	4097	{"_key": 4097, "groupID": 4097, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 575003, "useBasePrice": 1, "fittableNonSingleton": 0}
1413	4098	{"_key": 4098, "groupID": 4098, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2100, "groupNameID": 575183, "useBasePrice": 0, "fittableNonSingleton": 0}
1414	4100	{"_key": 4100, "groupID": 4100, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 575536, "useBasePrice": 0, "fittableNonSingleton": 0}
1415	4102	{"_key": 4102, "groupID": 4102, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 575815, "useBasePrice": 0, "fittableNonSingleton": 0}
1416	4105	{"_key": 4105, "groupID": 4105, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 576839, "useBasePrice": 0, "fittableNonSingleton": 0}
1417	4106	{"_key": 4106, "groupID": 4106, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 576840, "useBasePrice": 0, "fittableNonSingleton": 0}
1418	4107	{"_key": 4107, "groupID": 4107, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 22, "groupNameID": 580887, "useBasePrice": 0, "fittableNonSingleton": 0}
1419	4108	{"_key": 4108, "groupID": 4108, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 580889, "useBasePrice": 1, "fittableNonSingleton": 0}
1420	4117	{"_key": 4117, "groupID": 4117, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 581418, "useBasePrice": 0, "fittableNonSingleton": 0}
1421	4118	{"_key": 4118, "iconID": 0, "groupID": 4118, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 581436, "useBasePrice": 1, "fittableNonSingleton": 0}
1422	4127	{"_key": 4127, "iconID": 0, "groupID": 4127, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 582723, "useBasePrice": 0, "fittableNonSingleton": 0}
1423	4128	{"_key": 4128, "groupID": 4128, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 582726, "useBasePrice": 0, "fittableNonSingleton": 0}
1424	4129	{"_key": 4129, "iconID": 0, "groupID": 4129, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 586226, "useBasePrice": 0, "fittableNonSingleton": 0}
1425	4130	{"_key": 4130, "groupID": 4130, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 583913, "useBasePrice": 0, "fittableNonSingleton": 0}
1426	4137	{"_key": 4137, "groupID": 4137, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 22, "groupNameID": 586787, "useBasePrice": 1, "fittableNonSingleton": 0}
1427	4138	{"_key": 4138, "groupID": 4138, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 587196, "useBasePrice": 0, "fittableNonSingleton": 0}
1428	4139	{"_key": 4139, "groupID": 4139, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 587314, "useBasePrice": 1, "fittableNonSingleton": 0}
1429	4141	{"_key": 4141, "groupID": 4141, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 588137, "useBasePrice": 1, "fittableNonSingleton": 0}
1430	4142	{"_key": 4142, "groupID": 4142, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 588315, "useBasePrice": 1, "fittableNonSingleton": 0}
1431	4145	{"_key": 4145, "groupID": 4145, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 17, "groupNameID": 588713, "useBasePrice": 1, "fittableNonSingleton": 0}
1432	4147	{"_key": 4147, "iconID": 0, "groupID": 4147, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 18, "groupNameID": 589718, "useBasePrice": 0, "fittableNonSingleton": 0}
1433	4151	{"_key": 4151, "groupID": 4151, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 590531, "useBasePrice": 0, "fittableNonSingleton": 0}
1434	4153	{"_key": 4153, "groupID": 4153, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 590910, "useBasePrice": 0, "fittableNonSingleton": 0}
1435	4158	{"_key": 4158, "groupID": 4158, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 591265, "useBasePrice": 0, "fittableNonSingleton": 0}
1436	4159	{"_key": 4159, "groupID": 4159, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 591699, "useBasePrice": 0, "fittableNonSingleton": 0}
1437	4160	{"_key": 4160, "groupID": 4160, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 601201, "useBasePrice": 0, "fittableNonSingleton": 0}
1438	4161	{"_key": 4161, "groupID": 4161, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 25, "groupNameID": 592233, "useBasePrice": 1, "fittableNonSingleton": 0}
1439	4162	{"_key": 4162, "iconID": 25070, "groupID": 4162, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 4, "groupNameID": 592324, "useBasePrice": 0, "fittableNonSingleton": 0}
1440	4163	{"_key": 4163, "iconID": 10159, "groupID": 4163, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 640512, "useBasePrice": 0, "fittableNonSingleton": 0}
1441	4165	{"_key": 4165, "groupID": 4165, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 592992, "useBasePrice": 1, "fittableNonSingleton": 0}
1442	4166	{"_key": 4166, "groupID": 4166, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 593062, "useBasePrice": 1, "fittableNonSingleton": 0}
1443	4168	{"_key": 4168, "iconID": 25169, "groupID": 4168, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2, "groupNameID": 594612, "useBasePrice": 0, "fittableNonSingleton": 0}
1444	4174	{"_key": 4174, "iconID": 25152, "groupID": 4174, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 595063, "useBasePrice": 1, "fittableNonSingleton": 0}
1445	4175	{"_key": 4175, "groupID": 4175, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 595230, "useBasePrice": 1, "fittableNonSingleton": 0}
1446	4181	{"_key": 4181, "groupID": 4181, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 6, "groupNameID": 596545, "useBasePrice": 0, "fittableNonSingleton": 0}
1447	4182	{"_key": 4182, "groupID": 4182, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 6, "groupNameID": 596546, "useBasePrice": 0, "fittableNonSingleton": 0}
1448	4183	{"_key": 4183, "groupID": 4183, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 6, "groupNameID": 596547, "useBasePrice": 0, "fittableNonSingleton": 0}
1449	4184	{"_key": 4184, "iconID": 0, "groupID": 4184, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 596753, "useBasePrice": 0, "fittableNonSingleton": 0}
1450	4186	{"_key": 4186, "iconID": 1304, "groupID": 4186, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 597623, "useBasePrice": 0, "fittableNonSingleton": 1}
1451	4188	{"_key": 4188, "groupID": 4188, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 597627, "useBasePrice": 1, "fittableNonSingleton": 0}
1452	4194	{"_key": 4194, "groupID": 4194, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 600082, "useBasePrice": 0, "fittableNonSingleton": 0}
1453	4196	{"_key": 4196, "groupID": 4196, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 16, "groupNameID": 600456, "useBasePrice": 0, "fittableNonSingleton": 0}
1454	4197	{"_key": 4197, "groupID": 4197, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 609215, "useBasePrice": 0, "fittableNonSingleton": 0}
1455	4201	{"_key": 4201, "groupID": 4201, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 17, "groupNameID": 609694, "useBasePrice": 0, "fittableNonSingleton": 0}
1456	4202	{"_key": 4202, "groupID": 4202, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 610307, "useBasePrice": 0, "fittableNonSingleton": 0}
1457	4210	{"_key": 4210, "groupID": 4210, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 611503, "useBasePrice": 0, "fittableNonSingleton": 0}
1458	4211	{"_key": 4211, "groupID": 4211, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 611510, "useBasePrice": 0, "fittableNonSingleton": 0}
1459	4212	{"_key": 4212, "groupID": 4212, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 611516, "useBasePrice": 0, "fittableNonSingleton": 0}
1460	4213	{"_key": 4213, "groupID": 4213, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 611531, "useBasePrice": 0, "fittableNonSingleton": 0}
1461	4214	{"_key": 4214, "groupID": 4214, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 611547, "useBasePrice": 0, "fittableNonSingleton": 0}
1462	4215	{"_key": 4215, "groupID": 4215, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 611555, "useBasePrice": 0, "fittableNonSingleton": 0}
1463	4216	{"_key": 4216, "groupID": 4216, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 611571, "useBasePrice": 0, "fittableNonSingleton": 0}
1464	4217	{"_key": 4217, "groupID": 4217, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 611585, "useBasePrice": 0, "fittableNonSingleton": 0}
1465	4218	{"_key": 4218, "groupID": 4218, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 611602, "useBasePrice": 0, "fittableNonSingleton": 0}
1466	4219	{"_key": 4219, "groupID": 4219, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 611623, "useBasePrice": 0, "fittableNonSingleton": 0}
1467	4220	{"_key": 4220, "groupID": 4220, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2113, "groupNameID": 611630, "useBasePrice": 0, "fittableNonSingleton": 0}
1468	4221	{"_key": 4221, "groupID": 4221, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 611664, "useBasePrice": 0, "fittableNonSingleton": 0}
1469	4222	{"_key": 4222, "groupID": 4222, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 611843, "useBasePrice": 0, "fittableNonSingleton": 0}
1470	4223	{"_key": 4223, "groupID": 4223, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 611981, "useBasePrice": 0, "fittableNonSingleton": 0}
1471	4224	{"_key": 4224, "groupID": 4224, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612134, "useBasePrice": 0, "fittableNonSingleton": 0}
1472	4225	{"_key": 4225, "groupID": 4225, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2113, "groupNameID": 612184, "useBasePrice": 0, "fittableNonSingleton": 0}
1473	4226	{"_key": 4226, "groupID": 4226, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612189, "useBasePrice": 0, "fittableNonSingleton": 0}
1474	4227	{"_key": 4227, "groupID": 4227, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612210, "useBasePrice": 0, "fittableNonSingleton": 0}
1475	4228	{"_key": 4228, "groupID": 4228, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612254, "useBasePrice": 0, "fittableNonSingleton": 0}
1476	4229	{"_key": 4229, "groupID": 4229, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612294, "useBasePrice": 0, "fittableNonSingleton": 0}
1477	4230	{"_key": 4230, "groupID": 4230, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612330, "useBasePrice": 0, "fittableNonSingleton": 0}
1478	4231	{"_key": 4231, "groupID": 4231, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612339, "useBasePrice": 0, "fittableNonSingleton": 0}
1479	4232	{"_key": 4232, "groupID": 4232, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612383, "useBasePrice": 0, "fittableNonSingleton": 0}
1480	4233	{"_key": 4233, "groupID": 4233, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612432, "useBasePrice": 0, "fittableNonSingleton": 0}
1481	4234	{"_key": 4234, "groupID": 4234, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612441, "useBasePrice": 0, "fittableNonSingleton": 0}
1482	4235	{"_key": 4235, "groupID": 4235, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612473, "useBasePrice": 0, "fittableNonSingleton": 0}
1483	4236	{"_key": 4236, "groupID": 4236, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612490, "useBasePrice": 0, "fittableNonSingleton": 0}
1484	4237	{"_key": 4237, "groupID": 4237, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612516, "useBasePrice": 0, "fittableNonSingleton": 0}
1485	4238	{"_key": 4238, "groupID": 4238, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612530, "useBasePrice": 0, "fittableNonSingleton": 0}
1486	4239	{"_key": 4239, "groupID": 4239, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612540, "useBasePrice": 0, "fittableNonSingleton": 0}
1487	4240	{"_key": 4240, "groupID": 4240, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612555, "useBasePrice": 0, "fittableNonSingleton": 0}
1488	4241	{"_key": 4241, "groupID": 4241, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612570, "useBasePrice": 0, "fittableNonSingleton": 0}
1489	4242	{"_key": 4242, "groupID": 4242, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612593, "useBasePrice": 0, "fittableNonSingleton": 0}
1490	4243	{"_key": 4243, "groupID": 4243, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612620, "useBasePrice": 0, "fittableNonSingleton": 0}
1491	4244	{"_key": 4244, "groupID": 4244, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612642, "useBasePrice": 0, "fittableNonSingleton": 0}
1492	4245	{"_key": 4245, "groupID": 4245, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612667, "useBasePrice": 0, "fittableNonSingleton": 0}
1493	4246	{"_key": 4246, "groupID": 4246, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612678, "useBasePrice": 0, "fittableNonSingleton": 0}
1494	4247	{"_key": 4247, "groupID": 4247, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612685, "useBasePrice": 0, "fittableNonSingleton": 0}
1495	4248	{"_key": 4248, "groupID": 4248, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612702, "useBasePrice": 0, "fittableNonSingleton": 0}
1496	4249	{"_key": 4249, "groupID": 4249, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612721, "useBasePrice": 0, "fittableNonSingleton": 0}
1497	4250	{"_key": 4250, "groupID": 4250, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612738, "useBasePrice": 0, "fittableNonSingleton": 0}
1498	4251	{"_key": 4251, "groupID": 4251, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612778, "useBasePrice": 0, "fittableNonSingleton": 0}
1499	4252	{"_key": 4252, "groupID": 4252, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612792, "useBasePrice": 0, "fittableNonSingleton": 0}
1500	4253	{"_key": 4253, "groupID": 4253, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612801, "useBasePrice": 0, "fittableNonSingleton": 0}
1501	4254	{"_key": 4254, "groupID": 4254, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612810, "useBasePrice": 0, "fittableNonSingleton": 0}
1502	4255	{"_key": 4255, "groupID": 4255, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612824, "useBasePrice": 0, "fittableNonSingleton": 0}
1503	4256	{"_key": 4256, "groupID": 4256, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612838, "useBasePrice": 0, "fittableNonSingleton": 0}
1504	4257	{"_key": 4257, "groupID": 4257, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612846, "useBasePrice": 0, "fittableNonSingleton": 0}
1505	4258	{"_key": 4258, "groupID": 4258, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612851, "useBasePrice": 0, "fittableNonSingleton": 0}
1506	4259	{"_key": 4259, "groupID": 4259, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612868, "useBasePrice": 1, "fittableNonSingleton": 0}
1507	4260	{"_key": 4260, "groupID": 4260, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612875, "useBasePrice": 0, "fittableNonSingleton": 0}
1508	4261	{"_key": 4261, "groupID": 4261, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612891, "useBasePrice": 0, "fittableNonSingleton": 0}
1509	4262	{"_key": 4262, "groupID": 4262, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612902, "useBasePrice": 0, "fittableNonSingleton": 0}
1510	4263	{"_key": 4263, "groupID": 4263, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612908, "useBasePrice": 0, "fittableNonSingleton": 0}
1511	4264	{"_key": 4264, "groupID": 4264, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 612936, "useBasePrice": 0, "fittableNonSingleton": 0}
1512	4265	{"_key": 4265, "groupID": 4265, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613006, "useBasePrice": 0, "fittableNonSingleton": 0}
1513	4266	{"_key": 4266, "groupID": 4266, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613044, "useBasePrice": 0, "fittableNonSingleton": 0}
1514	4267	{"_key": 4267, "groupID": 4267, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613049, "useBasePrice": 0, "fittableNonSingleton": 0}
1515	4268	{"_key": 4268, "groupID": 4268, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613093, "useBasePrice": 0, "fittableNonSingleton": 0}
1516	4269	{"_key": 4269, "groupID": 4269, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613102, "useBasePrice": 0, "fittableNonSingleton": 0}
1517	4270	{"_key": 4270, "groupID": 4270, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613136, "useBasePrice": 0, "fittableNonSingleton": 0}
1518	4271	{"_key": 4271, "groupID": 4271, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613144, "useBasePrice": 0, "fittableNonSingleton": 0}
1519	4272	{"_key": 4272, "groupID": 4272, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613169, "useBasePrice": 0, "fittableNonSingleton": 0}
1520	4273	{"_key": 4273, "groupID": 4273, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613183, "useBasePrice": 0, "fittableNonSingleton": 0}
1521	4274	{"_key": 4274, "groupID": 4274, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613199, "useBasePrice": 0, "fittableNonSingleton": 0}
1522	4275	{"_key": 4275, "groupID": 4275, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613214, "useBasePrice": 0, "fittableNonSingleton": 0}
1523	4276	{"_key": 4276, "groupID": 4276, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613228, "useBasePrice": 0, "fittableNonSingleton": 0}
1524	4277	{"_key": 4277, "groupID": 4277, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613232, "useBasePrice": 0, "fittableNonSingleton": 0}
1525	4278	{"_key": 4278, "groupID": 4278, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613250, "useBasePrice": 0, "fittableNonSingleton": 0}
1526	4279	{"_key": 4279, "groupID": 4279, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613262, "useBasePrice": 0, "fittableNonSingleton": 0}
1527	4280	{"_key": 4280, "groupID": 4280, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613276, "useBasePrice": 0, "fittableNonSingleton": 0}
1528	4281	{"_key": 4281, "groupID": 4281, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613290, "useBasePrice": 0, "fittableNonSingleton": 0}
1529	4282	{"_key": 4282, "groupID": 4282, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613304, "useBasePrice": 0, "fittableNonSingleton": 0}
1530	4283	{"_key": 4283, "groupID": 4283, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613314, "useBasePrice": 0, "fittableNonSingleton": 0}
1531	4284	{"_key": 4284, "groupID": 4284, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613327, "useBasePrice": 0, "fittableNonSingleton": 0}
1532	4285	{"_key": 4285, "groupID": 4285, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613332, "useBasePrice": 0, "fittableNonSingleton": 0}
1533	4286	{"_key": 4286, "groupID": 4286, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613355, "useBasePrice": 0, "fittableNonSingleton": 0}
1534	4287	{"_key": 4287, "groupID": 4287, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2113, "groupNameID": 613369, "useBasePrice": 0, "fittableNonSingleton": 0}
1535	4288	{"_key": 4288, "groupID": 4288, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2113, "groupNameID": 613375, "useBasePrice": 0, "fittableNonSingleton": 0}
1536	4289	{"_key": 4289, "groupID": 4289, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613376, "useBasePrice": 0, "fittableNonSingleton": 0}
1537	4290	{"_key": 4290, "groupID": 4290, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613421, "useBasePrice": 0, "fittableNonSingleton": 0}
1538	4291	{"_key": 4291, "groupID": 4291, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2113, "groupNameID": 613433, "useBasePrice": 0, "fittableNonSingleton": 0}
1539	4292	{"_key": 4292, "groupID": 4292, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2113, "groupNameID": 613435, "useBasePrice": 0, "fittableNonSingleton": 0}
1540	4293	{"_key": 4293, "groupID": 4293, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613437, "useBasePrice": 0, "fittableNonSingleton": 0}
1541	4294	{"_key": 4294, "groupID": 4294, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613441, "useBasePrice": 0, "fittableNonSingleton": 0}
1542	4295	{"_key": 4295, "groupID": 4295, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613536, "useBasePrice": 0, "fittableNonSingleton": 0}
1543	4296	{"_key": 4296, "groupID": 4296, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613538, "useBasePrice": 0, "fittableNonSingleton": 0}
1544	4297	{"_key": 4297, "groupID": 4297, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613551, "useBasePrice": 0, "fittableNonSingleton": 0}
1545	4298	{"_key": 4298, "groupID": 4298, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613638, "useBasePrice": 0, "fittableNonSingleton": 0}
1546	4299	{"_key": 4299, "groupID": 4299, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613781, "useBasePrice": 0, "fittableNonSingleton": 0}
1547	4300	{"_key": 4300, "groupID": 4300, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613851, "useBasePrice": 0, "fittableNonSingleton": 0}
1548	4301	{"_key": 4301, "groupID": 4301, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613871, "useBasePrice": 0, "fittableNonSingleton": 0}
1549	4302	{"_key": 4302, "groupID": 4302, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613893, "useBasePrice": 0, "fittableNonSingleton": 0}
1550	4303	{"_key": 4303, "groupID": 4303, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613925, "useBasePrice": 0, "fittableNonSingleton": 0}
1551	4304	{"_key": 4304, "groupID": 4304, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 613973, "useBasePrice": 0, "fittableNonSingleton": 0}
1552	4305	{"_key": 4305, "groupID": 4305, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 614010, "useBasePrice": 1, "fittableNonSingleton": 0}
1553	4306	{"_key": 4306, "groupID": 4306, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 614052, "useBasePrice": 0, "fittableNonSingleton": 0}
1554	4307	{"_key": 4307, "groupID": 4307, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 614108, "useBasePrice": 0, "fittableNonSingleton": 0}
1555	4308	{"_key": 4308, "groupID": 4308, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 614121, "useBasePrice": 0, "fittableNonSingleton": 0}
1556	4309	{"_key": 4309, "groupID": 4309, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 614145, "useBasePrice": 0, "fittableNonSingleton": 0}
1557	4310	{"_key": 4310, "groupID": 4310, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 614176, "useBasePrice": 0, "fittableNonSingleton": 0}
1558	4311	{"_key": 4311, "groupID": 4311, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 614406, "useBasePrice": 0, "fittableNonSingleton": 0}
1559	4312	{"_key": 4312, "groupID": 4312, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2113, "groupNameID": 614466, "useBasePrice": 0, "fittableNonSingleton": 0}
1560	4313	{"_key": 4313, "groupID": 4313, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 614469, "useBasePrice": 0, "fittableNonSingleton": 0}
1561	4314	{"_key": 4314, "groupID": 4314, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2113, "groupNameID": 614487, "useBasePrice": 0, "fittableNonSingleton": 0}
1562	4315	{"_key": 4315, "groupID": 4315, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 614550, "useBasePrice": 0, "fittableNonSingleton": 0}
1563	4316	{"_key": 4316, "groupID": 4316, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 614639, "useBasePrice": 0, "fittableNonSingleton": 0}
1564	4317	{"_key": 4317, "groupID": 4317, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 615083, "useBasePrice": 0, "fittableNonSingleton": 0}
1565	4318	{"_key": 4318, "groupID": 4318, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 615456, "useBasePrice": 0, "fittableNonSingleton": 0}
1566	4319	{"_key": 4319, "groupID": 4319, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 615618, "useBasePrice": 0, "fittableNonSingleton": 0}
1567	4320	{"_key": 4320, "groupID": 4320, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 615653, "useBasePrice": 0, "fittableNonSingleton": 0}
1568	4321	{"_key": 4321, "groupID": 4321, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 615717, "useBasePrice": 0, "fittableNonSingleton": 0}
1569	4322	{"_key": 4322, "groupID": 4322, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2113, "groupNameID": 615736, "useBasePrice": 0, "fittableNonSingleton": 0}
1570	4323	{"_key": 4323, "groupID": 4323, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2113, "groupNameID": 615749, "useBasePrice": 0, "fittableNonSingleton": 0}
1571	4324	{"_key": 4324, "groupID": 4324, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 615796, "useBasePrice": 0, "fittableNonSingleton": 0}
1572	4325	{"_key": 4325, "groupID": 4325, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 615860, "useBasePrice": 0, "fittableNonSingleton": 0}
1573	4326	{"_key": 4326, "groupID": 4326, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 615892, "useBasePrice": 0, "fittableNonSingleton": 0}
1574	4327	{"_key": 4327, "groupID": 4327, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616024, "useBasePrice": 0, "fittableNonSingleton": 0}
1575	4328	{"_key": 4328, "groupID": 4328, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616248, "useBasePrice": 0, "fittableNonSingleton": 0}
1576	4329	{"_key": 4329, "groupID": 4329, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616283, "useBasePrice": 0, "fittableNonSingleton": 0}
1577	4330	{"_key": 4330, "groupID": 4330, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616291, "useBasePrice": 0, "fittableNonSingleton": 0}
1578	4331	{"_key": 4331, "groupID": 4331, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616308, "useBasePrice": 0, "fittableNonSingleton": 0}
1579	4332	{"_key": 4332, "groupID": 4332, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616410, "useBasePrice": 0, "fittableNonSingleton": 0}
1580	4333	{"_key": 4333, "groupID": 4333, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616420, "useBasePrice": 0, "fittableNonSingleton": 0}
1581	4334	{"_key": 4334, "groupID": 4334, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2113, "groupNameID": 616424, "useBasePrice": 0, "fittableNonSingleton": 0}
1582	4335	{"_key": 4335, "groupID": 4335, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616428, "useBasePrice": 0, "fittableNonSingleton": 0}
1583	4336	{"_key": 4336, "groupID": 4336, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616436, "useBasePrice": 1, "fittableNonSingleton": 0}
1584	4337	{"_key": 4337, "groupID": 4337, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616464, "useBasePrice": 0, "fittableNonSingleton": 0}
1585	4338	{"_key": 4338, "groupID": 4338, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616467, "useBasePrice": 0, "fittableNonSingleton": 0}
1586	4339	{"_key": 4339, "groupID": 4339, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616531, "useBasePrice": 0, "fittableNonSingleton": 0}
1587	4340	{"_key": 4340, "groupID": 4340, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616814, "useBasePrice": 0, "fittableNonSingleton": 0}
1588	4341	{"_key": 4341, "groupID": 4341, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616829, "useBasePrice": 0, "fittableNonSingleton": 0}
1589	4342	{"_key": 4342, "groupID": 4342, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616843, "useBasePrice": 0, "fittableNonSingleton": 0}
1590	4343	{"_key": 4343, "groupID": 4343, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616852, "useBasePrice": 0, "fittableNonSingleton": 0}
1591	4344	{"_key": 4344, "groupID": 4344, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616868, "useBasePrice": 0, "fittableNonSingleton": 0}
1592	4345	{"_key": 4345, "groupID": 4345, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616890, "useBasePrice": 0, "fittableNonSingleton": 0}
1593	4346	{"_key": 4346, "groupID": 4346, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616898, "useBasePrice": 0, "fittableNonSingleton": 0}
1594	4347	{"_key": 4347, "groupID": 4347, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616912, "useBasePrice": 0, "fittableNonSingleton": 0}
1595	4348	{"_key": 4348, "groupID": 4348, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616919, "useBasePrice": 0, "fittableNonSingleton": 0}
1596	4349	{"_key": 4349, "groupID": 4349, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616965, "useBasePrice": 0, "fittableNonSingleton": 0}
1597	4350	{"_key": 4350, "groupID": 4350, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 616997, "useBasePrice": 0, "fittableNonSingleton": 0}
1598	4351	{"_key": 4351, "groupID": 4351, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 617043, "useBasePrice": 0, "fittableNonSingleton": 0}
1599	4352	{"_key": 4352, "groupID": 4352, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 617073, "useBasePrice": 0, "fittableNonSingleton": 0}
1600	4353	{"_key": 4353, "groupID": 4353, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 617113, "useBasePrice": 0, "fittableNonSingleton": 0}
1601	4354	{"_key": 4354, "groupID": 4354, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 617151, "useBasePrice": 0, "fittableNonSingleton": 0}
1602	4355	{"_key": 4355, "groupID": 4355, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 617155, "useBasePrice": 0, "fittableNonSingleton": 0}
1603	4356	{"_key": 4356, "groupID": 4356, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 617169, "useBasePrice": 0, "fittableNonSingleton": 0}
1604	4357	{"_key": 4357, "groupID": 4357, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 617204, "useBasePrice": 0, "fittableNonSingleton": 0}
1605	4358	{"_key": 4358, "groupID": 4358, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 617333, "useBasePrice": 0, "fittableNonSingleton": 0}
1606	4359	{"_key": 4359, "groupID": 4359, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 617346, "useBasePrice": 0, "fittableNonSingleton": 0}
1607	4360	{"_key": 4360, "groupID": 4360, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 617860, "useBasePrice": 0, "fittableNonSingleton": 0}
1608	4361	{"_key": 4361, "groupID": 4361, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 617900, "useBasePrice": 0, "fittableNonSingleton": 0}
1609	4362	{"_key": 4362, "groupID": 4362, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 617944, "useBasePrice": 0, "fittableNonSingleton": 0}
1610	4363	{"_key": 4363, "groupID": 4363, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 617974, "useBasePrice": 0, "fittableNonSingleton": 0}
1611	4364	{"_key": 4364, "groupID": 4364, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 618382, "useBasePrice": 0, "fittableNonSingleton": 0}
1612	4365	{"_key": 4365, "groupID": 4365, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 618420, "useBasePrice": 0, "fittableNonSingleton": 0}
1613	4366	{"_key": 4366, "groupID": 4366, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 618442, "useBasePrice": 0, "fittableNonSingleton": 0}
1614	4367	{"_key": 4367, "groupID": 4367, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 618478, "useBasePrice": 0, "fittableNonSingleton": 0}
1615	4368	{"_key": 4368, "groupID": 4368, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 618482, "useBasePrice": 0, "fittableNonSingleton": 0}
1616	4369	{"_key": 4369, "groupID": 4369, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 618538, "useBasePrice": 0, "fittableNonSingleton": 0}
1617	4370	{"_key": 4370, "groupID": 4370, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 618541, "useBasePrice": 0, "fittableNonSingleton": 0}
1618	4371	{"_key": 4371, "groupID": 4371, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 618626, "useBasePrice": 0, "fittableNonSingleton": 0}
1619	4372	{"_key": 4372, "groupID": 4372, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 618739, "useBasePrice": 0, "fittableNonSingleton": 0}
1620	4373	{"_key": 4373, "groupID": 4373, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 618963, "useBasePrice": 0, "fittableNonSingleton": 0}
1621	4374	{"_key": 4374, "groupID": 4374, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 619019, "useBasePrice": 0, "fittableNonSingleton": 0}
1622	4375	{"_key": 4375, "groupID": 4375, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 619036, "useBasePrice": 0, "fittableNonSingleton": 0}
1623	4376	{"_key": 4376, "groupID": 4376, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 619073, "useBasePrice": 0, "fittableNonSingleton": 0}
1624	4377	{"_key": 4377, "groupID": 4377, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 619106, "useBasePrice": 0, "fittableNonSingleton": 0}
1625	4378	{"_key": 4378, "groupID": 4378, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 619122, "useBasePrice": 0, "fittableNonSingleton": 0}
1626	4379	{"_key": 4379, "groupID": 4379, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 619178, "useBasePrice": 0, "fittableNonSingleton": 0}
1627	4380	{"_key": 4380, "groupID": 4380, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 619196, "useBasePrice": 0, "fittableNonSingleton": 0}
1628	4381	{"_key": 4381, "groupID": 4381, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 619204, "useBasePrice": 0, "fittableNonSingleton": 0}
1629	4382	{"_key": 4382, "groupID": 4382, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 619292, "useBasePrice": 0, "fittableNonSingleton": 0}
1630	4383	{"_key": 4383, "groupID": 4383, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 619434, "useBasePrice": 0, "fittableNonSingleton": 0}
1631	4384	{"_key": 4384, "groupID": 4384, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 619554, "useBasePrice": 0, "fittableNonSingleton": 0}
1632	4385	{"_key": 4385, "groupID": 4385, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 619799, "useBasePrice": 0, "fittableNonSingleton": 0}
1633	4386	{"_key": 4386, "groupID": 4386, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 619811, "useBasePrice": 0, "fittableNonSingleton": 0}
1634	4387	{"_key": 4387, "groupID": 4387, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 620325, "useBasePrice": 0, "fittableNonSingleton": 0}
1635	4388	{"_key": 4388, "groupID": 4388, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 620464, "useBasePrice": 0, "fittableNonSingleton": 0}
1636	4389	{"_key": 4389, "groupID": 4389, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 620494, "useBasePrice": 0, "fittableNonSingleton": 0}
1637	4390	{"_key": 4390, "groupID": 4390, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 620525, "useBasePrice": 0, "fittableNonSingleton": 0}
1638	4391	{"_key": 4391, "groupID": 4391, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 620567, "useBasePrice": 0, "fittableNonSingleton": 0}
1639	4392	{"_key": 4392, "groupID": 4392, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 620599, "useBasePrice": 0, "fittableNonSingleton": 0}
1640	4393	{"_key": 4393, "groupID": 4393, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 620677, "useBasePrice": 0, "fittableNonSingleton": 0}
1641	4394	{"_key": 4394, "groupID": 4394, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 620743, "useBasePrice": 0, "fittableNonSingleton": 0}
1642	4395	{"_key": 4395, "groupID": 4395, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 620775, "useBasePrice": 0, "fittableNonSingleton": 0}
1643	4396	{"_key": 4396, "groupID": 4396, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 620845, "useBasePrice": 0, "fittableNonSingleton": 0}
1644	4397	{"_key": 4397, "groupID": 4397, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 621118, "useBasePrice": 0, "fittableNonSingleton": 0}
1645	4398	{"_key": 4398, "groupID": 4398, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 621156, "useBasePrice": 0, "fittableNonSingleton": 0}
1646	4399	{"_key": 4399, "groupID": 4399, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 621198, "useBasePrice": 0, "fittableNonSingleton": 0}
1647	4400	{"_key": 4400, "groupID": 4400, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 621348, "useBasePrice": 0, "fittableNonSingleton": 0}
1648	4401	{"_key": 4401, "groupID": 4401, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 621502, "useBasePrice": 0, "fittableNonSingleton": 0}
1649	4402	{"_key": 4402, "groupID": 4402, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 621620, "useBasePrice": 0, "fittableNonSingleton": 0}
1650	4403	{"_key": 4403, "groupID": 4403, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 621738, "useBasePrice": 0, "fittableNonSingleton": 0}
1651	4404	{"_key": 4404, "groupID": 4404, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 621832, "useBasePrice": 0, "fittableNonSingleton": 0}
1652	4405	{"_key": 4405, "groupID": 4405, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 621982, "useBasePrice": 0, "fittableNonSingleton": 0}
1653	4406	{"_key": 4406, "groupID": 4406, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 622092, "useBasePrice": 0, "fittableNonSingleton": 0}
1654	4407	{"_key": 4407, "groupID": 4407, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 622124, "useBasePrice": 0, "fittableNonSingleton": 0}
1655	4408	{"_key": 4408, "groupID": 4408, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 622250, "useBasePrice": 0, "fittableNonSingleton": 0}
1656	4409	{"_key": 4409, "groupID": 4409, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 622383, "useBasePrice": 0, "fittableNonSingleton": 0}
1657	4410	{"_key": 4410, "groupID": 4410, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 622491, "useBasePrice": 0, "fittableNonSingleton": 0}
1658	4411	{"_key": 4411, "groupID": 4411, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 622517, "useBasePrice": 0, "fittableNonSingleton": 0}
1659	4412	{"_key": 4412, "groupID": 4412, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 622525, "useBasePrice": 0, "fittableNonSingleton": 0}
1660	4413	{"_key": 4413, "groupID": 4413, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 622539, "useBasePrice": 0, "fittableNonSingleton": 0}
1661	4414	{"_key": 4414, "groupID": 4414, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 622558, "useBasePrice": 0, "fittableNonSingleton": 0}
1662	4415	{"_key": 4415, "groupID": 4415, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 622566, "useBasePrice": 0, "fittableNonSingleton": 0}
1663	4416	{"_key": 4416, "groupID": 4416, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2113, "groupNameID": 622582, "useBasePrice": 0, "fittableNonSingleton": 0}
1664	4417	{"_key": 4417, "groupID": 4417, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 622587, "useBasePrice": 0, "fittableNonSingleton": 0}
1665	4418	{"_key": 4418, "groupID": 4418, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 622601, "useBasePrice": 0, "fittableNonSingleton": 0}
1666	4419	{"_key": 4419, "groupID": 4419, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 623062, "useBasePrice": 0, "fittableNonSingleton": 0}
1667	4420	{"_key": 4420, "groupID": 4420, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 623300, "useBasePrice": 0, "fittableNonSingleton": 0}
1668	4421	{"_key": 4421, "groupID": 4421, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 623327, "useBasePrice": 0, "fittableNonSingleton": 0}
1669	4422	{"_key": 4422, "groupID": 4422, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2113, "groupNameID": 623337, "useBasePrice": 0, "fittableNonSingleton": 0}
1670	4423	{"_key": 4423, "groupID": 4423, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2113, "groupNameID": 623339, "useBasePrice": 0, "fittableNonSingleton": 0}
1671	4424	{"_key": 4424, "groupID": 4424, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 623342, "useBasePrice": 0, "fittableNonSingleton": 0}
1672	4425	{"_key": 4425, "groupID": 4425, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2113, "groupNameID": 623350, "useBasePrice": 0, "fittableNonSingleton": 0}
1673	4426	{"_key": 4426, "groupID": 4426, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 623355, "useBasePrice": 0, "fittableNonSingleton": 0}
1674	4427	{"_key": 4427, "groupID": 4427, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 623404, "useBasePrice": 0, "fittableNonSingleton": 0}
1675	4428	{"_key": 4428, "groupID": 4428, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 623442, "useBasePrice": 0, "fittableNonSingleton": 0}
1676	4429	{"_key": 4429, "groupID": 4429, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 623454, "useBasePrice": 0, "fittableNonSingleton": 0}
1677	4430	{"_key": 4430, "groupID": 4430, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 623561, "useBasePrice": 0, "fittableNonSingleton": 0}
1678	4431	{"_key": 4431, "groupID": 4431, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 623607, "useBasePrice": 0, "fittableNonSingleton": 0}
1679	4432	{"_key": 4432, "groupID": 4432, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 623608, "useBasePrice": 0, "fittableNonSingleton": 0}
1680	4433	{"_key": 4433, "groupID": 4433, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 623609, "useBasePrice": 0, "fittableNonSingleton": 0}
1681	4434	{"_key": 4434, "groupID": 4434, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 623610, "useBasePrice": 0, "fittableNonSingleton": 0}
1682	4436	{"_key": 4436, "groupID": 4436, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 623908, "useBasePrice": 0, "fittableNonSingleton": 0}
1683	4445	{"_key": 4445, "iconID": 33, "groupID": 4445, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 20, "groupNameID": 628298, "useBasePrice": 0, "fittableNonSingleton": 0}
1684	4446	{"_key": 4446, "iconID": 33, "groupID": 4446, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 628298, "useBasePrice": 0, "fittableNonSingleton": 0}
1685	4471	{"_key": 4471, "groupID": 4471, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2118, "groupNameID": 631767, "useBasePrice": 0, "fittableNonSingleton": 0}
1686	4477	{"_key": 4477, "groupID": 4477, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 22, "groupNameID": 635229, "useBasePrice": 1, "fittableNonSingleton": 0}
1687	4478	{"_key": 4478, "groupID": 4478, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 6, "groupNameID": 636053, "useBasePrice": 0, "fittableNonSingleton": 0}
1688	4479	{"_key": 4479, "groupID": 4479, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 636056, "useBasePrice": 0, "fittableNonSingleton": 0}
1689	4480	{"_key": 4480, "iconID": 1288, "groupID": 4480, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 8, "groupNameID": 636057, "useBasePrice": 0, "fittableNonSingleton": 1}
1690	4481	{"_key": 4481, "groupID": 4481, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 8, "groupNameID": 636070, "useBasePrice": 0, "fittableNonSingleton": 1}
1691	4482	{"_key": 4482, "groupID": 4482, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 8, "groupNameID": 636073, "useBasePrice": 0, "fittableNonSingleton": 1}
1692	4483	{"_key": 4483, "groupID": 4483, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 636078, "useBasePrice": 0, "fittableNonSingleton": 0}
1693	4484	{"_key": 4484, "groupID": 4484, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 636081, "useBasePrice": 0, "fittableNonSingleton": 0}
1694	4485	{"_key": 4485, "groupID": 4485, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 636100, "useBasePrice": 0, "fittableNonSingleton": 0}
1695	4486	{"_key": 4486, "iconID": 96, "groupID": 4486, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 636141, "useBasePrice": 0, "fittableNonSingleton": 0}
1696	4487	{"_key": 4487, "iconID": 1031, "groupID": 4487, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 636146, "useBasePrice": 0, "fittableNonSingleton": 0}
1697	4488	{"_key": 4488, "iconID": 1033, "groupID": 4488, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 8, "groupNameID": 636151, "useBasePrice": 0, "fittableNonSingleton": 1}
1698	4489	{"_key": 4489, "groupID": 4489, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 636152, "useBasePrice": 0, "fittableNonSingleton": 0}
1699	4490	{"_key": 4490, "groupID": 4490, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 636165, "useBasePrice": 0, "fittableNonSingleton": 0}
1700	4491	{"_key": 4491, "groupID": 4491, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 636174, "useBasePrice": 0, "fittableNonSingleton": 0}
1701	4492	{"_key": 4492, "groupID": 4492, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 636179, "useBasePrice": 0, "fittableNonSingleton": 0}
1702	4493	{"_key": 4493, "groupID": 4493, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 636346, "useBasePrice": 1, "fittableNonSingleton": 0}
1703	4494	{"_key": 4494, "groupID": 4494, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 637132, "useBasePrice": 0, "fittableNonSingleton": 0}
1704	4495	{"_key": 4495, "groupID": 4495, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 637359, "useBasePrice": 0, "fittableNonSingleton": 0}
1705	4496	{"_key": 4496, "groupID": 4496, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 637360, "useBasePrice": 0, "fittableNonSingleton": 0}
1706	4497	{"_key": 4497, "groupID": 4497, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 637361, "useBasePrice": 0, "fittableNonSingleton": 0}
1707	4498	{"_key": 4498, "groupID": 4498, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 637362, "useBasePrice": 0, "fittableNonSingleton": 0}
1708	4499	{"_key": 4499, "groupID": 4499, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 22, "groupNameID": 638199, "useBasePrice": 1, "fittableNonSingleton": 0}
1709	4500	{"_key": 4500, "iconID": 0, "groupID": 4500, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 639004, "useBasePrice": 0, "fittableNonSingleton": 0}
1710	4501	{"_key": 4501, "groupID": 4501, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 639247, "useBasePrice": 0, "fittableNonSingleton": 0}
1711	4504	{"_key": 4504, "iconID": 0, "groupID": 4504, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 640053, "useBasePrice": 0, "fittableNonSingleton": 0}
1712	4506	{"_key": 4506, "iconID": 0, "groupID": 4506, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 626768, "useBasePrice": 1, "fittableNonSingleton": 0}
1713	4513	{"_key": 4513, "iconID": 15, "groupID": 4513, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 640735, "useBasePrice": 0, "fittableNonSingleton": 0}
1714	4514	{"_key": 4514, "iconID": 15, "groupID": 4514, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 640736, "useBasePrice": 0, "fittableNonSingleton": 0}
1715	4515	{"_key": 4515, "iconID": 15, "groupID": 4515, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 640737, "useBasePrice": 0, "fittableNonSingleton": 0}
1716	4516	{"_key": 4516, "iconID": 15, "groupID": 4516, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 640738, "useBasePrice": 0, "fittableNonSingleton": 0}
1717	4536	{"_key": 4536, "iconID": 0, "groupID": 4536, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 642595, "useBasePrice": 0, "fittableNonSingleton": 0}
1718	4537	{"_key": 4537, "groupID": 4537, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 7, "groupNameID": 642639, "useBasePrice": 0, "fittableNonSingleton": 0}
1719	4538	{"_key": 4538, "iconID": 0, "groupID": 4538, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 17, "groupNameID": 643758, "useBasePrice": 1, "fittableNonSingleton": 0}
1720	4539	{"_key": 4539, "groupID": 4539, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 17, "groupNameID": 644595, "useBasePrice": 0, "fittableNonSingleton": 0}
1721	4545	{"_key": 4545, "iconID": 0, "groupID": 4545, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 646102, "useBasePrice": 1, "fittableNonSingleton": 0}
1722	4546	{"_key": 4546, "iconID": 0, "groupID": 4546, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 647112, "useBasePrice": 1, "fittableNonSingleton": 0}
1723	4547	{"_key": 4547, "groupID": 4547, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 647116, "useBasePrice": 0, "fittableNonSingleton": 0}
1724	4548	{"_key": 4548, "groupID": 4548, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 647117, "useBasePrice": 0, "fittableNonSingleton": 0}
1725	4549	{"_key": 4549, "groupID": 4549, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 647118, "useBasePrice": 0, "fittableNonSingleton": 0}
1726	4564	{"_key": 4564, "groupID": 4564, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 647760, "useBasePrice": 0, "fittableNonSingleton": 0}
1727	4566	{"_key": 4566, "groupID": 4566, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 648615, "useBasePrice": 0, "fittableNonSingleton": 0}
1728	4567	{"_key": 4567, "groupID": 4567, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 648987, "useBasePrice": 0, "fittableNonSingleton": 0}
1729	4568	{"_key": 4568, "groupID": 4568, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 656418, "useBasePrice": 1, "fittableNonSingleton": 0}
1730	4569	{"_key": 4569, "groupID": 4569, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 657368, "useBasePrice": 0, "fittableNonSingleton": 0}
1731	4570	{"_key": 4570, "groupID": 4570, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 657496, "useBasePrice": 0, "fittableNonSingleton": 0}
1732	4571	{"_key": 4571, "groupID": 4571, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 657497, "useBasePrice": 0, "fittableNonSingleton": 0}
1733	4572	{"_key": 4572, "groupID": 4572, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 657513, "useBasePrice": 0, "fittableNonSingleton": 0}
1734	4573	{"_key": 4573, "groupID": 4573, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 659180, "useBasePrice": 0, "fittableNonSingleton": 0}
1735	4574	{"_key": 4574, "groupID": 4574, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 659181, "useBasePrice": 0, "fittableNonSingleton": 0}
1736	4575	{"_key": 4575, "groupID": 4575, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 659287, "useBasePrice": 1, "fittableNonSingleton": 0}
1737	4576	{"_key": 4576, "groupID": 4576, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 660753, "useBasePrice": 0, "fittableNonSingleton": 0}
1738	4577	{"_key": 4577, "groupID": 4577, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 660754, "useBasePrice": 0, "fittableNonSingleton": 0}
1739	4578	{"_key": 4578, "groupID": 4578, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 660786, "useBasePrice": 0, "fittableNonSingleton": 0}
1740	4579	{"_key": 4579, "groupID": 4579, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 660808, "useBasePrice": 0, "fittableNonSingleton": 0}
1741	4580	{"_key": 4580, "groupID": 4580, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 661464, "useBasePrice": 0, "fittableNonSingleton": 0}
1742	4594	{"_key": 4594, "groupID": 4594, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 662671, "useBasePrice": 0, "fittableNonSingleton": 0}
1743	4599	{"_key": 4599, "groupID": 4599, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 662939, "useBasePrice": 1, "fittableNonSingleton": 0}
1744	4603	{"_key": 4603, "groupID": 4603, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 66, "groupNameID": 664686, "useBasePrice": 0, "fittableNonSingleton": 0}
1745	4604	{"_key": 4604, "groupID": 4604, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2125, "groupNameID": 626771, "useBasePrice": 0, "fittableNonSingleton": 0}
1746	4605	{"_key": 4605, "groupID": 4605, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2125, "groupNameID": 626772, "useBasePrice": 0, "fittableNonSingleton": 0}
1747	4606	{"_key": 4606, "groupID": 4606, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2125, "groupNameID": 626918, "useBasePrice": 0, "fittableNonSingleton": 0}
1748	4607	{"_key": 4607, "groupID": 4607, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2125, "groupNameID": 626919, "useBasePrice": 0, "fittableNonSingleton": 0}
1749	4622	{"_key": 4622, "groupID": 4622, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 666012, "useBasePrice": 0, "fittableNonSingleton": 0}
1750	4632	{"_key": 4632, "groupID": 4632, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2126, "groupNameID": 666797, "useBasePrice": 0, "fittableNonSingleton": 0}
1751	4636	{"_key": 4636, "groupID": 4636, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 671872, "useBasePrice": 0, "fittableNonSingleton": 0}
1752	4637	{"_key": 4637, "groupID": 4637, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 695931, "useBasePrice": 0, "fittableNonSingleton": 0}
1753	4638	{"_key": 4638, "groupID": 4638, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 696092, "useBasePrice": 0, "fittableNonSingleton": 0}
1754	4641	{"_key": 4641, "groupID": 4641, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2127, "groupNameID": 687800, "useBasePrice": 0, "fittableNonSingleton": 0}
1755	4642	{"_key": 4642, "groupID": 4642, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 687802, "useBasePrice": 0, "fittableNonSingleton": 0}
1756	4643	{"_key": 4643, "groupID": 4643, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2128, "groupNameID": 689670, "useBasePrice": 0, "fittableNonSingleton": 0}
1757	4644	{"_key": 4644, "groupID": 4644, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 65, "groupNameID": 693278, "useBasePrice": 0, "fittableNonSingleton": 0}
1758	4647	{"_key": 4647, "groupID": 4647, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 696170, "useBasePrice": 0, "fittableNonSingleton": 0}
1759	4648	{"_key": 4648, "groupID": 4648, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 696171, "useBasePrice": 0, "fittableNonSingleton": 0}
1760	4649	{"_key": 4649, "groupID": 4649, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 696172, "useBasePrice": 0, "fittableNonSingleton": 0}
1761	4650	{"_key": 4650, "groupID": 4650, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 696173, "useBasePrice": 0, "fittableNonSingleton": 0}
1762	4651	{"_key": 4651, "groupID": 4651, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 696174, "useBasePrice": 0, "fittableNonSingleton": 0}
1763	4652	{"_key": 4652, "groupID": 4652, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 696175, "useBasePrice": 0, "fittableNonSingleton": 0}
1764	4653	{"_key": 4653, "groupID": 4653, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 696176, "useBasePrice": 0, "fittableNonSingleton": 0}
1765	4654	{"_key": 4654, "groupID": 4654, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 696177, "useBasePrice": 0, "fittableNonSingleton": 0}
1766	4655	{"_key": 4655, "groupID": 4655, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 696178, "useBasePrice": 0, "fittableNonSingleton": 0}
1767	4656	{"_key": 4656, "groupID": 4656, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 696179, "useBasePrice": 0, "fittableNonSingleton": 0}
1768	4669	{"_key": 4669, "groupID": 4669, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2126, "groupNameID": 696879, "useBasePrice": 0, "fittableNonSingleton": 0}
1769	4670	{"_key": 4670, "groupID": 4670, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2126, "groupNameID": 696880, "useBasePrice": 0, "fittableNonSingleton": 0}
1770	4671	{"_key": 4671, "groupID": 4671, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2126, "groupNameID": 696881, "useBasePrice": 0, "fittableNonSingleton": 0}
1771	4672	{"_key": 4672, "groupID": 4672, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2126, "groupNameID": 696882, "useBasePrice": 0, "fittableNonSingleton": 0}
1772	4673	{"_key": 4673, "groupID": 4673, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 11, "groupNameID": 697213, "useBasePrice": 0, "fittableNonSingleton": 0}
1773	4709	{"_key": 4709, "groupID": 4709, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 698472, "useBasePrice": 0, "fittableNonSingleton": 0}
1774	4712	{"_key": 4712, "groupID": 4712, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 699162, "useBasePrice": 0, "fittableNonSingleton": 0}
1775	4713	{"_key": 4713, "groupID": 4713, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 699250, "useBasePrice": 0, "fittableNonSingleton": 0}
1776	4714	{"_key": 4714, "groupID": 4714, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 25, "groupNameID": 701099, "useBasePrice": 0, "fittableNonSingleton": 0}
1777	4716	{"_key": 4716, "groupID": 4716, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 706043, "useBasePrice": 1, "fittableNonSingleton": 0}
1778	4717	{"_key": 4717, "groupID": 4717, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 706149, "useBasePrice": 0, "fittableNonSingleton": 0}
1779	4719	{"_key": 4719, "groupID": 4719, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 706696, "useBasePrice": 0, "fittableNonSingleton": 0}
1780	4723	{"_key": 4723, "groupID": 4723, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2126, "groupNameID": 707916, "useBasePrice": 0, "fittableNonSingleton": 0}
1781	4725	{"_key": 4725, "groupID": 4725, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2118, "groupNameID": 709243, "useBasePrice": 0, "fittableNonSingleton": 0}
1782	4726	{"_key": 4726, "groupID": 4726, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2118, "groupNameID": 709245, "useBasePrice": 0, "fittableNonSingleton": 0}
1783	4729	{"_key": 4729, "groupID": 4729, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2143, "groupNameID": 709448, "useBasePrice": 1, "fittableNonSingleton": 0}
1784	4734	{"_key": 4734, "groupID": 4734, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 16, "groupNameID": 709915, "useBasePrice": 1, "fittableNonSingleton": 0}
1785	4736	{"_key": 4736, "groupID": 4736, "anchored": 0, "published": 1, "anchorable": 1, "categoryID": 46, "groupNameID": 709917, "useBasePrice": 0, "fittableNonSingleton": 0}
1786	4737	{"_key": 4737, "groupID": 4737, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 710534, "useBasePrice": 0, "fittableNonSingleton": 0}
1787	4742	{"_key": 4742, "groupID": 4742, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 710656, "useBasePrice": 0, "fittableNonSingleton": 0}
1788	4743	{"_key": 4743, "groupID": 4743, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 710745, "useBasePrice": 1, "fittableNonSingleton": 0}
1789	4744	{"_key": 4744, "groupID": 4744, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 65, "groupNameID": 710827, "useBasePrice": 0, "fittableNonSingleton": 0}
1790	4745	{"_key": 4745, "groupID": 4745, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 711268, "useBasePrice": 0, "fittableNonSingleton": 0}
1791	4755	{"_key": 4755, "iconID": 15, "groupID": 4755, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 712212, "useBasePrice": 0, "fittableNonSingleton": 0}
1792	4756	{"_key": 4756, "iconID": 15, "groupID": 4756, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 712213, "useBasePrice": 0, "fittableNonSingleton": 0}
1793	4757	{"_key": 4757, "iconID": 15, "groupID": 4757, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 712214, "useBasePrice": 0, "fittableNonSingleton": 0}
1794	4758	{"_key": 4758, "iconID": 15, "groupID": 4758, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 712215, "useBasePrice": 0, "fittableNonSingleton": 0}
1795	4759	{"_key": 4759, "iconID": 15, "groupID": 4759, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 712216, "useBasePrice": 0, "fittableNonSingleton": 0}
1796	4768	{"_key": 4768, "groupID": 4768, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 39, "groupNameID": 720415, "useBasePrice": 1, "fittableNonSingleton": 0}
1797	4769	{"_key": 4769, "groupID": 4769, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 720661, "useBasePrice": 0, "fittableNonSingleton": 0}
1798	4771	{"_key": 4771, "groupID": 4771, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 721700, "useBasePrice": 0, "fittableNonSingleton": 0}
1799	4772	{"_key": 4772, "groupID": 4772, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 39, "groupNameID": 722226, "useBasePrice": 1, "fittableNonSingleton": 0}
1800	4776	{"_key": 4776, "groupID": 4776, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 722902, "useBasePrice": 1, "fittableNonSingleton": 0}
1801	4777	{"_key": 4777, "groupID": 4777, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 87, "groupNameID": 723473, "useBasePrice": 0, "fittableNonSingleton": 0}
1802	4778	{"_key": 4778, "groupID": 4778, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 87, "groupNameID": 723474, "useBasePrice": 0, "fittableNonSingleton": 0}
1803	4779	{"_key": 4779, "groupID": 4779, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 87, "groupNameID": 723475, "useBasePrice": 0, "fittableNonSingleton": 0}
1804	4784	{"_key": 4784, "groupID": 4784, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 724383, "useBasePrice": 0, "fittableNonSingleton": 0}
1805	4786	{"_key": 4786, "groupID": 4786, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 724506, "useBasePrice": 0, "fittableNonSingleton": 0}
1806	4789	{"_key": 4789, "groupID": 4789, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 725322, "useBasePrice": 0, "fittableNonSingleton": 0}
1807	4791	{"_key": 4791, "groupID": 4791, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 4, "groupNameID": 725470, "useBasePrice": 1, "fittableNonSingleton": 0}
1808	4792	{"_key": 4792, "groupID": 4792, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 725507, "useBasePrice": 0, "fittableNonSingleton": 0}
1809	4795	{"_key": 4795, "groupID": 4795, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 726309, "useBasePrice": 0, "fittableNonSingleton": 0}
1810	4796	{"_key": 4796, "groupID": 4796, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 726310, "useBasePrice": 0, "fittableNonSingleton": 0}
1811	4797	{"_key": 4797, "groupID": 4797, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 726311, "useBasePrice": 0, "fittableNonSingleton": 0}
1812	4798	{"_key": 4798, "groupID": 4798, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 726312, "useBasePrice": 0, "fittableNonSingleton": 0}
1813	4799	{"_key": 4799, "groupID": 4799, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 726313, "useBasePrice": 0, "fittableNonSingleton": 0}
1814	4800	{"_key": 4800, "groupID": 4800, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 726314, "useBasePrice": 0, "fittableNonSingleton": 0}
1815	4801	{"_key": 4801, "groupID": 4801, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 726317, "useBasePrice": 0, "fittableNonSingleton": 0}
1816	4802	{"_key": 4802, "groupID": 4802, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 726319, "useBasePrice": 0, "fittableNonSingleton": 0}
1817	4803	{"_key": 4803, "groupID": 4803, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 726320, "useBasePrice": 0, "fittableNonSingleton": 0}
1818	4804	{"_key": 4804, "groupID": 4804, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 726321, "useBasePrice": 0, "fittableNonSingleton": 0}
1819	4807	{"_key": 4807, "groupID": 4807, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 726805, "useBasePrice": 0, "fittableNonSingleton": 0}
1820	4808	{"_key": 4808, "groupID": 4808, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 726814, "useBasePrice": 0, "fittableNonSingleton": 1}
1821	4809	{"_key": 4809, "iconID": 20971, "groupID": 4809, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 726856, "useBasePrice": 0, "fittableNonSingleton": 0}
1822	4810	{"_key": 4810, "groupID": 4810, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 22, "groupNameID": 727344, "useBasePrice": 0, "fittableNonSingleton": 0}
1823	4811	{"_key": 4811, "groupID": 4811, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 727376, "useBasePrice": 1, "fittableNonSingleton": 0}
1824	4815	{"_key": 4815, "groupID": 4815, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 727794, "useBasePrice": 0, "fittableNonSingleton": 0}
1825	4816	{"_key": 4816, "groupID": 4816, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 727795, "useBasePrice": 0, "fittableNonSingleton": 0}
1826	4817	{"_key": 4817, "groupID": 4817, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 727796, "useBasePrice": 0, "fittableNonSingleton": 0}
1827	4820	{"_key": 4820, "groupID": 4820, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 863197, "useBasePrice": 1, "fittableNonSingleton": 0}
1828	4821	{"_key": 4821, "groupID": 4821, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 869759, "useBasePrice": 1, "fittableNonSingleton": 0}
1829	4824	{"_key": 4824, "groupID": 4824, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 896315, "useBasePrice": 1, "fittableNonSingleton": 0}
1830	4825	{"_key": 4825, "groupID": 4825, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 896728, "useBasePrice": 0, "fittableNonSingleton": 0}
1831	4826	{"_key": 4826, "iconID": 26562, "groupID": 4826, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 4, "groupNameID": 1005041, "useBasePrice": 1, "fittableNonSingleton": 0}
1832	4827	{"_key": 4827, "groupID": 4827, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 1005117, "useBasePrice": 1, "fittableNonSingleton": 0}
1833	4828	{"_key": 4828, "groupID": 4828, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 1005118, "useBasePrice": 0, "fittableNonSingleton": 0}
1834	4829	{"_key": 4829, "groupID": 4829, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 1008261, "useBasePrice": 0, "fittableNonSingleton": 0}
1835	4838	{"_key": 4838, "groupID": 4838, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 39, "groupNameID": 1009927, "useBasePrice": 1, "fittableNonSingleton": 0}
1836	4839	{"_key": 4839, "groupID": 4839, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 39, "groupNameID": 1010226, "useBasePrice": 1, "fittableNonSingleton": 0}
1837	4843	{"_key": 4843, "groupID": 4843, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 1010659, "useBasePrice": 1, "fittableNonSingleton": 0}
1838	4857	{"_key": 4857, "iconID": 15, "groupID": 4857, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 1011290, "useBasePrice": 0, "fittableNonSingleton": 0}
1839	4900	{"_key": 4900, "groupID": 4900, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 1016597, "useBasePrice": 1, "fittableNonSingleton": 0}
1840	4901	{"_key": 4901, "groupID": 4901, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 1017058, "useBasePrice": 0, "fittableNonSingleton": 0}
1841	4902	{"_key": 4902, "groupID": 4902, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 1017831, "useBasePrice": 0, "fittableNonSingleton": 0}
1842	4903	{"_key": 4903, "iconID": 21894, "groupID": 4903, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 7, "groupNameID": 1017842, "useBasePrice": 0, "fittableNonSingleton": 0}
1843	4904	{"_key": 4904, "groupID": 4904, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 1017843, "useBasePrice": 1, "fittableNonSingleton": 0}
1844	4905	{"_key": 4905, "groupID": 4905, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 8, "groupNameID": 1017847, "useBasePrice": 0, "fittableNonSingleton": 1}
1845	4906	{"_key": 4906, "groupID": 4906, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 1017929, "useBasePrice": 1, "fittableNonSingleton": 0}
1846	4909	{"_key": 4909, "groupID": 4909, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1018583, "useBasePrice": 0, "fittableNonSingleton": 0}
1847	4910	{"_key": 4910, "iconID": 27083, "groupID": 4910, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 2113, "groupNameID": 1018709, "useBasePrice": 0, "fittableNonSingleton": 0}
1848	4913	{"_key": 4913, "groupID": 4913, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 22, "groupNameID": 1019003, "useBasePrice": 0, "fittableNonSingleton": 0}
1849	4914	{"_key": 4914, "groupID": 4914, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 1019014, "useBasePrice": 1, "fittableNonSingleton": 0}
1850	4915	{"_key": 4915, "iconID": 15, "groupID": 4915, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 4, "groupNameID": 1019022, "useBasePrice": 0, "fittableNonSingleton": 0}
1851	4916	{"_key": 4916, "iconID": 15, "groupID": 4916, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2152, "groupNameID": 1019025, "useBasePrice": 0, "fittableNonSingleton": 0}
1852	4917	{"_key": 4917, "groupID": 4917, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1019368, "useBasePrice": 0, "fittableNonSingleton": 0}
1853	4918	{"_key": 4918, "groupID": 4918, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 1019374, "useBasePrice": 0, "fittableNonSingleton": 0}
1854	4919	{"_key": 4919, "iconID": 0, "groupID": 4919, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1019401, "useBasePrice": 0, "fittableNonSingleton": 0}
1855	4920	{"_key": 4920, "iconID": 0, "groupID": 4920, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1019402, "useBasePrice": 0, "fittableNonSingleton": 0}
1856	4924	{"_key": 4924, "groupID": 4924, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 1019501, "useBasePrice": 1, "fittableNonSingleton": 0}
1857	4930	{"_key": 4930, "groupID": 4930, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 1019556, "useBasePrice": 0, "fittableNonSingleton": 0}
1858	4932	{"_key": 4932, "groupID": 4932, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 4, "groupNameID": 1019559, "useBasePrice": 1, "fittableNonSingleton": 0}
1859	4935	{"_key": 4935, "groupID": 4935, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 1019732, "useBasePrice": 0, "fittableNonSingleton": 0}
1860	4936	{"_key": 4936, "groupID": 4936, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 1019734, "useBasePrice": 0, "fittableNonSingleton": 0}
1861	4937	{"_key": 4937, "groupID": 4937, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 1019736, "useBasePrice": 0, "fittableNonSingleton": 0}
1862	4938	{"_key": 4938, "groupID": 4938, "anchored": 1, "published": 0, "anchorable": 0, "categoryID": 2, "groupNameID": 1019737, "useBasePrice": 0, "fittableNonSingleton": 0}
1863	4939	{"_key": 4939, "groupID": 4939, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 22, "groupNameID": 1020721, "useBasePrice": 0, "fittableNonSingleton": 0}
1864	4941	{"_key": 4941, "groupID": 4941, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 2152, "groupNameID": 1021186, "useBasePrice": 0, "fittableNonSingleton": 0}
1865	4945	{"_key": 4945, "groupID": 4945, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1021410, "useBasePrice": 0, "fittableNonSingleton": 0}
1866	4947	{"_key": 4947, "groupID": 4947, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 9, "groupNameID": 1021682, "useBasePrice": 1, "fittableNonSingleton": 0}
1867	4948	{"_key": 4948, "iconID": 26562, "groupID": 4948, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 4, "groupNameID": 1021816, "useBasePrice": 1, "fittableNonSingleton": 0}
1868	4949	{"_key": 4949, "groupID": 4949, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1025585, "useBasePrice": 0, "fittableNonSingleton": 0}
1869	4972	{"_key": 4972, "groupID": 4972, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 1028940, "useBasePrice": 1, "fittableNonSingleton": 0}
1870	4975	{"_key": 4975, "groupID": 4975, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1030693, "useBasePrice": 0, "fittableNonSingleton": 0}
1871	5032	{"_key": 5032, "groupID": 5032, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1034374, "useBasePrice": 0, "fittableNonSingleton": 0}
1872	5063	{"_key": 5063, "groupID": 5063, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1035583, "useBasePrice": 0, "fittableNonSingleton": 0}
1873	5064	{"_key": 5064, "groupID": 5064, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1035584, "useBasePrice": 0, "fittableNonSingleton": 0}
1874	5065	{"_key": 5065, "groupID": 5065, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1035585, "useBasePrice": 0, "fittableNonSingleton": 0}
1875	5066	{"_key": 5066, "groupID": 5066, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1035586, "useBasePrice": 0, "fittableNonSingleton": 0}
1876	5067	{"_key": 5067, "groupID": 5067, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 1035590, "useBasePrice": 1, "fittableNonSingleton": 0}
1877	5068	{"_key": 5068, "groupID": 5068, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 17, "groupNameID": 1035692, "useBasePrice": 1, "fittableNonSingleton": 0}
1878	5078	{"_key": 5078, "groupID": 5078, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1037219, "useBasePrice": 0, "fittableNonSingleton": 0}
1879	5079	{"_key": 5079, "groupID": 5079, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1037221, "useBasePrice": 0, "fittableNonSingleton": 0}
1880	5080	{"_key": 5080, "groupID": 5080, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1037222, "useBasePrice": 0, "fittableNonSingleton": 0}
1881	5082	{"_key": 5082, "groupID": 5082, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 30, "groupNameID": 1037307, "useBasePrice": 0, "fittableNonSingleton": 0}
1882	5083	{"_key": 5083, "iconID": 15, "groupID": 5083, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 1038221, "useBasePrice": 0, "fittableNonSingleton": 0}
1883	5084	{"_key": 5084, "iconID": 15, "groupID": 5084, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 1038222, "useBasePrice": 0, "fittableNonSingleton": 0}
1884	5085	{"_key": 5085, "iconID": 15, "groupID": 5085, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 1038223, "useBasePrice": 0, "fittableNonSingleton": 0}
1885	5086	{"_key": 5086, "iconID": 15, "groupID": 5086, "anchored": 1, "published": 1, "anchorable": 0, "categoryID": 25, "groupNameID": 1038224, "useBasePrice": 0, "fittableNonSingleton": 0}
1886	5087	{"_key": 5087, "groupID": 5087, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 1038882, "useBasePrice": 0, "fittableNonSingleton": 0}
1887	5089	{"_key": 5089, "groupID": 5089, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1039572, "useBasePrice": 0, "fittableNonSingleton": 0}
1888	5090	{"_key": 5090, "groupID": 5090, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1039573, "useBasePrice": 0, "fittableNonSingleton": 0}
1889	5096	{"_key": 5096, "groupID": 5096, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1040320, "useBasePrice": 0, "fittableNonSingleton": 0}
1890	5097	{"_key": 5097, "groupID": 5097, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1041279, "useBasePrice": 0, "fittableNonSingleton": 0}
1891	5098	{"_key": 5098, "groupID": 5098, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1041280, "useBasePrice": 0, "fittableNonSingleton": 0}
1892	5099	{"_key": 5099, "groupID": 5099, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1041326, "useBasePrice": 0, "fittableNonSingleton": 0}
1893	5100	{"_key": 5100, "groupID": 5100, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1041327, "useBasePrice": 0, "fittableNonSingleton": 0}
1894	5101	{"_key": 5101, "groupID": 5101, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1041328, "useBasePrice": 0, "fittableNonSingleton": 0}
1895	5102	{"_key": 5102, "groupID": 5102, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1041329, "useBasePrice": 0, "fittableNonSingleton": 0}
1896	5119	{"_key": 5119, "groupID": 5119, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1043050, "useBasePrice": 0, "fittableNonSingleton": 0}
1897	5120	{"_key": 5120, "groupID": 5120, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 6, "groupNameID": 1043211, "useBasePrice": 0, "fittableNonSingleton": 0}
1898	5122	{"_key": 5122, "groupID": 5122, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1044385, "useBasePrice": 0, "fittableNonSingleton": 0}
1899	5123	{"_key": 5123, "groupID": 5123, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1044386, "useBasePrice": 0, "fittableNonSingleton": 0}
1900	5124	{"_key": 5124, "groupID": 5124, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1044387, "useBasePrice": 0, "fittableNonSingleton": 0}
1901	5125	{"_key": 5125, "groupID": 5125, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1044388, "useBasePrice": 0, "fittableNonSingleton": 0}
1902	5154	{"_key": 5154, "groupID": 5154, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 11, "groupNameID": 1049467, "useBasePrice": 0, "fittableNonSingleton": 0}
1903	5201	{"_key": 5201, "groupID": 5201, "anchored": 0, "published": 1, "anchorable": 0, "categoryID": 22, "groupNameID": 1051274, "useBasePrice": 0, "fittableNonSingleton": 0}
1904	350858	{"_key": 350858, "groupID": 350858, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 350001, "groupNameID": 278207, "useBasePrice": 1, "fittableNonSingleton": 0}
1905	351064	{"_key": 351064, "groupID": 351064, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 350001, "groupNameID": 278208, "useBasePrice": 1, "fittableNonSingleton": 0}
1906	351121	{"_key": 351121, "groupID": 351121, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 350001, "groupNameID": 278209, "useBasePrice": 1, "fittableNonSingleton": 0}
1907	351210	{"_key": 351210, "groupID": 351210, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 350001, "groupNameID": 278211, "useBasePrice": 1, "fittableNonSingleton": 0}
1908	351648	{"_key": 351648, "groupID": 351648, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 350001, "groupNameID": 278210, "useBasePrice": 1, "fittableNonSingleton": 0}
1909	351844	{"_key": 351844, "groupID": 351844, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 350001, "groupNameID": 278206, "useBasePrice": 1, "fittableNonSingleton": 0}
1910	354641	{"_key": 354641, "groupID": 354641, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 350001, "groupNameID": 278213, "useBasePrice": 1, "fittableNonSingleton": 0}
1911	354753	{"_key": 354753, "groupID": 354753, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 350001, "groupNameID": 278212, "useBasePrice": 1, "fittableNonSingleton": 0}
1912	364204	{"_key": 364204, "groupID": 364204, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 350001, "groupNameID": 286999, "useBasePrice": 1, "fittableNonSingleton": 0}
1913	367487	{"_key": 367487, "groupID": 367487, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 350001, "groupNameID": 296571, "useBasePrice": 0, "fittableNonSingleton": 0}
1914	367580	{"_key": 367580, "groupID": 367580, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 350001, "groupNameID": 296701, "useBasePrice": 0, "fittableNonSingleton": 0}
1915	367594	{"_key": 367594, "groupID": 367594, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 350001, "groupNameID": 296754, "useBasePrice": 1, "fittableNonSingleton": 0}
1916	367774	{"_key": 367774, "groupID": 367774, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 350001, "groupNameID": 297341, "useBasePrice": 0, "fittableNonSingleton": 0}
1917	367776	{"_key": 367776, "groupID": 367776, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 350001, "groupNameID": 297343, "useBasePrice": 0, "fittableNonSingleton": 0}
1918	368656	{"_key": 368656, "groupID": 368656, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 350001, "groupNameID": 299923, "useBasePrice": 1, "fittableNonSingleton": 0}
1919	368666	{"_key": 368666, "groupID": 368666, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 350001, "groupNameID": 299981, "useBasePrice": 1, "fittableNonSingleton": 0}
1920	368726	{"_key": 368726, "groupID": 368726, "anchored": 0, "published": 0, "anchorable": 0, "categoryID": 350001, "groupNameID": 305415, "useBasePrice": 1, "fittableNonSingleton": 0}
\.


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (row_no);


--
-- Name: groups_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX groups_key_idx ON sde_native.groups USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict clBi0CwhbkYHUvxMHGGxa6PpBTnl1pk8lFvJxhEp6Y0z6wzZQg4x5h2PaucT2mu

