--
-- PostgreSQL database dump
--

\restrict GgsuygKUP17vt3uMh2crR5tDgGUeAsOTBpITFFrrhcYcQUsR1ih57Wr3EAGGoUN

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: eventtypes; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.eventtypes (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: eventtypes; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.eventtypes (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "eventTypeName": "Activate Gate"}
1	2	{"_key": 2, "eventTypeName": "Spawn Guards"}
2	3	{"_key": 3, "eventTypeName": "Spawn Guard Object"}
3	4	{"_key": 4, "eventTypeName": "Ranged NPC Healing"}
4	5	{"_key": 5, "eventTypeName": "Ranged Player Damage (EM)"}
5	6	{"_key": 6, "eventTypeName": "Ranged Player Damage (Explosive)"}
6	7	{"_key": 7, "eventTypeName": "Ranged Player Damage (Kinetic)"}
7	8	{"_key": 8, "eventTypeName": "Ranged Player Damage (Thermal)"}
8	9	{"_key": 9, "eventTypeName": "Mission Completion"}
9	10	{"_key": 10, "eventTypeName": "Message"}
10	11	{"_key": 11, "eventTypeName": "Dungeon Completion"}
11	13	{"_key": 13, "eventTypeName": "Effect Beacon Activate"}
12	14	{"_key": 14, "eventTypeName": "Effect Beacon Deactivate"}
13	15	{"_key": 15, "eventTypeName": "Object Despawn"}
14	16	{"_key": 16, "eventTypeName": "Object Explode"}
15	18	{"_key": 18, "eventTypeName": "Entity Despawn"}
16	19	{"_key": 19, "eventTypeName": "Entity Explode"}
17	20	{"_key": 20, "eventTypeName": "Grant FacWar Victory Points"}
18	22	{"_key": 22, "eventTypeName": "Agent Talk To"}
19	23	{"_key": 23, "eventTypeName": "Agent Message"}
20	24	{"_key": 24, "eventTypeName": "Drop Loot"}
21	25	{"_key": 25, "eventTypeName": "Ranged Player Healing"}
22	26	{"_key": 26, "eventTypeName": "Ranged NPC Damage (EM)"}
23	27	{"_key": 27, "eventTypeName": "Ranged NPC Damage (Explosive)"}
24	28	{"_key": 28, "eventTypeName": "Ranged NPC Damage (Kinetic)"}
25	29	{"_key": 29, "eventTypeName": "Ranged NPC Damage (Thermal)"}
26	30	{"_key": 30, "eventTypeName": "Spawn Item In Cargo"}
27	31	{"_key": 31, "eventTypeName": "Mission Failure"}
28	32	{"_key": 32, "eventTypeName": "Counter Add"}
29	33	{"_key": 33, "eventTypeName": "Counter Subtract"}
30	34	{"_key": 34, "eventTypeName": "Counter Multiply"}
31	35	{"_key": 35, "eventTypeName": "Counter Divide"}
32	36	{"_key": 36, "eventTypeName": "Counter Set"}
33	37	{"_key": 37, "eventTypeName": "Grant Group Reward"}
34	38	{"_key": 38, "eventTypeName": "Grant Delayed Group Rewards"}
35	39	{"_key": 39, "eventTypeName": "AdjustSystemInfluence"}
36	40	{"_key": 40, "eventTypeName": "Warp Ship Away and despawn"}
37	41	{"_key": 41, "eventTypeName": "Warp ship away and come back"}
38	42	{"_key": 42, "eventTypeName": "Supress All Respawn"}
39	45	{"_key": 45, "eventTypeName": "Grant Group Reward (limited restrictions)"}
40	47	{"_key": 47, "eventTypeName": "Spawn Ship"}
41	48	{"_key": 48, "eventTypeName": "Grant FacWar Loyalty Points"}
42	49	{"_key": 49, "eventTypeName": "Timer Start"}
43	52	{"_key": 52, "eventTypeName": "Timer Cancel"}
44	54	{"_key": 54, "eventTypeName": "Start Tale"}
45	55	{"_key": 55, "eventTypeName": "Spawn Entity By Type ID"}
46	56	{"_key": 56, "eventTypeName": "Ranged Player Damage (Explosive) (POD included)"}
47	57	{"_key": 57, "eventTypeName": "Warp In Guards"}
48	58	{"_key": 58, "eventTypeName": "Spawn Guard Delay"}
49	59	{"_key": 59, "eventTypeName": "Empire Ore Removal"}
50	61	{"_key": 61, "eventTypeName": "Event Spawn Npcs Dynamically Using Blackboard"}
51	63	{"_key": 63, "eventTypeName": "Open Abyss Gate"}
52	65	{"_key": 65, "eventTypeName": "Remove Cargo From Ship"}
53	67	{"_key": 67, "eventTypeName": "Set Pose"}
54	68	{"_key": 68, "eventTypeName": "Grant Insurgency Loyalty Points"}
55	69	{"_key": 69, "eventTypeName": "Grant Insurgency Standings Change"}
56	2068	{"_key": 2068, "eventTypeName": "Blackboard Integer Value"}
57	2069	{"_key": 2069, "eventTypeName": "Blackboard String Value"}
58	2130	{"_key": 2130, "eventTypeName": "Camera Interest"}
59	2132	{"_key": 2132, "eventTypeName": "Apply Fitting"}
60	2133	{"_key": 2133, "eventTypeName": "Play Music"}
61	2134	{"_key": 2134, "eventTypeName": "Start Conversation"}
62	2135	{"_key": 2135, "eventTypeName": "Deactivate Gate"}
63	2138	{"_key": 2138, "eventTypeName": "Ignore Triggers"}
64	2143	{"_key": 2143, "eventTypeName": "OpenVoidSpaceExit"}
65	2144	{"_key": 2144, "eventTypeName": "Play Ambient Sound"}
66	2201	{"_key": 2201, "eventTypeName": "Labyinth Init"}
67	2202	{"_key": 2202, "eventTypeName": "Labyinth Dungeon Enter"}
68	2203	{"_key": 2203, "eventTypeName": "Labyinth Dungeon Finish"}
69	2204	{"_key": 2204, "eventTypeName": "Labyinth Finish"}
70	2346	{"_key": 2346, "eventTypeName": "Send Dungeon Message To Clients"}
71	2347	{"_key": 2347, "eventTypeName": "Send Message To Node Graph"}
72	2348	{"_key": 2348, "eventTypeName": "Blackboard Character List"}
73	2349	{"_key": 2349, "eventTypeName": "Blackboard List"}
74	2351	{"_key": 2351, "eventTypeName": "Add Contribution Value"}
75	2354	{"_key": 2354, "eventTypeName": "Blackboard Random Integer"}
\.


--
-- Name: eventtypes eventtypes_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.eventtypes
    ADD CONSTRAINT eventtypes_pkey PRIMARY KEY (row_no);


--
-- Name: eventtypes_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX eventtypes_key_idx ON sde_native.eventtypes USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict GgsuygKUP17vt3uMh2crR5tDgGUeAsOTBpITFFrrhcYcQUsR1ih57Wr3EAGGoUN

