--
-- PostgreSQL database dump
--

\restrict KcHFFWcTYgIGbsPb0vn42Z6q3JNKPveIbZkc7sMwdd2cFAyhOfHtRfEJvr0quYk

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: currencybuckets; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.currencybuckets (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: currencybuckets; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.currencybuckets (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "capacity": 25000, "currency": "skillPoints", "redeemTypeID": 49756}
1	2	{"_key": 2, "capacity": 50000, "currency": "skillPoints", "redeemTypeID": 49809}
2	3	{"_key": 3, "capacity": 100000, "currency": "skillPoints", "redeemTypeID": 49810}
3	4	{"_key": 4, "capacity": 10000, "currency": "skillPoints", "redeemTypeID": 52520}
4	5	{"_key": 5, "capacity": 250000, "currency": "skillPoints", "redeemTypeID": 43680}
5	6	{"_key": 6, "capacity": 500000, "currency": "skillPoints", "redeemTypeID": 52269}
6	7	{"_key": 7, "capacity": 750000, "currency": "skillPoints", "redeemTypeID": 52270}
7	8	{"_key": 8, "capacity": 1000000, "currency": "skillPoints", "redeemTypeID": 52263}
8	12	{"_key": 12, "capacity": 150000, "currency": "skillPoints", "redeemTypeID": 54648}
9	15	{"_key": 15, "capacity": 75000, "currency": "skillPoints", "redeemTypeID": 63824}
10	16	{"_key": 16, "capacity": 125000, "currency": "skillPoints", "redeemTypeID": 63825}
\.


--
-- Name: currencybuckets currencybuckets_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.currencybuckets
    ADD CONSTRAINT currencybuckets_pkey PRIMARY KEY (row_no);


--
-- Name: currencybuckets_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX currencybuckets_key_idx ON sde_native.currencybuckets USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict KcHFFWcTYgIGbsPb0vn42Z6q3JNKPveIbZkc7sMwdd2cFAyhOfHtRfEJvr0quYk

