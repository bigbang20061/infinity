--
-- PostgreSQL database dump
--

\restrict xy4Z9bg6vzTyWnikDEBg1KPkHjfaNX2P5ShcAQj1Bi0WY1QYxJwfyXg3GSE5367

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: itemtraderrecipes; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.itemtraderrecipes (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: itemtraderrecipes; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.itemtraderrecipes (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "inputIsk": 0, "inputItems": {"78848": 1}, "outputItems": {"78867": 1}, "internalName": "for typeID 78868"}
1	2	{"_key": 2, "inputIsk": 0, "inputItems": {"78848": 1}, "outputItems": {"78872": 1}, "internalName": "for typeID 78869"}
2	3	{"_key": 3, "inputIsk": 0, "inputItems": {"78857": 1}, "outputItems": {"78873": 1}, "internalName": "for typeID 78870"}
3	4	{"_key": 4, "inputIsk": 0, "inputItems": {"78862": 1}, "outputItems": {"78874": 1}, "internalName": "for typeID 78871"}
4	5	{"_key": 5, "inputIsk": 0, "inputItems": {"36902": 1, "78886": 1, "78887": 1}, "outputItems": {"78906": 1}, "internalName": "for typeID 78907"}
5	6	{"_key": 6, "inputIsk": 0, "inputItems": {"78857": 1}, "outputItems": {"79117": 1}, "internalName": "for typeID 79115"}
6	7	{"_key": 7, "inputIsk": 0, "inputItems": {"78862": 1}, "outputItems": {"79118": 1}, "internalName": "for typeID 79116"}
7	8	{"_key": 8, "inputIsk": 0, "inputItems": {"34551": 1}, "outputItems": {"34556": 10}, "internalName": "for typeID 34498"}
8	9	{"_key": 9, "inputIsk": 0, "inputItems": {"34552": 1}, "outputItems": {"34557": 10}, "internalName": "typeID 34499"}
9	10	{"_key": 10, "inputIsk": 0, "inputItems": {"34553": 1}, "outputItems": {"34558": 10}, "internalName": "for typeID 34500"}
10	11	{"_key": 11, "inputIsk": 0, "inputItems": {"34554": 1}, "outputItems": {"34559": 10}, "internalName": "for typeID 34501"}
11	12	{"_key": 12, "inputIsk": 0, "inputItems": {"34555": 1}, "outputItems": {"34560": 10}, "internalName": "for typeID 34502"}
12	13	{"_key": 13, "inputIsk": 0, "inputItems": {"34540": 1, "34541": 1}, "outputItems": {"34575": 3, "36908": 10}, "internalName": "for typeID 36903"}
13	14	{"_key": 14, "inputIsk": 0, "inputItems": {"34542": 1, "34543": 1}, "outputItems": {"34575": 3, "36909": 10}, "internalName": "for typeID 36904"}
14	15	{"_key": 15, "inputIsk": 0, "inputItems": {"34544": 1, "34545": 1}, "outputItems": {"34575": 3, "36910": 10}, "internalName": "for typeID 36905"}
15	16	{"_key": 16, "inputIsk": 0, "inputItems": {"34548": 1, "34549": 1}, "outputItems": {"34575": 3, "36912": 10}, "internalName": "for typeID 36907"}
16	17	{"_key": 17, "inputIsk": 0, "inputItems": {"40541": 1}, "outputItems": {"30488": 1}, "internalName": "for typeID 40542"}
17	18	{"_key": 18, "inputIsk": 0, "inputItems": {"49789": 160}, "outputItems": {"48927": 2}, "internalName": "for typeID 49699"}
18	19	{"_key": 19, "inputIsk": 0, "inputItems": {"49787": 15}, "outputItems": {"48927": 1}, "internalName": "for typeID 49965"}
19	20	{"_key": 20, "inputIsk": 13000000, "inputItems": {"48927": 5, "50039": 1}, "outputItems": {"50045": 1}, "internalName": "for typeID 50017"}
20	21	{"_key": 21, "inputIsk": 25000000, "inputItems": {"48927": 5, "50039": 1}, "outputItems": {"50046": 1}, "internalName": "for typeID 50018"}
21	22	{"_key": 22, "inputIsk": 0, "inputItems": {"53291": 1}, "outputItems": {"53299": 1}, "internalName": "for typeID 53294"}
22	23	{"_key": 23, "inputIsk": 0, "inputItems": {"33569": 10}, "outputItems": {"53343": 1}, "internalName": "for typeID 53344"}
23	24	{"_key": 24, "inputIsk": 0, "inputItems": {"53476": 10}, "outputItems": {"56750": 1}, "internalName": "for typeID 56772"}
24	25	{"_key": 25, "inputIsk": 0, "inputItems": {"56950": 7}, "outputItems": {"90741": 1}, "internalName": "for typeID 57042"}
25	26	{"_key": 26, "inputIsk": 0, "inputItems": {"57028": 7}, "outputItems": {"90743": 1}, "internalName": "for typeID 57047"}
26	27	{"_key": 27, "inputIsk": 0, "inputItems": {"57027": 7}, "outputItems": {"90742": 1}, "internalName": "for typeID 57048"}
27	28	{"_key": 28, "inputIsk": 0, "inputItems": {"72902": 10000}, "outputItems": {"73248": 5}, "internalName": "for typeID 72921"}
28	29	{"_key": 29, "inputIsk": 0, "inputItems": {"72935": 10000}, "outputItems": {"73249": 5}, "internalName": "for typeID 72930"}
29	30	{"_key": 30, "inputIsk": 0, "inputItems": {"72373": 100}, "outputItems": {"73250": 10}, "internalName": "for typeID 73254"}
30	31	{"_key": 31, "inputIsk": 0, "inputItems": {"72373": 100}, "outputItems": {"73251": 10}, "internalName": "for typeID 73255"}
31	32	{"_key": 32, "inputIsk": 0, "inputItems": {"73041": 100}, "outputItems": {"73248": 10}, "internalName": "for typeID 73267"}
32	33	{"_key": 33, "inputIsk": 0, "inputItems": {"76203": 10}, "outputItems": {"76216": 1}, "internalName": "for typeID 73268"}
33	34	{"_key": 34, "inputIsk": 0, "inputItems": {"76375": 1}, "outputItems": {"76214": 2}, "internalName": "for typeID 76218"}
34	35	{"_key": 35, "inputIsk": 0, "inputItems": {"76375": 1}, "outputItems": {"76215": 2}, "internalName": "for typeID 76219"}
35	36	{"_key": 36, "inputIsk": 0, "inputItems": {"76375": 1}, "outputItems": {"76216": 2}, "internalName": "for typeID 76220"}
36	37	{"_key": 37, "inputIsk": 0, "inputItems": {"76375": 1}, "outputItems": {"76217": 2}, "internalName": "for typeID 76221"}
37	38	{"_key": 38, "inputIsk": 0, "inputItems": {"76203": 10}, "outputItems": {"76215": 1}, "internalName": "for typeID 76321"}
38	39	{"_key": 39, "inputIsk": 0, "inputItems": {"76204": 10}, "outputItems": {"76216": 1}, "internalName": "for typeID 76322"}
39	40	{"_key": 40, "inputIsk": 0, "inputItems": {"76204": 10}, "outputItems": {"76214": 1}, "internalName": "for typeID 76323"}
40	41	{"_key": 41, "inputIsk": 0, "inputItems": {"76204": 10}, "outputItems": {"76217": 1}, "internalName": "for typeID 76324"}
41	42	{"_key": 42, "inputIsk": 0, "inputItems": {"85316": 30}, "outputItems": {"85787": 1}, "internalName": "for typeID 85632"}
42	43	{"_key": 43, "inputIsk": 0, "inputItems": {"85242": 1}, "outputItems": {"85880": 1}, "internalName": "for typeID 85632"}
43	52	{"_key": 52, "inputIsk": 0, "inputItems": {"34546": 1, "34547": 1}, "outputItems": {"34575": 3, "36911": 10}, "internalName": "for typeID 36906"}
44	54	{"_key": 54, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85746": 25200}, "outputItems": {"86270": 1}, "internalName": "ZZ Tholos Infomorph BPC", "displayNameID": 871628}
45	55	{"_key": 55, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85746": 67200}, "outputItems": {"86271": 1}, "internalName": "ZZ Cenotaph Infomorph BPC", "displayNameID": 871627}
46	56	{"_key": 56, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"85746": 360}, "outputItems": {"86272": 1}, "internalName": "ZZ SCARAB Breacher Pod S Blueprint Crate", "displayNameID": 871626}
47	57	{"_key": 57, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"85746": 720}, "outputItems": {"86273": 1}, "internalName": "ZZ SCARAB Breacher Pod M Blueprint Crate", "displayNameID": 871625}
48	58	{"_key": 58, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"85746": 4800}, "outputItems": {"86104": 1}, "internalName": "ZZ  Edge of Cerulean Matte", "displayNameID": 871624}
49	59	{"_key": 59, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"85746": 26400}, "outputItems": {"86107": 1}, "internalName": "ZZ  Deathless Covenant - Limited", "displayNameID": 871623}
50	60	{"_key": 60, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"85746": 12000}, "outputItems": {"86106": 1}, "internalName": "ZZ  Coronal Horizon Bronze Metallic", "displayNameID": 871622}
51	62	{"_key": 62, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"85316": 425}, "outputItems": {"86106": 1}, "internalName": "ZZ  Coronal Horizon Bronze Metallic Atavum", "displayNameID": 871621}
52	63	{"_key": 63, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"85316": 940}, "outputItems": {"86107": 1}, "internalName": "ZZ  Deathless Covenant - Limited Atavum", "displayNameID": 871620}
53	64	{"_key": 64, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"85316": 170}, "outputItems": {"86104": 1}, "internalName": "ZZ  Edge of Cerulean Matte Atavum", "displayNameID": 871619}
54	65	{"_key": 65, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85316": 2390}, "outputItems": {"86271": 1}, "internalName": "ZZ Cenotaph Atavum BPC", "displayNameID": 871618}
55	66	{"_key": 66, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"85316": 25}, "outputItems": {"86273": 1}, "internalName": "ZZ SCARAB Breacher Pod M Blueprint Crate Atavum", "displayNameID": 871617}
56	67	{"_key": 67, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"85316": 15}, "outputItems": {"86272": 1}, "internalName": "ZZ SCARAB Breacher Pod S Blueprint Crate Atavum", "displayNameID": 871616}
57	68	{"_key": 68, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85316": 895}, "outputItems": {"86270": 1}, "internalName": "ZZ Tholos Atavum BPC", "displayNameID": 871615}
58	69	{"_key": 69, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85746": 24000}, "outputItems": {"86270": 1}, "internalName": "WH Tholos Infomorph BPC", "displayNameID": 871614}
59	70	{"_key": 70, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"85746": 290}, "outputItems": {"86272": 1}, "internalName": "WH SCARAB Breacher Pod S Blueprint Crate", "displayNameID": 871613}
60	71	{"_key": 71, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"85746": 580}, "outputItems": {"86273": 1}, "internalName": "WH SCARAB Breacher Pod M Blueprint Crate", "displayNameID": 871612}
61	72	{"_key": 72, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85746": 60000}, "outputItems": {"86271": 1}, "internalName": "WH Cenotaph Infomorph BPC", "displayNameID": 871611}
62	73	{"_key": 73, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"85746": 4320}, "outputItems": {"86104": 1}, "internalName": "WH Edge of Cerulean Matte", "displayNameID": 871610}
63	74	{"_key": 74, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"85746": 24000}, "outputItems": {"86107": 1}, "internalName": "WH Deathless Covenant - Limited", "displayNameID": 871609}
64	75	{"_key": 75, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"85746": 11520}, "outputItems": {"86106": 1}, "internalName": "WH Coronal Horizon Bronze Metallic", "displayNameID": 871608}
65	76	{"_key": 76, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85316": 855}, "outputItems": {"86270": 1}, "internalName": "WH Tholos Atavum BPC", "displayNameID": 871607}
66	78	{"_key": 78, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"85316": 20}, "outputItems": {"86273": 1}, "internalName": "WH SCARAB Breacher Pod M Blueprint Crate Atavum", "displayNameID": 871605}
67	79	{"_key": 79, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85316": 2130}, "outputItems": {"86271": 1}, "internalName": "WH Cenotaph Atavum BPC", "displayNameID": 871604}
68	80	{"_key": 80, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"85316": 155}, "outputItems": {"86104": 1}, "internalName": "WH Edge of Cerulean Matte Atavum", "displayNameID": 871603}
69	81	{"_key": 81, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"85316": 855}, "outputItems": {"86107": 1}, "internalName": "WH Deathless Covenant - Limited Atavum", "displayNameID": 871602}
70	82	{"_key": 82, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"85316": 410}, "outputItems": {"86106": 1}, "internalName": "WH Coronal Horizon Bronze Metallic Atavum", "displayNameID": 871601}
71	83	{"_key": 83, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85746": 2400}, "outputItems": {"86274": 1}, "internalName": "ZZ Small Breacher Pod Launcher Blueprint Crate Infomorph", "displayNameID": 871600}
72	84	{"_key": 84, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85746": 4080}, "outputItems": {"86275": 1}, "internalName": "ZZ Medium Breacher Pod Launcher Blueprint Crate Infomorph", "displayNameID": 871599}
73	85	{"_key": 85, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85316": 145}, "outputItems": {"86275": 1}, "internalName": "ZZ Medium Breacher Pod Launcher Blueprint Crate Atavum", "displayNameID": 871598}
74	86	{"_key": 86, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85316": 85}, "outputItems": {"86274": 1}, "internalName": "ZZ Small Breacher Pod Launcher Blueprint Crate Atavum", "displayNameID": 871597}
75	87	{"_key": 87, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85316": 75}, "outputItems": {"86274": 1}, "internalName": "WH Small Breacher Pod Launcher Blueprint Crate Atavum", "displayNameID": 871596}
76	88	{"_key": 88, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85316": 130}, "outputItems": {"86275": 1}, "internalName": "WH Medium Breacher Pod Launcher Blueprint Crate Atavum", "displayNameID": 871595}
77	89	{"_key": 89, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85746": 3600}, "outputItems": {"86275": 1}, "internalName": "WH Medium Breacher Pod Launcher Blueprint Crate Infomorph", "displayNameID": 871594}
78	90	{"_key": 90, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85746": 2160}, "outputItems": {"86274": 1}, "internalName": "WH Small Breacher Pod Launcher Blueprint Crate Infomorph", "displayNameID": 871593}
79	91	{"_key": 91, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"85316": 10}, "outputItems": {"86272": 1}, "internalName": "WH SCARAB Breacher Pod S Blueprint Crate Atavum", "displayNameID": 871592}
80	94	{"_key": 94, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"85316": 50}, "outputItems": {"86272": 1}, "internalName": "TEST WH SCARAB Breacher Pod S Blueprint Crate Atavum", "displayNameID": 871578}
81	95	{"_key": 95, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85316": 340}, "outputItems": {"86276": 1}, "internalName": "ZZ 'Seneschal' Mercenary Den Blueprint Crate Atavum", "displayNameID": 871591}
82	96	{"_key": 96, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85316": 300}, "outputItems": {"86276": 1}, "internalName": "WH 'Seneschal' Mercenary Den Blueprint Crate Atavum", "displayNameID": 871590}
83	97	{"_key": 97, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85746": 9600}, "outputItems": {"86276": 1}, "internalName": "ZZ 'Seneschal' Mercenary Den Blueprint Crate Infomorph ", "displayNameID": 871589}
84	98	{"_key": 98, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"85746": 8400}, "outputItems": {"86276": 1}, "internalName": "WH 'Seneschal' Mercenary Den Blueprint Crate Infomorph ", "displayNameID": 871588}
85	99	{"_key": 99, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85316": 205}, "outputItems": {"86260": 1}, "internalName": "WH  Breacher Pod Launcher Operation Atavum", "displayNameID": 871629}
86	100	{"_key": 100, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85746": 5760}, "outputItems": {"86260": 1}, "internalName": "WH  Breacher Pod Launcher Operation Infomorph", "displayNameID": 871630}
87	101	{"_key": 101, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85746": 6480}, "outputItems": {"86260": 1}, "internalName": "ZZ  Breacher Pod Launcher Operation Infomorph", "displayNameID": 871631}
88	102	{"_key": 102, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85316": 230}, "outputItems": {"86260": 1}, "internalName": "ZZ  Breacher Pod Launcher Operation Atavum", "displayNameID": 871632}
89	103	{"_key": 103, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85316": 385}, "outputItems": {"86261": 1}, "internalName": "ZZ  Breacher Pod Clone Efficacity Atavum", "displayNameID": 871633}
90	104	{"_key": 104, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85746": 10800}, "outputItems": {"86261": 1}, "internalName": "ZZ  Breacher Pod Clone Efficacity Infomorph", "displayNameID": 871634}
91	105	{"_key": 105, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85746": 9600}, "outputItems": {"86261": 1}, "internalName": "WH Breacher Pod Clone Efficacity Infomorph", "displayNameID": 871635}
92	106	{"_key": 106, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85316": 340}, "outputItems": {"86261": 1}, "internalName": "WH Breacher Pod Clone Efficacity Atavum", "displayNameID": 871636}
93	107	{"_key": 107, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85316": 340}, "outputItems": {"86263": 1}, "internalName": "WH Breacher Pod Projection Atavum", "displayNameID": 871637}
94	108	{"_key": 108, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85746": 9600}, "outputItems": {"86263": 1}, "internalName": "WH Breacher Pod Projection Infomorph", "displayNameID": 871638}
95	109	{"_key": 109, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85746": 10800}, "outputItems": {"86263": 1}, "internalName": "ZZ Breacher Pod Projection Infomorph", "displayNameID": 871639}
96	110	{"_key": 110, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85316": 385}, "outputItems": {"86263": 1}, "internalName": "ZZ Breacher Pod Projection Atavum", "displayNameID": 871640}
97	111	{"_key": 111, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85316": 385}, "outputItems": {"86264": 1}, "internalName": "ZZ Breacher Pod Rapid Firing Atavum", "displayNameID": 871641}
98	112	{"_key": 112, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85746": 10800}, "outputItems": {"86264": 1}, "internalName": "ZZ Breacher Pod Rapid Firing Infomorph", "displayNameID": 871642}
99	113	{"_key": 113, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85746": 9600}, "outputItems": {"86264": 1}, "internalName": "WH Breacher Pod Rapid Firing Infomorph", "displayNameID": 871643}
100	114	{"_key": 114, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85316": 340}, "outputItems": {"86264": 1}, "internalName": "WH Breacher Pod Rapid Firing Atavum", "displayNameID": 871644}
101	115	{"_key": 115, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85316": 480}, "outputItems": {"86262": 1}, "internalName": "WH Breacher Pod Clone Longevity Atavum", "displayNameID": 871645}
102	116	{"_key": 116, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85746": 13440}, "outputItems": {"86262": 1}, "internalName": "WH Breacher Pod Clone Longevity Infomorph", "displayNameID": 871646}
103	117	{"_key": 117, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85746": 14400}, "outputItems": {"86262": 1}, "internalName": "ZZ Breacher Pod Clone Longevity Infomorph", "displayNameID": 871647}
104	118	{"_key": 118, "groupID": "SKILLBOOKS", "inputIsk": 0, "inputItems": {"85316": 510}, "outputItems": {"86262": 1}, "internalName": "ZZ Breacher Pod Clone Longevity Atavum", "displayNameID": 871648}
105	119	{"_key": 119, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"85316": 170}, "outputItems": {"86105": 1}, "internalName": "ZZ Circle Carmine Matte - Limited Atavum", "displayNameID": 871649}
106	120	{"_key": 120, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"85746": 4800}, "outputItems": {"86105": 1}, "internalName": "ZZ Circle Carmine Matte - Limited Infomorph", "displayNameID": 871650}
107	121	{"_key": 121, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"85746": 4320}, "outputItems": {"86105": 1}, "internalName": "WH Circle Carmine Matte - Limited Infomorph", "displayNameID": 871651}
108	122	{"_key": 122, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"85316": 155}, "outputItems": {"86105": 1}, "internalName": "WH Circle Carmine Matte - Limited Atavum", "displayNameID": 871652}
109	123	{"_key": 123, "inputIsk": 0, "inputItems": {"77030": 10000}, "outputItems": {"77086": 1}, "internalName": "for type 77016"}
110	124	{"_key": 124, "inputIsk": 0, "inputItems": {"86400": 1}, "outputItems": {"86472": 1}, "internalName": "for type 86471"}
111	125	{"_key": 125, "inputIsk": 0, "inputItems": {"86399": 1}, "outputItems": {"86494": 1}, "internalName": "for type 86493"}
112	126	{"_key": 126, "inputIsk": 0, "inputItems": {"86398": 1}, "outputItems": {"86403": 1}, "internalName": "for type 86597"}
113	127	{"_key": 127, "inputIsk": 0, "inputItems": {"87337": 1, "87338": 1, "87339": 1, "87340": 1, "87341": 1, "87342": 1, "87343": 1, "87344": 1, "87345": 1, "87346": 1, "87347": 1, "87348": 1}, "outputItems": {"87360": 1}, "internalName": "Darkness Revealed Puzzle Crate", "displayNameID": 1008894}
114	128	{"_key": 128, "inputIsk": 0, "inputItems": {"87601": 1, "87604": 1, "87606": 1, "87607": 1}, "outputItems": {"88263": 1}, "internalName": "Maze - Tyrannos Armor Command Burst", "displayNameID": 1009809}
115	129	{"_key": 129, "inputIsk": 0, "inputItems": {"87608": 1}, "outputItems": {"88053": 1}, "internalName": "Maze - Kikimora Tyrantbreaker SKIN", "displayNameID": 1012992}
116	130	{"_key": 130, "inputIsk": 0, "inputItems": {"87603": 36, "87606": 6}, "outputItems": {"47700": 1}, "internalName": "Maze - Unstable Stasis Webifier Mutaplasmid", "displayNameID": 1012994}
117	131	{"_key": 131, "inputIsk": 0, "inputItems": {"87604": 3, "87605": 21}, "outputItems": {"47755": 1}, "internalName": "Maze - Unstable 100MN Afterburner Mutaplasmid", "displayNameID": 1012995}
118	132	{"_key": 132, "inputIsk": 0, "inputItems": {"87601": 1, "87604": 1, "87606": 1, "87607": 1}, "outputItems": {"88261": 1}, "internalName": "Maze - Vigilant Shield Command Burst", "displayNameID": 1012991}
119	133	{"_key": 133, "inputIsk": 0, "inputItems": {"87602": 60, "87607": 9}, "outputItems": {"52226": 1}, "internalName": "Maze - Unstable Damage Control Mutaplasmid", "displayNameID": 1012993}
120	134	{"_key": 134, "inputIsk": 0, "inputItems": {"88087": 10000}, "outputItems": {"88351": 1}, "internalName": "Vis Vitalis Volatile Booster", "displayNameID": 1013226}
121	135	{"_key": 135, "inputIsk": 0, "inputItems": {"88087": 10000}, "outputItems": {"88353": 1}, "internalName": "Theriac Volatile Booster", "displayNameID": 1013227}
122	136	{"_key": 136, "inputIsk": 0, "inputItems": {"88087": 10000}, "outputItems": {"88352": 1}, "internalName": "Balneum Volatile Booster", "displayNameID": 1013228}
123	137	{"_key": 137, "inputIsk": 0, "inputItems": {"88087": 10000}, "outputItems": {"88354": 1}, "internalName": "Mithridate Volatile Booster", "displayNameID": 1013229}
124	138	{"_key": 138, "inputIsk": 0, "inputItems": {"88087": 10000}, "outputItems": {"88350": 1}, "internalName": "Aegytica Volatile Booster", "displayNameID": 1013230}
125	139	{"_key": 139, "inputIsk": 0, "inputItems": {"88179": 1}, "outputItems": {"88051": 1}, "internalName": "Astero Tyrantbreaker SKIN", "displayNameID": 1013231}
126	140	{"_key": 140, "inputIsk": 0, "inputItems": {"87605": 3, "87606": 1}, "outputItems": {"31908": 1}, "internalName": "Imperial Navy 400mm Steel Plates", "displayNameID": 1013232}
127	141	{"_key": 141, "inputIsk": 0, "inputItems": {"87603": 60, "87607": 8}, "outputItems": {"17547": 1}, "internalName": "Imperial Navy Medium Armor Repairer", "displayNameID": 1013233}
128	142	{"_key": 142, "inputIsk": 0, "inputItems": {"87602": 20, "87604": 3}, "outputItems": {"15810": 1}, "internalName": "Imperial Navy Heat Sink", "displayNameID": 1013234}
129	143	{"_key": 143, "inputIsk": 0, "inputItems": {"87605": 25, "87606": 4}, "outputItems": {"16064": 1}, "internalName": "Caldari Navy Heavy Missile Launcher", "displayNameID": 1013235}
130	144	{"_key": 144, "inputIsk": 0, "inputItems": {"87603": 3, "87607": 1}, "outputItems": {"31926": 1}, "internalName": "Caldari Navy Medium Shield Extender", "displayNameID": 1013236}
131	145	{"_key": 145, "inputIsk": 0, "inputItems": {"87602": 120, "87604": 15}, "outputItems": {"17498": 1}, "internalName": "Caldari Navy Multispectrum Shield Hardener", "displayNameID": 1013237}
132	146	{"_key": 146, "inputIsk": 0, "inputItems": {"87605": 130, "87606": 15}, "outputItems": {"54749": 1}, "internalName": "Medium Consortium Vorton Projector", "displayNameID": 1013239}
133	147	{"_key": 147, "inputIsk": 0, "inputItems": {"87603": 70, "87607": 10}, "outputItems": {"78624": 1}, "internalName": "Unstable Vorton Tuning System Mutaplasmid", "displayNameID": 1013240}
134	148	{"_key": 148, "inputIsk": 0, "inputItems": {"87602": 5, "87604": 1}, "outputItems": {"41215": 1}, "internalName": "Republic Fleet Medium Cap Battery", "displayNameID": 1013241}
135	149	{"_key": 149, "inputIsk": 0, "inputItems": {"87605": 15, "87606": 3}, "outputItems": {"16054": 1}, "internalName": "Republic Fleet 425mm Autocannon", "displayNameID": 1013242}
136	150	{"_key": 150, "inputIsk": 0, "inputItems": {"87603": 10, "87607": 2}, "outputItems": {"15753": 1}, "internalName": "Republic Fleet 10MN Afterburner", "displayNameID": 1013243}
137	151	{"_key": 151, "inputIsk": 0, "inputItems": {"87605": 20, "87606": 3}, "outputItems": {"47919": 1}, "internalName": "Veles Heavy Entropic Disintegrator", "displayNameID": 1013245}
138	152	{"_key": 152, "inputIsk": 0, "inputItems": {"87603": 10, "87607": 1}, "outputItems": {"49774": 1}, "internalName": "Perun Heavy Mutadaptive Remote Armor Repairer", "displayNameID": 1013246}
139	153	{"_key": 153, "inputIsk": 0, "inputItems": {"87602": 85, "87604": 12}, "outputItems": {"54915": 1}, "internalName": "Drekavac Kybernaut Clade SKIN", "displayNameID": 1013247}
140	154	{"_key": 154, "inputIsk": 0, "inputItems": {"88087": 15000}, "outputItems": {"88353": 1}, "internalName": "Theriac Volatile Booster - High sec cost", "displayNameID": 1013927}
141	155	{"_key": 155, "inputIsk": 0, "inputItems": {"88087": 15000}, "outputItems": {"88354": 1}, "internalName": "Mithridate Volatile Booster - High sec cost", "displayNameID": 1013928}
142	156	{"_key": 156, "inputIsk": 0, "inputItems": {"87603": 15, "87607": 3}, "outputItems": {"15753": 1}, "internalName": "Republic Fleet 10MN Afterburner - High sec cost", "displayNameID": 1013929}
143	157	{"_key": 157, "inputIsk": 0, "inputItems": {"87605": 23, "87606": 5}, "outputItems": {"16054": 1}, "internalName": "Republic Fleet 425mm Autocannon - High sec cost", "displayNameID": 1013930}
144	158	{"_key": 158, "inputIsk": 0, "inputItems": {"87602": 8, "87604": 2}, "outputItems": {"41215": 1}, "internalName": "Republic Fleet Medium Cap Battery - High sec cost", "displayNameID": 1013931}
145	159	{"_key": 159, "inputIsk": 0, "inputItems": {"88179": 2}, "outputItems": {"88051": 1}, "internalName": "Astero Tyrantbreaker SKIN  - High sec cost", "displayNameID": 1013933}
146	160	{"_key": 160, "inputIsk": 0, "inputItems": {"88087": 15000}, "outputItems": {"88352": 1}, "internalName": "Balneum Volatile Booster - High sec cost", "displayNameID": 1013938}
147	161	{"_key": 161, "inputIsk": 0, "inputItems": {"87605": 38, "87606": 6}, "outputItems": {"16064": 1}, "internalName": "Caldari Navy Heavy Missile Launcher - High sec cost", "displayNameID": 1013940}
148	162	{"_key": 162, "inputIsk": 0, "inputItems": {"87603": 5, "87607": 2}, "outputItems": {"31926": 1}, "internalName": "Caldari Navy Medium Shield Extender - High sec cost", "displayNameID": 1013943}
149	163	{"_key": 163, "inputIsk": 0, "inputItems": {"87602": 180, "87604": 23}, "outputItems": {"17498": 1}, "internalName": "Caldari Navy Multispectrum Shield Hardener - High sec cost", "displayNameID": 1013944}
150	164	{"_key": 164, "inputIsk": 0, "inputItems": {"88087": 15000}, "outputItems": {"88351": 1}, "internalName": "Vis Vitalis Volatile Booster - High sec cost", "displayNameID": 1013950}
151	165	{"_key": 165, "inputIsk": 0, "inputItems": {"87605": 5, "87606": 2}, "outputItems": {"31908": 1}, "internalName": "Imperial Navy 400mm Steel Plates - High sec cost", "displayNameID": 1013951}
152	166	{"_key": 166, "inputIsk": 0, "inputItems": {"87603": 90, "87607": 12}, "outputItems": {"17547": 1}, "internalName": "Imperial Navy Medium Armor Repairer - High sec cost", "displayNameID": 1013953}
153	167	{"_key": 167, "inputIsk": 0, "inputItems": {"87602": 30, "87604": 5}, "outputItems": {"15810": 1}, "internalName": "Imperial Navy Heat Sink - High sec cost", "displayNameID": 1013956}
154	168	{"_key": 168, "inputIsk": 0, "inputItems": {"88087": 15000}, "outputItems": {"88350": 1}, "internalName": "Aegytica Volatile Booster - High sec cost", "displayNameID": 1013958}
155	169	{"_key": 169, "inputIsk": 0, "inputItems": {"87605": 195, "87606": 23}, "outputItems": {"54749": 1}, "internalName": "Medium Consortium Vorton Projector - High sec cost", "displayNameID": 1013961}
156	170	{"_key": 170, "inputIsk": 0, "inputItems": {"87603": 105, "87607": 15}, "outputItems": {"78624": 1}, "internalName": "Unstable Vorton Tuning System Mutaplasmid - High sec cost", "displayNameID": 1013964}
157	171	{"_key": 171, "inputIsk": 0, "inputItems": {"87602": 8, "87604": 2}, "outputItems": {"41215": 1}, "internalName": "Republic Fleet Medium Cap Battery - High sec cost", "displayNameID": 1013966}
158	172	{"_key": 172, "inputIsk": 0, "inputItems": {"87605": 30, "87606": 5}, "outputItems": {"47919": 1}, "internalName": "Veles Heavy Entropic Disintegrator - High sec cost", "displayNameID": 1013967}
159	173	{"_key": 173, "inputIsk": 0, "inputItems": {"87603": 15, "87607": 2}, "outputItems": {"49774": 1}, "internalName": "Perun Heavy Mutadaptive Remote Armor Repairer - High sec cost", "displayNameID": 1013968}
160	174	{"_key": 174, "inputIsk": 0, "inputItems": {"87602": 128, "87604": 18}, "outputItems": {"54915": 1}, "internalName": "Drekavac Kybernaut Clade SKIN - High sec cost", "displayNameID": 1013970}
161	175	{"_key": 175, "inputIsk": 0, "inputItems": {"88568": 1}, "outputItems": {"88048": 1}, "internalName": "Maze - Skybreaker Tyrantbreaker SKIN", "displayNameID": 1014579}
162	176	{"_key": 176, "inputIsk": 0, "inputItems": {"87602": 90, "87607": 15}, "outputItems": {"52226": 1}, "internalName": "Maze - Unstable Damage Control Mutaplasmid - HS", "displayNameID": 1014673}
163	177	{"_key": 177, "inputIsk": 0, "inputItems": {"87603": 54, "87606": 9}, "outputItems": {"47700": 1}, "internalName": "Maze - Unstable Stasis Webifier Mutaplasmid - HS", "displayNameID": 1014672}
164	178	{"_key": 178, "inputIsk": 0, "inputItems": {"87604": 6, "87605": 33}, "outputItems": {"47755": 1}, "internalName": "Maze - Unstable 100MN Afterburner Mutaplasmid - HS", "displayNameID": 1014671}
165	180	{"_key": 180, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89712": 1}, "internalName": "Omen Arkombine Arisen SKIN", "displayNameID": 1018416}
166	181	{"_key": 181, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89711": 1}, "internalName": "Zealot Arkombine Arisen SKIN", "displayNameID": 1018417}
167	182	{"_key": 182, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89665": 1}, "internalName": "Gila Arkombine Arisen SKIN", "displayNameID": 1018418}
168	183	{"_key": 183, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89664": 1}, "internalName": "Rapier Arkombine Arisen SKIN", "displayNameID": 1018415}
169	184	{"_key": 184, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89663": 1}, "internalName": "Huginn Arkombine Arisen SKIN", "displayNameID": 1018495}
170	185	{"_key": 185, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89662": 1}, "internalName": "Bellicose Arkombine Arisen SKIN", "displayNameID": 1018496}
171	186	{"_key": 186, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89661": 1}, "internalName": "Vagabond Arkombine Arisen SKIN", "displayNameID": 1018497}
172	187	{"_key": 187, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89660": 1}, "internalName": "Sleipnir Arkombine Arisen SKIN", "displayNameID": 1018498}
173	188	{"_key": 188, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89659": 1}, "internalName": "Stabber Arkombine Arisen SKIN", "displayNameID": 1018499}
174	189	{"_key": 189, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89658": 1}, "internalName": "Hurricane Arkombine Arisen SKIN", "displayNameID": 1018500}
175	190	{"_key": 190, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89657": 1}, "internalName": "Ishtar Arkombine Arisen SKIN", "displayNameID": 1018501}
176	191	{"_key": 191, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89656": 1}, "internalName": "Enyo Arkombine Arisen SKIN", "displayNameID": 1018502}
177	192	{"_key": 192, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89655": 1}, "internalName": "Ishkur Arkombine Arisen SKIN", "displayNameID": 1018503}
178	193	{"_key": 193, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89654": 1}, "internalName": "Vexor Arkombine Arisen SKIN", "displayNameID": 1018504}
179	194	{"_key": 194, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89653": 1}, "internalName": "Incursus Arkombine Arisen SKIN", "displayNameID": 1018505}
180	195	{"_key": 195, "inputIsk": 0, "inputItems": {"89784": 10}, "outputItems": {"45635": 1}, "internalName": "Small Skill Injector", "displayNameID": 1018518}
181	196	{"_key": 196, "inputIsk": 0, "inputItems": {"89784": 1}, "outputItems": {"89692": 3}, "internalName": "Triple-star Sync - Limited", "displayNameID": 1018530}
182	197	{"_key": 197, "inputIsk": 0, "inputItems": {"89784": 1}, "outputItems": {"89691": 3}, "internalName": "Triform Virtuoso - Limited", "displayNameID": 1018531}
183	198	{"_key": 198, "inputIsk": 0, "inputItems": {"89784": 1}, "outputItems": {"89687": 3}, "internalName": "Orbital Cavalier - Limited", "displayNameID": 1018532}
184	199	{"_key": 199, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89688": 1}, "internalName": "Orbital Cavalier - Unlimited", "displayNameID": 1018533}
185	200	{"_key": 200, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89690": 1}, "internalName": "Triform Virtuoso - Unlimited", "displayNameID": 1018534}
186	201	{"_key": 201, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89693": 1}, "internalName": "Triple-star Sync - Unlimited", "displayNameID": 1018535}
187	202	{"_key": 202, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89698": 1}, "internalName": "Top Brass Metallic - Unlimited", "displayNameID": 1018536}
188	203	{"_key": 203, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89696": 1}, "internalName": "Veteran Gunmetal Metallic - Unlimited", "displayNameID": 1018537}
189	204	{"_key": 204, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89694": 1}, "internalName": "Cinderchrome Metallic - Unlimited", "displayNameID": 1018538}
190	205	{"_key": 205, "inputIsk": 0, "inputItems": {"89784": 1}, "outputItems": {"89695": 3}, "internalName": "Cinderchrome Metallic - Limited", "displayNameID": 1018539}
191	206	{"_key": 206, "inputIsk": 0, "inputItems": {"89784": 1}, "outputItems": {"89697": 3}, "internalName": "Veteran Gunmetal Metallic - Limited", "displayNameID": 1018540}
192	207	{"_key": 207, "inputIsk": 0, "inputItems": {"89784": 1}, "outputItems": {"89699": 3}, "internalName": "Top Brass Metallic - Limited", "displayNameID": 1018541}
193	208	{"_key": 208, "inputIsk": 0, "inputItems": {"89784": 1}, "outputItems": {"89710": 3}, "internalName": "Opal Mantle Gloss - Limited", "displayNameID": 1018542}
194	209	{"_key": 209, "inputIsk": 0, "inputItems": {"89784": 1}, "outputItems": {"89708": 3}, "internalName": "Triumphant Hematite Gloss - Limited", "displayNameID": 1018543}
195	210	{"_key": 210, "inputIsk": 0, "inputItems": {"89784": 1}, "outputItems": {"89706": 3}, "internalName": "Gun Smoke Grey Matte - Limited", "displayNameID": 1018544}
196	211	{"_key": 211, "inputIsk": 0, "inputItems": {"89784": 1}, "outputItems": {"89704": 3}, "internalName": "War Torn Skies Matte - Limited", "displayNameID": 1018545}
197	212	{"_key": 212, "inputIsk": 0, "inputItems": {"89784": 1}, "outputItems": {"89702": 3}, "internalName": "Saffron Noon Satin - Limited", "displayNameID": 1018546}
198	213	{"_key": 213, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89701": 1}, "internalName": "Saffron Noon Satin - Unlimited", "displayNameID": 1018547}
199	214	{"_key": 214, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89703": 1}, "internalName": "War Torn Skies Matte - Unlimited", "displayNameID": 1018548}
200	215	{"_key": 215, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89705": 1}, "internalName": "Gun Smoke Grey Matte - Unlimited", "displayNameID": 1018549}
201	216	{"_key": 216, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89707": 1}, "internalName": "Triumphant Hematite Gloss - Unlimited", "displayNameID": 1018550}
202	217	{"_key": 217, "inputIsk": 0, "inputItems": {"89784": 3}, "outputItems": {"89709": 1}, "internalName": "Opal Mantle Gloss - Unlimited", "displayNameID": 1018551}
203	218	{"_key": 218, "inputIsk": 0, "inputItems": {"88105": 50}, "outputItems": {"78906": 1}, "internalName": "GREAD M1 Ore Trade Recipe"}
204	219	{"_key": 219, "inputIsk": 0, "inputItems": {"34": 320000, "35": 60000, "36": 20000, "37": 4000}, "outputItems": {"90180": 1}, "internalName": "M2 ORE Epic Arc Item Trader Recipe - Pioneer Redemption Token", "displayNameID": 1019397}
205	220	{"_key": 220, "inputIsk": 0, "inputItems": {"90505": 160}, "outputItems": {"91009": 1}, "internalName": "for type 91008"}
206	221	{"_key": 221, "inputIsk": 0, "inputItems": {"90505": 130}, "outputItems": {"91009": 1}, "internalName": "for type 91010"}
207	222	{"_key": 222, "inputIsk": 0, "inputItems": {"56950": 7, "91082": 1}, "outputItems": {"91085": 1}, "internalName": "for type 57042"}
208	223	{"_key": 223, "inputIsk": 0, "inputItems": {"57028": 7, "91083": 1}, "outputItems": {"91086": 1}, "internalName": "For type 57047"}
209	224	{"_key": 224, "inputIsk": 0, "inputItems": {"57027": 7, "91084": 1}, "outputItems": {"91087": 1}, "internalName": "For type 57048"}
210	227	{"_key": 227, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92391": 25}, "outputItems": {"92005": 1}, "internalName": "Federation Electronics Booster IV", "displayNameID": 1038698}
211	228	{"_key": 228, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92391": 25}, "outputItems": {"92001": 1}, "internalName": "Federation Mobility Booster IV", "displayNameID": 1038699}
212	229	{"_key": 229, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92391": 25}, "outputItems": {"92032": 1}, "internalName": "Federation Damage Booster IV", "displayNameID": 1038700}
213	230	{"_key": 230, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92391": 25}, "outputItems": {"92028": 1}, "internalName": "Federation Projection Booster IV", "displayNameID": 1038701}
214	231	{"_key": 231, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92391": 25}, "outputItems": {"92024": 1}, "internalName": "Federation Application Booster IV", "displayNameID": 1038702}
215	232	{"_key": 232, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92391": 25}, "outputItems": {"92019": 1}, "internalName": "Federation Defense Booster IV", "displayNameID": 1038703}
216	233	{"_key": 233, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92391": 10}, "outputItems": {"92181": 1}, "internalName": "Gallente Election Booster Crate", "displayNameID": 1038704}
217	234	{"_key": 234, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92391": 50}, "outputItems": {"92160": 1}, "internalName": "Extended 'Demos' Cerebral Accelerator", "displayNameID": 1038705}
218	235	{"_key": 235, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92391": 25}, "outputItems": {"92161": 1}, "internalName": "Gallente ElectionCerebral Accelerator Crate", "displayNameID": 1038706}
219	236	{"_key": 236, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92391": 15}, "outputItems": {"92375": 1}, "internalName": "Gallente Election SKINr Crate", "displayNameID": 1038707}
220	237	{"_key": 237, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92391": 50}, "outputItems": {"92092": 1}, "internalName": "Gallente Election SKIN Crate", "displayNameID": 1038708}
221	238	{"_key": 238, "groupID": "DRONES", "inputIsk": 0, "inputItems": {"92391": 5}, "outputItems": {"92461": 1}, "internalName": "Gallente election Light TargetPaint/DPS Drone", "displayNameID": 1038709}
222	239	{"_key": 239, "groupID": "DRONES", "inputIsk": 0, "inputItems": {"92391": 10}, "outputItems": {"92462": 1}, "internalName": "Gallente Election Medium TargetPaint/DPS Drone", "displayNameID": 1038710}
223	240	{"_key": 240, "groupID": "DRONES", "inputIsk": 0, "inputItems": {"92391": 25}, "outputItems": {"92463": 1}, "internalName": "Gallente Election Heavy TargetPaint/DPS Drone", "displayNameID": 1038711}
224	241	{"_key": 241, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92391": 250}, "outputItems": {"92458": 1}, "internalName": "Gallente Election Faction skirmish command burst", "displayNameID": 1038712}
225	242	{"_key": 242, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92392": 4}, "outputItems": {"92451": 1}, "internalName": "Gallente Election Officer Guidance Disruptor", "displayNameID": 1038713}
226	243	{"_key": 243, "groupID": "DRONES", "inputIsk": 0, "inputItems": {"92391": 5}, "outputItems": {"92464": 1}, "internalName": "Gallente Election Light SensorDamp/DPS Drone", "displayNameID": 1038714}
227	244	{"_key": 244, "groupID": "DRONES", "inputIsk": 0, "inputItems": {"92391": 10}, "outputItems": {"92465": 1}, "internalName": "Gallente Election Medium SensorDamp/DPS Drone", "displayNameID": 1038715}
228	245	{"_key": 245, "groupID": "DRONES", "inputIsk": 0, "inputItems": {"92391": 25}, "outputItems": {"92466": 1}, "internalName": "Gallente Election Heavy SensorDamp/DPS Drone", "displayNameID": 1038716}
229	246	{"_key": 246, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92391": 250}, "outputItems": {"92455": 1}, "internalName": "Gallente Election Faction info command burst", "displayNameID": 1038717}
230	247	{"_key": 247, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92392": 4}, "outputItems": {"92453": 1}, "internalName": "Gallente Election Officer Scan Probe Launcher", "displayNameID": 1038718}
231	248	{"_key": 248, "groupID": "DRONES", "inputIsk": 0, "inputItems": {"92391": 5}, "outputItems": {"92467": 1}, "internalName": "Gallente Election Light TargetDrisrupt/DPS Drone", "displayNameID": 1038719}
232	249	{"_key": 249, "groupID": "DRONES", "inputIsk": 0, "inputItems": {"92391": 10}, "outputItems": {"92468": 1}, "internalName": "Gallente Election Medium TargetDrisrupt/DPS Drone", "displayNameID": 1038720}
233	250	{"_key": 250, "groupID": "DRONES", "inputIsk": 0, "inputItems": {"92391": 25}, "outputItems": {"92469": 1}, "internalName": "Gallente Election Heavy TargetDrisrupt/DPS Drone", "displayNameID": 1038721}
234	251	{"_key": 251, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92391": 250}, "outputItems": {"92456": 1}, "internalName": "Gallente Election Faction mining command burst", "displayNameID": 1038722}
235	252	{"_key": 252, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92392": 4}, "outputItems": {"92454": 1}, "internalName": "Gallente Election Officer Nanofiber Internal Structure", "displayNameID": 1038723}
236	253	{"_key": 253, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92569": 1000}, "outputItems": {"91947": 1}, "internalName": "Imperial Mobility Booster I", "displayNameID": 1038007}
237	254	{"_key": 254, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92569": 1000}, "outputItems": {"91962": 1}, "internalName": "Imperial Hardpoint Booster I", "displayNameID": 1038008}
238	255	{"_key": 255, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92569": 1000}, "outputItems": {"91916": 1}, "internalName": "Imperial Electronics Booster I", "displayNameID": 1038009}
239	256	{"_key": 256, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92569": 1000}, "outputItems": {"91932": 1}, "internalName": "Imperial Defense Booster I", "displayNameID": 1038010}
240	257	{"_key": 257, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92569": 4000}, "outputItems": {"91952": 1}, "internalName": "Imperial Mobility Booster II", "displayNameID": 1038012}
241	258	{"_key": 258, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92569": 20000}, "outputItems": {"91951": 1}, "internalName": "Imperial Mobility Booster III", "displayNameID": 1038014}
242	259	{"_key": 259, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92569": 4000}, "outputItems": {"91970": 1}, "internalName": "Imperial Hardpoint Booster II", "displayNameID": 1038015}
243	260	{"_key": 260, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92569": 20000}, "outputItems": {"91971": 1}, "internalName": "Imperial Hardpoint Booster III", "displayNameID": 1038016}
244	261	{"_key": 261, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92569": 4000}, "outputItems": {"91929": 1}, "internalName": "Imperial Electronics Booster II", "displayNameID": 1038017}
245	262	{"_key": 262, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92569": 20000}, "outputItems": {"91930": 1}, "internalName": "Imperial Electronics Booster III", "displayNameID": 1038018}
246	263	{"_key": 263, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92569": 4000}, "outputItems": {"91939": 1}, "internalName": "Imperial Defense Booster II", "displayNameID": 1038019}
247	264	{"_key": 264, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92569": 20000}, "outputItems": {"91940": 1}, "internalName": "Imperial Defense Booster III", "displayNameID": 1038020}
248	265	{"_key": 265, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92570": 1000}, "outputItems": {"91948": 1}, "internalName": "State Mobility Booster I", "displayNameID": 1038021}
249	266	{"_key": 266, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92570": 1000}, "outputItems": {"91963": 1}, "internalName": "State Hardpoint Booster I", "displayNameID": 1038022}
250	267	{"_key": 267, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92570": 1000}, "outputItems": {"91920": 1}, "internalName": "State Electronics Booster I", "displayNameID": 1038023}
251	268	{"_key": 268, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92570": 1000}, "outputItems": {"91934": 1}, "internalName": "State Defense Booster I", "displayNameID": 1038024}
252	269	{"_key": 269, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92570": 4000}, "outputItems": {"91953": 1}, "internalName": "State Mobility Booster II", "displayNameID": 1038025}
253	270	{"_key": 270, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92570": 20000}, "outputItems": {"91954": 1}, "internalName": "State Mobility Booster III", "displayNameID": 1038026}
254	271	{"_key": 271, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92570": 4000}, "outputItems": {"91972": 1}, "internalName": "State Hardpoint Booster II", "displayNameID": 1038027}
255	272	{"_key": 272, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92570": 20000}, "outputItems": {"91973": 1}, "internalName": "State Hardpoint Booster III", "displayNameID": 1038028}
256	273	{"_key": 273, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92570": 4000}, "outputItems": {"91927": 1}, "internalName": "State Electronics Booster II", "displayNameID": 1038029}
257	274	{"_key": 274, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92570": 20000}, "outputItems": {"91928": 1}, "internalName": "State Electronics Booster III", "displayNameID": 1038030}
258	275	{"_key": 275, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92570": 4000}, "outputItems": {"91941": 1}, "internalName": "State Defense Booster II", "displayNameID": 1038031}
259	276	{"_key": 276, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92570": 20000}, "outputItems": {"91942": 1}, "internalName": "State Defense Booster III", "displayNameID": 1038032}
260	277	{"_key": 277, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92571": 1000}, "outputItems": {"91949": 1}, "internalName": "Federation Mobility Booster I", "displayNameID": 1038033}
261	278	{"_key": 278, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92571": 4000}, "outputItems": {"91958": 1}, "internalName": "Federation Mobility Booster II", "displayNameID": 1038034}
262	279	{"_key": 279, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92571": 20000}, "outputItems": {"91959": 1}, "internalName": "Federation Mobility Booster III", "displayNameID": 1038035}
263	280	{"_key": 280, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92571": 1000}, "outputItems": {"91964": 1}, "internalName": "Federation Hardpoint Booster I", "displayNameID": 1038036}
264	281	{"_key": 281, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92571": 4000}, "outputItems": {"91974": 1}, "internalName": "Federation Hardpoint Booster II", "displayNameID": 1038037}
265	282	{"_key": 282, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92571": 20000}, "outputItems": {"91975": 1}, "internalName": "Federation Hardpoint Booster III", "displayNameID": 1038038}
266	283	{"_key": 283, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92571": 1000}, "outputItems": {"91921": 1}, "internalName": "Federation Electronics Booster I", "displayNameID": 1038039}
267	284	{"_key": 284, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92571": 4000}, "outputItems": {"91925": 1}, "internalName": "Federation Electronics Booster II", "displayNameID": 1038040}
268	285	{"_key": 285, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92571": 20000}, "outputItems": {"91926": 1}, "internalName": "Federation Electronics Booster III", "displayNameID": 1038041}
269	286	{"_key": 286, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92571": 1000}, "outputItems": {"91935": 1}, "internalName": "Federation Defense Booster I", "displayNameID": 1038042}
270	287	{"_key": 287, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92571": 4000}, "outputItems": {"91944": 1}, "internalName": "Federation Defense Booster II", "displayNameID": 1038043}
271	288	{"_key": 288, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92571": 20000}, "outputItems": {"91943": 1}, "internalName": "Federation Defense Booster III", "displayNameID": 1038044}
272	289	{"_key": 289, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92572": 1000}, "outputItems": {"91950": 1}, "internalName": "Republic Mobility Booster I", "displayNameID": 1038045}
273	290	{"_key": 290, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92572": 4000}, "outputItems": {"91960": 1}, "internalName": "Republic Mobility Booster II", "displayNameID": 1038046}
274	291	{"_key": 291, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92572": 20000}, "outputItems": {"91961": 1}, "internalName": "Republic Mobility Booster III", "displayNameID": 1038047}
275	292	{"_key": 292, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92572": 1000}, "outputItems": {"91965": 1}, "internalName": "Republic Hardpoint Booster I", "displayNameID": 1038048}
276	293	{"_key": 293, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92572": 4000}, "outputItems": {"91976": 1}, "internalName": "Republic Hardpoint Booster II", "displayNameID": 1038049}
277	294	{"_key": 294, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92572": 20000}, "outputItems": {"91977": 1}, "internalName": "Republic Hardpoint Booster III", "displayNameID": 1038050}
278	295	{"_key": 295, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92572": 1000}, "outputItems": {"91922": 1}, "internalName": "Republic Electronics Booster I", "displayNameID": 1038051}
279	296	{"_key": 296, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92572": 4000}, "outputItems": {"91923": 1}, "internalName": "Republic Electronics Booster II", "displayNameID": 1038052}
280	297	{"_key": 297, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92572": 20000}, "outputItems": {"91924": 1}, "internalName": "Republic Electronics Booster III", "displayNameID": 1038053}
281	298	{"_key": 298, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92572": 4000}, "outputItems": {"91945": 1}, "internalName": "Republic Defense Booster II", "displayNameID": 1038054}
282	299	{"_key": 299, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92572": 20000}, "outputItems": {"91946": 1}, "internalName": "Republic Defense Booster III", "displayNameID": 1038055}
283	300	{"_key": 300, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"92572": 1000}, "outputItems": {"91936": 1}, "internalName": "Republic Defense Booster I", "displayNameID": 1038056}
284	301	{"_key": 301, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92569": 100000}, "outputItems": {"92779": 1}, "internalName": "Crucifier Navy Issue War Reserves Lieutenant SKIN", "displayNameID": 1038140}
285	302	{"_key": 302, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92569": 250000}, "outputItems": {"92780": 1}, "internalName": "Omen Navy Issue War Reserves Lieutenant SKIN", "displayNameID": 1038142}
286	303	{"_key": 303, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92569": 400000}, "outputItems": {"92781": 1}, "internalName": "Harbinger Navy Issue War Reserves Lieutenant SKIN", "displayNameID": 1038145}
287	304	{"_key": 304, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92569": 400000}, "outputItems": {"92784": 1}, "internalName": "Prophecy Navy Issue War Reserves Lieutenant SKIN", "displayNameID": 1038146}
288	305	{"_key": 305, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92569": 500000}, "outputItems": {"92783": 1}, "internalName": "Armageddon Navy Issue War Reserves Lieutenant SKIN", "displayNameID": 1038147}
289	306	{"_key": 306, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92569": 500000}, "outputItems": {"92782": 1}, "internalName": "Apocalypse Navy Issue War Reserves Lieutenant SKIN", "displayNameID": 1038148}
290	307	{"_key": 307, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92570": 100000}, "outputItems": {"92785": 1}, "internalName": "Griffin Navy Issue Military Stockpile Captain SKIN", "displayNameID": 1038149}
291	308	{"_key": 308, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92570": 250000}, "outputItems": {"92786": 1}, "internalName": "Caracal Navy Issue Military Stockpile Captain SKIN", "displayNameID": 1038150}
292	309	{"_key": 309, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92570": 400000}, "outputItems": {"92787": 1}, "internalName": "Drake Navy Issue Military Stockpile Captain SKIN", "displayNameID": 1038151}
293	310	{"_key": 310, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92570": 400000}, "outputItems": {"92788": 1}, "internalName": "Ferox Navy Issue Military Stockpile Captain SKIN", "displayNameID": 1038152}
294	311	{"_key": 311, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92570": 500000}, "outputItems": {"92789": 1}, "internalName": "Scorpion Navy Issue Military Stockpile Captain SKIN", "displayNameID": 1038153}
295	312	{"_key": 312, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92570": 500000}, "outputItems": {"92790": 1}, "internalName": "Raven Navy Issue Military Stockpile Captain SKIN", "displayNameID": 1038154}
296	313	{"_key": 313, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92571": 100000}, "outputItems": {"92791": 1}, "internalName": "Maulus Navy Issue Strategic Materiel Defender SKIN", "displayNameID": 1038155}
297	314	{"_key": 314, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92571": 250000}, "outputItems": {"92792": 1}, "internalName": "Vexor Navy Issue Strategic Materiel Defender SKIN", "displayNameID": 1038156}
298	315	{"_key": 315, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92571": 400000}, "outputItems": {"92793": 1}, "internalName": "Myrmidon Navy Issue Strategic Materiel Defender SKIN", "displayNameID": 1038157}
299	316	{"_key": 316, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92571": 400000}, "outputItems": {"92794": 1}, "internalName": "Brutix Navy Issue Strategic Materiel Defender SKIN", "displayNameID": 1038158}
300	317	{"_key": 317, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92571": 500000}, "outputItems": {"92795": 1}, "internalName": "Dominix Navy Issue Strategic Materiel Defender SKIN", "displayNameID": 1038159}
301	318	{"_key": 318, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92571": 500000}, "outputItems": {"92796": 1}, "internalName": "Megathron Navy Issue Strategic Materiel Defender SKIN", "displayNameID": 1038160}
302	319	{"_key": 319, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92572": 100000}, "outputItems": {"92797": 1}, "internalName": "Vigil Fleet Issue Fleet Ordnance Spike SKIN", "displayNameID": 1038161}
303	320	{"_key": 320, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92572": 250000}, "outputItems": {"92798": 1}, "internalName": "Stabber Fleet Issue Fleet Ordnance Spike SKIN", "displayNameID": 1038167}
304	321	{"_key": 321, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92572": 400000}, "outputItems": {"92799": 1}, "internalName": "Hurricane Fleet Issue Fleet Ordnance Spike SKIN", "displayNameID": 1038163}
305	322	{"_key": 322, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92572": 400000}, "outputItems": {"92800": 1}, "internalName": "Cyclone Fleet Issue Fleet Ordnance Spike SKIN", "displayNameID": 1038164}
306	323	{"_key": 323, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92572": 500000}, "outputItems": {"92801": 1}, "internalName": "Tempest Fleet Issue Fleet Ordnance Spike SKIN", "displayNameID": 1038165}
307	324	{"_key": 324, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"92572": 500000}, "outputItems": {"92802": 1}, "internalName": "Typhoon Fleet Issue Fleet Ordnance Spike SKIN", "displayNameID": 1038166}
308	325	{"_key": 325, "groupID": "BACKGROUNDS", "inputIsk": 0, "inputItems": {"92391": 150}, "outputItems": {"92550": 1}, "internalName": "Tenzin's Gallente Background", "displayNameID": 1038724}
309	326	{"_key": 326, "groupID": "BACKGROUNDS", "inputIsk": 0, "inputItems": {"92391": 150}, "outputItems": {"92554": 1}, "internalName": "Moreau's Gallente Background", "displayNameID": 1038725}
310	327	{"_key": 327, "groupID": "BACKGROUNDS", "inputIsk": 0, "inputItems": {"92391": 150}, "outputItems": {"92555": 1}, "internalName": "Roden's Gallente Background", "displayNameID": 1038726}
311	328	{"_key": 328, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92391": 20}, "outputItems": {"92573": 1}, "internalName": "Federation Ascent - Limited", "displayNameID": 1038727}
312	329	{"_key": 329, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92391": 20}, "outputItems": {"92575": 1}, "internalName": "Federation Field - Limited", "displayNameID": 1038728}
313	330	{"_key": 330, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92391": 75}, "outputItems": {"92574": 1}, "internalName": "Federation Ascent - Unlimited", "displayNameID": 1038729}
314	331	{"_key": 331, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92391": 75}, "outputItems": {"92576": 1}, "internalName": "Federation Field - Unlimited", "displayNameID": 1038730}
315	332	{"_key": 332, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92391": 50}, "outputItems": {"92578": 1}, "internalName": "Verdigris Referendum Gloss - Unlimited", "displayNameID": 1038731}
316	333	{"_key": 333, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92391": 50}, "outputItems": {"92580": 1}, "internalName": "Civic Ember Matte - Unlimited", "displayNameID": 1038732}
317	334	{"_key": 334, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92391": 50}, "outputItems": {"92582": 1}, "internalName": "Diverse Unakite Matte - Unlimited", "displayNameID": 1038733}
318	335	{"_key": 335, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92391": 50}, "outputItems": {"92584": 1}, "internalName": "Senatorial Swamp Metallic - Unlimited", "displayNameID": 1038734}
319	336	{"_key": 336, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92391": 50}, "outputItems": {"92586": 1}, "internalName": "Turquoise Accord Metallic - Unlimited", "displayNameID": 1038735}
320	337	{"_key": 337, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92391": 50}, "outputItems": {"92588": 1}, "internalName": "Tei-Su Meadow Metallic - Unlimited", "displayNameID": 1038738}
321	338	{"_key": 338, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92391": 50}, "outputItems": {"92590": 1}, "internalName": "Caille Steel Metallic - Unlimited", "displayNameID": 1038740}
322	339	{"_key": 339, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92391": 50}, "outputItems": {"92592": 1}, "internalName": "Intaki Obsidian Metallic - Unlimited", "displayNameID": 1038741}
323	340	{"_key": 340, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92569": 6000}, "outputItems": {"93001": 1}, "internalName": "Imperial Benediction - Limited", "displayNameID": 1041210}
324	341	{"_key": 341, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92569": 3000}, "outputItems": {"92997": 1}, "internalName": "Empress Ivory Satin - Limited", "displayNameID": 1041212}
325	342	{"_key": 342, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92569": 3000}, "outputItems": {"92993": 1}, "internalName": "Honeyed Gold Satin - Limited", "displayNameID": 1041213}
326	343	{"_key": 343, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92569": 3000}, "outputItems": {"92991": 1}, "internalName": "Divine Bronze Metallic - Limited", "displayNameID": 1041214}
327	344	{"_key": 344, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92569": 15000}, "outputItems": {"93468": 1}, "internalName": "Empress Ivory Satin - Unlimited", "displayNameID": 1041215}
328	345	{"_key": 345, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92569": 30000}, "outputItems": {"93467": 1}, "internalName": "Divine Convergence - Unlimited", "displayNameID": 1041208}
329	346	{"_key": 346, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92569": 6000}, "outputItems": {"93000": 1}, "internalName": "Divine Convergence - Limited", "displayNameID": 1041209}
330	347	{"_key": 347, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92569": 30000}, "outputItems": {"93466": 1}, "internalName": "Imperial Benediction - Unlimited", "displayNameID": 1041211}
331	348	{"_key": 348, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92569": 15000}, "outputItems": {"93470": 1}, "internalName": "Honeyed Gold Satin - Unlimited", "displayNameID": 1041216}
332	349	{"_key": 349, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92569": 15000}, "outputItems": {"93469": 1}, "internalName": "Divine Bronze Metallic - Unlimited", "displayNameID": 1041217}
333	350	{"_key": 350, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92570": 6000}, "outputItems": {"93002": 1}, "internalName": "State Directive - Limited", "displayNameID": 1041248}
334	351	{"_key": 351, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92570": 30000}, "outputItems": {"93471": 1}, "internalName": "State Directive - Unlimited", "displayNameID": 1041219}
335	352	{"_key": 352, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92570": 6000}, "outputItems": {"93003": 1}, "internalName": " State Corridor - Limited", "displayNameID": 1041220}
336	353	{"_key": 353, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92570": 30000}, "outputItems": {"93472": 1}, "internalName": " State Corridor - Unlimited", "displayNameID": 1041221}
337	354	{"_key": 354, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92570": 3000}, "outputItems": {"92986": 1}, "internalName": "Plum Loyalty Gloss - Limited", "displayNameID": 1041222}
338	355	{"_key": 355, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92570": 15000}, "outputItems": {"93473": 1}, "internalName": "Plum Loyalty Gloss - Unlimited", "displayNameID": 1041223}
339	356	{"_key": 356, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92570": 3000}, "outputItems": {"92988": 1}, "internalName": "Megacorp White Satin - Limited", "displayNameID": 1041224}
340	357	{"_key": 357, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92570": 15000}, "outputItems": {"93474": 1}, "internalName": "Megacorp White Satin - Unlimited", "displayNameID": 1041225}
341	358	{"_key": 358, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92570": 3000}, "outputItems": {"92990": 1}, "internalName": "Breakout Midnight Matte - Limited", "displayNameID": 1041226}
342	359	{"_key": 359, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92570": 15000}, "outputItems": {"93475": 1}, "internalName": "Breakout Midnight Matte - Unlimited", "displayNameID": 1041227}
343	360	{"_key": 360, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92571": 6000}, "outputItems": {"93013": 1}, "internalName": "Federal Cohesion - Limited", "displayNameID": 1041228}
344	361	{"_key": 361, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92571": 30000}, "outputItems": {"93476": 1}, "internalName": "Federal Cohesion - Unlimited", "displayNameID": 1041229}
345	362	{"_key": 362, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92571": 6000}, "outputItems": {"93014": 1}, "internalName": "Federation Supports - Limited", "displayNameID": 1041230}
346	363	{"_key": 363, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92571": 30000}, "outputItems": {"93477": 1}, "internalName": "Federation Supports - Unlimited", "displayNameID": 1041231}
347	364	{"_key": 364, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92571": 3000}, "outputItems": {"92977": 1}, "internalName": "Lirautton Verdure Matte - Limited", "displayNameID": 1041232}
348	365	{"_key": 365, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92571": 15000}, "outputItems": {"93478": 1}, "internalName": "Lirautton Verdure Matte - Unlimited", "displayNameID": 1041233}
349	366	{"_key": 366, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92571": 3000}, "outputItems": {"92971": 1}, "internalName": "Anodized Freedom Metallic - Limited", "displayNameID": 1041234}
350	367	{"_key": 367, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92571": 15000}, "outputItems": {"93479": 1}, "internalName": "Anodized Freedom Metallic - Unlimited", "displayNameID": 1041235}
351	368	{"_key": 368, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92571": 3000}, "outputItems": {"92980": 1}, "internalName": "Intaki Evergreen Satin - Limited", "displayNameID": 1041236}
352	369	{"_key": 369, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92571": 15000}, "outputItems": {"93480": 1}, "internalName": "Intaki Evergreen Satin - Unlimited", "displayNameID": 1041237}
353	370	{"_key": 370, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92572": 6000}, "outputItems": {"93015": 1}, "internalName": "Republic Lineage - Limited", "displayNameID": 1041238}
354	371	{"_key": 371, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92572": 30000}, "outputItems": {"93481": 1}, "internalName": "Republic Lineage - Unlimited", "displayNameID": 1041239}
355	372	{"_key": 372, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92572": 6000}, "outputItems": {"93016": 1}, "internalName": "Republic Iconic - Limited", "displayNameID": 1041240}
356	373	{"_key": 373, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92572": 30000}, "outputItems": {"93482": 1}, "internalName": "Republic Iconic - Unlimited", "displayNameID": 1041241}
357	374	{"_key": 374, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92572": 3000}, "outputItems": {"92982": 1}, "internalName": "Starkman Ochre Satin - Limited", "displayNameID": 1041242}
358	375	{"_key": 375, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92572": 15000}, "outputItems": {"93483": 1}, "internalName": "Starkman Ochre Satin - Unlimited", "displayNameID": 1041243}
359	376	{"_key": 376, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92572": 3000}, "outputItems": {"92984": 1}, "internalName": "Darkest Clay Satin - Limited", "displayNameID": 1041244}
360	377	{"_key": 377, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92572": 15000}, "outputItems": {"93484": 1}, "internalName": "Darkest Clay Satin - Unlimited", "displayNameID": 1041245}
361	378	{"_key": 378, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92572": 3000}, "outputItems": {"92985": 1}, "internalName": "Matar Moss Matte - Limited", "displayNameID": 1041246}
362	379	{"_key": 379, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"92572": 15000}, "outputItems": {"93485": 1}, "internalName": "Matar Moss Matte - Unlimited", "displayNameID": 1041247}
363	380	{"_key": 380, "inputIsk": 0, "inputItems": {"93594": 1}, "outputItems": {"93592": 1}, "internalName": "Capital Logistic Site"}
364	381	{"_key": 381, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92569": 60000}, "outputItems": {"93840": 1}, "internalName": "Imperial Navy Large Remote Armor Repairer", "displayNameID": 1042568}
365	382	{"_key": 382, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92571": 60000}, "outputItems": {"93841": 1}, "internalName": "Federation Navy Large Remote Armor Repairer", "displayNameID": 1042571}
366	383	{"_key": 383, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92570": 60000}, "outputItems": {"93838": 1}, "internalName": "Caldari Navy Large Remote Shield Booster", "displayNameID": 1042570}
367	384	{"_key": 384, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92572": 60000}, "outputItems": {"93839": 1}, "internalName": "Republic Fleet Large Remote Shield Booster", "displayNameID": 1042569}
368	386	{"_key": 386, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93120": 1}, "internalName": "Imperial Electronics Booster IV"}
369	387	{"_key": 387, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93124": 1}, "internalName": "Imperial Damage Booster IV"}
370	388	{"_key": 388, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93128": 1}, "internalName": "Imperial Projection Booster IV"}
371	389	{"_key": 389, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93132": 1}, "internalName": "Imperial Application Booster IV"}
372	390	{"_key": 390, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93136": 1}, "internalName": "Imperial Defense Booster IV"}
373	391	{"_key": 391, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 50}, "outputItems": {"93831": 1}, "internalName": "Amarr Booster Crate"}
374	392	{"_key": 392, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 200}, "outputItems": {"93776": 1}, "internalName": "Extended Cerebral Accelerator"}
375	393	{"_key": 393, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93783": 1}, "internalName": "Cerebral Accelerator Crate"}
376	394	{"_key": 394, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 200}, "outputItems": {"93779": 1}, "internalName": "Extended Glamourex Booster"}
377	395	{"_key": 395, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93781": 1}, "internalName": "Glamourex Booster Crate"}
378	396	{"_key": 396, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 300}, "outputItems": {"93344": 1}, "internalName": "Imperial Supremacy - Unlimited"}
379	397	{"_key": 397, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93343": 1}, "internalName": "Imperial Supremacy - Limited"}
380	398	{"_key": 398, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 200}, "outputItems": {"93356": 1}, "internalName": "Chaotic Skies - Unlimited"}
381	399	{"_key": 399, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 200}, "outputItems": {"93358": 1}, "internalName": "Echoes of Action - Unlimited"}
382	400	{"_key": 400, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 200}, "outputItems": {"93360": 1}, "internalName": "Advancing Lines - Unlimited"}
383	401	{"_key": 401, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 200}, "outputItems": {"93362": 1}, "internalName": "War Fatigue - Unlimited"}
384	402	{"_key": 402, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 200}, "outputItems": {"93364": 1}, "internalName": "Combined Forces - Unlimited"}
385	403	{"_key": 403, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 75}, "outputItems": {"93236": 1}, "internalName": "Amarr SKINR Crate"}
386	404	{"_key": 404, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"93592": 350}, "outputItems": {"93726": 1}, "internalName": "Apocalypse Navy Issue Capsuleer Day XXIII SKIN"}
387	405	{"_key": 405, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"93592": 250}, "outputItems": {"93729": 1}, "internalName": "Augoror Navy Issue Capsuleer Day XXIII SKIN"}
388	406	{"_key": 406, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"93592": 5000}, "outputItems": {"93992": 1}, "internalName": "Officer Expanded Cargohold BPC"}
389	407	{"_key": 407, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93085": 1}, "internalName": "State Damage Booster IV"}
390	408	{"_key": 408, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93095": 1}, "internalName": "State Application Booster IV"}
391	409	{"_key": 409, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93102": 1}, "internalName": "State Mobility Booster IV"}
392	410	{"_key": 410, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93108": 1}, "internalName": "State Defense Booster IV"}
393	411	{"_key": 411, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93112": 1}, "internalName": "State Electronics Booster IV"}
394	412	{"_key": 412, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93115": 1}, "internalName": "State Projection Booster IV"}
395	413	{"_key": 413, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 50}, "outputItems": {"93833": 1}, "internalName": "Caldari Booster Crate"}
396	414	{"_key": 414, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 300}, "outputItems": {"93348": 1}, "internalName": "Fortified State - Unlimited"}
397	415	{"_key": 415, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93347": 1}, "internalName": "Fortified State - Limited"}
398	416	{"_key": 416, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 75}, "outputItems": {"93237": 1}, "internalName": "Caldari SKINR Crate"}
399	417	{"_key": 417, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"93592": 350}, "outputItems": {"93736": 1}, "internalName": "Raven Navy Issue Capsuleer Day XXIII SKIN"}
400	418	{"_key": 418, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"93592": 250}, "outputItems": {"93733": 1}, "internalName": "Caldari Navy Hookbill Capsuleer Day XXIII SKIN"}
401	419	{"_key": 419, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"93592": 5000}, "outputItems": {"93997": 1}, "internalName": "Officer Capacitor Flux Coil BPC"}
402	420	{"_key": 420, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"92948": 1}, "internalName": "Federation Defense Booster IV"}
403	421	{"_key": 421, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"92953": 1}, "internalName": "Federation Electronics Booster IV"}
404	422	{"_key": 422, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"92973": 1}, "internalName": "Federation Mobility Booster IV"}
405	423	{"_key": 423, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"92987": 1}, "internalName": "Federation Damage Booster IV"}
406	424	{"_key": 424, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"92994": 1}, "internalName": "Federation Projection Booster IV"}
407	425	{"_key": 425, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"92999": 1}, "internalName": "Federation Application Booster IV"}
408	426	{"_key": 426, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 50}, "outputItems": {"93834": 1}, "internalName": "Gallente Booster Crate"}
409	427	{"_key": 427, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 300}, "outputItems": {"93346": 1}, "internalName": "Federation Charge - Unlimited"}
410	428	{"_key": 428, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93345": 1}, "internalName": "Federation Charge - Limited"}
411	429	{"_key": 429, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 75}, "outputItems": {"93238": 1}, "internalName": "Gallente SKINR Crate"}
412	430	{"_key": 430, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"93592": 350}, "outputItems": {"93741": 1}, "internalName": "Megathron Navy Issue Capsuleer Day XXIII SKIN"}
413	431	{"_key": 431, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"93592": 250}, "outputItems": {"93738": 1}, "internalName": "Federation Navy Comet Capsuleer Day XXIII SKIN"}
414	432	{"_key": 432, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"93592": 5000}, "outputItems": {"93991": 1}, "internalName": "Officer Integrated Analyzer BPC"}
415	433	{"_key": 433, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93021": 1}, "internalName": "Republic Mobility Booster IV"}
416	434	{"_key": 434, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93025": 1}, "internalName": "Republic Damage Booster IV"}
417	435	{"_key": 435, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93029": 1}, "internalName": "Republic Projection Booster IV"}
418	436	{"_key": 436, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93053": 1}, "internalName": "Republic Application Booster IV"}
419	437	{"_key": 437, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93059": 1}, "internalName": "Republic Defense Booster IV"}
420	438	{"_key": 438, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93063": 1}, "internalName": "Republic Electronics Booster IV"}
421	439	{"_key": 439, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 50}, "outputItems": {"93835": 1}, "internalName": "Minmatar Booster Crate"}
422	440	{"_key": 440, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 300}, "outputItems": {"93350": 1}, "internalName": "Guerilla Republic - Unlimited"}
423	441	{"_key": 441, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93349": 1}, "internalName": "Guerilla Republic - Limited"}
424	442	{"_key": 442, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 75}, "outputItems": {"93241": 1}, "internalName": "Minmatar SKINR Crate"}
425	443	{"_key": 443, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"93592": 350}, "outputItems": {"93745": 1}, "internalName": "Tempest Fleet Issue Capsuleer Day XXIII SKIN"}
426	444	{"_key": 444, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"93592": 250}, "outputItems": {"93742": 1}, "internalName": "Republic Fleet Firetail Capsuleer Day XXIII SKIN"}
427	445	{"_key": 445, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"93592": 5000}, "outputItems": {"93993": 1}, "internalName": "Officer Mining Upgrade BPC"}
428	446	{"_key": 446, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"93592": 100}, "outputItems": {"93140": 1}, "internalName": "Imperial Mobility Booster IV"}
429	447	{"_key": 447, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"93592": 4000}, "outputItems": {"94011": 1}, "internalName": "Imperial Navy Bastion Module Blueprint Crate"}
430	448	{"_key": 448, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"93592": 4000}, "outputItems": {"94012": 1}, "internalName": "Caldari Navy Bastion Module Blueprint Crate"}
431	449	{"_key": 449, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"93592": 4000}, "outputItems": {"94013": 1}, "internalName": "Federation Navy Bastion Module Blueprint Crate"}
432	450	{"_key": 450, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"93592": 4000}, "outputItems": {"94014": 1}, "internalName": "Republic Fleet Bastion Module Blueprint Crate"}
433	451	{"_key": 451, "groupID": "DRONES", "inputIsk": 0, "inputItems": {"92571": 4000}, "outputItems": {"93963": 1}, "internalName": "'Aergia' Hobgoblin SW-300", "displayNameID": 1043504}
434	452	{"_key": 452, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92570": 40000}, "outputItems": {"93908": 1}, "internalName": "Caldari Navy Missile Guidance Enhancer", "displayNameID": 1043507}
435	453	{"_key": 453, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92572": 40000}, "outputItems": {"93909": 1}, "internalName": "Republic Fleet Missile Guidance Enhancer", "displayNameID": 1043508}
436	454	{"_key": 454, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92569": 40000}, "outputItems": {"93913": 1}, "internalName": "Imperial Navy 'Atonement' Tracking Enhancer", "displayNameID": 1043506}
437	455	{"_key": 455, "groupID": "DRONES", "inputIsk": 0, "inputItems": {"92571": 140000}, "outputItems": {"94026": 1}, "internalName": "Prototype 'Pluto' Mining Drone Blueprint Crate", "displayNameID": 1043521}
438	456	{"_key": 456, "groupID": "DRONES", "inputIsk": 0, "inputItems": {"92571": 140000}, "outputItems": {"94027": 1}, "internalName": "Prototype 'Pluto' Ice Harvesting Drone Blueprint Crate", "displayNameID": 1043522}
439	457	{"_key": 457, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92571": 20000}, "outputItems": {"93998": 1}, "internalName": "Federation Navy 'Argyreos' Magnetic Field Stabilizer", "displayNameID": 1043727}
440	458	{"_key": 458, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92571": 200000}, "outputItems": {"94020": 1}, "internalName": "Federation Navy 'Khryseos' Magnetic Field Stabilizer", "displayNameID": 1043728}
441	459	{"_key": 459, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92569": 20000}, "outputItems": {"94058": 1}, "internalName": "Imperial Navy 'Neophyte' Heat Sink", "displayNameID": 1043729}
442	460	{"_key": 460, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92569": 200000}, "outputItems": {"94060": 1}, "internalName": "Imperial Navy 'Disciple' Heat Sink", "displayNameID": 1043730}
443	461	{"_key": 461, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92570": 140000}, "outputItems": {"94063": 1}, "internalName": "Caldari Navy Missile Guidance Computer", "displayNameID": 1043739}
444	462	{"_key": 462, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92572": 140000}, "outputItems": {"94064": 1}, "internalName": "Republic Fleet Missile Guidance Computer", "displayNameID": 1043740}
445	463	{"_key": 463, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92570": 50000}, "outputItems": {"94067": 1}, "internalName": "Caldari Navy Signal Distortion Amplifier", "displayNameID": 1043747}
446	464	{"_key": 464, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"92572": 50000}, "outputItems": {"94065": 1}, "internalName": "Republic Fleet Mining Survey Chipset", "displayNameID": 1043748}
447	465	{"_key": 465, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 500}, "outputItems": {"93352": 1}, "internalName": "Jita Ascendent - Unlimited"}
448	466	{"_key": 466, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 500}, "outputItems": {"93354": 1}, "internalName": "Mark of the 4-4 - Unlimited"}
449	467	{"_key": 467, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"93592": 150}, "outputItems": {"93353": 1}, "internalName": "Mark of the 4-4 - Limited"}
450	468	{"_key": 468, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"93593": 1}, "outputItems": {"94312": 1}, "internalName": "Amarr Navy Destroyer Blueprint Crate"}
451	470	{"_key": 470, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"93593": 1}, "outputItems": {"94314": 1}, "internalName": "Caldari Navy Destroyer Blueprint Crate"}
452	471	{"_key": 471, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"93593": 1}, "outputItems": {"94315": 1}, "internalName": "Gallente Navy Destroyer Blueprint Crate"}
453	472	{"_key": 472, "groupID": "SHIP_BLUEPRINTS", "inputIsk": 0, "inputItems": {"93593": 1}, "outputItems": {"94316": 1}, "internalName": "Minmatar Navy Destroyer Blueprint Crate"}
454	473	{"_key": 473, "inputIsk": 0, "inputItems": {"95640": 430}, "outputItems": {"83467": 1}, "internalName": "Avalon Angel NET Resonator"}
455	474	{"_key": 474, "inputIsk": 0, "inputItems": {"95640": 430}, "outputItems": {"83468": 1}, "internalName": "Avalon Blood Raider NET Resonator"}
456	475	{"_key": 475, "inputIsk": 0, "inputItems": {"95640": 430}, "outputItems": {"83469": 1}, "internalName": "Avalon Guristas NET Resonator"}
457	476	{"_key": 476, "inputIsk": 0, "inputItems": {"95640": 430}, "outputItems": {"83471": 1}, "internalName": "Avalon Sansha NET Resonator"}
458	477	{"_key": 477, "inputIsk": 0, "inputItems": {"95640": 430}, "outputItems": {"83472": 1}, "internalName": "Avalon Serpentis NET Resonator"}
459	478	{"_key": 478, "inputIsk": 0, "inputItems": {"95640": 430}, "outputItems": {"83473": 1}, "internalName": "Avalon SoE NET Resonator"}
460	479	{"_key": 479, "inputIsk": 0, "inputItems": {"95640": 260}, "outputItems": {"52312": 1}, "internalName": "Avalon Zero-Point Field Manipulator"}
461	480	{"_key": 480, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"95640": 9240}, "outputItems": {"95414": 1}, "internalName": "Avalon Breach Control"}
462	481	{"_key": 481, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"95640": 4620}, "outputItems": {"95529": 1}, "internalName": "Avalon Poteque 'Prospector' Salvaging SV-906"}
463	482	{"_key": 482, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"95640": 260}, "outputItems": {"95532": 1}, "internalName": "Avalon Cavalry Clash Booster"}
464	483	{"_key": 483, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"95640": 260}, "outputItems": {"95533": 1}, "internalName": "Avalon Astrograph Clash Booster"}
465	484	{"_key": 484, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"95640": 260}, "outputItems": {"95534": 1}, "internalName": "Avalon SITREP Clash Booster"}
466	485	{"_key": 485, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"95640": 260}, "outputItems": {"95537": 1}, "internalName": "Avalon Coherence Volatile Booster"}
467	486	{"_key": 486, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"95640": 260}, "outputItems": {"95538": 1}, "internalName": "Avalon Upcycle Volatile Booster"}
468	487	{"_key": 487, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"95640": 260}, "outputItems": {"95539": 1}, "internalName": "Avalon Requisition Volatile Booster"}
469	488	{"_key": 488, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"95640": 260}, "outputItems": {"95540": 1}, "internalName": "Avalon Zero-In Volatile Booster"}
470	489	{"_key": 489, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"95640": 260}, "outputItems": {"95541": 1}, "internalName": "Avalon Soaring Volatile Booster"}
471	490	{"_key": 490, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"95640": 260}, "outputItems": {"95542": 1}, "internalName": "Avalon Hallowed Volatile Booster "}
472	491	{"_key": 491, "groupID": "BOOSTERS", "inputIsk": 0, "inputItems": {"95640": 260}, "outputItems": {"95543": 1}, "internalName": "Avalon Tenacious Volatile Booster"}
473	492	{"_key": 492, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"95640": 350}, "outputItems": {"95404": 1}, "internalName": "Avalon Harmonic Alloy Metallic - Limited"}
474	493	{"_key": 493, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"95640": 1040}, "outputItems": {"95405": 1}, "internalName": "Avalon Harmonic Alloy Metallic - Unlimited"}
475	494	{"_key": 494, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"95640": 610}, "outputItems": {"95417": 1}, "internalName": "Avalon Remnant Honor - Limited"}
476	495	{"_key": 495, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"95640": 1520}, "outputItems": {"95418": 1}, "internalName": "Avalon Remnant Honor - Unlimited"}
477	496	{"_key": 496, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"95640": 1040}, "outputItems": {"95399": 1}, "internalName": "Avalon Radiant Aureate Metallic - Unlimited"}
478	497	{"_key": 497, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"95640": 1040}, "outputItems": {"95401": 1}, "internalName": "Avalon Defiant Latten Matte - Unlimited"}
479	498	{"_key": 498, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"95640": 1040}, "outputItems": {"95403": 1}, "internalName": "Avalon Avalon Aqua Gloss - Unlimited"}
480	499	{"_key": 499, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"95640": 1040}, "outputItems": {"95407": 1}, "internalName": "Avalon Avalon Aqua Matte - Unlimited"}
481	500	{"_key": 500, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"95640": 1300}, "outputItems": {"95409": 1}, "internalName": "Avalon Arkombine Dawn Satin - Unlimited"}
482	501	{"_key": 501, "groupID": "SKINR", "inputIsk": 0, "inputItems": {"95640": 1300}, "outputItems": {"95413": 1}, "internalName": "Avalon Harmonius Bridge - Unlimited"}
483	504	{"_key": 504, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"95716": 1}, "outputItems": {"95654": 1}, "internalName": "Avalon Aeon Arkombine Arisen SKIN"}
484	505	{"_key": 505, "groupID": "SKINS", "inputIsk": 0, "inputItems": {"95716": 1}, "outputItems": {"95655": 1}, "internalName": "Avalon Salvation Arkombine Arisen SKIN"}
485	506	{"_key": 506, "groupID": "BACKGROUNDS", "inputIsk": 0, "inputItems": {"95640": 370}, "outputItems": {"95458": 1}, "internalName": "Operation Avalon Background"}
486	507	{"_key": 507, "groupID": "MODULES_AMMO", "inputIsk": 0, "inputItems": {"95716": 1}, "outputItems": {"95556": 1}, "internalName": "Avalon Modified Inertial Stabilizer"}
\.


--
-- Name: itemtraderrecipes itemtraderrecipes_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.itemtraderrecipes
    ADD CONSTRAINT itemtraderrecipes_pkey PRIMARY KEY (row_no);


--
-- Name: itemtraderrecipes_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX itemtraderrecipes_key_idx ON sde_native.itemtraderrecipes USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict xy4Z9bg6vzTyWnikDEBg1KPkHjfaNX2P5ShcAQj1Bi0WY1QYxJwfyXg3GSE5367

