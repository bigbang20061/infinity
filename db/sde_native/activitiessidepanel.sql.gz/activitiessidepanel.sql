--
-- PostgreSQL database dump
--

\restrict OxWMN3m2zviLm5IJzN2IEVbGQo5Fr4gROFXVsGVDPykJz1tNeHuakKBK4Q7K8cj

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activitiessidepanel; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.activitiessidepanel (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: activitiessidepanel; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.activitiessidepanel (row_no, key, data) FROM stdin;
0	\N	{"activities": [{"icon": "res:/UI/Texture/BattlePass/Season_Icon.png", "params": "{}", "function": "BattlePass", "orderIndex": 0, "activityName": 710935}, {"icon": "res:/UI/Texture/WindowIcons/exchangeShop.png", "params": "{}", "function": "ExchangeShop", "orderIndex": 1, "activityName": 710595}, {"icon": "res:/UI/Texture/bluebird/wndicon.png", "params": "{\\"refit_plan_id\\": 1}", "function": "BlueBird", "orderIndex": 2, "endDateTime": "2024-05-27 03:00", "activityName": 710594}, {"icon": "res:/UI/Texture/ActivitiesSidePanel/recruitIcon2.png", "params": "{}", "function": "Recruit", "orderIndex": 3, "activityName": 710936}, {"icon": "res:/UI/Texture/WindowIcons/shipKillBenefitShop.png", "params": "{}", "function": "ShipKillBenefit", "orderIndex": 4, "activityName": 711426}, {"icon": "res:/UI/Texture/Monetization/Monetization.png", "params": "{}", "function": "MonetizationAccu", "orderIndex": 5, "activityName": 711427}, {"icon": "res:/UI/Texture/recruitment/recruitlogo.png", "params": "{}", "function": "MobileCollect", "orderIndex": 6, "activityName": 720930}]}
\.


--
-- Name: activitiessidepanel activitiessidepanel_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.activitiessidepanel
    ADD CONSTRAINT activitiessidepanel_pkey PRIMARY KEY (row_no);


--
-- Name: activitiessidepanel_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX activitiessidepanel_key_idx ON sde_native.activitiessidepanel USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict OxWMN3m2zviLm5IJzN2IEVbGQo5Fr4gROFXVsGVDPykJz1tNeHuakKBK4Q7K8cj

