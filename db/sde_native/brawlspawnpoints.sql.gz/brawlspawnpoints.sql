--
-- PostgreSQL database dump
--

\restrict hN6JzvVNDBVdqxDUQvnfayoCDQwETepgKRxb7vSD73xMU93ELuh7sIjrOR9R6qq

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: brawlspawnpoints; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.brawlspawnpoints (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: brawlspawnpoints; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.brawlspawnpoints (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "room_object_id": 1152201, "spawn_list_table": [1], "round_spawn_limit": 2, "distance_from_center": 25000.0, "spawn_time_scheduled": [0]}
1	2	{"_key": 2, "room_object_id": 1157993, "spawn_list_table": [7, 8], "round_spawn_limit": 4, "distance_from_center": 35000.0, "spawn_time_scheduled": [120, 240, 420]}
2	3	{"_key": 3, "room_object_id": 1157994, "spawn_list_table": [21], "round_spawn_limit": 3, "distance_from_center": 10000.0, "spawn_time_scheduled": [420, 600, 780]}
3	4	{"_key": 4, "room_object_id": 1160517, "spawn_list_table": [2], "round_spawn_limit": 3, "distance_from_center": 15000.0, "spawn_time_scheduled": [0]}
4	5	{"_key": 5, "room_object_id": 1160519, "spawn_list_table": [11], "round_spawn_limit": 2, "distance_from_center": 15000.0, "spawn_time_scheduled": [420]}
5	6	{"_key": 6, "room_object_id": 1152205, "spawn_list_table": [7, 8], "round_spawn_limit": 5, "distance_from_center": 25000.0, "spawn_time_scheduled": [0, 120, 240, 420, 600, 780]}
6	7	{"_key": 7, "room_object_id": 1157990, "spawn_list_table": [19], "round_spawn_limit": 2, "distance_from_center": 7500.0, "spawn_time_scheduled": [600, 780]}
7	8	{"_key": 8, "room_object_id": 1157992, "spawn_list_table": [18], "round_spawn_limit": 2, "distance_from_center": 15000.0, "spawn_time_scheduled": [0, 45, 90, 135, 180, 225, 270, 315, 360, 405, 450, 495, 540, 585, 630, 675, 720, 765, 810, 855, 900, 945]}
8	9	{"_key": 9, "room_object_id": 1160526, "spawn_list_table": [3], "round_spawn_limit": 3, "distance_from_center": 15000.0, "spawn_time_scheduled": [0]}
9	10	{"_key": 10, "room_object_id": 1160528, "spawn_list_table": [12], "round_spawn_limit": 2, "distance_from_center": 15000.0, "spawn_time_scheduled": [420]}
10	11	{"_key": 11, "room_object_id": 1152922, "spawn_list_table": [7, 8], "round_spawn_limit": 5, "distance_from_center": 25000.0, "spawn_time_scheduled": [0, 120, 240, 420, 600, 780]}
11	12	{"_key": 12, "room_object_id": 1157996, "spawn_list_table": [19], "round_spawn_limit": 2, "distance_from_center": 7500.0, "spawn_time_scheduled": [600, 780]}
12	13	{"_key": 13, "room_object_id": 1157997, "spawn_list_table": [22], "round_spawn_limit": 2, "distance_from_center": 15000.0, "spawn_time_scheduled": [0, 45, 90, 135, 180, 225, 270, 315, 360, 405, 450, 495, 540, 585, 630, 675, 720, 765, 810, 855, 900, 945]}
13	14	{"_key": 14, "room_object_id": 1160584, "spawn_list_table": [4], "round_spawn_limit": 1, "distance_from_center": 15000.0, "spawn_time_scheduled": [0]}
14	15	{"_key": 15, "room_object_id": 1160586, "spawn_list_table": [13], "round_spawn_limit": 2, "distance_from_center": 15000.0, "spawn_time_scheduled": [420]}
15	16	{"_key": 16, "room_object_id": 1152937, "spawn_list_table": [7, 8], "round_spawn_limit": 5, "distance_from_center": 25000.0, "spawn_time_scheduled": [0, 120, 240, 420, 600, 780]}
16	17	{"_key": 17, "room_object_id": 1158011, "spawn_list_table": [19], "round_spawn_limit": 2, "distance_from_center": 7500.0, "spawn_time_scheduled": [600, 780]}
17	18	{"_key": 18, "room_object_id": 1158012, "spawn_list_table": [22], "round_spawn_limit": 2, "distance_from_center": 15000.0, "spawn_time_scheduled": [0, 45, 90, 135, 180, 225, 270, 315, 360, 405, 450, 495, 540, 585, 630, 675, 720, 765, 810, 855, 900, 945]}
18	19	{"_key": 19, "room_object_id": 1160568, "spawn_list_table": [5], "round_spawn_limit": 1, "distance_from_center": 15000.0, "spawn_time_scheduled": [0]}
19	20	{"_key": 20, "room_object_id": 1160570, "spawn_list_table": [14], "round_spawn_limit": 1, "distance_from_center": 15000.0, "spawn_time_scheduled": [420]}
20	21	{"_key": 21, "room_object_id": 1152931, "spawn_list_table": [7, 8], "round_spawn_limit": 5, "distance_from_center": 25000.0, "spawn_time_scheduled": [0, 120, 240, 420, 600, 780]}
21	22	{"_key": 22, "room_object_id": 1158006, "spawn_list_table": [19], "round_spawn_limit": 2, "distance_from_center": 7500.0, "spawn_time_scheduled": [600, 780]}
22	23	{"_key": 23, "room_object_id": 1158007, "spawn_list_table": [18], "round_spawn_limit": 2, "distance_from_center": 15000.0, "spawn_time_scheduled": [0, 45, 90, 135, 180, 225, 270, 315, 360, 405, 450, 495, 540, 585, 630, 675, 720, 765, 810, 855, 900, 945]}
23	24	{"_key": 24, "room_object_id": 1160608, "spawn_list_table": [6], "round_spawn_limit": 4, "distance_from_center": 15000.0, "spawn_time_scheduled": [0]}
24	25	{"_key": 25, "room_object_id": 1160609, "spawn_list_table": [15], "round_spawn_limit": 3, "distance_from_center": 15000.0, "spawn_time_scheduled": [420]}
25	26	{"_key": 26, "room_object_id": 1152925, "spawn_list_table": [20, 21], "round_spawn_limit": 3, "distance_from_center": 30000.0, "spawn_time_scheduled": [0, 120, 240, 360, 480, 600, 720, 840]}
26	27	{"_key": 27, "room_object_id": 1160606, "spawn_list_table": [17], "round_spawn_limit": 2, "distance_from_center": 15000.0, "spawn_time_scheduled": [0, 45, 90, 135, 180, 225, 270, 315, 360, 405, 450, 495, 540, 585, 630, 675, 720, 765, 810, 855, 900, 945]}
27	28	{"_key": 28, "room_object_id": 1160688, "spawn_list_table": [6], "round_spawn_limit": 4, "distance_from_center": 15000.0, "spawn_time_scheduled": [0]}
28	29	{"_key": 29, "room_object_id": 1160689, "spawn_list_table": [15], "round_spawn_limit": 3, "distance_from_center": 15000.0, "spawn_time_scheduled": [420]}
29	30	{"_key": 30, "room_object_id": 1152928, "spawn_list_table": [20, 21], "round_spawn_limit": 3, "distance_from_center": 30000.0, "spawn_time_scheduled": [0, 120, 240, 360, 480, 600, 720, 840]}
30	31	{"_key": 31, "room_object_id": 1160686, "spawn_list_table": [16], "round_spawn_limit": 2, "distance_from_center": 15000.0, "spawn_time_scheduled": [0, 45, 90, 135, 180, 225, 270, 315, 360, 405, 450, 495, 540, 585, 630, 675, 720, 765, 810, 855, 900, 945]}
31	32	{"_key": 32, "room_object_id": 1160719, "spawn_list_table": [6], "round_spawn_limit": 4, "distance_from_center": 15000.0, "spawn_time_scheduled": [0]}
32	33	{"_key": 33, "room_object_id": 1160720, "spawn_list_table": [15], "round_spawn_limit": 3, "distance_from_center": 15000.0, "spawn_time_scheduled": [420]}
33	34	{"_key": 34, "room_object_id": 1152934, "spawn_list_table": [20, 21], "round_spawn_limit": 3, "distance_from_center": 30000.0, "spawn_time_scheduled": [0, 120, 240, 360, 480, 600, 720, 840]}
34	35	{"_key": 35, "room_object_id": 1160717, "spawn_list_table": [17], "round_spawn_limit": 2, "distance_from_center": 15000.0, "spawn_time_scheduled": [0, 45, 90, 135, 180, 225, 270, 315, 360, 405, 450, 495, 540, 585, 630, 675, 720, 765, 810, 855, 900, 945]}
35	36	{"_key": 36, "room_object_id": 1160751, "spawn_list_table": [6], "round_spawn_limit": 4, "distance_from_center": 15000.0, "spawn_time_scheduled": [0]}
36	37	{"_key": 37, "room_object_id": 1160752, "spawn_list_table": [15], "round_spawn_limit": 2, "distance_from_center": 15000.0, "spawn_time_scheduled": [480]}
37	38	{"_key": 38, "room_object_id": 1152940, "spawn_list_table": [20, 21], "round_spawn_limit": 3, "distance_from_center": 30000.0, "spawn_time_scheduled": [0, 120, 240, 360, 480, 600, 720, 840]}
38	39	{"_key": 39, "room_object_id": 1160749, "spawn_list_table": [16], "round_spawn_limit": 2, "distance_from_center": 15000.0, "spawn_time_scheduled": [45, 90, 135, 180, 225, 270, 315, 360, 405, 450, 495, 540, 585, 630, 675, 720, 765, 810, 855, 900, 945]}
39	40	{"_key": 40, "room_object_id": 1160516, "spawn_list_table": [10], "round_spawn_limit": 4, "distance_from_center": 12500.0, "spawn_time_scheduled": [0, 60, 120, 180, 240, 300, 360, 420, 480, 540, 600, 660, 720, 780, 840, 900, 960]}
40	41	{"_key": 41, "room_object_id": 1160525, "spawn_list_table": [10], "round_spawn_limit": 4, "distance_from_center": 12500.0, "spawn_time_scheduled": [0, 60, 120, 180, 240, 300, 360, 420, 480, 540, 600, 660, 720, 780, 840, 900, 960]}
41	42	{"_key": 42, "room_object_id": 1160566, "spawn_list_table": [10], "round_spawn_limit": 4, "distance_from_center": 12500.0, "spawn_time_scheduled": [0, 60, 120, 180, 240, 300, 360, 420, 480, 540, 600, 660, 720, 780, 840, 900, 960]}
42	43	{"_key": 43, "room_object_id": 1160583, "spawn_list_table": [10], "round_spawn_limit": 4, "distance_from_center": 12500.0, "spawn_time_scheduled": [0, 60, 120, 180, 240, 300, 360, 420, 480, 540, 600, 660, 720, 780, 840, 900, 960]}
43	44	{"_key": 44, "room_object_id": 1160605, "spawn_list_table": [9], "round_spawn_limit": 6, "distance_from_center": 7500.0, "spawn_time_scheduled": [0, 60, 120, 180, 240, 300, 360, 420, 480, 540, 600, 660, 720, 780, 840, 900, 960]}
44	45	{"_key": 45, "room_object_id": 1160685, "spawn_list_table": [9], "round_spawn_limit": 6, "distance_from_center": 7500.0, "spawn_time_scheduled": [0, 60, 120, 180, 240, 300, 360, 420, 480, 540, 600, 660, 720, 780, 840, 900, 960]}
45	46	{"_key": 46, "room_object_id": 1160716, "spawn_list_table": [9], "round_spawn_limit": 6, "distance_from_center": 7500.0, "spawn_time_scheduled": [0, 60, 120, 180, 240, 300, 360, 420, 480, 540, 600, 660, 720, 780, 840, 900, 960]}
46	47	{"_key": 47, "room_object_id": 1160748, "spawn_list_table": [9], "round_spawn_limit": 6, "distance_from_center": 7500.0, "spawn_time_scheduled": [0, 60, 120, 180, 240, 300, 360, 420, 480, 540, 600, 660, 720, 780, 840, 900, 960]}
47	48	{"_key": 48, "room_object_id": 1157995, "spawn_list_table": [23], "round_spawn_limit": 2, "distance_from_center": 35000.0, "spawn_time_scheduled": [0]}
48	49	{"_key": 49, "room_object_id": 1160502, "spawn_list_table": [24], "round_spawn_limit": 3, "distance_from_center": 5000.0, "spawn_time_scheduled": [420, 600, 780]}
49	50	{"_key": 50, "room_object_id": 1157991, "spawn_list_table": [23], "round_spawn_limit": 1, "distance_from_center": 5000.0, "spawn_time_scheduled": [0]}
50	51	{"_key": 51, "room_object_id": 1157998, "spawn_list_table": [23], "round_spawn_limit": 1, "distance_from_center": 5000.0, "spawn_time_scheduled": [0]}
51	52	{"_key": 52, "room_object_id": 1158013, "spawn_list_table": [23], "round_spawn_limit": 3, "distance_from_center": 5000.0, "spawn_time_scheduled": [0]}
52	53	{"_key": 53, "room_object_id": 1158005, "spawn_list_table": [23], "round_spawn_limit": 3, "distance_from_center": 5000.0, "spawn_time_scheduled": [0]}
\.


--
-- Name: brawlspawnpoints brawlspawnpoints_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.brawlspawnpoints
    ADD CONSTRAINT brawlspawnpoints_pkey PRIMARY KEY (row_no);


--
-- Name: brawlspawnpoints_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX brawlspawnpoints_key_idx ON sde_native.brawlspawnpoints USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict hN6JzvVNDBVdqxDUQvnfayoCDQwETepgKRxb7vSD73xMU93ELuh7sIjrOR9R6qq

