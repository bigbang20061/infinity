--
-- PostgreSQL database dump
--

\restrict MVVqq3rX7IZebKCCXxpueNK22xXdj8cER9Ttwfix1WUUttkphlGdTVeCGRIMa9j

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ship_cosmetic_slot_categories; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.ship_cosmetic_slot_categories (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: ship_cosmetic_slot_categories; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.ship_cosmetic_slot_categories (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "name": "Material_slot"}
1	2	{"_key": 2, "name": "Pattern_slot"}
2	3	{"_key": 3, "name": "Pattern_material_slot"}
\.


--
-- Name: ship_cosmetic_slot_categories ship_cosmetic_slot_categories_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.ship_cosmetic_slot_categories
    ADD CONSTRAINT ship_cosmetic_slot_categories_pkey PRIMARY KEY (row_no);


--
-- Name: ship_cosmetic_slot_categories_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX ship_cosmetic_slot_categories_key_idx ON sde_native.ship_cosmetic_slot_categories USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict MVVqq3rX7IZebKCCXxpueNK22xXdj8cER9Ttwfix1WUUttkphlGdTVeCGRIMa9j

