--
-- PostgreSQL database dump
--

\restrict 0xeGjFkoO7eNbynkDbnJcTS8xdxbSXKJwc2HklErLImlgpqMqhJ08z6Kt8aUIbM

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: corporationroles; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.corporationroles (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: corporationroles; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.corporationroles (row_no, key, data) FROM stdin;
0	0	{"_key": 0, "nameID": 60174, "roleName": "roleDirector", "descriptionID": 60126}
1	1	{"_key": 1, "nameID": 698288, "roleName": "roleDeliveriesHangarCanTake0", "descriptionID": 698287}
2	2	{"_key": 2, "nameID": 698290, "roleName": "roleDeliveriesHangarCanQuery0", "descriptionID": 698289}
3	3	{"_key": 3, "nameID": 698292, "roleName": "roleDeliveriesHangarContainerCanTake0", "descriptionID": 698291}
4	7	{"_key": 7, "nameID": 60175, "roleName": "rolePersonnelManager", "descriptionID": 60127}
5	8	{"_key": 8, "nameID": 60176, "roleName": "roleAccountant", "descriptionID": 60128}
6	9	{"_key": 9, "nameID": 60177, "roleName": "roleSecurityOfficer", "descriptionID": 60129}
7	10	{"_key": 10, "nameID": 60178, "roleName": "roleFactoryManager", "descriptionID": 60130}
8	11	{"_key": 11, "nameID": 60179, "roleName": "roleStationManager", "descriptionID": 60131}
9	12	{"_key": 12, "nameID": 60180, "roleName": "roleAuditor", "descriptionID": 60132}
10	13	{"_key": 13, "nameID": 60181, "roleName": "roleHangarCanTake1", "descriptionID": 60133}
11	14	{"_key": 14, "nameID": 60182, "roleName": "roleHangarCanTake2", "descriptionID": 60134}
12	15	{"_key": 15, "nameID": 60183, "roleName": "roleHangarCanTake3", "descriptionID": 60135}
13	16	{"_key": 16, "nameID": 60184, "roleName": "roleHangarCanTake4", "descriptionID": 60136}
14	17	{"_key": 17, "nameID": 60185, "roleName": "roleHangarCanTake5", "descriptionID": 60137}
15	18	{"_key": 18, "nameID": 60186, "roleName": "roleHangarCanTake6", "descriptionID": 60138}
16	19	{"_key": 19, "nameID": 60187, "roleName": "roleHangarCanTake7", "descriptionID": 60139}
17	20	{"_key": 20, "nameID": 60188, "roleName": "roleHangarCanQuery1", "descriptionID": 60140}
18	21	{"_key": 21, "nameID": 60189, "roleName": "roleHangarCanQuery2", "descriptionID": 60141}
19	22	{"_key": 22, "nameID": 60190, "roleName": "roleHangarCanQuery3", "descriptionID": 60142}
20	23	{"_key": 23, "nameID": 60191, "roleName": "roleHangarCanQuery4", "descriptionID": 60143}
21	24	{"_key": 24, "nameID": 60192, "roleName": "roleHangarCanQuery5", "descriptionID": 60144}
22	25	{"_key": 25, "nameID": 60193, "roleName": "roleHangarCanQuery6", "descriptionID": 60145}
23	26	{"_key": 26, "nameID": 60194, "roleName": "roleHangarCanQuery7", "descriptionID": 60146}
24	27	{"_key": 27, "nameID": 60195, "roleName": "roleAccountCanTake1", "descriptionID": 60147}
25	28	{"_key": 28, "nameID": 60196, "roleName": "roleAccountCanTake2", "descriptionID": 60148}
26	29	{"_key": 29, "nameID": 60197, "roleName": "roleAccountCanTake3", "descriptionID": 60149}
27	30	{"_key": 30, "nameID": 60198, "roleName": "roleAccountCanTake4", "descriptionID": 60150}
28	31	{"_key": 31, "nameID": 60199, "roleName": "roleAccountCanTake5", "descriptionID": 60151}
29	32	{"_key": 32, "nameID": 60200, "roleName": "roleAccountCanTake6", "descriptionID": 60152}
30	33	{"_key": 33, "nameID": 60201, "roleName": "roleAccountCanTake7", "descriptionID": 60153}
31	34	{"_key": 34, "nameID": 60202, "roleName": "roleDiplomat", "descriptionID": 60154}
32	35	{"_key": 35, "nameID": 655293, "roleName": "roleBrandManager", "descriptionID": 655292}
33	41	{"_key": 41, "nameID": 60203, "roleName": "roleEquipmentConfig", "descriptionID": 60155}
34	42	{"_key": 42, "nameID": 60204, "roleName": "roleContainerCanTake1", "descriptionID": 60156}
35	43	{"_key": 43, "nameID": 60205, "roleName": "roleContainerCanTake2", "descriptionID": 60157}
36	44	{"_key": 44, "nameID": 60206, "roleName": "roleContainerCanTake3", "descriptionID": 60158}
37	45	{"_key": 45, "nameID": 60207, "roleName": "roleContainerCanTake4", "descriptionID": 60159}
38	46	{"_key": 46, "nameID": 60208, "roleName": "roleContainerCanTake5", "descriptionID": 60160}
39	47	{"_key": 47, "nameID": 60209, "roleName": "roleContainerCanTake6", "descriptionID": 60161}
40	48	{"_key": 48, "nameID": 60210, "roleName": "roleContainerCanTake7", "descriptionID": 60162}
41	49	{"_key": 49, "nameID": 60211, "roleName": "roleCanRentOffice", "descriptionID": 60163}
42	50	{"_key": 50, "nameID": 60212, "roleName": "roleCanRentFactorySlot", "descriptionID": 60164}
43	51	{"_key": 51, "nameID": 60213, "roleName": "roleCanRentResearchSlot", "descriptionID": 60165}
44	52	{"_key": 52, "nameID": 60214, "roleName": "roleJuniorAccountant", "descriptionID": 60166}
45	53	{"_key": 53, "nameID": 60215, "roleName": "roleStarbaseConfig", "descriptionID": 60167}
46	54	{"_key": 54, "nameID": 60216, "roleName": "roleTrader", "descriptionID": 60168}
47	55	{"_key": 55, "nameID": 60217, "roleName": "roleChatManager", "descriptionID": 60169}
48	56	{"_key": 56, "nameID": 60218, "roleName": "roleContractManager", "descriptionID": 60170}
49	57	{"_key": 57, "nameID": 60219, "roleName": "roleInfrastructureTacticalOfficer", "descriptionID": 60171}
50	58	{"_key": 58, "nameID": 60220, "roleName": "roleStarbaseCaretaker", "descriptionID": 60172}
51	59	{"_key": 59, "nameID": 60221, "roleName": "roleFittingManager", "descriptionID": 60173}
52	60	{"_key": 60, "nameID": 290368, "roleName": "roleProjectManager", "descriptionID": 290367}
53	61	{"_key": 61, "nameID": 290370, "roleName": "roleTerrestrialLogisticsOfficer", "descriptionID": 290369}
54	62	{"_key": 62, "nameID": 589065, "roleName": "roleSkillPlanManager", "descriptionID": 589064}
\.


--
-- Name: corporationroles corporationroles_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.corporationroles
    ADD CONSTRAINT corporationroles_pkey PRIMARY KEY (row_no);


--
-- Name: corporationroles_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX corporationroles_key_idx ON sde_native.corporationroles USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 0xeGjFkoO7eNbynkDbnJcTS8xdxbSXKJwc2HklErLImlgpqMqhJ08z6Kt8aUIbM

