--
-- PostgreSQL database dump
--

\restrict sZXE4D9CtQbw2IlA8HmJzSxok2p1bXoSDxSgmCxqI9Il1Accb9hfN8DTDU2Hcgx

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agencyhelpvideos; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.agencyhelpvideos (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: agencyhelpvideos; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.agencyhelpvideos (row_no, key, data) FROM stdin;
0	37	{"_key": 37, "path": "res:/video/agency/helpVideos/exploration/scanning/scanning_1_1.webm", "nameID": 573444, "descriptionID": 573445}
1	38	{"_key": 38, "path": "res:/video/agency/helpVideos/exploration/scanning/scanning_1_2.webm", "nameID": 573446, "descriptionID": 573447}
2	39	{"_key": 39, "path": "res:/video/agency/helpVideos/exploration/scanning/scanning_1_3.webm", "nameID": 573448, "descriptionID": 573449}
3	40	{"_key": 40, "path": "res:/video/agency/helpVideos/exploration/scanning/scanning_2_1.webm", "nameID": 573711, "descriptionID": 573712}
4	41	{"_key": 41, "path": "res:/video/agency/helpVideos/exploration/scanning/scanning_2_2.webm", "nameID": 573713, "descriptionID": 573714}
5	42	{"_key": 42, "path": "res:/video/agency/helpVideos/exploration/scanning/scanning_2_3.webm", "nameID": 573715, "descriptionID": 573716}
6	43	{"_key": 43, "path": "res:/video/agency/helpVideos/exploration/scanning/scanning_2_4.webm", "nameID": 573717, "descriptionID": 573718}
7	44	{"_key": 44, "path": "res:/video/agency/helpVideos/exploration/scanning/scanning_3_1.webm", "nameID": 573719, "descriptionID": 573720}
8	45	{"_key": 45, "path": "res:/video/agency/helpVideos/exploration/scanning/scanning_3_2.webm", "nameID": 573721, "descriptionID": 573722}
9	46	{"_key": 46, "path": "res:/video/agency/helpVideos/exploration/scanning/scanning_3_3.webm", "nameID": 573723, "descriptionID": 573724}
10	47	{"_key": 47, "path": "res:/video/agency/helpVideos/exploration/scanning/scanning_3_4.webm", "nameID": 573725, "descriptionID": 573726}
11	48	{"_key": 48, "path": "res:/video/agency/helpVideos/exploration/scanning/scanning_3_5.webm", "nameID": 573727, "descriptionID": 573728}
12	49	{"_key": 49, "path": "res:/video/agency/helpVideos/exploration/scanning/scanning_3_6.webm", "nameID": 573729, "descriptionID": 573730}
13	50	{"_key": 50, "path": "res:/video/agency/helpVideos/exploration/scanning/scanning_3_7.webm", "nameID": 573731, "descriptionID": 573732}
14	55	{"_key": 55, "path": "res:/video/agency/helpVideos/eveacademy/soldieroffortune/securitystatuses/UnderstandingSecurityStatus.webm", "nameID": 582629, "descriptionID": 582628}
15	56	{"_key": 56, "path": "res:/video/agency/helpVideos/eveacademy/industrialist/miningresourceacq/Mining-and-Resource-Acquisition.webm", "nameID": 582635, "descriptionID": 582634}
16	57	{"_key": 57, "path": "res:/video/agency/helpVideos/eveacademy/explorer/scanningbasics/Explorer-Scanning_Basics.webm", "nameID": 582641, "descriptionID": 582640}
17	58	{"_key": 58, "path": "res:/video/agency/helpVideos/eveacademy/enforcer/epicarcs/Enforcer-EpicArcs.webm", "nameID": 582647, "descriptionID": 582646}
18	59	{"_key": 59, "path": "res:/video/agency/helpVideos/eveacademy/enforcer/missionbasics/Enforcer-MissionBasics-4K.webm", "nameID": 582649, "descriptionID": 582648}
19	60	{"_key": 60, "path": "res:/video/agency/helpVideos/eveacademy/soldieroffortune/How2findCorp/Finding-a-Corp.webm", "nameID": 585457, "descriptionID": 585456}
20	62	{"_key": 62, "path": "res:/video/agency/helpVideos/eveacademy/explorer/Hacking4Profit/Explorer-HackingForProfit.webm", "nameID": 586223, "descriptionID": 586222}
21	63	{"_key": 63, "path": "res:/video/agency/helpVideos/eveacademy/explorer/WormholeBasics/WormholeBasics.webm", "nameID": 586242, "descriptionID": 586241}
22	64	{"_key": 64, "path": "res:/video/agency/helpVideos/eveacademy/industrialist/MarketTrading/MarketTrading.webm", "nameID": 588303, "descriptionID": 588302}
23	65	{"_key": 65, "path": "res:/video/agency/helpVideos/eveacademy/enforcer/Fitting4PvE/Fitting-your-ship.webm", "nameID": 588305, "descriptionID": 588304}
24	68	{"_key": 68, "path": "res:/video/agency/helpVideos/eveacademy/explorer/WormholeCombat/WormholeCombat.webm", "nameID": 590347, "descriptionID": 590346}
25	72	{"_key": 72, "path": "res:/video/agency/helpVideos/roguelike/SolarFlareIntro.webm", "nameID": 594335, "descriptionID": 594334}
26	73	{"_key": 73, "path": "res:/video/agency/helpVideos/roguelike/SolarFlareCombat.webm", "nameID": 594337, "descriptionID": 594336}
27	74	{"_key": 74, "path": "res:/video/agency/helpVideos/roguelike/SolarFlareUpgrade.webm", "nameID": 594341, "descriptionID": 594338}
28	75	{"_key": 75, "path": "res:/video/agency/helpVideos/roguelike/SolarFlareFusing.webm", "nameID": 594342, "descriptionID": 594339}
29	76	{"_key": 76, "path": "res:/video/agency/helpVideos/roguelike/SolarFlareEvo.webm", "nameID": 594343, "descriptionID": 594340}
30	85	{"_key": 85, "path": "res:/video/agency/helpVideos/combatmechanics/ECM.webm", "nameID": 602203, "descriptionID": 602202}
31	86	{"_key": 86, "path": "res:/video/agency/helpVideos/combatmechanics/Energy_Neutralisers.webm", "nameID": 602206, "descriptionID": 602205}
32	87	{"_key": 87, "path": "res:/video/agency/helpVideos/combatmechanics/Missile-Application.webm", "nameID": 602208, "descriptionID": 602207}
33	88	{"_key": 88, "path": "res:/video/agency/helpVideos/combatmechanics/Missile-Range.webm", "nameID": 602210, "descriptionID": 602209}
34	89	{"_key": 89, "path": "res:/video/agency/helpVideos/combatmechanics/Optimal-Range.webm", "nameID": 602212, "descriptionID": 602211}
35	90	{"_key": 90, "path": "res:/video/agency/helpVideos/combatmechanics/Sensor_Dampening.webm", "nameID": 602214, "descriptionID": 602213}
36	91	{"_key": 91, "path": "res:/video/agency/helpVideos/combatmechanics/Spiral-Tackle.webm", "nameID": 602216, "descriptionID": 602215}
37	92	{"_key": 92, "path": "res:/video/agency/helpVideos/combatmechanics/Target_Painting.webm", "nameID": 602218, "descriptionID": 602217}
38	93	{"_key": 93, "path": "res:/video/agency/helpVideos/combatmechanics/Tracking.webm", "nameID": 602220, "descriptionID": 602219}
39	94	{"_key": 94, "path": "res:/video/agency/helpVideos/combatmechanics/Warp-Disruption.webm", "nameID": 602222, "descriptionID": 602221}
40	95	{"_key": 95, "path": "res:/video/agency/helpVideos/combatmechanics/Weapon-Disruption.webm", "nameID": 602224, "descriptionID": 602223}
\.


--
-- Name: agencyhelpvideos agencyhelpvideos_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.agencyhelpvideos
    ADD CONSTRAINT agencyhelpvideos_pkey PRIMARY KEY (row_no);


--
-- Name: agencyhelpvideos_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX agencyhelpvideos_key_idx ON sde_native.agencyhelpvideos USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict sZXE4D9CtQbw2IlA8HmJzSxok2p1bXoSDxSgmCxqI9Il1Accb9hfN8DTDU2Hcgx

