--
-- PostgreSQL database dump
--

\restrict a1lVhNGxGKiHiC1ff513eGFtNgnQQaHUL54uAezmtgfFmkBQmb0JKSdo5LXTJgm

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: races; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.races (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: races; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.races (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "iconID": 1439, "nameID": 59592, "skills": {"3300": 4, "3301": 1, "3310": 2, "3311": 2, "3312": 2, "3315": 0, "3316": 2, "3317": 1, "3318": 2, "3319": 1, "3327": 3, "3330": 1, "3342": 1, "3380": 1, "3386": 3, "3392": 3, "3393": 0, "3394": 2, "3402": 4, "3411": 1, "3412": 3, "3413": 4, "3417": 3, "3418": 3, "3419": 2, "3420": 2, "3424": 1, "3425": 2, "3426": 4, "3427": 1, "3428": 2, "3429": 3, "3431": 2, "3432": 3, "3435": 1, "3436": 1, "3437": 1, "3443": 2, "3449": 3, "3450": 3, "3453": 1, "3454": 1, "3455": 2, "3551": 3, "13278": 1, "16598": 1, "21718": 1, "22578": 0, "25739": 1, "25811": 1, "25863": 3, "32918": 1}, "shipTypeID": 601, "descriptionID": 59586}
1	2	{"_key": 2, "iconID": 1440, "nameID": 59593, "skills": {"3300": 4, "3302": 1, "3310": 2, "3311": 2, "3312": 2, "3315": 0, "3316": 1, "3317": 1, "3318": 2, "3319": 1, "3327": 3, "3329": 1, "3341": 1, "3380": 1, "3386": 3, "3392": 3, "3393": 0, "3394": 3, "3402": 4, "3411": 1, "3412": 3, "3413": 4, "3417": 3, "3418": 3, "3419": 1, "3420": 1, "3424": 1, "3425": 1, "3426": 4, "3427": 1, "3428": 2, "3429": 3, "3431": 2, "3432": 3, "3435": 1, "3436": 1, "3437": 1, "3443": 2, "3449": 3, "3450": 3, "3453": 1, "3454": 1, "3455": 2, "3551": 3, "13278": 1, "16598": 1, "21718": 1, "22578": 0, "25739": 1, "25811": 1, "25863": 3, "32918": 1}, "shipTypeID": 588, "descriptionID": 59587}
2	4	{"_key": 4, "iconID": 1442, "nameID": 59594, "skills": {"3300": 4, "3303": 1, "3310": 2, "3311": 2, "3312": 2, "3315": 0, "3316": 2, "3317": 1, "3318": 2, "3319": 1, "3327": 3, "3331": 1, "3343": 1, "3380": 1, "3386": 3, "3392": 3, "3393": 0, "3394": 3, "3402": 4, "3411": 1, "3412": 3, "3413": 4, "3417": 3, "3418": 3, "3419": 1, "3420": 1, "3424": 1, "3425": 1, "3426": 4, "3427": 1, "3428": 2, "3429": 3, "3431": 2, "3432": 3, "3435": 1, "3436": 1, "3437": 1, "3443": 2, "3449": 3, "3450": 3, "3453": 1, "3454": 1, "3455": 2, "3551": 3, "13278": 1, "16598": 1, "21718": 1, "22578": 0, "25739": 1, "25811": 1, "25863": 3, "32918": 1}, "shipTypeID": 596, "descriptionID": 59588}
3	8	{"_key": 8, "iconID": 1441, "nameID": 59595, "skills": {"3300": 4, "3301": 1, "3310": 2, "3311": 2, "3312": 2, "3315": 0, "3316": 2, "3317": 1, "3318": 2, "3319": 1, "3327": 3, "3328": 1, "3340": 1, "3380": 1, "3386": 3, "3392": 3, "3393": 0, "3394": 3, "3402": 4, "3411": 1, "3412": 3, "3413": 4, "3417": 3, "3418": 3, "3419": 1, "3420": 1, "3424": 1, "3425": 1, "3426": 4, "3427": 1, "3428": 2, "3429": 3, "3431": 2, "3432": 3, "3435": 1, "3436": 1, "3437": 1, "3443": 2, "3449": 3, "3450": 3, "3453": 1, "3454": 1, "3455": 2, "3551": 3, "13278": 1, "16598": 1, "21718": 1, "22578": 0, "25739": 1, "25811": 1, "25863": 3, "32918": 1}, "shipTypeID": 606, "descriptionID": 59589}
4	16	{"_key": 16, "nameID": 59590, "descriptionID": 59585}
5	32	{"_key": 32, "nameID": 59591}
6	64	{"_key": 64, "nameID": 234419}
7	128	{"_key": 128, "iconID": 0, "nameID": 277200, "descriptionID": 277201}
8	134	{"_key": 134, "nameID": 317718, "descriptionID": 317720}
9	135	{"_key": 135, "nameID": 317719, "descriptionID": 317721}
10	161	{"_key": 161, "nameID": 599498, "skills": {}, "shipTypeID": 601}
11	168	{"_key": 168, "nameID": 722066, "descriptionID": 722065}
12	169	{"_key": 169, "nameID": 725163, "skills": {}, "shipTypeID": 601}
13	174	{"_key": 174, "nameID": 1030415}
\.


--
-- Name: races races_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.races
    ADD CONSTRAINT races_pkey PRIMARY KEY (row_no);


--
-- Name: races_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX races_key_idx ON sde_native.races USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict a1lVhNGxGKiHiC1ff513eGFtNgnQQaHUL54uAezmtgfFmkBQmb0JKSdo5LXTJgm

