--
-- PostgreSQL database dump
--

\restrict j6YsOGHZgDLoCEuNLgo2hf2PS4kIir9F0yS3ctPkqyMAZlscMf14AcKh3PbNiNC

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: metagroups; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.metagroups (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: metagroups; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.metagroups (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "color": [0.78039, 0.66667, 0.04314, 1.0], "nameID": 66672}
1	2	{"_key": 2, "color": [0.61961, 0.38039, 0.00392, 1.0], "iconID": 24150, "nameID": 66673, "iconSuffix": "t2"}
2	3	{"_key": 3, "color": [0.26667, 0.43137, 0.11765, 1.0], "iconID": 24147, "nameID": 66674, "iconSuffix": "storyline"}
3	4	{"_key": 4, "color": [0.06667, 0.27843, 0.05098, 1.0], "iconID": 24146, "nameID": 66675, "iconSuffix": "faction"}
4	5	{"_key": 5, "color": [0.20392, 0.0549, 0.45098, 1.0], "iconID": 24149, "nameID": 66676, "iconSuffix": "officer"}
5	6	{"_key": 6, "color": [0.16078, 0.27843, 0.5451, 1.0], "iconID": 24148, "nameID": 66677, "iconSuffix": "deadspace", "descriptionID": 66671}
6	14	{"_key": 14, "color": [0.62353, 0.22745, 0.01176, 1.0], "iconID": 24151, "nameID": 66685, "iconSuffix": "t3"}
7	15	{"_key": 15, "color": [0.52941, 0.12549, 0.12549, 1.0], "iconID": 24152, "nameID": 317771, "iconSuffix": "abyssal"}
8	17	{"_key": 17, "color": [0.61961, 0.34118, 0.8549, 1.0], "iconID": 24153, "nameID": 317893, "iconSuffix": "premium", "descriptionID": 317894}
9	19	{"_key": 19, "color": [0.18039, 0.70588, 0.87451, 1.0], "iconID": 24154, "nameID": 317895, "iconSuffix": "limited", "descriptionID": 317896}
10	52	{"_key": 52, "iconID": 24155, "nameID": 550638, "iconSuffix": "struct_faction"}
11	53	{"_key": 53, "iconID": 24156, "nameID": 550639, "iconSuffix": "struct_t2"}
12	54	{"_key": 54, "iconID": 24157, "nameID": 550644, "iconSuffix": "struct"}
13	55	{"_key": 55, "iconID": 25077, "nameID": 592665, "iconSuffix": "SFe"}
\.


--
-- Name: metagroups metagroups_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.metagroups
    ADD CONSTRAINT metagroups_pkey PRIMARY KEY (row_no);


--
-- Name: metagroups_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX metagroups_key_idx ON sde_native.metagroups USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict j6YsOGHZgDLoCEuNLgo2hf2PS4kIir9F0yS3ctPkqyMAZlscMf14AcKh3PbNiNC

