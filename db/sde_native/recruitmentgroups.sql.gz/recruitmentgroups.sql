--
-- PostgreSQL database dump
--

\restrict 4Abnj8oLGUPTn2LiZ5EH1sv03DF8RcfpBVk64KY1TkMWde20m9rjW6LOHTfgmSX

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: recruitmentgroups; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.recruitmentgroups (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: recruitmentgroups; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.recruitmentgroups (row_no, key, data) FROM stdin;
0	6	{"_key": 6, "nameID": 59662, "descriptionID": 59656}
1	8	{"_key": 8, "nameID": 59663, "descriptionID": 59657}
2	9	{"_key": 9, "nameID": 59661, "descriptionID": 59655}
3	10	{"_key": 10, "nameID": 59664, "descriptionID": 59658}
4	11	{"_key": 11, "nameID": 59665, "descriptionID": 59659}
5	12	{"_key": 12, "nameID": 59666, "descriptionID": 59660}
6	79	{"_key": 79, "nameID": 589049, "descriptionID": 589048}
7	80	{"_key": 80, "nameID": 589051, "descriptionID": 589050}
\.


--
-- Name: recruitmentgroups recruitmentgroups_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.recruitmentgroups
    ADD CONSTRAINT recruitmentgroups_pkey PRIMARY KEY (row_no);


--
-- Name: recruitmentgroups_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX recruitmentgroups_key_idx ON sde_native.recruitmentgroups USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 4Abnj8oLGUPTn2LiZ5EH1sv03DF8RcfpBVk64KY1TkMWde20m9rjW6LOHTfgmSX

