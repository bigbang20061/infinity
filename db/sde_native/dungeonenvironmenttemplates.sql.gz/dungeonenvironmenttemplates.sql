--
-- PostgreSQL database dump
--

\restrict UQQGSDzw44tNzohRAG50H3DpVilLUfyWxEiJR3TwQfz6OB9OGhDDVLWqWGRZKSk

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dungeonenvironmenttemplates; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.dungeonenvironmenttemplates (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: dungeonenvironmenttemplates; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.dungeonenvironmenttemplates (row_no, key, data) FROM stdin;
0	1215	{"_key": 1215, "roomTemplates": {"17492": [], "17493": [], "17494": []}, "systemWideTemplates": [], "dungeonWideTemplates": []}
1	2023	{"_key": 2023, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
2	2024	{"_key": 2024, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
3	2051	{"_key": 2051, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
4	2052	{"_key": 2052, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
5	2054	{"_key": 2054, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
6	2055	{"_key": 2055, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
7	2056	{"_key": 2056, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
8	2058	{"_key": 2058, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
9	2059	{"_key": 2059, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
10	2060	{"_key": 2060, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
11	2062	{"_key": 2062, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
12	2063	{"_key": 2063, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
13	2064	{"_key": 2064, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
14	2065	{"_key": 2065, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
15	2069	{"_key": 2069, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
16	2070	{"_key": 2070, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
17	2071	{"_key": 2071, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
18	2072	{"_key": 2072, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
19	2073	{"_key": 2073, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
20	2074	{"_key": 2074, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
21	2075	{"_key": 2075, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
22	2076	{"_key": 2076, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
23	2077	{"_key": 2077, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
24	2078	{"_key": 2078, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
25	2079	{"_key": 2079, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
26	2080	{"_key": 2080, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
27	2081	{"_key": 2081, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
28	2083	{"_key": 2083, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
29	2084	{"_key": 2084, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
30	2090	{"_key": 2090, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
31	2091	{"_key": 2091, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
32	2092	{"_key": 2092, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
33	2093	{"_key": 2093, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
34	2094	{"_key": 2094, "roomTemplates": {"19100": [], "19101": [], "19102": [], "19103": []}, "systemWideTemplates": [], "dungeonWideTemplates": []}
35	2096	{"_key": 2096, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
36	2097	{"_key": 2097, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
37	2098	{"_key": 2098, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
38	2102	{"_key": 2102, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
39	2103	{"_key": 2103, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
40	2104	{"_key": 2104, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
41	2108	{"_key": 2108, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
42	2110	{"_key": 2110, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
43	2111	{"_key": 2111, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
44	2678	{"_key": 2678, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": [1]}
45	2961	{"_key": 2961, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": [1]}
46	2966	{"_key": 2966, "roomTemplates": {}, "systemWideTemplates": [1], "dungeonWideTemplates": []}
47	2969	{"_key": 2969, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": [1]}
48	3510	{"_key": 3510, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
49	3516	{"_key": 3516, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
50	3517	{"_key": 3517, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
51	3518	{"_key": 3518, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
52	3520	{"_key": 3520, "roomTemplates": {"21275": [], "21276": []}, "systemWideTemplates": [], "dungeonWideTemplates": []}
53	3522	{"_key": 3522, "roomTemplates": {"21277": [], "21278": []}, "systemWideTemplates": [], "dungeonWideTemplates": []}
54	3523	{"_key": 3523, "roomTemplates": {"21279": [], "21280": []}, "systemWideTemplates": [], "dungeonWideTemplates": []}
55	3524	{"_key": 3524, "roomTemplates": {"21281": [], "21282": []}, "systemWideTemplates": [], "dungeonWideTemplates": []}
56	3525	{"_key": 3525, "roomTemplates": {"21283": [], "21284": [], "21285": [], "21286": []}, "systemWideTemplates": [], "dungeonWideTemplates": []}
57	3526	{"_key": 3526, "roomTemplates": {"21287": [], "21288": [], "21289": [], "21290": []}, "systemWideTemplates": [], "dungeonWideTemplates": []}
58	3527	{"_key": 3527, "roomTemplates": {"21291": [], "21292": [], "21293": [], "21294": []}, "systemWideTemplates": [], "dungeonWideTemplates": []}
59	3811	{"_key": 3811, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": [1]}
60	3813	{"_key": 3813, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": [1]}
61	3818	{"_key": 3818, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": [1]}
62	3820	{"_key": 3820, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": [1]}
63	3823	{"_key": 3823, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": [1]}
64	4082	{"_key": 4082, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
65	4087	{"_key": 4087, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
66	4091	{"_key": 4091, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
67	4092	{"_key": 4092, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
68	4093	{"_key": 4093, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
69	4178	{"_key": 4178, "roomTemplates": {"22209": [2720]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
70	4179	{"_key": 4179, "roomTemplates": {"22208": [2680]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
71	4182	{"_key": 4182, "roomTemplates": {"22214": [2678]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
72	4183	{"_key": 4183, "roomTemplates": {"22215": [2679]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
73	4184	{"_key": 4184, "roomTemplates": {"22216": [2681]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
74	4191	{"_key": 4191, "roomTemplates": {"22225": []}, "systemWideTemplates": [], "dungeonWideTemplates": []}
75	9412	{"_key": 9412, "roomTemplates": {"28185": [2718]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
76	9413	{"_key": 9413, "roomTemplates": {"28185": [2721]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
77	9414	{"_key": 9414, "roomTemplates": {"28187": [2721]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
78	9417	{"_key": 9417, "roomTemplates": {"28191": []}, "systemWideTemplates": [], "dungeonWideTemplates": []}
79	9418	{"_key": 9418, "roomTemplates": {"28192": []}, "systemWideTemplates": [], "dungeonWideTemplates": []}
80	9419	{"_key": 9419, "roomTemplates": {"28193": []}, "systemWideTemplates": [], "dungeonWideTemplates": []}
81	10422	{"_key": 10422, "roomTemplates": {"29420": [3087]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
82	12961	{"_key": 12961, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
83	13990	{"_key": 13990, "roomTemplates": {"33078": [1]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
84	13991	{"_key": 13991, "roomTemplates": {"33080": [1]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
85	13992	{"_key": 13992, "roomTemplates": {"33082": [1]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
86	13993	{"_key": 13993, "roomTemplates": {"33085": [1]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
87	13994	{"_key": 13994, "roomTemplates": {"33087": [1]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
88	14000	{"_key": 14000, "roomTemplates": {"33093": [1]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
89	14003	{"_key": 14003, "roomTemplates": {"33096": [1]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
90	14005	{"_key": 14005, "roomTemplates": {"33098": [1]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
91	14010	{"_key": 14010, "roomTemplates": {"33103": [1]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
92	14035	{"_key": 14035, "roomTemplates": {"33131": [1]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
93	14036	{"_key": 14036, "roomTemplates": {"33132": [1]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
94	14039	{"_key": 14039, "roomTemplates": {"33135": [1]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
95	14040	{"_key": 14040, "roomTemplates": {"33136": [1]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
96	14041	{"_key": 14041, "roomTemplates": {"33137": [1]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
97	14050	{"_key": 14050, "roomTemplates": {"33150": [1]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
98	14051	{"_key": 14051, "roomTemplates": {"33151": [1]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
99	14076	{"_key": 14076, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": [1]}
100	14078	{"_key": 14078, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": [1]}
101	14079	{"_key": 14079, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": [1]}
102	14080	{"_key": 14080, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": [1]}
103	14134	{"_key": 14134, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
104	14139	{"_key": 14139, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
105	14141	{"_key": 14141, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
106	14143	{"_key": 14143, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
107	14151	{"_key": 14151, "roomTemplates": {"33288": [1]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
108	14160	{"_key": 14160, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
109	14236	{"_key": 14236, "roomTemplates": {"33378": [3488]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
110	14239	{"_key": 14239, "roomTemplates": {"33381": [3489]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
111	14241	{"_key": 14241, "roomTemplates": {"33383": [3480]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
112	14243	{"_key": 14243, "roomTemplates": {"33385": [3491]}, "systemWideTemplates": [], "dungeonWideTemplates": []}
113	14258	{"_key": 14258, "roomTemplates": {}, "systemWideTemplates": [], "dungeonWideTemplates": []}
\.


--
-- Name: dungeonenvironmenttemplates dungeonenvironmenttemplates_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.dungeonenvironmenttemplates
    ADD CONSTRAINT dungeonenvironmenttemplates_pkey PRIMARY KEY (row_no);


--
-- Name: dungeonenvironmenttemplates_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX dungeonenvironmenttemplates_key_idx ON sde_native.dungeonenvironmenttemplates USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict UQQGSDzw44tNzohRAG50H3DpVilLUfyWxEiJR3TwQfz6OB9OGhDDVLWqWGRZKSk

