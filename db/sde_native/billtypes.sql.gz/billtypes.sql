--
-- PostgreSQL database dump
--

\restrict BUzV3pjbIhOE2Ue339uL6SvG7hFckrFfbqQOod55kpNFvMdysCLZ74kLNHNUrZQ

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: billtypes; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.billtypes (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: billtypes; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.billtypes (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "nameID": 77950, "billTypeName": "Market Fine"}
1	2	{"_key": 2, "nameID": 77951, "billTypeName": "Rental Bill"}
2	3	{"_key": 3, "nameID": 77952, "billTypeName": "Broker Bill"}
3	4	{"_key": 4, "nameID": 77953, "billTypeName": "War Bill"}
4	5	{"_key": 5, "nameID": 77954, "billTypeName": "Alliance Maintenance Bill"}
5	6	{"_key": 6, "nameID": 77955, "description": "CONCORD sovereignty registrar fee", "billTypeName": "Sovereignty Bill"}
6	7	{"_key": 7, "nameID": 309671, "description": "Bill for infrastructure hub", "billTypeName": "Infrastructure Hub Bill"}
\.


--
-- Name: billtypes billtypes_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.billtypes
    ADD CONSTRAINT billtypes_pkey PRIMARY KEY (row_no);


--
-- Name: billtypes_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX billtypes_key_idx ON sde_native.billtypes USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict BUzV3pjbIhOE2Ue339uL6SvG7hFckrFfbqQOod55kpNFvMdysCLZ74kLNHNUrZQ

