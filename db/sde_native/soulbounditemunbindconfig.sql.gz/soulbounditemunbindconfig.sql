--
-- PostgreSQL database dump
--

\restrict dinRlTU6OCQcyAJANvtzgfAVS8PT1mgeA07lhvkmYgwVcnzjoyYEackKqxrZQ9b

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: soulbounditemunbindconfig; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.soulbounditemunbindconfig (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: soulbounditemunbindconfig; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.soulbounditemunbindconfig (row_no, key, data) FROM stdin;
0	\N	{"defaultUnbindItem": {"amount": 2, "typeID": 630}, "unbindSoulBoundItems": {"33470": {"amount": 1, "typeID": 630}, "59322": {"amount": 1, "typeID": 61957}}}
\.


--
-- Name: soulbounditemunbindconfig soulbounditemunbindconfig_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.soulbounditemunbindconfig
    ADD CONSTRAINT soulbounditemunbindconfig_pkey PRIMARY KEY (row_no);


--
-- Name: soulbounditemunbindconfig_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX soulbounditemunbindconfig_key_idx ON sde_native.soulbounditemunbindconfig USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict dinRlTU6OCQcyAJANvtzgfAVS8PT1mgeA07lhvkmYgwVcnzjoyYEackKqxrZQ9b

