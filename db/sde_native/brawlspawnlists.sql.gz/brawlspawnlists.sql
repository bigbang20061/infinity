--
-- PostgreSQL database dump
--

\restrict TnRCpOHOdZfRIa6PR5mxmWicnDGugZGv6FAI1chwdos4JAGbaPzrHfcfhIIgxM7

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: brawlspawnlists; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.brawlspawnlists (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: brawlspawnlists; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.brawlspawnlists (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "chests": [{"chance": 1.0, "chest_type_id": 3}, {"chance": 1.0, "chest_type_id": 4}, {"chance": 1.0, "chest_type_id": 5}], "spawn_count": 3}
1	2	{"_key": 2, "chests": [{"chance": 1.0, "chest_type_id": 4}, {"chance": 1.0, "chest_type_id": 5}, {"chance": 1.0, "chest_type_id": 7}], "spawn_count": 3}
2	3	{"_key": 3, "chests": [{"chance": 1.0, "chest_type_id": 3}, {"chance": 1.0, "chest_type_id": 5}, {"chance": 1.0, "chest_type_id": 6}], "spawn_count": 3}
3	4	{"_key": 4, "chests": [{"chance": 1.0, "chest_type_id": 5}, {"chance": 1.0, "chest_type_id": 8}], "spawn_count": 1}
4	5	{"_key": 5, "chests": [{"chance": 1.0, "chest_type_id": 3}, {"chance": 1.0, "chest_type_id": 4}, {"chance": 1.0, "chest_type_id": 5}, {"chance": 1.0, "chest_type_id": 6}, {"chance": 1.0, "chest_type_id": 7}, {"chance": 1.0, "chest_type_id": 8}], "spawn_count": 1}
5	6	{"_key": 6, "chests": [{"chance": 1.0, "chest_type_id": 3}, {"chance": 1.0, "chest_type_id": 4}, {"chance": 1.0, "chest_type_id": 5}, {"chance": 1.0, "chest_type_id": 16}, {"chance": 1.0, "chest_type_id": 17}, {"chance": 1.0, "chest_type_id": 18}, {"chance": 1.0, "chest_type_id": 19}], "spawn_count": 4}
6	7	{"_key": 7, "chests": [{"chance": 15.0, "chest_type_id": 1}, {"chance": 4.0, "chest_type_id": 12}, {"chance": 1.0, "chest_type_id": 13}], "spawn_count": 2}
7	8	{"_key": 8, "chests": [{"chance": 4.0, "chest_type_id": 14}, {"chance": 1.0, "chest_type_id": 15}, {"chance": 15.0, "chest_type_id": 1}], "spawn_count": 2}
8	9	{"_key": 9, "chests": [{"chance": 1.0, "chest_type_id": 2}, {"chance": 3.0, "chest_type_id": 1}], "spawn_count": 1}
9	10	{"_key": 10, "chests": [{"chance": 1.0, "chest_type_id": 2}, {"chance": 5.0, "chest_type_id": 1}], "spawn_count": 1}
10	11	{"_key": 11, "chests": [{"chance": 1.0, "chest_type_id": 7}, {"chance": 1.0, "chest_type_id": 8}, {"chance": 1.0, "chest_type_id": 10}], "spawn_count": 8}
11	12	{"_key": 12, "chests": [{"chance": 1.0, "chest_type_id": 6}, {"chance": 1.0, "chest_type_id": 8}, {"chance": 1.0, "chest_type_id": 9}], "spawn_count": 2}
12	13	{"_key": 13, "chests": [{"chance": 1.0, "chest_type_id": 8}, {"chance": 1.0, "chest_type_id": 11}], "spawn_count": 2}
13	14	{"_key": 14, "chests": [{"chance": 1.0, "chest_type_id": 6}, {"chance": 1.0, "chest_type_id": 7}, {"chance": 1.0, "chest_type_id": 8}, {"chance": 1.0, "chest_type_id": 9}, {"chance": 1.0, "chest_type_id": 10}, {"chance": 1.0, "chest_type_id": 11}], "spawn_count": 1}
14	15	{"_key": 15, "chests": [{"chance": 1.0, "chest_type_id": 6}, {"chance": 1.0, "chest_type_id": 7}, {"chance": 1.0, "chest_type_id": 8}, {"chance": 1.0, "chest_type_id": 18}, {"chance": 1.0, "chest_type_id": 19}, {"chance": 1.0, "chest_type_id": 9}, {"chance": 1.0, "chest_type_id": 10}, {"chance": 1.0, "chest_type_id": 11}, {"chance": 8.0, "chest_type_id": 1}], "spawn_count": 6}
15	16	{"_key": 16, "chests": [{"chance": 1.0, "chest_type_id": 20}, {"chance": 3.0, "chest_type_id": 1}], "spawn_count": 1}
16	17	{"_key": 17, "chests": [{"chance": 1.0, "chest_type_id": 22}, {"chance": 3.0, "chest_type_id": 1}], "spawn_count": 1}
17	18	{"_key": 18, "chests": [{"chance": 1.0, "chest_type_id": 21}, {"chance": 3.0, "chest_type_id": 1}], "spawn_count": 1}
18	19	{"_key": 19, "chests": [{"chance": 2.0, "chest_type_id": 23}, {"chance": 1.0, "chest_type_id": 1}], "spawn_count": 1}
19	20	{"_key": 20, "chests": [{"chance": 20.0, "chest_type_id": 1}, {"chance": 1.0, "chest_type_id": 12}, {"chance": 4.0, "chest_type_id": 13}], "spawn_count": 2}
20	21	{"_key": 21, "chests": [{"chance": 1.0, "chest_type_id": 14}, {"chance": 4.0, "chest_type_id": 15}, {"chance": 10.0, "chest_type_id": 1}], "spawn_count": 2}
21	22	{"_key": 22, "chests": [{"chance": 1.0, "chest_type_id": 24}, {"chance": 3.0, "chest_type_id": 1}], "spawn_count": 1}
22	23	{"_key": 23, "chests": [{"chance": 4.0, "chest_type_id": 14}, {"chance": 4.0, "chest_type_id": 16}, {"chance": 4.0, "chest_type_id": 17}, {"chance": 1.0, "chest_type_id": 15}, {"chance": 1.0, "chest_type_id": 18}, {"chance": 1.0, "chest_type_id": 19}], "spawn_count": 3}
23	24	{"_key": 24, "chests": [{"chance": 1.0, "chest_type_id": 13}], "spawn_count": 1}
\.


--
-- Name: brawlspawnlists brawlspawnlists_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.brawlspawnlists
    ADD CONSTRAINT brawlspawnlists_pkey PRIMARY KEY (row_no);


--
-- Name: brawlspawnlists_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX brawlspawnlists_key_idx ON sde_native.brawlspawnlists USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict TnRCpOHOdZfRIa6PR5mxmWicnDGugZGv6FAI1chwdos4JAGbaPzrHfcfhIIgxM7

