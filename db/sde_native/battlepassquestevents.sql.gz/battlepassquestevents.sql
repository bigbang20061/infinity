--
-- PostgreSQL database dump
--

\restrict Ja4JWmkj7uYk8lExDPsdvKm20ZIFhMp2QjIu4hs1utZxZDMd0fargfdIwBPy4QH

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: battlepassquestevents; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.battlepassquestevents (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: battlepassquestevents; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.battlepassquestevents (row_no, key, data) FROM stdin;
0	9900	{"_key": 9900, "name": "CharacterData", "conditions": [{"name": "MyShipTypeID", "condition_type": 9901}, {"name": "MySSolarSystemID", "condition_type": 9902}, {"name": "MySSolarSystemSecurity", "condition_type": 9903}]}
1	10100	{"_key": 10100, "name": "NPCShipExploded", "conditions": [{"name": "ExplodedShipType", "condition_type": 10102}, {"name": "ExplodedShipFaction", "condition_type": 10103}, {"name": "SolarSystemID", "condition_type": 10104}]}
2	10200	{"_key": 10200, "name": "SolarSystemEntered", "conditions": [{"name": "SolarSystemID", "condition_type": 10202}]}
3	10300	{"_key": 10300, "name": "StationEntered", "conditions": [{"name": "SolarSystemID", "condition_type": 10302}, {"name": "StationID", "condition_type": 10303}]}
4	10400	{"_key": 10400, "name": "MiningCompleted", "conditions": [{"name": "MinedItemType", "condition_type": 10402}, {"name": "SolarSystemID", "condition_type": 10403}]}
5	10500	{"_key": 10500, "name": "SalvagingCompleted", "conditions": [{"name": "WreckType", "condition_type": 10502}, {"name": "SalvagedItemType", "condition_type": 10503}]}
6	10600	{"_key": 10600, "name": "PlanetaryOperationCompleted", "conditions": [{"name": "PinType", "condition_type": 10602}, {"name": "ItemType", "condition_type": 10603}, {"name": "ItemQuantity", "condition_type": 10604}]}
7	10700	{"_key": 10700, "name": "SolarSystemLeft", "conditions": [{"name": "SolarSystem", "condition_type": 10702}]}
8	10800	{"_key": 10800, "name": "RelicSiteCharacterCompleted", "conditions": [{"name": "Archetype", "condition_type": 10802}, {"name": "DungeonId", "condition_type": 10803}]}
9	10900	{"_key": 10900, "name": "ManufacturingCompleted", "conditions": [{"name": "ItemType", "condition_type": 10902}]}
10	11000	{"_key": 11000, "name": "DataSiteCharacterCompleted", "conditions": [{"name": "Archetype", "condition_type": 11002}, {"name": "DungeonId", "condition_type": 11003}]}
11	11100	{"_key": 11100, "name": "CombatSiteCharacterCompleted", "conditions": [{"name": "Archetype", "condition_type": 11102}, {"name": "DungeonId", "condition_type": 11103}]}
12	11200	{"_key": 11200, "name": "GateJumped", "conditions": [{"name": "Destination", "condition_type": 11202}, {"name": "ShipType", "condition_type": 11203}, {"name": "CargoItem", "condition_type": 11204}, {"name": "SlotItem", "condition_type": 11205}]}
13	11300	{"_key": 11300, "name": "ExplorationSignatureScanned", "conditions": [{"name": "Archetype", "condition_type": 11302}]}
14	11400	{"_key": 11400, "name": "BountyPaid", "conditions": [{"name": "FactionType", "condition_type": 11402}, {"name": "SolarSystemID", "condition_type": 11403}]}
15	11500	{"_key": 11500, "name": "ShipExploded", "conditions": [{"name": "ExploderShipType", "condition_type": 11502}, {"name": "ExplodedCharacter", "condition_type": 11503}, {"name": "ExplodedShipType", "condition_type": 11504}, {"name": "SolarSystemID", "condition_type": 11505}]}
16	11600	{"_key": 11600, "name": "StructureExploded", "conditions": [{"name": "StructureType", "condition_type": 11602}]}
17	11700	{"_key": 11700, "name": "ShieldBoostApplied", "conditions": [{"name": "AmountBoosted", "condition_type": 11702}, {"name": "ModuleType", "condition_type": 11703}]}
18	11800	{"_key": 11800, "name": "ArmorRepairApplied", "conditions": [{"name": "AmountBoosted", "condition_type": 11802}, {"name": "ModuleType", "condition_type": 11803}]}
19	11900	{"_key": 11900, "name": "HullRepairApplied", "conditions": [{"name": "AmountBoosted", "condition_type": 11902}, {"name": "ModuleType", "condition_type": 11903}]}
20	12000	{"_key": 12000, "name": "ArmorActivated", "conditions": [{"name": "Duration", "condition_type": 12002}, {"name": "ModuleType", "condition_type": 12003}, {"name": "ShipsAffected", "condition_type": 12004}]}
21	12100	{"_key": 12100, "name": "InformationActivated", "conditions": [{"name": "Duration", "condition_type": 12102}, {"name": "ModuleType", "condition_type": 12103}, {"name": "ShipsAffected", "condition_type": 12104}]}
22	12200	{"_key": 12200, "name": "ShieldActivated", "conditions": [{"name": "Duration", "condition_type": 12202}, {"name": "ModuleType", "condition_type": 12203}, {"name": "ShipsAffected", "condition_type": 12204}]}
23	12300	{"_key": 12300, "name": "SkirmishActivated", "conditions": [{"name": "Duration", "condition_type": 12302}, {"name": "ModuleType", "condition_type": 12303}, {"name": "ShipsAffected", "condition_type": 12304}]}
24	12400	{"_key": 12400, "name": "MiningActivated", "conditions": [{"name": "Duration", "condition_type": 12402}, {"name": "ModuleType", "condition_type": 12403}, {"name": "ShipsAffected", "condition_type": 12404}]}
25	12500	{"_key": 12500, "name": "CapacitorTransmissionApplied", "conditions": [{"name": "AmountTransmitted", "condition_type": 12502}, {"name": "ModuleType", "condition_type": 12503}]}
26	12600	{"_key": 12600, "name": "TrackingComputerApplied", "conditions": [{"name": "ModuleType", "condition_type": 12602}]}
27	12700	{"_key": 12700, "name": "SensorBoosterApplied", "conditions": [{"name": "ModuleType", "condition_type": 12702}]}
28	12800	{"_key": 12800, "name": "JammingApplied", "conditions": [{"name": "JammerCharacter", "condition_type": 12801}, {"name": "JammedPilotCharacter", "condition_type": 12802}, {"name": "DurationJammed", "condition_type": 12803}, {"name": "ModuleType", "condition_type": 12804}]}
29	12900	{"_key": 12900, "name": "SensorDampeningApplied", "conditions": [{"name": "DampenerCharacter", "condition_type": 12901}, {"name": "DampenedPilotCharacter", "condition_type": 12902}, {"name": "DurationDampened", "condition_type": 12903}, {"name": "ModuleType", "condition_type": 12904}]}
30	13000	{"_key": 13000, "name": "StasisWebApplied", "conditions": [{"name": "WebberCharacter", "condition_type": 13001}, {"name": "WebbedPilotCharacter", "condition_type": 13002}, {"name": "DurationWebbed", "condition_type": 13003}, {"name": "ModuleType", "condition_type": 13004}]}
31	13100	{"_key": 13100, "name": "TargetPaintingApplied", "conditions": [{"name": "PainterCharacter", "condition_type": 13101}, {"name": "PaintedPilotCharacter", "condition_type": 13102}, {"name": "DurationPainted", "condition_type": 13103}, {"name": "ModuleType", "condition_type": 13104}]}
32	13200	{"_key": 13200, "name": "WarpDisruptionApplied", "conditions": [{"name": "DisrupterCharacter", "condition_type": 13201}, {"name": "DisruptedPilotCharacter", "condition_type": 13202}, {"name": "DurationDisrupted", "condition_type": 13203}, {"name": "ModuleType", "condition_type": 13204}]}
33	13300	{"_key": 13300, "name": "WarpScramblingApplied", "conditions": [{"name": "ScramblerCharacter", "condition_type": 13301}, {"name": "ScrambledPilotCharacter", "condition_type": 13302}, {"name": "DurationScrambled", "condition_type": 13303}, {"name": "ModuleType", "condition_type": 13304}]}
34	13400	{"_key": 13400, "name": "WeaponsDisruptionApplied", "conditions": [{"name": "DisrupterCharacter", "condition_type": 13401}, {"name": "DisruptedPilotCharacter", "condition_type": 13402}, {"name": "DurationDisrupted", "condition_type": 13403}, {"name": "ModuleType", "condition_type": 13404}]}
35	13500	{"_key": 13500, "name": "CapacitorNosferatuApplied", "conditions": [{"name": "DrainerCharacter", "condition_type": 13501}, {"name": "DrainedPilotCharacter", "condition_type": 13502}, {"name": "AmountDrained", "condition_type": 13503}, {"name": "ModuleType", "condition_type": 13504}]}
36	13600	{"_key": 13600, "name": "CapacitorNeutralizationApplied", "conditions": [{"name": "NeutralizerCharacter", "condition_type": 13601}, {"name": "NeutralizedPilotCharacter", "condition_type": 13602}, {"name": "AmountNeutralized", "condition_type": 13603}, {"name": "ModuleType", "condition_type": 13604}]}
37	13700	{"_key": 13700, "name": "MissionDistributionCompleted", "conditions": [{"name": "Level", "condition_type": 13702}]}
38	13800	{"_key": 13800, "name": "MissionMiningCompleted", "conditions": [{"name": "Level", "condition_type": 13802}]}
39	13900	{"_key": 13900, "name": "MissionSecurityCompleted", "conditions": [{"name": "Level", "condition_type": 13902}]}
40	14000	{"_key": 14000, "name": "IncursionsiteCompleted", "conditions": [{"name": "SiteType", "condition_type": 14002}]}
41	14100	{"_key": 14100, "name": "AbyssalEntered", "conditions": [{"name": "Level", "condition_type": 14102}, {"name": "WeatherType", "condition_type": 14103}]}
42	14200	{"_key": 14200, "name": "AbyssalCompleted", "conditions": [{"name": "Level", "condition_type": 14202}, {"name": "WeatherType", "condition_type": 14203}]}
43	14300	{"_key": 14300, "name": "PiratestrongholdDestructionParticipated", "conditions": [{"name": "PiratestrongholdType", "condition_type": 14302}, {"name": "ParticipatedTotalDamage", "condition_type": 14303}]}
44	14400	{"_key": 14400, "name": "PiratestrongholdRewardReceived", "conditions": [{"name": "PiratestrongholdType", "condition_type": 14402}, {"name": "IskReceived", "condition_type": 14403}]}
45	14500	{"_key": 14500, "name": "FactionwarfareCharacterFactionTransferred", "conditions": [{"name": "FromFaction", "condition_type": 14502}, {"name": "ToFaction", "condition_type": 14503}]}
46	14600	{"_key": 14600, "name": "FactionwarfaresiteCharacterConquered", "conditions": [{"name": "ArcheType", "condition_type": 14602}]}
47	14700	{"_key": 14700, "name": "FactionwarfaresiteCharacterDefended", "conditions": [{"name": "ArcheType", "condition_type": 14702}]}
48	14800	{"_key": 14800, "name": "ReactionCompleted", "conditions": [{"name": "ItemType", "condition_type": 14802}]}
49	14900	{"_key": 14900, "name": "BlueprintCopyCompleted", "conditions": [{"name": "ItemType", "condition_type": 14902}]}
50	15000	{"_key": 15000, "name": "BlueprintInventionCompleted", "conditions": [{"name": "ItemType", "condition_type": 15002}]}
51	15100	{"_key": 15100, "name": "MissionCommonCompleted", "conditions": [{"name": "MissionId", "condition_type": 15103}, {"name": "AgentId", "condition_type": 15104}]}
52	15200	{"_key": 15200, "name": "CharacterSelected", "conditions": [{"name": "User", "condition_type": 15201}, {"name": "Character", "condition_type": 15202}]}
53	15300	{"_key": 15300, "name": "WormholeJumped", "conditions": [{"name": "WormholeJumpedCharacter", "condition_type": 15301}, {"name": "WormholeJumpedOriginSolarSystemID", "condition_type": 15302}, {"name": "WormholeJumpedDestinationSolarSystemID", "condition_type": 15303}]}
54	15400	{"_key": 15400, "name": "FilamentActivated", "conditions": [{"name": "Character", "condition_type": 15401}, {"name": "FilamentUsed", "condition_type": 15402}]}
55	15500	{"_key": 15500, "name": "RoguelikeCompleted", "conditions": [{"name": "EndLevel", "condition_type": 15502}]}
56	15600	{"_key": 15600, "name": "RoguelikeUnlockedShopItem", "conditions": [{"name": "RoguelikeUnlockedShopItemId", "condition_type": 15602}]}
57	15700	{"_key": 15700, "name": "SkillPoints", "conditions": [{"name": "TotalSkillPoints", "condition_type": 15701}]}
58	15800	{"_key": 15800, "name": "Isk", "conditions": [{"name": "TotalIsk", "condition_type": 15801}]}
59	15900	{"_key": 15900, "name": "MissionOffered", "conditions": [{"name": "MissionOfferedByMissionId", "condition_type": 15902}, {"name": "MissionOfferedByAgentId", "condition_type": 15903}]}
60	16000	{"_key": 16000, "name": "CloudComputingShipAdded", "conditions": [{"name": "CloudComputingShipAddedShipId", "condition_type": 16002}]}
61	16100	{"_key": 16100, "name": "ShipAdaptionProgressAdded"}
62	16200	{"_key": 16200, "name": "ShipAdaptionUnlocked"}
63	16300	{"_key": 16300, "name": "WorldTaskDungeonCompleted"}
64	16400	{"_key": 16400, "name": "GachaTicketDecreased", "conditions": [{"name": "GachaTicketId", "condition_type": 16401}]}
65	16500	{"_key": 16500, "name": "MatrixTrained", "conditions": [{"name": "MatrixTrainedSlot1", "condition_type": 16501}, {"name": "MatrixTrainedSlot2", "condition_type": 16502}, {"name": "MatrixTrainedBoth", "condition_type": 16503}]}
66	16600	{"_key": 16600, "name": "MatrixEquipped", "conditions": [{"name": "MatrixEquippedSlot1", "condition_type": 16601}, {"name": "MatrixEquippedSlot2", "condition_type": 16602}, {"name": "MatrixEquippedBoth", "condition_type": 16603}]}
67	16700	{"_key": 16700, "name": "SeasonScoreAdded", "conditions": [{"name": "SeasonScore", "condition_type": 16701}, {"name": "SeasonId", "condition_type": 16702}]}
68	16800	{"_key": 16800, "name": "MatrixSecondaryLevelUp", "conditions": [{"name": "MatrixSecondaryLevel", "condition_type": 16801}]}
69	16900	{"_key": 16900, "name": "MatrixLevelUpByMatrix"}
70	17000	{"_key": 17000, "name": "MatrixSecondaryStageUp", "conditions": [{"name": "MatrixSecondaryStage", "condition_type": 17001}]}
71	17100	{"_key": 17100, "name": "MatrixPrimaryLevelUp", "conditions": [{"name": "MatrixPrimaryLevel", "condition_type": 17101}]}
72	17200	{"_key": 17200, "name": "MatrixRegenerated"}
\.


--
-- Name: battlepassquestevents battlepassquestevents_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.battlepassquestevents
    ADD CONSTRAINT battlepassquestevents_pkey PRIMARY KEY (row_no);


--
-- Name: battlepassquestevents_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX battlepassquestevents_key_idx ON sde_native.battlepassquestevents USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict Ja4JWmkj7uYk8lExDPsdvKm20ZIFhMp2QjIu4hs1utZxZDMd0fargfdIwBPy4QH

