--
-- PostgreSQL database dump
--

\restrict qp1o7VuRYbh3P9VwBll9OpJD0LFLFgUaKQXhPWxHQcNvyxfWHf4fa8FxCGcsJc8

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: petitionproperties; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.petitionproperties (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: petitionproperties; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.petitionproperties (row_no, key, data) FROM stdin;
0	2	{"_key": 2, "obsolete": 0, "required": 1, "inputInfo": "Missions", "inputType": "DropDown", "description": "The mission in question", "orderWeight": 1, "propertyName": "AgentMissionReq", "descriptionID": 62179, "outputTemplate": "<A href=\\"/gm/character.py?action=AgentDetails&agentID=propvalue&characterID=charvalue&\\" target=\\"blank\\">Agent</A>"}
1	3	{"_key": 3, "obsolete": 0, "required": 0, "inputInfo": "Missions", "inputType": "DropDown", "description": "The mission in question", "orderWeight": 1, "propertyName": "AgentMissionNoReq", "descriptionID": 62180, "outputTemplate": "<A href=\\"/gm/character.py?action=AgentDetails&agentID=propvalue&characterID=charvalue&\\" target=\\"blank\\">Agent</A>"}
2	4	{"_key": 4, "obsolete": 0, "required": 0, "inputInfo": "Agents", "inputType": "Picker", "description": "The agent in question", "orderWeight": 1, "propertyName": "Agents", "descriptionID": 62181, "outputTemplate": "<A href=\\"/gm/character.py?action=AgentDetails&agentID=propvalue&characterID=propCharacterID&\\" target=\\"blank\\">Agent</a>"}
3	5	{"_key": 5, "obsolete": 0, "required": 0, "inputInfo": "Destroyed Ship", "inputType": "DropDown", "description": "Please select the ship that was destroyed", "orderWeight": 1, "propertyName": "ShipID", "descriptionID": 62182, "outputTemplate": "<A href=\\"/gm/character.py?action=ShipKilled&characterID=0&eventID=propvalue\\" target=\\"blank\\">Destroyed ship</a>"}
4	6	{"_key": 6, "obsolete": 0, "required": 0, "inputInfo": "SolarSystems", "inputType": "Picker", "description": "Select solar system", "orderWeight": 1, "propertyName": "StarbaseLocation", "descriptionID": 62183, "outputTemplate": "<A href=\\"/gm/starbase.py?systemID=propvalue&Post=Submit&action=xStarbases\\" target=\\"blank\\">Starbases in system</a>"}
5	7	{"_key": 7, "obsolete": 0, "required": 0, "inputInfo": "Characters", "inputType": "Picker", "description": "Select Character", "orderWeight": 1, "propertyName": "Character", "descriptionID": 62184, "outputTemplate": "<A href=\\"/gm/character.py?action=Character&characterID=propvalue\\" target=\\"blank\\">Character</a>"}
6	8	{"_key": 8, "obsolete": 0, "required": 1, "inputInfo": "UserCharacters", "inputType": "DropDown", "description": "Select Character", "orderWeight": 1, "propertyName": "UserCharacters", "descriptionID": 62185, "outputTemplate": "<A href=\\"/gm/character.py?action=Character&characterID=propvalue\\" target=\\"blank\\">Character</a>"}
7	9	{"_key": 9, "obsolete": 0, "required": 1, "inputInfo": "http://", "inputType": "EditBox", "description": "Web Address", "orderWeight": 1, "propertyName": "WebAddress", "descriptionID": 62186, "outputTemplate": "<A href=\\"propvalue\\" target=\\"blank\\">WebPage</A>"}
8	10	{"_key": 10, "obsolete": 0, "required": 1, "inputInfo": "Corporations", "inputType": "Picker", "description": "Select Corporation", "orderWeight": 1, "propertyName": "Corporations", "descriptionID": 62187, "outputTemplate": "<A href=\\"/gm/corporation.py?corporationID=propvalue&Post=Go&action=Corporation\\" target=\\"blank\\">Corporation</A>"}
9	11	{"_key": 11, "obsolete": 0, "required": 0, "inputInfo": "ChrAgent", "inputType": "DropDown", "description": "The agent in question", "orderWeight": 1, "propertyName": "ChrAgent", "descriptionID": 62188, "outputTemplate": "<A href=\\"/gm/character.py?action=AgentDetails&agentID=propvalue&characterID=propCharacterID&\\" target=\\"blank\\">Agent</a>"}
10	12	{"_key": 12, "obsolete": 0, "required": 1, "inputInfo": "Operating System", "inputType": "DropDown", "description": "Operating System", "orderWeight": 1, "propertyName": "OS", "descriptionID": 62189, "outputTemplate": "propvalue"}
11	13	{"_key": 13, "obsolete": 0, "required": 0, "inputInfo": "ChrEpicArc", "inputType": "DropDown", "description": "The epic arc in question", "orderWeight": 1, "propertyName": "ChrEpicArc", "descriptionID": 62190, "outputTemplate": "<a href=\\"/gm/character.py?action=DisplayEpicMissionArcStatus&characterID=propCharacterID&\\" target=\\"_blank\\">Epic Arc</a></td></tr><tr><td class=\\"csp-\\"><a href=\\"/gm/character.py?action=AgentDetails&agentID=propvalue&characterID=propCharacterID&\\" target=\\"_blank\\">Agent</a>"}
\.


--
-- Name: petitionproperties petitionproperties_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.petitionproperties
    ADD CONSTRAINT petitionproperties_pkey PRIMARY KEY (row_no);


--
-- Name: petitionproperties_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX petitionproperties_key_idx ON sde_native.petitionproperties USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict qp1o7VuRYbh3P9VwBll9OpJD0LFLFgUaKQXhPWxHQcNvyxfWHf4fa8FxCGcsJc8

