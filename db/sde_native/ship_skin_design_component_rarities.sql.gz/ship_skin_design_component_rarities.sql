--
-- PostgreSQL database dump
--

\restrict EfV05Fhgu9Z2bbhvFH3PeeKjS1ITXXMdeqJgSeCrj4Vq1wphx281IEPRnjB2thN

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ship_skin_design_component_rarities; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.ship_skin_design_component_rarities (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: ship_skin_design_component_rarities; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.ship_skin_design_component_rarities (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "name": 709470, "rank": 1}
1	2	{"_key": 2, "name": 709471, "rank": 2}
2	3	{"_key": 3, "name": 709472, "rank": 3}
3	4	{"_key": 4, "name": 709473, "rank": 4}
4	5	{"_key": 5, "name": 709474, "rank": 5}
5	6	{"_key": 6, "name": 709475, "rank": 6}
\.


--
-- Name: ship_skin_design_component_rarities ship_skin_design_component_rarities_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.ship_skin_design_component_rarities
    ADD CONSTRAINT ship_skin_design_component_rarities_pkey PRIMARY KEY (row_no);


--
-- Name: ship_skin_design_component_rarities_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX ship_skin_design_component_rarities_key_idx ON sde_native.ship_skin_design_component_rarities USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict EfV05Fhgu9Z2bbhvFH3PeeKjS1ITXXMdeqJgSeCrj4Vq1wphx281IEPRnjB2thN

