--
-- PostgreSQL database dump
--

\restrict GJekAQ8CmIF9zUdcW5DIViWztjKPoQYUKTIlhaxMkgPet1XsS65FViPl7cQkmHh

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: amplificationskills; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.amplificationskills (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: amplificationskills; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.amplificationskills (row_no, key, data) FROM stdin;
0	100	{"_key": 100, "nameID": 695596, "target": 1, "cooldownTo": 360.0, "durationTo": 180.0, "collectionID": 2381, "cooldownFrom": 420.0, "durationFrom": 120.0, "descriptionID": 695597, "effectValueTo": 10.5, "effectValueFrom": 4.0}
1	101	{"_key": 101, "nameID": 695598, "target": 1, "cooldownTo": 150.0, "durationTo": 15.0, "collectionID": 2382, "cooldownFrom": 210.0, "durationFrom": 10.0, "descriptionID": 695599, "effectValueTo": 12.0, "effectValueFrom": 5.0}
2	102	{"_key": 102, "nameID": 695600, "target": 1, "cooldownTo": 150.0, "durationTo": 15.0, "collectionID": 2383, "cooldownFrom": 210.0, "durationFrom": 10.0, "descriptionID": 695601, "effectValueTo": 12.0, "effectValueFrom": 5.0}
3	103	{"_key": 103, "nameID": 695602, "target": 1, "cooldownTo": 150.0, "durationTo": 15.0, "collectionID": 2384, "cooldownFrom": 210.0, "durationFrom": 10.0, "descriptionID": 695603, "effectValueTo": 12.0, "effectValueFrom": 5.0}
4	104	{"_key": 104, "nameID": 695604, "target": 1, "cooldownTo": 130.0, "durationTo": 13.0, "collectionID": 2373, "cooldownFrom": 180.0, "durationFrom": 8.0, "descriptionID": 695605, "effectValueTo": -12.0, "effectValueFrom": -5.0}
5	105	{"_key": 105, "nameID": 695608, "target": 1, "cooldownTo": 130.0, "durationTo": 13.0, "collectionID": 2374, "cooldownFrom": 180.0, "durationFrom": 8.0, "descriptionID": 695609, "effectValueTo": -12.0, "effectValueFrom": -5.0}
6	106	{"_key": 106, "nameID": 695610, "target": 1, "cooldownTo": 130.0, "durationTo": 13.0, "collectionID": 2385, "cooldownFrom": 180.0, "durationFrom": 8.0, "descriptionID": 695611, "effectValueTo": 12.0, "effectValueFrom": 5.0}
7	107	{"_key": 107, "nameID": 695612, "target": 1, "cooldownTo": 130.0, "durationTo": 13.0, "collectionID": 2386, "cooldownFrom": 180.0, "durationFrom": 8.0, "descriptionID": 695613, "effectValueTo": 12.0, "effectValueFrom": 5.0}
8	108	{"_key": 108, "nameID": 695612, "target": 1, "cooldownTo": 160.0, "durationTo": 20.0, "collectionID": 2386, "cooldownFrom": 180.0, "durationFrom": 15.0, "descriptionID": 695613, "effectValueTo": 15.0, "effectValueFrom": 10.0}
9	109	{"_key": 109, "nameID": 711299, "target": 1, "cooldownTo": 100.0, "durationTo": 25.0, "collectionID": 2422, "cooldownFrom": 160.0, "durationFrom": 15.0, "descriptionID": 711298, "effectValueTo": -23.5, "effectValueFrom": -9.5}
10	200	{"_key": 200, "nameID": 695614, "target": 1, "cooldownTo": 360.0, "durationTo": 210.0, "collectionID": 2387, "cooldownFrom": 420.0, "durationFrom": 150.0, "descriptionID": 695615, "effectValueTo": -13.0, "effectValueFrom": -5.0}
11	201	{"_key": 201, "nameID": 695616, "target": 1, "cooldownTo": 360.0, "durationTo": 210.0, "collectionID": 2412, "cooldownFrom": 420.0, "durationFrom": 150.0, "descriptionID": 695617, "effectValueTo": -13.0, "effectValueFrom": -5.0}
12	202	{"_key": 202, "nameID": 695618, "target": 1, "cooldownTo": 210.0, "durationTo": 26.0, "collectionID": 2389, "cooldownFrom": 300.0, "durationFrom": 18.0, "descriptionID": 695619, "effectValueTo": -25.0, "effectValueFrom": -10.0}
13	203	{"_key": 203, "nameID": 695620, "target": 1, "cooldownTo": 100.0, "durationTo": 19.0, "collectionID": 2390, "cooldownFrom": 160.0, "durationFrom": 12.0, "descriptionID": 695621, "effectValueTo": -18.0, "effectValueFrom": -6.0}
14	204	{"_key": 204, "nameID": 695622, "target": 1, "cooldownTo": 100.0, "durationTo": 19.0, "collectionID": 2391, "cooldownFrom": 160.0, "durationFrom": 12.0, "descriptionID": 695623, "effectValueTo": -18.0, "effectValueFrom": -16.0}
15	205	{"_key": 205, "nameID": 695625, "target": 1, "cooldownTo": 60.0, "durationTo": 23.0, "collectionID": 2375, "cooldownFrom": 100.0, "durationFrom": 15.0, "descriptionID": 695626, "effectValueTo": 20.0, "effectValueFrom": 7.5}
16	206	{"_key": 206, "nameID": 695628, "target": 1, "cooldownTo": 70.0, "durationTo": 60.0, "collectionID": 2376, "cooldownFrom": 110.0, "durationFrom": 40.0, "descriptionID": 695629, "effectValueTo": 30.0, "effectValueFrom": 13.0}
17	207	{"_key": 207, "nameID": 695631, "target": 1, "cooldownTo": 105.0, "durationTo": 19.0, "collectionID": 2377, "cooldownFrom": 150.0, "durationFrom": 12.0, "descriptionID": 695632, "effectValueTo": -18.0, "effectValueFrom": -6.0}
18	208	{"_key": 208, "nameID": 695633, "target": 1, "cooldownTo": 90.0, "durationTo": 12.0, "collectionID": 2392, "cooldownFrom": 120.0, "durationFrom": 6.0, "descriptionID": 695634, "effectValueTo": 25.0, "effectValueFrom": 10.0}
19	209	{"_key": 209, "nameID": 695635, "target": 1, "cooldownTo": 120.0, "durationTo": 19.0, "collectionID": 2393, "cooldownFrom": 180.0, "durationFrom": 12.0, "descriptionID": 695636, "effectValueTo": -17.0, "effectValueFrom": -7.5}
20	210	{"_key": 210, "nameID": 695637, "target": 1, "cooldownTo": 120.0, "durationTo": 19.0, "collectionID": 2394, "cooldownFrom": 180.0, "durationFrom": 12.0, "descriptionID": 695638, "effectValueTo": -17.0, "effectValueFrom": -7.5}
21	211	{"_key": 211, "nameID": 695639, "target": 1, "cooldownTo": 120.0, "durationTo": 19.0, "collectionID": 2384, "cooldownFrom": 180.0, "durationFrom": 12.0, "descriptionID": 695640, "effectValueTo": 20.5, "effectValueFrom": 8.0}
22	212	{"_key": 212, "nameID": 695641, "target": 1, "cooldownTo": 110.0, "durationTo": 16.0, "collectionID": 2373, "cooldownFrom": 160.0, "durationFrom": 10.0, "descriptionID": 695642, "effectValueTo": -18.5, "effectValueFrom": -7.5}
23	213	{"_key": 213, "nameID": 695643, "target": 1, "cooldownTo": 110.0, "durationTo": 16.0, "collectionID": 2374, "cooldownFrom": 160.0, "durationFrom": 10.0, "descriptionID": 695644, "effectValueTo": -18.5, "effectValueFrom": -7.5}
24	300	{"_key": 300, "nameID": 695645, "target": 1, "cooldownTo": 100.0, "durationTo": 25.0, "collectionID": 2382, "cooldownFrom": 160.0, "durationFrom": 15.0, "descriptionID": 695646, "effectValueTo": 30.0, "effectValueFrom": 10.5}
25	301	{"_key": 301, "nameID": 695647, "target": 1, "cooldownTo": 100.0, "durationTo": 25.0, "collectionID": 2383, "cooldownFrom": 160.0, "durationFrom": 15.0, "descriptionID": 695648, "effectValueTo": 30.0, "effectValueFrom": 10.5}
26	302	{"_key": 302, "nameID": 695649, "target": 1, "cooldownTo": 110.0, "durationTo": 25.0, "collectionID": 2384, "cooldownFrom": 160.0, "durationFrom": 15.0, "descriptionID": 695650, "effectValueTo": 30.0, "effectValueFrom": 10.5}
27	303	{"_key": 303, "nameID": 695651, "target": 1, "cooldownTo": 90.0, "durationTo": 22.0, "collectionID": 2373, "cooldownFrom": 140.0, "durationFrom": 12.0, "descriptionID": 695652, "effectValueTo": -30.0, "effectValueFrom": -10.5}
28	304	{"_key": 304, "nameID": 695653, "target": 1, "cooldownTo": 90.0, "durationTo": 22.0, "collectionID": 2374, "cooldownFrom": 140.0, "durationFrom": 12.0, "descriptionID": 695654, "effectValueTo": -30.0, "effectValueFrom": -10.5}
29	305	{"_key": 305, "nameID": 695655, "target": 1, "cooldownTo": 90.0, "durationTo": 22.0, "collectionID": 2385, "cooldownFrom": 140.0, "durationFrom": 12.0, "descriptionID": 695656, "effectValueTo": 30.0, "effectValueFrom": 10.5}
30	306	{"_key": 306, "nameID": 695657, "target": 1, "cooldownTo": 90.0, "durationTo": 22.0, "collectionID": 2386, "cooldownFrom": 140.0, "durationFrom": 12.0, "descriptionID": 695658, "effectValueTo": 30.0, "effectValueFrom": 10.5}
31	307	{"_key": 307, "nameID": 695659, "target": 1, "cooldownTo": 60.0, "durationTo": 17.0, "collectionID": 2395, "cooldownFrom": 90.0, "durationFrom": 9.0, "descriptionID": 695660, "effectValueTo": 23.5, "effectValueFrom": 8.0}
32	308	{"_key": 308, "nameID": 695665, "target": 1, "cooldownTo": 450.0, "durationTo": 300.0, "collectionID": 2378, "cooldownFrom": 600.0, "durationFrom": 225.0, "descriptionID": 695666, "effectValueTo": 21.5, "effectValueFrom": 7.5}
33	666	{"_key": 666, "nameID": 701179, "target": 1, "cooldownTo": 60.0, "durationTo": 5.0, "collectionID": 2395, "cooldownFrom": 60.0, "durationFrom": 5.0, "descriptionID": 701178, "effectValueTo": 3.0, "effectValueFrom": 3.0}
34	999	{"_key": 999, "nameID": 695594, "target": 1, "cooldownTo": 240.0, "durationTo": 10.0, "collectionID": 2395, "cooldownFrom": 240.0, "durationFrom": 10.0, "descriptionID": 695595, "effectValueTo": 1.0, "effectValueFrom": 1.0}
\.


--
-- Name: amplificationskills amplificationskills_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.amplificationskills
    ADD CONSTRAINT amplificationskills_pkey PRIMARY KEY (row_no);


--
-- Name: amplificationskills_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX amplificationskills_key_idx ON sde_native.amplificationskills USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict GJekAQ8CmIF9zUdcW5DIViWztjKPoQYUKTIlhaxMkgPet1XsS65FViPl7cQkmHh

