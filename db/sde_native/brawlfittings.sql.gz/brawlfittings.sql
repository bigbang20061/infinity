--
-- PostgreSQL database dump
--

\restrict fYofayymayvHNhNaTNYd8NZ2MyVahlcDOGx7Y8CoTBfchxsuUH4Hstl2bkfKcuf

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: brawlfittings; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.brawlfittings (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: brawlfittings; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.brawlfittings (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "name": 644776, "fitData": [{"typeID": 73319, "quantity": 1, "slotFlag": 27}, {"typeID": 73319, "quantity": 1, "slotFlag": 28}, {"typeID": 73385, "quantity": 1, "slotFlag": 29}, {"typeID": 73346, "quantity": 1, "slotFlag": 19}, {"typeID": 73349, "quantity": 1, "slotFlag": 20}, {"typeID": 77028, "quantity": 1, "slotFlag": 21}, {"typeID": 73364, "quantity": 1, "slotFlag": 11}, {"typeID": 73320, "quantity": 60, "slotFlag": 90}, {"typeID": 73350, "quantity": 3, "slotFlag": 90}, {"typeID": 76471, "quantity": 1, "slotFlag": 90}], "shipTypeID": 73318, "description": 644775, "shipFittingID": 50, "consumeAchievementPoint": 0}
1	2	{"_key": 2, "name": 644778, "fitData": [{"typeID": 73319, "quantity": 1, "slotFlag": 27}, {"typeID": 73319, "quantity": 1, "slotFlag": 28}, {"typeID": 73356, "quantity": 1, "slotFlag": 29}, {"typeID": 73346, "quantity": 1, "slotFlag": 19}, {"typeID": 73349, "quantity": 1, "slotFlag": 20}, {"typeID": 73378, "quantity": 1, "slotFlag": 21}, {"typeID": 77028, "quantity": 1, "slotFlag": 22}, {"typeID": 73320, "quantity": 45, "slotFlag": 90}, {"typeID": 73350, "quantity": 3, "slotFlag": 90}, {"typeID": 76471, "quantity": 1, "slotFlag": 90}], "shipTypeID": 74422, "description": 644777, "shipFittingID": 51, "consumeAchievementPoint": 175}
2	3	{"_key": 3, "name": 644797, "fitData": [{"typeID": 73323, "quantity": 1, "slotFlag": 27}, {"typeID": 73323, "quantity": 1, "slotFlag": 28}, {"typeID": 73346, "quantity": 1, "slotFlag": 19}, {"typeID": 73349, "quantity": 1, "slotFlag": 20}, {"typeID": 77028, "quantity": 1, "slotFlag": 21}, {"typeID": 76461, "quantity": 1, "slotFlag": 11}, {"typeID": 73324, "quantity": 2, "slotFlag": 90}, {"typeID": 73350, "quantity": 3, "slotFlag": 90}, {"typeID": 76471, "quantity": 1, "slotFlag": 90}], "shipTypeID": 73379, "description": 644796, "shipFittingID": 52, "consumeAchievementPoint": 0}
3	4	{"_key": 4, "name": 648972, "fitData": [{"typeID": 73319, "quantity": 1, "slotFlag": 27}, {"typeID": 73319, "quantity": 1, "slotFlag": 28}, {"typeID": 73346, "quantity": 1, "slotFlag": 19}, {"typeID": 73349, "quantity": 1, "slotFlag": 20}, {"typeID": 77028, "quantity": 1, "slotFlag": 21}, {"typeID": 76463, "quantity": 1, "slotFlag": 11}, {"typeID": 73320, "quantity": 60, "slotFlag": 90}, {"typeID": 73350, "quantity": 3, "slotFlag": 90}, {"typeID": 76471, "quantity": 1, "slotFlag": 90}], "shipTypeID": 76010, "description": 648971, "shipFittingID": 53, "consumeAchievementPoint": 0}
4	5	{"_key": 5, "name": 651655, "fitData": [{"typeID": 73319, "quantity": 1, "slotFlag": 27}, {"typeID": 73319, "quantity": 1, "slotFlag": 28}, {"typeID": 73346, "quantity": 1, "slotFlag": 19}, {"typeID": 73349, "quantity": 1, "slotFlag": 20}, {"typeID": 73348, "quantity": 1, "slotFlag": 21}, {"typeID": 77028, "quantity": 1, "slotFlag": 22}, {"typeID": 73320, "quantity": 60, "slotFlag": 90}, {"typeID": 73350, "quantity": 3, "slotFlag": 90}, {"typeID": 76471, "quantity": 1, "slotFlag": 90}], "preFitID": 1, "shipTypeID": 73318, "description": 651654, "shipFittingID": 54, "consumeAchievementPoint": 75}
5	6	{"_key": 6, "name": 651660, "fitData": [{"typeID": 73323, "quantity": 1, "slotFlag": 27}, {"typeID": 73323, "quantity": 1, "slotFlag": 28}, {"typeID": 73346, "quantity": 1, "slotFlag": 19}, {"typeID": 73349, "quantity": 1, "slotFlag": 20}, {"typeID": 74496, "quantity": 1, "slotFlag": 21}, {"typeID": 77028, "quantity": 1, "slotFlag": 22}, {"typeID": 73324, "quantity": 2, "slotFlag": 90}, {"typeID": 73350, "quantity": 3, "slotFlag": 90}, {"typeID": 76471, "quantity": 1, "slotFlag": 90}], "preFitID": 1, "shipTypeID": 73318, "description": 651659, "shipFittingID": 55, "consumeAchievementPoint": 75}
6	7	{"_key": 7, "name": 651665, "fitData": [{"typeID": 73319, "quantity": 1, "slotFlag": 27}, {"typeID": 73319, "quantity": 1, "slotFlag": 28}, {"typeID": 73356, "quantity": 1, "slotFlag": 29}, {"typeID": 73346, "quantity": 1, "slotFlag": 19}, {"typeID": 73349, "quantity": 1, "slotFlag": 20}, {"typeID": 77013, "quantity": 1, "slotFlag": 21}, {"typeID": 77028, "quantity": 1, "slotFlag": 22}, {"typeID": 73320, "quantity": 60, "slotFlag": 90}, {"typeID": 73350, "quantity": 3, "slotFlag": 90}, {"typeID": 76471, "quantity": 1, "slotFlag": 90}], "preFitID": 2, "shipTypeID": 74422, "description": 651664, "shipFittingID": 56, "consumeAchievementPoint": 75}
7	8	{"_key": 8, "name": 651676, "fitData": [{"typeID": 73325, "quantity": 1, "slotFlag": 27}, {"typeID": 73325, "quantity": 1, "slotFlag": 28}, {"typeID": 73346, "quantity": 1, "slotFlag": 19}, {"typeID": 73349, "quantity": 1, "slotFlag": 20}, {"typeID": 77028, "quantity": 1, "slotFlag": 21}, {"typeID": 73334, "quantity": 2, "slotFlag": 90}, {"typeID": 73350, "quantity": 3, "slotFlag": 90}, {"typeID": 76471, "quantity": 1, "slotFlag": 90}], "preFitID": 3, "shipTypeID": 73379, "description": 651675, "shipFittingID": 57, "consumeAchievementPoint": 75}
8	9	{"_key": 9, "name": 651679, "fitData": [{"typeID": 73319, "quantity": 1, "slotFlag": 27}, {"typeID": 73319, "quantity": 1, "slotFlag": 28}, {"typeID": 73346, "quantity": 1, "slotFlag": 19}, {"typeID": 73349, "quantity": 1, "slotFlag": 20}, {"typeID": 77028, "quantity": 1, "slotFlag": 21}, {"typeID": 73363, "quantity": 1, "slotFlag": 11}, {"typeID": 73320, "quantity": 60, "slotFlag": 90}, {"typeID": 73350, "quantity": 3, "slotFlag": 90}, {"typeID": 76471, "quantity": 1, "slotFlag": 90}], "preFitID": 4, "shipTypeID": 76010, "description": 651678, "shipFittingID": 58, "consumeAchievementPoint": 75}
\.


--
-- Name: brawlfittings brawlfittings_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.brawlfittings
    ADD CONSTRAINT brawlfittings_pkey PRIMARY KEY (row_no);


--
-- Name: brawlfittings_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX brawlfittings_key_idx ON sde_native.brawlfittings USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict fYofayymayvHNhNaTNYd8NZ2MyVahlcDOGx7Y8CoTBfchxsuUH4Hstl2bkfKcuf

