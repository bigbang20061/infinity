--
-- PostgreSQL database dump
--

\restrict NhShJLKPnDI9Zo6CEtjue32bp7VHN4zH8MkmGYM9OWbvlCVSJLSEWIvwdDDdORV

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: shipadaptionchips; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.shipadaptionchips (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: shipadaptionchips; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.shipadaptionchips (row_no, key, data) FROM stdin;
0	64093	{"_key": 64093, "corpsBonus": {}, "defaultCorpBonus": {"lpBonus": 100}}
1	64094	{"_key": 64094, "corpsBonus": {}, "defaultCorpBonus": {"lpBonus": 250}}
2	64095	{"_key": 64095, "corpsBonus": {}, "defaultCorpBonus": {"lpBonus": 500}}
\.


--
-- Name: shipadaptionchips shipadaptionchips_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.shipadaptionchips
    ADD CONSTRAINT shipadaptionchips_pkey PRIMARY KEY (row_no);


--
-- Name: shipadaptionchips_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX shipadaptionchips_key_idx ON sde_native.shipadaptionchips USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict NhShJLKPnDI9Zo6CEtjue32bp7VHN4zH8MkmGYM9OWbvlCVSJLSEWIvwdDDdORV

