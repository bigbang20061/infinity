--
-- PostgreSQL database dump
--

\restrict nUXuAY6PR7N2fN4H774rUjZTW1qFytpxxXo6CrXJjhZcJOxdBeYMcxQjm4wsnck

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: character_modifierlocations; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.character_modifierlocations (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: character_modifierlocations; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.character_modifierlocations (row_no, key, data) FROM stdin;
0	2	{"_key": 2, "modifierKey": "topouter", "variationKey": ""}
1	3	{"_key": 3, "modifierKey": "makeup/implants", "variationKey": ""}
2	4	{"_key": 4, "modifierKey": "accessories/earslow", "variationKey": ""}
3	5	{"_key": 5, "modifierKey": "hair", "variationKey": ""}
4	6	{"_key": 6, "modifierKey": "makeup/eyes", "variationKey": ""}
5	7	{"_key": 7, "modifierKey": "makeup/lipstick", "variationKey": ""}
6	8	{"_key": 8, "modifierKey": "makeup/blush", "variationKey": ""}
7	9	{"_key": 9, "modifierKey": "makeup/eyeshadow", "variationKey": ""}
8	10	{"_key": 10, "modifierKey": "outer", "variationKey": "dependants/hood"}
9	11	{"_key": 11, "modifierKey": "makeup/freckles", "variationKey": ""}
10	12	{"_key": 12, "modifierKey": "accessories/nose", "variationKey": ""}
11	13	{"_key": 13, "modifierKey": "accessories/nostril", "variationKey": ""}
12	14	{"_key": 14, "modifierKey": "accessories/lips", "variationKey": ""}
13	15	{"_key": 15, "modifierKey": "makeup/aging", "variationKey": ""}
14	16	{"_key": 16, "modifierKey": "beard", "variationKey": ""}
15	17	{"_key": 17, "modifierKey": "makeup/eyeliner", "variationKey": ""}
16	18	{"_key": 18, "modifierKey": "makeup/eyelashes", "variationKey": ""}
17	19	{"_key": 19, "modifierKey": "accessories/earshigh", "variationKey": ""}
18	20	{"_key": 20, "modifierKey": "makeup/eyebrows", "variationKey": ""}
19	21	{"_key": 21, "modifierKey": "accessories/glasses", "variationKey": ""}
20	22	{"_key": 22, "modifierKey": "feet", "variationKey": "dependants/boottucking"}
21	23	{"_key": 23, "modifierKey": "bottominner", "variationKey": ""}
22	24	{"_key": 24, "modifierKey": "makeup/scarring", "variationKey": ""}
23	25	{"_key": 25, "modifierKey": "bottomouter", "variationKey": "dependants/waisttucking"}
24	26	{"_key": 26, "modifierKey": "topmiddle", "variationKey": "dependants/drape"}
25	27	{"_key": 27, "modifierKey": "topinner", "variationKey": ""}
26	28	{"_key": 28, "modifierKey": "scars/head", "variationKey": ""}
27	29	{"_key": 29, "modifierKey": "accessories/brow", "variationKey": ""}
28	30	{"_key": 30, "modifierKey": "tattoo/head", "variationKey": ""}
29	31	{"_key": 31, "modifierKey": "archetypes", "variationKey": ""}
30	32	{"_key": 32, "modifierKey": "accessories/chin", "variationKey": ""}
31	33	{"_key": 33, "modifierKey": "accessories", "variationKey": ""}
32	34	{"_key": 34, "modifierKey": "accessories/piercings", "variationKey": ""}
33	121	{"_key": 121, "modifierKey": "topunderwear", "variationKey": ""}
34	122	{"_key": 122, "modifierKey": "bottomunderwear", "variationKey": ""}
35	123	{"_key": 123, "modifierKey": "tattoo/armleft", "variationKey": ""}
36	124	{"_key": 124, "modifierKey": "tattoo/armright", "variationKey": ""}
37	125	{"_key": 125, "modifierKey": "bottommiddle", "variationKey": ""}
38	128	{"_key": 128, "modifierKey": "makeup/teeth", "variationKey": ""}
39	129	{"_key": 129, "modifierKey": "makeup/blemish", "variationKey": ""}
40	131	{"_key": 131, "modifierKey": "skintype", "variationKey": ""}
41	157	{"_key": 157, "modifierKey": "makeup/armright", "variationKey": ""}
42	158	{"_key": 158, "modifierKey": "makeup/armleft", "variationKey": ""}
43	201	{"_key": 201, "modifierKey": "makeup/augmentations", "variationKey": ""}
44	202	{"_key": 202, "modifierKey": "makeup/bodyaugmentations", "variationKey": ""}
45	203	{"_key": 203, "modifierKey": "accessories/masks", "variationKey": ""}
\.


--
-- Name: character_modifierlocations character_modifierlocations_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.character_modifierlocations
    ADD CONSTRAINT character_modifierlocations_pkey PRIMARY KEY (row_no);


--
-- Name: character_modifierlocations_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX character_modifierlocations_key_idx ON sde_native.character_modifierlocations USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict nUXuAY6PR7N2fN4H774rUjZTW1qFytpxxXo6CrXJjhZcJOxdBeYMcxQjm4wsnck

