--
-- PostgreSQL database dump
--

\restrict 9bN1bgaMh5fcgz3fAEqaZuMYDEI529RtlcVFFRxZJ8R2kyjapYEWGj3rOXitoyU

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: landmarks; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.landmarks (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: landmarks; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.landmarks (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "position": [-515501499308782900, 612187233571366.0, -76819336279219790], "position2d": [-264962111963111870, -55163155250987200], "landmarkType": "landmark", "descriptionID": 60740, "landmarkNameID": 60785}
1	3	{"_key": 3, "iconID": 2071, "position": [-204748693848000000, 40238378906300000, -57621276855500000], "position2d": [-84073287128690900, -88100039192090610], "landmarkType": "landmark", "descriptionID": 60741, "landmarkNameID": 60786}
2	4	{"_key": 4, "iconID": 2071, "position": [-211238818359000000, 1722270995380.0, -70628735351600000], "position2d": [-146125749481000000, -78657107766000000], "landmarkType": "landmark", "descriptionID": 60742, "landmarkNameID": 60787}
3	5	{"_key": 5, "iconID": 2081, "position": [-88028601074200000, 141912640538.0, 28733605957000000], "position2d": [114572205534810820, 56831076740588800], "landmarkType": "landmark", "descriptionID": 60743, "landmarkNameID": 60788}
4	6	{"_key": 6, "iconID": 2072, "position": [-135868737793000000, -7529594749210.0, 119848132324000000], "position2d": [-74006406970191680, 197374767806004100], "landmarkType": "landmark", "descriptionID": 60744, "landmarkNameID": 60789}
5	7	{"_key": 7, "iconID": 2076, "position": [-223934619141000000, -4200590029360.0, 55112884521500000], "position2d": [-249844290724331650, 82059911096990980], "landmarkType": "landmark", "descriptionID": 60745, "landmarkNameID": 60790}
6	8	{"_key": 8, "iconID": 2079, "position": [9537117767330000.0, -261083897203.0, 253588720703000000], "position2d": [149732477519990900, 384185018293746400], "landmarkType": "landmark", "descriptionID": 60746, "landmarkNameID": 60791}
7	9	{"_key": 9, "position": [-87952695312500000, 550164356827.7358, -65326328125000000], "position2d": [98203443178829280, -86492990749554690], "landmarkType": "landmark", "descriptionID": 60747, "landmarkNameID": 60792}
8	10	{"_key": 10, "iconID": 2080, "position": [-296470820312000000, 27066481113400.0, -139493173828000000], "position2d": [-311213453123672600, -218990786819053700], "landmarkType": "landmark", "descriptionID": 60748, "landmarkNameID": 60793}
9	11	{"_key": 11, "position": [-431159296875000000, 66517033576965.33, -2205274658203125.0], "position2d": [-532426106160626300, -21804725458953450], "landmarkType": "landmark", "descriptionID": 60749, "landmarkNameID": 60794}
10	12	{"_key": 12, "iconID": 2074, "position": [3564098815917968.5, -1551699970.1503663, -153965849609375000], "position2d": [212288664337114050, -242321903933180960], "landmarkType": "landmark", "descriptionID": 60750, "landmarkNameID": 60795}
11	13	{"_key": 13, "position": [34615988769531250, 657644420862.1979, -76553710937500000], "position2d": [296259989111969860, -110581977299650560], "landmarkType": "landmark", "descriptionID": 60751, "landmarkNameID": 60796}
12	14	{"_key": 14, "position": [-315631054687499970, 3285689651966.0947, 62230039062500000], "position2d": [-321444690509249340, 101201440746817730], "landmarkType": "landmark", "descriptionID": 60752, "landmarkNameID": 60797}
13	15	{"_key": 15, "iconID": 2083, "position": [-391229140625000000, -11646238565444.945, 90042294921874990], "position2d": [-455872162170732800, 188298596488500000], "landmarkType": "landmark", "descriptionID": 60753, "landmarkNameID": 60798}
14	16	{"_key": 16, "iconID": 2086, "position": [-152929238281250000, 5929108858108.5205, -337768984375000000], "position2d": [-52019062370040950, -484274004105437440], "landmarkType": "landmark", "descriptionID": 60754, "landmarkNameID": 60799}
15	17	{"_key": 17, "iconID": 2089, "position": [-146257285156250000, -8899687528610.229, 306315273437499970], "position2d": [-61606567282900000, 460437640701000000], "landmarkType": "landmark", "descriptionID": 60755, "landmarkNameID": 60800}
16	18	{"_key": 18, "position": [-332093046875000000, 3536401391029.358, -74681669921874990], "position2d": [-308197193641564400, -139913655028284620], "landmarkType": "landmark", "descriptionID": 60756, "landmarkNameID": 60801}
17	19	{"_key": 19, "position": [-640263993187698200, 23199272296997410, 24406428846340290], "position2d": [-337678010335509570, -37543451777804420], "landmarkType": "landmark", "descriptionID": 60757, "landmarkNameID": 60802}
18	20	{"_key": 20, "iconID": 2084, "position": [0.0, 0.0, 0.0], "position2d": [159423466613000000, 57765478013000000], "landmarkType": "landmark", "descriptionID": 60758, "landmarkNameID": 60803}
19	21	{"_key": 21, "position": [-220403867187500000, -3218077719211.578, 144320312500000000], "position2d": [-187239405470000000, 238104923598000000], "landmarkType": "landmark", "descriptionID": 60759, "landmarkNameID": 60804}
20	22	{"_key": 22, "position": [-24209152832031250, 280828960239.8872, -72004936523437496], "position2d": [183717899697000000, -116033158664000000], "landmarkType": "landmark", "descriptionID": 60760, "landmarkNameID": 60805}
21	23	{"_key": 23, "position": [-224672636718749980, 10845973491668.701, -211340605468749980], "position2d": [-116497315648265330, -345229311824016500], "landmarkType": "landmark", "descriptionID": 60761, "landmarkNameID": 60806}
22	24	{"_key": 24, "position": [-240463140649911230, 17248010291093.682, -194030196402565380], "position2d": [-17558830426117040, -411395270332138900], "landmarkType": "landmark", "descriptionID": 60762, "landmarkNameID": 60807}
23	25	{"_key": 25, "position": [-478983422255076540, 39229407488610380, 38954844523750760], "position2d": [-322704762583510460, 106731757072741570], "landmarkType": "landmark", "descriptionID": 60763, "landmarkNameID": 60808}
24	26	{"_key": 26, "iconID": 2077, "position": [19695043945312500, -37010509986.430405, 48958544921875000], "position2d": [220886982235151970, 119149858674155620], "landmarkType": "landmark", "descriptionID": 60764, "landmarkNameID": 60809}
25	27	{"_key": 27, "iconID": 2078, "position": [-8968666578880000.0, -1931296768510000.0, 12455882442100000], "position2d": [187102441113657920, -7428033568198760.0], "landmarkType": "landmark", "descriptionID": 60765, "landmarkNameID": 60810}
26	29	{"_key": 29, "iconID": 2082, "position": [-144283830156000000, 14791787097300000, -20825449358800000], "position2d": [21092510808284116, -53662634640816344], "landmarkType": "landmark", "descriptionID": 60766, "landmarkNameID": 60811}
27	30	{"_key": 30, "iconID": 2070, "position": [-233253181242000000, 77447645254500000, 175038095915000000], "position2d": [-104698597300745340, 290388783722477760], "landmarkType": "landmark", "descriptionID": 60767, "landmarkNameID": 60812}
28	31	{"_key": 31, "iconID": 2085, "position": [-250627818165000000, 88713294501300000, 88252913685600000], "position2d": [-224037162420804770, 165110531034977280], "landmarkType": "landmark", "descriptionID": 60768, "landmarkNameID": 60813}
29	32	{"_key": 32, "iconID": 2088, "position": [-211801036757000000, 76934840455300000, -170806860062000000], "position2d": [-211541447684381950, -173739285456548030], "landmarkType": "landmark", "descriptionID": 60769, "landmarkNameID": 60814}
30	33	{"_key": 33, "iconID": 2073, "position": [-124848162975000000, 68919484073500000, -95540713206600000], "position2d": [14079935786309136, -98258228921188460], "landmarkType": "landmark", "descriptionID": 60770, "landmarkNameID": 60815}
31	34	{"_key": 34, "position": [-77161361552700000, 84780754185000000, 118987926624000000], "position2d": [5819463299486192.0, 201100198286428300], "landmarkType": "landmark", "descriptionID": 60771, "landmarkNameID": 60816}
32	35	{"_key": 35, "position": [-131138457457000000, 50316946491300000, 53833755454700000], "position2d": [44438907057224880, 134776213348123150], "landmarkType": "landmark", "descriptionID": 60772, "landmarkNameID": 60817}
33	36	{"_key": 36, "position": [-156869399693000000, 46040764352000000, 43599461458000000], "position2d": [-91575890179545220, 86439726833372130], "landmarkType": "landmark", "descriptionID": 60773, "landmarkNameID": 60818}
34	37	{"_key": 37, "position": [-239010135074000000, 36747840148200000, -30044403524600000], "position2d": [-203856225492330340, -57229795198869580], "landmarkType": "landmark", "descriptionID": 60774, "landmarkNameID": 60819}
35	38	{"_key": 38, "position": [-44895594885400000, 32880779275900000, -36250328056600000], "locationID": 30000116, "position2d": [129294351967663680, -57867440366883360], "landmarkType": "landmark", "descriptionID": 60775, "landmarkNameID": 60820}
36	39	{"_key": 39, "position": [-52650527276400000, 11963942616400000, -11413548567800000], "locationID": 30002395, "position2d": [153938805072234560, -46654625097371300], "landmarkType": "landmark", "descriptionID": 60776, "landmarkNameID": 60821}
37	40	{"_key": 40, "position": [-1514667562460000.0, 81652960362700000, 175435909068000000], "locationID": 30000309, "position2d": [64228673785254770, 320177009304104960], "landmarkType": "landmark", "descriptionID": 60777, "landmarkNameID": 60822}
38	41	{"_key": 41, "position": [-92208857011400000, 53346199906800000, 424399053475000000], "locationID": 30003618, "position2d": [-57884180454826450, 550129510073524540], "landmarkType": "landmark", "descriptionID": 60778, "landmarkNameID": 60823}
39	42	{"_key": 42, "position": [-81450881881300000, 13207198076100000, -245190231620000000], "locationID": 30001202, "position2d": [-19754825599014164, -356878891206225300], "landmarkType": "landmark", "descriptionID": 60779, "landmarkNameID": 60824}
40	43	{"_key": 43, "position": [-405565219016000000, 65417695269200000, -325671810865000000], "locationID": 30004799, "position2d": [-422487861333696100, -414913732452539500], "landmarkType": "landmark", "descriptionID": 60780, "landmarkNameID": 60825}
41	44	{"_key": 44, "position": [-417903047349000000, 46178469202500000, 33130671307100000], "locationID": 30004558, "position2d": [-494587420104552960, 9751862139933952.0], "landmarkType": "landmark", "descriptionID": 60781, "landmarkNameID": 60826}
42	45	{"_key": 45, "position": [-307524486230000000, 83384943798600000, 176405700933000000], "locationID": 30004065, "position2d": [-353231073860810000, 265756505227320000], "landmarkType": "landmark", "descriptionID": 60782, "landmarkNameID": 60827}
43	46	{"_key": 46, "position": [19330653740000000, -20960381400400000, -364920785955000000], "locationID": 30004421, "position2d": [162105533067000000, -535278617146000000], "landmarkType": "landmark", "descriptionID": 60783, "landmarkNameID": 60828}
44	47	{"_key": 47, "position": [99277128765700000, -13043260308600000, -162926173720000000], "locationID": 30000595, "position2d": [307060389487611460, -282393108990390820], "landmarkType": "landmark", "descriptionID": 60784, "landmarkNameID": 60829}
\.


--
-- Name: landmarks landmarks_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.landmarks
    ADD CONSTRAINT landmarks_pkey PRIMARY KEY (row_no);


--
-- Name: landmarks_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX landmarks_key_idx ON sde_native.landmarks USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 9bN1bgaMh5fcgz3fAEqaZuMYDEI529RtlcVFFRxZJ8R2kyjapYEWGj3rOXitoyU

