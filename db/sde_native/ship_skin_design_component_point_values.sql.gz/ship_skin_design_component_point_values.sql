--
-- PostgreSQL database dump
--

\restrict ODX6xbLlevym161jcozB8cEQHpij2LEon7Dbr3q0Zkj07PeIitM2Z4TQ8cTjmTM

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ship_skin_design_component_point_values; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.ship_skin_design_component_point_values (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: ship_skin_design_component_point_values; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.ship_skin_design_component_point_values (row_no, key, data) FROM stdin;
0	1	{"1": 25, "2": 50, "3": 100, "4": 200, "5": 400, "6": 600, "_key": 1}
1	2	{"1": 75, "2": 150, "3": 250, "4": 350, "5": 500, "6": 750, "_key": 2}
2	3	{"1": 100, "2": 200, "3": 300, "4": 400, "5": 600, "6": 900, "_key": 3}
\.


--
-- Name: ship_skin_design_component_point_values ship_skin_design_component_point_values_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.ship_skin_design_component_point_values
    ADD CONSTRAINT ship_skin_design_component_point_values_pkey PRIMARY KEY (row_no);


--
-- Name: ship_skin_design_component_point_values_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX ship_skin_design_component_point_values_key_idx ON sde_native.ship_skin_design_component_point_values USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict ODX6xbLlevym161jcozB8cEQHpij2LEon7Dbr3q0Zkj07PeIitM2Z4TQ8cTjmTM

