--
-- PostgreSQL database dump
--

\restrict 0fjx1ORMUKkULVIiS4C7en53xqOO7dOM40h4GRy8HGU2hCk2KaFMdFUITdNymUP

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: uiblinks; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.uiblinks (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: uiblinks; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.uiblinks (row_no, key, data) FROM stdin;
0	2	{"_key": 2, "name": "[AIR NPE] - 5.3.2 Wallet Balance: Tab", "blinkType": 1, "description": "Tab: Wallet Balance", "uiElementPath": "PersonalWalletTab_Isk", "secondsTilFadeout": 3}
1	3	{"_key": 3, "name": "[AIR NPE] 5.3.3 Market Transaction: Entry", "blinkType": 1, "description": "Row: Market Transaction Entry", "uiElementPath": "marketTransaction_60771", "secondsTilFadeout": 4}
2	4	{"_key": 4, "name": "[AIR NPE] 5.3.4 - Market Entries: Entry", "blinkType": 1, "description": "Row: Transaction Entry", "uiElementPath": "walletWindow/**/transaction_54", "secondsTilFadeout": 4}
3	7	{"_key": 7, "name": "[AIR NPE] 5.4 - Resource Harvesting", "blinkType": 1, "description": "Resource Harvesting", "uiElementPath": "AgencyWndNew/**/AgencyWndNewTab14"}
4	8	{"_key": 8, "name": "[AIR NPE] 5.3.3 Market Transactions: Tab", "blinkType": 1, "description": "Tab: Market Transactions", "uiElementPath": "IskPanelTab_marketTransactions"}
5	9	{"_key": 9, "name": "[AIR NPE] 5.3.4 - Market Entries: Tab", "blinkType": 1, "description": "Tab: Transactions", "uiElementPath": "IskPanelTab_transactions"}
6	10	{"_key": 10, "name": "[AIR NPE] 5.3.4 - Close window", "blinkType": 1, "description": "Close Wallet button", "uiElementPath": "walletWindow/**/CloseButtonIcon"}
7	11	{"_key": 11, "name": "[AIR NPE] 5.4 Agency blink", "blinkType": 1, "description": "[AIR NPE] 5.4 Agency", "uiElementPath": "Neocom/**/agency"}
8	12	{"_key": 12, "name": "[AIR NPE] Undock", "blinkType": 1, "description": "Undock", "uiElementPath": "lobbyWnd/**/undockButton"}
9	13	{"_key": 13, "name": "[AIR NPE] 4.2 Mining Tab", "blinkType": 1, "description": "Overview Tab Mining", "uiElementPath": "overview/**/OverviewTab_DefaultPreset_639442"}
10	14	{"_key": 14, "name": "[AIR NPE] - Board Corvette", "blinkType": 1, "description": "Board Corvette", "uiElementPath": "corvetteButton"}
11	15	{"_key": 15, "name": "[AIR NPE] Close Skill window", "blinkType": 1, "description": "Close Skill Window button", "uiElementPath": "SkillPlanner/**/DockPanel_HeaderButton_Close"}
12	16	{"_key": 16, "name": "[AIR NPE] Close Inventory Window", "blinkType": 1, "description": "Close Inventory in Station Window", "uiElementPath": "InventoryStation/**/CloseButtonIcon"}
13	19	{"_key": 19, "name": "[AIR NPE] 5.5 - Agency Career Agents", "blinkType": 1, "description": "Destination Set (Career Agents)", "uiElementPath": "AgencyWndNew/**/Agency_CareerAgents_InteractionButton"}
14	20	{"_key": 20, "name": "[AIR NPE] - 2.4 Use Afterburner", "blinkType": 2, "description": "Afterburner", "uiElementPath": "ModuleButton_21857"}
15	21	{"_key": 21, "name": "[AIR NPE] - 2.4 Use Turret Module 1", "blinkType": 2, "description": "Turret Modules", "uiElementPath": "ModuleButton_3634"}
16	22	{"_key": 22, "name": "[AIR NPE] - 2.5 Use Webifier", "blinkType": 2, "description": "Webifier", "uiElementPath": "ModuleButton_30328"}
17	23	{"_key": 23, "name": "[AIR NPE] - 2.6 Use ECM", "blinkType": 2, "description": "ECM", "uiElementPath": "ModuleButton_1957"}
18	24	{"_key": 24, "name": "[AIR NPE] 5.4 - Resource Harvesting (Photon)", "blinkType": 1, "description": "Resource Harvesting (Photon)", "uiElementPath": "AgencyWndNew/**/14"}
19	25	{"_key": 25, "name": "Making Mountains of Molehills (3/10) 3.1.1", "blinkType": 1, "description": "Testing guidance through conversations.", "uiElementPath": "Neocom/**/agency"}
20	26	{"_key": 26, "name": "Making Mountains of Molehills (3/10) 3.1.1b", "blinkType": 1, "description": "Testing guidance through conversations.", "uiElementPath": "Neocom/**/mail"}
21	28	{"_key": 28, "name": "[Guide] Find Asteroid - Ore types Blink", "blinkType": 1, "uiElementPath": "AgencyWndNew/**/oreTypeCombo", "secondsTilFadeout": 5}
22	29	{"_key": 29, "name": "[Guide] Find Asteroid - Mineral Help Blink", "blinkType": 1, "uiElementPath": "AgencyWndNew/**/descriptionIcon", "secondsTilFadeout": 5}
23	30	{"_key": 30, "name": "[Guide] Find Asteroid - System List Blink", "blinkType": 1, "uiElementPath": "AgencyWndNew/**/scrollContainer", "secondsTilFadeout": 5}
24	31	{"_key": 31, "name": "[Guide] Find Asteroid - Asteroid Belts List Blink", "blinkType": 1, "uiElementPath": "AgencyWndNew/**/scrollCont", "secondsTilFadeout": 5}
25	32	{"_key": 32, "name": "[Guide] Find Asteroid - Button Blink", "blinkType": 1, "uiElementPath": "AgencyWndNew/**/DarkStyleStatefulPrimaryButton"}
26	33	{"_key": 33, "name": "[Market Guidance] Neocom Market icon", "blinkType": 1, "uiElementPath": "Neocom/**/market"}
27	34	{"_key": 34, "name": "[Market] Blink Search bar", "blinkType": 1, "uiElementPath": "market/**/searchField"}
28	35	{"_key": 35, "name": "[Market] Blink sell orders container", "blinkType": 1, "uiElementPath": "market/**/buyscroll"}
29	36	{"_key": 36, "name": "[Market] Buy pop-up window quantity", "blinkType": 1, "uiElementPath": "marketbuyaction/**/Quantity", "secondsTilFadeout": 3}
30	38	{"_key": 38, "name": "[NES Intro] 2.3.2 - Drag PLEX in vault", "blinkType": 1, "uiElementPath": "l_main/**/PlexVault"}
31	39	{"_key": 39, "name": "[NES Intro] 2.3.3 - Click Wallet", "blinkType": 1, "uiElementPath": "l_viewstate/**/wallet"}
32	40	{"_key": 40, "name": "[NES Intro] 3.1.1 - Close NES", "blinkType": 1, "uiElementPath": "l_virtual_goods_store/**/exitButton"}
33	41	{"_key": 41, "name": "[NES Intro] 3.3.1 - Open  Fitting Window", "blinkType": 1, "uiElementPath": "l_viewstate/**/fitting"}
34	42	{"_key": 42, "name": "[NES Intro] 3.3.1 - Open Personalization", "blinkType": 1, "uiElementPath": "l_main/**/personalization"}
35	43	{"_key": 43, "name": "[NES Intro] 2.3.2 - Open PLEX Vault", "blinkType": 1, "uiElementPath": "l_main/**/PlexVault"}
36	44	{"_key": 44, "name": "[NES Intro] 2.3.2 -Open Inventory", "blinkType": 1, "uiElementPath": "l_viewstate/**/inventory"}
37	45	{"_key": 45, "name": "[NES Intro] 4.1.1 -Open Inventory", "blinkType": 1, "uiElementPath": "l_main/**/skins"}
\.


--
-- Name: uiblinks uiblinks_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.uiblinks
    ADD CONSTRAINT uiblinks_pkey PRIMARY KEY (row_no);


--
-- Name: uiblinks_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX uiblinks_key_idx ON sde_native.uiblinks USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 0fjx1ORMUKkULVIiS4C7en53xqOO7dOM40h4GRy8HGU2hCk2KaFMdFUITdNymUP

