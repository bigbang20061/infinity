--
-- PostgreSQL database dump
--

\restrict bv66egHKBhI1StP2NnRxwn4hatriNpUR6h8mI3Hlmk7KarSlHfZj7krEmgPguzc

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: npcstructuresettings; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.npcstructuresettings (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: npcstructuresettings; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.npcstructuresettings (row_no, key, data) FROM stdin;
0	78260	{"_key": 78260, "warFactionIdBased": {"19": {"500011": 1.0}}}
1	79172	{"_key": 79172, "warFactionIdBased": {"19": {"500010": 1.0}}}
\.


--
-- Name: npcstructuresettings npcstructuresettings_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.npcstructuresettings
    ADD CONSTRAINT npcstructuresettings_pkey PRIMARY KEY (row_no);


--
-- Name: npcstructuresettings_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX npcstructuresettings_key_idx ON sde_native.npcstructuresettings USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict bv66egHKBhI1StP2NnRxwn4hatriNpUR6h8mI3Hlmk7KarSlHfZj7krEmgPguzc

