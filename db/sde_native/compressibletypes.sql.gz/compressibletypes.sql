--
-- PostgreSQL database dump
--

\restrict yvEcNQznt5ym2QyaLAcgVyGtACsDULrLnApz2SDaPRiDgxJJWtOwLmA7gZefAV1

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: compressibletypes; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.compressibletypes (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: compressibletypes; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.compressibletypes (row_no, key, data) FROM stdin;
0	18	{"_key": 18, "value": 62528}
1	19	{"_key": 19, "value": 62572}
2	20	{"_key": 20, "value": 62536}
3	21	{"_key": 21, "value": 62548}
4	22	{"_key": 22, "value": 62568}
5	1223	{"_key": 1223, "value": 62564}
6	1224	{"_key": 1224, "value": 62524}
7	1225	{"_key": 1225, "value": 62560}
8	1226	{"_key": 1226, "value": 62540}
9	1227	{"_key": 1227, "value": 62532}
10	1228	{"_key": 1228, "value": 62520}
11	1229	{"_key": 1229, "value": 62552}
12	1230	{"_key": 1230, "value": 62516}
13	1231	{"_key": 1231, "value": 62544}
14	1232	{"_key": 1232, "value": 62556}
15	11396	{"_key": 11396, "value": 62586}
16	16262	{"_key": 16262, "value": 28434}
17	16263	{"_key": 16263, "value": 28438}
18	16264	{"_key": 16264, "value": 28433}
19	16265	{"_key": 16265, "value": 28444}
20	16266	{"_key": 16266, "value": 28439}
21	16267	{"_key": 16267, "value": 28435}
22	16268	{"_key": 16268, "value": 28437}
23	16269	{"_key": 16269, "value": 28440}
24	17425	{"_key": 17425, "value": 62569}
25	17426	{"_key": 17426, "value": 62570}
26	17428	{"_key": 17428, "value": 62565}
27	17429	{"_key": 17429, "value": 62566}
28	17432	{"_key": 17432, "value": 62561}
29	17433	{"_key": 17433, "value": 62562}
30	17436	{"_key": 17436, "value": 62557}
31	17437	{"_key": 17437, "value": 62558}
32	17440	{"_key": 17440, "value": 62549}
33	17441	{"_key": 17441, "value": 62550}
34	17444	{"_key": 17444, "value": 62545}
35	17445	{"_key": 17445, "value": 62546}
36	17448	{"_key": 17448, "value": 62541}
37	17449	{"_key": 17449, "value": 62542}
38	17452	{"_key": 17452, "value": 62537}
39	17453	{"_key": 17453, "value": 62538}
40	17455	{"_key": 17455, "value": 62529}
41	17456	{"_key": 17456, "value": 62530}
42	17459	{"_key": 17459, "value": 62525}
43	17460	{"_key": 17460, "value": 62526}
44	17463	{"_key": 17463, "value": 62521}
45	17464	{"_key": 17464, "value": 62522}
46	17466	{"_key": 17466, "value": 62573}
47	17467	{"_key": 17467, "value": 62574}
48	17470	{"_key": 17470, "value": 62517}
49	17471	{"_key": 17471, "value": 62518}
50	17865	{"_key": 17865, "value": 62553}
51	17866	{"_key": 17866, "value": 62554}
52	17867	{"_key": 17867, "value": 62533}
53	17868	{"_key": 17868, "value": 62534}
54	17869	{"_key": 17869, "value": 62587}
55	17870	{"_key": 17870, "value": 62588}
56	17975	{"_key": 17975, "value": 28443}
57	17976	{"_key": 17976, "value": 28441}
58	17977	{"_key": 17977, "value": 28442}
59	17978	{"_key": 17978, "value": 28436}
60	25268	{"_key": 25268, "value": 62396}
61	25273	{"_key": 25273, "value": 62390}
62	25274	{"_key": 25274, "value": 62394}
63	25275	{"_key": 25275, "value": 62387}
64	25276	{"_key": 25276, "value": 62392}
65	25277	{"_key": 25277, "value": 62391}
66	25278	{"_key": 25278, "value": 62393}
67	25279	{"_key": 25279, "value": 62386}
68	28694	{"_key": 28694, "value": 62377}
69	28695	{"_key": 28695, "value": 62379}
70	28696	{"_key": 28696, "value": 62380}
71	28697	{"_key": 28697, "value": 62381}
72	28698	{"_key": 28698, "value": 62382}
73	28699	{"_key": 28699, "value": 62383}
74	28700	{"_key": 28700, "value": 62384}
75	28701	{"_key": 28701, "value": 62385}
76	30370	{"_key": 30370, "value": 62399}
77	30371	{"_key": 30371, "value": 62397}
78	30372	{"_key": 30372, "value": 62398}
79	30373	{"_key": 30373, "value": 62403}
80	30374	{"_key": 30374, "value": 62400}
81	30375	{"_key": 30375, "value": 62402}
82	30376	{"_key": 30376, "value": 62404}
83	30377	{"_key": 30377, "value": 62406}
84	30378	{"_key": 30378, "value": 62405}
85	45490	{"_key": 45490, "value": 62463}
86	45491	{"_key": 45491, "value": 62460}
87	45492	{"_key": 45492, "value": 62454}
88	45493	{"_key": 45493, "value": 62457}
89	45494	{"_key": 45494, "value": 62474}
90	45495	{"_key": 45495, "value": 62471}
91	45496	{"_key": 45496, "value": 62477}
92	45497	{"_key": 45497, "value": 62468}
93	45498	{"_key": 45498, "value": 62483}
94	45499	{"_key": 45499, "value": 62486}
95	45500	{"_key": 45500, "value": 62489}
96	45501	{"_key": 45501, "value": 62480}
97	45502	{"_key": 45502, "value": 62492}
98	45503	{"_key": 45503, "value": 62501}
99	45504	{"_key": 45504, "value": 62498}
100	45506	{"_key": 45506, "value": 62495}
101	45510	{"_key": 45510, "value": 62510}
102	45511	{"_key": 45511, "value": 62507}
103	45512	{"_key": 45512, "value": 62504}
104	45513	{"_key": 45513, "value": 62513}
105	46280	{"_key": 46280, "value": 62464}
106	46281	{"_key": 46281, "value": 62467}
107	46282	{"_key": 46282, "value": 62461}
108	46283	{"_key": 46283, "value": 62466}
109	46284	{"_key": 46284, "value": 62455}
110	46285	{"_key": 46285, "value": 62456}
111	46286	{"_key": 46286, "value": 62458}
112	46287	{"_key": 46287, "value": 62459}
113	46288	{"_key": 46288, "value": 62475}
114	46289	{"_key": 46289, "value": 62476}
115	46290	{"_key": 46290, "value": 62472}
116	46291	{"_key": 46291, "value": 62473}
117	46292	{"_key": 46292, "value": 62478}
118	46293	{"_key": 46293, "value": 62479}
119	46294	{"_key": 46294, "value": 62469}
120	46295	{"_key": 46295, "value": 62470}
121	46296	{"_key": 46296, "value": 62484}
122	46297	{"_key": 46297, "value": 62485}
123	46298	{"_key": 46298, "value": 62487}
124	46299	{"_key": 46299, "value": 62488}
125	46300	{"_key": 46300, "value": 62490}
126	46301	{"_key": 46301, "value": 62491}
127	46302	{"_key": 46302, "value": 62481}
128	46303	{"_key": 46303, "value": 62482}
129	46304	{"_key": 46304, "value": 62493}
130	46305	{"_key": 46305, "value": 62494}
131	46306	{"_key": 46306, "value": 62502}
132	46307	{"_key": 46307, "value": 62503}
133	46308	{"_key": 46308, "value": 62499}
134	46309	{"_key": 46309, "value": 62500}
135	46310	{"_key": 46310, "value": 62496}
136	46311	{"_key": 46311, "value": 62497}
137	46312	{"_key": 46312, "value": 62511}
138	46313	{"_key": 46313, "value": 62512}
139	46314	{"_key": 46314, "value": 62508}
140	46315	{"_key": 46315, "value": 62509}
141	46316	{"_key": 46316, "value": 62505}
142	46317	{"_key": 46317, "value": 62506}
143	46318	{"_key": 46318, "value": 62514}
144	46319	{"_key": 46319, "value": 62515}
145	46675	{"_key": 46675, "value": 62559}
146	46676	{"_key": 46676, "value": 62567}
147	46677	{"_key": 46677, "value": 62563}
148	46678	{"_key": 46678, "value": 62571}
149	46679	{"_key": 46679, "value": 62555}
150	46680	{"_key": 46680, "value": 62551}
151	46681	{"_key": 46681, "value": 62547}
152	46682	{"_key": 46682, "value": 62543}
153	46683	{"_key": 46683, "value": 62539}
154	46684	{"_key": 46684, "value": 62535}
155	46685	{"_key": 46685, "value": 62531}
156	46686	{"_key": 46686, "value": 62527}
157	46687	{"_key": 46687, "value": 62523}
158	46688	{"_key": 46688, "value": 62575}
159	46689	{"_key": 46689, "value": 62519}
160	52306	{"_key": 52306, "value": 62582}
161	52315	{"_key": 52315, "value": 62579}
162	52316	{"_key": 52316, "value": 62576}
163	56625	{"_key": 56625, "value": 62583}
164	56626	{"_key": 56626, "value": 62584}
165	56627	{"_key": 56627, "value": 62577}
166	56628	{"_key": 56628, "value": 62578}
167	56629	{"_key": 56629, "value": 62580}
168	56630	{"_key": 56630, "value": 62581}
169	74521	{"_key": 74521, "value": 75275}
170	74522	{"_key": 74522, "value": 75276}
171	74523	{"_key": 74523, "value": 75277}
172	74524	{"_key": 74524, "value": 75278}
173	74525	{"_key": 74525, "value": 75279}
174	74526	{"_key": 74526, "value": 75280}
175	74527	{"_key": 74527, "value": 75281}
176	74528	{"_key": 74528, "value": 75282}
177	74529	{"_key": 74529, "value": 75283}
178	74530	{"_key": 74530, "value": 75284}
179	74531	{"_key": 74531, "value": 75285}
180	74532	{"_key": 74532, "value": 75286}
181	74533	{"_key": 74533, "value": 75287}
182	74534	{"_key": 74534, "value": 75288}
183	74535	{"_key": 74535, "value": 75289}
184	74536	{"_key": 74536, "value": 75290}
185	81900	{"_key": 81900, "value": 82300}
186	81901	{"_key": 81901, "value": 82301}
187	81902	{"_key": 81902, "value": 82302}
188	81903	{"_key": 81903, "value": 82303}
189	81975	{"_key": 81975, "value": 82316}
190	81976	{"_key": 81976, "value": 82317}
191	81977	{"_key": 81977, "value": 82318}
192	81978	{"_key": 81978, "value": 82319}
193	82016	{"_key": 82016, "value": 82304}
194	82017	{"_key": 82017, "value": 82305}
195	82018	{"_key": 82018, "value": 82306}
196	82019	{"_key": 82019, "value": 82307}
197	82163	{"_key": 82163, "value": 82312}
198	82164	{"_key": 82164, "value": 82313}
199	82165	{"_key": 82165, "value": 82314}
200	82166	{"_key": 82166, "value": 82315}
201	82205	{"_key": 82205, "value": 82308}
202	82206	{"_key": 82206, "value": 82309}
203	82207	{"_key": 82207, "value": 82310}
204	82208	{"_key": 82208, "value": 82311}
205	90041	{"_key": 90041, "value": 90307}
206	92371	{"_key": 92371, "value": 92372}
207	92373	{"_key": 92373, "value": 92374}
208	92565	{"_key": 92565, "value": 92818}
209	92566	{"_key": 92566, "value": 92819}
210	92567	{"_key": 92567, "value": 92820}
211	92568	{"_key": 92568, "value": 92821}
\.


--
-- Name: compressibletypes compressibletypes_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.compressibletypes
    ADD CONSTRAINT compressibletypes_pkey PRIMARY KEY (row_no);


--
-- Name: compressibletypes_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX compressibletypes_key_idx ON sde_native.compressibletypes USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict yvEcNQznt5ym2QyaLAcgVyGtACsDULrLnApz2SDaPRiDgxJJWtOwLmA7gZefAV1

