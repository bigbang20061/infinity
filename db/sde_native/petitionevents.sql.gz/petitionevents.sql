--
-- PostgreSQL database dump
--

\restrict VdqFzMYvJytmqwLegiYl7XgTg5528S4FgWyyRVJgnjnFubT41phMQXNA7iuHSov

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: petitionevents; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.petitionevents (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: petitionevents; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.petitionevents (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "eventText": "Created", "eventTextID": 62191}
1	2	{"_key": 2, "eventText": "Cancelled by player", "eventTextID": 62192}
2	3	{"_key": 3, "eventText": "Deleted", "eventTextID": 62193}
3	4	{"_key": 4, "eventText": "Claimed", "eventTextID": 62194}
4	5	{"_key": 5, "eventText": "Unclaimed", "eventTextID": 62195}
5	6	{"_key": 6, "eventText": "Escalated", "eventTextID": 62196}
6	7	{"_key": 7, "eventText": "Closed", "eventTextID": 62197}
7	8	{"_key": 8, "eventText": "Transfered", "eventTextID": 62198}
8	9	{"_key": 9, "eventText": "Auto escalated", "eventTextID": 62199}
9	10	{"_key": 10, "eventText": "Released", "eventTextID": 62200}
10	11	{"_key": 11, "eventText": "Unclaimed on timeout", "eventTextID": 62201}
11	12	{"_key": 12, "eventText": "Attached to characterID", "eventTextID": 62202}
12	13	{"_key": 13, "eventText": "Assigned to", "eventTextID": 62203}
13	14	{"_key": 14, "eventText": "Pulled", "eventTextID": 62204}
14	15	{"_key": 15, "eventText": "Reply Sent", "eventTextID": 62205}
15	16	{"_key": 16, "eventText": "Reply Sent to e-mail", "eventTextID": 62206}
16	17	{"_key": 17, "eventText": "Attachment added", "eventTextID": 62207}
17	18	{"_key": 18, "eventText": "Status set to Updated", "eventTextID": 62208}
18	19	{"_key": 19, "eventText": "Status set to Waiting", "eventTextID": 62209}
19	20	{"_key": 20, "eventText": "Flag as bug"}
20	21	{"_key": 21, "eventText": "Unflag as bug"}
\.


--
-- Name: petitionevents petitionevents_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.petitionevents
    ADD CONSTRAINT petitionevents_pkey PRIMARY KEY (row_no);


--
-- Name: petitionevents_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX petitionevents_key_idx ON sde_native.petitionevents USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict VdqFzMYvJytmqwLegiYl7XgTg5528S4FgWyyRVJgnjnFubT41phMQXNA7iuHSov

