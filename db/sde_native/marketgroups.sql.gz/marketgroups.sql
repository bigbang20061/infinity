--
-- PostgreSQL database dump
--

\restrict nJaXDBG2PrALi4VwwVNkhzTFPXcpbtLROvQ49ujAn9vhEe4agAsv1LWAxKnNOMM

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: marketgroups; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.marketgroups (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: marketgroups; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.marketgroups (row_no, key, data) FROM stdin;
0	2	{"_key": 2, "iconID": 2703, "nameID": 65524, "hasTypes": 0, "descriptionID": 64450}
1	4	{"_key": 4, "iconID": 1443, "nameID": 65525, "hasTypes": 0, "descriptionID": 64451}
2	5	{"_key": 5, "iconID": 1443, "nameID": 66319, "hasTypes": 0, "descriptionID": 65245, "parentGroupID": 1361}
3	6	{"_key": 6, "iconID": 1443, "nameID": 66324, "hasTypes": 0, "descriptionID": 65250, "parentGroupID": 1367}
4	7	{"_key": 7, "iconID": 1443, "nameID": 66332, "hasTypes": 0, "descriptionID": 65258, "parentGroupID": 1376}
5	8	{"_key": 8, "iconID": 1443, "nameID": 66341, "hasTypes": 0, "descriptionID": 65267, "parentGroupID": 1382}
6	9	{"_key": 9, "iconID": 1432, "nameID": 65526, "hasTypes": 0, "descriptionID": 64452}
7	10	{"_key": 10, "iconID": 365, "nameID": 65527, "hasTypes": 0, "descriptionID": 64453, "parentGroupID": 9}
8	11	{"_key": 11, "iconID": 1299, "nameID": 65528, "hasTypes": 0, "descriptionID": 64454}
9	14	{"_key": 14, "iconID": 68, "nameID": 65529, "hasTypes": 0, "descriptionID": 64455, "parentGroupID": 9}
10	19	{"_key": 19, "iconID": 2340, "nameID": 65531, "hasTypes": 0, "descriptionID": 64457}
11	20	{"_key": 20, "iconID": 1192, "nameID": 65532, "hasTypes": 1, "descriptionID": 64458, "parentGroupID": 19}
12	22	{"_key": 22, "iconID": 29, "nameID": 65533, "hasTypes": 1, "descriptionID": 64459, "parentGroupID": 19}
13	23	{"_key": 23, "iconID": 2543, "nameID": 65534, "hasTypes": 1, "descriptionID": 64460, "parentGroupID": 19}
14	24	{"_key": 24, "iconID": 2563, "nameID": 65535, "hasTypes": 0, "descriptionID": 64461}
15	27	{"_key": 27, "iconID": 2062, "nameID": 65536, "hasTypes": 0, "descriptionID": 64462, "parentGroupID": 24}
16	52	{"_key": 52, "iconID": 72, "nameID": 65537, "hasTypes": 0, "descriptionID": 64463, "parentGroupID": 9}
17	54	{"_key": 54, "iconID": 1277, "nameID": 65538, "hasTypes": 0, "descriptionID": 64464, "parentGroupID": 1031}
18	61	{"_key": 61, "iconID": 20966, "nameID": 65539, "hasTypes": 1, "descriptionID": 64465, "parentGroupID": 5}
19	64	{"_key": 64, "iconID": 20968, "nameID": 65540, "hasTypes": 1, "descriptionID": 64466, "parentGroupID": 5}
20	65	{"_key": 65, "iconID": 2199, "nameID": 65541, "hasTypes": 0, "descriptionID": 64467, "parentGroupID": 1035}
21	72	{"_key": 72, "iconID": 20959, "nameID": 65542, "hasTypes": 1, "descriptionID": 64468, "parentGroupID": 5}
22	73	{"_key": 73, "iconID": 20968, "nameID": 65543, "hasTypes": 1, "descriptionID": 64469, "parentGroupID": 6}
23	74	{"_key": 74, "iconID": 20959, "nameID": 65544, "hasTypes": 1, "descriptionID": 64470, "parentGroupID": 6}
24	75	{"_key": 75, "iconID": 20966, "nameID": 65545, "hasTypes": 1, "descriptionID": 64471, "parentGroupID": 6}
25	76	{"_key": 76, "iconID": 20967, "nameID": 65546, "hasTypes": 1, "descriptionID": 64472, "parentGroupID": 6}
26	77	{"_key": 77, "iconID": 20967, "nameID": 65547, "hasTypes": 1, "descriptionID": 64473, "parentGroupID": 5}
27	78	{"_key": 78, "iconID": 20968, "nameID": 65548, "hasTypes": 1, "descriptionID": 64474, "parentGroupID": 7}
28	79	{"_key": 79, "iconID": 20959, "nameID": 65549, "hasTypes": 1, "descriptionID": 64475, "parentGroupID": 7}
29	80	{"_key": 80, "iconID": 20966, "nameID": 65550, "hasTypes": 1, "descriptionID": 64476, "parentGroupID": 7}
30	81	{"_key": 81, "iconID": 20967, "nameID": 65551, "hasTypes": 1, "descriptionID": 64477, "parentGroupID": 7}
31	82	{"_key": 82, "iconID": 20968, "nameID": 65552, "hasTypes": 1, "descriptionID": 64478, "parentGroupID": 8}
32	83	{"_key": 83, "iconID": 20967, "nameID": 65553, "hasTypes": 1, "descriptionID": 64479, "parentGroupID": 8}
33	84	{"_key": 84, "iconID": 20966, "nameID": 65554, "hasTypes": 1, "descriptionID": 64480, "parentGroupID": 8}
34	85	{"_key": 85, "iconID": 20959, "nameID": 65555, "hasTypes": 1, "descriptionID": 64481, "parentGroupID": 8}
35	86	{"_key": 86, "iconID": 376, "nameID": 65556, "hasTypes": 0, "descriptionID": 64482, "parentGroupID": 10}
36	87	{"_key": 87, "iconID": 387, "nameID": 65557, "hasTypes": 0, "descriptionID": 64483, "parentGroupID": 10}
37	88	{"_key": 88, "iconID": 352, "nameID": 65558, "hasTypes": 0, "descriptionID": 64484, "parentGroupID": 10}
38	99	{"_key": 99, "iconID": 1004, "nameID": 65559, "hasTypes": 0, "descriptionID": 64485, "parentGroupID": 11}
39	100	{"_key": 100, "iconID": 1047, "nameID": 65560, "hasTypes": 0, "descriptionID": 64486, "parentGroupID": 11}
40	101	{"_key": 101, "iconID": 1131, "nameID": 65561, "hasTypes": 0, "descriptionID": 64487, "parentGroupID": 11}
41	102	{"_key": 102, "iconID": 1142, "nameID": 65562, "hasTypes": 1, "descriptionID": 64488, "parentGroupID": 851}
42	103	{"_key": 103, "iconID": 1142, "nameID": 65563, "hasTypes": 1, "descriptionID": 64489, "parentGroupID": 851}
43	105	{"_key": 105, "iconID": 1142, "nameID": 65564, "hasTypes": 1, "descriptionID": 64490, "parentGroupID": 851}
44	106	{"_key": 106, "iconID": 1047, "nameID": 65565, "hasTypes": 1, "descriptionID": 64491, "parentGroupID": 848}
45	107	{"_key": 107, "iconID": 1047, "nameID": 65566, "hasTypes": 1, "descriptionID": 64492, "parentGroupID": 848}
46	108	{"_key": 108, "iconID": 1047, "nameID": 65567, "hasTypes": 1, "descriptionID": 64493, "parentGroupID": 848}
47	109	{"_key": 109, "iconID": 1004, "nameID": 65568, "hasTypes": 1, "descriptionID": 64494, "parentGroupID": 845}
48	112	{"_key": 112, "iconID": 1004, "nameID": 65569, "hasTypes": 1, "descriptionID": 64495, "parentGroupID": 845}
49	113	{"_key": 113, "iconID": 1004, "nameID": 65570, "hasTypes": 1, "descriptionID": 64496, "parentGroupID": 845}
50	114	{"_key": 114, "iconID": 1334, "nameID": 65571, "hasTypes": 0, "descriptionID": 64497, "parentGroupID": 11}
51	115	{"_key": 115, "iconID": 1335, "nameID": 65572, "hasTypes": 0, "descriptionID": 64498, "parentGroupID": 114}
52	116	{"_key": 116, "iconID": 192, "nameID": 65573, "hasTypes": 1, "descriptionID": 64499, "parentGroupID": 114}
53	117	{"_key": 117, "iconID": 192, "nameID": 65574, "hasTypes": 0, "descriptionID": 64500, "parentGroupID": 114}
54	118	{"_key": 118, "iconID": 1352, "nameID": 65575, "hasTypes": 0, "descriptionID": 64501, "parentGroupID": 114}
55	120	{"_key": 120, "iconID": 1723, "nameID": 66272, "hasTypes": 0, "descriptionID": 65198, "parentGroupID": 11}
56	126	{"_key": 126, "iconID": 26451, "nameID": 65576, "hasTypes": 1, "descriptionID": 64502, "parentGroupID": 554}
57	128	{"_key": 128, "iconID": 86, "nameID": 65577, "hasTypes": 0, "descriptionID": 64503, "parentGroupID": 554}
58	131	{"_key": 131, "iconID": 10149, "nameID": 65578, "hasTypes": 1, "descriptionID": 64504, "parentGroupID": 52}
59	132	{"_key": 132, "iconID": 97, "nameID": 65579, "hasTypes": 0, "descriptionID": 64505, "parentGroupID": 52}
60	133	{"_key": 133, "iconID": 79, "nameID": 65580, "hasTypes": 0, "descriptionID": 64506, "parentGroupID": 14}
61	134	{"_key": 134, "iconID": 80, "nameID": 65581, "hasTypes": 0, "descriptionID": 64507, "parentGroupID": 14}
62	135	{"_key": 135, "iconID": 92, "nameID": 66271, "hasTypes": 0, "descriptionID": 65197, "parentGroupID": 14}
63	139	{"_key": 139, "iconID": 1033, "nameID": 65583, "hasTypes": 1, "descriptionID": 64509, "parentGroupID": 11}
64	140	{"_key": 140, "iconID": 168, "nameID": 65584, "hasTypes": 0, "descriptionID": 64510, "parentGroupID": 10}
65	141	{"_key": 141, "iconID": 112, "nameID": 65585, "hasTypes": 0, "descriptionID": 64511, "parentGroupID": 9}
66	143	{"_key": 143, "iconID": 21440, "nameID": 65586, "hasTypes": 0, "descriptionID": 64512, "parentGroupID": 10}
67	150	{"_key": 150, "iconID": 33, "nameID": 65587, "hasTypes": 0, "descriptionID": 64513}
68	157	{"_key": 157, "iconID": 1084, "nameID": 65588, "hasTypes": 0, "descriptionID": 64514}
69	158	{"_key": 158, "iconID": 1084, "nameID": 65589, "hasTypes": 1, "descriptionID": 64515, "parentGroupID": 157}
70	159	{"_key": 159, "iconID": 1084, "nameID": 65590, "hasTypes": 0, "descriptionID": 64516, "parentGroupID": 157}
71	204	{"_key": 204, "iconID": 2703, "nameID": 65591, "hasTypes": 0, "descriptionID": 64517, "parentGroupID": 2}
72	205	{"_key": 205, "iconID": 2703, "nameID": 65592, "hasTypes": 0, "descriptionID": 64518, "parentGroupID": 204}
73	206	{"_key": 206, "iconID": 2703, "nameID": 65593, "hasTypes": 0, "descriptionID": 64519, "parentGroupID": 204}
74	207	{"_key": 207, "iconID": 2703, "nameID": 65594, "hasTypes": 0, "descriptionID": 64520, "parentGroupID": 204}
75	208	{"_key": 208, "iconID": 2703, "nameID": 65595, "hasTypes": 0, "descriptionID": 64521, "parentGroupID": 204}
76	209	{"_key": 209, "iconID": 2703, "nameID": 65596, "hasTypes": 0, "descriptionID": 64522, "parentGroupID": 2}
77	210	{"_key": 210, "iconID": 2703, "nameID": 65597, "hasTypes": 0, "descriptionID": 64523, "parentGroupID": 209}
78	211	{"_key": 211, "iconID": 2703, "nameID": 65598, "hasTypes": 0, "descriptionID": 64524, "parentGroupID": 2}
79	214	{"_key": 214, "iconID": 2703, "nameID": 65601, "hasTypes": 0, "descriptionID": 64527, "parentGroupID": 209}
80	252	{"_key": 252, "iconID": 2703, "nameID": 65602, "hasTypes": 0, "descriptionID": 64528, "parentGroupID": 209}
81	261	{"_key": 261, "iconID": 2703, "nameID": 65603, "hasTypes": 1, "descriptionID": 64529, "parentGroupID": 205}
82	264	{"_key": 264, "iconID": 2703, "nameID": 65604, "hasTypes": 1, "descriptionID": 64530, "parentGroupID": 205}
83	272	{"_key": 272, "iconID": 2703, "nameID": 65605, "hasTypes": 1, "descriptionID": 64531, "parentGroupID": 205}
84	273	{"_key": 273, "iconID": 2703, "nameID": 65606, "hasTypes": 1, "descriptionID": 64532, "parentGroupID": 206}
85	274	{"_key": 274, "iconID": 2703, "nameID": 65607, "hasTypes": 1, "descriptionID": 64533, "parentGroupID": 206}
86	275	{"_key": 275, "iconID": 2703, "nameID": 65608, "hasTypes": 1, "descriptionID": 64534, "parentGroupID": 206}
87	276	{"_key": 276, "iconID": 2703, "nameID": 65609, "hasTypes": 1, "descriptionID": 64535, "parentGroupID": 206}
88	277	{"_key": 277, "iconID": 2703, "nameID": 65610, "hasTypes": 1, "descriptionID": 64536, "parentGroupID": 205}
89	278	{"_key": 278, "iconID": 2703, "nameID": 65611, "hasTypes": 1, "descriptionID": 64537, "parentGroupID": 207}
90	279	{"_key": 279, "iconID": 2703, "nameID": 65612, "hasTypes": 1, "descriptionID": 64538, "parentGroupID": 207}
91	280	{"_key": 280, "iconID": 2703, "nameID": 65613, "hasTypes": 1, "descriptionID": 64539, "parentGroupID": 207}
92	281	{"_key": 281, "iconID": 2703, "nameID": 65614, "hasTypes": 1, "descriptionID": 64540, "parentGroupID": 207}
93	282	{"_key": 282, "iconID": 2703, "nameID": 65615, "hasTypes": 1, "descriptionID": 64541, "parentGroupID": 208}
94	283	{"_key": 283, "iconID": 2703, "nameID": 65616, "hasTypes": 1, "descriptionID": 64542, "parentGroupID": 208}
95	284	{"_key": 284, "iconID": 2703, "nameID": 65617, "hasTypes": 1, "descriptionID": 64543, "parentGroupID": 208}
96	285	{"_key": 285, "iconID": 2703, "nameID": 65618, "hasTypes": 1, "descriptionID": 64544, "parentGroupID": 208}
97	286	{"_key": 286, "iconID": 2703, "nameID": 65619, "hasTypes": 0, "descriptionID": 64545, "parentGroupID": 210}
98	287	{"_key": 287, "iconID": 2703, "nameID": 65620, "hasTypes": 0, "descriptionID": 64546, "parentGroupID": 210}
99	288	{"_key": 288, "iconID": 2703, "nameID": 65621, "hasTypes": 0, "descriptionID": 64547, "parentGroupID": 210}
100	289	{"_key": 289, "iconID": 2703, "nameID": 65622, "hasTypes": 1, "descriptionID": 64548, "parentGroupID": 286}
101	290	{"_key": 290, "iconID": 2703, "nameID": 65623, "hasTypes": 1, "descriptionID": 64549, "parentGroupID": 286}
102	291	{"_key": 291, "iconID": 2703, "nameID": 65624, "hasTypes": 1, "descriptionID": 64550, "parentGroupID": 286}
103	292	{"_key": 292, "iconID": 2703, "nameID": 65625, "hasTypes": 1, "descriptionID": 64551, "parentGroupID": 288}
104	293	{"_key": 293, "iconID": 2703, "nameID": 65626, "hasTypes": 1, "descriptionID": 64552, "parentGroupID": 288}
105	295	{"_key": 295, "iconID": 2703, "nameID": 65627, "hasTypes": 1, "descriptionID": 64553, "parentGroupID": 288}
106	296	{"_key": 296, "iconID": 2703, "nameID": 65628, "hasTypes": 1, "descriptionID": 64554, "parentGroupID": 287}
107	297	{"_key": 297, "iconID": 2703, "nameID": 65629, "hasTypes": 1, "descriptionID": 64555, "parentGroupID": 287}
108	298	{"_key": 298, "iconID": 2703, "nameID": 65630, "hasTypes": 1, "descriptionID": 64556, "parentGroupID": 287}
109	299	{"_key": 299, "iconID": 2703, "nameID": 65631, "hasTypes": 0, "descriptionID": 64557, "parentGroupID": 211}
110	300	{"_key": 300, "iconID": 2703, "nameID": 65632, "hasTypes": 0, "descriptionID": 64558, "parentGroupID": 211}
111	301	{"_key": 301, "iconID": 2703, "nameID": 65633, "hasTypes": 0, "descriptionID": 64559, "parentGroupID": 211}
112	302	{"_key": 302, "iconID": 2703, "nameID": 65634, "hasTypes": 1, "descriptionID": 64560, "parentGroupID": 301}
113	303	{"_key": 303, "iconID": 2703, "nameID": 65635, "hasTypes": 1, "descriptionID": 64561, "parentGroupID": 301}
114	305	{"_key": 305, "iconID": 2703, "nameID": 65636, "hasTypes": 1, "descriptionID": 64562, "parentGroupID": 301}
115	306	{"_key": 306, "iconID": 2703, "nameID": 65637, "hasTypes": 1, "descriptionID": 64563, "parentGroupID": 300}
116	307	{"_key": 307, "iconID": 2703, "nameID": 65638, "hasTypes": 1, "descriptionID": 64564, "parentGroupID": 300}
117	308	{"_key": 308, "iconID": 2703, "nameID": 65639, "hasTypes": 1, "descriptionID": 64565, "parentGroupID": 300}
118	309	{"_key": 309, "iconID": 2703, "nameID": 65640, "hasTypes": 1, "descriptionID": 64566, "parentGroupID": 299}
119	312	{"_key": 312, "iconID": 2703, "nameID": 65641, "hasTypes": 1, "descriptionID": 64567, "parentGroupID": 299}
120	313	{"_key": 313, "iconID": 2703, "nameID": 65642, "hasTypes": 1, "descriptionID": 64568, "parentGroupID": 299}
121	314	{"_key": 314, "iconID": 2703, "nameID": 65643, "hasTypes": 0, "descriptionID": 64569, "parentGroupID": 211}
122	315	{"_key": 315, "iconID": 2703, "nameID": 65644, "hasTypes": 1, "descriptionID": 64570, "parentGroupID": 314}
123	316	{"_key": 316, "iconID": 2703, "nameID": 65645, "hasTypes": 1, "descriptionID": 64571, "parentGroupID": 314}
124	318	{"_key": 318, "iconID": 2703, "nameID": 65647, "hasTypes": 1, "descriptionID": 64573, "parentGroupID": 314}
125	320	{"_key": 320, "iconID": 2703, "nameID": 65648, "hasTypes": 1, "descriptionID": 64574, "parentGroupID": 1520}
126	325	{"_key": 325, "iconID": 2703, "nameID": 65652, "hasTypes": 1, "descriptionID": 64578, "parentGroupID": 1710}
127	331	{"_key": 331, "iconID": 2703, "nameID": 65656, "hasTypes": 1, "descriptionID": 64582, "parentGroupID": 252}
128	332	{"_key": 332, "iconID": 2703, "nameID": 65657, "hasTypes": 1, "descriptionID": 64583, "parentGroupID": 252}
129	335	{"_key": 335, "iconID": 2703, "nameID": 65660, "hasTypes": 1, "descriptionID": 64586, "parentGroupID": 214}
130	338	{"_key": 338, "iconID": 2703, "nameID": 65661, "hasTypes": 1, "descriptionID": 64587, "parentGroupID": 1711}
131	339	{"_key": 339, "iconID": 2703, "nameID": 65662, "hasTypes": 1, "descriptionID": 64588, "parentGroupID": 211}
132	340	{"_key": 340, "iconID": 2703, "nameID": 65663, "hasTypes": 1, "descriptionID": 64589, "parentGroupID": 210}
133	341	{"_key": 341, "iconID": 2703, "nameID": 65664, "hasTypes": 1, "descriptionID": 64590, "parentGroupID": 209}
134	343	{"_key": 343, "iconID": 2703, "nameID": 65665, "hasTypes": 1, "descriptionID": 64591, "parentGroupID": 210}
135	357	{"_key": 357, "iconID": 2703, "nameID": 65666, "hasTypes": 0, "descriptionID": 64592, "parentGroupID": 2}
136	358	{"_key": 358, "iconID": 2703, "nameID": 65667, "hasTypes": 1, "descriptionID": 64593, "parentGroupID": 357}
137	359	{"_key": 359, "iconID": 2703, "nameID": 65668, "hasTypes": 1, "descriptionID": 64594, "parentGroupID": 1530}
138	364	{"_key": 364, "iconID": 33, "nameID": 65670, "hasTypes": 1, "descriptionID": 64596, "parentGroupID": 150}
139	365	{"_key": 365, "iconID": 33, "nameID": 65671, "hasTypes": 1, "descriptionID": 64597, "parentGroupID": 150}
140	366	{"_key": 366, "iconID": 33, "nameID": 65672, "hasTypes": 1, "descriptionID": 64598, "parentGroupID": 150}
141	367	{"_key": 367, "iconID": 33, "nameID": 65673, "hasTypes": 1, "descriptionID": 64599, "parentGroupID": 150}
142	368	{"_key": 368, "iconID": 33, "nameID": 65674, "hasTypes": 1, "descriptionID": 64600, "parentGroupID": 150}
143	369	{"_key": 369, "iconID": 33, "nameID": 65675, "hasTypes": 1, "descriptionID": 64601, "parentGroupID": 150}
144	370	{"_key": 370, "iconID": 33, "nameID": 65676, "hasTypes": 1, "descriptionID": 64602, "parentGroupID": 150}
145	372	{"_key": 372, "iconID": 33, "nameID": 65677, "hasTypes": 1, "descriptionID": 64603, "parentGroupID": 150}
146	373	{"_key": 373, "iconID": 33, "nameID": 65678, "hasTypes": 1, "descriptionID": 64604, "parentGroupID": 150}
147	374	{"_key": 374, "iconID": 33, "nameID": 65679, "hasTypes": 1, "descriptionID": 64605, "parentGroupID": 150}
148	375	{"_key": 375, "iconID": 33, "nameID": 65680, "hasTypes": 1, "descriptionID": 64606, "parentGroupID": 150}
149	376	{"_key": 376, "iconID": 33, "nameID": 65681, "hasTypes": 1, "descriptionID": 64607, "parentGroupID": 150}
150	377	{"_key": 377, "iconID": 33, "nameID": 66146, "hasTypes": 1, "descriptionID": 65072, "parentGroupID": 150}
151	378	{"_key": 378, "iconID": 33, "nameID": 65682, "hasTypes": 1, "descriptionID": 64608, "parentGroupID": 150}
152	379	{"_key": 379, "iconID": 16, "nameID": 65683, "hasTypes": 0, "descriptionID": 64609, "parentGroupID": 404}
153	380	{"_key": 380, "iconID": 112, "nameID": 65684, "hasTypes": 1, "descriptionID": 64610, "parentGroupID": 141}
154	381	{"_key": 381, "iconID": 112, "nameID": 65685, "hasTypes": 1, "descriptionID": 64611, "parentGroupID": 141}
155	382	{"_key": 382, "iconID": 112, "nameID": 65686, "hasTypes": 1, "descriptionID": 64612, "parentGroupID": 141}
156	383	{"_key": 383, "iconID": 112, "nameID": 65687, "hasTypes": 1, "descriptionID": 64613, "parentGroupID": 141}
157	387	{"_key": 387, "iconID": 1349, "nameID": 65688, "hasTypes": 0, "descriptionID": 64614, "parentGroupID": 114}
158	390	{"_key": 390, "iconID": 2703, "nameID": 66143, "hasTypes": 1, "descriptionID": 65069, "parentGroupID": 314}
159	391	{"_key": 391, "iconID": 1443, "nameID": 65689, "hasTypes": 0, "descriptionID": 64615, "parentGroupID": 4}
160	393	{"_key": 393, "iconID": 20959, "nameID": 65690, "hasTypes": 1, "descriptionID": 64616, "parentGroupID": 391}
161	394	{"_key": 394, "iconID": 20968, "nameID": 65691, "hasTypes": 1, "descriptionID": 64617, "parentGroupID": 391}
162	395	{"_key": 395, "iconID": 20967, "nameID": 65692, "hasTypes": 1, "descriptionID": 64618, "parentGroupID": 391}
163	396	{"_key": 396, "iconID": 20966, "nameID": 65693, "hasTypes": 1, "descriptionID": 64619, "parentGroupID": 391}
164	399	{"_key": 399, "iconID": 1443, "nameID": 66323, "hasTypes": 0, "descriptionID": 65249, "parentGroupID": 1364}
165	400	{"_key": 400, "iconID": 20959, "nameID": 65695, "hasTypes": 1, "descriptionID": 64621, "parentGroupID": 399}
166	401	{"_key": 401, "iconID": 20966, "nameID": 65696, "hasTypes": 1, "descriptionID": 64622, "parentGroupID": 399}
167	402	{"_key": 402, "iconID": 20967, "nameID": 65697, "hasTypes": 1, "descriptionID": 64623, "parentGroupID": 399}
168	403	{"_key": 403, "iconID": 20968, "nameID": 65698, "hasTypes": 1, "descriptionID": 64624, "parentGroupID": 399}
169	404	{"_key": 404, "iconID": 16, "nameID": 65699, "hasTypes": 0, "descriptionID": 64625, "parentGroupID": 477}
170	405	{"_key": 405, "iconID": 16, "nameID": 65700, "hasTypes": 1, "descriptionID": 64626, "parentGroupID": 404}
171	406	{"_key": 406, "iconID": 2703, "nameID": 65701, "hasTypes": 0, "descriptionID": 64627, "parentGroupID": 1338}
172	407	{"_key": 407, "iconID": 2703, "nameID": 66374, "hasTypes": 1, "descriptionID": 65300, "parentGroupID": 406}
173	408	{"_key": 408, "iconID": 2703, "nameID": 65702, "hasTypes": 0, "descriptionID": 64628, "parentGroupID": 204}
174	410	{"_key": 410, "iconID": 2703, "nameID": 65703, "hasTypes": 1, "descriptionID": 64629, "parentGroupID": 408}
175	411	{"_key": 411, "iconID": 2703, "nameID": 65704, "hasTypes": 1, "descriptionID": 64630, "parentGroupID": 408}
176	412	{"_key": 412, "iconID": 2703, "nameID": 65705, "hasTypes": 1, "descriptionID": 64631, "parentGroupID": 408}
177	413	{"_key": 413, "iconID": 2703, "nameID": 65706, "hasTypes": 1, "descriptionID": 64632, "parentGroupID": 408}
178	414	{"_key": 414, "iconID": 2703, "nameID": 65707, "hasTypes": 0, "descriptionID": 64633, "parentGroupID": 204}
179	415	{"_key": 415, "iconID": 2703, "nameID": 65708, "hasTypes": 1, "descriptionID": 64634, "parentGroupID": 414}
180	416	{"_key": 416, "iconID": 2703, "nameID": 65709, "hasTypes": 1, "descriptionID": 64635, "parentGroupID": 414}
181	417	{"_key": 417, "iconID": 2703, "nameID": 65710, "hasTypes": 1, "descriptionID": 64636, "parentGroupID": 414}
182	418	{"_key": 418, "iconID": 2703, "nameID": 65711, "hasTypes": 1, "descriptionID": 64637, "parentGroupID": 414}
183	419	{"_key": 419, "iconID": 2703, "nameID": 65712, "hasTypes": 0, "descriptionID": 64638, "parentGroupID": 204}
184	420	{"_key": 420, "iconID": 1443, "nameID": 66322, "hasTypes": 0, "descriptionID": 65248, "parentGroupID": 1364}
185	421	{"_key": 421, "iconID": 20959, "nameID": 65713, "hasTypes": 1, "descriptionID": 64639, "parentGroupID": 420}
186	422	{"_key": 422, "iconID": 20966, "nameID": 65714, "hasTypes": 1, "descriptionID": 64640, "parentGroupID": 420}
187	423	{"_key": 423, "iconID": 20967, "nameID": 65715, "hasTypes": 1, "descriptionID": 64641, "parentGroupID": 420}
188	424	{"_key": 424, "iconID": 20968, "nameID": 65716, "hasTypes": 1, "descriptionID": 64642, "parentGroupID": 420}
189	425	{"_key": 425, "iconID": 2703, "nameID": 65717, "hasTypes": 1, "descriptionID": 64643, "parentGroupID": 419}
190	427	{"_key": 427, "iconID": 2703, "nameID": 65718, "hasTypes": 1, "descriptionID": 64644, "parentGroupID": 419}
191	428	{"_key": 428, "iconID": 2703, "nameID": 65719, "hasTypes": 1, "descriptionID": 64645, "parentGroupID": 419}
192	429	{"_key": 429, "iconID": 2703, "nameID": 65720, "hasTypes": 1, "descriptionID": 64646, "parentGroupID": 419}
193	430	{"_key": 430, "iconID": 2703, "nameID": 65721, "hasTypes": 1, "descriptionID": 64647, "parentGroupID": 1578}
194	432	{"_key": 432, "iconID": 1443, "nameID": 66320, "hasTypes": 0, "descriptionID": 65246, "parentGroupID": 1364}
195	433	{"_key": 433, "iconID": 20959, "nameID": 65722, "hasTypes": 1, "descriptionID": 64648, "parentGroupID": 432}
196	434	{"_key": 434, "iconID": 20966, "nameID": 65723, "hasTypes": 1, "descriptionID": 64649, "parentGroupID": 432}
197	435	{"_key": 435, "iconID": 20967, "nameID": 65724, "hasTypes": 1, "descriptionID": 64650, "parentGroupID": 432}
198	436	{"_key": 436, "iconID": 20968, "nameID": 65725, "hasTypes": 1, "descriptionID": 64651, "parentGroupID": 432}
199	437	{"_key": 437, "iconID": 1443, "nameID": 66328, "hasTypes": 0, "descriptionID": 65254, "parentGroupID": 1368}
200	438	{"_key": 438, "iconID": 20959, "nameID": 65726, "hasTypes": 1, "descriptionID": 64652, "parentGroupID": 437}
201	439	{"_key": 439, "iconID": 20966, "nameID": 65727, "hasTypes": 1, "descriptionID": 64653, "parentGroupID": 437}
202	440	{"_key": 440, "iconID": 20967, "nameID": 65728, "hasTypes": 1, "descriptionID": 64654, "parentGroupID": 437}
203	441	{"_key": 441, "iconID": 20968, "nameID": 65729, "hasTypes": 1, "descriptionID": 64655, "parentGroupID": 437}
204	442	{"_key": 442, "iconID": 2703, "nameID": 65730, "hasTypes": 0, "descriptionID": 64656, "parentGroupID": 204}
205	443	{"_key": 443, "iconID": 2703, "nameID": 65731, "hasTypes": 1, "descriptionID": 64657, "parentGroupID": 442}
206	444	{"_key": 444, "iconID": 2703, "nameID": 65732, "hasTypes": 1, "descriptionID": 64658, "parentGroupID": 442}
207	445	{"_key": 445, "iconID": 2703, "nameID": 65733, "hasTypes": 1, "descriptionID": 64659, "parentGroupID": 442}
208	446	{"_key": 446, "iconID": 2703, "nameID": 65734, "hasTypes": 1, "descriptionID": 64660, "parentGroupID": 442}
209	448	{"_key": 448, "iconID": 1443, "nameID": 66327, "hasTypes": 0, "descriptionID": 65253, "parentGroupID": 1368}
210	449	{"_key": 449, "iconID": 20959, "nameID": 65735, "hasTypes": 1, "descriptionID": 64661, "parentGroupID": 448}
211	450	{"_key": 450, "iconID": 20966, "nameID": 65736, "hasTypes": 1, "descriptionID": 64662, "parentGroupID": 448}
212	451	{"_key": 451, "iconID": 20967, "nameID": 65737, "hasTypes": 1, "descriptionID": 64663, "parentGroupID": 448}
213	452	{"_key": 452, "iconID": 20968, "nameID": 65738, "hasTypes": 1, "descriptionID": 64664, "parentGroupID": 448}
214	453	{"_key": 453, "iconID": 2703, "nameID": 65739, "hasTypes": 0, "descriptionID": 64665, "parentGroupID": 204}
215	454	{"_key": 454, "iconID": 2703, "nameID": 65740, "hasTypes": 1, "descriptionID": 64666, "parentGroupID": 453}
216	455	{"_key": 455, "iconID": 2703, "nameID": 65741, "hasTypes": 1, "descriptionID": 64667, "parentGroupID": 453}
217	456	{"_key": 456, "iconID": 2703, "nameID": 65742, "hasTypes": 1, "descriptionID": 64668, "parentGroupID": 453}
218	457	{"_key": 457, "iconID": 2703, "nameID": 65743, "hasTypes": 1, "descriptionID": 64669, "parentGroupID": 453}
219	458	{"_key": 458, "iconID": 2703, "nameID": 65744, "hasTypes": 0, "descriptionID": 64670, "parentGroupID": 204}
220	459	{"_key": 459, "iconID": 2703, "nameID": 65745, "hasTypes": 1, "descriptionID": 64671, "parentGroupID": 458}
221	461	{"_key": 461, "iconID": 2703, "nameID": 65746, "hasTypes": 1, "descriptionID": 64672, "parentGroupID": 458}
222	462	{"_key": 462, "iconID": 2703, "nameID": 65747, "hasTypes": 1, "descriptionID": 64673, "parentGroupID": 458}
223	463	{"_key": 463, "iconID": 2703, "nameID": 65748, "hasTypes": 1, "descriptionID": 64674, "parentGroupID": 458}
224	464	{"_key": 464, "iconID": 1443, "nameID": 66329, "hasTypes": 0, "descriptionID": 65255, "parentGroupID": 1372}
225	465	{"_key": 465, "iconID": 20959, "nameID": 65749, "hasTypes": 1, "descriptionID": 64675, "parentGroupID": 464}
226	466	{"_key": 466, "iconID": 20966, "nameID": 65750, "hasTypes": 1, "descriptionID": 64676, "parentGroupID": 464}
227	467	{"_key": 467, "iconID": 20967, "nameID": 65751, "hasTypes": 1, "descriptionID": 64677, "parentGroupID": 464}
228	468	{"_key": 468, "iconID": 20968, "nameID": 65752, "hasTypes": 1, "descriptionID": 64678, "parentGroupID": 464}
229	469	{"_key": 469, "iconID": 1443, "nameID": 66330, "hasTypes": 0, "descriptionID": 65256, "parentGroupID": 1374}
230	470	{"_key": 470, "iconID": 20959, "nameID": 65753, "hasTypes": 1, "descriptionID": 64679, "parentGroupID": 469}
231	471	{"_key": 471, "iconID": 20966, "nameID": 65754, "hasTypes": 1, "descriptionID": 64680, "parentGroupID": 469}
232	472	{"_key": 472, "iconID": 20967, "nameID": 65755, "hasTypes": 1, "descriptionID": 64681, "parentGroupID": 469}
233	473	{"_key": 473, "iconID": 20968, "nameID": 65756, "hasTypes": 1, "descriptionID": 64682, "parentGroupID": 469}
234	475	{"_key": 475, "iconID": 1436, "nameID": 65757, "hasTypes": 0, "descriptionID": 64683}
235	477	{"_key": 477, "iconID": 2222, "nameID": 66294, "hasTypes": 0, "descriptionID": 65220}
236	478	{"_key": 478, "iconID": 2222, "nameID": 66295, "hasTypes": 1, "descriptionID": 65221, "parentGroupID": 1285}
237	479	{"_key": 479, "iconID": 2222, "nameID": 66296, "hasTypes": 1, "descriptionID": 65222, "parentGroupID": 480}
238	480	{"_key": 480, "iconID": 2222, "nameID": 66297, "hasTypes": 0, "descriptionID": 65223, "parentGroupID": 1285}
239	481	{"_key": 481, "iconID": 2222, "nameID": 66298, "hasTypes": 1, "descriptionID": 65224, "parentGroupID": 480}
240	482	{"_key": 482, "iconID": 2222, "nameID": 66299, "hasTypes": 1, "descriptionID": 65225, "parentGroupID": 1285}
241	483	{"_key": 483, "iconID": 2222, "nameID": 66300, "hasTypes": 1, "descriptionID": 65226, "parentGroupID": 1285}
242	484	{"_key": 484, "iconID": 2222, "nameID": 66301, "hasTypes": 1, "descriptionID": 65227, "parentGroupID": 1285}
243	485	{"_key": 485, "iconID": 2222, "nameID": 66302, "hasTypes": 1, "descriptionID": 65228, "parentGroupID": 1285}
244	488	{"_key": 488, "iconID": 2222, "nameID": 66303, "hasTypes": 1, "descriptionID": 65229, "parentGroupID": 1285}
245	490	{"_key": 490, "iconID": 2222, "nameID": 66304, "hasTypes": 1, "descriptionID": 65230, "parentGroupID": 1285}
246	491	{"_key": 491, "iconID": 1194, "nameID": 65759, "hasTypes": 1, "descriptionID": 64685, "parentGroupID": 19}
247	492	{"_key": 492, "iconID": 1182, "nameID": 65760, "hasTypes": 1, "descriptionID": 64686, "parentGroupID": 19}
248	494	{"_key": 494, "iconID": 1443, "nameID": 66343, "hasTypes": 1, "descriptionID": 65269, "parentGroupID": 1384}
249	496	{"_key": 496, "iconID": 2703, "nameID": 65763, "hasTypes": 0, "descriptionID": 64689, "parentGroupID": 204}
250	497	{"_key": 497, "iconID": 2703, "nameID": 65764, "hasTypes": 1, "descriptionID": 64690, "parentGroupID": 496}
251	499	{"_key": 499, "iconID": 2679, "nameID": 65765, "hasTypes": 1, "descriptionID": 64691, "parentGroupID": 1034}
252	500	{"_key": 500, "iconID": 2664, "nameID": 65766, "hasTypes": 1, "descriptionID": 64692, "parentGroupID": 1034}
253	501	{"_key": 501, "iconID": 2668, "nameID": 65767, "hasTypes": 1, "descriptionID": 64693, "parentGroupID": 1034}
254	502	{"_key": 502, "iconID": 1004, "nameID": 65768, "hasTypes": 1, "descriptionID": 64694, "parentGroupID": 845}
255	503	{"_key": 503, "iconID": 1142, "nameID": 65769, "hasTypes": 1, "descriptionID": 64695, "parentGroupID": 851}
256	504	{"_key": 504, "iconID": 1047, "nameID": 65770, "hasTypes": 1, "descriptionID": 64696, "parentGroupID": 848}
257	505	{"_key": 505, "iconID": 1346, "nameID": 66270, "hasTypes": 0, "descriptionID": 65196, "parentGroupID": 114}
258	506	{"_key": 506, "iconID": 2222, "nameID": 66305, "hasTypes": 1, "descriptionID": 65231, "parentGroupID": 1285}
259	512	{"_key": 512, "iconID": 1277, "nameID": 65774, "hasTypes": 1, "descriptionID": 64700, "parentGroupID": 54}
260	514	{"_key": 514, "iconID": 1273, "nameID": 65775, "hasTypes": 1, "descriptionID": 64701, "parentGroupID": 54}
261	515	{"_key": 515, "iconID": 231, "nameID": 65776, "hasTypes": 1, "descriptionID": 64702, "parentGroupID": 54}
262	516	{"_key": 516, "iconID": 230, "nameID": 65777, "hasTypes": 1, "descriptionID": 64703, "parentGroupID": 54}
263	517	{"_key": 517, "iconID": 1274, "nameID": 65778, "hasTypes": 1, "descriptionID": 64704, "parentGroupID": 54}
264	518	{"_key": 518, "iconID": 232, "nameID": 65779, "hasTypes": 1, "descriptionID": 64705, "parentGroupID": 54}
265	519	{"_key": 519, "iconID": 1356, "nameID": 65780, "hasTypes": 1, "descriptionID": 64706, "parentGroupID": 54}
266	521	{"_key": 521, "iconID": 1272, "nameID": 65781, "hasTypes": 1, "descriptionID": 64707, "parentGroupID": 54}
267	522	{"_key": 522, "iconID": 1275, "nameID": 65782, "hasTypes": 1, "descriptionID": 64708, "parentGroupID": 54}
268	523	{"_key": 523, "iconID": 1270, "nameID": 65783, "hasTypes": 1, "descriptionID": 64709, "parentGroupID": 54}
269	525	{"_key": 525, "iconID": 1377, "nameID": 65784, "hasTypes": 1, "descriptionID": 64710, "parentGroupID": 54}
270	526	{"_key": 526, "iconID": 1271, "nameID": 65785, "hasTypes": 1, "descriptionID": 64711, "parentGroupID": 54}
271	527	{"_key": 527, "iconID": 1269, "nameID": 65786, "hasTypes": 1, "descriptionID": 64712, "parentGroupID": 54}
272	528	{"_key": 528, "iconID": 1282, "nameID": 65787, "hasTypes": 1, "descriptionID": 64713, "parentGroupID": 54}
273	529	{"_key": 529, "iconID": 1279, "nameID": 65788, "hasTypes": 1, "descriptionID": 64714, "parentGroupID": 54}
274	530	{"_key": 530, "iconID": 2102, "nameID": 65789, "hasTypes": 1, "descriptionID": 64715, "parentGroupID": 54}
275	531	{"_key": 531, "iconID": 2224, "nameID": 65790, "hasTypes": 0, "descriptionID": 64716, "parentGroupID": 27}
276	532	{"_key": 532, "iconID": 2062, "nameID": 65791, "hasTypes": 0, "descriptionID": 64717, "parentGroupID": 27}
277	533	{"_key": 533, "iconID": 1201, "nameID": 65792, "hasTypes": 0, "descriptionID": 64718, "parentGroupID": 475}
278	535	{"_key": 535, "iconID": 1030, "nameID": 65793, "hasTypes": 0, "descriptionID": 64719, "parentGroupID": 14}
279	537	{"_key": 537, "iconID": 80, "nameID": 65794, "hasTypes": 0, "descriptionID": 64720, "parentGroupID": 14}
280	538	{"_key": 538, "iconID": 80, "nameID": 65795, "hasTypes": 0, "descriptionID": 64721, "parentGroupID": 14}
281	540	{"_key": 540, "iconID": 1030, "nameID": 65796, "hasTypes": 0, "descriptionID": 64722, "parentGroupID": 14}
282	541	{"_key": 541, "iconID": 2066, "nameID": 65797, "hasTypes": 0, "descriptionID": 64723, "parentGroupID": 14}
283	542	{"_key": 542, "iconID": 96, "nameID": 65798, "hasTypes": 1, "descriptionID": 64724, "parentGroupID": 52}
284	550	{"_key": 550, "iconID": 20939, "nameID": 65799, "hasTypes": 0, "descriptionID": 64725, "parentGroupID": 554}
285	551	{"_key": 551, "iconID": 1044, "nameID": 65800, "hasTypes": 0, "descriptionID": 64726, "parentGroupID": 554}
286	552	{"_key": 552, "iconID": 84, "nameID": 65801, "hasTypes": 0, "descriptionID": 64727, "parentGroupID": 554}
287	553	{"_key": 553, "iconID": 81, "nameID": 65802, "hasTypes": 0, "descriptionID": 64728, "parentGroupID": 554}
288	554	{"_key": 554, "iconID": 69, "nameID": 65803, "hasTypes": 0, "descriptionID": 64729, "parentGroupID": 9}
289	555	{"_key": 555, "iconID": 366, "nameID": 65804, "hasTypes": 0, "descriptionID": 64730, "parentGroupID": 86}
290	556	{"_key": 556, "iconID": 365, "nameID": 65805, "hasTypes": 0, "descriptionID": 64731, "parentGroupID": 86}
291	557	{"_key": 557, "iconID": 361, "nameID": 65806, "hasTypes": 0, "descriptionID": 64732, "parentGroupID": 88}
292	558	{"_key": 558, "iconID": 360, "nameID": 65807, "hasTypes": 0, "descriptionID": 64733, "parentGroupID": 88}
293	559	{"_key": 559, "iconID": 381, "nameID": 65808, "hasTypes": 0, "descriptionID": 64734, "parentGroupID": 87}
294	560	{"_key": 560, "iconID": 381, "nameID": 65809, "hasTypes": 0, "descriptionID": 64735, "parentGroupID": 87}
295	561	{"_key": 561, "iconID": 376, "nameID": 65810, "hasTypes": 1, "descriptionID": 64736, "parentGroupID": 556}
296	562	{"_key": 562, "iconID": 371, "nameID": 65811, "hasTypes": 1, "descriptionID": 64737, "parentGroupID": 556}
297	563	{"_key": 563, "iconID": 365, "nameID": 65812, "hasTypes": 1, "descriptionID": 64738, "parentGroupID": 556}
298	564	{"_key": 564, "iconID": 349, "nameID": 65813, "hasTypes": 1, "descriptionID": 64739, "parentGroupID": 555}
299	565	{"_key": 565, "iconID": 370, "nameID": 65814, "hasTypes": 1, "descriptionID": 64740, "parentGroupID": 555}
300	566	{"_key": 566, "iconID": 366, "nameID": 65815, "hasTypes": 1, "descriptionID": 64741, "parentGroupID": 555}
301	567	{"_key": 567, "iconID": 352, "nameID": 65816, "hasTypes": 1, "descriptionID": 64742, "parentGroupID": 557}
302	568	{"_key": 568, "iconID": 355, "nameID": 65817, "hasTypes": 1, "descriptionID": 64743, "parentGroupID": 557}
303	569	{"_key": 569, "iconID": 361, "nameID": 65818, "hasTypes": 1, "descriptionID": 64744, "parentGroupID": 557}
304	570	{"_key": 570, "iconID": 350, "nameID": 65819, "hasTypes": 1, "descriptionID": 64745, "parentGroupID": 558}
305	572	{"_key": 572, "iconID": 356, "nameID": 65820, "hasTypes": 1, "descriptionID": 64746, "parentGroupID": 558}
306	573	{"_key": 573, "iconID": 360, "nameID": 65821, "hasTypes": 1, "descriptionID": 64747, "parentGroupID": 558}
307	574	{"_key": 574, "iconID": 387, "nameID": 65822, "hasTypes": 1, "descriptionID": 64748, "parentGroupID": 559}
308	575	{"_key": 575, "iconID": 386, "nameID": 65823, "hasTypes": 1, "descriptionID": 64749, "parentGroupID": 559}
309	576	{"_key": 576, "iconID": 381, "nameID": 65824, "hasTypes": 1, "descriptionID": 64750, "parentGroupID": 559}
310	577	{"_key": 577, "iconID": 389, "nameID": 65825, "hasTypes": 1, "descriptionID": 64751, "parentGroupID": 560}
311	578	{"_key": 578, "iconID": 384, "nameID": 65826, "hasTypes": 1, "descriptionID": 64752, "parentGroupID": 560}
312	579	{"_key": 579, "iconID": 379, "nameID": 65827, "hasTypes": 1, "descriptionID": 64753, "parentGroupID": 560}
313	580	{"_key": 580, "iconID": 184, "nameID": 65828, "hasTypes": 0, "descriptionID": 64754, "parentGroupID": 114}
314	581	{"_key": 581, "iconID": 186, "nameID": 65829, "hasTypes": 0, "descriptionID": 64755, "parentGroupID": 114}
315	582	{"_key": 582, "iconID": 2703, "nameID": 65830, "hasTypes": 0, "descriptionID": 64756, "parentGroupID": 204}
316	583	{"_key": 583, "iconID": 2703, "nameID": 65831, "hasTypes": 1, "descriptionID": 64757, "parentGroupID": 582}
317	584	{"_key": 584, "iconID": 2703, "nameID": 65832, "hasTypes": 1, "descriptionID": 64758, "parentGroupID": 582}
318	585	{"_key": 585, "iconID": 2703, "nameID": 65833, "hasTypes": 1, "descriptionID": 64759, "parentGroupID": 582}
319	586	{"_key": 586, "iconID": 2703, "nameID": 65834, "hasTypes": 1, "descriptionID": 64760, "parentGroupID": 582}
320	588	{"_key": 588, "iconID": 2703, "nameID": 65835, "hasTypes": 0, "descriptionID": 64761, "parentGroupID": 204}
321	589	{"_key": 589, "iconID": 2703, "nameID": 65836, "hasTypes": 1, "descriptionID": 64762, "parentGroupID": 588}
322	590	{"_key": 590, "iconID": 2703, "nameID": 65837, "hasTypes": 1, "descriptionID": 64763, "parentGroupID": 588}
323	591	{"_key": 591, "iconID": 2703, "nameID": 65838, "hasTypes": 1, "descriptionID": 64764, "parentGroupID": 588}
324	592	{"_key": 592, "iconID": 2703, "nameID": 65839, "hasTypes": 1, "descriptionID": 64765, "parentGroupID": 588}
325	593	{"_key": 593, "iconID": 24968, "nameID": 65840, "hasTypes": 0, "descriptionID": 64766, "parentGroupID": 11}
326	594	{"_key": 594, "iconID": 2222, "nameID": 65841, "hasTypes": 1, "descriptionID": 64767, "parentGroupID": 480}
327	595	{"_key": 595, "iconID": 2222, "nameID": 65842, "hasTypes": 1, "descriptionID": 64768, "parentGroupID": 480}
328	596	{"_key": 596, "iconID": 2222, "nameID": 65843, "hasTypes": 1, "descriptionID": 64769, "parentGroupID": 480}
329	597	{"_key": 597, "iconID": 2703, "nameID": 65844, "hasTypes": 1, "descriptionID": 64770, "parentGroupID": 299}
330	598	{"_key": 598, "iconID": 2703, "nameID": 65845, "hasTypes": 1, "descriptionID": 64771, "parentGroupID": 300}
331	599	{"_key": 599, "iconID": 2703, "nameID": 65846, "hasTypes": 1, "descriptionID": 64772, "parentGroupID": 301}
332	600	{"_key": 600, "iconID": 86, "nameID": 65847, "hasTypes": 1, "descriptionID": 64773, "parentGroupID": 128}
333	601	{"_key": 601, "iconID": 86, "nameID": 65848, "hasTypes": 1, "descriptionID": 64774, "parentGroupID": 128}
334	602	{"_key": 602, "iconID": 86, "nameID": 65849, "hasTypes": 1, "descriptionID": 64775, "parentGroupID": 128}
335	603	{"_key": 603, "iconID": 86, "nameID": 65850, "hasTypes": 1, "descriptionID": 64776, "parentGroupID": 128}
336	604	{"_key": 604, "iconID": 86, "nameID": 65851, "hasTypes": 1, "descriptionID": 64777, "parentGroupID": 128}
337	605	{"_key": 605, "iconID": 1044, "nameID": 65852, "hasTypes": 1, "descriptionID": 64778, "parentGroupID": 551}
338	606	{"_key": 606, "iconID": 1044, "nameID": 65853, "hasTypes": 1, "descriptionID": 64779, "parentGroupID": 551}
339	608	{"_key": 608, "iconID": 1044, "nameID": 65855, "hasTypes": 1, "descriptionID": 64781, "parentGroupID": 551}
340	609	{"_key": 609, "iconID": 84, "nameID": 65856, "hasTypes": 1, "descriptionID": 64782, "parentGroupID": 552}
341	610	{"_key": 610, "iconID": 84, "nameID": 65857, "hasTypes": 1, "descriptionID": 64783, "parentGroupID": 552}
342	611	{"_key": 611, "iconID": 84, "nameID": 65858, "hasTypes": 1, "descriptionID": 64784, "parentGroupID": 552}
343	612	{"_key": 612, "iconID": 84, "nameID": 65859, "hasTypes": 1, "descriptionID": 64785, "parentGroupID": 552}
344	613	{"_key": 613, "iconID": 84, "nameID": 65860, "hasTypes": 1, "descriptionID": 64786, "parentGroupID": 552}
345	614	{"_key": 614, "iconID": 2302, "nameID": 65861, "hasTypes": 0, "descriptionID": 64787, "parentGroupID": 19}
346	615	{"_key": 615, "iconID": 77, "nameID": 65862, "hasTypes": 1, "descriptionID": 64788, "parentGroupID": 14}
347	616	{"_key": 616, "iconID": 2552, "nameID": 65863, "hasTypes": 0, "descriptionID": 64789, "parentGroupID": 19}
348	617	{"_key": 617, "iconID": 2703, "nameID": 66144, "hasTypes": 1, "descriptionID": 65070, "parentGroupID": 314}
349	618	{"_key": 618, "iconID": 2053, "nameID": 65864, "hasTypes": 1, "descriptionID": 64790, "parentGroupID": 532}
350	619	{"_key": 619, "iconID": 2061, "nameID": 65865, "hasTypes": 1, "descriptionID": 64791, "parentGroupID": 532}
351	620	{"_key": 620, "iconID": 2054, "nameID": 65866, "hasTypes": 1, "descriptionID": 64792, "parentGroupID": 532}
352	621	{"_key": 621, "iconID": 2062, "nameID": 65867, "hasTypes": 1, "descriptionID": 64793, "parentGroupID": 532}
353	622	{"_key": 622, "iconID": 2060, "nameID": 65868, "hasTypes": 1, "descriptionID": 64794, "parentGroupID": 532}
354	629	{"_key": 629, "iconID": 1443, "nameID": 66342, "hasTypes": 0, "descriptionID": 65268, "parentGroupID": 1385}
355	630	{"_key": 630, "iconID": 20959, "nameID": 65869, "hasTypes": 1, "descriptionID": 64795, "parentGroupID": 629}
356	631	{"_key": 631, "iconID": 20966, "nameID": 65870, "hasTypes": 1, "descriptionID": 64796, "parentGroupID": 629}
357	632	{"_key": 632, "iconID": 20967, "nameID": 65871, "hasTypes": 1, "descriptionID": 64797, "parentGroupID": 629}
358	633	{"_key": 633, "iconID": 20968, "nameID": 65872, "hasTypes": 1, "descriptionID": 64798, "parentGroupID": 629}
359	634	{"_key": 634, "iconID": 2703, "nameID": 65873, "hasTypes": 0, "descriptionID": 64799, "parentGroupID": 204}
360	635	{"_key": 635, "iconID": 2703, "nameID": 65874, "hasTypes": 1, "descriptionID": 64800, "parentGroupID": 634}
361	636	{"_key": 636, "iconID": 2703, "nameID": 65875, "hasTypes": 1, "descriptionID": 64801, "parentGroupID": 634}
362	637	{"_key": 637, "iconID": 2703, "nameID": 65876, "hasTypes": 1, "descriptionID": 64802, "parentGroupID": 634}
363	638	{"_key": 638, "iconID": 2703, "nameID": 65877, "hasTypes": 1, "descriptionID": 64803, "parentGroupID": 634}
364	639	{"_key": 639, "iconID": 1345, "nameID": 65878, "hasTypes": 1, "descriptionID": 64804, "parentGroupID": 140}
365	640	{"_key": 640, "iconID": 168, "nameID": 65879, "hasTypes": 1, "descriptionID": 64805, "parentGroupID": 140}
366	641	{"_key": 641, "iconID": 1345, "nameID": 65880, "hasTypes": 1, "descriptionID": 64806, "parentGroupID": 140}
367	642	{"_key": 642, "iconID": 169, "nameID": 65881, "hasTypes": 1, "descriptionID": 64807, "parentGroupID": 140}
368	643	{"_key": 643, "iconID": 2530, "nameID": 65882, "hasTypes": 1, "descriptionID": 64808, "parentGroupID": 140}
369	644	{"_key": 644, "iconID": 170, "nameID": 65883, "hasTypes": 1, "descriptionID": 64809, "parentGroupID": 140}
370	645	{"_key": 645, "iconID": 21440, "nameID": 65884, "hasTypes": 1, "descriptionID": 64810, "parentGroupID": 143}
371	646	{"_key": 646, "iconID": 26452, "nameID": 65885, "hasTypes": 1, "descriptionID": 64811, "parentGroupID": 143}
372	647	{"_key": 647, "iconID": 26453, "nameID": 65886, "hasTypes": 1, "descriptionID": 64812, "parentGroupID": 143}
373	648	{"_key": 648, "iconID": 26454, "nameID": 65887, "hasTypes": 1, "descriptionID": 64813, "parentGroupID": 143}
374	655	{"_key": 655, "iconID": 70, "nameID": 65888, "hasTypes": 0, "descriptionID": 64814, "parentGroupID": 9}
375	656	{"_key": 656, "iconID": 104, "nameID": 65889, "hasTypes": 0, "descriptionID": 64815, "parentGroupID": 9}
376	657	{"_key": 657, "iconID": 111, "nameID": 65890, "hasTypes": 0, "descriptionID": 64816, "parentGroupID": 9}
377	658	{"_key": 658, "iconID": 26546, "nameID": 65891, "hasTypes": 1, "descriptionID": 64817, "parentGroupID": 655}
378	659	{"_key": 659, "iconID": 26547, "nameID": 65892, "hasTypes": 1, "descriptionID": 64818, "parentGroupID": 655}
379	660	{"_key": 660, "iconID": 2105, "nameID": 66145, "hasTypes": 1, "descriptionID": 65071, "parentGroupID": 655}
380	661	{"_key": 661, "iconID": 1283, "nameID": 66350, "hasTypes": 0, "descriptionID": 65276, "parentGroupID": 655}
381	662	{"_key": 662, "iconID": 1029, "nameID": 65893, "hasTypes": 0, "descriptionID": 64819, "parentGroupID": 655}
382	663	{"_key": 663, "iconID": 1035, "nameID": 65894, "hasTypes": 0, "descriptionID": 64820, "parentGroupID": 655}
383	664	{"_key": 664, "iconID": 89, "nameID": 65895, "hasTypes": 0, "descriptionID": 64821, "parentGroupID": 655}
384	665	{"_key": 665, "iconID": 26457, "nameID": 65896, "hasTypes": 1, "descriptionID": 64822, "parentGroupID": 655}
385	666	{"_key": 666, "iconID": 26456, "nameID": 65897, "hasTypes": 1, "descriptionID": 64823, "parentGroupID": 655}
386	667	{"_key": 667, "iconID": 26455, "nameID": 65898, "hasTypes": 1, "descriptionID": 64824, "parentGroupID": 655}
387	668	{"_key": 668, "iconID": 1031, "nameID": 65899, "hasTypes": 0, "descriptionID": 64825, "parentGroupID": 655}
388	669	{"_key": 669, "iconID": 26727, "nameID": 65900, "hasTypes": 1, "descriptionID": 64826, "parentGroupID": 656}
389	670	{"_key": 670, "iconID": 26721, "nameID": 65901, "hasTypes": 1, "descriptionID": 64827, "parentGroupID": 656}
390	671	{"_key": 671, "iconID": 26726, "nameID": 65902, "hasTypes": 1, "descriptionID": 64828, "parentGroupID": 656}
391	672	{"_key": 672, "iconID": 26724, "nameID": 65903, "hasTypes": 1, "descriptionID": 64829, "parentGroupID": 656}
392	673	{"_key": 673, "iconID": 26725, "nameID": 65904, "hasTypes": 1, "descriptionID": 64830, "parentGroupID": 656}
393	675	{"_key": 675, "iconID": 2106, "nameID": 65906, "hasTypes": 1, "descriptionID": 64832, "parentGroupID": 656}
394	676	{"_key": 676, "iconID": 1405, "nameID": 65907, "hasTypes": 1, "descriptionID": 64833, "parentGroupID": 656}
395	677	{"_key": 677, "iconID": 109, "nameID": 65908, "hasTypes": 0, "descriptionID": 64834, "parentGroupID": 657}
396	678	{"_key": 678, "iconID": 109, "nameID": 65909, "hasTypes": 1, "descriptionID": 64835, "parentGroupID": 657}
397	679	{"_key": 679, "iconID": 105, "nameID": 65910, "hasTypes": 1, "descriptionID": 64836, "parentGroupID": 657}
398	680	{"_key": 680, "iconID": 1639, "nameID": 65911, "hasTypes": 1, "descriptionID": 64837, "parentGroupID": 657}
399	681	{"_key": 681, "iconID": 104, "nameID": 65912, "hasTypes": 0, "descriptionID": 64838, "parentGroupID": 657}
400	683	{"_key": 683, "iconID": 1284, "nameID": 65914, "hasTypes": 1, "descriptionID": 64840, "parentGroupID": 657}
401	685	{"_key": 685, "iconID": 104, "nameID": 65915, "hasTypes": 0, "descriptionID": 64841, "parentGroupID": 657}
402	686	{"_key": 686, "iconID": 110, "nameID": 65916, "hasTypes": 1, "descriptionID": 64842, "parentGroupID": 657}
403	687	{"_key": 687, "iconID": 26449, "nameID": 65917, "hasTypes": 1, "descriptionID": 64843, "parentGroupID": 554}
404	688	{"_key": 688, "iconID": 26450, "nameID": 65918, "hasTypes": 1, "descriptionID": 64844, "parentGroupID": 554}
405	689	{"_key": 689, "iconID": 1283, "nameID": 65919, "hasTypes": 1, "descriptionID": 64845, "parentGroupID": 661}
406	690	{"_key": 690, "iconID": 1283, "nameID": 65920, "hasTypes": 1, "descriptionID": 64846, "parentGroupID": 661}
407	691	{"_key": 691, "iconID": 1283, "nameID": 65921, "hasTypes": 1, "descriptionID": 64847, "parentGroupID": 661}
408	692	{"_key": 692, "iconID": 1029, "nameID": 65922, "hasTypes": 1, "descriptionID": 64848, "parentGroupID": 662}
409	693	{"_key": 693, "iconID": 1029, "nameID": 65923, "hasTypes": 1, "descriptionID": 64849, "parentGroupID": 662}
410	694	{"_key": 694, "iconID": 1029, "nameID": 65924, "hasTypes": 1, "descriptionID": 64850, "parentGroupID": 662}
411	695	{"_key": 695, "iconID": 1035, "nameID": 65925, "hasTypes": 1, "descriptionID": 64851, "parentGroupID": 663}
412	696	{"_key": 696, "iconID": 1035, "nameID": 65926, "hasTypes": 1, "descriptionID": 64852, "parentGroupID": 663}
413	697	{"_key": 697, "iconID": 1035, "nameID": 65927, "hasTypes": 1, "descriptionID": 64853, "parentGroupID": 663}
414	698	{"_key": 698, "iconID": 1031, "nameID": 65928, "hasTypes": 1, "descriptionID": 64854, "parentGroupID": 668}
415	699	{"_key": 699, "iconID": 1031, "nameID": 65929, "hasTypes": 1, "descriptionID": 64855, "parentGroupID": 668}
416	700	{"_key": 700, "iconID": 1031, "nameID": 65930, "hasTypes": 1, "descriptionID": 64856, "parentGroupID": 668}
417	701	{"_key": 701, "iconID": 1031, "nameID": 65931, "hasTypes": 1, "descriptionID": 64857, "parentGroupID": 668}
418	702	{"_key": 702, "iconID": 89, "nameID": 65932, "hasTypes": 1, "descriptionID": 64858, "parentGroupID": 664}
419	703	{"_key": 703, "iconID": 89, "nameID": 65933, "hasTypes": 1, "descriptionID": 64859, "parentGroupID": 664}
420	704	{"_key": 704, "iconID": 89, "nameID": 65934, "hasTypes": 1, "descriptionID": 64860, "parentGroupID": 664}
421	705	{"_key": 705, "iconID": 89, "nameID": 65935, "hasTypes": 1, "descriptionID": 64861, "parentGroupID": 664}
422	706	{"_key": 706, "iconID": 3346, "nameID": 65936, "hasTypes": 1, "descriptionID": 64862, "parentGroupID": 143}
423	707	{"_key": 707, "iconID": 1640, "nameID": 65937, "hasTypes": 1, "descriptionID": 64863, "parentGroupID": 143}
424	708	{"_key": 708, "iconID": 3346, "nameID": 65938, "hasTypes": 1, "descriptionID": 64864, "parentGroupID": 143}
425	711	{"_key": 711, "iconID": 106, "nameID": 65939, "hasTypes": 1, "descriptionID": 64865, "parentGroupID": 1708}
426	712	{"_key": 712, "iconID": 2677, "nameID": 66262, "hasTypes": 1, "descriptionID": 65188, "parentGroupID": 1708}
427	713	{"_key": 713, "iconID": 107, "nameID": 65940, "hasTypes": 1, "descriptionID": 64866, "parentGroupID": 1708}
428	714	{"_key": 714, "iconID": 2732, "nameID": 65941, "hasTypes": 1, "descriptionID": 64867, "parentGroupID": 1708}
429	715	{"_key": 715, "iconID": 3227, "nameID": 65942, "hasTypes": 1, "descriptionID": 64868, "parentGroupID": 677}
430	716	{"_key": 716, "iconID": 3228, "nameID": 65943, "hasTypes": 1, "descriptionID": 64869, "parentGroupID": 677}
431	717	{"_key": 717, "iconID": 3226, "nameID": 65944, "hasTypes": 1, "descriptionID": 64870, "parentGroupID": 677}
432	718	{"_key": 718, "iconID": 3229, "nameID": 65945, "hasTypes": 1, "descriptionID": 64871, "parentGroupID": 677}
433	719	{"_key": 719, "iconID": 109, "nameID": 65946, "hasTypes": 1, "descriptionID": 64872, "parentGroupID": 677}
434	720	{"_key": 720, "iconID": 104, "nameID": 66149, "hasTypes": 1, "descriptionID": 65075, "parentGroupID": 681}
435	721	{"_key": 721, "iconID": 104, "nameID": 66147, "hasTypes": 1, "descriptionID": 65073, "parentGroupID": 681}
436	722	{"_key": 722, "iconID": 104, "nameID": 66148, "hasTypes": 1, "descriptionID": 65074, "parentGroupID": 681}
437	723	{"_key": 723, "iconID": 104, "nameID": 65947, "hasTypes": 1, "descriptionID": 64873, "parentGroupID": 681}
438	724	{"_key": 724, "iconID": 104, "nameID": 65948, "hasTypes": 1, "descriptionID": 64874, "parentGroupID": 681}
439	725	{"_key": 725, "iconID": 104, "nameID": 65949, "hasTypes": 1, "descriptionID": 64875, "parentGroupID": 685}
440	726	{"_key": 726, "iconID": 104, "nameID": 65950, "hasTypes": 1, "descriptionID": 64876, "parentGroupID": 685}
441	727	{"_key": 727, "iconID": 104, "nameID": 65951, "hasTypes": 1, "descriptionID": 64877, "parentGroupID": 685}
442	728	{"_key": 728, "iconID": 104, "nameID": 65952, "hasTypes": 1, "descriptionID": 64878, "parentGroupID": 685}
443	729	{"_key": 729, "iconID": 104, "nameID": 65953, "hasTypes": 1, "descriptionID": 64879, "parentGroupID": 685}
444	730	{"_key": 730, "iconID": 2552, "nameID": 65954, "hasTypes": 1, "descriptionID": 64880, "parentGroupID": 616}
445	731	{"_key": 731, "iconID": 2552, "nameID": 65955, "hasTypes": 1, "descriptionID": 64881, "parentGroupID": 616}
446	732	{"_key": 732, "iconID": 2552, "nameID": 65956, "hasTypes": 1, "descriptionID": 64882, "parentGroupID": 616}
447	733	{"_key": 733, "iconID": 2552, "nameID": 65957, "hasTypes": 1, "descriptionID": 64883, "parentGroupID": 616}
448	734	{"_key": 734, "iconID": 2552, "nameID": 65958, "hasTypes": 1, "descriptionID": 64884, "parentGroupID": 616}
449	735	{"_key": 735, "iconID": 2552, "nameID": 65959, "hasTypes": 1, "descriptionID": 64885, "parentGroupID": 616}
450	736	{"_key": 736, "iconID": 2552, "nameID": 65960, "hasTypes": 1, "descriptionID": 64886, "parentGroupID": 616}
451	737	{"_key": 737, "iconID": 2552, "nameID": 65961, "hasTypes": 1, "descriptionID": 64887, "parentGroupID": 616}
452	738	{"_key": 738, "iconID": 2038, "nameID": 65962, "hasTypes": 1, "descriptionID": 64888, "parentGroupID": 19}
453	739	{"_key": 739, "iconID": 2325, "nameID": 65963, "hasTypes": 0, "descriptionID": 64889, "parentGroupID": 19}
454	740	{"_key": 740, "iconID": 2312, "nameID": 65964, "hasTypes": 1, "descriptionID": 64890, "parentGroupID": 739}
455	741	{"_key": 741, "iconID": 2317, "nameID": 65965, "hasTypes": 1, "descriptionID": 64891, "parentGroupID": 739}
456	742	{"_key": 742, "iconID": 2317, "nameID": 65966, "hasTypes": 1, "descriptionID": 64892, "parentGroupID": 739}
457	743	{"_key": 743, "iconID": 2312, "nameID": 65967, "hasTypes": 1, "descriptionID": 64893, "parentGroupID": 739}
458	744	{"_key": 744, "iconID": 2327, "nameID": 65968, "hasTypes": 1, "descriptionID": 64894, "parentGroupID": 739}
459	745	{"_key": 745, "iconID": 2327, "nameID": 65969, "hasTypes": 1, "descriptionID": 64895, "parentGroupID": 739}
460	746	{"_key": 746, "iconID": 2332, "nameID": 65970, "hasTypes": 1, "descriptionID": 64896, "parentGroupID": 739}
461	747	{"_key": 747, "iconID": 2322, "nameID": 65971, "hasTypes": 1, "descriptionID": 64897, "parentGroupID": 739}
462	748	{"_key": 748, "iconID": 2322, "nameID": 65972, "hasTypes": 1, "descriptionID": 64898, "parentGroupID": 739}
463	749	{"_key": 749, "iconID": 2332, "nameID": 65973, "hasTypes": 1, "descriptionID": 64899, "parentGroupID": 739}
464	750	{"_key": 750, "iconID": 2319, "nameID": 65974, "hasTypes": 1, "descriptionID": 64900, "parentGroupID": 739}
465	751	{"_key": 751, "iconID": 2039, "nameID": 65975, "hasTypes": 1, "descriptionID": 64901, "parentGroupID": 614}
466	752	{"_key": 752, "iconID": 2302, "nameID": 65976, "hasTypes": 1, "descriptionID": 64902, "parentGroupID": 614}
467	753	{"_key": 753, "iconID": 2703, "nameID": 65977, "hasTypes": 0, "descriptionID": 64903, "parentGroupID": 211}
468	754	{"_key": 754, "iconID": 1204, "nameID": 66236, "hasTypes": 1, "descriptionID": 65162, "parentGroupID": 19}
469	757	{"_key": 757, "iconID": 2983, "nameID": 65978, "hasTypes": 1, "descriptionID": 64904, "parentGroupID": 657}
470	761	{"_key": 761, "iconID": 1443, "nameID": 66338, "hasTypes": 0, "descriptionID": 65264, "parentGroupID": 1381}
471	762	{"_key": 762, "iconID": 20959, "nameID": 65981, "hasTypes": 1, "descriptionID": 64907, "parentGroupID": 3509}
472	763	{"_key": 763, "iconID": 20966, "nameID": 65982, "hasTypes": 1, "descriptionID": 64908, "parentGroupID": 3509}
473	764	{"_key": 764, "iconID": 20967, "nameID": 65983, "hasTypes": 1, "descriptionID": 64909, "parentGroupID": 3509}
474	765	{"_key": 765, "iconID": 20968, "nameID": 65984, "hasTypes": 1, "descriptionID": 64910, "parentGroupID": 3509}
475	766	{"_key": 766, "iconID": 1443, "nameID": 66340, "hasTypes": 0, "descriptionID": 65266, "parentGroupID": 1381}
476	767	{"_key": 767, "iconID": 20959, "nameID": 65985, "hasTypes": 1, "descriptionID": 64911, "parentGroupID": 766}
477	768	{"_key": 768, "iconID": 20966, "nameID": 65986, "hasTypes": 1, "descriptionID": 64912, "parentGroupID": 766}
478	769	{"_key": 769, "iconID": 20967, "nameID": 65987, "hasTypes": 1, "descriptionID": 64913, "parentGroupID": 766}
479	770	{"_key": 770, "iconID": 20968, "nameID": 65988, "hasTypes": 1, "descriptionID": 64914, "parentGroupID": 766}
480	771	{"_key": 771, "iconID": 2836, "nameID": 65989, "hasTypes": 1, "descriptionID": 64915, "parentGroupID": 556}
481	772	{"_key": 772, "iconID": 2840, "nameID": 65990, "hasTypes": 1, "descriptionID": 64916, "parentGroupID": 555}
482	773	{"_key": 773, "iconID": 2837, "nameID": 65991, "hasTypes": 1, "descriptionID": 64917, "parentGroupID": 557}
483	774	{"_key": 774, "iconID": 2841, "nameID": 65992, "hasTypes": 1, "descriptionID": 64918, "parentGroupID": 558}
484	775	{"_key": 775, "iconID": 2842, "nameID": 65993, "hasTypes": 1, "descriptionID": 64919, "parentGroupID": 560}
485	776	{"_key": 776, "iconID": 2838, "nameID": 65994, "hasTypes": 1, "descriptionID": 64920, "parentGroupID": 559}
486	777	{"_key": 777, "iconID": 3955, "nameID": 65995, "hasTypes": 1, "descriptionID": 64921, "parentGroupID": 140}
487	778	{"_key": 778, "iconID": 84, "nameID": 65996, "hasTypes": 1, "descriptionID": 64922, "parentGroupID": 552}
488	779	{"_key": 779, "iconID": 20969, "nameID": 65997, "hasTypes": 0, "descriptionID": 64923, "parentGroupID": 9}
489	781	{"_key": 781, "iconID": 2863, "nameID": 65999, "hasTypes": 1, "descriptionID": 64925, "parentGroupID": 1035}
490	782	{"_key": 782, "iconID": 2703, "nameID": 66000, "hasTypes": 0, "descriptionID": 64926, "parentGroupID": 204}
491	783	{"_key": 783, "iconID": 2703, "nameID": 66001, "hasTypes": 1, "descriptionID": 64927, "parentGroupID": 782}
492	784	{"_key": 784, "iconID": 2703, "nameID": 66002, "hasTypes": 1, "descriptionID": 64928, "parentGroupID": 782}
493	785	{"_key": 785, "iconID": 2703, "nameID": 66003, "hasTypes": 1, "descriptionID": 64929, "parentGroupID": 782}
494	786	{"_key": 786, "iconID": 2703, "nameID": 66004, "hasTypes": 1, "descriptionID": 64930, "parentGroupID": 782}
495	787	{"_key": 787, "iconID": 2703, "nameID": 66005, "hasTypes": 0, "descriptionID": 64931, "parentGroupID": 204}
496	788	{"_key": 788, "iconID": 2703, "nameID": 66006, "hasTypes": 1, "descriptionID": 64932, "parentGroupID": 787}
497	789	{"_key": 789, "iconID": 2703, "nameID": 66007, "hasTypes": 1, "descriptionID": 64933, "parentGroupID": 787}
498	790	{"_key": 790, "iconID": 2703, "nameID": 66008, "hasTypes": 1, "descriptionID": 64934, "parentGroupID": 787}
499	791	{"_key": 791, "iconID": 2703, "nameID": 66009, "hasTypes": 1, "descriptionID": 64935, "parentGroupID": 787}
500	792	{"_key": 792, "iconID": 2703, "nameID": 66010, "hasTypes": 1, "descriptionID": 64936, "parentGroupID": 286}
501	793	{"_key": 793, "iconID": 2703, "nameID": 66011, "hasTypes": 1, "descriptionID": 64937, "parentGroupID": 287}
502	794	{"_key": 794, "iconID": 2703, "nameID": 66012, "hasTypes": 1, "descriptionID": 64938, "parentGroupID": 288}
503	796	{"_key": 796, "iconID": 2703, "nameID": 66378, "hasTypes": 1, "descriptionID": 65304, "parentGroupID": 800}
504	798	{"_key": 798, "iconID": 2703, "nameID": 66379, "hasTypes": 0, "descriptionID": 65305, "parentGroupID": 800}
505	799	{"_key": 799, "iconID": 2703, "nameID": 66376, "hasTypes": 1, "descriptionID": 65302, "parentGroupID": 209}
506	800	{"_key": 800, "iconID": 2703, "nameID": 66013, "hasTypes": 0, "descriptionID": 64939, "parentGroupID": 1041}
507	801	{"_key": 801, "iconID": 2851, "nameID": 66014, "hasTypes": 1, "descriptionID": 64940, "parentGroupID": 143}
508	802	{"_key": 802, "iconID": 20959, "nameID": 66015, "hasTypes": 1, "parentGroupID": 65}
509	803	{"_key": 803, "iconID": 20966, "nameID": 66016, "hasTypes": 1, "parentGroupID": 65}
510	812	{"_key": 812, "iconID": 1443, "nameID": 66337, "hasTypes": 0, "descriptionID": 65263, "parentGroupID": 1381}
511	813	{"_key": 813, "iconID": 20959, "nameID": 66025, "hasTypes": 1, "descriptionID": 64951, "parentGroupID": 812}
512	814	{"_key": 814, "iconID": 20966, "nameID": 66026, "hasTypes": 1, "descriptionID": 64952, "parentGroupID": 812}
513	815	{"_key": 815, "iconID": 20967, "nameID": 66027, "hasTypes": 1, "descriptionID": 64953, "parentGroupID": 812}
514	816	{"_key": 816, "iconID": 20968, "nameID": 66028, "hasTypes": 1, "descriptionID": 64954, "parentGroupID": 812}
515	817	{"_key": 817, "iconID": 1443, "nameID": 66335, "hasTypes": 0, "descriptionID": 65261, "parentGroupID": 1381}
516	818	{"_key": 818, "iconID": 20959, "nameID": 66029, "hasTypes": 1, "descriptionID": 64955, "parentGroupID": 817}
517	819	{"_key": 819, "iconID": 20966, "nameID": 66030, "hasTypes": 1, "descriptionID": 64956, "parentGroupID": 817}
518	820	{"_key": 820, "iconID": 20967, "nameID": 66031, "hasTypes": 1, "descriptionID": 64957, "parentGroupID": 817}
519	821	{"_key": 821, "iconID": 20968, "nameID": 66032, "hasTypes": 1, "descriptionID": 64958, "parentGroupID": 817}
520	822	{"_key": 822, "iconID": 1443, "nameID": 66331, "hasTypes": 0, "descriptionID": 65257, "parentGroupID": 1375}
521	823	{"_key": 823, "iconID": 1443, "nameID": 66450, "hasTypes": 0, "descriptionID": 65376, "parentGroupID": 1373}
522	824	{"_key": 824, "iconID": 1443, "nameID": 66326, "hasTypes": 0, "descriptionID": 65252, "parentGroupID": 1368}
523	825	{"_key": 825, "iconID": 20959, "nameID": 66033, "hasTypes": 1, "descriptionID": 64959, "parentGroupID": 822}
524	826	{"_key": 826, "iconID": 20959, "nameID": 66034, "hasTypes": 1, "descriptionID": 64960, "parentGroupID": 823}
525	827	{"_key": 827, "iconID": 20959, "nameID": 66035, "hasTypes": 1, "descriptionID": 64961, "parentGroupID": 824}
526	828	{"_key": 828, "iconID": 20966, "nameID": 66036, "hasTypes": 1, "descriptionID": 64962, "parentGroupID": 822}
527	829	{"_key": 829, "iconID": 20966, "nameID": 66037, "hasTypes": 1, "descriptionID": 64963, "parentGroupID": 823}
528	830	{"_key": 830, "iconID": 20966, "nameID": 66038, "hasTypes": 1, "descriptionID": 64964, "parentGroupID": 824}
529	831	{"_key": 831, "iconID": 20967, "nameID": 66039, "hasTypes": 1, "descriptionID": 64965, "parentGroupID": 822}
530	832	{"_key": 832, "iconID": 20967, "nameID": 66040, "hasTypes": 1, "descriptionID": 64966, "parentGroupID": 823}
531	833	{"_key": 833, "iconID": 20967, "nameID": 66041, "hasTypes": 1, "descriptionID": 64967, "parentGroupID": 824}
532	834	{"_key": 834, "iconID": 20968, "nameID": 66042, "hasTypes": 1, "descriptionID": 64968, "parentGroupID": 822}
533	835	{"_key": 835, "iconID": 20968, "nameID": 66043, "hasTypes": 1, "descriptionID": 64969, "parentGroupID": 823}
534	836	{"_key": 836, "iconID": 20968, "nameID": 66044, "hasTypes": 1, "descriptionID": 64970, "parentGroupID": 824}
535	837	{"_key": 837, "iconID": 1084, "nameID": 66045, "hasTypes": 1, "descriptionID": 64971, "parentGroupID": 159}
536	838	{"_key": 838, "iconID": 1084, "nameID": 66046, "hasTypes": 1, "descriptionID": 64972, "parentGroupID": 159}
537	839	{"_key": 839, "iconID": 1084, "nameID": 66047, "hasTypes": 1, "descriptionID": 64973, "parentGroupID": 159}
538	840	{"_key": 840, "iconID": 1084, "nameID": 66316, "hasTypes": 1, "descriptionID": 65242, "parentGroupID": 2410}
539	841	{"_key": 841, "iconID": 1084, "nameID": 66048, "hasTypes": 1, "descriptionID": 64974, "parentGroupID": 157}
540	842	{"_key": 842, "iconID": 1084, "nameID": 66049, "hasTypes": 1, "descriptionID": 64975, "parentGroupID": 157}
541	843	{"_key": 843, "iconID": 1084, "nameID": 66050, "hasTypes": 1, "descriptionID": 64976, "parentGroupID": 157}
542	845	{"_key": 845, "iconID": 1004, "nameID": 66051, "hasTypes": 0, "descriptionID": 64977, "parentGroupID": 99}
543	846	{"_key": 846, "iconID": 1287, "nameID": 66052, "hasTypes": 0, "descriptionID": 64978, "parentGroupID": 99}
544	847	{"_key": 847, "iconID": 1291, "nameID": 66053, "hasTypes": 0, "descriptionID": 64979, "parentGroupID": 99}
545	848	{"_key": 848, "iconID": 1047, "nameID": 66054, "hasTypes": 0, "descriptionID": 64980, "parentGroupID": 100}
546	849	{"_key": 849, "iconID": 1310, "nameID": 66055, "hasTypes": 0, "descriptionID": 64981, "parentGroupID": 100}
547	850	{"_key": 850, "iconID": 1311, "nameID": 66056, "hasTypes": 0, "descriptionID": 64982, "parentGroupID": 100}
548	851	{"_key": 851, "iconID": 1142, "nameID": 66218, "hasTypes": 0, "descriptionID": 65144, "parentGroupID": 101}
549	852	{"_key": 852, "iconID": 1145, "nameID": 66057, "hasTypes": 0, "descriptionID": 64983, "parentGroupID": 101}
550	853	{"_key": 853, "iconID": 1140, "nameID": 66058, "hasTypes": 0, "descriptionID": 64984, "parentGroupID": 101}
551	854	{"_key": 854, "iconID": 1287, "nameID": 66059, "hasTypes": 1, "descriptionID": 64985, "parentGroupID": 846}
552	855	{"_key": 855, "iconID": 1287, "nameID": 66060, "hasTypes": 1, "descriptionID": 64986, "parentGroupID": 846}
553	856	{"_key": 856, "iconID": 1287, "nameID": 66061, "hasTypes": 1, "descriptionID": 64987, "parentGroupID": 846}
554	857	{"_key": 857, "iconID": 1291, "nameID": 66062, "hasTypes": 1, "descriptionID": 64988, "parentGroupID": 847}
555	858	{"_key": 858, "iconID": 1291, "nameID": 66063, "hasTypes": 1, "descriptionID": 64989, "parentGroupID": 847}
556	859	{"_key": 859, "iconID": 1291, "nameID": 66064, "hasTypes": 1, "descriptionID": 64990, "parentGroupID": 847}
557	860	{"_key": 860, "iconID": 1310, "nameID": 66065, "hasTypes": 1, "descriptionID": 64991, "parentGroupID": 849}
558	861	{"_key": 861, "iconID": 1310, "nameID": 66066, "hasTypes": 1, "descriptionID": 64992, "parentGroupID": 849}
559	862	{"_key": 862, "iconID": 1310, "nameID": 66067, "hasTypes": 1, "descriptionID": 64993, "parentGroupID": 849}
560	863	{"_key": 863, "iconID": 1311, "nameID": 66068, "hasTypes": 1, "descriptionID": 64994, "parentGroupID": 850}
561	864	{"_key": 864, "iconID": 1311, "nameID": 66069, "hasTypes": 1, "descriptionID": 64995, "parentGroupID": 850}
562	865	{"_key": 865, "iconID": 1311, "nameID": 66070, "hasTypes": 1, "descriptionID": 64996, "parentGroupID": 850}
563	866	{"_key": 866, "iconID": 1145, "nameID": 66071, "hasTypes": 1, "descriptionID": 64997, "parentGroupID": 852}
564	867	{"_key": 867, "iconID": 1145, "nameID": 66072, "hasTypes": 1, "descriptionID": 64998, "parentGroupID": 852}
565	868	{"_key": 868, "iconID": 1145, "nameID": 66073, "hasTypes": 1, "descriptionID": 64999, "parentGroupID": 852}
566	869	{"_key": 869, "iconID": 1140, "nameID": 66074, "hasTypes": 1, "descriptionID": 65000, "parentGroupID": 853}
567	870	{"_key": 870, "iconID": 1140, "nameID": 66075, "hasTypes": 1, "descriptionID": 65001, "parentGroupID": 853}
568	871	{"_key": 871, "iconID": 1140, "nameID": 66076, "hasTypes": 1, "descriptionID": 65002, "parentGroupID": 853}
569	872	{"_key": 872, "iconID": 2986, "nameID": 66077, "hasTypes": 1, "descriptionID": 65003, "parentGroupID": 656}
570	874	{"_key": 874, "iconID": 1443, "nameID": 66344, "hasTypes": 1, "descriptionID": 65270, "parentGroupID": 1384}
571	878	{"_key": 878, "iconID": 2703, "nameID": 66079, "hasTypes": 0, "descriptionID": 65005, "parentGroupID": 204}
572	879	{"_key": 879, "iconID": 2703, "nameID": 66080, "hasTypes": 0, "descriptionID": 65006, "parentGroupID": 204}
573	880	{"_key": 880, "iconID": 2703, "nameID": 66081, "hasTypes": 0, "descriptionID": 65007, "parentGroupID": 204}
574	881	{"_key": 881, "iconID": 2703, "nameID": 66082, "hasTypes": 0, "descriptionID": 65008, "parentGroupID": 204}
575	882	{"_key": 882, "iconID": 2703, "nameID": 66083, "hasTypes": 0, "descriptionID": 65009, "parentGroupID": 204}
576	883	{"_key": 883, "iconID": 2703, "nameID": 66370, "hasTypes": 0, "descriptionID": 65296, "parentGroupID": 204}
577	884	{"_key": 884, "iconID": 2703, "nameID": 66084, "hasTypes": 1, "descriptionID": 65010, "parentGroupID": 878}
578	885	{"_key": 885, "iconID": 2703, "nameID": 66085, "hasTypes": 1, "descriptionID": 65011, "parentGroupID": 878}
579	886	{"_key": 886, "iconID": 2703, "nameID": 66086, "hasTypes": 1, "descriptionID": 65012, "parentGroupID": 878}
580	887	{"_key": 887, "iconID": 2703, "nameID": 66087, "hasTypes": 1, "descriptionID": 65013, "parentGroupID": 878}
581	888	{"_key": 888, "iconID": 2703, "nameID": 66088, "hasTypes": 1, "descriptionID": 65014, "parentGroupID": 879}
582	889	{"_key": 889, "iconID": 2703, "nameID": 66089, "hasTypes": 1, "descriptionID": 65015, "parentGroupID": 879}
583	890	{"_key": 890, "iconID": 2703, "nameID": 66090, "hasTypes": 1, "descriptionID": 65016, "parentGroupID": 879}
584	891	{"_key": 891, "iconID": 2703, "nameID": 66091, "hasTypes": 1, "descriptionID": 65017, "parentGroupID": 879}
585	892	{"_key": 892, "iconID": 2703, "nameID": 66092, "hasTypes": 1, "descriptionID": 65018, "parentGroupID": 880}
586	893	{"_key": 893, "iconID": 2703, "nameID": 66093, "hasTypes": 1, "descriptionID": 65019, "parentGroupID": 880}
587	894	{"_key": 894, "iconID": 2703, "nameID": 66094, "hasTypes": 1, "descriptionID": 65020, "parentGroupID": 880}
588	895	{"_key": 895, "iconID": 2703, "nameID": 66095, "hasTypes": 1, "descriptionID": 65021, "parentGroupID": 880}
589	896	{"_key": 896, "iconID": 2703, "nameID": 66096, "hasTypes": 1, "descriptionID": 65022, "parentGroupID": 881}
590	897	{"_key": 897, "iconID": 2703, "nameID": 66097, "hasTypes": 1, "descriptionID": 65023, "parentGroupID": 881}
591	898	{"_key": 898, "iconID": 2703, "nameID": 66098, "hasTypes": 1, "descriptionID": 65024, "parentGroupID": 881}
592	899	{"_key": 899, "iconID": 2703, "nameID": 66099, "hasTypes": 1, "descriptionID": 65025, "parentGroupID": 881}
593	900	{"_key": 900, "iconID": 2703, "nameID": 66100, "hasTypes": 1, "descriptionID": 65026, "parentGroupID": 882}
594	901	{"_key": 901, "iconID": 2703, "nameID": 66101, "hasTypes": 1, "descriptionID": 65027, "parentGroupID": 882}
595	902	{"_key": 902, "iconID": 2703, "nameID": 66102, "hasTypes": 1, "descriptionID": 65028, "parentGroupID": 882}
596	903	{"_key": 903, "iconID": 2703, "nameID": 66103, "hasTypes": 1, "descriptionID": 65029, "parentGroupID": 882}
597	904	{"_key": 904, "iconID": 2703, "nameID": 66104, "hasTypes": 1, "descriptionID": 65030, "parentGroupID": 883}
598	905	{"_key": 905, "iconID": 2703, "nameID": 66105, "hasTypes": 1, "descriptionID": 65031, "parentGroupID": 1578}
599	910	{"_key": 910, "iconID": 1035, "nameID": 66110, "hasTypes": 1, "descriptionID": 65036, "parentGroupID": 663}
600	911	{"_key": 911, "iconID": 1084, "nameID": 66111, "hasTypes": 1, "descriptionID": 65037, "parentGroupID": 159}
601	912	{"_key": 912, "iconID": 2934, "nameID": 66112, "hasTypes": 0, "descriptionID": 65038, "parentGroupID": 10}
602	913	{"_key": 913, "iconID": 2703, "nameID": 66113, "hasTypes": 1, "descriptionID": 65039, "parentGroupID": 210}
603	914	{"_key": 914, "iconID": 1335, "nameID": 66114, "hasTypes": 1, "descriptionID": 65040, "parentGroupID": 115}
604	917	{"_key": 917, "iconID": 192, "nameID": 66117, "hasTypes": 1, "descriptionID": 65043, "parentGroupID": 117}
605	918	{"_key": 918, "iconID": 184, "nameID": 66118, "hasTypes": 1, "descriptionID": 65044, "parentGroupID": 580}
606	919	{"_key": 919, "iconID": 186, "nameID": 66119, "hasTypes": 1, "descriptionID": 65045, "parentGroupID": 581}
607	920	{"_key": 920, "iconID": 192, "nameID": 66120, "hasTypes": 1, "descriptionID": 65046, "parentGroupID": 117}
608	921	{"_key": 921, "iconID": 184, "nameID": 66121, "hasTypes": 1, "descriptionID": 65047, "parentGroupID": 580}
609	922	{"_key": 922, "iconID": 1352, "nameID": 66122, "hasTypes": 1, "descriptionID": 65048, "parentGroupID": 118}
610	923	{"_key": 923, "iconID": 1349, "nameID": 66123, "hasTypes": 1, "descriptionID": 65049, "parentGroupID": 387}
611	924	{"_key": 924, "iconID": 186, "nameID": 66124, "hasTypes": 1, "descriptionID": 65050, "parentGroupID": 581}
612	925	{"_key": 925, "iconID": 184, "nameID": 66125, "hasTypes": 1, "descriptionID": 65051, "parentGroupID": 580}
613	926	{"_key": 926, "iconID": 186, "nameID": 66126, "hasTypes": 1, "descriptionID": 65052, "parentGroupID": 581}
614	927	{"_key": 927, "iconID": 192, "nameID": 66127, "hasTypes": 1, "descriptionID": 65053, "parentGroupID": 117}
615	928	{"_key": 928, "iconID": 1352, "nameID": 66128, "hasTypes": 1, "descriptionID": 65054, "parentGroupID": 118}
616	929	{"_key": 929, "iconID": 1349, "nameID": 66129, "hasTypes": 1, "descriptionID": 65055, "parentGroupID": 387}
617	930	{"_key": 930, "iconID": 1352, "nameID": 66130, "hasTypes": 1, "descriptionID": 65056, "parentGroupID": 118}
618	931	{"_key": 931, "iconID": 1349, "nameID": 66131, "hasTypes": 1, "descriptionID": 65057, "parentGroupID": 387}
619	932	{"_key": 932, "iconID": 2222, "nameID": 66306, "hasTypes": 1, "descriptionID": 65232, "parentGroupID": 1285}
620	933	{"_key": 933, "iconID": 2222, "nameID": 66307, "hasTypes": 1, "descriptionID": 65233, "parentGroupID": 1285}
621	935	{"_key": 935, "iconID": 1046, "nameID": 66132, "hasTypes": 1, "descriptionID": 65058, "parentGroupID": 1713}
622	937	{"_key": 937, "iconID": 2703, "nameID": 66133, "hasTypes": 1, "descriptionID": 65059, "parentGroupID": 1711}
623	938	{"_key": 938, "iconID": 2989, "nameID": 66134, "hasTypes": 1, "descriptionID": 65060, "parentGroupID": 9}
624	939	{"_key": 939, "iconID": 2703, "nameID": 66135, "hasTypes": 1, "descriptionID": 65061, "parentGroupID": 209}
625	940	{"_key": 940, "iconID": 1192, "nameID": 66237, "hasTypes": 1, "descriptionID": 65163, "parentGroupID": 19}
626	943	{"_key": 943, "iconID": 2703, "nameID": 66137, "hasTypes": 0, "descriptionID": 65063, "parentGroupID": 2}
627	944	{"_key": 944, "iconID": 2703, "nameID": 66273, "hasTypes": 0, "descriptionID": 65199, "parentGroupID": 943}
628	945	{"_key": 945, "iconID": 2703, "nameID": 66285, "hasTypes": 0, "descriptionID": 65211, "parentGroupID": 943}
629	946	{"_key": 946, "iconID": 2703, "nameID": 66286, "hasTypes": 0, "descriptionID": 65212, "parentGroupID": 943}
630	948	{"_key": 948, "iconID": 2703, "nameID": 66288, "hasTypes": 0, "descriptionID": 65214, "parentGroupID": 943}
631	949	{"_key": 949, "iconID": 2703, "nameID": 66289, "hasTypes": 0, "descriptionID": 65215, "parentGroupID": 943}
632	950	{"_key": 950, "iconID": 2703, "nameID": 66290, "hasTypes": 0, "descriptionID": 65216, "parentGroupID": 943}
633	951	{"_key": 951, "iconID": 2703, "nameID": 66291, "hasTypes": 0, "descriptionID": 65217, "parentGroupID": 943}
634	952	{"_key": 952, "iconID": 2703, "nameID": 66292, "hasTypes": 0, "descriptionID": 65218, "parentGroupID": 943}
635	953	{"_key": 953, "iconID": 2703, "nameID": 66314, "hasTypes": 0, "descriptionID": 65240, "parentGroupID": 943}
636	954	{"_key": 954, "iconID": 2703, "nameID": 66293, "hasTypes": 0, "descriptionID": 65219, "parentGroupID": 943}
637	955	{"_key": 955, "iconID": 2887, "nameID": 66538, "hasTypes": 0, "descriptionID": 65463}
638	956	{"_key": 956, "iconID": 3194, "nameID": 66274, "hasTypes": 0, "descriptionID": 65200, "parentGroupID": 1111}
639	957	{"_key": 957, "iconID": 3196, "nameID": 66275, "hasTypes": 0, "descriptionID": 65201, "parentGroupID": 1111}
640	958	{"_key": 958, "iconID": 3200, "nameID": 66276, "hasTypes": 0, "descriptionID": 65202, "parentGroupID": 1111}
641	960	{"_key": 960, "iconID": 3198, "nameID": 66278, "hasTypes": 0, "descriptionID": 65204, "parentGroupID": 1111}
642	961	{"_key": 961, "iconID": 3195, "nameID": 66279, "hasTypes": 0, "descriptionID": 65205, "parentGroupID": 1111}
643	962	{"_key": 962, "iconID": 3203, "nameID": 66280, "hasTypes": 0, "descriptionID": 65206, "parentGroupID": 1111}
644	963	{"_key": 963, "iconID": 3202, "nameID": 66281, "hasTypes": 0, "descriptionID": 65207, "parentGroupID": 1111}
645	964	{"_key": 964, "iconID": 3197, "nameID": 66282, "hasTypes": 0, "descriptionID": 65208, "parentGroupID": 1111}
646	965	{"_key": 965, "iconID": 3193, "nameID": 66283, "hasTypes": 0, "descriptionID": 65209, "parentGroupID": 1111}
647	967	{"_key": 967, "iconID": 1046, "nameID": 66207, "hasTypes": 1, "descriptionID": 65133, "parentGroupID": 677}
648	968	{"_key": 968, "iconID": 186, "nameID": 66139, "hasTypes": 0, "descriptionID": 65065, "parentGroupID": 114}
649	971	{"_key": 971, "iconID": 186, "nameID": 66229, "hasTypes": 1, "descriptionID": 65155, "parentGroupID": 968}
650	972	{"_key": 972, "iconID": 186, "nameID": 66230, "hasTypes": 1, "descriptionID": 65156, "parentGroupID": 968}
651	973	{"_key": 973, "iconID": 186, "nameID": 66231, "hasTypes": 1, "descriptionID": 65157, "parentGroupID": 968}
652	974	{"_key": 974, "iconID": 3241, "nameID": 66186, "hasTypes": 1, "descriptionID": 65112, "parentGroupID": 140}
653	975	{"_key": 975, "iconID": 2703, "nameID": 66153, "hasTypes": 1, "descriptionID": 65079, "parentGroupID": 314}
654	977	{"_key": 977, "iconID": 3211, "nameID": 66140, "hasTypes": 0, "descriptionID": 65066, "parentGroupID": 24}
655	979	{"_key": 979, "iconID": 3201, "nameID": 66284, "hasTypes": 0, "descriptionID": 65210, "parentGroupID": 1111}
656	983	{"_key": 983, "iconID": 3220, "nameID": 66242, "hasTypes": 1, "descriptionID": 65168, "parentGroupID": 1032}
657	986	{"_key": 986, "iconID": 1288, "nameID": 66141, "hasTypes": 0, "descriptionID": 65067, "parentGroupID": 99}
658	987	{"_key": 987, "iconID": 1288, "nameID": 66209, "hasTypes": 1, "descriptionID": 65135, "parentGroupID": 986}
659	988	{"_key": 988, "iconID": 1288, "nameID": 66210, "hasTypes": 1, "descriptionID": 65136, "parentGroupID": 986}
660	989	{"_key": 989, "iconID": 1288, "nameID": 66211, "hasTypes": 1, "descriptionID": 65137, "parentGroupID": 986}
661	990	{"_key": 990, "iconID": 1313, "nameID": 66215, "hasTypes": 0, "descriptionID": 65141, "parentGroupID": 100}
662	991	{"_key": 991, "iconID": 1313, "nameID": 66214, "hasTypes": 1, "descriptionID": 65140, "parentGroupID": 990}
663	992	{"_key": 992, "iconID": 1313, "nameID": 66216, "hasTypes": 1, "descriptionID": 65142, "parentGroupID": 990}
664	993	{"_key": 993, "iconID": 1313, "nameID": 66217, "hasTypes": 1, "descriptionID": 65143, "parentGroupID": 990}
665	994	{"_key": 994, "iconID": 1141, "nameID": 66219, "hasTypes": 0, "descriptionID": 65145, "parentGroupID": 101}
666	995	{"_key": 995, "iconID": 1141, "nameID": 66220, "hasTypes": 1, "descriptionID": 65146, "parentGroupID": 994}
667	996	{"_key": 996, "iconID": 1141, "nameID": 66221, "hasTypes": 1, "descriptionID": 65147, "parentGroupID": 994}
668	997	{"_key": 997, "iconID": 1141, "nameID": 66222, "hasTypes": 1, "descriptionID": 65148, "parentGroupID": 994}
669	998	{"_key": 998, "iconID": 192, "nameID": 66224, "hasTypes": 1, "descriptionID": 65150, "parentGroupID": 117}
670	999	{"_key": 999, "iconID": 1352, "nameID": 66225, "hasTypes": 1, "descriptionID": 65151, "parentGroupID": 118}
671	1000	{"_key": 1000, "iconID": 1349, "nameID": 66226, "hasTypes": 1, "descriptionID": 65152, "parentGroupID": 387}
672	1001	{"_key": 1001, "iconID": 184, "nameID": 66227, "hasTypes": 1, "descriptionID": 65153, "parentGroupID": 580}
673	1002	{"_key": 1002, "iconID": 186, "nameID": 66228, "hasTypes": 1, "descriptionID": 65154, "parentGroupID": 581}
674	1003	{"_key": 1003, "iconID": 186, "nameID": 66232, "hasTypes": 1, "descriptionID": 65158, "parentGroupID": 968}
675	1004	{"_key": 1004, "iconID": 1313, "nameID": 66213, "hasTypes": 1, "descriptionID": 65139, "parentGroupID": 990}
676	1006	{"_key": 1006, "iconID": 1288, "nameID": 66212, "hasTypes": 1, "descriptionID": 65138, "parentGroupID": 986}
677	1007	{"_key": 1007, "iconID": 1141, "nameID": 66223, "hasTypes": 1, "descriptionID": 65149, "parentGroupID": 994}
678	1008	{"_key": 1008, "iconID": 2703, "nameID": 66375, "hasTypes": 1, "descriptionID": 65301, "parentGroupID": 406}
679	1009	{"_key": 1009, "iconID": 2222, "nameID": 66308, "hasTypes": 1, "descriptionID": 65234, "parentGroupID": 480}
680	1010	{"_key": 1010, "iconID": 2222, "nameID": 66309, "hasTypes": 1, "descriptionID": 65235, "parentGroupID": 1285}
681	1011	{"_key": 1011, "iconID": 2222, "nameID": 66310, "hasTypes": 1, "descriptionID": 65236, "parentGroupID": 1285}
682	1012	{"_key": 1012, "iconID": 2222, "nameID": 66311, "hasTypes": 1, "descriptionID": 65237, "parentGroupID": 1285}
683	1013	{"_key": 1013, "iconID": 2222, "nameID": 66312, "hasTypes": 1, "descriptionID": 65238, "parentGroupID": 1285}
684	1014	{"_key": 1014, "iconID": 2677, "nameID": 66187, "hasTypes": 1, "descriptionID": 65113, "parentGroupID": 10}
685	1015	{"_key": 1015, "iconID": 3281, "nameID": 66233, "hasTypes": 1, "descriptionID": 65159, "parentGroupID": 11}
686	1016	{"_key": 1016, "iconID": 2703, "nameID": 66154, "hasTypes": 1, "descriptionID": 65080, "parentGroupID": 211}
687	1018	{"_key": 1018, "iconID": 80, "nameID": 66199, "hasTypes": 0, "descriptionID": 65125, "parentGroupID": 14}
688	1019	{"_key": 1019, "iconID": 2703, "nameID": 66152, "hasTypes": 1, "descriptionID": 65078, "parentGroupID": 210}
689	1021	{"_key": 1021, "iconID": 3303, "nameID": 66247, "hasTypes": 0, "descriptionID": 65173, "parentGroupID": 1035}
690	1022	{"_key": 1022, "iconID": 3303, "nameID": 66248, "hasTypes": 0, "parentGroupID": 1021}
691	1027	{"_key": 1027, "iconID": 3303, "nameID": 66252, "hasTypes": 1, "descriptionID": 65178, "parentGroupID": 1021}
692	1028	{"_key": 1028, "iconID": 2703, "nameID": 66156, "hasTypes": 1, "descriptionID": 65082, "parentGroupID": 2237}
693	1029	{"_key": 1029, "iconID": 2703, "nameID": 66157, "hasTypes": 1, "descriptionID": 65083, "parentGroupID": 357}
694	1030	{"_key": 1030, "iconID": 2703, "nameID": 66158, "hasTypes": 1, "descriptionID": 65084, "parentGroupID": 357}
695	1031	{"_key": 1031, "iconID": 1277, "nameID": 66240, "hasTypes": 0, "descriptionID": 65166, "parentGroupID": 533}
696	1032	{"_key": 1032, "iconID": 3219, "nameID": 66241, "hasTypes": 0, "descriptionID": 65167, "parentGroupID": 533}
697	1033	{"_key": 1033, "iconID": 2697, "nameID": 66244, "hasTypes": 1, "descriptionID": 65170, "parentGroupID": 533}
698	1034	{"_key": 1034, "iconID": 2567, "nameID": 66245, "hasTypes": 0, "descriptionID": 65171, "parentGroupID": 533}
699	1035	{"_key": 1035, "iconID": 1436, "nameID": 66246, "hasTypes": 0, "descriptionID": 65172, "parentGroupID": 475}
700	1037	{"_key": 1037, "iconID": 3074, "nameID": 66182, "hasTypes": 1, "descriptionID": 65108, "parentGroupID": 1713}
701	1038	{"_key": 1038, "iconID": 2526, "nameID": 66183, "hasTypes": 1, "descriptionID": 65109, "parentGroupID": 1713}
702	1039	{"_key": 1039, "iconID": 1061, "nameID": 66184, "hasTypes": 1, "descriptionID": 65110, "parentGroupID": 1713}
703	1040	{"_key": 1040, "iconID": 2527, "nameID": 66185, "hasTypes": 1, "descriptionID": 65111, "parentGroupID": 1713}
704	1041	{"_key": 1041, "iconID": 2703, "nameID": 66142, "hasTypes": 0, "descriptionID": 65068, "parentGroupID": 2}
705	1045	{"_key": 1045, "iconID": 2703, "nameID": 66371, "hasTypes": 0, "descriptionID": 65297, "parentGroupID": 204}
706	1046	{"_key": 1046, "iconID": 2703, "nameID": 66151, "hasTypes": 1, "descriptionID": 65077, "parentGroupID": 1045}
707	1047	{"_key": 1047, "iconID": 1443, "nameID": 66339, "hasTypes": 0, "descriptionID": 65265, "parentGroupID": 1381}
708	1048	{"_key": 1048, "iconID": 27058, "nameID": 66161, "hasTypes": 1, "descriptionID": 65087, "parentGroupID": 1047}
709	1049	{"_key": 1049, "iconID": 80, "nameID": 66188, "hasTypes": 1, "descriptionID": 65114, "parentGroupID": 134}
710	1050	{"_key": 1050, "iconID": 80, "nameID": 66189, "hasTypes": 1, "descriptionID": 65115, "parentGroupID": 134}
711	1051	{"_key": 1051, "iconID": 80, "nameID": 66190, "hasTypes": 1, "descriptionID": 65116, "parentGroupID": 134}
712	1052	{"_key": 1052, "iconID": 80, "nameID": 66191, "hasTypes": 1, "descriptionID": 65117, "parentGroupID": 134}
713	1053	{"_key": 1053, "iconID": 80, "nameID": 66196, "hasTypes": 1, "descriptionID": 65122, "parentGroupID": 538}
714	1054	{"_key": 1054, "iconID": 80, "nameID": 66197, "hasTypes": 1, "descriptionID": 65123, "parentGroupID": 538}
715	1055	{"_key": 1055, "iconID": 80, "nameID": 66198, "hasTypes": 1, "descriptionID": 65124, "parentGroupID": 538}
716	1056	{"_key": 1056, "iconID": 80, "nameID": 66192, "hasTypes": 1, "descriptionID": 65118, "parentGroupID": 537}
717	1057	{"_key": 1057, "iconID": 80, "nameID": 66193, "hasTypes": 1, "descriptionID": 65119, "parentGroupID": 537}
718	1058	{"_key": 1058, "iconID": 80, "nameID": 66194, "hasTypes": 1, "descriptionID": 65120, "parentGroupID": 537}
719	1059	{"_key": 1059, "iconID": 80, "nameID": 66195, "hasTypes": 1, "descriptionID": 65121, "parentGroupID": 537}
720	1060	{"_key": 1060, "iconID": 80, "nameID": 66200, "hasTypes": 1, "descriptionID": 65126, "parentGroupID": 1018}
721	1061	{"_key": 1061, "iconID": 80, "nameID": 66201, "hasTypes": 1, "descriptionID": 65127, "parentGroupID": 1018}
722	1062	{"_key": 1062, "iconID": 80, "nameID": 66202, "hasTypes": 1, "descriptionID": 65128, "parentGroupID": 1018}
723	1063	{"_key": 1063, "iconID": 80, "nameID": 66203, "hasTypes": 1, "descriptionID": 65129, "parentGroupID": 1018}
724	1065	{"_key": 1065, "iconID": 1443, "nameID": 66321, "hasTypes": 0, "descriptionID": 65247, "parentGroupID": 1364}
725	1066	{"_key": 1066, "iconID": 20959, "nameID": 66162, "hasTypes": 1, "descriptionID": 65088, "parentGroupID": 1065}
726	1067	{"_key": 1067, "iconID": 20966, "nameID": 66163, "hasTypes": 1, "descriptionID": 65089, "parentGroupID": 1065}
727	1068	{"_key": 1068, "iconID": 20967, "nameID": 66164, "hasTypes": 1, "descriptionID": 65090, "parentGroupID": 1065}
728	1069	{"_key": 1069, "iconID": 20968, "nameID": 66165, "hasTypes": 1, "descriptionID": 65091, "parentGroupID": 1065}
729	1070	{"_key": 1070, "iconID": 1443, "nameID": 66325, "hasTypes": 0, "descriptionID": 65251, "parentGroupID": 1368}
730	1071	{"_key": 1071, "iconID": 20959, "nameID": 66166, "hasTypes": 1, "descriptionID": 65092, "parentGroupID": 1070}
731	1072	{"_key": 1072, "iconID": 20966, "nameID": 66167, "hasTypes": 1, "descriptionID": 65093, "parentGroupID": 1070}
732	1073	{"_key": 1073, "iconID": 20967, "nameID": 66168, "hasTypes": 1, "descriptionID": 65094, "parentGroupID": 1070}
733	1074	{"_key": 1074, "iconID": 20968, "nameID": 66169, "hasTypes": 1, "descriptionID": 65095, "parentGroupID": 1070}
734	1075	{"_key": 1075, "iconID": 1443, "nameID": 66334, "hasTypes": 0, "descriptionID": 65260, "parentGroupID": 1377}
735	1076	{"_key": 1076, "iconID": 20959, "nameID": 66170, "hasTypes": 1, "descriptionID": 65096, "parentGroupID": 1075}
736	1077	{"_key": 1077, "iconID": 20966, "nameID": 66171, "hasTypes": 1, "descriptionID": 65097, "parentGroupID": 1075}
737	1078	{"_key": 1078, "iconID": 20967, "nameID": 66172, "hasTypes": 1, "descriptionID": 65098, "parentGroupID": 1075}
738	1079	{"_key": 1079, "iconID": 20968, "nameID": 66173, "hasTypes": 1, "descriptionID": 65099, "parentGroupID": 1075}
739	1080	{"_key": 1080, "iconID": 1443, "nameID": 66333, "hasTypes": 0, "descriptionID": 65259, "parentGroupID": 1377}
740	1081	{"_key": 1081, "iconID": 20959, "nameID": 66174, "hasTypes": 1, "descriptionID": 65100, "parentGroupID": 1080}
741	1082	{"_key": 1082, "iconID": 20966, "nameID": 66175, "hasTypes": 1, "descriptionID": 65101, "parentGroupID": 1080}
742	1083	{"_key": 1083, "iconID": 20967, "nameID": 66176, "hasTypes": 1, "descriptionID": 65102, "parentGroupID": 1080}
743	1084	{"_key": 1084, "iconID": 20968, "nameID": 66177, "hasTypes": 1, "descriptionID": 65103, "parentGroupID": 1080}
744	1085	{"_key": 1085, "iconID": 21489, "nameID": 66208, "hasTypes": 1, "descriptionID": 65134, "parentGroupID": 657}
745	1086	{"_key": 1086, "iconID": 1041, "nameID": 66204, "hasTypes": 1, "descriptionID": 65130, "parentGroupID": 132}
746	1087	{"_key": 1087, "iconID": 98, "nameID": 66205, "hasTypes": 1, "descriptionID": 65131, "parentGroupID": 132}
747	1088	{"_key": 1088, "iconID": 97, "nameID": 66206, "hasTypes": 1, "descriptionID": 65132, "parentGroupID": 132}
748	1089	{"_key": 1089, "iconID": 1443, "nameID": 66336, "hasTypes": 0, "descriptionID": 65262, "parentGroupID": 1381}
749	1090	{"_key": 1090, "iconID": 20959, "nameID": 66178, "hasTypes": 1, "descriptionID": 65104, "parentGroupID": 1089}
750	1091	{"_key": 1091, "iconID": 20966, "nameID": 66179, "hasTypes": 1, "descriptionID": 65105, "parentGroupID": 1089}
751	1092	{"_key": 1092, "iconID": 20967, "nameID": 66180, "hasTypes": 1, "descriptionID": 65106, "parentGroupID": 1089}
752	1093	{"_key": 1093, "iconID": 20968, "nameID": 66181, "hasTypes": 1, "descriptionID": 65107, "parentGroupID": 1089}
753	1094	{"_key": 1094, "iconID": 3345, "nameID": 66234, "hasTypes": 1, "descriptionID": 65160, "parentGroupID": 11}
754	1097	{"_key": 1097, "iconID": 2703, "nameID": 66380, "hasTypes": 0, "descriptionID": 65306, "parentGroupID": 800}
755	1103	{"_key": 1103, "iconID": 3302, "nameID": 66235, "hasTypes": 1, "descriptionID": 65161, "parentGroupID": 11}
756	1105	{"_key": 1105, "iconID": 2703, "nameID": 66155, "hasTypes": 1, "descriptionID": 65081, "parentGroupID": 211}
757	1109	{"_key": 1109, "iconID": 3755, "nameID": 66475, "hasTypes": 1, "descriptionID": 65401, "parentGroupID": 19}
758	1110	{"_key": 1110, "iconID": 33, "nameID": 66263, "hasTypes": 1, "descriptionID": 65189, "parentGroupID": 150}
759	1111	{"_key": 1111, "iconID": 3203, "nameID": 66264, "hasTypes": 0, "descriptionID": 65190, "parentGroupID": 955}
760	1112	{"_key": 1112, "iconID": 3641, "nameID": 66572, "hasTypes": 0, "descriptionID": 65497, "parentGroupID": 955}
761	1122	{"_key": 1122, "iconID": 3636, "nameID": 66582, "hasTypes": 1, "descriptionID": 65507, "parentGroupID": 1610}
762	1123	{"_key": 1123, "iconID": 3636, "nameID": 66583, "hasTypes": 1, "descriptionID": 65508, "parentGroupID": 1625}
763	1124	{"_key": 1124, "iconID": 3636, "nameID": 66584, "hasTypes": 1, "descriptionID": 65509, "parentGroupID": 1627}
764	1125	{"_key": 1125, "iconID": 3636, "nameID": 66585, "hasTypes": 1, "descriptionID": 65510, "parentGroupID": 1626}
765	1126	{"_key": 1126, "iconID": 3631, "nameID": 66586, "hasTypes": 1, "descriptionID": 65511, "parentGroupID": 1610}
766	1127	{"_key": 1127, "iconID": 3631, "nameID": 66587, "hasTypes": 1, "descriptionID": 65512, "parentGroupID": 1625}
767	1128	{"_key": 1128, "iconID": 3631, "nameID": 66588, "hasTypes": 1, "descriptionID": 65513, "parentGroupID": 1626}
768	1129	{"_key": 1129, "iconID": 3631, "nameID": 66589, "hasTypes": 1, "descriptionID": 65514, "parentGroupID": 1627}
769	1130	{"_key": 1130, "iconID": 3641, "nameID": 66590, "hasTypes": 1, "descriptionID": 65515, "parentGroupID": 1610}
770	1131	{"_key": 1131, "iconID": 3641, "nameID": 66591, "hasTypes": 1, "descriptionID": 65516, "parentGroupID": 1625}
771	1132	{"_key": 1132, "iconID": 3641, "nameID": 66592, "hasTypes": 1, "descriptionID": 65517, "parentGroupID": 1627}
772	1133	{"_key": 1133, "iconID": 3641, "nameID": 66593, "hasTypes": 1, "descriptionID": 65518, "parentGroupID": 1626}
773	1134	{"_key": 1134, "iconID": 3646, "nameID": 66594, "hasTypes": 1, "descriptionID": 65519, "parentGroupID": 1610}
774	1135	{"_key": 1135, "iconID": 3646, "nameID": 66595, "hasTypes": 1, "descriptionID": 65520, "parentGroupID": 1625}
775	1136	{"_key": 1136, "iconID": 3646, "nameID": 66596, "hasTypes": 1, "descriptionID": 65521, "parentGroupID": 1627}
776	1137	{"_key": 1137, "iconID": 3646, "nameID": 66597, "hasTypes": 1, "descriptionID": 65522, "parentGroupID": 1626}
777	1138	{"_key": 1138, "iconID": 1443, "nameID": 66444, "hasTypes": 0, "descriptionID": 65370, "parentGroupID": 1368}
778	1139	{"_key": 1139, "iconID": 20959, "nameID": 66345, "hasTypes": 1, "descriptionID": 65271, "parentGroupID": 1138}
779	1140	{"_key": 1140, "iconID": 20966, "nameID": 66346, "hasTypes": 1, "descriptionID": 65272, "parentGroupID": 1138}
780	1141	{"_key": 1141, "iconID": 20967, "nameID": 66347, "hasTypes": 1, "descriptionID": 65273, "parentGroupID": 1138}
781	1142	{"_key": 1142, "iconID": 20968, "nameID": 66348, "hasTypes": 1, "descriptionID": 65274, "parentGroupID": 1138}
782	1147	{"_key": 1147, "iconID": 3721, "nameID": 66529, "hasTypes": 1, "descriptionID": 65454, "parentGroupID": 1035}
783	1191	{"_key": 1191, "iconID": 2703, "nameID": 66382, "hasTypes": 1, "descriptionID": 65308, "parentGroupID": 800}
784	1192	{"_key": 1192, "iconID": 1335, "nameID": 66466, "hasTypes": 1, "descriptionID": 65392, "parentGroupID": 115}
785	1193	{"_key": 1193, "iconID": 1346, "nameID": 66467, "hasTypes": 1, "descriptionID": 65393, "parentGroupID": 505}
786	1194	{"_key": 1194, "iconID": 1346, "nameID": 66468, "hasTypes": 1, "descriptionID": 65394, "parentGroupID": 505}
787	1195	{"_key": 1195, "iconID": 76, "nameID": 66463, "hasTypes": 1, "descriptionID": 65389, "parentGroupID": 135}
788	1196	{"_key": 1196, "iconID": 1042, "nameID": 66464, "hasTypes": 1, "descriptionID": 65390, "parentGroupID": 135}
789	1197	{"_key": 1197, "iconID": 92, "nameID": 66465, "hasTypes": 1, "descriptionID": 65391, "parentGroupID": 135}
790	1198	{"_key": 1198, "iconID": 2703, "nameID": 66369, "hasTypes": 1, "descriptionID": 65295, "parentGroupID": 1710}
791	1199	{"_key": 1199, "iconID": 1722, "nameID": 66472, "hasTypes": 1, "descriptionID": 65398, "parentGroupID": 120}
792	1200	{"_key": 1200, "iconID": 2663, "nameID": 66473, "hasTypes": 1, "descriptionID": 65399, "parentGroupID": 120}
793	1201	{"_key": 1201, "iconID": 1721, "nameID": 66474, "hasTypes": 1, "descriptionID": 65400, "parentGroupID": 120}
794	1202	{"_key": 1202, "iconID": 2703, "nameID": 66384, "hasTypes": 1, "descriptionID": 65310, "parentGroupID": 944}
795	1203	{"_key": 1203, "iconID": 2703, "nameID": 66385, "hasTypes": 1, "descriptionID": 65311, "parentGroupID": 944}
796	1204	{"_key": 1204, "iconID": 2703, "nameID": 66386, "hasTypes": 1, "descriptionID": 65312, "parentGroupID": 944}
797	1206	{"_key": 1206, "iconID": 3194, "nameID": 66539, "hasTypes": 1, "descriptionID": 65464, "parentGroupID": 956}
798	1207	{"_key": 1207, "iconID": 3194, "nameID": 66540, "hasTypes": 1, "descriptionID": 65465, "parentGroupID": 956}
799	1208	{"_key": 1208, "iconID": 3194, "nameID": 66541, "hasTypes": 1, "descriptionID": 65466, "parentGroupID": 956}
800	1210	{"_key": 1210, "iconID": 3196, "nameID": 66542, "hasTypes": 1, "descriptionID": 65467, "parentGroupID": 957}
801	1211	{"_key": 1211, "iconID": 3196, "nameID": 66543, "hasTypes": 1, "descriptionID": 65468, "parentGroupID": 957}
802	1212	{"_key": 1212, "iconID": 3196, "nameID": 66544, "hasTypes": 1, "descriptionID": 65469, "parentGroupID": 957}
803	1213	{"_key": 1213, "iconID": 3200, "nameID": 66545, "hasTypes": 1, "descriptionID": 65470, "parentGroupID": 958}
804	1214	{"_key": 1214, "iconID": 3200, "nameID": 66546, "hasTypes": 1, "descriptionID": 65471, "parentGroupID": 958}
805	1215	{"_key": 1215, "iconID": 3200, "nameID": 66547, "hasTypes": 1, "descriptionID": 65472, "parentGroupID": 958}
806	1219	{"_key": 1219, "iconID": 3198, "nameID": 66551, "hasTypes": 1, "descriptionID": 65476, "parentGroupID": 960}
807	1220	{"_key": 1220, "iconID": 3198, "nameID": 66552, "hasTypes": 1, "descriptionID": 65477, "parentGroupID": 960}
808	1221	{"_key": 1221, "iconID": 3198, "nameID": 66553, "hasTypes": 1, "descriptionID": 65478, "parentGroupID": 960}
809	1222	{"_key": 1222, "iconID": 3195, "nameID": 66554, "hasTypes": 1, "descriptionID": 65479, "parentGroupID": 961}
810	1223	{"_key": 1223, "iconID": 3195, "nameID": 66555, "hasTypes": 1, "descriptionID": 65480, "parentGroupID": 961}
811	1224	{"_key": 1224, "iconID": 3195, "nameID": 66556, "hasTypes": 1, "descriptionID": 65481, "parentGroupID": 961}
812	1225	{"_key": 1225, "iconID": 3203, "nameID": 66557, "hasTypes": 1, "descriptionID": 65482, "parentGroupID": 962}
813	1226	{"_key": 1226, "iconID": 3203, "nameID": 66558, "hasTypes": 1, "descriptionID": 65483, "parentGroupID": 962}
814	1227	{"_key": 1227, "iconID": 3203, "nameID": 66559, "hasTypes": 1, "descriptionID": 65484, "parentGroupID": 962}
815	1228	{"_key": 1228, "iconID": 3202, "nameID": 66560, "hasTypes": 1, "descriptionID": 65485, "parentGroupID": 963}
816	1229	{"_key": 1229, "iconID": 3202, "nameID": 66561, "hasTypes": 1, "descriptionID": 65486, "parentGroupID": 963}
817	1230	{"_key": 1230, "iconID": 3202, "nameID": 66562, "hasTypes": 1, "descriptionID": 65487, "parentGroupID": 963}
818	1231	{"_key": 1231, "iconID": 3197, "nameID": 66563, "hasTypes": 1, "descriptionID": 65488, "parentGroupID": 964}
819	1232	{"_key": 1232, "iconID": 3197, "nameID": 66564, "hasTypes": 1, "descriptionID": 65489, "parentGroupID": 964}
820	1233	{"_key": 1233, "iconID": 3197, "nameID": 66565, "hasTypes": 1, "descriptionID": 65490, "parentGroupID": 964}
821	1234	{"_key": 1234, "iconID": 3193, "nameID": 66566, "hasTypes": 1, "descriptionID": 65491, "parentGroupID": 965}
822	1235	{"_key": 1235, "iconID": 3193, "nameID": 66567, "hasTypes": 1, "descriptionID": 65492, "parentGroupID": 965}
823	1236	{"_key": 1236, "iconID": 3193, "nameID": 66568, "hasTypes": 1, "descriptionID": 65493, "parentGroupID": 965}
824	1237	{"_key": 1237, "iconID": 3201, "nameID": 66569, "hasTypes": 1, "descriptionID": 65494, "parentGroupID": 979}
825	1238	{"_key": 1238, "iconID": 3201, "nameID": 66570, "hasTypes": 1, "descriptionID": 65495, "parentGroupID": 979}
826	1239	{"_key": 1239, "iconID": 3201, "nameID": 66571, "hasTypes": 1, "descriptionID": 65496, "parentGroupID": 979}
827	1240	{"_key": 1240, "iconID": 2703, "nameID": 66387, "hasTypes": 1, "descriptionID": 65313, "parentGroupID": 945}
828	1241	{"_key": 1241, "iconID": 2703, "nameID": 66388, "hasTypes": 1, "descriptionID": 65314, "parentGroupID": 945}
829	1242	{"_key": 1242, "iconID": 2703, "nameID": 66389, "hasTypes": 1, "descriptionID": 65315, "parentGroupID": 945}
830	1243	{"_key": 1243, "iconID": 2703, "nameID": 66390, "hasTypes": 1, "descriptionID": 65316, "parentGroupID": 946}
831	1244	{"_key": 1244, "iconID": 2703, "nameID": 66391, "hasTypes": 1, "descriptionID": 65317, "parentGroupID": 946}
832	1245	{"_key": 1245, "iconID": 2703, "nameID": 66392, "hasTypes": 1, "descriptionID": 65318, "parentGroupID": 946}
833	1249	{"_key": 1249, "iconID": 2703, "nameID": 66396, "hasTypes": 1, "descriptionID": 65322, "parentGroupID": 948}
834	1250	{"_key": 1250, "iconID": 2703, "nameID": 66397, "hasTypes": 1, "descriptionID": 65323, "parentGroupID": 948}
835	1251	{"_key": 1251, "iconID": 2703, "nameID": 66398, "hasTypes": 1, "descriptionID": 65324, "parentGroupID": 948}
836	1252	{"_key": 1252, "iconID": 2703, "nameID": 66399, "hasTypes": 1, "descriptionID": 65325, "parentGroupID": 949}
837	1253	{"_key": 1253, "iconID": 2703, "nameID": 66400, "hasTypes": 1, "descriptionID": 65326, "parentGroupID": 949}
838	1254	{"_key": 1254, "iconID": 2703, "nameID": 66401, "hasTypes": 1, "descriptionID": 65327, "parentGroupID": 949}
839	1255	{"_key": 1255, "iconID": 2703, "nameID": 66402, "hasTypes": 1, "descriptionID": 65328, "parentGroupID": 950}
840	1256	{"_key": 1256, "iconID": 2703, "nameID": 66403, "hasTypes": 1, "descriptionID": 65329, "parentGroupID": 950}
841	1257	{"_key": 1257, "iconID": 2703, "nameID": 66404, "hasTypes": 1, "descriptionID": 65330, "parentGroupID": 950}
842	1258	{"_key": 1258, "iconID": 2703, "nameID": 66405, "hasTypes": 1, "descriptionID": 65331, "parentGroupID": 951}
843	1259	{"_key": 1259, "iconID": 2703, "nameID": 66406, "hasTypes": 1, "descriptionID": 65332, "parentGroupID": 951}
844	1260	{"_key": 1260, "iconID": 2703, "nameID": 66407, "hasTypes": 1, "descriptionID": 65333, "parentGroupID": 951}
845	1261	{"_key": 1261, "iconID": 2703, "nameID": 66408, "hasTypes": 1, "descriptionID": 65334, "parentGroupID": 952}
846	1262	{"_key": 1262, "iconID": 2703, "nameID": 66409, "hasTypes": 1, "descriptionID": 65335, "parentGroupID": 952}
847	1263	{"_key": 1263, "iconID": 2703, "nameID": 66410, "hasTypes": 1, "descriptionID": 65336, "parentGroupID": 952}
848	1264	{"_key": 1264, "iconID": 2703, "nameID": 66411, "hasTypes": 1, "descriptionID": 65337, "parentGroupID": 953}
849	1265	{"_key": 1265, "iconID": 2703, "nameID": 66412, "hasTypes": 1, "descriptionID": 65338, "parentGroupID": 953}
850	1266	{"_key": 1266, "iconID": 2703, "nameID": 66413, "hasTypes": 1, "descriptionID": 65339, "parentGroupID": 953}
851	1267	{"_key": 1267, "iconID": 2703, "nameID": 66414, "hasTypes": 1, "descriptionID": 65340, "parentGroupID": 954}
852	1268	{"_key": 1268, "iconID": 2703, "nameID": 66415, "hasTypes": 1, "descriptionID": 65341, "parentGroupID": 954}
853	1269	{"_key": 1269, "iconID": 2703, "nameID": 66416, "hasTypes": 1, "descriptionID": 65342, "parentGroupID": 954}
854	1272	{"_key": 1272, "iconID": 3952, "nameID": 66534, "hasTypes": 0, "descriptionID": 65459, "parentGroupID": 477}
855	1273	{"_key": 1273, "iconID": 3952, "nameID": 66535, "hasTypes": 1, "descriptionID": 65460, "parentGroupID": 1272}
856	1274	{"_key": 1274, "iconID": 3952, "nameID": 66536, "hasTypes": 1, "descriptionID": 65461, "parentGroupID": 1272}
857	1275	{"_key": 1275, "iconID": 3952, "nameID": 66537, "hasTypes": 1, "descriptionID": 65462, "parentGroupID": 1272}
858	1276	{"_key": 1276, "iconID": 3947, "nameID": 66313, "hasTypes": 0, "descriptionID": 65239, "parentGroupID": 1272}
859	1282	{"_key": 1282, "iconID": 3946, "nameID": 66530, "hasTypes": 1, "descriptionID": 65455, "parentGroupID": 1276}
860	1283	{"_key": 1283, "iconID": 3948, "nameID": 66531, "hasTypes": 1, "descriptionID": 65456, "parentGroupID": 1276}
861	1284	{"_key": 1284, "iconID": 3947, "nameID": 66532, "hasTypes": 1, "descriptionID": 65457, "parentGroupID": 1276}
862	1285	{"_key": 1285, "iconID": 2222, "nameID": 66533, "hasTypes": 0, "descriptionID": 65458, "parentGroupID": 477}
863	1286	{"_key": 1286, "iconID": 2703, "nameID": 66372, "hasTypes": 1, "descriptionID": 65298, "parentGroupID": 314}
864	1287	{"_key": 1287, "iconID": 183, "nameID": 66470, "hasTypes": 1, "descriptionID": 65396, "parentGroupID": 1316}
865	1310	{"_key": 1310, "iconID": 1084, "nameID": 66315, "hasTypes": 1, "descriptionID": 65241, "parentGroupID": 2410}
866	1313	{"_key": 1313, "iconID": 2703, "nameID": 66317, "hasTypes": 1, "descriptionID": 65243, "parentGroupID": 2237}
867	1316	{"_key": 1316, "iconID": 183, "nameID": 66469, "hasTypes": 0, "descriptionID": 65395, "parentGroupID": 114}
868	1317	{"_key": 1317, "iconID": 183, "nameID": 66471, "hasTypes": 1, "descriptionID": 65397, "parentGroupID": 1316}
869	1320	{"_key": 1320, "iconID": 2881, "nameID": 66318, "hasTypes": 0, "descriptionID": 65244}
870	1322	{"_key": 1322, "iconID": 2875, "nameID": 66598, "hasTypes": 1, "descriptionID": 65523, "parentGroupID": 1320}
871	1323	{"_key": 1323, "iconID": 33, "nameID": 66515, "hasTypes": 1, "descriptionID": 65441, "parentGroupID": 150}
872	1332	{"_key": 1332, "iconID": 10073, "nameID": 66349, "hasTypes": 0, "descriptionID": 65275, "parentGroupID": 533}
873	1333	{"_key": 1333, "iconID": 10012, "nameID": 66521, "hasTypes": 1, "descriptionID": 65447, "parentGroupID": 1332}
874	1334	{"_key": 1334, "iconID": 10023, "nameID": 66522, "hasTypes": 1, "descriptionID": 65448, "parentGroupID": 1332}
875	1335	{"_key": 1335, "iconID": 1362, "nameID": 66523, "hasTypes": 1, "descriptionID": 65449, "parentGroupID": 1332}
876	1336	{"_key": 1336, "iconID": 10040, "nameID": 66525, "hasTypes": 1, "descriptionID": 65450, "parentGroupID": 1332}
877	1337	{"_key": 1337, "iconID": 10074, "nameID": 66526, "hasTypes": 1, "descriptionID": 65451, "parentGroupID": 1332}
878	1338	{"_key": 1338, "iconID": 2703, "nameID": 66417, "hasTypes": 0, "descriptionID": 65343, "parentGroupID": 2}
879	1339	{"_key": 1339, "iconID": 2703, "nameID": 66418, "hasTypes": 1, "descriptionID": 65344, "parentGroupID": 1841}
880	1340	{"_key": 1340, "iconID": 2703, "nameID": 66419, "hasTypes": 1, "descriptionID": 65345, "parentGroupID": 1841}
881	1341	{"_key": 1341, "iconID": 2703, "nameID": 66420, "hasTypes": 1, "descriptionID": 65346, "parentGroupID": 1841}
882	1342	{"_key": 1342, "iconID": 2703, "nameID": 66421, "hasTypes": 1, "descriptionID": 65347, "parentGroupID": 1841}
883	1343	{"_key": 1343, "iconID": 2703, "nameID": 66422, "hasTypes": 1, "descriptionID": 65348, "parentGroupID": 1841}
884	1344	{"_key": 1344, "iconID": 2703, "nameID": 66423, "hasTypes": 1, "descriptionID": 65349, "parentGroupID": 1534}
885	1345	{"_key": 1345, "iconID": 2703, "nameID": 66424, "hasTypes": 1, "descriptionID": 65350, "parentGroupID": 1534}
886	1346	{"_key": 1346, "iconID": 2703, "nameID": 66425, "hasTypes": 1, "descriptionID": 65351, "parentGroupID": 1841}
887	1347	{"_key": 1347, "iconID": 2703, "nameID": 66426, "hasTypes": 1, "descriptionID": 65352, "parentGroupID": 1534}
888	1348	{"_key": 1348, "iconID": 2703, "nameID": 66427, "hasTypes": 1, "descriptionID": 65353, "parentGroupID": 1534}
889	1349	{"_key": 1349, "iconID": 2703, "nameID": 66428, "hasTypes": 1, "descriptionID": 65354, "parentGroupID": 1534}
890	1350	{"_key": 1350, "iconID": 2703, "nameID": 66429, "hasTypes": 1, "descriptionID": 65355, "parentGroupID": 1534}
891	1351	{"_key": 1351, "iconID": 2703, "nameID": 66430, "hasTypes": 1, "descriptionID": 65356, "parentGroupID": 1841}
892	1352	{"_key": 1352, "iconID": 2703, "nameID": 66431, "hasTypes": 1, "descriptionID": 65357, "parentGroupID": 1841}
893	1353	{"_key": 1353, "iconID": 2703, "nameID": 66432, "hasTypes": 1, "descriptionID": 65358, "parentGroupID": 1841}
894	1354	{"_key": 1354, "iconID": 2703, "nameID": 66433, "hasTypes": 1, "descriptionID": 65359, "parentGroupID": 1841}
895	1355	{"_key": 1355, "iconID": 2703, "nameID": 66434, "hasTypes": 1, "descriptionID": 65360, "parentGroupID": 1841}
896	1356	{"_key": 1356, "iconID": 2703, "nameID": 66435, "hasTypes": 1, "descriptionID": 65361, "parentGroupID": 2015}
897	1358	{"_key": 1358, "iconID": 2703, "nameID": 66373, "hasTypes": 1, "descriptionID": 65299, "parentGroupID": 211}
898	1359	{"_key": 1359, "iconID": 2703, "nameID": 66436, "hasTypes": 1, "descriptionID": 65362, "parentGroupID": 1841}
899	1361	{"_key": 1361, "iconID": 1443, "nameID": 66437, "hasTypes": 0, "descriptionID": 65363, "parentGroupID": 4}
900	1362	{"_key": 1362, "iconID": 1443, "nameID": 66438, "hasTypes": 0, "descriptionID": 65364, "parentGroupID": 1361}
901	1364	{"_key": 1364, "iconID": 1443, "nameID": 66441, "hasTypes": 0, "descriptionID": 65367, "parentGroupID": 1361}
902	1365	{"_key": 1365, "iconID": 1443, "nameID": 66439, "hasTypes": 1, "descriptionID": 65365, "parentGroupID": 1362}
903	1366	{"_key": 1366, "iconID": 1443, "nameID": 66440, "hasTypes": 0, "descriptionID": 65366, "parentGroupID": 1362}
904	1367	{"_key": 1367, "iconID": 1443, "nameID": 66442, "hasTypes": 0, "descriptionID": 65368, "parentGroupID": 4}
905	1368	{"_key": 1368, "iconID": 1443, "nameID": 66443, "hasTypes": 0, "descriptionID": 65369, "parentGroupID": 1367}
906	1369	{"_key": 1369, "iconID": 1443, "nameID": 66445, "hasTypes": 0, "descriptionID": 65371, "parentGroupID": 1367}
907	1370	{"_key": 1370, "iconID": 1443, "nameID": 66446, "hasTypes": 1, "descriptionID": 65372, "parentGroupID": 1369}
908	1371	{"_key": 1371, "iconID": 1443, "nameID": 66447, "hasTypes": 1, "descriptionID": 65373, "parentGroupID": 1369}
909	1372	{"_key": 1372, "iconID": 1443, "nameID": 66448, "hasTypes": 0, "descriptionID": 65374, "parentGroupID": 4}
910	1373	{"_key": 1373, "iconID": 1443, "nameID": 66449, "hasTypes": 0, "descriptionID": 65375, "parentGroupID": 1372}
911	1374	{"_key": 1374, "iconID": 1443, "nameID": 66451, "hasTypes": 0, "descriptionID": 65377, "parentGroupID": 4}
912	1375	{"_key": 1375, "iconID": 1443, "nameID": 66452, "hasTypes": 0, "descriptionID": 65378, "parentGroupID": 1374}
913	1376	{"_key": 1376, "iconID": 1443, "nameID": 66453, "hasTypes": 0, "descriptionID": 65379, "parentGroupID": 4}
914	1377	{"_key": 1377, "iconID": 1443, "nameID": 66454, "hasTypes": 0, "descriptionID": 65380, "parentGroupID": 1376}
915	1378	{"_key": 1378, "iconID": 1443, "nameID": 66455, "hasTypes": 0, "descriptionID": 65381, "parentGroupID": 1376}
916	1379	{"_key": 1379, "iconID": 1443, "nameID": 66456, "hasTypes": 1, "descriptionID": 65382, "parentGroupID": 1378}
917	1380	{"_key": 1380, "iconID": 1443, "nameID": 66457, "hasTypes": 1, "descriptionID": 65383, "parentGroupID": 1378}
918	1381	{"_key": 1381, "iconID": 1443, "nameID": 66458, "hasTypes": 0, "descriptionID": 65384, "parentGroupID": 4}
919	1382	{"_key": 1382, "iconID": 1443, "nameID": 66460, "hasTypes": 0, "descriptionID": 65386, "parentGroupID": 4}
920	1384	{"_key": 1384, "iconID": 1443, "nameID": 66462, "hasTypes": 0, "descriptionID": 65388, "parentGroupID": 4}
921	1385	{"_key": 1385, "iconID": 1443, "nameID": 66461, "hasTypes": 0, "descriptionID": 65387, "parentGroupID": 1382}
922	1389	{"_key": 1389, "iconID": 2703, "nameID": 66351, "hasTypes": 1, "descriptionID": 65277, "parentGroupID": 208}
923	1390	{"_key": 1390, "iconID": 27058, "nameID": 66352, "hasTypes": 1, "descriptionID": 65278, "parentGroupID": 8}
924	1392	{"_key": 1392, "iconID": 1443, "nameID": 66459, "hasTypes": 1, "descriptionID": 65385, "parentGroupID": 817}
925	1396	{"_key": 1396, "iconID": 10256, "nameID": 66364, "hasTypes": 0, "descriptionID": 65290}
926	1397	{"_key": 1397, "iconID": 10829, "nameID": 66365, "hasTypes": 0, "descriptionID": 65291, "parentGroupID": 1396}
927	1398	{"_key": 1398, "iconID": 10785, "nameID": 66354, "hasTypes": 1, "descriptionID": 65280, "parentGroupID": 1397}
928	1399	{"_key": 1399, "iconID": 10236, "nameID": 66355, "hasTypes": 1, "descriptionID": 65281, "parentGroupID": 1397}
929	1400	{"_key": 1400, "iconID": 10254, "nameID": 66356, "hasTypes": 1, "descriptionID": 65282, "parentGroupID": 1397}
930	1401	{"_key": 1401, "iconID": 10756, "nameID": 66357, "hasTypes": 1, "descriptionID": 65283, "parentGroupID": 1397}
931	1402	{"_key": 1402, "iconID": 10830, "nameID": 66366, "hasTypes": 0, "descriptionID": 65292, "parentGroupID": 1396}
932	1403	{"_key": 1403, "iconID": 10570, "nameID": 66358, "hasTypes": 1, "descriptionID": 65284, "parentGroupID": 1402}
933	1404	{"_key": 1404, "iconID": 10624, "nameID": 66359, "hasTypes": 1, "descriptionID": 65285, "parentGroupID": 1402}
934	1405	{"_key": 1405, "iconID": 10234, "nameID": 66360, "hasTypes": 1, "descriptionID": 65286, "parentGroupID": 1402}
935	1406	{"_key": 1406, "iconID": 10684, "nameID": 66361, "hasTypes": 1, "descriptionID": 65287, "parentGroupID": 1402}
936	1407	{"_key": 1407, "iconID": 10828, "nameID": 66367, "hasTypes": 0, "descriptionID": 65293, "parentGroupID": 1396}
937	1408	{"_key": 1408, "iconID": 10224, "nameID": 66362, "hasTypes": 1, "descriptionID": 65288, "parentGroupID": 1407}
938	1410	{"_key": 1410, "iconID": 2875, "nameID": 66363, "hasTypes": 1, "descriptionID": 65289, "parentGroupID": 1320}
939	1416	{"_key": 1416, "iconID": 10933, "nameID": 277852, "hasTypes": 1, "descriptionID": 277853, "parentGroupID": 535}
940	1426	{"_key": 1426, "iconID": 10932, "nameID": 278635, "hasTypes": 1, "descriptionID": 278636, "parentGroupID": 657}
941	1427	{"_key": 1427, "iconID": 10831, "nameID": 279366, "hasTypes": 1, "descriptionID": 279367, "parentGroupID": 19}
942	1469	{"_key": 1469, "iconID": 2224, "nameID": 279957, "hasTypes": 0, "descriptionID": 279958, "parentGroupID": 531}
943	1470	{"_key": 1470, "iconID": 2224, "nameID": 279959, "hasTypes": 0, "descriptionID": 279960, "parentGroupID": 531}
944	1471	{"_key": 1471, "iconID": 2224, "nameID": 279961, "hasTypes": 0, "descriptionID": 279962, "parentGroupID": 531}
945	1472	{"_key": 1472, "iconID": 2224, "nameID": 279963, "hasTypes": 0, "descriptionID": 279964, "parentGroupID": 531}
946	1473	{"_key": 1473, "iconID": 2224, "nameID": 279965, "hasTypes": 0, "descriptionID": 279966, "parentGroupID": 531}
947	1474	{"_key": 1474, "iconID": 2224, "nameID": 279967, "hasTypes": 0, "descriptionID": 279968, "parentGroupID": 531}
948	1475	{"_key": 1475, "iconID": 2224, "nameID": 279969, "hasTypes": 0, "descriptionID": 279970, "parentGroupID": 531}
949	1476	{"_key": 1476, "iconID": 2224, "nameID": 279971, "hasTypes": 0, "descriptionID": 279972, "parentGroupID": 531}
950	1477	{"_key": 1477, "iconID": 2224, "nameID": 279973, "hasTypes": 0, "descriptionID": 279974, "parentGroupID": 531}
951	1478	{"_key": 1478, "iconID": 2224, "nameID": 279975, "hasTypes": 0, "descriptionID": 279976, "parentGroupID": 531}
952	1479	{"_key": 1479, "iconID": 2224, "nameID": 279977, "hasTypes": 0, "descriptionID": 279978, "parentGroupID": 531}
953	1480	{"_key": 1480, "iconID": 2224, "nameID": 279979, "hasTypes": 1, "descriptionID": 279980, "parentGroupID": 1479}
954	1481	{"_key": 1481, "iconID": 2224, "nameID": 279981, "hasTypes": 1, "descriptionID": 279982, "parentGroupID": 1479}
955	1482	{"_key": 1482, "iconID": 2224, "nameID": 279983, "hasTypes": 1, "descriptionID": 279984, "parentGroupID": 1479}
956	1483	{"_key": 1483, "iconID": 2224, "nameID": 279985, "hasTypes": 1, "descriptionID": 279986, "parentGroupID": 1479}
957	1484	{"_key": 1484, "iconID": 2224, "nameID": 279987, "hasTypes": 1, "descriptionID": 279988, "parentGroupID": 1478}
958	1485	{"_key": 1485, "iconID": 2224, "nameID": 279989, "hasTypes": 1, "descriptionID": 279990, "parentGroupID": 1478}
959	1486	{"_key": 1486, "iconID": 2224, "nameID": 279991, "hasTypes": 1, "descriptionID": 279992, "parentGroupID": 1478}
960	1489	{"_key": 1489, "iconID": 2224, "nameID": 279997, "hasTypes": 1, "descriptionID": 279998, "parentGroupID": 1477}
961	1490	{"_key": 1490, "iconID": 2224, "nameID": 279999, "hasTypes": 1, "descriptionID": 280000, "parentGroupID": 1477}
962	1491	{"_key": 1491, "iconID": 2224, "nameID": 280001, "hasTypes": 1, "descriptionID": 280002, "parentGroupID": 1477}
963	1492	{"_key": 1492, "iconID": 2224, "nameID": 280003, "hasTypes": 1, "descriptionID": 280004, "parentGroupID": 1477}
964	1493	{"_key": 1493, "iconID": 2224, "nameID": 280005, "hasTypes": 1, "descriptionID": 280006, "parentGroupID": 1476}
965	1494	{"_key": 1494, "iconID": 2224, "nameID": 280007, "hasTypes": 1, "descriptionID": 280008, "parentGroupID": 1476}
966	1495	{"_key": 1495, "iconID": 2224, "nameID": 280009, "hasTypes": 1, "descriptionID": 280010, "parentGroupID": 1476}
967	1496	{"_key": 1496, "iconID": 2224, "nameID": 280011, "hasTypes": 1, "descriptionID": 280012, "parentGroupID": 1476}
968	1497	{"_key": 1497, "iconID": 2224, "nameID": 280013, "hasTypes": 1, "descriptionID": 280014, "parentGroupID": 1476}
969	1498	{"_key": 1498, "iconID": 2224, "nameID": 280015, "hasTypes": 1, "descriptionID": 280016, "parentGroupID": 1473}
970	1499	{"_key": 1499, "iconID": 2224, "nameID": 280017, "hasTypes": 1, "descriptionID": 280018, "parentGroupID": 1473}
971	1500	{"_key": 1500, "iconID": 2224, "nameID": 280019, "hasTypes": 1, "descriptionID": 280020, "parentGroupID": 1473}
972	1501	{"_key": 1501, "iconID": 2224, "nameID": 280021, "hasTypes": 1, "descriptionID": 280025, "parentGroupID": 1473}
973	1502	{"_key": 1502, "iconID": 2224, "nameID": 280022, "hasTypes": 1, "descriptionID": 280027, "parentGroupID": 1473}
974	1504	{"_key": 1504, "iconID": 2224, "nameID": 280024, "hasTypes": 1, "descriptionID": 280029, "parentGroupID": 1474}
975	1505	{"_key": 1505, "iconID": 2224, "nameID": 280026, "hasTypes": 1, "descriptionID": 280030, "parentGroupID": 1475}
976	1506	{"_key": 1506, "iconID": 2224, "nameID": 280031, "hasTypes": 1, "descriptionID": 280032, "parentGroupID": 1472}
977	1507	{"_key": 1507, "iconID": 2224, "nameID": 280033, "hasTypes": 1, "descriptionID": 280034, "parentGroupID": 1471}
978	1508	{"_key": 1508, "iconID": 2224, "nameID": 280035, "hasTypes": 1, "descriptionID": 280036, "parentGroupID": 1471}
979	1509	{"_key": 1509, "iconID": 2224, "nameID": 280037, "hasTypes": 1, "descriptionID": 280038, "parentGroupID": 1471}
980	1512	{"_key": 1512, "iconID": 2224, "nameID": 280043, "hasTypes": 1, "descriptionID": 280044, "parentGroupID": 1470}
981	1513	{"_key": 1513, "iconID": 2224, "nameID": 280045, "hasTypes": 1, "descriptionID": 280046, "parentGroupID": 1470}
982	1514	{"_key": 1514, "iconID": 2224, "nameID": 280047, "hasTypes": 1, "descriptionID": 280048, "parentGroupID": 1469}
983	1515	{"_key": 1515, "iconID": 2224, "nameID": 280049, "hasTypes": 1, "descriptionID": 280053, "parentGroupID": 1469}
984	1516	{"_key": 1516, "iconID": 2224, "nameID": 280050, "hasTypes": 1, "descriptionID": 280054, "parentGroupID": 1469}
985	1517	{"_key": 1517, "iconID": 2224, "nameID": 280051, "hasTypes": 1, "descriptionID": 280055, "parentGroupID": 1469}
986	1518	{"_key": 1518, "iconID": 2224, "nameID": 280052, "hasTypes": 1, "descriptionID": 280056, "parentGroupID": 1469}
987	1520	{"_key": 1520, "iconID": 2703, "nameID": 281033, "hasTypes": 0, "descriptionID": 281034, "parentGroupID": 211}
988	1521	{"_key": 1521, "iconID": 2703, "nameID": 281036, "hasTypes": 1, "descriptionID": 281037, "parentGroupID": 1520}
989	1522	{"_key": 1522, "iconID": 2703, "nameID": 281044, "hasTypes": 0, "descriptionID": 281045, "parentGroupID": 1041}
990	1525	{"_key": 1525, "iconID": 2703, "nameID": 281050, "hasTypes": 1, "descriptionID": 281051, "parentGroupID": 252}
991	1526	{"_key": 1526, "iconID": 2703, "nameID": 281052, "hasTypes": 1, "descriptionID": 281053, "parentGroupID": 314}
992	1527	{"_key": 1527, "iconID": 2703, "nameID": 281054, "hasTypes": 1, "descriptionID": 281055, "parentGroupID": 314}
993	1528	{"_key": 1528, "iconID": 2703, "nameID": 281056, "hasTypes": 1, "parentGroupID": 314}
994	1529	{"_key": 1529, "iconID": 2703, "nameID": 281058, "hasTypes": 1, "descriptionID": 281059, "parentGroupID": 1520}
995	1530	{"_key": 1530, "iconID": 2703, "nameID": 281274, "hasTypes": 0, "descriptionID": 281275, "parentGroupID": 357}
996	1531	{"_key": 1531, "iconID": 2703, "nameID": 281276, "hasTypes": 1, "descriptionID": 281277, "parentGroupID": 1530}
997	1532	{"_key": 1532, "iconID": 2703, "nameID": 281278, "hasTypes": 1, "descriptionID": 281279, "parentGroupID": 1530}
998	1533	{"_key": 1533, "iconID": 2703, "nameID": 281280, "hasTypes": 1, "descriptionID": 281281, "parentGroupID": 1530}
999	1534	{"_key": 1534, "iconID": 2703, "nameID": 281282, "hasTypes": 0, "descriptionID": 281283, "parentGroupID": 1841}
1000	1535	{"_key": 1535, "iconID": 2703, "nameID": 281284, "hasTypes": 1, "descriptionID": 281285, "parentGroupID": 1841}
1001	1536	{"_key": 1536, "iconID": 2703, "nameID": 281306, "hasTypes": 1, "descriptionID": 281307, "parentGroupID": 214}
1002	1537	{"_key": 1537, "iconID": 2703, "nameID": 281308, "hasTypes": 1, "descriptionID": 281309, "parentGroupID": 214}
1003	1538	{"_key": 1538, "iconID": 2703, "nameID": 281310, "hasTypes": 1, "descriptionID": 281311, "parentGroupID": 214}
1004	1539	{"_key": 1539, "iconID": 2703, "nameID": 281312, "hasTypes": 1, "descriptionID": 281313, "parentGroupID": 214}
1005	1540	{"_key": 1540, "iconID": 2703, "nameID": 281314, "hasTypes": 1, "descriptionID": 281315, "parentGroupID": 214}
1006	1541	{"_key": 1541, "iconID": 2703, "nameID": 281316, "hasTypes": 1, "descriptionID": 281317, "parentGroupID": 214}
1007	1542	{"_key": 1542, "iconID": 2703, "nameID": 281318, "hasTypes": 1, "descriptionID": 281319, "parentGroupID": 214}
1008	1543	{"_key": 1543, "iconID": 2703, "nameID": 281320, "hasTypes": 1, "descriptionID": 281321, "parentGroupID": 214}
1009	1544	{"_key": 1544, "iconID": 2703, "nameID": 281322, "hasTypes": 1, "descriptionID": 281323, "parentGroupID": 214}
1010	1545	{"_key": 1545, "iconID": 2703, "nameID": 281324, "hasTypes": 0, "descriptionID": 629999, "parentGroupID": 209}
1011	1546	{"_key": 1546, "iconID": 2703, "nameID": 281325, "hasTypes": 0, "descriptionID": 630008, "parentGroupID": 209}
1012	1547	{"_key": 1547, "iconID": 2703, "nameID": 281326, "hasTypes": 1, "descriptionID": 630006, "parentGroupID": 1545}
1013	1548	{"_key": 1548, "iconID": 2703, "nameID": 281327, "hasTypes": 1, "descriptionID": 630007, "parentGroupID": 1545}
1014	1549	{"_key": 1549, "iconID": 2703, "nameID": 281328, "hasTypes": 1, "descriptionID": 630001, "parentGroupID": 1545}
1015	1550	{"_key": 1550, "iconID": 2703, "nameID": 281329, "hasTypes": 1, "descriptionID": 630000, "parentGroupID": 1545}
1016	1551	{"_key": 1551, "iconID": 2703, "nameID": 281330, "hasTypes": 1, "descriptionID": 629998, "parentGroupID": 1545}
1017	1552	{"_key": 1552, "iconID": 2703, "nameID": 281331, "hasTypes": 1, "descriptionID": 629997, "parentGroupID": 1545}
1018	1553	{"_key": 1553, "iconID": 2703, "nameID": 281332, "hasTypes": 1, "descriptionID": 629996, "parentGroupID": 1545}
1019	1554	{"_key": 1554, "iconID": 2703, "nameID": 281333, "hasTypes": 1, "descriptionID": 630003, "parentGroupID": 1545}
1020	1555	{"_key": 1555, "iconID": 2703, "nameID": 281362, "hasTypes": 1, "descriptionID": 281363, "parentGroupID": 1546}
1021	1556	{"_key": 1556, "iconID": 2703, "nameID": 281364, "hasTypes": 1, "descriptionID": 281365, "parentGroupID": 1546}
1022	1557	{"_key": 1557, "iconID": 2703, "nameID": 281366, "hasTypes": 1, "descriptionID": 281367, "parentGroupID": 1546}
1023	1558	{"_key": 1558, "iconID": 2703, "nameID": 281368, "hasTypes": 1, "descriptionID": 281369, "parentGroupID": 1546}
1024	1559	{"_key": 1559, "iconID": 2703, "nameID": 281370, "hasTypes": 1, "descriptionID": 281371, "parentGroupID": 1546}
1025	1560	{"_key": 1560, "iconID": 2703, "nameID": 281372, "hasTypes": 1, "descriptionID": 281373, "parentGroupID": 1546}
1026	1561	{"_key": 1561, "iconID": 2703, "nameID": 281374, "hasTypes": 1, "descriptionID": 281375, "parentGroupID": 1546}
1027	1562	{"_key": 1562, "iconID": 2703, "nameID": 281376, "hasTypes": 1, "descriptionID": 281377, "parentGroupID": 1546}
1028	1563	{"_key": 1563, "iconID": 2703, "nameID": 281378, "hasTypes": 1, "descriptionID": 281379, "parentGroupID": 1546}
1029	1564	{"_key": 1564, "iconID": 2703, "nameID": 281380, "hasTypes": 1, "descriptionID": 281381, "parentGroupID": 1546}
1030	1565	{"_key": 1565, "iconID": 2703, "nameID": 281384, "hasTypes": 1, "descriptionID": 281385, "parentGroupID": 1546}
1031	1566	{"_key": 1566, "iconID": 2703, "nameID": 281386, "hasTypes": 0, "descriptionID": 281387, "parentGroupID": 209}
1032	1567	{"_key": 1567, "iconID": 2703, "nameID": 281388, "hasTypes": 1, "descriptionID": 281389, "parentGroupID": 1566}
1033	1568	{"_key": 1568, "iconID": 2703, "nameID": 281390, "hasTypes": 1, "descriptionID": 281391, "parentGroupID": 1566}
1034	1570	{"_key": 1570, "iconID": 2703, "nameID": 281394, "hasTypes": 1, "descriptionID": 281399, "parentGroupID": 1566}
1035	1571	{"_key": 1571, "iconID": 2703, "nameID": 281395, "hasTypes": 1, "descriptionID": 281400, "parentGroupID": 1566}
1036	1572	{"_key": 1572, "iconID": 2703, "nameID": 281396, "hasTypes": 1, "descriptionID": 281401, "parentGroupID": 1566}
1037	1574	{"_key": 1574, "iconID": 2703, "nameID": 281398, "hasTypes": 1, "descriptionID": 281403, "parentGroupID": 1566}
1038	1575	{"_key": 1575, "iconID": 2703, "nameID": 281413, "hasTypes": 1, "descriptionID": 281414, "parentGroupID": 1566}
1039	1576	{"_key": 1576, "iconID": 2703, "nameID": 281415, "hasTypes": 1, "descriptionID": 281416, "parentGroupID": 1566}
1040	1577	{"_key": 1577, "iconID": 2703, "nameID": 281417, "hasTypes": 1, "descriptionID": 281418, "parentGroupID": 1566}
1041	1578	{"_key": 1578, "iconID": 2703, "nameID": 281419, "hasTypes": 0, "descriptionID": 281420, "parentGroupID": 209}
1042	1579	{"_key": 1579, "iconID": 2703, "nameID": 281422, "hasTypes": 1, "descriptionID": 281423, "parentGroupID": 1578}
1043	1580	{"_key": 1580, "iconID": 2703, "nameID": 281424, "hasTypes": 1, "descriptionID": 281425, "parentGroupID": 1578}
1044	1581	{"_key": 1581, "iconID": 2703, "nameID": 281426, "hasTypes": 1, "descriptionID": 281427, "parentGroupID": 1578}
1045	1582	{"_key": 1582, "iconID": 2703, "nameID": 281428, "hasTypes": 1, "descriptionID": 281429, "parentGroupID": 1578}
1046	1583	{"_key": 1583, "iconID": 2703, "nameID": 281430, "hasTypes": 1, "descriptionID": 281431, "parentGroupID": 1566}
1047	1584	{"_key": 1584, "iconID": 2703, "nameID": 281432, "hasTypes": 1, "descriptionID": 281433, "parentGroupID": 1578}
1048	1585	{"_key": 1585, "iconID": 2703, "nameID": 281434, "hasTypes": 1, "descriptionID": 281435, "parentGroupID": 1578}
1049	1586	{"_key": 1586, "iconID": 2703, "nameID": 281697, "hasTypes": 1, "descriptionID": 281698, "parentGroupID": 357}
1050	1587	{"_key": 1587, "iconID": 2703, "nameID": 281700, "hasTypes": 1, "descriptionID": 281701, "parentGroupID": 1097}
1051	1588	{"_key": 1588, "iconID": 2703, "nameID": 281702, "hasTypes": 1, "descriptionID": 281703, "parentGroupID": 1097}
1052	1589	{"_key": 1589, "iconID": 2703, "nameID": 281704, "hasTypes": 1, "descriptionID": 281705, "parentGroupID": 1097}
1053	1590	{"_key": 1590, "iconID": 2703, "nameID": 281706, "hasTypes": 1, "descriptionID": 281707, "parentGroupID": 1097}
1054	1591	{"_key": 1591, "iconID": 2703, "nameID": 281715, "hasTypes": 0, "descriptionID": 281716, "parentGroupID": 800}
1055	1592	{"_key": 1592, "iconID": 2703, "nameID": 281717, "hasTypes": 1, "descriptionID": 281718, "parentGroupID": 1591}
1056	1593	{"_key": 1593, "iconID": 2703, "nameID": 281719, "hasTypes": 1, "descriptionID": 281720, "parentGroupID": 1591}
1057	1594	{"_key": 1594, "iconID": 2703, "nameID": 281721, "hasTypes": 1, "descriptionID": 281722, "parentGroupID": 1591}
1058	1595	{"_key": 1595, "iconID": 2703, "nameID": 281723, "hasTypes": 1, "descriptionID": 281724, "parentGroupID": 1591}
1059	1598	{"_key": 1598, "iconID": 10942, "nameID": 282506, "hasTypes": 1, "parentGroupID": 99}
1060	1599	{"_key": 1599, "iconID": 10940, "nameID": 282507, "hasTypes": 1, "parentGroupID": 101}
1061	1600	{"_key": 1600, "iconID": 10941, "nameID": 282508, "hasTypes": 1, "parentGroupID": 100}
1062	1601	{"_key": 1601, "iconID": 2703, "nameID": 282509, "hasTypes": 1, "parentGroupID": 300}
1063	1602	{"_key": 1602, "iconID": 2703, "nameID": 282510, "hasTypes": 1, "parentGroupID": 301}
1064	1603	{"_key": 1603, "iconID": 2703, "nameID": 282511, "hasTypes": 1, "parentGroupID": 299}
1065	1610	{"_key": 1610, "iconID": 20959, "nameID": 283283, "hasTypes": 0, "descriptionID": 283284, "parentGroupID": 1112}
1066	1612	{"_key": 1612, "iconID": 1443, "nameID": 283309, "hasTypes": 0, "descriptionID": 283310, "parentGroupID": 4}
1067	1614	{"_key": 1614, "iconID": 1443, "nameID": 283313, "hasTypes": 1, "descriptionID": 283314, "parentGroupID": 1612}
1068	1616	{"_key": 1616, "iconID": 27058, "nameID": 283354, "hasTypes": 1, "descriptionID": 283355, "parentGroupID": 5}
1069	1617	{"_key": 1617, "iconID": 2703, "nameID": 283356, "hasTypes": 1, "descriptionID": 283357, "parentGroupID": 205}
1070	1618	{"_key": 1618, "iconID": 1443, "nameID": 283441, "hasTypes": 1, "descriptionID": 283442, "parentGroupID": 1612}
1071	1619	{"_key": 1619, "iconID": 1443, "nameID": 283443, "hasTypes": 1, "descriptionID": 283444, "parentGroupID": 1612}
1072	1620	{"_key": 1620, "iconID": 1443, "nameID": 283445, "hasTypes": 1, "descriptionID": 283446, "parentGroupID": 1612}
1073	1621	{"_key": 1621, "iconID": 1443, "nameID": 283447, "hasTypes": 1, "descriptionID": 283448, "parentGroupID": 1612}
1074	1623	{"_key": 1623, "iconID": 1443, "nameID": 283451, "hasTypes": 1, "descriptionID": 283452, "parentGroupID": 1612}
1075	1624	{"_key": 1624, "iconID": 1443, "nameID": 283453, "hasTypes": 1, "descriptionID": 283454, "parentGroupID": 1612}
1076	1625	{"_key": 1625, "iconID": 20966, "nameID": 283524, "hasTypes": 0, "descriptionID": 630004, "parentGroupID": 1112}
1077	1626	{"_key": 1626, "iconID": 20968, "nameID": 283525, "hasTypes": 0, "descriptionID": 630005, "parentGroupID": 1112}
1078	1627	{"_key": 1627, "iconID": 20967, "nameID": 283526, "hasTypes": 0, "descriptionID": 630002, "parentGroupID": 1112}
1079	1631	{"_key": 1631, "iconID": 1443, "nameID": 283554, "hasTypes": 1, "descriptionID": 283555, "parentGroupID": 391}
1080	1633	{"_key": 1633, "iconID": 20970, "nameID": 283632, "hasTypes": 1, "descriptionID": 283633, "parentGroupID": 779}
1081	1639	{"_key": 1639, "iconID": 1444, "nameID": 283644, "hasTypes": 1, "descriptionID": 283645, "parentGroupID": 779}
1082	1640	{"_key": 1640, "iconID": 2985, "nameID": 283646, "hasTypes": 1, "descriptionID": 283647, "parentGroupID": 779}
1083	1641	{"_key": 1641, "iconID": 1444, "nameID": 283648, "hasTypes": 1, "descriptionID": 283649, "parentGroupID": 779}
1084	1642	{"_key": 1642, "iconID": 34, "nameID": 283650, "hasTypes": 1, "descriptionID": 283651, "parentGroupID": 779}
1085	1643	{"_key": 1643, "iconID": 2703, "nameID": 283657, "hasTypes": 1, "descriptionID": 283658, "parentGroupID": 357}
1086	1646	{"_key": 1646, "iconID": 1084, "nameID": 283661, "hasTypes": 1, "descriptionID": 283662, "parentGroupID": 157}
1087	1650	{"_key": 1650, "iconID": 20971, "nameID": 283705, "hasTypes": 1, "descriptionID": 283706, "parentGroupID": 52}
1088	1651	{"_key": 1651, "iconID": 16, "nameID": 283756, "hasTypes": 1, "descriptionID": 283757, "parentGroupID": 379}
1089	1652	{"_key": 1652, "iconID": 16, "nameID": 283758, "hasTypes": 1, "descriptionID": 283759, "parentGroupID": 379}
1090	1653	{"_key": 1653, "iconID": 16, "nameID": 283760, "hasTypes": 1, "descriptionID": 283761, "parentGroupID": 379}
1091	1657	{"_key": 1657, "iconID": 16, "nameID": 283767, "hasTypes": 1, "descriptionID": 283768, "parentGroupID": 379}
1092	1658	{"_key": 1658, "iconID": 16, "nameID": 283766, "hasTypes": 1, "descriptionID": 283769, "parentGroupID": 379}
1093	1659	{"_key": 1659, "nameID": 285221, "hasTypes": 0, "descriptionID": 285222}
1094	1660	{"_key": 1660, "iconID": 21065, "nameID": 285223, "hasTypes": 0, "descriptionID": 285224, "parentGroupID": 1659}
1095	1661	{"_key": 1661, "iconID": 2231, "nameID": 285268, "hasTypes": 0, "descriptionID": 285269, "parentGroupID": 1659}
1096	1662	{"_key": 1662, "iconID": 20977, "nameID": 285270, "hasTypes": 1, "descriptionID": 285271, "parentGroupID": 1659}
1097	1663	{"_key": 1663, "iconID": 20973, "nameID": 285272, "hasTypes": 1, "descriptionID": 285273, "parentGroupID": 1659}
1098	1665	{"_key": 1665, "iconID": 1394, "nameID": 285352, "hasTypes": 1, "descriptionID": 285353, "parentGroupID": 540}
1099	1666	{"_key": 1666, "iconID": 1393, "nameID": 285354, "hasTypes": 1, "descriptionID": 285355, "parentGroupID": 540}
1100	1667	{"_key": 1667, "iconID": 1395, "nameID": 285356, "hasTypes": 1, "descriptionID": 285357, "parentGroupID": 540}
1101	1668	{"_key": 1668, "iconID": 1396, "nameID": 285358, "hasTypes": 1, "descriptionID": 285359, "parentGroupID": 540}
1102	1669	{"_key": 1669, "iconID": 1030, "nameID": 285360, "hasTypes": 1, "descriptionID": 285361, "parentGroupID": 14}
1103	1670	{"_key": 1670, "iconID": 1030, "nameID": 285362, "hasTypes": 1, "descriptionID": 285363, "parentGroupID": 540}
1104	1672	{"_key": 1672, "iconID": 79, "nameID": 285368, "hasTypes": 1, "descriptionID": 285373, "parentGroupID": 133}
1105	1673	{"_key": 1673, "iconID": 79, "nameID": 285367, "hasTypes": 1, "descriptionID": 285372, "parentGroupID": 133}
1106	1674	{"_key": 1674, "iconID": 79, "nameID": 285366, "hasTypes": 1, "descriptionID": 285371, "parentGroupID": 133}
1107	1675	{"_key": 1675, "iconID": 79, "nameID": 285365, "hasTypes": 1, "descriptionID": 285374, "parentGroupID": 133}
1108	1676	{"_key": 1676, "iconID": 79, "nameID": 285364, "hasTypes": 1, "descriptionID": 285370, "parentGroupID": 133}
1109	1678	{"_key": 1678, "iconID": 1394, "nameID": 285378, "hasTypes": 1, "descriptionID": 285381, "parentGroupID": 535}
1110	1679	{"_key": 1679, "iconID": 1393, "nameID": 285377, "hasTypes": 1, "parentGroupID": 535}
1111	1680	{"_key": 1680, "iconID": 1395, "nameID": 285376, "hasTypes": 1, "descriptionID": 285380, "parentGroupID": 535}
1112	1681	{"_key": 1681, "iconID": 1396, "nameID": 285379, "hasTypes": 1, "descriptionID": 285382, "parentGroupID": 535}
1113	1682	{"_key": 1682, "iconID": 1395, "nameID": 285385, "hasTypes": 1, "descriptionID": 285386, "parentGroupID": 541}
1114	1683	{"_key": 1683, "iconID": 1394, "nameID": 285387, "hasTypes": 1, "descriptionID": 285388, "parentGroupID": 541}
1115	1684	{"_key": 1684, "iconID": 1396, "nameID": 285389, "hasTypes": 1, "descriptionID": 285390, "parentGroupID": 541}
1116	1685	{"_key": 1685, "iconID": 1393, "nameID": 285391, "hasTypes": 1, "descriptionID": 285392, "parentGroupID": 541}
1117	1686	{"_key": 1686, "iconID": 2066, "nameID": 285393, "hasTypes": 1, "descriptionID": 285394, "parentGroupID": 541}
1118	1687	{"_key": 1687, "iconID": 2066, "nameID": 285395, "hasTypes": 1, "descriptionID": 285396, "parentGroupID": 14}
1119	1688	{"_key": 1688, "iconID": 1394, "nameID": 285397, "hasTypes": 1, "descriptionID": 285398, "parentGroupID": 550}
1120	1689	{"_key": 1689, "iconID": 1393, "nameID": 285399, "hasTypes": 1, "descriptionID": 285400, "parentGroupID": 550}
1121	1690	{"_key": 1690, "iconID": 1395, "nameID": 285401, "hasTypes": 1, "descriptionID": 285402, "parentGroupID": 550}
1122	1691	{"_key": 1691, "iconID": 1396, "nameID": 285403, "hasTypes": 1, "descriptionID": 285404, "parentGroupID": 550}
1123	1692	{"_key": 1692, "iconID": 1394, "nameID": 285406, "hasTypes": 1, "descriptionID": 285407, "parentGroupID": 553}
1124	1693	{"_key": 1693, "iconID": 1393, "nameID": 285408, "hasTypes": 1, "descriptionID": 285409, "parentGroupID": 553}
1125	1694	{"_key": 1694, "iconID": 1395, "nameID": 285410, "hasTypes": 1, "descriptionID": 285411, "parentGroupID": 553}
1126	1695	{"_key": 1695, "iconID": 1396, "nameID": 285412, "hasTypes": 1, "descriptionID": 285413, "parentGroupID": 553}
1127	1696	{"_key": 1696, "iconID": 81, "nameID": 285414, "hasTypes": 1, "descriptionID": 285415, "parentGroupID": 553}
1128	1697	{"_key": 1697, "iconID": 2703, "nameID": 286396, "hasTypes": 1, "descriptionID": 292997, "parentGroupID": 252}
1129	1698	{"_key": 1698, "iconID": 1443, "nameID": 286596, "hasTypes": 1, "descriptionID": 286597, "parentGroupID": 1612}
1130	1699	{"_key": 1699, "iconID": 1443, "nameID": 286607, "hasTypes": 1, "descriptionID": 286608, "parentGroupID": 1612}
1131	1700	{"_key": 1700, "iconID": 2040, "nameID": 287124, "hasTypes": 1, "descriptionID": 287125, "parentGroupID": 19}
1132	1701	{"_key": 1701, "iconID": 2703, "nameID": 288101, "hasTypes": 1, "descriptionID": 288102, "parentGroupID": 1841}
1133	1702	{"_key": 1702, "iconID": 2222, "nameID": 288103, "hasTypes": 1, "descriptionID": 288104, "parentGroupID": 1285}
1134	1703	{"_key": 1703, "iconID": 1443, "nameID": 288167, "hasTypes": 0, "descriptionID": 288168, "parentGroupID": 1374}
1135	1704	{"_key": 1704, "iconID": 1443, "nameID": 288169, "hasTypes": 1, "descriptionID": 288170, "parentGroupID": 1703}
1136	1707	{"_key": 1707, "iconID": 2703, "nameID": 288306, "hasTypes": 1, "descriptionID": 288307, "parentGroupID": 1710}
1137	1708	{"_key": 1708, "iconID": 107, "nameID": 288308, "hasTypes": 0, "descriptionID": 288309, "parentGroupID": 9}
1138	1709	{"_key": 1709, "iconID": 21025, "nameID": 288310, "hasTypes": 1, "descriptionID": 288311, "parentGroupID": 1708}
1139	1710	{"_key": 1710, "iconID": 2703, "nameID": 288471, "hasTypes": 0, "descriptionID": 288472, "parentGroupID": 209}
1140	1711	{"_key": 1711, "iconID": 2703, "nameID": 288473, "hasTypes": 0, "descriptionID": 288474, "parentGroupID": 209}
1141	1712	{"_key": 1712, "iconID": 2703, "nameID": 288475, "hasTypes": 1, "descriptionID": 288476, "parentGroupID": 1711}
1142	1713	{"_key": 1713, "iconID": 1061, "nameID": 288477, "hasTypes": 0, "descriptionID": 288478, "parentGroupID": 9}
1143	1715	{"_key": 1715, "iconID": 3240, "nameID": 288479, "hasTypes": 1, "parentGroupID": 1713}
1144	1716	{"_key": 1716, "iconID": 2703, "nameID": 288492, "hasTypes": 1, "descriptionID": 288493, "parentGroupID": 1710}
1145	1717	{"_key": 1717, "iconID": 2677, "nameID": 288494, "hasTypes": 1, "descriptionID": 288495, "parentGroupID": 1708}
1146	1718	{"_key": 1718, "iconID": 2856, "nameID": 288503, "hasTypes": 1, "descriptionID": 288504, "parentGroupID": 1708}
1147	1719	{"_key": 1719, "iconID": 2703, "nameID": 288769, "hasTypes": 1, "descriptionID": 288770, "parentGroupID": 944}
1148	1720	{"_key": 1720, "iconID": 2703, "nameID": 288777, "hasTypes": 1, "descriptionID": 288778, "parentGroupID": 945}
1149	1721	{"_key": 1721, "iconID": 2703, "nameID": 288782, "hasTypes": 1, "descriptionID": 288783, "parentGroupID": 946}
1150	1723	{"_key": 1723, "iconID": 2703, "nameID": 288789, "hasTypes": 1, "descriptionID": 288790, "parentGroupID": 948}
1151	1724	{"_key": 1724, "iconID": 2703, "nameID": 288791, "hasTypes": 1, "descriptionID": 288792, "parentGroupID": 949}
1152	1725	{"_key": 1725, "iconID": 2703, "nameID": 288793, "hasTypes": 1, "descriptionID": 288794, "parentGroupID": 950}
1153	1726	{"_key": 1726, "iconID": 2703, "nameID": 288795, "hasTypes": 1, "descriptionID": 288796, "parentGroupID": 951}
1154	1727	{"_key": 1727, "iconID": 2703, "nameID": 288797, "hasTypes": 1, "descriptionID": 288798, "parentGroupID": 952}
1155	1728	{"_key": 1728, "iconID": 2703, "nameID": 288799, "hasTypes": 1, "descriptionID": 288800, "parentGroupID": 953}
1156	1729	{"_key": 1729, "iconID": 2703, "nameID": 288801, "hasTypes": 1, "descriptionID": 288802, "parentGroupID": 954}
1157	1730	{"_key": 1730, "iconID": 3194, "nameID": 288803, "hasTypes": 1, "descriptionID": 288804, "parentGroupID": 956}
1158	1731	{"_key": 1731, "iconID": 3201, "nameID": 288805, "hasTypes": 1, "descriptionID": 288806, "parentGroupID": 979}
1159	1732	{"_key": 1732, "iconID": 3193, "nameID": 288807, "hasTypes": 1, "descriptionID": 288808, "parentGroupID": 965}
1160	1733	{"_key": 1733, "iconID": 3197, "nameID": 288809, "hasTypes": 1, "descriptionID": 288810, "parentGroupID": 964}
1161	1734	{"_key": 1734, "iconID": 3202, "nameID": 288811, "hasTypes": 1, "descriptionID": 288812, "parentGroupID": 963}
1162	1735	{"_key": 1735, "iconID": 3203, "nameID": 288813, "hasTypes": 1, "descriptionID": 288814, "parentGroupID": 962}
1163	1736	{"_key": 1736, "iconID": 3195, "nameID": 288815, "hasTypes": 1, "descriptionID": 288816, "parentGroupID": 961}
1164	1737	{"_key": 1737, "iconID": 3198, "nameID": 288817, "hasTypes": 1, "descriptionID": 288818, "parentGroupID": 960}
1165	1739	{"_key": 1739, "iconID": 3200, "nameID": 288821, "hasTypes": 1, "descriptionID": 288822, "parentGroupID": 958}
1166	1740	{"_key": 1740, "iconID": 3196, "nameID": 288823, "hasTypes": 1, "descriptionID": 288824, "parentGroupID": 957}
1167	1745	{"_key": 1745, "iconID": 33, "nameID": 288862, "hasTypes": 1, "descriptionID": 288863, "parentGroupID": 150}
1168	1746	{"_key": 1746, "iconID": 33, "nameID": 288864, "hasTypes": 1, "descriptionID": 288865, "parentGroupID": 150}
1169	1747	{"_key": 1747, "iconID": 33, "nameID": 288866, "hasTypes": 1, "descriptionID": 288867, "parentGroupID": 150}
1170	1748	{"_key": 1748, "iconID": 33, "nameID": 288869, "hasTypes": 1, "descriptionID": 288870, "parentGroupID": 150}
1171	1761	{"_key": 1761, "iconID": 2224, "nameID": 288917, "hasTypes": 0, "descriptionID": 288918, "parentGroupID": 531}
1172	1762	{"_key": 1762, "iconID": 2224, "nameID": 288919, "hasTypes": 0, "descriptionID": 288920, "parentGroupID": 531}
1173	1763	{"_key": 1763, "iconID": 2224, "nameID": 288921, "hasTypes": 0, "descriptionID": 288922, "parentGroupID": 531}
1174	1764	{"_key": 1764, "iconID": 2224, "nameID": 288923, "hasTypes": 0, "descriptionID": 288924, "parentGroupID": 531}
1175	1765	{"_key": 1765, "iconID": 2224, "nameID": 288925, "hasTypes": 1, "descriptionID": 288926, "parentGroupID": 1761}
1176	1766	{"_key": 1766, "iconID": 2224, "nameID": 288927, "hasTypes": 1, "descriptionID": 288928, "parentGroupID": 1761}
1177	1767	{"_key": 1767, "iconID": 2224, "nameID": 288929, "hasTypes": 1, "descriptionID": 288930, "parentGroupID": 1762}
1178	1768	{"_key": 1768, "iconID": 2224, "nameID": 288931, "hasTypes": 1, "descriptionID": 288932, "parentGroupID": 1762}
1179	1769	{"_key": 1769, "iconID": 2224, "nameID": 288933, "hasTypes": 1, "descriptionID": 288934, "parentGroupID": 1762}
1180	1770	{"_key": 1770, "iconID": 2224, "nameID": 288936, "hasTypes": 1, "descriptionID": 288937, "parentGroupID": 1763}
1181	1771	{"_key": 1771, "iconID": 2224, "nameID": 288938, "hasTypes": 1, "descriptionID": 288939, "parentGroupID": 1763}
1182	1772	{"_key": 1772, "iconID": 2224, "nameID": 288940, "hasTypes": 1, "descriptionID": 288941, "parentGroupID": 1763}
1183	1773	{"_key": 1773, "iconID": 2224, "nameID": 288942, "hasTypes": 1, "descriptionID": 288943, "parentGroupID": 1763}
1184	1774	{"_key": 1774, "iconID": 2224, "nameID": 288944, "hasTypes": 1, "descriptionID": 288945, "parentGroupID": 1763}
1185	1775	{"_key": 1775, "iconID": 2224, "nameID": 288948, "hasTypes": 1, "descriptionID": 288949, "parentGroupID": 1764}
1186	1776	{"_key": 1776, "iconID": 2224, "nameID": 288950, "hasTypes": 1, "descriptionID": 288951, "parentGroupID": 1764}
1187	1777	{"_key": 1777, "iconID": 2224, "nameID": 288952, "hasTypes": 1, "descriptionID": 288953, "parentGroupID": 1764}
1188	1779	{"_key": 1779, "iconID": 21057, "nameID": 288956, "hasTypes": 0, "descriptionID": 288957, "parentGroupID": 1111}
1189	1780	{"_key": 1780, "iconID": 21058, "nameID": 288958, "hasTypes": 0, "descriptionID": 288959, "parentGroupID": 1111}
1190	1781	{"_key": 1781, "iconID": 21059, "nameID": 288960, "hasTypes": 0, "descriptionID": 288961, "parentGroupID": 1111}
1191	1782	{"_key": 1782, "iconID": 21057, "nameID": 288962, "hasTypes": 1, "descriptionID": 288963, "parentGroupID": 1779}
1192	1783	{"_key": 1783, "iconID": 21057, "nameID": 288964, "hasTypes": 1, "descriptionID": 288965, "parentGroupID": 1779}
1193	1784	{"_key": 1784, "iconID": 21057, "nameID": 288966, "hasTypes": 1, "descriptionID": 288967, "parentGroupID": 1779}
1194	1785	{"_key": 1785, "iconID": 21057, "nameID": 288968, "hasTypes": 1, "descriptionID": 288969, "parentGroupID": 1779}
1195	1786	{"_key": 1786, "iconID": 21058, "nameID": 288970, "hasTypes": 1, "descriptionID": 288971, "parentGroupID": 1780}
1196	1787	{"_key": 1787, "iconID": 21058, "nameID": 288972, "hasTypes": 1, "descriptionID": 288973, "parentGroupID": 1780}
1197	1788	{"_key": 1788, "iconID": 21058, "nameID": 288974, "hasTypes": 1, "descriptionID": 288975, "parentGroupID": 1780}
1198	1789	{"_key": 1789, "iconID": 21058, "nameID": 288976, "hasTypes": 1, "descriptionID": 288977, "parentGroupID": 1780}
1199	1790	{"_key": 1790, "iconID": 21059, "nameID": 288978, "hasTypes": 1, "descriptionID": 288979, "parentGroupID": 1781}
1200	1791	{"_key": 1791, "iconID": 21059, "nameID": 288980, "hasTypes": 1, "descriptionID": 288981, "parentGroupID": 1781}
1201	1792	{"_key": 1792, "iconID": 21059, "nameID": 288982, "hasTypes": 1, "descriptionID": 288983, "parentGroupID": 1781}
1202	1793	{"_key": 1793, "iconID": 21059, "nameID": 288984, "hasTypes": 1, "descriptionID": 288985, "parentGroupID": 1781}
1203	1794	{"_key": 1794, "iconID": 2703, "nameID": 289000, "hasTypes": 0, "descriptionID": 289001, "parentGroupID": 943}
1204	1795	{"_key": 1795, "iconID": 2703, "nameID": 289002, "hasTypes": 0, "descriptionID": 289003, "parentGroupID": 943}
1205	1796	{"_key": 1796, "iconID": 2703, "nameID": 289004, "hasTypes": 0, "descriptionID": 289005, "parentGroupID": 943}
1206	1797	{"_key": 1797, "iconID": 2703, "nameID": 289006, "hasTypes": 1, "descriptionID": 289007, "parentGroupID": 1794}
1207	1798	{"_key": 1798, "iconID": 2703, "nameID": 289008, "hasTypes": 1, "descriptionID": 289009, "parentGroupID": 1794}
1208	1799	{"_key": 1799, "iconID": 2703, "nameID": 289010, "hasTypes": 1, "descriptionID": 289011, "parentGroupID": 1794}
1209	1800	{"_key": 1800, "iconID": 2703, "nameID": 289012, "hasTypes": 1, "descriptionID": 289013, "parentGroupID": 1794}
1210	1801	{"_key": 1801, "iconID": 2703, "nameID": 289014, "hasTypes": 1, "descriptionID": 289015, "parentGroupID": 1795}
1211	1802	{"_key": 1802, "iconID": 2703, "nameID": 289016, "hasTypes": 1, "descriptionID": 289017, "parentGroupID": 1795}
1212	1803	{"_key": 1803, "iconID": 2703, "nameID": 289018, "hasTypes": 1, "descriptionID": 289019, "parentGroupID": 1795}
1213	1804	{"_key": 1804, "iconID": 2703, "nameID": 289020, "hasTypes": 1, "descriptionID": 289021, "parentGroupID": 1795}
1214	1805	{"_key": 1805, "iconID": 2703, "nameID": 289022, "hasTypes": 1, "descriptionID": 289023, "parentGroupID": 1796}
1215	1806	{"_key": 1806, "iconID": 2703, "nameID": 289024, "hasTypes": 1, "descriptionID": 289025, "parentGroupID": 1796}
1216	1807	{"_key": 1807, "iconID": 2703, "nameID": 289026, "hasTypes": 1, "descriptionID": 289027, "parentGroupID": 1796}
1217	1808	{"_key": 1808, "iconID": 2703, "nameID": 289028, "hasTypes": 1, "descriptionID": 289029, "parentGroupID": 1796}
1218	1809	{"_key": 1809, "iconID": 2703, "nameID": 289137, "hasTypes": 1, "descriptionID": 289138, "parentGroupID": 1710}
1219	1810	{"_key": 1810, "iconID": 21065, "nameID": 289171, "hasTypes": 0, "descriptionID": 289172, "parentGroupID": 1660}
1220	1811	{"_key": 1811, "iconID": 20974, "nameID": 289173, "hasTypes": 0, "descriptionID": 289174, "parentGroupID": 1660}
1221	1812	{"_key": 1812, "iconID": 21065, "nameID": 289175, "hasTypes": 1, "descriptionID": 289176, "parentGroupID": 1810}
1222	1813	{"_key": 1813, "iconID": 20974, "nameID": 289177, "hasTypes": 1, "descriptionID": 289178, "parentGroupID": 1811}
1223	1814	{"_key": 1814, "iconID": 21047, "nameID": 289179, "hasTypes": 1, "descriptionID": 289180, "parentGroupID": 1659}
1224	1815	{"_key": 1815, "iconID": 1443, "nameID": 289264, "hasTypes": 0, "descriptionID": 289265, "parentGroupID": 4}
1225	1816	{"_key": 1816, "iconID": 20959, "nameID": 289266, "hasTypes": 1, "descriptionID": 289267, "parentGroupID": 1815}
1226	1817	{"_key": 1817, "iconID": 20966, "nameID": 289268, "hasTypes": 1, "descriptionID": 289269, "parentGroupID": 1815}
1227	1818	{"_key": 1818, "iconID": 20967, "nameID": 289270, "hasTypes": 1, "descriptionID": 289271, "parentGroupID": 1815}
1228	1819	{"_key": 1819, "iconID": 20968, "nameID": 289272, "hasTypes": 1, "descriptionID": 289273, "parentGroupID": 1815}
1229	1822	{"_key": 1822, "iconID": 21048, "nameID": 289360, "hasTypes": 1, "descriptionID": 289361, "parentGroupID": 1407}
1230	1823	{"_key": 1823, "iconID": 33, "nameID": 289822, "hasTypes": 1, "descriptionID": 289823, "parentGroupID": 150}
1231	1824	{"_key": 1824, "iconID": 33, "nameID": 289824, "hasTypes": 1, "descriptionID": 289825, "parentGroupID": 150}
1232	1827	{"_key": 1827, "iconID": 21074, "nameID": 290301, "hasTypes": 1, "parentGroupID": 140}
1233	1828	{"_key": 1828, "iconID": 2703, "nameID": 292452, "hasTypes": 1, "descriptionID": 292453, "parentGroupID": 406}
1234	1829	{"_key": 1829, "iconID": 2703, "nameID": 292454, "hasTypes": 1, "descriptionID": 292455, "parentGroupID": 406}
1235	1830	{"_key": 1830, "iconID": 2703, "nameID": 292456, "hasTypes": 1, "descriptionID": 292457, "parentGroupID": 406}
1236	1831	{"_key": 1831, "iconID": 16, "nameID": 292458, "hasTypes": 1, "parentGroupID": 404}
1237	1832	{"_key": 1832, "iconID": 16, "nameID": 292459, "hasTypes": 1, "parentGroupID": 404}
1238	1833	{"_key": 1833, "iconID": 16, "nameID": 292460, "hasTypes": 1, "parentGroupID": 404}
1239	1834	{"_key": 1834, "iconID": 2703, "nameID": 292478, "hasTypes": 1, "descriptionID": 292480, "parentGroupID": 406}
1240	1835	{"_key": 1835, "iconID": 16, "nameID": 292485, "hasTypes": 1, "descriptionID": 292486, "parentGroupID": 404}
1241	1836	{"_key": 1836, "iconID": 21078, "nameID": 292613, "hasTypes": 1, "descriptionID": 292614, "parentGroupID": 1407}
1242	1837	{"_key": 1837, "iconID": 1443, "nameID": 292713, "hasTypes": 1, "parentGroupID": 1612}
1243	1838	{"_key": 1838, "iconID": 1443, "nameID": 292714, "hasTypes": 1, "parentGroupID": 1612}
1244	1840	{"_key": 1840, "iconID": 2039, "nameID": 293385, "hasTypes": 1, "descriptionID": 296523, "parentGroupID": 19}
1245	1841	{"_key": 1841, "iconID": 2703, "nameID": 294036, "hasTypes": 0, "descriptionID": 294037, "parentGroupID": 1338}
1246	1842	{"_key": 1842, "iconID": 2703, "nameID": 294173, "hasTypes": 1, "parentGroupID": 406}
1247	1843	{"_key": 1843, "iconID": 2703, "nameID": 294174, "hasTypes": 1, "parentGroupID": 406}
1248	1844	{"_key": 1844, "iconID": 16, "nameID": 294175, "hasTypes": 1, "parentGroupID": 404}
1249	1845	{"_key": 1845, "iconID": 16, "nameID": 294176, "hasTypes": 1, "parentGroupID": 404}
1250	1846	{"_key": 1846, "iconID": 24565, "nameID": 294260, "hasTypes": 1, "descriptionID": 294261, "parentGroupID": 19}
1251	1847	{"_key": 1847, "iconID": 16, "nameID": 294262, "hasTypes": 1, "descriptionID": 294263, "parentGroupID": 404}
1252	1849	{"_key": 1849, "iconID": 21783, "nameID": 294560, "hasTypes": 0, "descriptionID": 294561, "parentGroupID": 2}
1253	1850	{"_key": 1850, "iconID": 2665, "nameID": 294562, "hasTypes": 1, "descriptionID": 294563, "parentGroupID": 1849}
1254	1851	{"_key": 1851, "iconID": 2665, "nameID": 294564, "hasTypes": 1, "descriptionID": 294565, "parentGroupID": 1849}
1255	1852	{"_key": 1852, "iconID": 2665, "nameID": 294566, "hasTypes": 1, "descriptionID": 294567, "parentGroupID": 1849}
1256	1853	{"_key": 1853, "iconID": 2665, "nameID": 294568, "hasTypes": 1, "descriptionID": 294569, "parentGroupID": 1849}
1257	1854	{"_key": 1854, "iconID": 2665, "nameID": 294570, "hasTypes": 1, "descriptionID": 294571, "parentGroupID": 1849}
1258	1855	{"_key": 1855, "iconID": 2554, "nameID": 294572, "hasTypes": 1, "descriptionID": 294573, "parentGroupID": 1031}
1259	1856	{"_key": 1856, "iconID": 2215, "nameID": 294574, "hasTypes": 1, "descriptionID": 294575, "parentGroupID": 1031}
1260	1857	{"_key": 1857, "iconID": 404, "nameID": 294576, "hasTypes": 1, "descriptionID": 294577, "parentGroupID": 533}
1261	1858	{"_key": 1858, "iconID": 2664, "nameID": 294578, "hasTypes": 1, "descriptionID": 294579, "parentGroupID": 1034}
1262	1859	{"_key": 1859, "iconID": 3222, "nameID": 294581, "hasTypes": 1, "descriptionID": 294582, "parentGroupID": 1032}
1263	1860	{"_key": 1860, "iconID": 3751, "nameID": 294586, "hasTypes": 1, "descriptionID": 294587, "parentGroupID": 1034}
1264	1861	{"_key": 1861, "iconID": 3256, "nameID": 294588, "hasTypes": 0, "parentGroupID": 533}
1265	1862	{"_key": 1862, "iconID": 3722, "nameID": 294589, "hasTypes": 1, "descriptionID": 294590, "parentGroupID": 1861}
1266	1863	{"_key": 1863, "iconID": 3260, "nameID": 294591, "hasTypes": 1, "descriptionID": 294592, "parentGroupID": 1861}
1267	1864	{"_key": 1864, "iconID": 3303, "nameID": 294593, "hasTypes": 1, "descriptionID": 294594, "parentGroupID": 1021}
1268	1865	{"_key": 1865, "iconID": 2875, "nameID": 294595, "hasTypes": 1, "descriptionID": 294596, "parentGroupID": 1035}
1269	1866	{"_key": 1866, "iconID": 20959, "nameID": 294597, "hasTypes": 1, "descriptionID": 294598, "parentGroupID": 1022}
1270	1867	{"_key": 1867, "iconID": 20966, "nameID": 294599, "hasTypes": 1, "descriptionID": 294600, "parentGroupID": 1022}
1271	1868	{"_key": 1868, "iconID": 20967, "nameID": 294601, "hasTypes": 1, "descriptionID": 294602, "parentGroupID": 1022}
1272	1869	{"_key": 1869, "iconID": 20968, "nameID": 294603, "hasTypes": 1, "descriptionID": 294604, "parentGroupID": 1022}
1273	1870	{"_key": 1870, "iconID": 10835, "nameID": 294605, "hasTypes": 1, "descriptionID": 294606, "parentGroupID": 1035}
1274	1872	{"_key": 1872, "iconID": 2225, "nameID": 294612, "hasTypes": 0, "descriptionID": 294613, "parentGroupID": 475}
1275	1873	{"_key": 1873, "iconID": 2885, "nameID": 294614, "hasTypes": 1, "parentGroupID": 1872}
1276	1880	{"_key": 1880, "iconID": 3233, "nameID": 294629, "hasTypes": 1, "descriptionID": 294630, "parentGroupID": 1872}
1277	1883	{"_key": 1883, "iconID": 2193, "nameID": 294637, "hasTypes": 0, "descriptionID": 294638, "parentGroupID": 1035}
1278	1884	{"_key": 1884, "iconID": 20959, "nameID": 294639, "hasTypes": 1, "parentGroupID": 1883}
1279	1885	{"_key": 1885, "iconID": 20966, "nameID": 294640, "hasTypes": 1, "parentGroupID": 1883}
1280	1886	{"_key": 1886, "iconID": 20967, "nameID": 294641, "hasTypes": 1, "parentGroupID": 1883}
1281	1887	{"_key": 1887, "iconID": 20968, "nameID": 294642, "hasTypes": 1, "parentGroupID": 1883}
1282	1888	{"_key": 1888, "iconID": 20967, "nameID": 294643, "hasTypes": 1, "parentGroupID": 65}
1283	1889	{"_key": 1889, "iconID": 20968, "nameID": 294644, "hasTypes": 1, "parentGroupID": 65}
1284	1897	{"_key": 1897, "iconID": 2890, "nameID": 294751, "hasTypes": 0, "parentGroupID": 533}
1285	1898	{"_key": 1898, "iconID": 2887, "nameID": 294754, "hasTypes": 1, "descriptionID": 294755, "parentGroupID": 1897}
1286	1899	{"_key": 1899, "iconID": 2890, "nameID": 294758, "hasTypes": 1, "descriptionID": 294759, "parentGroupID": 1897}
1287	1900	{"_key": 1900, "iconID": 2888, "nameID": 294760, "hasTypes": 1, "descriptionID": 294761, "parentGroupID": 1897}
1288	1901	{"_key": 1901, "iconID": 2890, "nameID": 294762, "hasTypes": 1, "descriptionID": 294763, "parentGroupID": 1897}
1289	1902	{"_key": 1902, "iconID": 2889, "nameID": 294764, "hasTypes": 1, "descriptionID": 294765, "parentGroupID": 1897}
1290	1903	{"_key": 1903, "iconID": 2886, "nameID": 294766, "hasTypes": 1, "descriptionID": 294767, "parentGroupID": 1897}
1291	1904	{"_key": 1904, "iconID": 2890, "nameID": 294768, "hasTypes": 1, "descriptionID": 294769, "parentGroupID": 1897}
1292	1905	{"_key": 1905, "iconID": 2886, "nameID": 294770, "hasTypes": 1, "descriptionID": 294771, "parentGroupID": 1897}
1293	1906	{"_key": 1906, "iconID": 3335, "nameID": 294772, "hasTypes": 1, "descriptionID": 294773, "parentGroupID": 1897}
1294	1907	{"_key": 1907, "iconID": 2225, "nameID": 294779, "hasTypes": 1, "descriptionID": 294780, "parentGroupID": 1872}
1295	1908	{"_key": 1908, "iconID": 2226, "nameID": 294781, "hasTypes": 1, "descriptionID": 294782, "parentGroupID": 1035}
1296	1909	{"_key": 1909, "iconID": 3736, "nameID": 294857, "hasTypes": 1, "parentGroupID": 1872}
1297	1912	{"_key": 1912, "iconID": 2703, "nameID": 294868, "hasTypes": 1, "parentGroupID": 798}
1298	1913	{"_key": 1913, "iconID": 2703, "nameID": 294869, "hasTypes": 1, "parentGroupID": 800}
1299	1918	{"_key": 1918, "iconID": 2703, "nameID": 294874, "hasTypes": 1, "parentGroupID": 800}
1300	1919	{"_key": 1919, "iconID": 2703, "nameID": 294875, "hasTypes": 1, "parentGroupID": 1522}
1301	1920	{"_key": 1920, "iconID": 2703, "nameID": 294876, "hasTypes": 1, "parentGroupID": 800}
1302	1921	{"_key": 1921, "iconID": 2222, "nameID": 294899, "hasTypes": 1, "descriptionID": 294900, "parentGroupID": 1285}
1303	1922	{"_key": 1922, "iconID": 21481, "nameID": 294916, "hasTypes": 0, "descriptionID": 296382}
1304	1923	{"_key": 1923, "iconID": 21481, "nameID": 294918, "hasTypes": 1, "descriptionID": 296374, "parentGroupID": 1922}
1305	1924	{"_key": 1924, "iconID": 1443, "nameID": 295182, "hasTypes": 1, "parentGroupID": 1364}
1306	1931	{"_key": 1931, "iconID": 98, "nameID": 295696, "hasTypes": 1, "parentGroupID": 132}
1307	1932	{"_key": 1932, "iconID": 1443, "nameID": 295888, "hasTypes": 1, "parentGroupID": 1612}
1308	1935	{"_key": 1935, "iconID": 111, "nameID": 296252, "hasTypes": 1, "parentGroupID": 657}
1309	1936	{"_key": 1936, "iconID": 3433, "nameID": 296253, "hasTypes": 1, "parentGroupID": 657}
1310	1937	{"_key": 1937, "iconID": 2990, "nameID": 296257, "hasTypes": 1, "parentGroupID": 657}
1311	1938	{"_key": 1938, "iconID": 2703, "nameID": 296264, "hasTypes": 1, "parentGroupID": 1566}
1312	1939	{"_key": 1939, "iconID": 2703, "nameID": 296265, "hasTypes": 1, "parentGroupID": 1566}
1313	1940	{"_key": 1940, "iconID": 2703, "nameID": 296266, "hasTypes": 1, "parentGroupID": 1566}
1314	1941	{"_key": 1941, "iconID": 98, "nameID": 296288, "hasTypes": 1, "parentGroupID": 132}
1315	1942	{"_key": 1942, "iconID": 21335, "nameID": 296375, "hasTypes": 1, "descriptionID": 296526, "parentGroupID": 1922}
1316	1943	{"_key": 1943, "iconID": 21204, "nameID": 296376, "hasTypes": 1, "parentGroupID": 1407}
1317	1944	{"_key": 1944, "iconID": 21275, "nameID": 296377, "hasTypes": 1, "parentGroupID": 1402}
1318	1945	{"_key": 1945, "iconID": 2703, "nameID": 296457, "hasTypes": 1, "descriptionID": 296458, "parentGroupID": 1841}
1319	1949	{"_key": 1949, "iconID": 2703, "nameID": 297631, "hasTypes": 1, "descriptionID": 297632, "parentGroupID": 787}
1320	1950	{"_key": 1950, "iconID": 27058, "nameID": 297633, "hasTypes": 1, "descriptionID": 297634, "parentGroupID": 766}
1321	1951	{"_key": 1951, "iconID": 1443, "nameID": 298043, "hasTypes": 0, "parentGroupID": 1373}
1322	1952	{"_key": 1952, "iconID": 20959, "nameID": 298044, "hasTypes": 1, "parentGroupID": 1951}
1323	1953	{"_key": 1953, "iconID": 20968, "nameID": 305008, "hasTypes": 1, "parentGroupID": 1951}
1324	1954	{"_key": 1954, "iconID": 21420, "nameID": 305465, "hasTypes": 0, "descriptionID": 305466}
1325	1955	{"_key": 1955, "iconID": 21420, "nameID": 305467, "hasTypes": 0, "parentGroupID": 1954}
1326	1956	{"_key": 1956, "iconID": 20959, "nameID": 305468, "hasTypes": 1, "parentGroupID": 2101}
1327	1957	{"_key": 1957, "iconID": 20966, "nameID": 305469, "hasTypes": 1, "parentGroupID": 2101}
1328	1958	{"_key": 1958, "iconID": 20967, "nameID": 305470, "hasTypes": 1, "parentGroupID": 2101}
1329	1959	{"_key": 1959, "iconID": 20968, "nameID": 305471, "hasTypes": 1, "parentGroupID": 2101}
1330	1960	{"_key": 1960, "iconID": 21420, "nameID": 305472, "hasTypes": 0, "parentGroupID": 1954}
1331	1961	{"_key": 1961, "iconID": 21420, "nameID": 305473, "hasTypes": 0, "parentGroupID": 1960}
1332	1962	{"_key": 1962, "iconID": 21420, "nameID": 305474, "hasTypes": 0, "parentGroupID": 1960}
1333	1963	{"_key": 1963, "iconID": 21420, "nameID": 305475, "hasTypes": 1, "parentGroupID": 1961}
1334	1964	{"_key": 1964, "iconID": 20959, "nameID": 305476, "hasTypes": 1, "parentGroupID": 1962}
1335	1965	{"_key": 1965, "iconID": 20966, "nameID": 305477, "hasTypes": 1, "parentGroupID": 1962}
1336	1966	{"_key": 1966, "iconID": 20967, "nameID": 305478, "hasTypes": 1, "parentGroupID": 1962}
1337	1967	{"_key": 1967, "iconID": 20968, "nameID": 305479, "hasTypes": 1, "parentGroupID": 1962}
1338	1968	{"_key": 1968, "iconID": 21420, "nameID": 305480, "hasTypes": 0, "parentGroupID": 1954}
1339	1969	{"_key": 1969, "iconID": 21420, "nameID": 305481, "hasTypes": 1, "parentGroupID": 2114}
1340	1970	{"_key": 1970, "iconID": 21420, "nameID": 305482, "hasTypes": 0, "parentGroupID": 1968}
1341	1971	{"_key": 1971, "iconID": 21420, "nameID": 305483, "hasTypes": 0, "parentGroupID": 1968}
1342	1972	{"_key": 1972, "iconID": 21420, "nameID": 305484, "hasTypes": 0, "parentGroupID": 1968}
1343	1973	{"_key": 1973, "iconID": 21420, "nameID": 305485, "hasTypes": 0, "parentGroupID": 1968}
1344	1974	{"_key": 1974, "iconID": 20959, "nameID": 305486, "hasTypes": 1, "parentGroupID": 2374}
1345	1975	{"_key": 1975, "iconID": 20966, "nameID": 305487, "hasTypes": 1, "parentGroupID": 2374}
1346	1976	{"_key": 1976, "iconID": 20967, "nameID": 305488, "hasTypes": 1, "parentGroupID": 2374}
1347	1977	{"_key": 1977, "iconID": 20968, "nameID": 305489, "hasTypes": 1, "parentGroupID": 2374}
1348	1978	{"_key": 1978, "iconID": 20959, "nameID": 305490, "hasTypes": 1, "parentGroupID": 2381}
1349	1979	{"_key": 1979, "iconID": 20967, "nameID": 305491, "hasTypes": 1, "parentGroupID": 2381}
1350	1980	{"_key": 1980, "iconID": 20959, "nameID": 305492, "hasTypes": 1, "parentGroupID": 2377}
1351	1981	{"_key": 1981, "iconID": 20966, "nameID": 305493, "hasTypes": 1, "parentGroupID": 2377}
1352	1982	{"_key": 1982, "iconID": 20967, "nameID": 305494, "hasTypes": 1, "parentGroupID": 2377}
1353	1983	{"_key": 1983, "iconID": 20968, "nameID": 305495, "hasTypes": 1, "parentGroupID": 2377}
1354	1984	{"_key": 1984, "iconID": 20959, "nameID": 305496, "hasTypes": 1, "parentGroupID": 1972}
1355	1985	{"_key": 1985, "iconID": 20966, "nameID": 305497, "hasTypes": 1, "parentGroupID": 1972}
1356	1986	{"_key": 1986, "iconID": 20967, "nameID": 305498, "hasTypes": 1, "parentGroupID": 1972}
1357	1987	{"_key": 1987, "iconID": 20968, "nameID": 305499, "hasTypes": 1, "parentGroupID": 1972}
1358	1988	{"_key": 1988, "iconID": 21420, "nameID": 305500, "hasTypes": 0, "parentGroupID": 1954}
1359	1989	{"_key": 1989, "iconID": 21420, "nameID": 305501, "hasTypes": 0, "parentGroupID": 1954}
1360	1990	{"_key": 1990, "iconID": 20959, "nameID": 305502, "hasTypes": 1, "parentGroupID": 2028}
1361	1991	{"_key": 1991, "iconID": 20966, "nameID": 305503, "hasTypes": 1, "parentGroupID": 2028}
1362	1992	{"_key": 1992, "iconID": 20967, "nameID": 305504, "hasTypes": 1, "parentGroupID": 2028}
1363	1993	{"_key": 1993, "iconID": 20968, "nameID": 305505, "hasTypes": 1, "parentGroupID": 2028}
1364	1994	{"_key": 1994, "iconID": 20959, "nameID": 305506, "hasTypes": 1, "parentGroupID": 2035}
1365	1995	{"_key": 1995, "iconID": 20966, "nameID": 305507, "hasTypes": 1, "parentGroupID": 2035}
1366	1996	{"_key": 1996, "iconID": 20967, "nameID": 305508, "hasTypes": 1, "parentGroupID": 2035}
1367	1997	{"_key": 1997, "iconID": 20968, "nameID": 305509, "hasTypes": 1, "parentGroupID": 2035}
1368	1998	{"_key": 1998, "iconID": 21420, "nameID": 305510, "hasTypes": 0, "parentGroupID": 1954}
1369	1999	{"_key": 1999, "iconID": 21420, "nameID": 305511, "hasTypes": 0, "parentGroupID": 1998}
1370	2000	{"_key": 2000, "iconID": 21420, "nameID": 305512, "hasTypes": 1, "parentGroupID": 1999}
1371	2001	{"_key": 2001, "iconID": 21420, "nameID": 305513, "hasTypes": 0, "parentGroupID": 1998}
1372	2002	{"_key": 2002, "iconID": 20959, "nameID": 305514, "hasTypes": 1, "parentGroupID": 2001}
1373	2003	{"_key": 2003, "iconID": 20966, "nameID": 305515, "hasTypes": 1, "parentGroupID": 2001}
1374	2004	{"_key": 2004, "iconID": 20967, "nameID": 305516, "hasTypes": 1, "parentGroupID": 2001}
1375	2005	{"_key": 2005, "iconID": 20968, "nameID": 305517, "hasTypes": 1, "parentGroupID": 2001}
1376	2006	{"_key": 2006, "iconID": 21420, "nameID": 305518, "hasTypes": 0, "parentGroupID": 1954}
1377	2007	{"_key": 2007, "iconID": 20959, "nameID": 305519, "hasTypes": 1, "parentGroupID": 2085}
1378	2008	{"_key": 2008, "iconID": 20966, "nameID": 305520, "hasTypes": 1, "parentGroupID": 2085}
1379	2009	{"_key": 2009, "iconID": 20967, "nameID": 305521, "hasTypes": 1, "parentGroupID": 2085}
1380	2010	{"_key": 2010, "iconID": 20968, "nameID": 305522, "hasTypes": 1, "parentGroupID": 2085}
1381	2011	{"_key": 2011, "iconID": 21420, "nameID": 305523, "hasTypes": 0, "parentGroupID": 1954}
1382	2012	{"_key": 2012, "iconID": 21420, "nameID": 305526, "hasTypes": 1, "parentGroupID": 2011}
1383	2013	{"_key": 2013, "iconID": 2889, "nameID": 306040, "hasTypes": 1, "descriptionID": 306041, "parentGroupID": 19}
1384	2014	{"_key": 2014, "iconID": 2703, "nameID": 306798, "hasTypes": 1, "descriptionID": 306802, "parentGroupID": 2015}
1385	2015	{"_key": 2015, "iconID": 2703, "nameID": 306835, "hasTypes": 0, "parentGroupID": 1338}
1386	2016	{"_key": 2016, "iconID": 2703, "nameID": 306836, "hasTypes": 1, "descriptionID": 306837, "parentGroupID": 2015}
1387	2017	{"_key": 2017, "iconID": 2703, "nameID": 306838, "hasTypes": 1, "descriptionID": 306839, "parentGroupID": 2015}
1388	2018	{"_key": 2018, "iconID": 21421, "nameID": 306841, "hasTypes": 1, "parentGroupID": 1708}
1389	2020	{"_key": 2020, "iconID": 2703, "nameID": 306843, "hasTypes": 1, "descriptionID": 306844, "parentGroupID": 1710}
1390	2021	{"_key": 2021, "iconID": 20966, "nameID": 308858, "hasTypes": 1, "parentGroupID": 1951}
1391	2022	{"_key": 2022, "iconID": 21420, "nameID": 309244, "hasTypes": 0, "parentGroupID": 1960}
1392	2023	{"_key": 2023, "iconID": 21420, "nameID": 309245, "hasTypes": 0, "parentGroupID": 2022}
1393	2024	{"_key": 2024, "iconID": 20959, "nameID": 309246, "hasTypes": 1, "parentGroupID": 2023}
1394	2025	{"_key": 2025, "iconID": 20966, "nameID": 309247, "hasTypes": 1, "parentGroupID": 2023}
1395	2026	{"_key": 2026, "iconID": 20967, "nameID": 309248, "hasTypes": 1, "parentGroupID": 2023}
1396	2027	{"_key": 2027, "iconID": 20968, "nameID": 309249, "hasTypes": 1, "parentGroupID": 2023}
1397	2028	{"_key": 2028, "iconID": 21420, "nameID": 309250, "hasTypes": 0, "parentGroupID": 1988}
1398	2029	{"_key": 2029, "iconID": 21420, "nameID": 309251, "hasTypes": 0, "parentGroupID": 1988}
1399	2030	{"_key": 2030, "iconID": 21420, "nameID": 309252, "hasTypes": 1, "parentGroupID": 2029}
1400	2031	{"_key": 2031, "iconID": 21420, "nameID": 309253, "hasTypes": 1, "parentGroupID": 1999}
1401	2032	{"_key": 2032, "iconID": 21437, "nameID": 309668, "hasTypes": 1, "parentGroupID": 143}
1402	2033	{"_key": 2033, "iconID": 21439, "nameID": 309669, "hasTypes": 1, "parentGroupID": 143}
1403	2034	{"_key": 2034, "iconID": 20967, "nameID": 309672, "hasTypes": 1, "parentGroupID": 1951}
1404	2035	{"_key": 2035, "iconID": 21420, "nameID": 309680, "hasTypes": 0, "parentGroupID": 1989}
1405	2036	{"_key": 2036, "iconID": 21420, "nameID": 309681, "hasTypes": 0, "parentGroupID": 1989}
1406	2037	{"_key": 2037, "iconID": 21420, "nameID": 309682, "hasTypes": 0, "parentGroupID": 2036}
1407	2038	{"_key": 2038, "iconID": 20959, "nameID": 309683, "hasTypes": 1, "parentGroupID": 2037}
1408	2039	{"_key": 2039, "iconID": 20966, "nameID": 309684, "hasTypes": 1, "parentGroupID": 2037}
1409	2040	{"_key": 2040, "iconID": 20967, "nameID": 309685, "hasTypes": 1, "parentGroupID": 2037}
1410	2041	{"_key": 2041, "iconID": 20968, "nameID": 309686, "hasTypes": 1, "parentGroupID": 2037}
1411	2042	{"_key": 2042, "iconID": 21420, "nameID": 309687, "hasTypes": 0, "parentGroupID": 1998}
1412	2043	{"_key": 2043, "iconID": 21420, "nameID": 309688, "hasTypes": 0, "parentGroupID": 2042}
1413	2044	{"_key": 2044, "iconID": 21420, "nameID": 309689, "hasTypes": 0, "parentGroupID": 2042}
1414	2045	{"_key": 2045, "iconID": 21420, "nameID": 309690, "hasTypes": 0, "parentGroupID": 2042}
1415	2046	{"_key": 2046, "iconID": 21420, "nameID": 309691, "hasTypes": 0, "parentGroupID": 2042}
1416	2047	{"_key": 2047, "iconID": 20959, "nameID": 309692, "hasTypes": 1, "parentGroupID": 2043}
1417	2048	{"_key": 2048, "iconID": 20966, "nameID": 309693, "hasTypes": 1, "parentGroupID": 2043}
1418	2049	{"_key": 2049, "iconID": 20967, "nameID": 309694, "hasTypes": 1, "parentGroupID": 2043}
1419	2050	{"_key": 2050, "iconID": 20968, "nameID": 309695, "hasTypes": 1, "parentGroupID": 2043}
1420	2051	{"_key": 2051, "iconID": 20959, "nameID": 309696, "hasTypes": 1, "parentGroupID": 2044}
1421	2052	{"_key": 2052, "iconID": 20966, "nameID": 309697, "hasTypes": 1, "parentGroupID": 2044}
1422	2053	{"_key": 2053, "iconID": 20967, "nameID": 309698, "hasTypes": 1, "parentGroupID": 2044}
1423	2054	{"_key": 2054, "iconID": 20968, "nameID": 309699, "hasTypes": 1, "parentGroupID": 2044}
1424	2055	{"_key": 2055, "iconID": 20959, "nameID": 309700, "hasTypes": 1, "parentGroupID": 2045}
1425	2056	{"_key": 2056, "iconID": 20966, "nameID": 309701, "hasTypes": 1, "parentGroupID": 2045}
1426	2057	{"_key": 2057, "iconID": 20967, "nameID": 309702, "hasTypes": 1, "parentGroupID": 2045}
1427	2058	{"_key": 2058, "iconID": 20968, "nameID": 309703, "hasTypes": 1, "parentGroupID": 2045}
1428	2059	{"_key": 2059, "iconID": 20959, "nameID": 309704, "hasTypes": 1, "parentGroupID": 2046}
1429	2060	{"_key": 2060, "iconID": 20966, "nameID": 309705, "hasTypes": 1, "parentGroupID": 2046}
1430	2061	{"_key": 2061, "iconID": 20967, "nameID": 309706, "hasTypes": 1, "parentGroupID": 2046}
1431	2062	{"_key": 2062, "iconID": 20968, "nameID": 309707, "hasTypes": 1, "parentGroupID": 2046}
1432	2063	{"_key": 2063, "iconID": 21420, "nameID": 309708, "hasTypes": 1, "parentGroupID": 2029}
1433	2064	{"_key": 2064, "iconID": 21420, "nameID": 309709, "hasTypes": 0, "parentGroupID": 1988}
1434	2065	{"_key": 2065, "iconID": 21420, "nameID": 309710, "hasTypes": 0, "parentGroupID": 2064}
1435	2066	{"_key": 2066, "iconID": 21420, "nameID": 309711, "hasTypes": 0, "parentGroupID": 2064}
1436	2067	{"_key": 2067, "iconID": 21420, "nameID": 309712, "hasTypes": 0, "parentGroupID": 2064}
1437	2068	{"_key": 2068, "iconID": 21420, "nameID": 309713, "hasTypes": 0, "parentGroupID": 2064}
1438	2069	{"_key": 2069, "iconID": 20959, "nameID": 309714, "hasTypes": 1, "parentGroupID": 2065}
1439	2070	{"_key": 2070, "iconID": 20966, "nameID": 309715, "hasTypes": 1, "parentGroupID": 2065}
1440	2071	{"_key": 2071, "iconID": 20967, "nameID": 309716, "hasTypes": 1, "parentGroupID": 2065}
1441	2072	{"_key": 2072, "iconID": 20968, "nameID": 309717, "hasTypes": 1, "parentGroupID": 2065}
1442	2073	{"_key": 2073, "iconID": 20959, "nameID": 309718, "hasTypes": 1, "parentGroupID": 2066}
1443	2074	{"_key": 2074, "iconID": 20966, "nameID": 309719, "hasTypes": 1, "parentGroupID": 2066}
1444	2075	{"_key": 2075, "iconID": 20967, "nameID": 309720, "hasTypes": 1, "parentGroupID": 2066}
1445	2076	{"_key": 2076, "iconID": 20968, "nameID": 309721, "hasTypes": 1, "parentGroupID": 2066}
1446	2077	{"_key": 2077, "iconID": 20959, "nameID": 309722, "hasTypes": 1, "parentGroupID": 2067}
1447	2078	{"_key": 2078, "iconID": 20966, "nameID": 309723, "hasTypes": 1, "parentGroupID": 2067}
1448	2079	{"_key": 2079, "iconID": 20967, "nameID": 309724, "hasTypes": 1, "parentGroupID": 2067}
1449	2080	{"_key": 2080, "iconID": 20968, "nameID": 309725, "hasTypes": 1, "parentGroupID": 2067}
1450	2081	{"_key": 2081, "iconID": 20959, "nameID": 309726, "hasTypes": 1, "parentGroupID": 2068}
1451	2082	{"_key": 2082, "iconID": 20966, "nameID": 309727, "hasTypes": 1, "parentGroupID": 2068}
1452	2083	{"_key": 2083, "iconID": 20967, "nameID": 309728, "hasTypes": 1, "parentGroupID": 2068}
1453	2084	{"_key": 2084, "iconID": 20968, "nameID": 309729, "hasTypes": 1, "parentGroupID": 2068}
1454	2085	{"_key": 2085, "iconID": 21420, "nameID": 309730, "hasTypes": 0, "parentGroupID": 2006}
1455	2086	{"_key": 2086, "iconID": 21420, "nameID": 309731, "hasTypes": 0, "parentGroupID": 2006}
1456	2087	{"_key": 2087, "iconID": 21420, "nameID": 309732, "hasTypes": 0, "parentGroupID": 2086}
1457	2088	{"_key": 2088, "iconID": 20959, "nameID": 309733, "hasTypes": 1, "parentGroupID": 2087}
1458	2089	{"_key": 2089, "iconID": 20966, "nameID": 309734, "hasTypes": 1, "parentGroupID": 2087}
1459	2090	{"_key": 2090, "iconID": 20967, "nameID": 309735, "hasTypes": 1, "parentGroupID": 2087}
1460	2091	{"_key": 2091, "iconID": 20968, "nameID": 309736, "hasTypes": 1, "parentGroupID": 2087}
1461	2092	{"_key": 2092, "iconID": 20966, "nameID": 309737, "hasTypes": 1, "parentGroupID": 2381}
1462	2093	{"_key": 2093, "iconID": 20968, "nameID": 309738, "hasTypes": 1, "parentGroupID": 2381}
1463	2094	{"_key": 2094, "iconID": 21420, "nameID": 309739, "hasTypes": 0, "parentGroupID": 1968}
1464	2095	{"_key": 2095, "iconID": 20959, "nameID": 309740, "hasTypes": 1, "parentGroupID": 2094}
1465	2096	{"_key": 2096, "iconID": 20966, "nameID": 309741, "hasTypes": 1, "parentGroupID": 2094}
1466	2097	{"_key": 2097, "iconID": 20967, "nameID": 309742, "hasTypes": 1, "parentGroupID": 2094}
1467	2098	{"_key": 2098, "iconID": 20968, "nameID": 309743, "hasTypes": 1, "parentGroupID": 2094}
1468	2099	{"_key": 2099, "iconID": 21420, "nameID": 309744, "hasTypes": 0, "parentGroupID": 1955}
1469	2100	{"_key": 2100, "iconID": 21420, "nameID": 309745, "hasTypes": 0, "parentGroupID": 1955}
1470	2101	{"_key": 2101, "iconID": 21420, "nameID": 309746, "hasTypes": 0, "parentGroupID": 1955}
1471	2102	{"_key": 2102, "iconID": 21420, "nameID": 309747, "hasTypes": 0, "parentGroupID": 2099}
1472	2103	{"_key": 2103, "iconID": 21420, "nameID": 309748, "hasTypes": 1, "parentGroupID": 2100}
1473	2104	{"_key": 2104, "iconID": 20959, "nameID": 309749, "hasTypes": 1, "parentGroupID": 2102}
1474	2105	{"_key": 2105, "iconID": 20966, "nameID": 309750, "hasTypes": 1, "parentGroupID": 2102}
1475	2106	{"_key": 2106, "iconID": 20967, "nameID": 309751, "hasTypes": 1, "parentGroupID": 2102}
1476	2107	{"_key": 2107, "iconID": 20968, "nameID": 309752, "hasTypes": 1, "parentGroupID": 2102}
1477	2108	{"_key": 2108, "iconID": 21420, "nameID": 309753, "hasTypes": 1, "parentGroupID": 1961}
1478	2109	{"_key": 2109, "iconID": 21420, "nameID": 309754, "hasTypes": 0, "parentGroupID": 2022}
1479	2110	{"_key": 2110, "iconID": 20959, "nameID": 309755, "hasTypes": 1, "parentGroupID": 2109}
1480	2111	{"_key": 2111, "iconID": 20966, "nameID": 309756, "hasTypes": 1, "parentGroupID": 2109}
1481	2112	{"_key": 2112, "iconID": 20967, "nameID": 309757, "hasTypes": 1, "parentGroupID": 2109}
1482	2113	{"_key": 2113, "iconID": 20968, "nameID": 309758, "hasTypes": 1, "parentGroupID": 2109}
1483	2114	{"_key": 2114, "iconID": 21420, "nameID": 309799, "hasTypes": 0, "parentGroupID": 1968}
1484	2115	{"_key": 2115, "iconID": 1443, "nameID": 309833, "hasTypes": 1, "descriptionID": 309834, "parentGroupID": 1612}
1485	2119	{"_key": 2119, "iconID": 21420, "nameID": 310134, "hasTypes": 0, "parentGroupID": 1954}
1486	2120	{"_key": 2120, "iconID": 21420, "nameID": 310135, "hasTypes": 1, "parentGroupID": 2119}
1487	2125	{"_key": 2125, "iconID": 1443, "nameID": 310153, "hasTypes": 0, "parentGroupID": 1373}
1488	2126	{"_key": 2126, "iconID": 20959, "nameID": 310154, "hasTypes": 1, "parentGroupID": 2125}
1489	2131	{"_key": 2131, "iconID": 20966, "nameID": 310159, "hasTypes": 1, "parentGroupID": 2125}
1490	2132	{"_key": 2132, "iconID": 20967, "nameID": 310160, "hasTypes": 1, "parentGroupID": 2125}
1491	2133	{"_key": 2133, "iconID": 20968, "nameID": 310161, "hasTypes": 1, "parentGroupID": 2125}
1492	2134	{"_key": 2134, "iconID": 2703, "nameID": 310162, "hasTypes": 1, "parentGroupID": 252}
1493	2135	{"_key": 2135, "iconID": 20971, "nameID": 310163, "hasTypes": 1, "parentGroupID": 52}
1494	2136	{"_key": 2136, "iconID": 21420, "nameID": 310268, "hasTypes": 0, "parentGroupID": 2042}
1495	2137	{"_key": 2137, "iconID": 20959, "nameID": 310269, "hasTypes": 1, "parentGroupID": 2136}
1496	2138	{"_key": 2138, "iconID": 20966, "nameID": 310270, "hasTypes": 1, "parentGroupID": 2136}
1497	2139	{"_key": 2139, "iconID": 20967, "nameID": 310271, "hasTypes": 1, "parentGroupID": 2136}
1498	2140	{"_key": 2140, "iconID": 20968, "nameID": 310272, "hasTypes": 1, "parentGroupID": 2136}
1499	2141	{"_key": 2141, "iconID": 21420, "nameID": 310273, "hasTypes": 0, "parentGroupID": 2036}
1500	2142	{"_key": 2142, "iconID": 20959, "nameID": 310274, "hasTypes": 1, "parentGroupID": 2141}
1501	2143	{"_key": 2143, "iconID": 20966, "nameID": 310275, "hasTypes": 1, "parentGroupID": 2141}
1502	2144	{"_key": 2144, "iconID": 20967, "nameID": 310276, "hasTypes": 1, "parentGroupID": 2141}
1503	2145	{"_key": 2145, "iconID": 20968, "nameID": 310277, "hasTypes": 1, "parentGroupID": 2141}
1504	2146	{"_key": 2146, "iconID": 1443, "nameID": 310278, "hasTypes": 0, "descriptionID": 310279, "parentGroupID": 1364}
1505	2147	{"_key": 2147, "iconID": 20959, "nameID": 310280, "hasTypes": 1, "descriptionID": 310281, "parentGroupID": 2146}
1506	2148	{"_key": 2148, "iconID": 20966, "nameID": 310282, "hasTypes": 1, "descriptionID": 310283, "parentGroupID": 2146}
1507	2149	{"_key": 2149, "iconID": 20967, "nameID": 310284, "hasTypes": 1, "descriptionID": 310285, "parentGroupID": 2146}
1508	2150	{"_key": 2150, "iconID": 20968, "nameID": 310286, "hasTypes": 1, "descriptionID": 310287, "parentGroupID": 2146}
1509	2151	{"_key": 2151, "iconID": 1061, "nameID": 310307, "hasTypes": 1, "descriptionID": 310308, "parentGroupID": 1713}
1510	2152	{"_key": 2152, "iconID": 33, "nameID": 311566, "hasTypes": 1, "descriptionID": 311567, "parentGroupID": 150}
1511	2153	{"_key": 2153, "iconID": 2703, "nameID": 311809, "hasTypes": 1, "descriptionID": 311810, "parentGroupID": 1566}
1512	2154	{"_key": 2154, "iconID": 21581, "nameID": 311811, "hasTypes": 1, "descriptionID": 311812, "parentGroupID": 657}
1513	2155	{"_key": 2155, "iconID": 2890, "nameID": 312291, "hasTypes": 1, "parentGroupID": 533}
1514	2156	{"_key": 2156, "iconID": 2703, "nameID": 311952, "hasTypes": 1, "descriptionID": 311953, "parentGroupID": 1338}
1515	2157	{"_key": 2157, "iconID": 2703, "nameID": 311954, "hasTypes": 0, "descriptionID": 311955, "parentGroupID": 2}
1516	2158	{"_key": 2158, "iconID": 2703, "nameID": 311956, "hasTypes": 0, "descriptionID": 311957, "parentGroupID": 2}
1517	2159	{"_key": 2159, "iconID": 2703, "nameID": 311958, "hasTypes": 1, "descriptionID": 311959, "parentGroupID": 2157}
1518	2160	{"_key": 2160, "iconID": 2703, "nameID": 311960, "hasTypes": 1, "descriptionID": 311961, "parentGroupID": 2157}
1519	2161	{"_key": 2161, "iconID": 2703, "nameID": 311962, "hasTypes": 0, "parentGroupID": 2158}
1520	2162	{"_key": 2162, "iconID": 2703, "nameID": 311963, "hasTypes": 0, "parentGroupID": 2158}
1521	2163	{"_key": 2163, "iconID": 2703, "nameID": 311964, "hasTypes": 0, "parentGroupID": 2158}
1522	2164	{"_key": 2164, "iconID": 2703, "nameID": 311965, "hasTypes": 0, "parentGroupID": 2158}
1523	2165	{"_key": 2165, "iconID": 2703, "nameID": 311966, "hasTypes": 1, "parentGroupID": 2158}
1524	2166	{"_key": 2166, "iconID": 2703, "nameID": 311967, "hasTypes": 0, "parentGroupID": 2158}
1525	2167	{"_key": 2167, "iconID": 2703, "nameID": 311968, "hasTypes": 1, "parentGroupID": 2161}
1526	2168	{"_key": 2168, "iconID": 2703, "nameID": 311969, "hasTypes": 1, "parentGroupID": 2161}
1527	2169	{"_key": 2169, "iconID": 2703, "nameID": 311970, "hasTypes": 1, "parentGroupID": 2161}
1528	2170	{"_key": 2170, "iconID": 2703, "nameID": 311971, "hasTypes": 1, "parentGroupID": 2161}
1529	2171	{"_key": 2171, "iconID": 2703, "nameID": 311972, "hasTypes": 1, "descriptionID": 317006, "parentGroupID": 2161}
1530	2172	{"_key": 2172, "iconID": 2703, "nameID": 311973, "hasTypes": 1, "parentGroupID": 2161}
1531	2173	{"_key": 2173, "iconID": 2703, "nameID": 311974, "hasTypes": 1, "parentGroupID": 2162}
1532	2174	{"_key": 2174, "iconID": 2703, "nameID": 311975, "hasTypes": 1, "parentGroupID": 2162}
1533	2175	{"_key": 2175, "iconID": 2703, "nameID": 311976, "hasTypes": 1, "parentGroupID": 2163}
1534	2176	{"_key": 2176, "iconID": 2703, "nameID": 311977, "hasTypes": 1, "parentGroupID": 2163}
1535	2177	{"_key": 2177, "iconID": 2703, "nameID": 311978, "hasTypes": 1, "parentGroupID": 2163}
1536	2178	{"_key": 2178, "iconID": 2703, "nameID": 311979, "hasTypes": 0, "parentGroupID": 2164}
1537	2179	{"_key": 2179, "iconID": 2703, "nameID": 311980, "hasTypes": 0, "parentGroupID": 2164}
1538	2180	{"_key": 2180, "iconID": 2703, "nameID": 311981, "hasTypes": 1, "parentGroupID": 2164}
1539	2181	{"_key": 2181, "iconID": 2703, "nameID": 311982, "hasTypes": 1, "parentGroupID": 2166}
1540	2182	{"_key": 2182, "iconID": 2703, "nameID": 311983, "hasTypes": 1, "parentGroupID": 2166}
1541	2183	{"_key": 2183, "iconID": 2703, "nameID": 311984, "hasTypes": 1, "parentGroupID": 2178}
1542	2184	{"_key": 2184, "iconID": 2703, "nameID": 311985, "hasTypes": 1, "parentGroupID": 2178}
1543	2185	{"_key": 2185, "iconID": 2703, "nameID": 311986, "hasTypes": 1, "parentGroupID": 2164}
1544	2186	{"_key": 2186, "iconID": 2703, "nameID": 311987, "hasTypes": 1, "parentGroupID": 2163}
1545	2187	{"_key": 2187, "iconID": 2703, "nameID": 311988, "hasTypes": 1, "parentGroupID": 2162}
1546	2188	{"_key": 2188, "iconID": 2703, "nameID": 311989, "hasTypes": 1, "parentGroupID": 2163}
1547	2189	{"_key": 2189, "iconID": 2703, "nameID": 311990, "hasTypes": 1, "parentGroupID": 2179}
1548	2190	{"_key": 2190, "iconID": 2703, "nameID": 311991, "hasTypes": 1, "parentGroupID": 2179}
1549	2191	{"_key": 2191, "iconID": 2703, "nameID": 311992, "hasTypes": 1, "parentGroupID": 314}
1550	2192	{"_key": 2192, "iconID": 2703, "nameID": 311993, "hasTypes": 1, "parentGroupID": 314}
1551	2193	{"_key": 2193, "iconID": 2703, "nameID": 311994, "hasTypes": 1, "parentGroupID": 211}
1552	2196	{"_key": 2196, "iconID": 21568, "nameID": 311995, "hasTypes": 1, "parentGroupID": 114}
1553	2197	{"_key": 2197, "iconID": 21567, "nameID": 311996, "hasTypes": 1, "parentGroupID": 114}
1554	2198	{"_key": 2198, "iconID": 21569, "nameID": 311997, "hasTypes": 1, "parentGroupID": 11}
1555	2199	{"_key": 2199, "iconID": 2222, "nameID": 311998, "hasTypes": 0, "parentGroupID": 477}
1556	2200	{"_key": 2200, "iconID": 2222, "nameID": 311999, "hasTypes": 1, "parentGroupID": 2199}
1557	2201	{"_key": 2201, "iconID": 2222, "nameID": 312000, "hasTypes": 1, "parentGroupID": 2199}
1558	2202	{"_key": 2202, "iconID": 21561, "nameID": 312001, "hasTypes": 0, "descriptionID": 315541}
1559	2203	{"_key": 2203, "iconID": 2887, "nameID": 312002, "hasTypes": 0, "descriptionID": 315547}
1560	2204	{"_key": 2204, "iconID": 21602, "nameID": 312003, "hasTypes": 0, "descriptionID": 315465, "parentGroupID": 2203}
1561	2205	{"_key": 2205, "iconID": 21599, "nameID": 312004, "hasTypes": 0, "descriptionID": 312184, "parentGroupID": 2203}
1562	2206	{"_key": 2206, "iconID": 111, "nameID": 312005, "hasTypes": 0, "parentGroupID": 2202}
1563	2207	{"_key": 2207, "iconID": 104, "nameID": 312006, "hasTypes": 0, "parentGroupID": 2202}
1564	2208	{"_key": 2208, "iconID": 70, "nameID": 312007, "hasTypes": 0, "parentGroupID": 2202}
1565	2209	{"_key": 2209, "iconID": 365, "nameID": 312008, "hasTypes": 0, "parentGroupID": 2202}
1566	2210	{"_key": 2210, "iconID": 21596, "nameID": 312009, "hasTypes": 0, "parentGroupID": 2202}
1567	2211	{"_key": 2211, "iconID": 109, "nameID": 312010, "hasTypes": 1, "parentGroupID": 2206}
1568	2212	{"_key": 2212, "iconID": 105, "nameID": 312011, "hasTypes": 1, "parentGroupID": 2206}
1569	2213	{"_key": 2213, "iconID": 1284, "nameID": 312012, "hasTypes": 1, "parentGroupID": 2206}
1570	2214	{"_key": 2214, "iconID": 2983, "nameID": 312013, "hasTypes": 1, "parentGroupID": 2206}
1571	2215	{"_key": 2215, "iconID": 1639, "nameID": 312014, "hasTypes": 1, "descriptionID": 317007, "parentGroupID": 2206}
1572	2216	{"_key": 2216, "iconID": 111, "nameID": 312015, "hasTypes": 1, "parentGroupID": 2206}
1573	2218	{"_key": 2218, "iconID": 1405, "nameID": 312017, "hasTypes": 1, "parentGroupID": 2207}
1574	2219	{"_key": 2219, "iconID": 104, "nameID": 312018, "hasTypes": 1, "parentGroupID": 2207}
1575	2220	{"_key": 2220, "iconID": 26455, "nameID": 312019, "hasTypes": 1, "parentGroupID": 2208}
1576	2221	{"_key": 2221, "iconID": 21561, "nameID": 312020, "hasTypes": 1, "parentGroupID": 2208}
1577	2222	{"_key": 2222, "iconID": 26547, "nameID": 312021, "hasTypes": 1, "parentGroupID": 2208}
1578	2223	{"_key": 2223, "iconID": 1283, "nameID": 312022, "hasTypes": 1, "parentGroupID": 2208}
1579	2224	{"_key": 2224, "iconID": 89, "nameID": 312023, "hasTypes": 1, "parentGroupID": 2208}
1580	2226	{"_key": 2226, "iconID": 168, "nameID": 312025, "hasTypes": 0, "parentGroupID": 2209}
1581	2227	{"_key": 2227, "iconID": 21440, "nameID": 312026, "hasTypes": 0, "parentGroupID": 2209}
1582	2228	{"_key": 2228, "iconID": 2934, "nameID": 312027, "hasTypes": 1, "parentGroupID": 2209}
1583	2229	{"_key": 2229, "iconID": 21564, "nameID": 312028, "hasTypes": 1, "parentGroupID": 2209}
1584	2230	{"_key": 2230, "iconID": 21565, "nameID": 312029, "hasTypes": 1, "parentGroupID": 2226}
1585	2231	{"_key": 2231, "iconID": 21566, "nameID": 312030, "hasTypes": 1, "parentGroupID": 2226}
1586	2232	{"_key": 2232, "iconID": 21596, "nameID": 312031, "hasTypes": 1, "parentGroupID": 2210}
1587	2233	{"_key": 2233, "iconID": 21597, "nameID": 312032, "hasTypes": 1, "parentGroupID": 2210}
1588	2234	{"_key": 2234, "iconID": 21440, "nameID": 312033, "hasTypes": 1, "parentGroupID": 2227}
1589	2235	{"_key": 2235, "iconID": 21439, "nameID": 312034, "hasTypes": 1, "parentGroupID": 2227}
1590	2236	{"_key": 2236, "iconID": 1084, "nameID": 312035, "hasTypes": 0, "descriptionID": 315540, "parentGroupID": 157}
1591	2237	{"_key": 2237, "iconID": 2703, "nameID": 312036, "hasTypes": 0, "parentGroupID": 357}
1592	2238	{"_key": 2238, "iconID": 2703, "nameID": 312037, "hasTypes": 1, "descriptionID": 312038, "parentGroupID": 2237}
1593	2239	{"_key": 2239, "iconID": 1084, "nameID": 312039, "hasTypes": 1, "descriptionID": 312040, "parentGroupID": 2410}
1594	2240	{"_key": 2240, "iconID": 79, "nameID": 312068, "hasTypes": 1, "descriptionID": 312069, "parentGroupID": 133}
1595	2241	{"_key": 2241, "iconID": 1044, "nameID": 312070, "hasTypes": 1, "descriptionID": 312071, "parentGroupID": 551}
1596	2242	{"_key": 2242, "iconID": 89, "nameID": 312072, "hasTypes": 1, "descriptionID": 312073, "parentGroupID": 664}
1597	2243	{"_key": 2243, "iconID": 1031, "nameID": 312074, "hasTypes": 1, "descriptionID": 312075, "parentGroupID": 668}
1598	2244	{"_key": 2244, "iconID": 80, "nameID": 312076, "hasTypes": 1, "descriptionID": 312077, "parentGroupID": 538}
1599	2245	{"_key": 2245, "iconID": 10933, "nameID": 312078, "hasTypes": 1, "descriptionID": 312079, "parentGroupID": 535}
1600	2246	{"_key": 2246, "iconID": 81, "nameID": 312080, "hasTypes": 1, "descriptionID": 312081, "parentGroupID": 553}
1601	2247	{"_key": 2247, "iconID": 170, "nameID": 312115, "hasTypes": 1, "parentGroupID": 140}
1602	2248	{"_key": 2248, "iconID": 2703, "nameID": 312118, "hasTypes": 1, "parentGroupID": 1566}
1603	2249	{"_key": 2249, "iconID": 21604, "nameID": 312119, "hasTypes": 1, "parentGroupID": 657}
1604	2250	{"_key": 2250, "iconID": 1283, "nameID": 312123, "hasTypes": 1, "descriptionID": 312124, "parentGroupID": 661}
1605	2251	{"_key": 2251, "iconID": 1029, "nameID": 312121, "hasTypes": 1, "descriptionID": 312122, "parentGroupID": 662}
1606	2252	{"_key": 2252, "iconID": 1287, "nameID": 312134, "hasTypes": 1, "descriptionID": 312137, "parentGroupID": 846}
1607	2253	{"_key": 2253, "iconID": 1291, "nameID": 312135, "hasTypes": 1, "descriptionID": 312136, "parentGroupID": 847}
1608	2254	{"_key": 2254, "iconID": 1310, "nameID": 312138, "hasTypes": 1, "descriptionID": 312139, "parentGroupID": 849}
1609	2255	{"_key": 2255, "iconID": 1311, "nameID": 312140, "hasTypes": 1, "descriptionID": 312141, "parentGroupID": 850}
1610	2256	{"_key": 2256, "iconID": 1140, "nameID": 312142, "hasTypes": 1, "descriptionID": 312143, "parentGroupID": 853}
1611	2257	{"_key": 2257, "iconID": 1145, "nameID": 312144, "hasTypes": 1, "descriptionID": 312145, "parentGroupID": 852}
1612	2258	{"_key": 2258, "iconID": 1346, "nameID": 312146, "hasTypes": 1, "descriptionID": 312147, "parentGroupID": 505}
1613	2259	{"_key": 2259, "iconID": 1346, "nameID": 312148, "hasTypes": 1, "descriptionID": 312149, "parentGroupID": 505}
1614	2260	{"_key": 2260, "iconID": 183, "nameID": 312150, "hasTypes": 1, "descriptionID": 312151, "parentGroupID": 1316}
1615	2261	{"_key": 2261, "iconID": 183, "nameID": 312152, "hasTypes": 1, "descriptionID": 312153, "parentGroupID": 1316}
1616	2262	{"_key": 2262, "iconID": 2703, "nameID": 312186, "hasTypes": 0, "descriptionID": 312187, "parentGroupID": 204}
1617	2263	{"_key": 2263, "iconID": 2703, "nameID": 312188, "hasTypes": 1, "descriptionID": 312189, "parentGroupID": 2262}
1618	2264	{"_key": 2264, "iconID": 2703, "nameID": 312190, "hasTypes": 1, "descriptionID": 312191, "parentGroupID": 2262}
1619	2265	{"_key": 2265, "iconID": 2703, "nameID": 312192, "hasTypes": 1, "descriptionID": 312193, "parentGroupID": 2262}
1620	2266	{"_key": 2266, "iconID": 2703, "nameID": 312194, "hasTypes": 1, "descriptionID": 312195, "parentGroupID": 2262}
1621	2267	{"_key": 2267, "iconID": 2934, "nameID": 312196, "hasTypes": 1, "parentGroupID": 912}
1622	2268	{"_key": 2268, "iconID": 2934, "nameID": 312197, "hasTypes": 1, "parentGroupID": 912}
1623	2269	{"_key": 2269, "iconID": 2934, "nameID": 312198, "hasTypes": 1, "parentGroupID": 912}
1624	2270	{"_key": 2270, "iconID": 2934, "nameID": 312199, "hasTypes": 1, "parentGroupID": 912}
1625	2271	{"_key": 2271, "iconID": 1443, "nameID": 312241, "hasTypes": 0, "descriptionID": 312242, "parentGroupID": 1381}
1626	2272	{"_key": 2272, "iconID": 20959, "nameID": 312243, "hasTypes": 1, "descriptionID": 312244, "parentGroupID": 2271}
1627	2273	{"_key": 2273, "iconID": 20966, "nameID": 312245, "hasTypes": 1, "descriptionID": 312246, "parentGroupID": 2271}
1628	2274	{"_key": 2274, "iconID": 20967, "nameID": 312247, "hasTypes": 1, "descriptionID": 312248, "parentGroupID": 2271}
1629	2275	{"_key": 2275, "iconID": 20968, "nameID": 312249, "hasTypes": 1, "descriptionID": 312250, "parentGroupID": 2271}
1630	2276	{"_key": 2276, "iconID": 2934, "nameID": 312259, "hasTypes": 1, "parentGroupID": 912}
1631	2277	{"_key": 2277, "iconID": 21420, "nameID": 312284, "hasTypes": 0, "parentGroupID": 1968}
1632	2278	{"_key": 2278, "iconID": 20959, "nameID": 312285, "hasTypes": 1, "parentGroupID": 2277}
1633	2279	{"_key": 2279, "iconID": 20966, "nameID": 312286, "hasTypes": 1, "parentGroupID": 2277}
1634	2280	{"_key": 2280, "iconID": 20967, "nameID": 312287, "hasTypes": 1, "parentGroupID": 2277}
1635	2281	{"_key": 2281, "iconID": 20968, "nameID": 312288, "hasTypes": 1, "parentGroupID": 2277}
1636	2283	{"_key": 2283, "iconID": 21420, "nameID": 312293, "hasTypes": 0, "parentGroupID": 1954}
1637	2285	{"_key": 2285, "iconID": 21420, "nameID": 312294, "hasTypes": 1, "parentGroupID": 2283}
1638	2286	{"_key": 2286, "iconID": 21420, "nameID": 312295, "hasTypes": 1, "parentGroupID": 2283}
1639	2287	{"_key": 2287, "iconID": 1443, "nameID": 312559, "hasTypes": 1, "descriptionID": 312560, "parentGroupID": 812}
1640	2288	{"_key": 2288, "iconID": 1443, "nameID": 312557, "hasTypes": 0, "descriptionID": 312558, "parentGroupID": 761}
1641	2290	{"_key": 2290, "iconID": 2703, "nameID": 314927, "hasTypes": 0, "descriptionID": 314928, "parentGroupID": 211}
1642	2291	{"_key": 2291, "iconID": 2703, "nameID": 314929, "hasTypes": 1, "descriptionID": 314930, "parentGroupID": 2290}
1643	2292	{"_key": 2292, "iconID": 2703, "nameID": 314931, "hasTypes": 1, "descriptionID": 314932, "parentGroupID": 2290}
1644	2293	{"_key": 2293, "iconID": 2703, "nameID": 314933, "hasTypes": 1, "descriptionID": 314934, "parentGroupID": 2290}
1645	2294	{"_key": 2294, "iconID": 2703, "nameID": 314935, "hasTypes": 1, "descriptionID": 314936, "parentGroupID": 2290}
1646	2295	{"_key": 2295, "iconID": 2703, "nameID": 314937, "hasTypes": 1, "descriptionID": 314940, "parentGroupID": 2290}
1647	2297	{"_key": 2297, "iconID": 20970, "nameID": 314941, "hasTypes": 0, "descriptionID": 314942, "parentGroupID": 11}
1648	2298	{"_key": 2298, "iconID": 20970, "nameID": 314943, "hasTypes": 1, "descriptionID": 314944, "parentGroupID": 2297}
1649	2299	{"_key": 2299, "iconID": 20970, "nameID": 314945, "hasTypes": 1, "descriptionID": 314946, "parentGroupID": 2297}
1650	2300	{"_key": 2300, "iconID": 20970, "nameID": 314947, "hasTypes": 1, "descriptionID": 314948, "parentGroupID": 2297}
1651	2301	{"_key": 2301, "iconID": 20970, "nameID": 314949, "hasTypes": 1, "descriptionID": 314950, "parentGroupID": 2297}
1652	2302	{"_key": 2302, "iconID": 20970, "nameID": 314951, "hasTypes": 1, "descriptionID": 314952, "parentGroupID": 2297}
1653	2306	{"_key": 2306, "iconID": 21420, "nameID": 314956, "hasTypes": 0, "parentGroupID": 1954}
1654	2307	{"_key": 2307, "iconID": 21420, "nameID": 314957, "hasTypes": 0, "parentGroupID": 2306}
1655	2308	{"_key": 2308, "iconID": 20959, "nameID": 314958, "hasTypes": 1, "parentGroupID": 2307}
1656	2309	{"_key": 2309, "iconID": 21420, "nameID": 314959, "hasTypes": 0, "parentGroupID": 2036}
1657	2310	{"_key": 2310, "iconID": 20959, "nameID": 314960, "hasTypes": 1, "parentGroupID": 2309}
1658	2311	{"_key": 2311, "iconID": 21420, "nameID": 315008, "hasTypes": 0, "parentGroupID": 1955}
1659	2312	{"_key": 2312, "iconID": 21420, "nameID": 315009, "hasTypes": 1, "parentGroupID": 2311}
1660	2313	{"_key": 2313, "iconID": 21420, "nameID": 315010, "hasTypes": 0, "parentGroupID": 1989}
1661	2314	{"_key": 2314, "iconID": 21420, "nameID": 315011, "hasTypes": 1, "parentGroupID": 2313}
1662	2315	{"_key": 2315, "iconID": 21420, "nameID": 315012, "hasTypes": 0, "parentGroupID": 1954}
1663	2316	{"_key": 2316, "iconID": 21420, "nameID": 315013, "hasTypes": 1, "parentGroupID": 2315}
1664	2317	{"_key": 2317, "iconID": 2039, "nameID": 315399, "hasTypes": 1, "parentGroupID": 19}
1665	2318	{"_key": 2318, "iconID": 1443, "nameID": 315401, "hasTypes": 1, "parentGroupID": 1972}
1666	2319	{"_key": 2319, "iconID": 21420, "nameID": 315402, "hasTypes": 1, "parentGroupID": 2011}
1667	2320	{"_key": 2320, "iconID": 1443, "nameID": 315403, "hasTypes": 1, "parentGroupID": 2042}
1668	2321	{"_key": 2321, "iconID": 1443, "nameID": 315404, "hasTypes": 1, "parentGroupID": 2001}
1669	2322	{"_key": 2322, "iconID": 2703, "nameID": 315406, "hasTypes": 1, "descriptionID": 315407, "parentGroupID": 1338}
1670	2323	{"_key": 2323, "iconID": 2703, "nameID": 315408, "hasTypes": 1, "parentGroupID": 2166}
1671	2324	{"_key": 2324, "iconID": 2222, "nameID": 315409, "hasTypes": 1, "parentGroupID": 477}
1672	2325	{"_key": 2325, "iconID": 2934, "nameID": 315411, "hasTypes": 1, "parentGroupID": 912}
1673	2327	{"_key": 2327, "iconID": 2222, "nameID": 316320, "hasTypes": 1, "parentGroupID": 477}
1674	2328	{"_key": 2328, "iconID": 1443, "nameID": 315412, "hasTypes": 1, "parentGroupID": 2085}
1675	2330	{"_key": 2330, "iconID": 21420, "nameID": 315414, "hasTypes": 0, "parentGroupID": 2006}
1676	2331	{"_key": 2331, "iconID": 1443, "nameID": 315415, "hasTypes": 1, "parentGroupID": 2330}
1677	2332	{"_key": 2332, "iconID": 3007, "nameID": 315418, "hasTypes": 1, "parentGroupID": 2210}
1678	2333	{"_key": 2333, "iconID": 2703, "nameID": 315439, "hasTypes": 0, "descriptionID": 315440, "parentGroupID": 204}
1679	2334	{"_key": 2334, "iconID": 2703, "nameID": 315441, "hasTypes": 1, "descriptionID": 315442, "parentGroupID": 2333}
1680	2335	{"_key": 2335, "iconID": 1443, "nameID": 315443, "hasTypes": 0, "parentGroupID": 1382}
1681	2336	{"_key": 2336, "iconID": 27058, "nameID": 315444, "hasTypes": 1, "parentGroupID": 2335}
1682	2337	{"_key": 2337, "iconID": 21420, "nameID": 315445, "hasTypes": 0, "parentGroupID": 2006}
1683	2338	{"_key": 2338, "iconID": 1443, "nameID": 315446, "hasTypes": 1, "parentGroupID": 2337}
1684	2339	{"_key": 2339, "iconID": 2703, "nameID": 315461, "hasTypes": 1, "descriptionID": 315462, "parentGroupID": 2157}
1685	2340	{"_key": 2340, "iconID": 21729, "nameID": 315463, "hasTypes": 0, "descriptionID": 315464, "parentGroupID": 2203}
1686	2341	{"_key": 2341, "iconID": 21602, "nameID": 315466, "hasTypes": 1, "descriptionID": 315467, "parentGroupID": 2204}
1687	2342	{"_key": 2342, "iconID": 21602, "nameID": 315468, "hasTypes": 1, "descriptionID": 315469, "parentGroupID": 2204}
1688	2343	{"_key": 2343, "iconID": 21602, "nameID": 315470, "hasTypes": 1, "descriptionID": 315471, "parentGroupID": 2204}
1689	2344	{"_key": 2344, "iconID": 21599, "nameID": 315472, "hasTypes": 1, "descriptionID": 315473, "parentGroupID": 2205}
1690	2345	{"_key": 2345, "iconID": 21599, "nameID": 315474, "hasTypes": 1, "descriptionID": 315475, "parentGroupID": 2205}
1691	2346	{"_key": 2346, "iconID": 21599, "nameID": 315476, "hasTypes": 1, "descriptionID": 315477, "parentGroupID": 2205}
1692	2347	{"_key": 2347, "iconID": 21729, "nameID": 315478, "hasTypes": 1, "descriptionID": 315479, "parentGroupID": 2340}
1693	2348	{"_key": 2348, "iconID": 21729, "nameID": 315480, "hasTypes": 1, "descriptionID": 315481, "parentGroupID": 2340}
1694	2349	{"_key": 2349, "iconID": 21729, "nameID": 315482, "hasTypes": 1, "descriptionID": 315483, "parentGroupID": 2340}
1695	2350	{"_key": 2350, "iconID": 1443, "nameID": 315514, "hasTypes": 1, "descriptionID": 315515, "parentGroupID": 1612}
1696	2351	{"_key": 2351, "iconID": 1345, "nameID": 315522, "hasTypes": 1, "descriptionID": 315523, "parentGroupID": 140}
1697	2353	{"_key": 2353, "iconID": 20966, "nameID": 315559, "hasTypes": 1, "parentGroupID": 2307}
1698	2354	{"_key": 2354, "iconID": 20967, "nameID": 315560, "hasTypes": 1, "parentGroupID": 2307}
1699	2355	{"_key": 2355, "iconID": 20968, "nameID": 315561, "hasTypes": 1, "parentGroupID": 2307}
1700	2356	{"_key": 2356, "iconID": 20967, "nameID": 315612, "hasTypes": 1, "parentGroupID": 2309}
1701	2357	{"_key": 2357, "iconID": 1443, "nameID": 315645, "hasTypes": 1, "descriptionID": 315646, "parentGroupID": 2271}
1702	2358	{"_key": 2358, "iconID": 21531, "nameID": 315657, "hasTypes": 1, "descriptionID": 315658, "parentGroupID": 1922}
1703	2359	{"_key": 2359, "iconID": 21420, "nameID": 315669, "hasTypes": 0, "parentGroupID": 2306}
1704	2360	{"_key": 2360, "iconID": 21420, "nameID": 315670, "hasTypes": 1, "parentGroupID": 2359}
1705	2361	{"_key": 2361, "iconID": 21420, "nameID": 315671, "hasTypes": 1, "parentGroupID": 2044}
1706	2362	{"_key": 2362, "iconID": 21420, "nameID": 315672, "hasTypes": 1, "parentGroupID": 2068}
1707	2369	{"_key": 2369, "iconID": 21420, "nameID": 315770, "hasTypes": 0, "parentGroupID": 2064}
1708	2370	{"_key": 2370, "iconID": 20966, "nameID": 315771, "hasTypes": 1, "parentGroupID": 2369}
1709	2371	{"_key": 2371, "iconID": 20959, "nameID": 315772, "hasTypes": 1, "parentGroupID": 2369}
1710	2372	{"_key": 2372, "iconID": 20967, "nameID": 315773, "hasTypes": 1, "parentGroupID": 2369}
1711	2373	{"_key": 2373, "iconID": 20968, "nameID": 315774, "hasTypes": 1, "parentGroupID": 2369}
1712	2374	{"_key": 2374, "iconID": 21420, "nameID": 315904, "hasTypes": 0, "parentGroupID": 1970}
1713	2375	{"_key": 2375, "iconID": 21420, "nameID": 315905, "hasTypes": 0, "parentGroupID": 1970}
1714	2376	{"_key": 2376, "iconID": 21420, "nameID": 315906, "hasTypes": 1, "parentGroupID": 2375}
1715	2377	{"_key": 2377, "iconID": 21420, "nameID": 315907, "hasTypes": 0, "parentGroupID": 1971}
1716	2378	{"_key": 2378, "iconID": 21420, "nameID": 315908, "hasTypes": 0, "parentGroupID": 1971}
1717	2380	{"_key": 2380, "iconID": 21420, "nameID": 315910, "hasTypes": 1, "parentGroupID": 2378}
1718	2381	{"_key": 2381, "iconID": 21420, "nameID": 315911, "hasTypes": 0, "parentGroupID": 1973}
1719	2382	{"_key": 2382, "iconID": 21420, "nameID": 315912, "hasTypes": 0, "parentGroupID": 1973}
1720	2383	{"_key": 2383, "iconID": 21420, "nameID": 315913, "hasTypes": 1, "parentGroupID": 2382}
1721	2387	{"_key": 2387, "iconID": 20959, "nameID": 315926, "hasTypes": 1, "descriptionID": 315927, "parentGroupID": 2315}
1722	2388	{"_key": 2388, "iconID": 20966, "nameID": 315928, "hasTypes": 1, "descriptionID": 315929, "parentGroupID": 2315}
1723	2389	{"_key": 2389, "iconID": 20967, "nameID": 315930, "hasTypes": 1, "descriptionID": 315931, "parentGroupID": 2315}
1724	2390	{"_key": 2390, "iconID": 20968, "nameID": 315932, "hasTypes": 1, "descriptionID": 315933, "parentGroupID": 2315}
1725	2391	{"_key": 2391, "iconID": 20966, "nameID": 316197, "hasTypes": 1, "parentGroupID": 2309}
1726	2392	{"_key": 2392, "iconID": 20968, "nameID": 316198, "hasTypes": 1, "parentGroupID": 2309}
1727	2393	{"_key": 2393, "iconID": 2703, "nameID": 316317, "hasTypes": 1, "descriptionID": 316318, "parentGroupID": 1338}
1728	2395	{"_key": 2395, "iconID": 1270, "nameID": 316329, "hasTypes": 0, "parentGroupID": 1031}
1729	2396	{"_key": 2396, "iconID": 232, "nameID": 316330, "hasTypes": 1, "descriptionID": 316331, "parentGroupID": 2395}
1730	2397	{"_key": 2397, "iconID": 1356, "nameID": 316332, "hasTypes": 1, "parentGroupID": 2395}
1731	2398	{"_key": 2398, "iconID": 231, "nameID": 316333, "hasTypes": 1, "parentGroupID": 2395}
1732	2400	{"_key": 2400, "iconID": 230, "nameID": 316335, "hasTypes": 1, "parentGroupID": 2395}
1733	2401	{"_key": 2401, "iconID": 1271, "nameID": 316336, "hasTypes": 1, "parentGroupID": 2395}
1734	2402	{"_key": 2402, "iconID": 21783, "nameID": 316379, "hasTypes": 1, "descriptionID": 316380, "parentGroupID": 1849}
1735	2403	{"_key": 2403, "iconID": 21783, "nameID": 316381, "hasTypes": 1, "descriptionID": 316382, "parentGroupID": 1849}
1736	2404	{"_key": 2404, "iconID": 21783, "nameID": 316383, "hasTypes": 1, "descriptionID": 316384, "parentGroupID": 1849}
1737	2406	{"_key": 2406, "iconID": 21420, "nameID": 317093, "hasTypes": 1, "parentGroupID": 2109}
1738	2407	{"_key": 2407, "iconID": 2703, "nameID": 317623, "hasTypes": 1, "parentGroupID": 2161}
1739	2408	{"_key": 2408, "iconID": 21604, "nameID": 317624, "hasTypes": 1, "parentGroupID": 2206}
1740	2409	{"_key": 2409, "iconID": 1084, "nameID": 317632, "hasTypes": 0, "parentGroupID": 2236}
1741	2410	{"_key": 2410, "iconID": 1084, "nameID": 317633, "hasTypes": 0, "parentGroupID": 2236}
1742	2411	{"_key": 2411, "iconID": 1084, "nameID": 317634, "hasTypes": 1, "parentGroupID": 2409}
1743	2412	{"_key": 2412, "iconID": 1084, "nameID": 317635, "hasTypes": 1, "parentGroupID": 2409}
1744	2413	{"_key": 2413, "iconID": 1084, "nameID": 317636, "hasTypes": 1, "parentGroupID": 2409}
1745	2414	{"_key": 2414, "iconID": 79, "nameID": 317690, "hasTypes": 1, "parentGroupID": 2208}
1746	2415	{"_key": 2415, "iconID": 2703, "nameID": 317691, "hasTypes": 1, "parentGroupID": 2163}
1747	2416	{"_key": 2416, "iconID": 1443, "nameID": 317709, "hasTypes": 0, "parentGroupID": 1368}
1748	2417	{"_key": 2417, "iconID": 1443, "nameID": 317710, "hasTypes": 1, "parentGroupID": 2416}
1749	2418	{"_key": 2418, "iconID": 21420, "nameID": 317727, "hasTypes": 0, "parentGroupID": 2064}
1750	2419	{"_key": 2419, "iconID": 1443, "nameID": 317728, "hasTypes": 1, "parentGroupID": 2418}
1751	2420	{"_key": 2420, "iconID": 21420, "nameID": 317741, "hasTypes": 0, "parentGroupID": 1960}
1752	2421	{"_key": 2421, "iconID": 21420, "nameID": 317742, "hasTypes": 1, "parentGroupID": 2420}
1753	2425	{"_key": 2425, "iconID": 1443, "nameID": 317778, "hasTypes": 0, "descriptionID": 317779, "parentGroupID": 1361}
1754	2426	{"_key": 2426, "iconID": 24135, "nameID": 317780, "hasTypes": 1, "descriptionID": 317781, "parentGroupID": 2425}
1755	2427	{"_key": 2427, "iconID": 1443, "nameID": 317782, "hasTypes": 0, "descriptionID": 317783, "parentGroupID": 1367}
1756	2428	{"_key": 2428, "iconID": 24135, "nameID": 317784, "hasTypes": 1, "descriptionID": 317785, "parentGroupID": 2427}
1757	2429	{"_key": 2429, "iconID": 1443, "nameID": 317786, "hasTypes": 0, "descriptionID": 317787, "parentGroupID": 1376}
1758	2430	{"_key": 2430, "iconID": 24135, "nameID": 317788, "hasTypes": 1, "descriptionID": 317789, "parentGroupID": 2429}
1759	2431	{"_key": 2431, "iconID": 21923, "nameID": 317790, "hasTypes": 0, "descriptionID": 317791, "parentGroupID": 10}
1760	2432	{"_key": 2432, "iconID": 21921, "nameID": 317792, "hasTypes": 0, "descriptionID": 317793, "parentGroupID": 2431}
1761	2433	{"_key": 2433, "iconID": 21923, "nameID": 317794, "hasTypes": 1, "descriptionID": 317795, "parentGroupID": 2432}
1762	2434	{"_key": 2434, "iconID": 21922, "nameID": 317796, "hasTypes": 1, "descriptionID": 317797, "parentGroupID": 2432}
1763	2435	{"_key": 2435, "iconID": 21921, "nameID": 317798, "hasTypes": 1, "descriptionID": 317799, "parentGroupID": 2432}
1764	2436	{"_key": 2436, "iconID": 21891, "nameID": 317800, "hasTypes": 0, "descriptionID": 317801, "parentGroupID": 955}
1765	2437	{"_key": 2437, "iconID": 21989, "nameID": 317802, "hasTypes": 0, "descriptionID": 317803, "parentGroupID": 2436}
1766	2438	{"_key": 2438, "iconID": 21985, "nameID": 317804, "hasTypes": 0, "descriptionID": 317805, "parentGroupID": 2436}
1767	2439	{"_key": 2439, "iconID": 21984, "nameID": 317806, "hasTypes": 0, "descriptionID": 317807, "parentGroupID": 2436}
1768	2440	{"_key": 2440, "iconID": 21987, "nameID": 317808, "hasTypes": 0, "descriptionID": 317809, "parentGroupID": 2436}
1769	2441	{"_key": 2441, "iconID": 21993, "nameID": 317810, "hasTypes": 1, "descriptionID": 317811, "parentGroupID": 2436}
1770	2442	{"_key": 2442, "iconID": 21992, "nameID": 317812, "hasTypes": 1, "descriptionID": 317813, "parentGroupID": 2436}
1771	2443	{"_key": 2443, "nameID": 317814, "hasTypes": 1, "descriptionID": 317815, "parentGroupID": 2437}
1772	2444	{"_key": 2444, "nameID": 317816, "hasTypes": 1, "descriptionID": 317817, "parentGroupID": 2437}
1773	2445	{"_key": 2445, "nameID": 317818, "hasTypes": 1, "descriptionID": 317819, "parentGroupID": 2437}
1774	2446	{"_key": 2446, "nameID": 317820, "hasTypes": 1, "descriptionID": 317821, "parentGroupID": 2438}
1775	2447	{"_key": 2447, "nameID": 317822, "hasTypes": 1, "descriptionID": 317823, "parentGroupID": 2438}
1776	2448	{"_key": 2448, "nameID": 317824, "hasTypes": 1, "descriptionID": 317825, "parentGroupID": 2438}
1777	2449	{"_key": 2449, "nameID": 317826, "hasTypes": 1, "descriptionID": 317827, "parentGroupID": 2438}
1778	2450	{"_key": 2450, "nameID": 317828, "hasTypes": 1, "descriptionID": 317829, "parentGroupID": 2439}
1779	2451	{"_key": 2451, "nameID": 317830, "hasTypes": 1, "descriptionID": 317831, "parentGroupID": 2439}
1780	2452	{"_key": 2452, "nameID": 317832, "hasTypes": 1, "descriptionID": 317833, "parentGroupID": 2439}
1781	2453	{"_key": 2453, "nameID": 317834, "hasTypes": 1, "descriptionID": 317835, "parentGroupID": 2440}
1782	2454	{"_key": 2454, "nameID": 317836, "hasTypes": 1, "descriptionID": 317837, "parentGroupID": 2440}
1783	2455	{"_key": 2455, "nameID": 317838, "hasTypes": 1, "descriptionID": 317839, "parentGroupID": 2440}
1784	2456	{"_key": 2456, "iconID": 21924, "nameID": 317840, "hasTypes": 0, "descriptionID": 317841, "parentGroupID": 19}
1785	2457	{"_key": 2457, "iconID": 21905, "nameID": 317842, "hasTypes": 1, "descriptionID": 317843, "parentGroupID": 2456}
1786	2458	{"_key": 2458, "iconID": 21906, "nameID": 317844, "hasTypes": 1, "descriptionID": 317845, "parentGroupID": 2456}
1787	2459	{"_key": 2459, "iconID": 21907, "nameID": 317846, "hasTypes": 1, "descriptionID": 317847, "parentGroupID": 2456}
1788	2460	{"_key": 2460, "iconID": 21904, "nameID": 317848, "hasTypes": 1, "descriptionID": 317849, "parentGroupID": 2456}
1789	2461	{"_key": 2461, "iconID": 21903, "nameID": 317850, "hasTypes": 1, "descriptionID": 317851, "parentGroupID": 2456}
1790	2462	{"_key": 2462, "iconID": 21918, "nameID": 317852, "hasTypes": 0, "descriptionID": 317853, "parentGroupID": 11}
1791	2463	{"_key": 2463, "iconID": 21918, "nameID": 317854, "hasTypes": 0, "descriptionID": 317855, "parentGroupID": 2462}
1792	2464	{"_key": 2464, "iconID": 21920, "nameID": 317856, "hasTypes": 0, "descriptionID": 317916, "parentGroupID": 2462}
1793	2465	{"_key": 2465, "iconID": 21918, "nameID": 317857, "hasTypes": 1, "descriptionID": 317858, "parentGroupID": 2463}
1794	2466	{"_key": 2466, "iconID": 21918, "nameID": 317859, "hasTypes": 1, "descriptionID": 317860, "parentGroupID": 2463}
1795	2467	{"_key": 2467, "iconID": 21918, "nameID": 317861, "hasTypes": 1, "descriptionID": 317862, "parentGroupID": 2463}
1796	2468	{"_key": 2468, "iconID": 21920, "nameID": 317863, "hasTypes": 1, "descriptionID": 317864, "parentGroupID": 2464}
1797	2469	{"_key": 2469, "iconID": 21920, "nameID": 317865, "hasTypes": 1, "descriptionID": 317866, "parentGroupID": 2464}
1798	2470	{"_key": 2470, "iconID": 21920, "nameID": 317867, "hasTypes": 1, "descriptionID": 317868, "parentGroupID": 2464}
1799	2471	{"_key": 2471, "iconID": 26521, "nameID": 317889, "hasTypes": 1, "descriptionID": 317915, "parentGroupID": 143}
1800	2473	{"_key": 2473, "iconID": 2224, "nameID": 317899, "hasTypes": 0, "descriptionID": 317900, "parentGroupID": 531}
1801	2474	{"_key": 2474, "iconID": 2224, "nameID": 317901, "hasTypes": 1, "descriptionID": 317902, "parentGroupID": 2473}
1802	2475	{"_key": 2475, "iconID": 2224, "nameID": 317903, "hasTypes": 1, "descriptionID": 317904, "parentGroupID": 2473}
1803	2476	{"_key": 2476, "iconID": 2224, "nameID": 317905, "hasTypes": 1, "descriptionID": 317906, "parentGroupID": 2473}
1804	2477	{"_key": 2477, "iconID": 2224, "nameID": 317907, "hasTypes": 1, "descriptionID": 317908, "parentGroupID": 2473}
1805	2478	{"_key": 2478, "iconID": 2224, "nameID": 317909, "hasTypes": 1, "descriptionID": 317910, "parentGroupID": 2473}
1806	2479	{"_key": 2479, "iconID": 2103, "nameID": 317917, "hasTypes": 1, "descriptionID": 317918, "parentGroupID": 1031}
1807	2480	{"_key": 2480, "iconID": 21982, "nameID": 317919, "hasTypes": 1, "descriptionID": 317920, "parentGroupID": 19}
1808	2481	{"_key": 2481, "iconID": 21420, "nameID": 317931, "hasTypes": 0, "descriptionID": 317932, "parentGroupID": 1960}
1809	2482	{"_key": 2482, "iconID": 21420, "nameID": 317929, "hasTypes": 1, "descriptionID": 317930, "parentGroupID": 2481}
1810	2483	{"_key": 2483, "iconID": 21420, "nameID": 317933, "hasTypes": 0, "descriptionID": 317934, "parentGroupID": 1988}
1811	2484	{"_key": 2484, "iconID": 21420, "nameID": 317935, "hasTypes": 0, "descriptionID": 317936, "parentGroupID": 1998}
1812	2485	{"_key": 2485, "iconID": 21420, "nameID": 317937, "hasTypes": 1, "descriptionID": 317938, "parentGroupID": 2483}
1813	2486	{"_key": 2486, "iconID": 21420, "nameID": 317939, "hasTypes": 1, "descriptionID": 317940, "parentGroupID": 2484}
1814	2487	{"_key": 2487, "iconID": 10144, "nameID": 317941, "hasTypes": 0, "descriptionID": 317942, "parentGroupID": 24}
1815	2488	{"_key": 2488, "iconID": 3211, "nameID": 317943, "hasTypes": 0, "descriptionID": 317944, "parentGroupID": 977}
1816	2489	{"_key": 2489, "iconID": 3211, "nameID": 317945, "hasTypes": 0, "descriptionID": 317946, "parentGroupID": 977}
1817	2490	{"_key": 2490, "iconID": 3211, "nameID": 317947, "hasTypes": 0, "descriptionID": 317948, "parentGroupID": 977}
1818	2491	{"_key": 2491, "iconID": 3215, "nameID": 317949, "hasTypes": 1, "descriptionID": 317950, "parentGroupID": 2488}
1819	2492	{"_key": 2492, "iconID": 3211, "nameID": 317951, "hasTypes": 1, "descriptionID": 317952, "parentGroupID": 2488}
1820	2493	{"_key": 2493, "iconID": 3214, "nameID": 317953, "hasTypes": 1, "descriptionID": 317954, "parentGroupID": 2488}
1821	2494	{"_key": 2494, "iconID": 3217, "nameID": 317955, "hasTypes": 1, "descriptionID": 317956, "parentGroupID": 2488}
1822	2495	{"_key": 2495, "iconID": 21485, "nameID": 317957, "hasTypes": 1, "descriptionID": 317958, "parentGroupID": 2488}
1823	2496	{"_key": 2496, "iconID": 3212, "nameID": 317959, "hasTypes": 1, "descriptionID": 317960, "parentGroupID": 2489}
1824	2497	{"_key": 2497, "iconID": 3213, "nameID": 317961, "hasTypes": 1, "descriptionID": 317962, "parentGroupID": 2489}
1825	2498	{"_key": 2498, "iconID": 3216, "nameID": 317963, "hasTypes": 1, "descriptionID": 317964, "parentGroupID": 2489}
1826	2499	{"_key": 2499, "iconID": 21487, "nameID": 317965, "hasTypes": 1, "descriptionID": 317966, "parentGroupID": 2489}
1827	2500	{"_key": 2500, "iconID": 3210, "nameID": 317967, "hasTypes": 1, "descriptionID": 317968, "parentGroupID": 2490}
1828	2501	{"_key": 2501, "iconID": 21483, "nameID": 317969, "hasTypes": 1, "descriptionID": 317970, "parentGroupID": 2490}
1829	2502	{"_key": 2502, "iconID": 3211, "nameID": 317971, "hasTypes": 0, "descriptionID": 317972, "parentGroupID": 977}
1830	2503	{"_key": 2503, "iconID": 21841, "nameID": 317973, "hasTypes": 1, "descriptionID": 317974, "parentGroupID": 2502}
1831	2504	{"_key": 2504, "iconID": 21840, "nameID": 317975, "hasTypes": 1, "descriptionID": 317976, "parentGroupID": 2502}
1832	2505	{"_key": 2505, "iconID": 21839, "nameID": 317977, "hasTypes": 1, "descriptionID": 317978, "parentGroupID": 2502}
1833	2506	{"_key": 2506, "iconID": 3211, "nameID": 317979, "hasTypes": 1, "descriptionID": 317980, "parentGroupID": 2488}
1834	2508	{"_key": 2508, "iconID": 2703, "nameID": 317989, "hasTypes": 1, "descriptionID": 317990, "parentGroupID": 214}
1835	2509	{"_key": 2509, "iconID": 97, "nameID": 317991, "hasTypes": 1, "descriptionID": 317992, "parentGroupID": 14}
1836	2510	{"_key": 2510, "iconID": 2703, "nameID": 318008, "hasTypes": 1, "descriptionID": 318009, "parentGroupID": 3626}
1837	2511	{"_key": 2511, "iconID": 2222, "nameID": 318010, "hasTypes": 1, "parentGroupID": 3624}
1838	2512	{"_key": 2512, "iconID": 22064, "nameID": 318038, "hasTypes": 0, "parentGroupID": 2436}
1839	2513	{"_key": 2513, "nameID": 318040, "hasTypes": 1, "parentGroupID": 2512}
1840	2514	{"_key": 2514, "nameID": 318042, "hasTypes": 1, "parentGroupID": 2512}
1841	2515	{"_key": 2515, "nameID": 318044, "hasTypes": 1, "parentGroupID": 2512}
1842	2516	{"_key": 2516, "nameID": 318046, "hasTypes": 1, "parentGroupID": 2512}
1843	2517	{"_key": 2517, "nameID": 318048, "hasTypes": 1, "parentGroupID": 2512}
1844	2518	{"_key": 2518, "iconID": 21420, "nameID": 318021, "hasTypes": 0, "descriptionID": 318022, "parentGroupID": 1955}
1845	2519	{"_key": 2519, "iconID": 21420, "nameID": 318023, "hasTypes": 1, "descriptionID": 318024, "parentGroupID": 2518}
1846	2520	{"_key": 2520, "iconID": 21420, "nameID": 318025, "hasTypes": 0, "descriptionID": 318026, "parentGroupID": 1989}
1847	2521	{"_key": 2521, "iconID": 21420, "nameID": 318027, "hasTypes": 1, "descriptionID": 318028, "parentGroupID": 2520}
1848	2522	{"_key": 2522, "iconID": 1443, "nameID": 318030, "hasTypes": 0, "descriptionID": 318031, "parentGroupID": 1372}
1849	2523	{"_key": 2523, "iconID": 24135, "nameID": 318032, "hasTypes": 1, "descriptionID": 318033, "parentGroupID": 2522}
1850	2524	{"_key": 2524, "iconID": 1443, "nameID": 318034, "hasTypes": 0, "descriptionID": 318035, "parentGroupID": 1374}
1851	2525	{"_key": 2525, "iconID": 24135, "nameID": 318036, "hasTypes": 1, "descriptionID": 318037, "parentGroupID": 2524}
1852	2526	{"_key": 2526, "iconID": 24135, "nameID": 318070, "hasTypes": 1, "descriptionID": 318071, "parentGroupID": 437}
1853	2527	{"_key": 2527, "iconID": 80, "nameID": 318067, "hasTypes": 1, "parentGroupID": 14}
1854	2529	{"_key": 2529, "iconID": 80, "nameID": 318061, "hasTypes": 1, "descriptionID": 318062, "parentGroupID": 2527}
1855	2530	{"_key": 2530, "iconID": 3211, "nameID": 318072, "hasTypes": 1, "parentGroupID": 977}
1856	2531	{"_key": 2531, "iconID": 3215, "nameID": 318073, "hasTypes": 1, "parentGroupID": 977}
1857	2532	{"_key": 2532, "iconID": 24129, "nameID": 318091, "hasTypes": 0, "descriptionID": 318092, "parentGroupID": 2436}
1858	2533	{"_key": 2533, "nameID": 318093, "hasTypes": 1, "descriptionID": 318094, "parentGroupID": 2532}
1859	2534	{"_key": 2534, "nameID": 318095, "hasTypes": 1, "descriptionID": 318096, "parentGroupID": 2532}
1860	2535	{"_key": 2535, "iconID": 24135, "nameID": 318097, "hasTypes": 1, "descriptionID": 318098, "parentGroupID": 448}
1861	2536	{"_key": 2536, "iconID": 24135, "nameID": 318099, "hasTypes": 1, "descriptionID": 318100, "parentGroupID": 432}
1862	2537	{"_key": 2537, "iconID": 24135, "nameID": 318101, "hasTypes": 1, "descriptionID": 318102, "parentGroupID": 2125}
1863	2538	{"_key": 2538, "iconID": 24143, "nameID": 318108, "hasTypes": 1, "descriptionID": 318109, "parentGroupID": 54}
1864	2539	{"_key": 2539, "iconID": 24144, "nameID": 318110, "hasTypes": 1, "descriptionID": 318111, "parentGroupID": 54}
1865	2540	{"_key": 2540, "iconID": 24136, "nameID": 318112, "hasTypes": 1, "descriptionID": 318113, "parentGroupID": 54}
1866	2658	{"_key": 2658, "iconID": 24135, "nameID": 551112, "hasTypes": 1, "descriptionID": 551113, "parentGroupID": 65}
1867	2690	{"_key": 2690, "iconID": 24135, "nameID": 553050, "hasTypes": 1, "descriptionID": 553051, "parentGroupID": 3508}
1868	2691	{"_key": 2691, "iconID": 24237, "nameID": 553052, "hasTypes": 1, "descriptionID": 553053, "parentGroupID": 2432}
1869	2692	{"_key": 2692, "iconID": 21918, "nameID": 553054, "hasTypes": 1, "descriptionID": 553055, "parentGroupID": 2463}
1870	2693	{"_key": 2693, "iconID": 24135, "nameID": 553059, "hasTypes": 1, "parentGroupID": 1883}
1871	2701	{"_key": 2701, "iconID": 24205, "nameID": 554066, "hasTypes": 1, "descriptionID": 554068, "parentGroupID": 1922}
1872	2702	{"_key": 2702, "iconID": 1443, "nameID": 554135, "hasTypes": 1, "descriptionID": 554136, "parentGroupID": 1612}
1873	2703	{"_key": 2703, "iconID": 21420, "nameID": 555351, "hasTypes": 0, "descriptionID": 555352, "parentGroupID": 1971}
1874	2704	{"_key": 2704, "iconID": 21420, "nameID": 555353, "hasTypes": 1, "descriptionID": 555354, "parentGroupID": 2703}
1875	2706	{"_key": 2706, "iconID": 21924, "nameID": 560904, "hasTypes": 1, "descriptionID": 560905, "parentGroupID": 2456}
1876	2728	{"_key": 2728, "iconID": 24481, "nameID": 564543, "hasTypes": 0, "descriptionID": 564544, "parentGroupID": 11}
1877	2729	{"_key": 2729, "iconID": 24481, "nameID": 564545, "hasTypes": 0, "descriptionID": 564546, "parentGroupID": 2728}
1878	2730	{"_key": 2730, "iconID": 24480, "nameID": 564547, "hasTypes": 0, "descriptionID": 564548, "parentGroupID": 2728}
1879	2734	{"_key": 2734, "iconID": 24469, "nameID": 564558, "hasTypes": 1, "parentGroupID": 2729}
1880	2735	{"_key": 2735, "iconID": 24475, "nameID": 564559, "hasTypes": 1, "parentGroupID": 2729}
1881	2736	{"_key": 2736, "iconID": 24481, "nameID": 564560, "hasTypes": 1, "parentGroupID": 2729}
1882	2737	{"_key": 2737, "iconID": 24468, "nameID": 564561, "hasTypes": 1, "parentGroupID": 2730}
1883	2738	{"_key": 2738, "iconID": 24474, "nameID": 564562, "hasTypes": 1, "parentGroupID": 2730}
1884	2739	{"_key": 2739, "iconID": 24480, "nameID": 564563, "hasTypes": 1, "parentGroupID": 2730}
1885	2740	{"_key": 2740, "iconID": 24467, "nameID": 564564, "hasTypes": 1, "parentGroupID": 143}
1886	2741	{"_key": 2741, "iconID": 24466, "nameID": 564565, "hasTypes": 0, "descriptionID": 564566, "parentGroupID": 10}
1887	2742	{"_key": 2742, "iconID": 24464, "nameID": 564567, "hasTypes": 1, "parentGroupID": 2741}
1888	2743	{"_key": 2743, "iconID": 24465, "nameID": 564568, "hasTypes": 1, "parentGroupID": 2741}
1889	2744	{"_key": 2744, "iconID": 24466, "nameID": 564569, "hasTypes": 1, "parentGroupID": 2741}
1890	2747	{"_key": 2747, "iconID": 21925, "nameID": 567624, "hasTypes": 1, "descriptionID": 567625, "parentGroupID": 2456}
1891	2749	{"_key": 2749, "iconID": 21729, "nameID": 569644, "hasTypes": 1, "descriptionID": 569752, "parentGroupID": 2202}
1892	2750	{"_key": 2750, "nameID": 569938, "hasTypes": 1, "descriptionID": 569939, "parentGroupID": 2439}
1893	2751	{"_key": 2751, "nameID": 569940, "hasTypes": 1, "descriptionID": 569941, "parentGroupID": 2437}
1894	2752	{"_key": 2752, "nameID": 569943, "hasTypes": 1, "descriptionID": 569944, "parentGroupID": 2438}
1895	2753	{"_key": 2753, "nameID": 569945, "hasTypes": 1, "descriptionID": 569946, "parentGroupID": 2440}
1896	2754	{"_key": 2754, "nameID": 569951, "hasTypes": 1, "descriptionID": 569952, "parentGroupID": 2512}
1897	2756	{"_key": 2756, "iconID": 24530, "nameID": 571035, "hasTypes": 1, "descriptionID": 571036, "parentGroupID": 2456}
1898	2757	{"_key": 2757, "iconID": 24530, "nameID": 571037, "hasTypes": 1, "descriptionID": 571038, "parentGroupID": 2456}
1899	2761	{"_key": 2761, "iconID": 10144, "nameID": 573509, "hasTypes": 1, "descriptionID": 573510, "parentGroupID": 977}
1900	2763	{"_key": 2763, "iconID": 16, "nameID": 574837, "hasTypes": 1, "parentGroupID": 404}
1901	2764	{"_key": 2764, "iconID": 2703, "nameID": 574838, "hasTypes": 1, "parentGroupID": 406}
1902	2765	{"_key": 2765, "iconID": 24608, "nameID": 575004, "hasTypes": 1, "parentGroupID": 533}
1903	2766	{"_key": 2766, "iconID": 24623, "nameID": 575005, "hasTypes": 1, "parentGroupID": 533}
1904	2767	{"_key": 2767, "iconID": 24619, "nameID": 575006, "hasTypes": 1, "parentGroupID": 1034}
1905	2768	{"_key": 2768, "iconID": 24638, "nameID": 575007, "hasTypes": 1, "parentGroupID": 1035}
1906	2769	{"_key": 2769, "iconID": 21783, "nameID": 575008, "hasTypes": 1, "parentGroupID": 1849}
1907	2770	{"_key": 2770, "iconID": 2703, "nameID": 575009, "hasTypes": 1, "parentGroupID": 800}
1908	2771	{"_key": 2771, "iconID": 16, "nameID": 580890, "hasTypes": 1, "parentGroupID": 404}
1909	2772	{"_key": 2772, "iconID": 2703, "nameID": 580891, "hasTypes": 1, "descriptionID": 580892, "parentGroupID": 406}
1910	2783	{"_key": 2783, "iconID": 24730, "nameID": 581438, "hasTypes": 1, "descriptionID": 581439, "parentGroupID": 132}
1911	2790	{"_key": 2790, "iconID": 3215, "nameID": 584811, "hasTypes": 1, "parentGroupID": 977}
1912	2791	{"_key": 2791, "iconID": 3215, "nameID": 584815, "hasTypes": 1, "parentGroupID": 977}
1913	2792	{"_key": 2792, "iconID": 3215, "nameID": 584819, "hasTypes": 1, "parentGroupID": 977}
1914	2795	{"_key": 2795, "iconID": 3074, "nameID": 587197, "hasTypes": 1, "parentGroupID": 1713}
1915	2797	{"_key": 2797, "iconID": 2703, "nameID": 588176, "hasTypes": 1, "descriptionID": 588177, "parentGroupID": 406}
1916	2798	{"_key": 2798, "iconID": 16, "nameID": 588178, "hasTypes": 1, "parentGroupID": 404}
1917	2799	{"_key": 2799, "iconID": 21785, "nameID": 588316, "hasTypes": 1, "descriptionID": 588317, "parentGroupID": 19}
1918	2801	{"_key": 2801, "iconID": 10065, "nameID": 589184, "hasTypes": 1, "parentGroupID": 19}
1919	2804	{"_key": 2804, "iconID": 24968, "nameID": 591665, "hasTypes": 0, "descriptionID": 591666, "parentGroupID": 593}
1920	2805	{"_key": 2805, "iconID": 25021, "nameID": 591667, "hasTypes": 0, "descriptionID": 591668, "parentGroupID": 593}
1921	2806	{"_key": 2806, "iconID": 2703, "nameID": 591670, "hasTypes": 1, "parentGroupID": 753}
1922	2807	{"_key": 2807, "iconID": 2703, "nameID": 591671, "hasTypes": 1, "parentGroupID": 753}
1923	2808	{"_key": 2808, "iconID": 25070, "nameID": 592327, "hasTypes": 1, "parentGroupID": 533}
1924	2809	{"_key": 2809, "iconID": 25079, "nameID": 592713, "hasTypes": 1, "parentGroupID": 2436}
1925	2813	{"_key": 2813, "iconID": 1084, "nameID": 593694, "hasTypes": 1, "descriptionID": 593695, "parentGroupID": 157}
1926	2814	{"_key": 2814, "iconID": 25169, "nameID": 594613, "hasTypes": 1, "parentGroupID": 1032}
1927	2815	{"_key": 2815, "iconID": 25152, "nameID": 595064, "hasTypes": 1, "parentGroupID": 9}
1928	2816	{"_key": 2816, "iconID": 2703, "nameID": 595232, "hasTypes": 1, "parentGroupID": 209}
1929	2819	{"_key": 2819, "iconID": 1443, "nameID": 596354, "hasTypes": 1, "descriptionID": 596353, "parentGroupID": 1612}
1930	2820	{"_key": 2820, "iconID": 1004, "nameID": 597625, "hasTypes": 1, "descriptionID": 597624, "parentGroupID": 11}
1931	2821	{"_key": 2821, "iconID": 2703, "nameID": 597629, "hasTypes": 1, "descriptionID": 597628, "parentGroupID": 211}
1932	2822	{"_key": 2822, "iconID": 25353, "nameID": 610297, "hasTypes": 0, "descriptionID": 610298}
1933	2827	{"_key": 2827, "iconID": 24672, "nameID": 610348, "hasTypes": 1, "parentGroupID": 977}
1934	2828	{"_key": 2828, "iconID": 24676, "nameID": 610349, "hasTypes": 1, "parentGroupID": 977}
1935	2829	{"_key": 2829, "iconID": 24673, "nameID": 610350, "hasTypes": 1, "parentGroupID": 977}
1936	2830	{"_key": 2830, "iconID": 24674, "nameID": 610351, "hasTypes": 1, "parentGroupID": 977}
1937	2831	{"_key": 2831, "iconID": 21742, "nameID": 610353, "hasTypes": 0}
1938	2832	{"_key": 2832, "iconID": 24677, "nameID": 610354, "hasTypes": 1, "parentGroupID": 2831}
1939	2833	{"_key": 2833, "iconID": 24891, "nameID": 610355, "hasTypes": 0, "parentGroupID": 1922}
1940	2834	{"_key": 2834, "iconID": 21839, "nameID": 610455, "hasTypes": 1, "parentGroupID": 977}
1941	2835	{"_key": 2835, "iconID": 21841, "nameID": 610456, "hasTypes": 1, "parentGroupID": 977}
1942	2836	{"_key": 2836, "iconID": 25080, "nameID": 610894, "hasTypes": 1, "parentGroupID": 2487}
1943	2837	{"_key": 2837, "iconID": 10144, "nameID": 610895, "hasTypes": 0, "parentGroupID": 2487}
1944	2838	{"_key": 2838, "iconID": 10144, "nameID": 610896, "hasTypes": 1, "parentGroupID": 2837}
1945	2839	{"_key": 2839, "iconID": 10144, "nameID": 610897, "hasTypes": 1, "parentGroupID": 2837}
1946	2840	{"_key": 2840, "iconID": 10144, "nameID": 610898, "hasTypes": 1, "parentGroupID": 2837}
1947	2845	{"_key": 2845, "iconID": 84, "nameID": 611504, "hasTypes": 1, "parentGroupID": 2846}
1948	2846	{"_key": 2846, "iconID": 84, "nameID": 611505, "hasTypes": 0, "parentGroupID": 2847}
1949	2847	{"_key": 2847, "iconID": 69, "nameID": 611506, "hasTypes": 0, "parentGroupID": 2848}
1950	2848	{"_key": 2848, "iconID": 1432, "nameID": 611507, "hasTypes": 0, "parentGroupID": 2822}
1951	2849	{"_key": 2849, "iconID": 1443, "nameID": 611511, "hasTypes": 1, "parentGroupID": 2850}
1952	2850	{"_key": 2850, "iconID": 1443, "nameID": 611512, "hasTypes": 0, "parentGroupID": 2851}
1953	2851	{"_key": 2851, "iconID": 1443, "nameID": 611513, "hasTypes": 0, "parentGroupID": 2822}
1954	2852	{"_key": 2852, "iconID": 20959, "nameID": 611517, "hasTypes": 1, "parentGroupID": 2853}
1955	2853	{"_key": 2853, "iconID": 1443, "nameID": 611518, "hasTypes": 0, "parentGroupID": 2854}
1956	2854	{"_key": 2854, "iconID": 1443, "nameID": 611519, "hasTypes": 0, "parentGroupID": 2851}
1957	2855	{"_key": 2855, "iconID": 20966, "nameID": 611522, "hasTypes": 1, "parentGroupID": 2853}
1958	2856	{"_key": 2856, "iconID": 20967, "nameID": 611525, "hasTypes": 1, "parentGroupID": 2853}
1959	2857	{"_key": 2857, "iconID": 20968, "nameID": 611528, "hasTypes": 1, "parentGroupID": 2853}
1960	2858	{"_key": 2858, "iconID": 20966, "nameID": 611532, "hasTypes": 1, "parentGroupID": 2859}
1961	2859	{"_key": 2859, "iconID": 1443, "nameID": 611533, "hasTypes": 0, "parentGroupID": 2860}
1962	2860	{"_key": 2860, "iconID": 1443, "nameID": 611534, "hasTypes": 0, "parentGroupID": 2861}
1963	2861	{"_key": 2861, "iconID": 1443, "nameID": 611535, "hasTypes": 0, "parentGroupID": 2851}
1964	2862	{"_key": 2862, "iconID": 20959, "nameID": 611538, "hasTypes": 1, "parentGroupID": 2859}
1965	2863	{"_key": 2863, "iconID": 20968, "nameID": 611541, "hasTypes": 1, "parentGroupID": 2859}
1966	2864	{"_key": 2864, "iconID": 20967, "nameID": 611544, "hasTypes": 1, "parentGroupID": 2859}
1967	2865	{"_key": 2865, "iconID": 1443, "nameID": 611548, "hasTypes": 1, "parentGroupID": 2866}
1968	2866	{"_key": 2866, "iconID": 1443, "nameID": 611549, "hasTypes": 0, "parentGroupID": 2867}
1969	2867	{"_key": 2867, "iconID": 1443, "nameID": 611550, "hasTypes": 0, "parentGroupID": 2851}
1970	2868	{"_key": 2868, "iconID": 20959, "nameID": 611556, "hasTypes": 1, "parentGroupID": 2869}
1971	2869	{"_key": 2869, "iconID": 1443, "nameID": 611557, "hasTypes": 0, "parentGroupID": 2870}
1972	2870	{"_key": 2870, "iconID": 1443, "nameID": 611558, "hasTypes": 0, "parentGroupID": 2871}
1973	2871	{"_key": 2871, "iconID": 1443, "nameID": 611559, "hasTypes": 0, "parentGroupID": 2851}
1974	2872	{"_key": 2872, "iconID": 20966, "nameID": 611562, "hasTypes": 1, "parentGroupID": 2869}
1975	2873	{"_key": 2873, "iconID": 20967, "nameID": 611565, "hasTypes": 1, "parentGroupID": 2869}
1976	2874	{"_key": 2874, "iconID": 20968, "nameID": 611568, "hasTypes": 1, "parentGroupID": 2869}
1977	2875	{"_key": 2875, "iconID": 20959, "nameID": 611572, "hasTypes": 1, "parentGroupID": 2876}
1978	2876	{"_key": 2876, "iconID": 1443, "nameID": 611573, "hasTypes": 0, "parentGroupID": 2866}
1979	2877	{"_key": 2877, "iconID": 20966, "nameID": 611576, "hasTypes": 1, "parentGroupID": 2876}
1980	2878	{"_key": 2878, "iconID": 20967, "nameID": 611579, "hasTypes": 1, "parentGroupID": 2876}
1981	2879	{"_key": 2879, "iconID": 20968, "nameID": 611582, "hasTypes": 1, "parentGroupID": 2876}
1982	2880	{"_key": 2880, "iconID": 20968, "nameID": 611586, "hasTypes": 1, "parentGroupID": 2881}
1983	2881	{"_key": 2881, "iconID": 1443, "nameID": 611587, "hasTypes": 0, "parentGroupID": 2870}
1984	2882	{"_key": 2882, "iconID": 20959, "nameID": 611590, "hasTypes": 1, "parentGroupID": 2881}
1985	2883	{"_key": 2883, "iconID": 20966, "nameID": 611593, "hasTypes": 1, "parentGroupID": 2881}
1986	2884	{"_key": 2884, "iconID": 20967, "nameID": 611596, "hasTypes": 1, "parentGroupID": 2881}
1987	2885	{"_key": 2885, "iconID": 24135, "nameID": 611599, "hasTypes": 1, "parentGroupID": 2881}
1988	2886	{"_key": 2886, "iconID": 20959, "nameID": 611603, "hasTypes": 1, "parentGroupID": 2887}
1989	2887	{"_key": 2887, "iconID": 1443, "nameID": 611604, "hasTypes": 0, "parentGroupID": 2888}
1990	2888	{"_key": 2888, "iconID": 1443, "nameID": 611605, "hasTypes": 0, "parentGroupID": 2851}
1991	2889	{"_key": 2889, "iconID": 20966, "nameID": 611608, "hasTypes": 1, "parentGroupID": 2887}
1992	2890	{"_key": 2890, "iconID": 20967, "nameID": 611611, "hasTypes": 1, "parentGroupID": 2887}
1993	2891	{"_key": 2891, "iconID": 1443, "nameID": 611615, "hasTypes": 1, "parentGroupID": 2887}
1994	2892	{"_key": 2892, "iconID": 20968, "nameID": 611620, "hasTypes": 1, "parentGroupID": 2887}
1995	2893	{"_key": 2893, "iconID": 1443, "nameID": 611624, "hasTypes": 1, "parentGroupID": 2894}
1996	2894	{"_key": 2894, "iconID": 1443, "nameID": 611625, "hasTypes": 0, "parentGroupID": 2895}
1997	2895	{"_key": 2895, "iconID": 1443, "nameID": 611626, "hasTypes": 0, "parentGroupID": 2896}
1998	2896	{"_key": 2896, "iconID": 1443, "nameID": 611627, "hasTypes": 0, "parentGroupID": 2851}
1999	2897	{"_key": 2897, "iconID": 1443, "nameID": 611631, "hasTypes": 1, "parentGroupID": 2898}
2000	2898	{"_key": 2898, "iconID": 1443, "nameID": 611632, "hasTypes": 0, "parentGroupID": 2867}
2001	2902	{"_key": 2902, "iconID": 1443, "nameID": 611643, "hasTypes": 1, "parentGroupID": 2850}
2002	2903	{"_key": 2903, "iconID": 20966, "nameID": 611665, "hasTypes": 1, "parentGroupID": 2898}
2003	2904	{"_key": 2904, "iconID": 20968, "nameID": 611672, "hasTypes": 1, "parentGroupID": 2898}
2004	2905	{"_key": 2905, "iconID": 20959, "nameID": 611681, "hasTypes": 1, "parentGroupID": 2898}
2005	2906	{"_key": 2906, "iconID": 20967, "nameID": 611688, "hasTypes": 1, "parentGroupID": 2898}
2006	2907	{"_key": 2907, "iconID": 1443, "nameID": 611729, "hasTypes": 1, "parentGroupID": 2908}
2007	2908	{"_key": 2908, "iconID": 1443, "nameID": 611730, "hasTypes": 0, "parentGroupID": 2867}
2008	2909	{"_key": 2909, "iconID": 1443, "nameID": 611749, "hasTypes": 1, "parentGroupID": 2908}
2009	2910	{"_key": 2910, "iconID": 24135, "nameID": 611830, "hasTypes": 1, "parentGroupID": 2911}
2010	2911	{"_key": 2911, "iconID": 1443, "nameID": 611831, "hasTypes": 0, "parentGroupID": 2867}
2011	2912	{"_key": 2912, "iconID": 25196, "nameID": 611834, "hasTypes": 1, "parentGroupID": 2898}
2012	2913	{"_key": 2913, "iconID": 20959, "nameID": 611850, "hasTypes": 1, "parentGroupID": 2914}
2013	2914	{"_key": 2914, "iconID": 1443, "nameID": 611851, "hasTypes": 0, "parentGroupID": 2896}
2014	2915	{"_key": 2915, "iconID": 20966, "nameID": 611858, "hasTypes": 1, "parentGroupID": 2914}
2015	2916	{"_key": 2916, "iconID": 20968, "nameID": 611867, "hasTypes": 1, "parentGroupID": 2914}
2016	2917	{"_key": 2917, "iconID": 20967, "nameID": 611876, "hasTypes": 1, "parentGroupID": 2914}
2017	2918	{"_key": 2918, "iconID": 1443, "nameID": 611893, "hasTypes": 1, "parentGroupID": 2850}
2018	2919	{"_key": 2919, "iconID": 1443, "nameID": 611896, "hasTypes": 1, "parentGroupID": 2920}
2019	2920	{"_key": 2920, "iconID": 1443, "nameID": 611897, "hasTypes": 0, "parentGroupID": 2896}
2020	2921	{"_key": 2921, "iconID": 24135, "nameID": 611900, "hasTypes": 1, "parentGroupID": 2922}
2021	2922	{"_key": 2922, "iconID": 1443, "nameID": 611901, "hasTypes": 0, "parentGroupID": 2896}
2022	2923	{"_key": 2923, "iconID": 1443, "nameID": 611916, "hasTypes": 1, "parentGroupID": 2920}
2023	2924	{"_key": 2924, "iconID": 25196, "nameID": 611972, "hasTypes": 1, "parentGroupID": 2914}
2024	2925	{"_key": 2925, "iconID": 20966, "nameID": 611982, "hasTypes": 1, "parentGroupID": 2926}
2025	2926	{"_key": 2926, "iconID": 1443, "nameID": 611983, "hasTypes": 0, "parentGroupID": 2927}
2026	2927	{"_key": 2927, "iconID": 1443, "nameID": 611984, "hasTypes": 0, "parentGroupID": 2851}
2027	2928	{"_key": 2928, "iconID": 20968, "nameID": 611987, "hasTypes": 1, "parentGroupID": 2926}
2028	2929	{"_key": 2929, "iconID": 20967, "nameID": 611992, "hasTypes": 1, "parentGroupID": 2926}
2029	2930	{"_key": 2930, "iconID": 20959, "nameID": 611995, "hasTypes": 1, "parentGroupID": 2926}
2030	2931	{"_key": 2931, "iconID": 1443, "nameID": 612004, "hasTypes": 1, "parentGroupID": 2932}
2031	2932	{"_key": 2932, "iconID": 1443, "nameID": 612005, "hasTypes": 0, "parentGroupID": 2927}
2032	2933	{"_key": 2933, "iconID": 24135, "nameID": 612008, "hasTypes": 1, "parentGroupID": 2934}
2033	2934	{"_key": 2934, "iconID": 1443, "nameID": 612009, "hasTypes": 0, "parentGroupID": 2927}
2034	2935	{"_key": 2935, "iconID": 1443, "nameID": 612020, "hasTypes": 1, "parentGroupID": 2932}
2035	2936	{"_key": 2936, "iconID": 1443, "nameID": 612085, "hasTypes": 1, "parentGroupID": 2850}
2036	2937	{"_key": 2937, "iconID": 20966, "nameID": 612135, "hasTypes": 1, "parentGroupID": 2938}
2037	2938	{"_key": 2938, "iconID": 1443, "nameID": 612136, "hasTypes": 0, "parentGroupID": 2861}
2038	2939	{"_key": 2939, "iconID": 20967, "nameID": 612141, "hasTypes": 1, "parentGroupID": 2938}
2039	2940	{"_key": 2940, "iconID": 20968, "nameID": 612144, "hasTypes": 1, "parentGroupID": 2938}
2040	2941	{"_key": 2941, "iconID": 1443, "nameID": 612159, "hasTypes": 1, "parentGroupID": 2850}
2041	2942	{"_key": 2942, "iconID": 1443, "nameID": 612162, "hasTypes": 1, "parentGroupID": 2938}
2042	2943	{"_key": 2943, "iconID": 20959, "nameID": 612179, "hasTypes": 1, "parentGroupID": 2938}
2043	2944	{"_key": 2944, "iconID": 20968, "nameID": 612190, "hasTypes": 1, "parentGroupID": 2945}
2044	2945	{"_key": 2945, "iconID": 1443, "nameID": 612191, "hasTypes": 0, "parentGroupID": 2888}
2045	2946	{"_key": 2946, "iconID": 20966, "nameID": 612194, "hasTypes": 1, "parentGroupID": 2945}
2046	2947	{"_key": 2947, "iconID": 1443, "nameID": 612197, "hasTypes": 1, "parentGroupID": 2945}
2047	2948	{"_key": 2948, "iconID": 20967, "nameID": 612204, "hasTypes": 1, "parentGroupID": 2945}
2048	2949	{"_key": 2949, "iconID": 20959, "nameID": 612207, "hasTypes": 1, "parentGroupID": 2945}
2049	2950	{"_key": 2950, "iconID": 20966, "nameID": 612211, "hasTypes": 1, "parentGroupID": 2951}
2050	2951	{"_key": 2951, "iconID": 1443, "nameID": 612212, "hasTypes": 0, "parentGroupID": 2851}
2051	2952	{"_key": 2952, "iconID": 20967, "nameID": 612215, "hasTypes": 1, "parentGroupID": 2951}
2052	2953	{"_key": 2953, "iconID": 20968, "nameID": 612218, "hasTypes": 1, "parentGroupID": 2951}
2053	2954	{"_key": 2954, "iconID": 1443, "nameID": 612229, "hasTypes": 1, "parentGroupID": 2850}
2054	2955	{"_key": 2955, "iconID": 20959, "nameID": 612246, "hasTypes": 1, "parentGroupID": 2951}
2055	2956	{"_key": 2956, "iconID": 1443, "nameID": 612249, "hasTypes": 1, "parentGroupID": 2951}
2056	2957	{"_key": 2957, "iconID": 1443, "nameID": 612255, "hasTypes": 1, "parentGroupID": 2850}
2057	2958	{"_key": 2958, "iconID": 20959, "nameID": 612264, "hasTypes": 1, "parentGroupID": 2959}
2058	2959	{"_key": 2959, "iconID": 1443, "nameID": 612265, "hasTypes": 0, "parentGroupID": 2866}
2059	2960	{"_key": 2960, "iconID": 20968, "nameID": 612268, "hasTypes": 1, "parentGroupID": 2959}
2060	2961	{"_key": 2961, "iconID": 20966, "nameID": 612274, "hasTypes": 1, "parentGroupID": 2959}
2061	2962	{"_key": 2962, "iconID": 20967, "nameID": 612286, "hasTypes": 1, "parentGroupID": 2959}
2062	2963	{"_key": 2963, "iconID": 24135, "nameID": 612291, "hasTypes": 1, "parentGroupID": 2959}
2063	2964	{"_key": 2964, "iconID": 1443, "nameID": 612295, "hasTypes": 1, "parentGroupID": 2850}
2064	2965	{"_key": 2965, "iconID": 20966, "nameID": 612306, "hasTypes": 1, "parentGroupID": 2966}
2065	2966	{"_key": 2966, "iconID": 1443, "nameID": 612307, "hasTypes": 0, "parentGroupID": 2895}
2066	2967	{"_key": 2967, "iconID": 20968, "nameID": 612310, "hasTypes": 1, "parentGroupID": 2966}
2067	2968	{"_key": 2968, "iconID": 20959, "nameID": 612313, "hasTypes": 1, "parentGroupID": 2966}
2068	2969	{"_key": 2969, "iconID": 20967, "nameID": 612316, "hasTypes": 1, "parentGroupID": 2966}
2069	2970	{"_key": 2970, "iconID": 24135, "nameID": 612327, "hasTypes": 1, "parentGroupID": 2966}
2070	2971	{"_key": 2971, "iconID": 24135, "nameID": 612340, "hasTypes": 1, "parentGroupID": 2972}
2071	2972	{"_key": 2972, "iconID": 1443, "nameID": 612341, "hasTypes": 0, "parentGroupID": 2854}
2072	2973	{"_key": 2973, "iconID": 1443, "nameID": 612344, "hasTypes": 1, "parentGroupID": 2974}
2073	2974	{"_key": 2974, "iconID": 1443, "nameID": 612345, "hasTypes": 0, "parentGroupID": 2854}
2074	2975	{"_key": 2975, "iconID": 1443, "nameID": 612362, "hasTypes": 1, "parentGroupID": 2850}
2075	2976	{"_key": 2976, "iconID": 24135, "nameID": 612384, "hasTypes": 1, "parentGroupID": 2977}
2076	2977	{"_key": 2977, "iconID": 1443, "nameID": 612385, "hasTypes": 0, "parentGroupID": 2871}
2077	2978	{"_key": 2978, "iconID": 20967, "nameID": 612398, "hasTypes": 1, "parentGroupID": 2979}
2078	2979	{"_key": 2979, "iconID": 1443, "nameID": 612399, "hasTypes": 0, "parentGroupID": 2871}
2079	2980	{"_key": 2980, "iconID": 20959, "nameID": 612402, "hasTypes": 1, "parentGroupID": 2979}
2080	2981	{"_key": 2981, "iconID": 20966, "nameID": 612405, "hasTypes": 1, "parentGroupID": 2979}
2081	2982	{"_key": 2982, "iconID": 20968, "nameID": 612408, "hasTypes": 1, "parentGroupID": 2979}
2082	2983	{"_key": 2983, "iconID": 1443, "nameID": 612421, "hasTypes": 1, "parentGroupID": 2850}
2083	2984	{"_key": 2984, "iconID": 1443, "nameID": 612433, "hasTypes": 1, "parentGroupID": 2985}
2084	2985	{"_key": 2985, "iconID": 1443, "nameID": 612434, "hasTypes": 0, "parentGroupID": 2851}
2085	2986	{"_key": 2986, "iconID": 1443, "nameID": 612450, "hasTypes": 1, "parentGroupID": 2987}
2086	2987	{"_key": 2987, "iconID": 1443, "nameID": 612451, "hasTypes": 0, "parentGroupID": 2888}
2087	2988	{"_key": 2988, "iconID": 24135, "nameID": 612458, "hasTypes": 1, "parentGroupID": 2987}
2088	2989	{"_key": 2989, "iconID": 20966, "nameID": 612461, "hasTypes": 1, "parentGroupID": 2987}
2089	2990	{"_key": 2990, "iconID": 20968, "nameID": 612464, "hasTypes": 1, "parentGroupID": 2987}
2090	2991	{"_key": 2991, "iconID": 20967, "nameID": 612467, "hasTypes": 1, "parentGroupID": 2987}
2091	2992	{"_key": 2992, "iconID": 20959, "nameID": 612470, "hasTypes": 1, "parentGroupID": 2987}
2092	2993	{"_key": 2993, "iconID": 20959, "nameID": 612474, "hasTypes": 1, "parentGroupID": 2994}
2093	2994	{"_key": 2994, "iconID": 1443, "nameID": 612475, "hasTypes": 0, "parentGroupID": 2888}
2094	2995	{"_key": 2995, "iconID": 20967, "nameID": 612478, "hasTypes": 1, "parentGroupID": 2994}
2095	2996	{"_key": 2996, "iconID": 20968, "nameID": 612481, "hasTypes": 1, "parentGroupID": 2994}
2096	2997	{"_key": 2997, "iconID": 20966, "nameID": 612484, "hasTypes": 1, "parentGroupID": 2994}
2097	2998	{"_key": 2998, "iconID": 1443, "nameID": 612487, "hasTypes": 1, "parentGroupID": 2994}
2098	2999	{"_key": 2999, "iconID": 20967, "nameID": 612491, "hasTypes": 1, "parentGroupID": 3000}
2099	3000	{"_key": 3000, "iconID": 1443, "nameID": 612492, "hasTypes": 0, "parentGroupID": 3001}
2100	3001	{"_key": 3001, "iconID": 1443, "nameID": 612493, "hasTypes": 0, "parentGroupID": 2854}
2101	3002	{"_key": 3002, "iconID": 20968, "nameID": 612496, "hasTypes": 1, "parentGroupID": 3000}
2102	3003	{"_key": 3003, "iconID": 20966, "nameID": 612500, "hasTypes": 1, "parentGroupID": 3000}
2103	3004	{"_key": 3004, "iconID": 20959, "nameID": 612503, "hasTypes": 1, "parentGroupID": 3000}
2104	3005	{"_key": 3005, "iconID": 20959, "nameID": 612517, "hasTypes": 1, "parentGroupID": 3006}
2105	3006	{"_key": 3006, "iconID": 1443, "nameID": 612518, "hasTypes": 0, "parentGroupID": 2870}
2106	3007	{"_key": 3007, "iconID": 20968, "nameID": 612521, "hasTypes": 1, "parentGroupID": 3006}
2107	3008	{"_key": 3008, "iconID": 20967, "nameID": 612524, "hasTypes": 1, "parentGroupID": 3006}
2108	3009	{"_key": 3009, "iconID": 20966, "nameID": 612527, "hasTypes": 1, "parentGroupID": 3006}
2109	3010	{"_key": 3010, "iconID": 1443, "nameID": 612533, "hasTypes": 1, "parentGroupID": 2985}
2110	3011	{"_key": 3011, "iconID": 20967, "nameID": 612541, "hasTypes": 1, "parentGroupID": 3012}
2111	3012	{"_key": 3012, "iconID": 1443, "nameID": 612542, "hasTypes": 0, "parentGroupID": 2888}
2112	3013	{"_key": 3013, "iconID": 20959, "nameID": 612544, "hasTypes": 1, "parentGroupID": 3012}
2113	3014	{"_key": 3014, "iconID": 20966, "nameID": 612549, "hasTypes": 1, "parentGroupID": 3012}
2114	3015	{"_key": 3015, "iconID": 20968, "nameID": 612552, "hasTypes": 1, "parentGroupID": 3012}
2115	3016	{"_key": 3016, "iconID": 1443, "nameID": 612556, "hasTypes": 1, "parentGroupID": 3012}
2116	3017	{"_key": 3017, "iconID": 1443, "nameID": 612571, "hasTypes": 1, "parentGroupID": 2850}
2117	3018	{"_key": 3018, "iconID": 20967, "nameID": 612580, "hasTypes": 1, "parentGroupID": 3019}
2118	3019	{"_key": 3019, "iconID": 1443, "nameID": 612581, "hasTypes": 0, "parentGroupID": 2866}
2119	3020	{"_key": 3020, "iconID": 20968, "nameID": 612584, "hasTypes": 1, "parentGroupID": 3019}
2120	3021	{"_key": 3021, "iconID": 20966, "nameID": 612587, "hasTypes": 1, "parentGroupID": 3019}
2121	3022	{"_key": 3022, "iconID": 20959, "nameID": 612590, "hasTypes": 1, "parentGroupID": 3019}
2122	3023	{"_key": 3023, "iconID": 20968, "nameID": 612594, "hasTypes": 1, "parentGroupID": 3024}
2123	3024	{"_key": 3024, "iconID": 1443, "nameID": 612595, "hasTypes": 0, "parentGroupID": 2866}
2124	3025	{"_key": 3025, "iconID": 1443, "nameID": 612598, "hasTypes": 1, "parentGroupID": 2850}
2125	3026	{"_key": 3026, "iconID": 20966, "nameID": 612603, "hasTypes": 1, "parentGroupID": 3024}
2126	3027	{"_key": 3027, "iconID": 20967, "nameID": 612608, "hasTypes": 1, "parentGroupID": 3024}
2127	3028	{"_key": 3028, "iconID": 20959, "nameID": 612613, "hasTypes": 1, "parentGroupID": 3024}
2128	3029	{"_key": 3029, "iconID": 1443, "nameID": 612621, "hasTypes": 1, "parentGroupID": 2850}
2129	3030	{"_key": 3030, "iconID": 24135, "nameID": 612626, "hasTypes": 1, "parentGroupID": 3031}
2130	3031	{"_key": 3031, "iconID": 1443, "nameID": 612627, "hasTypes": 0, "parentGroupID": 2895}
2131	3032	{"_key": 3032, "iconID": 20968, "nameID": 612630, "hasTypes": 1, "parentGroupID": 3031}
2132	3033	{"_key": 3033, "iconID": 20966, "nameID": 612633, "hasTypes": 1, "parentGroupID": 3031}
2133	3034	{"_key": 3034, "iconID": 20959, "nameID": 612636, "hasTypes": 1, "parentGroupID": 3031}
2134	3035	{"_key": 3035, "iconID": 20967, "nameID": 612639, "hasTypes": 1, "parentGroupID": 3031}
2135	3036	{"_key": 3036, "iconID": 1443, "nameID": 612643, "hasTypes": 1, "parentGroupID": 2850}
2136	3037	{"_key": 3037, "iconID": 20966, "nameID": 612654, "hasTypes": 1, "parentGroupID": 3038}
2137	3038	{"_key": 3038, "iconID": 1443, "nameID": 612655, "hasTypes": 0, "parentGroupID": 2895}
2138	3039	{"_key": 3039, "iconID": 20968, "nameID": 612658, "hasTypes": 1, "parentGroupID": 3038}
2139	3040	{"_key": 3040, "iconID": 20959, "nameID": 612661, "hasTypes": 1, "parentGroupID": 3038}
2140	3041	{"_key": 3041, "iconID": 20967, "nameID": 612664, "hasTypes": 1, "parentGroupID": 3038}
2141	3042	{"_key": 3042, "iconID": 1443, "nameID": 612681, "hasTypes": 1, "parentGroupID": 3043}
2142	3043	{"_key": 3043, "iconID": 1443, "nameID": 612682, "hasTypes": 0, "parentGroupID": 2888}
2143	3044	{"_key": 3044, "iconID": 1443, "nameID": 612686, "hasTypes": 1, "parentGroupID": 2850}
2144	3045	{"_key": 3045, "iconID": 20967, "nameID": 612689, "hasTypes": 1, "parentGroupID": 3046}
2145	3046	{"_key": 3046, "iconID": 1443, "nameID": 612690, "hasTypes": 0, "parentGroupID": 2866}
2146	3047	{"_key": 3047, "iconID": 20968, "nameID": 612693, "hasTypes": 1, "parentGroupID": 3046}
2147	3048	{"_key": 3048, "iconID": 20966, "nameID": 612696, "hasTypes": 1, "parentGroupID": 3046}
2148	3049	{"_key": 3049, "iconID": 20959, "nameID": 612699, "hasTypes": 1, "parentGroupID": 3046}
2149	3050	{"_key": 3050, "iconID": 1443, "nameID": 612703, "hasTypes": 1, "parentGroupID": 2850}
2150	3051	{"_key": 3051, "iconID": 20966, "nameID": 612708, "hasTypes": 1, "parentGroupID": 3052}
2151	3052	{"_key": 3052, "iconID": 1443, "nameID": 612709, "hasTypes": 0, "parentGroupID": 2895}
2152	3053	{"_key": 3053, "iconID": 20968, "nameID": 612712, "hasTypes": 1, "parentGroupID": 3052}
2153	3054	{"_key": 3054, "iconID": 20959, "nameID": 612715, "hasTypes": 1, "parentGroupID": 3052}
2154	3055	{"_key": 3055, "iconID": 20967, "nameID": 612718, "hasTypes": 1, "parentGroupID": 3052}
2155	3056	{"_key": 3056, "iconID": 20959, "nameID": 612724, "hasTypes": 1, "parentGroupID": 3057}
2156	3057	{"_key": 3057, "iconID": 1443, "nameID": 612725, "hasTypes": 0, "parentGroupID": 3058}
2157	3058	{"_key": 3058, "iconID": 1443, "nameID": 612726, "hasTypes": 0, "parentGroupID": 2927}
2158	3059	{"_key": 3059, "iconID": 20967, "nameID": 612729, "hasTypes": 1, "parentGroupID": 3057}
2159	3060	{"_key": 3060, "iconID": 20966, "nameID": 612732, "hasTypes": 1, "parentGroupID": 3057}
2160	3061	{"_key": 3061, "iconID": 20968, "nameID": 612735, "hasTypes": 1, "parentGroupID": 3057}
2161	3062	{"_key": 3062, "iconID": 20959, "nameID": 612739, "hasTypes": 1, "parentGroupID": 3063}
2162	3063	{"_key": 3063, "iconID": 1443, "nameID": 612740, "hasTypes": 0, "parentGroupID": 3058}
2163	3064	{"_key": 3064, "iconID": 20967, "nameID": 612743, "hasTypes": 1, "parentGroupID": 3063}
2164	3065	{"_key": 3065, "iconID": 20968, "nameID": 612746, "hasTypes": 1, "parentGroupID": 3063}
2165	3066	{"_key": 3066, "iconID": 20966, "nameID": 612749, "hasTypes": 1, "parentGroupID": 3063}
2166	3067	{"_key": 3067, "iconID": 20966, "nameID": 612779, "hasTypes": 1, "parentGroupID": 3068}
2167	3068	{"_key": 3068, "iconID": 1443, "nameID": 612780, "hasTypes": 0, "parentGroupID": 2888}
2168	3069	{"_key": 3069, "iconID": 20968, "nameID": 612783, "hasTypes": 1, "parentGroupID": 3068}
2169	3070	{"_key": 3070, "iconID": 20967, "nameID": 612786, "hasTypes": 1, "parentGroupID": 3068}
2170	3071	{"_key": 3071, "iconID": 20959, "nameID": 612789, "hasTypes": 1, "parentGroupID": 3068}
2171	3072	{"_key": 3072, "iconID": 1443, "nameID": 612804, "hasTypes": 1, "parentGroupID": 3073}
2172	3073	{"_key": 3073, "iconID": 1443, "nameID": 612805, "hasTypes": 0, "parentGroupID": 2861}
2173	3074	{"_key": 3074, "iconID": 20966, "nameID": 612811, "hasTypes": 1, "parentGroupID": 3075}
2174	3075	{"_key": 3075, "iconID": 1443, "nameID": 612812, "hasTypes": 0, "parentGroupID": 2895}
2175	3076	{"_key": 3076, "iconID": 20959, "nameID": 612815, "hasTypes": 1, "parentGroupID": 3075}
2176	3077	{"_key": 3077, "iconID": 20967, "nameID": 612818, "hasTypes": 1, "parentGroupID": 3075}
2177	3078	{"_key": 3078, "iconID": 20968, "nameID": 612821, "hasTypes": 1, "parentGroupID": 3075}
2178	3079	{"_key": 3079, "iconID": 3240, "nameID": 612825, "hasTypes": 1, "parentGroupID": 3080}
2179	3080	{"_key": 3080, "iconID": 1061, "nameID": 612828, "hasTypes": 0, "parentGroupID": 2848}
2180	3081	{"_key": 3081, "iconID": 10933, "nameID": 612841, "hasTypes": 1, "parentGroupID": 3082}
2181	3082	{"_key": 3082, "iconID": 1030, "nameID": 612842, "hasTypes": 0, "parentGroupID": 3083}
2182	3083	{"_key": 3083, "iconID": 68, "nameID": 612843, "hasTypes": 0, "parentGroupID": 2848}
2183	3084	{"_key": 3084, "iconID": 10932, "nameID": 612847, "hasTypes": 1, "parentGroupID": 3085}
2184	3085	{"_key": 3085, "iconID": 111, "nameID": 612848, "hasTypes": 0, "parentGroupID": 2848}
2185	3086	{"_key": 3086, "iconID": 84, "nameID": 612854, "hasTypes": 1, "parentGroupID": 2846}
2186	3087	{"_key": 3087, "iconID": 84, "nameID": 612857, "hasTypes": 1, "parentGroupID": 2846}
2187	3088	{"_key": 3088, "iconID": 84, "nameID": 612862, "hasTypes": 1, "parentGroupID": 2846}
2188	3089	{"_key": 3089, "iconID": 84, "nameID": 612865, "hasTypes": 1, "parentGroupID": 2846}
2189	3090	{"_key": 3090, "iconID": 20971, "nameID": 612869, "hasTypes": 1, "parentGroupID": 3091}
2190	3091	{"_key": 3091, "iconID": 72, "nameID": 612870, "hasTypes": 0, "parentGroupID": 2848}
2191	3092	{"_key": 3092, "iconID": 80, "nameID": 612878, "hasTypes": 1, "parentGroupID": 3093}
2192	3093	{"_key": 3093, "iconID": 80, "nameID": 612879, "hasTypes": 0, "parentGroupID": 3083}
2193	3094	{"_key": 3094, "iconID": 80, "nameID": 612882, "hasTypes": 1, "parentGroupID": 3093}
2194	3095	{"_key": 3095, "iconID": 80, "nameID": 612885, "hasTypes": 1, "parentGroupID": 3093}
2195	3096	{"_key": 3096, "iconID": 80, "nameID": 612888, "hasTypes": 1, "parentGroupID": 3093}
2196	3097	{"_key": 3097, "iconID": 21025, "nameID": 612892, "hasTypes": 1, "parentGroupID": 3098}
2197	3098	{"_key": 3098, "iconID": 107, "nameID": 612893, "hasTypes": 0, "parentGroupID": 2848}
2198	3099	{"_key": 3099, "iconID": 2677, "nameID": 612903, "hasTypes": 1, "parentGroupID": 3098}
2199	3100	{"_key": 3100, "iconID": 21057, "nameID": 612909, "hasTypes": 1, "parentGroupID": 3101}
2200	3101	{"_key": 3101, "iconID": 21057, "nameID": 612910, "hasTypes": 0, "parentGroupID": 3102}
2201	3102	{"_key": 3102, "iconID": 3203, "nameID": 612911, "hasTypes": 0, "parentGroupID": 3103}
2202	3103	{"_key": 3103, "iconID": 2887, "nameID": 612912, "hasTypes": 0, "parentGroupID": 2822}
2203	3104	{"_key": 3104, "iconID": 21057, "nameID": 612915, "hasTypes": 1, "parentGroupID": 3101}
2204	3105	{"_key": 3105, "iconID": 21057, "nameID": 612920, "hasTypes": 1, "parentGroupID": 3101}
2205	3106	{"_key": 3106, "iconID": 21057, "nameID": 612927, "hasTypes": 1, "parentGroupID": 3101}
2206	3107	{"_key": 3107, "iconID": 21058, "nameID": 612937, "hasTypes": 1, "parentGroupID": 3108}
2207	3108	{"_key": 3108, "iconID": 21058, "nameID": 612938, "hasTypes": 0, "parentGroupID": 3102}
2208	3109	{"_key": 3109, "iconID": 21058, "nameID": 612941, "hasTypes": 1, "parentGroupID": 3108}
2209	3110	{"_key": 3110, "iconID": 21058, "nameID": 612948, "hasTypes": 1, "parentGroupID": 3108}
2210	3111	{"_key": 3111, "iconID": 21058, "nameID": 612973, "hasTypes": 1, "parentGroupID": 3108}
2211	3112	{"_key": 3112, "iconID": 21059, "nameID": 613007, "hasTypes": 1, "parentGroupID": 3113}
2212	3113	{"_key": 3113, "iconID": 21059, "nameID": 613008, "hasTypes": 0, "parentGroupID": 3102}
2213	3114	{"_key": 3114, "iconID": 21059, "nameID": 613011, "hasTypes": 1, "parentGroupID": 3113}
2214	3115	{"_key": 3115, "iconID": 21059, "nameID": 613016, "hasTypes": 1, "parentGroupID": 3113}
2215	3116	{"_key": 3116, "iconID": 21059, "nameID": 613025, "hasTypes": 1, "parentGroupID": 3113}
2216	3117	{"_key": 3117, "iconID": 21074, "nameID": 613050, "hasTypes": 1, "parentGroupID": 3118}
2217	3118	{"_key": 3118, "iconID": 168, "nameID": 613051, "hasTypes": 0, "parentGroupID": 3119}
2218	3119	{"_key": 3119, "iconID": 365, "nameID": 613052, "hasTypes": 0, "parentGroupID": 2848}
2219	3120	{"_key": 3120, "iconID": 98, "nameID": 613094, "hasTypes": 1, "parentGroupID": 3121}
2220	3121	{"_key": 3121, "iconID": 97, "nameID": 613095, "hasTypes": 0, "parentGroupID": 3091}
2221	3122	{"_key": 3122, "iconID": 2989, "nameID": 613105, "hasTypes": 1, "parentGroupID": 2848}
2222	3123	{"_key": 3123, "iconID": 98, "nameID": 613137, "hasTypes": 1, "parentGroupID": 3121}
2223	3124	{"_key": 3124, "iconID": 3196, "nameID": 613170, "hasTypes": 1, "parentGroupID": 3125}
2224	3125	{"_key": 3125, "iconID": 3196, "nameID": 613171, "hasTypes": 0, "parentGroupID": 3102}
2225	3126	{"_key": 3126, "iconID": 3196, "nameID": 613174, "hasTypes": 1, "parentGroupID": 3125}
2226	3127	{"_key": 3127, "iconID": 3196, "nameID": 613177, "hasTypes": 1, "parentGroupID": 3125}
2227	3128	{"_key": 3128, "iconID": 3196, "nameID": 613180, "hasTypes": 1, "parentGroupID": 3125}
2228	3129	{"_key": 3129, "iconID": 107, "nameID": 613184, "hasTypes": 1, "parentGroupID": 3098}
2229	3130	{"_key": 3130, "iconID": 21439, "nameID": 613206, "hasTypes": 1, "parentGroupID": 3131}
2230	3131	{"_key": 3131, "iconID": 21440, "nameID": 613207, "hasTypes": 0, "parentGroupID": 3119}
2231	3132	{"_key": 3132, "iconID": 21437, "nameID": 613221, "hasTypes": 1, "parentGroupID": 3131}
2232	3133	{"_key": 3133, "iconID": 20971, "nameID": 613229, "hasTypes": 1, "parentGroupID": 3091}
2233	3134	{"_key": 3134, "iconID": 1284, "nameID": 613233, "hasTypes": 1, "parentGroupID": 3085}
2234	3135	{"_key": 3135, "iconID": 170, "nameID": 613251, "hasTypes": 1, "parentGroupID": 3118}
2235	3136	{"_key": 3136, "iconID": 3955, "nameID": 613263, "hasTypes": 1, "parentGroupID": 3118}
2236	3137	{"_key": 3137, "iconID": 86, "nameID": 613277, "hasTypes": 1, "parentGroupID": 3138}
2237	3138	{"_key": 3138, "iconID": 86, "nameID": 613278, "hasTypes": 0, "parentGroupID": 2847}
2238	3139	{"_key": 3139, "iconID": 86, "nameID": 613281, "hasTypes": 1, "parentGroupID": 3138}
2239	3140	{"_key": 3140, "iconID": 86, "nameID": 613284, "hasTypes": 1, "parentGroupID": 3138}
2240	3141	{"_key": 3141, "iconID": 86, "nameID": 613287, "hasTypes": 1, "parentGroupID": 3138}
2241	3142	{"_key": 3142, "iconID": 80, "nameID": 613291, "hasTypes": 1, "parentGroupID": 3143}
2242	3143	{"_key": 3143, "iconID": 80, "nameID": 613292, "hasTypes": 0, "parentGroupID": 3083}
2243	3144	{"_key": 3144, "iconID": 80, "nameID": 613295, "hasTypes": 1, "parentGroupID": 3143}
2244	3145	{"_key": 3145, "iconID": 80, "nameID": 613298, "hasTypes": 1, "parentGroupID": 3143}
2245	3146	{"_key": 3146, "iconID": 80, "nameID": 613301, "hasTypes": 1, "parentGroupID": 3143}
2246	3147	{"_key": 3147, "iconID": 10933, "nameID": 613305, "hasTypes": 1, "parentGroupID": 3082}
2247	3148	{"_key": 3148, "iconID": 81, "nameID": 613315, "hasTypes": 1, "parentGroupID": 3149}
2248	3149	{"_key": 3149, "iconID": 81, "nameID": 613316, "hasTypes": 0, "parentGroupID": 2847}
2249	3150	{"_key": 3150, "iconID": 74, "nameID": 613328, "hasTypes": 1, "parentGroupID": 3151}
2250	3151	{"_key": 3151, "iconID": 104, "nameID": 613329, "hasTypes": 0, "parentGroupID": 2848}
2251	3152	{"_key": 3152, "iconID": 20970, "nameID": 613333, "hasTypes": 1, "parentGroupID": 3153}
2252	3153	{"_key": 3153, "iconID": 20969, "nameID": 613334, "hasTypes": 0, "parentGroupID": 2848}
2253	3154	{"_key": 3154, "iconID": 2934, "nameID": 613356, "hasTypes": 1, "parentGroupID": 3155}
2254	3155	{"_key": 3155, "iconID": 2934, "nameID": 613357, "hasTypes": 0, "parentGroupID": 3119}
2255	3156	{"_key": 3156, "iconID": 2934, "nameID": 613360, "hasTypes": 1, "parentGroupID": 3155}
2256	3157	{"_key": 3157, "iconID": 2934, "nameID": 613363, "hasTypes": 1, "parentGroupID": 3155}
2257	3158	{"_key": 3158, "iconID": 2934, "nameID": 613366, "hasTypes": 1, "parentGroupID": 3155}
2258	3159	{"_key": 3159, "iconID": 81, "nameID": 613370, "hasTypes": 1, "parentGroupID": 3149}
2259	3160	{"_key": 3160, "iconID": 2066, "nameID": 613372, "hasTypes": 1, "parentGroupID": 3161}
2260	3161	{"_key": 3161, "iconID": 2066, "nameID": 613373, "hasTypes": 0, "parentGroupID": 3083}
2261	3162	{"_key": 3162, "iconID": 21923, "nameID": 613377, "hasTypes": 1, "parentGroupID": 3163}
2262	3163	{"_key": 3163, "iconID": 21921, "nameID": 613378, "hasTypes": 0, "parentGroupID": 3164}
2263	3164	{"_key": 3164, "iconID": 21923, "nameID": 613379, "hasTypes": 0, "parentGroupID": 3119}
2264	3165	{"_key": 3165, "iconID": 21921, "nameID": 613382, "hasTypes": 1, "parentGroupID": 3163}
2265	3166	{"_key": 3166, "iconID": 21922, "nameID": 613393, "hasTypes": 1, "parentGroupID": 3163}
2266	3167	{"_key": 3167, "iconID": 24237, "nameID": 613416, "hasTypes": 1, "parentGroupID": 3163}
2267	3168	{"_key": 3168, "iconID": 1046, "nameID": 613422, "hasTypes": 1, "parentGroupID": 3131}
2268	3169	{"_key": 3169, "iconID": 97, "nameID": 613438, "hasTypes": 1, "parentGroupID": 3083}
2269	3170	{"_key": 3170, "iconID": 109, "nameID": 613448, "hasTypes": 1, "parentGroupID": 3171}
2270	3171	{"_key": 3171, "iconID": 109, "nameID": 613449, "hasTypes": 0, "parentGroupID": 3085}
2271	3172	{"_key": 3172, "iconID": 3227, "nameID": 613454, "hasTypes": 1, "parentGroupID": 3171}
2272	3173	{"_key": 3173, "iconID": 3228, "nameID": 613459, "hasTypes": 1, "parentGroupID": 3171}
2273	3174	{"_key": 3174, "iconID": 3226, "nameID": 613462, "hasTypes": 1, "parentGroupID": 3171}
2274	3175	{"_key": 3175, "iconID": 3229, "nameID": 613465, "hasTypes": 1, "parentGroupID": 3171}
2275	3176	{"_key": 3176, "iconID": 80, "nameID": 613539, "hasTypes": 1, "parentGroupID": 3177}
2276	3177	{"_key": 3177, "iconID": 80, "nameID": 613540, "hasTypes": 1, "parentGroupID": 3083}
2277	3178	{"_key": 3178, "iconID": 1046, "nameID": 613786, "hasTypes": 1, "parentGroupID": 3131}
2278	3179	{"_key": 3179, "iconID": 105, "nameID": 613854, "hasTypes": 1, "parentGroupID": 3085}
2279	3180	{"_key": 3180, "iconID": 3346, "nameID": 613872, "hasTypes": 1, "parentGroupID": 3131}
2280	3181	{"_key": 3181, "iconID": 104, "nameID": 613898, "hasTypes": 1, "parentGroupID": 3151}
2281	3182	{"_key": 3182, "iconID": 1640, "nameID": 613926, "hasTypes": 1, "parentGroupID": 3131}
2282	3183	{"_key": 3183, "iconID": 3346, "nameID": 614023, "hasTypes": 1, "parentGroupID": 3131}
2283	3184	{"_key": 3184, "iconID": 1405, "nameID": 614063, "hasTypes": 1, "parentGroupID": 3151}
2284	3185	{"_key": 3185, "iconID": 74, "nameID": 614122, "hasTypes": 1, "parentGroupID": 3151}
2285	3186	{"_key": 3186, "iconID": 1639, "nameID": 614146, "hasTypes": 1, "parentGroupID": 3085}
2286	3187	{"_key": 3187, "iconID": 1393, "nameID": 614223, "hasTypes": 1, "parentGroupID": 3188}
2287	3188	{"_key": 3188, "iconID": 20939, "nameID": 614224, "hasTypes": 0, "parentGroupID": 2847}
2288	3189	{"_key": 3189, "iconID": 1395, "nameID": 614227, "hasTypes": 1, "parentGroupID": 3188}
2289	3190	{"_key": 3190, "iconID": 1394, "nameID": 614234, "hasTypes": 1, "parentGroupID": 3188}
2290	3191	{"_key": 3191, "iconID": 1396, "nameID": 614241, "hasTypes": 1, "parentGroupID": 3188}
2291	3192	{"_key": 3192, "iconID": 1046, "nameID": 614417, "hasTypes": 1, "parentGroupID": 3131}
2292	3193	{"_key": 3193, "iconID": 97, "nameID": 614470, "hasTypes": 1, "parentGroupID": 3121}
2293	3194	{"_key": 3194, "iconID": 1396, "nameID": 614700, "hasTypes": 1, "parentGroupID": 3161}
2294	3195	{"_key": 3195, "iconID": 1395, "nameID": 614703, "hasTypes": 1, "parentGroupID": 3161}
2295	3196	{"_key": 3196, "iconID": 1393, "nameID": 614708, "hasTypes": 1, "parentGroupID": 3161}
2296	3197	{"_key": 3197, "iconID": 1394, "nameID": 614715, "hasTypes": 1, "parentGroupID": 3161}
2297	3198	{"_key": 3198, "iconID": 2066, "nameID": 614932, "hasTypes": 1, "parentGroupID": 3083}
2298	3199	{"_key": 3199, "iconID": 1395, "nameID": 615084, "hasTypes": 1, "parentGroupID": 3082}
2299	3200	{"_key": 3200, "iconID": 1396, "nameID": 615099, "hasTypes": 1, "parentGroupID": 3082}
2300	3201	{"_key": 3201, "iconID": 1393, "nameID": 615114, "hasTypes": 1, "parentGroupID": 3082}
2301	3202	{"_key": 3202, "iconID": 1394, "nameID": 615125, "hasTypes": 1, "parentGroupID": 3082}
2302	3203	{"_key": 3203, "iconID": 79, "nameID": 615483, "hasTypes": 1, "parentGroupID": 3204}
2303	3204	{"_key": 3204, "iconID": 79, "nameID": 615484, "hasTypes": 0, "parentGroupID": 3083}
2304	3205	{"_key": 3205, "iconID": 79, "nameID": 615487, "hasTypes": 1, "parentGroupID": 3204}
2305	3206	{"_key": 3206, "iconID": 79, "nameID": 615490, "hasTypes": 1, "parentGroupID": 3204}
2306	3207	{"_key": 3207, "iconID": 79, "nameID": 615493, "hasTypes": 1, "parentGroupID": 3204}
2307	3208	{"_key": 3208, "iconID": 79, "nameID": 615496, "hasTypes": 1, "parentGroupID": 3204}
2308	3209	{"_key": 3209, "iconID": 79, "nameID": 615519, "hasTypes": 1, "parentGroupID": 3204}
2309	3210	{"_key": 3210, "iconID": 2851, "nameID": 615619, "hasTypes": 1, "parentGroupID": 3131}
2310	3211	{"_key": 3211, "iconID": 2106, "nameID": 615622, "hasTypes": 1, "parentGroupID": 3151}
2311	3212	{"_key": 3212, "iconID": 84, "nameID": 615664, "hasTypes": 1, "parentGroupID": 2846}
2312	3213	{"_key": 3213, "iconID": 2105, "nameID": 615718, "hasTypes": 1, "parentGroupID": 3214}
2313	3214	{"_key": 3214, "iconID": 70, "nameID": 615719, "hasTypes": 0, "parentGroupID": 2848}
2314	3215	{"_key": 3215, "iconID": 21440, "nameID": 615799, "hasTypes": 1, "parentGroupID": 3131}
2315	3216	{"_key": 3216, "iconID": 2983, "nameID": 615873, "hasTypes": 1, "parentGroupID": 3085}
2316	3217	{"_key": 3217, "iconID": 1044, "nameID": 615913, "hasTypes": 1, "parentGroupID": 3218}
2317	3218	{"_key": 3218, "iconID": 1044, "nameID": 615914, "hasTypes": 0, "parentGroupID": 2847}
2318	3219	{"_key": 3219, "iconID": 1044, "nameID": 615933, "hasTypes": 1, "parentGroupID": 3218}
2319	3220	{"_key": 3220, "iconID": 1044, "nameID": 615936, "hasTypes": 1, "parentGroupID": 3218}
2320	3221	{"_key": 3221, "iconID": 1044, "nameID": 615987, "hasTypes": 1, "parentGroupID": 3218}
2321	3222	{"_key": 3222, "iconID": 83, "nameID": 616037, "hasTypes": 1, "parentGroupID": 2847}
2322	3223	{"_key": 3223, "iconID": 24464, "nameID": 616249, "hasTypes": 1, "parentGroupID": 3224}
2323	3224	{"_key": 3224, "iconID": 24466, "nameID": 616250, "hasTypes": 0, "parentGroupID": 3119}
2324	3225	{"_key": 3225, "iconID": 24465, "nameID": 616253, "hasTypes": 1, "parentGroupID": 3224}
2325	3226	{"_key": 3226, "iconID": 24466, "nameID": 616256, "hasTypes": 1, "parentGroupID": 3224}
2326	3227	{"_key": 3227, "iconID": 24467, "nameID": 616284, "hasTypes": 1, "parentGroupID": 3131}
2327	3228	{"_key": 3228, "iconID": 86, "nameID": 616369, "hasTypes": 1, "parentGroupID": 3138}
2328	3229	{"_key": 3229, "iconID": 24730, "nameID": 616411, "hasTypes": 1, "parentGroupID": 3121}
2329	3230	{"_key": 3230, "iconID": 2985, "nameID": 616421, "hasTypes": 1, "parentGroupID": 3153}
2330	3231	{"_key": 3231, "iconID": 77, "nameID": 616425, "hasTypes": 1, "parentGroupID": 3083}
2331	3232	{"_key": 3232, "iconID": 3074, "nameID": 616429, "hasTypes": 1, "parentGroupID": 3080}
2332	3233	{"_key": 3233, "iconID": 25152, "nameID": 616439, "hasTypes": 1, "parentGroupID": 2848}
2333	3234	{"_key": 3234, "iconID": 90, "nameID": 616470, "hasTypes": 1, "parentGroupID": 3214}
2334	3235	{"_key": 3235, "iconID": 10149, "nameID": 616532, "hasTypes": 1, "parentGroupID": 3091}
2335	3236	{"_key": 3236, "iconID": 96, "nameID": 616535, "hasTypes": 1, "parentGroupID": 3091}
2336	3237	{"_key": 3237, "iconID": 2526, "nameID": 616815, "hasTypes": 1, "parentGroupID": 3080}
2337	3238	{"_key": 3238, "iconID": 2527, "nameID": 616818, "hasTypes": 1, "parentGroupID": 3080}
2338	3239	{"_key": 3239, "iconID": 106, "nameID": 616832, "hasTypes": 1, "parentGroupID": 3098}
2339	3240	{"_key": 3240, "iconID": 107, "nameID": 616855, "hasTypes": 1, "parentGroupID": 3098}
2340	3241	{"_key": 3241, "iconID": 2677, "nameID": 616869, "hasTypes": 1, "parentGroupID": 3098}
2341	3242	{"_key": 3242, "iconID": 1061, "nameID": 616893, "hasTypes": 1, "parentGroupID": 3080}
2342	3243	{"_key": 3243, "iconID": 2732, "nameID": 616901, "hasTypes": 1, "parentGroupID": 3098}
2343	3246	{"_key": 3246, "iconID": 2530, "nameID": 616920, "hasTypes": 1, "parentGroupID": 3118}
2344	3247	{"_key": 3247, "iconID": 1345, "nameID": 616966, "hasTypes": 1, "parentGroupID": 3118}
2345	3248	{"_key": 3248, "iconID": 170, "nameID": 616998, "hasTypes": 1, "parentGroupID": 3118}
2346	3249	{"_key": 3249, "iconID": 168, "nameID": 617046, "hasTypes": 1, "parentGroupID": 3118}
2347	3250	{"_key": 3250, "iconID": 169, "nameID": 617086, "hasTypes": 1, "parentGroupID": 3118}
2348	3251	{"_key": 3251, "iconID": 1345, "nameID": 617126, "hasTypes": 1, "parentGroupID": 3118}
2349	3252	{"_key": 3252, "iconID": 1345, "nameID": 617152, "hasTypes": 1, "parentGroupID": 3118}
2350	3253	{"_key": 3253, "iconID": 1046, "nameID": 617156, "hasTypes": 1, "parentGroupID": 3171}
2351	3254	{"_key": 3254, "iconID": 111, "nameID": 617213, "hasTypes": 1, "parentGroupID": 3085}
2352	3255	{"_key": 3255, "iconID": 111, "nameID": 617216, "hasTypes": 1, "parentGroupID": 3085}
2353	3256	{"_key": 3256, "iconID": 352, "nameID": 617396, "hasTypes": 1, "parentGroupID": 3257}
2354	3257	{"_key": 3257, "iconID": 361, "nameID": 617397, "hasTypes": 0, "parentGroupID": 3258}
2355	3258	{"_key": 3258, "iconID": 352, "nameID": 617398, "hasTypes": 0, "parentGroupID": 3119}
2356	3259	{"_key": 3259, "iconID": 350, "nameID": 617407, "hasTypes": 1, "parentGroupID": 3260}
2357	3260	{"_key": 3260, "iconID": 360, "nameID": 617408, "hasTypes": 0, "parentGroupID": 3258}
2358	3261	{"_key": 3261, "iconID": 355, "nameID": 617425, "hasTypes": 1, "parentGroupID": 3257}
2359	3262	{"_key": 3262, "iconID": 356, "nameID": 617434, "hasTypes": 1, "parentGroupID": 3260}
2360	3263	{"_key": 3263, "iconID": 360, "nameID": 617467, "hasTypes": 1, "parentGroupID": 3260}
2361	3264	{"_key": 3264, "iconID": 361, "nameID": 617476, "hasTypes": 1, "parentGroupID": 3257}
2362	3265	{"_key": 3265, "iconID": 2841, "nameID": 617547, "hasTypes": 1, "parentGroupID": 3260}
2363	3266	{"_key": 3266, "iconID": 2837, "nameID": 617550, "hasTypes": 1, "parentGroupID": 3257}
2364	3267	{"_key": 3267, "iconID": 2856, "nameID": 617865, "hasTypes": 1, "parentGroupID": 3098}
2365	3268	{"_key": 3268, "iconID": 1061, "nameID": 617909, "hasTypes": 1, "parentGroupID": 3080}
2366	3269	{"_key": 3269, "iconID": 1046, "nameID": 617945, "hasTypes": 1, "parentGroupID": 3080}
2367	3270	{"_key": 3270, "iconID": 387, "nameID": 618025, "hasTypes": 1, "parentGroupID": 3271}
2368	3271	{"_key": 3271, "iconID": 381, "nameID": 618026, "hasTypes": 0, "parentGroupID": 3272}
2369	3272	{"_key": 3272, "iconID": 387, "nameID": 618027, "hasTypes": 0, "parentGroupID": 3119}
2370	3273	{"_key": 3273, "iconID": 389, "nameID": 618052, "hasTypes": 1, "parentGroupID": 3274}
2371	3274	{"_key": 3274, "iconID": 381, "nameID": 618053, "hasTypes": 0, "parentGroupID": 3272}
2372	3275	{"_key": 3275, "iconID": 386, "nameID": 618062, "hasTypes": 1, "parentGroupID": 3271}
2373	3276	{"_key": 3276, "iconID": 384, "nameID": 618087, "hasTypes": 1, "parentGroupID": 3274}
2374	3277	{"_key": 3277, "iconID": 381, "nameID": 618096, "hasTypes": 1, "parentGroupID": 3271}
2375	3278	{"_key": 3278, "iconID": 379, "nameID": 618121, "hasTypes": 1, "parentGroupID": 3274}
2376	3279	{"_key": 3279, "iconID": 2842, "nameID": 618196, "hasTypes": 1, "parentGroupID": 3274}
2377	3280	{"_key": 3280, "iconID": 2838, "nameID": 618199, "hasTypes": 1, "parentGroupID": 3271}
2378	3281	{"_key": 3281, "iconID": 83, "nameID": 618399, "hasTypes": 1, "parentGroupID": 2847}
2379	3282	{"_key": 3282, "iconID": 80, "nameID": 618421, "hasTypes": 1, "parentGroupID": 3283}
2380	3283	{"_key": 3283, "iconID": 80, "nameID": 618422, "hasTypes": 0, "parentGroupID": 3083}
2381	3284	{"_key": 3284, "iconID": 80, "nameID": 618425, "hasTypes": 1, "parentGroupID": 3283}
2382	3285	{"_key": 3285, "iconID": 80, "nameID": 618428, "hasTypes": 1, "parentGroupID": 3283}
2383	3286	{"_key": 3286, "iconID": 80, "nameID": 618433, "hasTypes": 1, "parentGroupID": 3283}
2384	3287	{"_key": 3287, "iconID": 2934, "nameID": 618454, "hasTypes": 1, "parentGroupID": 3155}
2385	3288	{"_key": 3288, "iconID": 2934, "nameID": 618467, "hasTypes": 1, "parentGroupID": 3155}
2386	3289	{"_key": 3289, "iconID": 111, "nameID": 618479, "hasTypes": 1, "parentGroupID": 3085}
2387	3290	{"_key": 3290, "iconID": 1046, "nameID": 618495, "hasTypes": 1, "parentGroupID": 3131}
2388	3291	{"_key": 3291, "iconID": 89, "nameID": 618627, "hasTypes": 1, "parentGroupID": 3292}
2389	3292	{"_key": 3292, "iconID": 89, "nameID": 618628, "hasTypes": 0, "parentGroupID": 3214}
2390	3293	{"_key": 3293, "iconID": 89, "nameID": 618653, "hasTypes": 1, "parentGroupID": 3292}
2391	3294	{"_key": 3294, "iconID": 89, "nameID": 618658, "hasTypes": 1, "parentGroupID": 3292}
2392	3295	{"_key": 3295, "iconID": 89, "nameID": 618679, "hasTypes": 1, "parentGroupID": 3292}
2393	3296	{"_key": 3296, "iconID": 89, "nameID": 618736, "hasTypes": 1, "parentGroupID": 3292}
2394	3297	{"_key": 3297, "iconID": 80, "nameID": 618964, "hasTypes": 1, "parentGroupID": 3298}
2395	3298	{"_key": 3298, "iconID": 80, "nameID": 618965, "hasTypes": 0, "parentGroupID": 3083}
2396	3299	{"_key": 3299, "iconID": 80, "nameID": 618972, "hasTypes": 1, "parentGroupID": 3298}
2397	3300	{"_key": 3300, "iconID": 80, "nameID": 618987, "hasTypes": 1, "parentGroupID": 3298}
2398	3301	{"_key": 3301, "iconID": 80, "nameID": 618990, "hasTypes": 1, "parentGroupID": 3298}
2399	3302	{"_key": 3302, "iconID": 1284, "nameID": 619127, "hasTypes": 1, "parentGroupID": 3085}
2400	3303	{"_key": 3303, "iconID": 2986, "nameID": 619183, "hasTypes": 1, "parentGroupID": 3151}
2401	3304	{"_key": 3304, "iconID": 1444, "nameID": 619197, "hasTypes": 1, "parentGroupID": 3153}
2402	3305	{"_key": 3305, "iconID": 1035, "nameID": 619205, "hasTypes": 1, "parentGroupID": 3306}
2403	3306	{"_key": 3306, "iconID": 1035, "nameID": 619206, "hasTypes": 0, "parentGroupID": 3214}
2404	3307	{"_key": 3307, "iconID": 1035, "nameID": 619209, "hasTypes": 1, "parentGroupID": 3306}
2405	3308	{"_key": 3308, "iconID": 1035, "nameID": 619212, "hasTypes": 1, "parentGroupID": 3306}
2406	3309	{"_key": 3309, "iconID": 1035, "nameID": 619215, "hasTypes": 1, "parentGroupID": 3306}
2407	3310	{"_key": 3310, "iconID": 1029, "nameID": 619295, "hasTypes": 1, "parentGroupID": 3311}
2408	3311	{"_key": 3311, "iconID": 1029, "nameID": 619296, "hasTypes": 0, "parentGroupID": 3214}
2409	3312	{"_key": 3312, "iconID": 1029, "nameID": 619315, "hasTypes": 1, "parentGroupID": 3311}
2410	3313	{"_key": 3313, "iconID": 1029, "nameID": 619324, "hasTypes": 1, "parentGroupID": 3311}
2411	3314	{"_key": 3314, "iconID": 1029, "nameID": 619329, "hasTypes": 1, "parentGroupID": 3311}
2412	3315	{"_key": 3315, "iconID": 1283, "nameID": 619435, "hasTypes": 1, "parentGroupID": 3316}
2413	3316	{"_key": 3316, "iconID": 1283, "nameID": 619436, "hasTypes": 0, "parentGroupID": 3214}
2414	3317	{"_key": 3317, "iconID": 1283, "nameID": 619443, "hasTypes": 1, "parentGroupID": 3316}
2415	3318	{"_key": 3318, "iconID": 1283, "nameID": 619450, "hasTypes": 1, "parentGroupID": 3316}
2416	3319	{"_key": 3319, "iconID": 1283, "nameID": 619459, "hasTypes": 1, "parentGroupID": 3316}
2417	3320	{"_key": 3320, "iconID": 112, "nameID": 619555, "hasTypes": 1, "parentGroupID": 3321}
2418	3321	{"_key": 3321, "iconID": 112, "nameID": 619556, "hasTypes": 0, "parentGroupID": 2848}
2419	3322	{"_key": 3322, "iconID": 112, "nameID": 619560, "hasTypes": 1, "parentGroupID": 3321}
2420	3323	{"_key": 3323, "iconID": 112, "nameID": 619567, "hasTypes": 1, "parentGroupID": 3321}
2421	3324	{"_key": 3324, "iconID": 112, "nameID": 619572, "hasTypes": 1, "parentGroupID": 3321}
2422	3325	{"_key": 3325, "iconID": 3074, "nameID": 619800, "hasTypes": 1, "parentGroupID": 3080}
2423	3326	{"_key": 3326, "iconID": 370, "nameID": 619812, "hasTypes": 1, "parentGroupID": 3327}
2424	3327	{"_key": 3327, "iconID": 366, "nameID": 619813, "hasTypes": 0, "parentGroupID": 3328}
2425	3328	{"_key": 3328, "iconID": 376, "nameID": 619814, "hasTypes": 0, "parentGroupID": 3119}
2426	3329	{"_key": 3329, "iconID": 365, "nameID": 619817, "hasTypes": 1, "parentGroupID": 3330}
2427	3330	{"_key": 3330, "iconID": 365, "nameID": 619818, "hasTypes": 0, "parentGroupID": 3328}
2428	3331	{"_key": 3331, "iconID": 366, "nameID": 619821, "hasTypes": 1, "parentGroupID": 3327}
2429	3332	{"_key": 3332, "iconID": 349, "nameID": 619880, "hasTypes": 1, "parentGroupID": 3327}
2430	3333	{"_key": 3333, "iconID": 376, "nameID": 619929, "hasTypes": 1, "parentGroupID": 3330}
2431	3334	{"_key": 3334, "iconID": 371, "nameID": 619954, "hasTypes": 1, "parentGroupID": 3330}
2432	3335	{"_key": 3335, "iconID": 2836, "nameID": 620061, "hasTypes": 1, "parentGroupID": 3330}
2433	3336	{"_key": 3336, "iconID": 2840, "nameID": 620064, "hasTypes": 1, "parentGroupID": 3327}
2434	3337	{"_key": 3337, "iconID": 1031, "nameID": 620326, "hasTypes": 1, "parentGroupID": 3338}
2435	3338	{"_key": 3338, "iconID": 1031, "nameID": 620327, "hasTypes": 0, "parentGroupID": 3214}
2436	3339	{"_key": 3339, "iconID": 1031, "nameID": 620346, "hasTypes": 1, "parentGroupID": 3338}
2437	3340	{"_key": 3340, "iconID": 1031, "nameID": 620351, "hasTypes": 1, "parentGroupID": 3338}
2438	3341	{"_key": 3341, "iconID": 1031, "nameID": 620356, "hasTypes": 1, "parentGroupID": 3338}
2439	3342	{"_key": 3342, "iconID": 1031, "nameID": 620375, "hasTypes": 1, "parentGroupID": 3338}
2440	3343	{"_key": 3343, "iconID": 1041, "nameID": 620465, "hasTypes": 1, "parentGroupID": 3121}
2441	3344	{"_key": 3344, "iconID": 1042, "nameID": 620503, "hasTypes": 1, "parentGroupID": 3345}
2442	3345	{"_key": 3345, "iconID": 92, "nameID": 620504, "hasTypes": 0, "parentGroupID": 3083}
2443	3346	{"_key": 3346, "iconID": 98, "nameID": 620528, "hasTypes": 1, "parentGroupID": 3121}
2444	3347	{"_key": 3347, "iconID": 92, "nameID": 620568, "hasTypes": 1, "parentGroupID": 3345}
2445	3348	{"_key": 3348, "iconID": 70, "nameID": 620604, "hasTypes": 1, "parentGroupID": 3214}
2446	3349	{"_key": 3349, "iconID": 90, "nameID": 620694, "hasTypes": 1, "parentGroupID": 3214}
2447	3350	{"_key": 3350, "iconID": 90, "nameID": 620752, "hasTypes": 1, "parentGroupID": 3214}
2448	3351	{"_key": 3351, "iconID": 70, "nameID": 620798, "hasTypes": 1, "parentGroupID": 3214}
2449	3352	{"_key": 3352, "iconID": 1393, "nameID": 620876, "hasTypes": 1, "parentGroupID": 3149}
2450	3353	{"_key": 3353, "iconID": 1396, "nameID": 620911, "hasTypes": 1, "parentGroupID": 3149}
2451	3354	{"_key": 3354, "iconID": 1395, "nameID": 620916, "hasTypes": 1, "parentGroupID": 3149}
2452	3355	{"_key": 3355, "iconID": 1394, "nameID": 620919, "hasTypes": 1, "parentGroupID": 3149}
2453	3356	{"_key": 3356, "iconID": 83, "nameID": 621123, "hasTypes": 1, "parentGroupID": 2847}
2454	3357	{"_key": 3357, "iconID": 3241, "nameID": 621171, "hasTypes": 1, "parentGroupID": 3118}
2455	3358	{"_key": 3358, "iconID": 3194, "nameID": 621199, "hasTypes": 1, "parentGroupID": 3359}
2456	3359	{"_key": 3359, "iconID": 3194, "nameID": 621200, "hasTypes": 0, "parentGroupID": 3102}
2457	3360	{"_key": 3360, "iconID": 3194, "nameID": 621203, "hasTypes": 1, "parentGroupID": 3359}
2458	3361	{"_key": 3361, "iconID": 3194, "nameID": 621210, "hasTypes": 1, "parentGroupID": 3359}
2459	3362	{"_key": 3362, "iconID": 3194, "nameID": 621289, "hasTypes": 1, "parentGroupID": 3359}
2460	3363	{"_key": 3363, "iconID": 3193, "nameID": 621353, "hasTypes": 1, "parentGroupID": 3364}
2461	3364	{"_key": 3364, "iconID": 3193, "nameID": 621354, "hasTypes": 0, "parentGroupID": 3102}
2462	3365	{"_key": 3365, "iconID": 3193, "nameID": 621357, "hasTypes": 1, "parentGroupID": 3364}
2463	3366	{"_key": 3366, "iconID": 3193, "nameID": 621364, "hasTypes": 1, "parentGroupID": 3364}
2464	3367	{"_key": 3367, "iconID": 3193, "nameID": 621443, "hasTypes": 1, "parentGroupID": 3364}
2465	3368	{"_key": 3368, "iconID": 3203, "nameID": 621503, "hasTypes": 1, "parentGroupID": 3369}
2466	3369	{"_key": 3369, "iconID": 3203, "nameID": 621504, "hasTypes": 0, "parentGroupID": 3102}
2467	3370	{"_key": 3370, "iconID": 3203, "nameID": 621507, "hasTypes": 1, "parentGroupID": 3369}
2468	3371	{"_key": 3371, "iconID": 3203, "nameID": 621514, "hasTypes": 1, "parentGroupID": 3369}
2469	3372	{"_key": 3372, "iconID": 3203, "nameID": 621589, "hasTypes": 1, "parentGroupID": 3369}
2470	3373	{"_key": 3373, "iconID": 3202, "nameID": 621621, "hasTypes": 1, "parentGroupID": 3374}
2471	3374	{"_key": 3374, "iconID": 3202, "nameID": 621622, "hasTypes": 0, "parentGroupID": 3102}
2472	3375	{"_key": 3375, "iconID": 3202, "nameID": 621625, "hasTypes": 1, "parentGroupID": 3374}
2473	3376	{"_key": 3376, "iconID": 3202, "nameID": 621632, "hasTypes": 1, "parentGroupID": 3374}
2474	3377	{"_key": 3377, "iconID": 3202, "nameID": 621703, "hasTypes": 1, "parentGroupID": 3374}
2475	3378	{"_key": 3378, "iconID": 3201, "nameID": 621739, "hasTypes": 1, "parentGroupID": 3379}
2476	3379	{"_key": 3379, "iconID": 3201, "nameID": 621740, "hasTypes": 0, "parentGroupID": 3102}
2477	3380	{"_key": 3380, "iconID": 3201, "nameID": 621743, "hasTypes": 1, "parentGroupID": 3379}
2478	3381	{"_key": 3381, "iconID": 3201, "nameID": 621750, "hasTypes": 1, "parentGroupID": 3379}
2479	3382	{"_key": 3382, "iconID": 3201, "nameID": 621797, "hasTypes": 1, "parentGroupID": 3379}
2480	3383	{"_key": 3383, "iconID": 3200, "nameID": 621837, "hasTypes": 1, "parentGroupID": 3384}
2481	3384	{"_key": 3384, "iconID": 3200, "nameID": 621838, "hasTypes": 0, "parentGroupID": 3102}
2482	3385	{"_key": 3385, "iconID": 3200, "nameID": 621841, "hasTypes": 1, "parentGroupID": 3384}
2483	3386	{"_key": 3386, "iconID": 3200, "nameID": 621912, "hasTypes": 1, "parentGroupID": 3384}
2484	3387	{"_key": 3387, "iconID": 3200, "nameID": 621943, "hasTypes": 1, "parentGroupID": 3384}
2485	3388	{"_key": 3388, "iconID": 3197, "nameID": 621983, "hasTypes": 1, "parentGroupID": 3389}
2486	3389	{"_key": 3389, "iconID": 3197, "nameID": 621984, "hasTypes": 0, "parentGroupID": 3102}
2487	3390	{"_key": 3390, "iconID": 3197, "nameID": 621987, "hasTypes": 1, "parentGroupID": 3389}
2488	3391	{"_key": 3391, "iconID": 3197, "nameID": 621994, "hasTypes": 1, "parentGroupID": 3389}
2489	3392	{"_key": 3392, "iconID": 3197, "nameID": 622059, "hasTypes": 1, "parentGroupID": 3389}
2490	3393	{"_key": 3393, "iconID": 76, "nameID": 622097, "hasTypes": 1, "parentGroupID": 3345}
2491	3394	{"_key": 3394, "iconID": 3195, "nameID": 622125, "hasTypes": 1, "parentGroupID": 3395}
2492	3395	{"_key": 3395, "iconID": 3195, "nameID": 622126, "hasTypes": 0, "parentGroupID": 3102}
2493	3396	{"_key": 3396, "iconID": 3195, "nameID": 622133, "hasTypes": 1, "parentGroupID": 3395}
2494	3397	{"_key": 3397, "iconID": 3195, "nameID": 622140, "hasTypes": 1, "parentGroupID": 3395}
2495	3398	{"_key": 3398, "iconID": 3195, "nameID": 622191, "hasTypes": 1, "parentGroupID": 3395}
2496	3399	{"_key": 3399, "iconID": 3198, "nameID": 622388, "hasTypes": 1, "parentGroupID": 3400}
2497	3400	{"_key": 3400, "iconID": 3198, "nameID": 622389, "hasTypes": 0, "parentGroupID": 3102}
2498	3401	{"_key": 3401, "iconID": 3198, "nameID": 622392, "hasTypes": 1, "parentGroupID": 3400}
2499	3402	{"_key": 3402, "iconID": 3198, "nameID": 622399, "hasTypes": 1, "parentGroupID": 3400}
2500	3403	{"_key": 3403, "iconID": 3198, "nameID": 622450, "hasTypes": 1, "parentGroupID": 3400}
2501	3404	{"_key": 3404, "iconID": 109, "nameID": 622492, "hasTypes": 1, "parentGroupID": 3085}
2502	3405	{"_key": 3405, "iconID": 34, "nameID": 622518, "hasTypes": 1, "parentGroupID": 3153}
2503	3406	{"_key": 3406, "iconID": 104, "nameID": 622526, "hasTypes": 1, "parentGroupID": 3151}
2504	3407	{"_key": 3407, "iconID": 21604, "nameID": 622540, "hasTypes": 1, "parentGroupID": 3085}
2505	3408	{"_key": 3408, "iconID": 2677, "nameID": 622561, "hasTypes": 1, "parentGroupID": 3119}
2506	3409	{"_key": 3409, "iconID": 111, "nameID": 622567, "hasTypes": 1, "parentGroupID": 3085}
2507	3410	{"_key": 3410, "iconID": 104, "nameID": 622588, "hasTypes": 1, "parentGroupID": 3151}
2508	3411	{"_key": 3411, "iconID": 1030, "nameID": 622650, "hasTypes": 1, "parentGroupID": 3412}
2509	3412	{"_key": 3412, "iconID": 1030, "nameID": 622651, "hasTypes": 0, "parentGroupID": 3083}
2510	3413	{"_key": 3413, "iconID": 1393, "nameID": 622654, "hasTypes": 1, "parentGroupID": 3412}
2511	3414	{"_key": 3414, "iconID": 1395, "nameID": 622657, "hasTypes": 1, "parentGroupID": 3412}
2512	3415	{"_key": 3415, "iconID": 1396, "nameID": 622660, "hasTypes": 1, "parentGroupID": 3412}
2513	3416	{"_key": 3416, "iconID": 1394, "nameID": 622663, "hasTypes": 1, "parentGroupID": 3412}
2514	3417	{"_key": 3417, "iconID": 1030, "nameID": 622680, "hasTypes": 1, "parentGroupID": 3083}
2515	3418	{"_key": 3418, "iconID": 1084, "nameID": 623063, "hasTypes": 1, "parentGroupID": 3419}
2516	3419	{"_key": 3419, "iconID": 1084, "nameID": 623064, "hasTypes": 0, "parentGroupID": 3420}
2517	3420	{"_key": 3420, "iconID": 1084, "nameID": 623065, "hasTypes": 0, "parentGroupID": 2822}
2518	3421	{"_key": 3421, "iconID": 1084, "nameID": 623120, "hasTypes": 1, "parentGroupID": 3419}
2519	3422	{"_key": 3422, "iconID": 1084, "nameID": 623147, "hasTypes": 1, "parentGroupID": 3419}
2520	3423	{"_key": 3423, "iconID": 1084, "nameID": 623152, "hasTypes": 1, "parentGroupID": 3419}
2521	3424	{"_key": 3424, "iconID": 1084, "nameID": 623301, "hasTypes": 1, "parentGroupID": 3420}
2522	3425	{"_key": 3425, "iconID": 1084, "nameID": 623328, "hasTypes": 1, "parentGroupID": 3420}
2523	3426	{"_key": 3426, "iconID": 1084, "nameID": 623343, "hasTypes": 1, "parentGroupID": 3420}
2524	3427	{"_key": 3427, "iconID": 1084, "nameID": 623358, "hasTypes": 1, "parentGroupID": 3420}
2525	3428	{"_key": 3428, "iconID": 1084, "nameID": 623383, "hasTypes": 1, "parentGroupID": 3420}
2526	3429	{"_key": 3429, "iconID": 1084, "nameID": 623405, "hasTypes": 1, "parentGroupID": 3420}
2527	3432	{"_key": 3432, "iconID": 1443, "nameID": 623504, "hasTypes": 0, "parentGroupID": 2851}
2528	3433	{"_key": 3433, "iconID": 20959, "nameID": 623505, "hasTypes": 1, "parentGroupID": 3432}
2529	3435	{"_key": 3435, "iconID": 20966, "nameID": 623506, "hasTypes": 1, "parentGroupID": 3432}
2530	3436	{"_key": 3436, "iconID": 20967, "nameID": 623507, "hasTypes": 1, "parentGroupID": 3432}
2531	3437	{"_key": 3437, "iconID": 20968, "nameID": 623508, "hasTypes": 1, "parentGroupID": 3432}
2532	3438	{"_key": 3438, "iconID": 24676, "nameID": 623861, "hasTypes": 1, "parentGroupID": 977}
2533	3439	{"_key": 3439, "iconID": 1443, "nameID": 623880, "hasTypes": 1, "descriptionID": 628803, "parentGroupID": 1368}
2534	3440	{"_key": 3440, "iconID": 1443, "nameID": 623910, "hasTypes": 1, "descriptionID": 623909, "parentGroupID": 1377}
2535	3443	{"_key": 3443, "iconID": 24675, "nameID": 626370, "hasTypes": 1, "parentGroupID": 977}
2536	3444	{"_key": 3444, "iconID": 24673, "nameID": 626372, "hasTypes": 1, "parentGroupID": 977}
2537	3445	{"_key": 3445, "iconID": 10144, "nameID": 628519, "hasTypes": 1, "parentGroupID": 2837}
2538	3446	{"_key": 3446, "iconID": 1443, "nameID": 628805, "hasTypes": 1, "descriptionID": 628804, "parentGroupID": 1368}
2539	3448	{"_key": 3448, "iconID": 10144, "nameID": 629483, "hasTypes": 1, "parentGroupID": 2837}
2540	3449	{"_key": 3449, "iconID": 10144, "nameID": 629484, "hasTypes": 1, "parentGroupID": 2837}
2541	3450	{"_key": 3450, "iconID": 16, "nameID": 636347, "hasTypes": 1, "parentGroupID": 404}
2542	3451	{"_key": 3451, "iconID": 2703, "nameID": 636353, "hasTypes": 0, "descriptionID": 636354, "parentGroupID": 406}
2543	3453	{"_key": 3453, "iconID": 1436, "nameID": 636415, "hasTypes": 1, "descriptionID": 636416, "parentGroupID": 1897}
2544	3454	{"_key": 3454, "iconID": 1436, "nameID": 636417, "hasTypes": 1, "descriptionID": 636418, "parentGroupID": 1897}
2545	3455	{"_key": 3455, "iconID": 1436, "nameID": 636419, "hasTypes": 1, "descriptionID": 636420, "parentGroupID": 1897}
2546	3456	{"_key": 3456, "iconID": 1436, "nameID": 636421, "hasTypes": 1, "descriptionID": 636422, "parentGroupID": 1897}
2547	3457	{"_key": 3457, "iconID": 3641, "nameID": 637294, "hasTypes": 0, "parentGroupID": 3103}
2548	3458	{"_key": 3458, "iconID": 20959, "nameID": 637298, "hasTypes": 0, "parentGroupID": 3457}
2549	3459	{"_key": 3459, "iconID": 20966, "nameID": 637299, "hasTypes": 0, "parentGroupID": 3457}
2550	3460	{"_key": 3460, "iconID": 20968, "nameID": 637300, "hasTypes": 0, "parentGroupID": 3457}
2551	3461	{"_key": 3461, "iconID": 20967, "nameID": 637301, "hasTypes": 0, "parentGroupID": 3457}
2552	3462	{"_key": 3462, "iconID": 3636, "nameID": 637302, "hasTypes": 1, "parentGroupID": 3458}
2553	3463	{"_key": 3463, "iconID": 3631, "nameID": 637303, "hasTypes": 1, "parentGroupID": 3458}
2554	3464	{"_key": 3464, "iconID": 3641, "nameID": 637304, "hasTypes": 1, "parentGroupID": 3458}
2555	3465	{"_key": 3465, "iconID": 3646, "nameID": 637305, "hasTypes": 1, "parentGroupID": 3458}
2556	3466	{"_key": 3466, "iconID": 3636, "nameID": 637306, "hasTypes": 1, "parentGroupID": 3459}
2557	3467	{"_key": 3467, "iconID": 3631, "nameID": 637307, "hasTypes": 1, "parentGroupID": 3459}
2558	3468	{"_key": 3468, "iconID": 3641, "nameID": 637308, "hasTypes": 1, "parentGroupID": 3459}
2559	3469	{"_key": 3469, "iconID": 3646, "nameID": 637309, "hasTypes": 1, "parentGroupID": 3459}
2560	3470	{"_key": 3470, "iconID": 3636, "nameID": 637310, "hasTypes": 1, "parentGroupID": 3460}
2561	3471	{"_key": 3471, "iconID": 3631, "nameID": 637311, "hasTypes": 1, "parentGroupID": 3460}
2562	3472	{"_key": 3472, "iconID": 3641, "nameID": 637312, "hasTypes": 1, "parentGroupID": 3460}
2563	3473	{"_key": 3473, "iconID": 3646, "nameID": 637313, "hasTypes": 1, "parentGroupID": 3460}
2564	3474	{"_key": 3474, "iconID": 3636, "nameID": 637314, "hasTypes": 1, "parentGroupID": 3461}
2565	3475	{"_key": 3475, "iconID": 3631, "nameID": 637315, "hasTypes": 1, "parentGroupID": 3461}
2566	3476	{"_key": 3476, "iconID": 3641, "nameID": 637316, "hasTypes": 1, "parentGroupID": 3461}
2567	3477	{"_key": 3477, "iconID": 3646, "nameID": 637317, "hasTypes": 1, "parentGroupID": 3461}
2568	3478	{"_key": 3478, "iconID": 24411, "nameID": 638794, "hasTypes": 1, "parentGroupID": 1407}
2569	3480	{"_key": 3480, "iconID": 1443, "nameID": 639178, "hasTypes": 0, "descriptionID": 639179, "parentGroupID": 1372}
2570	3481	{"_key": 3481, "iconID": 1443, "nameID": 639180, "hasTypes": 0, "descriptionID": 639181, "parentGroupID": 3480}
2571	3483	{"_key": 3483, "iconID": 1443, "nameID": 639185, "hasTypes": 1, "descriptionID": 639186, "parentGroupID": 2288}
2572	3484	{"_key": 3484, "iconID": 1443, "nameID": 639191, "hasTypes": 1, "descriptionID": 639192, "parentGroupID": 2288}
2573	3487	{"_key": 3487, "iconID": 15, "nameID": 640808, "hasTypes": 1, "parentGroupID": 54}
2574	3488	{"_key": 3488, "iconID": 15, "nameID": 640809, "hasTypes": 1, "parentGroupID": 54}
2575	3489	{"_key": 3489, "iconID": 15, "nameID": 640810, "hasTypes": 1, "parentGroupID": 54}
2576	3490	{"_key": 3490, "iconID": 15, "nameID": 640811, "hasTypes": 1, "parentGroupID": 54}
2577	3492	{"_key": 3492, "iconID": 1443, "nameID": 643078, "hasTypes": 1, "descriptionID": 643079, "parentGroupID": 1703}
2578	3493	{"_key": 3493, "iconID": 1443, "nameID": 645367, "hasTypes": 1, "descriptionID": 655907, "parentGroupID": 1612}
2579	3495	{"_key": 3495, "iconID": 21420, "nameID": 646076, "hasTypes": 1, "parentGroupID": 2378}
2580	3496	{"_key": 3496, "iconID": 21420, "nameID": 646079, "hasTypes": 0, "parentGroupID": 1989}
2581	3497	{"_key": 3497, "iconID": 21420, "nameID": 646080, "hasTypes": 1, "parentGroupID": 3496}
2582	3498	{"_key": 3498, "iconID": 25580, "nameID": 646876, "hasTypes": 1, "parentGroupID": 977}
2583	3499	{"_key": 3499, "iconID": 25579, "nameID": 646877, "hasTypes": 1, "parentGroupID": 977}
2584	3500	{"_key": 3500, "iconID": 25586, "nameID": 647083, "hasTypes": 1, "parentGroupID": 132}
2585	3502	{"_key": 3502, "iconID": 98, "nameID": 647765, "hasTypes": 1, "parentGroupID": 3121}
2586	3504	{"_key": 3504, "iconID": 21420, "nameID": 656412, "hasTypes": 1, "parentGroupID": 1970}
2587	3505	{"_key": 3505, "iconID": 1443, "nameID": 660966, "hasTypes": 1, "descriptionID": 660967, "parentGroupID": 1089}
2588	3507	{"_key": 3507, "iconID": 1443, "nameID": 661453, "hasTypes": 1, "parentGroupID": 824}
2589	3508	{"_key": 3508, "iconID": 1443, "nameID": 662632, "hasTypes": 0, "descriptionID": 662633, "parentGroupID": 761}
2590	3509	{"_key": 3509, "iconID": 1443, "nameID": 662638, "hasTypes": 0, "descriptionID": 662639, "parentGroupID": 761}
2591	3510	{"_key": 3510, "iconID": 1443, "nameID": 662640, "hasTypes": 0, "descriptionID": 662641, "parentGroupID": 761}
2592	3511	{"_key": 3511, "iconID": 1443, "nameID": 662642, "hasTypes": 0, "descriptionID": 662643, "parentGroupID": 3510}
2593	3512	{"_key": 3512, "iconID": 20959, "nameID": 662644, "hasTypes": 1, "descriptionID": 662645, "parentGroupID": 3511}
2594	3513	{"_key": 3513, "iconID": 20966, "nameID": 662650, "hasTypes": 1, "descriptionID": 662651, "parentGroupID": 3511}
2595	3514	{"_key": 3514, "iconID": 20968, "nameID": 662648, "hasTypes": 1, "descriptionID": 662649, "parentGroupID": 3511}
2596	3515	{"_key": 3515, "iconID": 20967, "nameID": 662646, "hasTypes": 1, "descriptionID": 662647, "parentGroupID": 3511}
2597	3516	{"_key": 3516, "iconID": 25566, "nameID": 662667, "hasTypes": 0, "parentGroupID": 2203}
2598	3517	{"_key": 3517, "iconID": 25627, "nameID": 662993, "hasTypes": 1, "descriptionID": 662994}
2599	3519	{"_key": 3519, "iconID": 21420, "nameID": 663107, "hasTypes": 0, "parentGroupID": 1971}
2600	3520	{"_key": 3520, "iconID": 21420, "nameID": 663108, "hasTypes": 0, "parentGroupID": 3519}
2601	3521	{"_key": 3521, "iconID": 20967, "nameID": 663109, "hasTypes": 1, "parentGroupID": 3520}
2602	3523	{"_key": 3523, "iconID": 20968, "nameID": 663285, "hasTypes": 1, "parentGroupID": 3520}
2603	3524	{"_key": 3524, "iconID": 1443, "nameID": 663744, "hasTypes": 0, "parentGroupID": 2871}
2604	3525	{"_key": 3525, "iconID": 1443, "nameID": 663745, "hasTypes": 1, "parentGroupID": 3524}
2605	3526	{"_key": 3526, "iconID": 1443, "nameID": 663750, "hasTypes": 1, "parentGroupID": 2974}
2606	3528	{"_key": 3528, "iconID": 1443, "nameID": 664816, "hasTypes": 1, "parentGroupID": 2125}
2607	3529	{"_key": 3529, "iconID": 1443, "nameID": 664817, "hasTypes": 1, "parentGroupID": 2881}
2608	3530	{"_key": 3530, "iconID": 1443, "nameID": 664822, "hasTypes": 1, "parentGroupID": 3038}
2609	3531	{"_key": 3531, "iconID": 1443, "nameID": 664855, "hasTypes": 1, "descriptionID": 664856, "parentGroupID": 3480}
2610	3534	{"_key": 3534, "iconID": 1443, "nameID": 664931, "hasTypes": 1, "parentGroupID": 1703}
2611	3535	{"_key": 3535, "iconID": 20959, "nameID": 665110, "hasTypes": 1, "parentGroupID": 3520}
2612	3536	{"_key": 3536, "iconID": 24419, "nameID": 666334, "hasTypes": 1, "descriptionID": 666339, "parentGroupID": 1362}
2613	3537	{"_key": 3537, "iconID": 24419, "nameID": 666335, "hasTypes": 1, "descriptionID": 666337, "parentGroupID": 1369}
2614	3538	{"_key": 3538, "iconID": 24419, "nameID": 666336, "hasTypes": 1, "descriptionID": 666338, "parentGroupID": 1378}
2615	3539	{"_key": 3539, "iconID": 21420, "nameID": 666340, "hasTypes": 1, "parentGroupID": 1961}
2616	3540	{"_key": 3540, "iconID": 21420, "nameID": 666341, "hasTypes": 1, "parentGroupID": 2029}
2617	3541	{"_key": 3541, "iconID": 21420, "nameID": 666342, "hasTypes": 1, "parentGroupID": 1999}
2618	3542	{"_key": 3542, "nameID": 666375, "hasTypes": 1, "parentGroupID": 2512}
2619	3543	{"_key": 3543, "iconID": 21420, "nameID": 666651, "hasTypes": 1, "parentGroupID": 2141}
2620	3544	{"_key": 3544, "iconID": 21420, "nameID": 666652, "hasTypes": 1, "parentGroupID": 2102}
2621	3545	{"_key": 3545, "iconID": 1443, "nameID": 666687, "hasTypes": 1, "descriptionID": 666688, "parentGroupID": 1612}
2622	3546	{"_key": 3546, "iconID": 20966, "nameID": 666925, "hasTypes": 1, "parentGroupID": 3520}
2623	3547	{"_key": 3547, "iconID": 21420, "nameID": 667126, "hasTypes": 1, "descriptionID": 667127}
2624	3548	{"_key": 3548, "iconID": 21420, "nameID": 681124, "hasTypes": 0, "parentGroupID": 1998}
2625	3549	{"_key": 3549, "iconID": 21420, "nameID": 681138, "hasTypes": 1, "parentGroupID": 3548}
2626	3562	{"_key": 3562, "iconID": 1443, "nameID": 696355, "hasTypes": 1, "parentGroupID": 437}
2627	3563	{"_key": 3563, "iconID": 1443, "nameID": 696356, "hasTypes": 0, "parentGroupID": 3031}
2628	3564	{"_key": 3564, "iconID": 1443, "nameID": 696357, "hasTypes": 1, "parentGroupID": 823}
2629	3565	{"_key": 3565, "iconID": 21420, "nameID": 696358, "hasTypes": 1, "parentGroupID": 2068}
2630	3566	{"_key": 3566, "iconID": 1443, "nameID": 696359, "hasTypes": 1, "parentGroupID": 3006}
2631	3567	{"_key": 3567, "iconID": 21420, "nameID": 697888, "hasTypes": 1, "parentGroupID": 2100}
2632	3568	{"_key": 3568, "iconID": 21420, "nameID": 697889, "hasTypes": 1, "parentGroupID": 3496}
2633	3573	{"_key": 3573, "iconID": 1443, "nameID": 698473, "hasTypes": 1, "parentGroupID": 2932}
2634	3574	{"_key": 3574, "iconID": 21420, "nameID": 707010, "hasTypes": 1, "parentGroupID": 1954}
2635	3576	{"_key": 3576, "iconID": 1443, "nameID": 708880, "hasTypes": 1, "descriptionID": 708881, "parentGroupID": 1612}
2636	3577	{"_key": 3577, "iconID": 1443, "nameID": 709085, "hasTypes": 1, "descriptionID": 709086, "parentGroupID": 8}
2637	3578	{"_key": 3578, "iconID": 1443, "nameID": 709087, "hasTypes": 1, "descriptionID": 709088, "parentGroupID": 629}
2638	3579	{"_key": 3579, "iconID": 2703, "nameID": 709090, "hasTypes": 1, "descriptionID": 709091, "parentGroupID": 208}
2639	3580	{"_key": 3580, "iconID": 1443, "nameID": 709119, "hasTypes": 1, "descriptionID": 709120, "parentGroupID": 766}
2640	3591	{"_key": 3591, "iconID": 2703, "nameID": 709173, "hasTypes": 1, "descriptionID": 709174, "parentGroupID": 787}
2641	3593	{"_key": 3593, "iconID": 2703, "nameID": 709212, "hasTypes": 1, "descriptionID": 709213, "parentGroupID": 1591}
2642	3594	{"_key": 3594, "iconID": 1443, "nameID": 709214, "hasTypes": 1, "parentGroupID": 65}
2643	3596	{"_key": 3596, "iconID": 24296, "nameID": 709445, "hasTypes": 1, "descriptionID": 709446, "parentGroupID": 533}
2644	3618	{"_key": 3618, "iconID": 25607, "nameID": 710127, "hasTypes": 1, "parentGroupID": 2831}
2645	3624	{"_key": 3624, "iconID": 2222, "nameID": 711241, "hasTypes": 0, "parentGroupID": 477}
2646	3625	{"_key": 3625, "iconID": 2222, "nameID": 711243, "hasTypes": 1, "parentGroupID": 3624}
2647	3626	{"_key": 3626, "iconID": 2703, "nameID": 711244, "hasTypes": 0, "parentGroupID": 1338}
2648	3627	{"_key": 3627, "iconID": 2703, "nameID": 711245, "hasTypes": 1, "parentGroupID": 3626}
2649	3628	{"_key": 3628, "iconID": 26056, "nameID": 711749, "hasTypes": 0, "descriptionID": 711750}
2650	3629	{"_key": 3629, "iconID": 26055, "nameID": 711751, "hasTypes": 1, "parentGroupID": 3628}
2651	3630	{"_key": 3630, "iconID": 26056, "nameID": 711752, "hasTypes": 0, "parentGroupID": 3628}
2652	3631	{"_key": 3631, "iconID": 26053, "nameID": 711753, "hasTypes": 0, "parentGroupID": 3630}
2653	3632	{"_key": 3632, "iconID": 26052, "nameID": 711754, "hasTypes": 1, "parentGroupID": 3630}
2654	3633	{"_key": 3633, "iconID": 26054, "nameID": 711755, "hasTypes": 1, "parentGroupID": 3630}
2655	3636	{"_key": 3636, "iconID": 1377, "nameID": 712219, "hasTypes": 1, "descriptionID": 712220, "parentGroupID": 54}
2656	3637	{"_key": 3637, "iconID": 1269, "nameID": 712221, "hasTypes": 1, "descriptionID": 712222, "parentGroupID": 54}
2657	3638	{"_key": 3638, "iconID": 1277, "nameID": 712225, "hasTypes": 1, "descriptionID": 712226, "parentGroupID": 54}
2658	3639	{"_key": 3639, "iconID": 1274, "nameID": 712227, "hasTypes": 1, "descriptionID": 712228, "parentGroupID": 54}
2659	3640	{"_key": 3640, "iconID": 1271, "nameID": 712229, "hasTypes": 1, "descriptionID": 712230, "parentGroupID": 54}
2660	3641	{"_key": 3641, "iconID": 2888, "nameID": 720384, "hasTypes": 1, "descriptionID": 720385, "parentGroupID": 1897}
2661	3642	{"_key": 3642, "iconID": 2888, "nameID": 720386, "hasTypes": 1, "descriptionID": 720387, "parentGroupID": 1897}
2662	3643	{"_key": 3643, "iconID": 2888, "nameID": 720388, "hasTypes": 1, "descriptionID": 720389, "parentGroupID": 1897}
2663	3651	{"_key": 3651, "iconID": 2703, "nameID": 722540, "hasTypes": 1, "descriptionID": 722541, "parentGroupID": 2015}
2664	3653	{"_key": 3653, "iconID": 26053, "nameID": 723578, "hasTypes": 1, "parentGroupID": 3631}
2665	3654	{"_key": 3654, "iconID": 26053, "nameID": 723579, "hasTypes": 1, "parentGroupID": 3631}
2666	3655	{"_key": 3655, "iconID": 26053, "nameID": 723580, "hasTypes": 1, "parentGroupID": 3631}
2667	3656	{"_key": 3656, "iconID": 33, "nameID": 723623, "hasTypes": 1, "parentGroupID": 150}
2668	3657	{"_key": 3657, "iconID": 26249, "nameID": 724387, "hasTypes": 0, "descriptionID": 724388, "parentGroupID": 1111}
2669	3658	{"_key": 3658, "iconID": 26249, "nameID": 724389, "hasTypes": 1, "descriptionID": 724390, "parentGroupID": 3657}
2670	3659	{"_key": 3659, "iconID": 26249, "nameID": 724447, "hasTypes": 1, "descriptionID": 724448, "parentGroupID": 3657}
2671	3660	{"_key": 3660, "iconID": 26249, "nameID": 724449, "hasTypes": 1, "descriptionID": 724450, "parentGroupID": 3657}
2672	3661	{"_key": 3661, "iconID": 26249, "nameID": 724451, "hasTypes": 1, "descriptionID": 724452, "parentGroupID": 3657}
2673	3662	{"_key": 3662, "iconID": 26249, "nameID": 724507, "hasTypes": 0, "parentGroupID": 3102}
2674	3663	{"_key": 3663, "iconID": 26249, "nameID": 724508, "hasTypes": 0, "parentGroupID": 3662}
2675	3664	{"_key": 3664, "iconID": 26249, "nameID": 724509, "hasTypes": 0, "parentGroupID": 3662}
2676	3665	{"_key": 3665, "iconID": 26249, "nameID": 724510, "hasTypes": 0, "parentGroupID": 3662}
2677	3666	{"_key": 3666, "iconID": 26249, "nameID": 724511, "hasTypes": 0, "parentGroupID": 3662}
2678	3667	{"_key": 3667, "iconID": 24129, "nameID": 725015, "hasTypes": 0, "descriptionID": 725016, "parentGroupID": 2436}
2679	3668	{"_key": 3668, "nameID": 725017, "hasTypes": 1, "descriptionID": 725018, "parentGroupID": 3667}
2680	3669	{"_key": 3669, "nameID": 725019, "hasTypes": 1, "descriptionID": 725020, "parentGroupID": 3667}
2681	3670	{"_key": 3670, "nameID": 725021, "hasTypes": 1, "descriptionID": 725022, "parentGroupID": 3667}
2682	3671	{"_key": 3671, "iconID": 3335, "nameID": 725473, "hasTypes": 1, "descriptionID": 725474, "parentGroupID": 1897}
2683	3672	{"_key": 3672, "iconID": 1443, "nameID": 725696, "hasTypes": 1, "descriptionID": 725697, "parentGroupID": 2085}
2684	3673	{"_key": 3673, "iconID": 1443, "nameID": 725698, "hasTypes": 1, "descriptionID": 725699, "parentGroupID": 2087}
2685	3677	{"_key": 3677, "iconID": 1443, "nameID": 726857, "hasTypes": 1, "parentGroupID": 2938}
2686	3678	{"_key": 3678, "iconID": 1443, "nameID": 726858, "hasTypes": 1, "parentGroupID": 2859}
2687	3679	{"_key": 3679, "iconID": 2040, "nameID": 727066, "hasTypes": 1, "parentGroupID": 739}
2688	3680	{"_key": 3680, "iconID": 16, "nameID": 727375, "hasTypes": 1, "parentGroupID": 404}
2689	3681	{"_key": 3681, "iconID": 2703, "nameID": 727378, "hasTypes": 1, "parentGroupID": 406}
2690	3696	{"_key": 3696, "iconID": 24296, "nameID": 731186, "hasTypes": 1, "descriptionID": 731185, "parentGroupID": 533}
2691	3697	{"_key": 3697, "iconID": 26356, "nameID": 862997, "hasTypes": 1, "parentGroupID": 533}
2692	3719	{"_key": 3719, "iconID": 24905, "nameID": 871028, "hasTypes": 0, "parentGroupID": 2436}
2693	3720	{"_key": 3720, "iconID": 24905, "nameID": 871029, "hasTypes": 1, "parentGroupID": 3719}
2694	3721	{"_key": 3721, "iconID": 24905, "nameID": 871030, "hasTypes": 1, "parentGroupID": 3719}
2695	3722	{"_key": 3722, "iconID": 24905, "nameID": 871031, "hasTypes": 1, "parentGroupID": 3719}
2696	3723	{"_key": 3723, "iconID": 24905, "nameID": 871033, "hasTypes": 1, "parentGroupID": 3719}
2697	3724	{"_key": 3724, "iconID": 24905, "nameID": 871034, "hasTypes": 1, "parentGroupID": 3719}
2698	3725	{"_key": 3725, "iconID": 26372, "nameID": 871476, "hasTypes": 1, "descriptionID": 871477, "parentGroupID": 11}
2699	3726	{"_key": 3726, "iconID": 26396, "nameID": 871478, "hasTypes": 1, "descriptionID": 871479, "parentGroupID": 10}
2700	3727	{"_key": 3727, "iconID": 26572, "nameID": 871902, "hasTypes": 1, "parentGroupID": 2490}
2701	3728	{"_key": 3728, "iconID": 26570, "nameID": 871903, "hasTypes": 1, "parentGroupID": 2490}
2702	3730	{"_key": 3730, "iconID": 26562, "nameID": 1005040, "hasTypes": 1, "parentGroupID": 533}
2703	3731	{"_key": 3731, "iconID": 21420, "nameID": 1005127, "hasTypes": 1, "parentGroupID": 2277}
2704	3732	{"_key": 3732, "iconID": 2038, "nameID": 1005132, "hasTypes": 1, "parentGroupID": 19}
2705	3733	{"_key": 3733, "iconID": 26395, "nameID": 1008262, "hasTypes": 1, "parentGroupID": 3119}
2706	3734	{"_key": 3734, "iconID": 2325, "nameID": 1008793, "hasTypes": 1, "descriptionID": 1008794, "parentGroupID": 614}
2707	3736	{"_key": 3736, "iconID": 3948, "nameID": 1009944, "hasTypes": 1, "parentGroupID": 1276}
2708	3737	{"_key": 3737, "iconID": 3755, "nameID": 1010660, "hasTypes": 1, "descriptionID": 1010661, "parentGroupID": 19}
2709	3738	{"_key": 3738, "iconID": 2703, "nameID": 1010922, "hasTypes": 1, "descriptionID": 1010923, "parentGroupID": 2015}
2710	3739	{"_key": 3739, "iconID": 3953, "nameID": 1010986, "hasTypes": 1, "parentGroupID": 1276}
2711	3740	{"_key": 3740, "iconID": 2703, "nameID": 1011224, "hasTypes": 1, "parentGroupID": 2015}
2712	3741	{"_key": 3741, "iconID": 26779, "nameID": 1011232, "hasTypes": 1, "descriptionID": 1011233, "parentGroupID": 1276}
2713	3742	{"_key": 3742, "iconID": 2703, "nameID": 1011343, "hasTypes": 1, "descriptionID": 1011344, "parentGroupID": 2015}
2714	3743	{"_key": 3743, "iconID": 26785, "nameID": 1011366, "hasTypes": 1, "descriptionID": 1011365, "parentGroupID": 54}
2715	3744	{"_key": 3744, "iconID": 24135, "nameID": 1011411, "hasTypes": 1, "descriptionID": 1011412, "parentGroupID": 1080}
2716	3745	{"_key": 3745, "iconID": 26799, "nameID": 1011898, "hasTypes": 1, "descriptionID": 1011900, "parentGroupID": 1922}
2717	3746	{"_key": 3746, "iconID": 1443, "nameID": 1014781, "hasTypes": 1, "parentGroupID": 1972}
2718	3753	{"_key": 3753, "iconID": 2703, "nameID": 1016687, "hasTypes": 1, "descriptionID": 1016688, "parentGroupID": 1041}
2719	3754	{"_key": 3754, "iconID": 2703, "nameID": 1017345, "hasTypes": 1, "descriptionID": 1017346, "parentGroupID": 582}
2720	3755	{"_key": 3755, "iconID": 27058, "nameID": 1017347, "hasTypes": 1, "descriptionID": 1017348, "parentGroupID": 464}
2721	3756	{"_key": 3756, "iconID": 20970, "nameID": 1017852, "hasTypes": 1, "descriptionID": 1017851, "parentGroupID": 2297}
2722	3757	{"_key": 3757, "iconID": 2703, "nameID": 1017925, "hasTypes": 1, "descriptionID": 1017926, "parentGroupID": 2290}
2723	3758	{"_key": 3758, "iconID": 27083, "nameID": 1017935, "hasTypes": 1, "parentGroupID": 14}
2724	3759	{"_key": 3759, "iconID": 1443, "nameID": 1017936, "hasTypes": 0, "parentGroupID": 1374}
2725	3761	{"_key": 3761, "iconID": 2703, "nameID": 1017952, "hasTypes": 1, "parentGroupID": 214}
2726	3762	{"_key": 3762, "iconID": 1546, "nameID": 1017957, "hasTypes": 1, "descriptionID": 1017958, "parentGroupID": 3759}
2727	3764	{"_key": 3764, "iconID": 27058, "nameID": 1018060, "hasTypes": 1, "parentGroupID": 2125}
2728	3765	{"_key": 3765, "iconID": 20959, "nameID": 1018095, "hasTypes": 1, "parentGroupID": 3481}
2729	3766	{"_key": 3766, "iconID": 20966, "nameID": 1018096, "hasTypes": 1, "parentGroupID": 3481}
2730	3767	{"_key": 3767, "iconID": 20967, "nameID": 1018097, "hasTypes": 1, "parentGroupID": 3481}
2731	3768	{"_key": 3768, "iconID": 20968, "nameID": 1018098, "hasTypes": 1, "parentGroupID": 3481}
2732	3769	{"_key": 3769, "iconID": 27058, "nameID": 1018099, "hasTypes": 1, "parentGroupID": 3481}
2733	3770	{"_key": 3770, "iconID": 20959, "nameID": 1018101, "hasTypes": 1, "parentGroupID": 1366}
2734	3771	{"_key": 3771, "iconID": 20966, "nameID": 1018102, "hasTypes": 1, "parentGroupID": 1366}
2735	3772	{"_key": 3772, "iconID": 20967, "nameID": 1018103, "hasTypes": 1, "parentGroupID": 1366}
2736	3773	{"_key": 3773, "iconID": 20968, "nameID": 1018104, "hasTypes": 1, "parentGroupID": 1366}
2737	3774	{"_key": 3774, "iconID": 27058, "nameID": 1018100, "hasTypes": 1, "parentGroupID": 1366}
2738	3775	{"_key": 3775, "iconID": 27083, "nameID": 1018270, "hasTypes": 1, "parentGroupID": 3083}
2739	3776	{"_key": 3776, "iconID": 27139, "nameID": 1019024, "hasTypes": 1, "descriptionID": 1019023, "parentGroupID": 54}
2740	3779	{"_key": 3779, "iconID": 2703, "nameID": 1019311, "hasTypes": 1, "descriptionID": 1019312, "parentGroupID": 406}
2741	3780	{"_key": 3780, "iconID": 24135, "nameID": 1019400, "hasTypes": 1, "parentGroupID": 3063}
2742	3781	{"_key": 3781, "iconID": 16, "nameID": 1019441, "hasTypes": 1, "parentGroupID": 404}
2743	3782	{"_key": 3782, "iconID": 21783, "nameID": 1019607, "hasTypes": 1, "parentGroupID": 1849}
2744	3784	{"_key": 3784, "iconID": 1277, "nameID": 1019620, "hasTypes": 1, "parentGroupID": 1031}
2745	3786	{"_key": 3786, "iconID": 27212, "nameID": 1021608, "hasTypes": 0, "parentGroupID": 2436}
2746	3790	{"_key": 3790, "iconID": 27212, "nameID": 1021663, "hasTypes": 1, "parentGroupID": 3786}
2747	3792	{"_key": 3792, "iconID": 27215, "nameID": 1021665, "hasTypes": 1, "parentGroupID": 3786}
2748	3794	{"_key": 3794, "iconID": 21420, "nameID": 1021707, "hasTypes": 1, "descriptionID": 1021708, "parentGroupID": 2023}
2749	3795	{"_key": 3795, "iconID": 27208, "nameID": 1021797, "hasTypes": 1, "parentGroupID": 3786}
2750	3796	{"_key": 3796, "iconID": 26562, "nameID": 1021815, "hasTypes": 1, "parentGroupID": 533}
2751	3797	{"_key": 3797, "iconID": 27205, "nameID": 1021870, "hasTypes": 1, "parentGroupID": 3786}
2752	3798	{"_key": 3798, "iconID": 27201, "nameID": 1021883, "hasTypes": 1, "parentGroupID": 3786}
2753	3799	{"_key": 3799, "iconID": 27198, "nameID": 1022024, "hasTypes": 1, "parentGroupID": 3786}
2754	3800	{"_key": 3800, "iconID": 24905, "nameID": 1022077, "hasTypes": 1, "parentGroupID": 3719}
2755	3801	{"_key": 3801, "iconID": 24968, "nameID": 1022850, "hasTypes": 1, "descriptionID": 1022851, "parentGroupID": 2804}
2756	3802	{"_key": 3802, "iconID": 24973, "nameID": 1022852, "hasTypes": 1, "descriptionID": 1022853, "parentGroupID": 2804}
2757	3803	{"_key": 3803, "iconID": 24971, "nameID": 1022854, "hasTypes": 1, "descriptionID": 1022855, "parentGroupID": 2804}
2758	3804	{"_key": 3804, "iconID": 24972, "nameID": 1022856, "hasTypes": 1, "descriptionID": 1022857, "parentGroupID": 2804}
2759	3805	{"_key": 3805, "iconID": 24969, "nameID": 1022858, "hasTypes": 1, "descriptionID": 1022859, "parentGroupID": 2804}
2760	3806	{"_key": 3806, "iconID": 24970, "nameID": 1022860, "hasTypes": 1, "descriptionID": 1022861, "parentGroupID": 2804}
2761	3807	{"_key": 3807, "iconID": 27218, "nameID": 1022862, "hasTypes": 1, "descriptionID": 1022863, "parentGroupID": 2804}
2762	3808	{"_key": 3808, "iconID": 25027, "nameID": 1022864, "hasTypes": 1, "descriptionID": 1022865, "parentGroupID": 2805}
2763	3809	{"_key": 3809, "iconID": 25021, "nameID": 1022868, "hasTypes": 1, "descriptionID": 1022869, "parentGroupID": 2805}
2764	3810	{"_key": 3810, "iconID": 25033, "nameID": 1022870, "hasTypes": 1, "descriptionID": 1022871, "parentGroupID": 2805}
2765	3811	{"_key": 3811, "iconID": 25039, "nameID": 1022872, "hasTypes": 1, "descriptionID": 1022873, "parentGroupID": 2805}
2766	3812	{"_key": 3812, "iconID": 25045, "nameID": 1022874, "hasTypes": 1, "descriptionID": 1022875, "parentGroupID": 2805}
2767	3813	{"_key": 3813, "iconID": 27058, "nameID": 1030380, "hasTypes": 1, "parentGroupID": 2035}
2768	3818	{"_key": 3818, "iconID": 27058, "nameID": 1030384, "hasTypes": 1, "parentGroupID": 2141}
2769	3831	{"_key": 3831, "iconID": 26518, "nameID": 1032623, "hasTypes": 1, "parentGroupID": 1661}
2770	3832	{"_key": 3832, "iconID": 22082, "nameID": 1032624, "hasTypes": 1, "parentGroupID": 1661}
2771	3833	{"_key": 3833, "iconID": 1660, "nameID": 1032625, "hasTypes": 1, "parentGroupID": 1661}
2772	3834	{"_key": 3834, "iconID": 21898, "nameID": 1032626, "hasTypes": 0, "parentGroupID": 1661}
2773	3835	{"_key": 3835, "iconID": 21060, "nameID": 1032627, "hasTypes": 1, "parentGroupID": 1661}
2774	3836	{"_key": 3836, "iconID": 21900, "nameID": 1032628, "hasTypes": 1, "parentGroupID": 3834}
2775	3837	{"_key": 3837, "iconID": 21902, "nameID": 1032629, "hasTypes": 1, "parentGroupID": 3834}
2776	3838	{"_key": 3838, "iconID": 21725, "nameID": 1032630, "hasTypes": 1, "parentGroupID": 3834}
2777	3839	{"_key": 3839, "iconID": 21901, "nameID": 1032631, "hasTypes": 1, "parentGroupID": 3834}
2778	3840	{"_key": 3840, "iconID": 24281, "nameID": 1032632, "hasTypes": 1, "parentGroupID": 3834}
2779	3841	{"_key": 3841, "iconID": 21899, "nameID": 1032633, "hasTypes": 1, "parentGroupID": 3834}
2780	3842	{"_key": 3842, "iconID": 1443, "nameID": 1034113, "hasTypes": 1, "parentGroupID": 3524}
2781	3844	{"_key": 3844, "iconID": 1443, "nameID": 1034266, "hasTypes": 1, "parentGroupID": 3000}
2782	3845	{"_key": 3845, "iconID": 21832, "nameID": 1035664, "hasTypes": 1, "parentGroupID": 3834}
2783	3846	{"_key": 3846, "iconID": 27345, "nameID": 1037311, "hasTypes": 1, "parentGroupID": 1396}
2784	3848	{"_key": 3848, "iconID": 27347, "nameID": 1038276, "hasTypes": 1, "parentGroupID": 19}
2785	3849	{"_key": 3849, "iconID": 21823, "nameID": 1038277, "hasTypes": 1, "parentGroupID": 54}
2786	3851	{"_key": 3851, "iconID": 21920, "nameID": 1040825, "hasTypes": 1, "parentGroupID": 2464}
2787	3853	{"_key": 3853, "iconID": 1443, "nameID": 1043821, "hasTypes": 0, "parentGroupID": 1381}
2788	3856	{"_key": 3856, "iconID": 20959, "nameID": 1043825, "hasTypes": 1, "parentGroupID": 3853}
2789	3859	{"_key": 3859, "iconID": 20966, "nameID": 1043828, "hasTypes": 1, "parentGroupID": 3853}
2790	3861	{"_key": 3861, "iconID": 20967, "nameID": 1043830, "hasTypes": 1, "parentGroupID": 3853}
2791	3863	{"_key": 3863, "iconID": 20968, "nameID": 1043832, "hasTypes": 1, "parentGroupID": 3853}
2792	3864	{"_key": 3864, "iconID": 24819, "nameID": 1048151, "hasTypes": 1, "parentGroupID": 3834}
2793	3869	{"_key": 3869, "iconID": 21420, "nameID": 1048457, "hasTypes": 0, "parentGroupID": 1970}
2794	3871	{"_key": 3871, "iconID": 21420, "nameID": 1048459, "hasTypes": 0, "parentGroupID": 3869}
2795	3873	{"_key": 3873, "iconID": 20968, "nameID": 1048461, "hasTypes": 1, "parentGroupID": 3871}
2796	3886	{"_key": 3886, "iconID": 16, "nameID": 1054686, "hasTypes": 1, "parentGroupID": 404}
2797	30001	{"_key": 30001, "iconID": 25196, "nameID": 596551, "hasTypes": 1, "descriptionID": 596552, "parentGroupID": 5}
2798	30002	{"_key": 30002, "iconID": 25196, "nameID": 596553, "hasTypes": 1, "descriptionID": 596554, "parentGroupID": 6}
\.


--
-- Name: marketgroups marketgroups_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.marketgroups
    ADD CONSTRAINT marketgroups_pkey PRIMARY KEY (row_no);


--
-- Name: marketgroups_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX marketgroups_key_idx ON sde_native.marketgroups USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict nJaXDBG2PrALi4VwwVNkhzTFPXcpbtLROvQ49ujAn9vhEe4agAsv1LWAxKnNOMM

