--
-- PostgreSQL database dump
--

\restrict P1jFfpKeQZLotRUC3hFuDALwLR6Po51X7Df5AVN1LbeHUEmXXaZZ2AEktAkg8kF

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dogmaunits; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.dogmaunits (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: dogmaunits; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.dogmaunits (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "name": "Length", "descriptionID": 77965, "displayNameID": 78005}
1	2	{"_key": 2, "name": "Mass", "descriptionID": 77966, "displayNameID": 78006}
2	3	{"_key": 3, "name": "Time", "descriptionID": 77967, "displayNameID": 78007}
3	4	{"_key": 4, "name": "Electric Current", "descriptionID": 77968, "displayNameID": 78008}
4	5	{"_key": 5, "name": "Temperature", "descriptionID": 77969, "displayNameID": 78009}
5	6	{"_key": 6, "name": "Amount Of Substance", "descriptionID": 77970, "displayNameID": 78010}
6	7	{"_key": 7, "name": "Luminous Intensity", "descriptionID": 77971, "displayNameID": 78011}
7	8	{"_key": 8, "name": "Area", "descriptionID": 77972, "displayNameID": 78012}
8	9	{"_key": 9, "name": "Volume", "descriptionID": 77973, "displayNameID": 78013}
9	10	{"_key": 10, "name": "Speed", "descriptionID": 77974, "displayNameID": 78014}
10	11	{"_key": 11, "name": "Acceleration", "descriptionID": 77975, "displayNameID": 78015}
11	12	{"_key": 12, "name": "Wave Number", "descriptionID": 77976, "displayNameID": 78016}
12	13	{"_key": 13, "name": "Mass Density", "descriptionID": 77977, "displayNameID": 78017}
13	14	{"_key": 14, "name": "Specific Volume", "descriptionID": 77978, "displayNameID": 78018}
14	15	{"_key": 15, "name": "Current Density", "descriptionID": 77979, "displayNameID": 78019}
15	16	{"_key": 16, "name": "Magnetic Field Strength", "descriptionID": 77980, "displayNameID": 78020}
16	17	{"_key": 17, "name": "Amount-Of-Substance Concentration", "descriptionID": 77981, "displayNameID": 78021}
17	18	{"_key": 18, "name": "Luminance", "descriptionID": 77982, "displayNameID": 78022}
18	19	{"_key": 19, "name": "Mass Fraction", "descriptionID": 77983, "displayNameID": 78023}
19	101	{"_key": 101, "name": "Milliseconds", "displayNameID": 78024}
20	102	{"_key": 102, "name": "Millimeters", "displayNameID": 78025}
21	103	{"_key": 103, "name": "MegaPascals"}
22	104	{"_key": 104, "name": "Multiplier", "descriptionID": 77984, "displayNameID": 78026}
23	105	{"_key": 105, "name": "Percentage", "displayNameID": 78027}
24	106	{"_key": 106, "name": "Teraflops", "displayNameID": 78028}
25	107	{"_key": 107, "name": "MegaWatts", "displayNameID": 78029}
26	108	{"_key": 108, "name": "Inverse Absolute Percent", "descriptionID": 77985, "displayNameID": 78030}
27	109	{"_key": 109, "name": "Modifier Percent", "descriptionID": 77986, "displayNameID": 78031}
28	111	{"_key": 111, "name": "Inversed Modifier Percent", "descriptionID": 77987, "displayNameID": 78032}
29	112	{"_key": 112, "name": "Radians/Second", "descriptionID": 77988, "displayNameID": 78033}
30	113	{"_key": 113, "name": "Hitpoints", "displayNameID": 78034}
31	114	{"_key": 114, "name": "capacitor units", "descriptionID": 77989, "displayNameID": 78035}
32	115	{"_key": 115, "name": "groupID", "displayNameID": 78036}
33	116	{"_key": 116, "name": "typeID", "displayNameID": 78037}
34	117	{"_key": 117, "name": "Sizeclass", "descriptionID": 318074, "displayNameID": 78038}
35	118	{"_key": 118, "name": "Ore units", "displayNameID": 78039}
36	119	{"_key": 119, "name": "attributeID", "displayNameID": 78040}
37	120	{"_key": 120, "name": "attributePoints", "displayNameID": 78041}
38	121	{"_key": 121, "name": "realPercent", "descriptionID": 77990, "displayNameID": 78042}
39	122	{"_key": 122, "name": "Fitting slots"}
40	123	{"_key": 123, "name": "trueTime", "descriptionID": 77991, "displayNameID": 78043}
41	124	{"_key": 124, "name": "Modifier Relative Percent", "descriptionID": 77992, "displayNameID": 78044}
42	125	{"_key": 125, "name": "Newton", "displayNameID": 78045}
43	126	{"_key": 126, "name": "Light Year", "displayNameID": 78046}
44	127	{"_key": 127, "name": "Absolute Percent", "descriptionID": 77993, "displayNameID": 78047}
45	128	{"_key": 128, "name": "Drone bandwidth", "descriptionID": 77994, "displayNameID": 78048}
46	129	{"_key": 129, "name": "Hours", "descriptionID": 77995}
47	133	{"_key": 133, "name": "Money", "descriptionID": 77996, "displayNameID": 78049}
48	134	{"_key": 134, "name": "Logistical Capacity", "descriptionID": 77997, "displayNameID": 78050}
49	135	{"_key": 135, "name": "Astronomical Unit", "descriptionID": 77998, "displayNameID": 78051}
50	136	{"_key": 136, "name": "Slot", "descriptionID": 77999, "displayNameID": 78052}
51	137	{"_key": 137, "name": "Boolean", "descriptionID": 78000, "displayNameID": 78053}
52	138	{"_key": 138, "name": "Units", "descriptionID": 78001, "displayNameID": 78054}
53	139	{"_key": 139, "name": "Bonus", "descriptionID": 78002, "displayNameID": 78055}
54	140	{"_key": 140, "name": "Level", "descriptionID": 78003, "displayNameID": 78056}
55	141	{"_key": 141, "name": "Hardpoints", "descriptionID": 78004, "displayNameID": 78057}
56	142	{"_key": 142, "name": "Sex", "displayNameID": 78058}
57	143	{"_key": 143, "name": "Datetime", "descriptionID": 312106}
58	144	{"_key": 144, "name": "Warp speed", "descriptionID": 561538, "displayNameID": 561537}
59	205	{"_key": 205, "name": "modifier realPercent", "descriptionID": 592242, "displayNameID": 592243}
\.


--
-- Name: dogmaunits dogmaunits_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.dogmaunits
    ADD CONSTRAINT dogmaunits_pkey PRIMARY KEY (row_no);


--
-- Name: dogmaunits_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX dogmaunits_key_idx ON sde_native.dogmaunits USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict P1jFfpKeQZLotRUC3hFuDALwLR6Po51X7Df5AVN1LbeHUEmXXaZZ2AEktAkg8kF

