--
-- PostgreSQL database dump
--

\restrict ied2lU9Dci1uMydqKWpQN1SY55K79vceFpuXAjZtJwLe3YbNxcn6dJvuCx15K56

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accountingkeys; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.accountingkeys (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: accountingkeys; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.accountingkeys (row_no, key, data) FROM stdin;
0	1000	{"_key": 1000, "keyName": "cash", "keyType": "A", "currency": "ISK", "keyNameID": 59917}
1	1001	{"_key": 1001, "keyName": "cash2", "keyType": "A", "currency": "ISK", "keyNameID": 59918}
2	1002	{"_key": 1002, "keyName": "cash3", "keyType": "A", "currency": "ISK", "keyNameID": 59919}
3	1003	{"_key": 1003, "keyName": "cash4", "keyType": "A", "currency": "ISK", "keyNameID": 59920}
4	1004	{"_key": 1004, "keyName": "cash5", "keyType": "A", "currency": "ISK", "keyNameID": 59921}
5	1005	{"_key": 1005, "keyName": "cash6", "keyType": "A", "currency": "ISK", "keyNameID": 59922}
6	1006	{"_key": 1006, "keyName": "cash7", "keyType": "A", "currency": "ISK", "keyNameID": 59923}
7	1099	{"_key": 1099, "keyName": "cashFrozen", "keyType": "A", "currency": "ISK", "description": "A key inaccessible by the character, where cash is stored when put up for sale with an RMT system."}
8	1200	{"_key": 1200, "keyName": "AURUM", "keyType": "A", "currency": "AUR", "keyNameID": 59925, "description": "EVE - AURUM Account"}
9	1201	{"_key": 1201, "keyName": "AURUM2", "keyType": "A", "currency": "AUR", "keyNameID": 59926, "description": "EVE - AURUM2 Account"}
10	1202	{"_key": 1202, "keyName": "AURUM3", "keyType": "A", "currency": "AUR", "keyNameID": 59927, "description": "EVE - AURUM3 Account"}
11	1203	{"_key": 1203, "keyName": "AURUM4", "keyType": "A", "currency": "AUR", "keyNameID": 59928, "description": "EVE - AURUM4 Account"}
12	1204	{"_key": 1204, "keyName": "AURUM5", "keyType": "A", "currency": "AUR", "keyNameID": 59929, "description": "EVE - AURUM5 Account"}
13	1205	{"_key": 1205, "keyName": "AURUM6", "keyType": "A", "currency": "AUR", "keyNameID": 59930, "description": "EVE - AURUM6 Account"}
14	1206	{"_key": 1206, "keyName": "AURUM7", "keyType": "A", "currency": "AUR", "keyNameID": 59931, "description": "EVE - AURUM7 Account"}
15	10000	{"_key": 10000, "keyName": "ISK", "keyType": "A", "currency": "ISK", "keyNameID": 59939, "description": "DUST - ISK Account"}
16	11000	{"_key": 11000, "keyName": "AUR", "keyType": "A", "currency": "AUD", "keyNameID": 59940, "description": "DUST - AUR Account"}
17	12000	{"_key": 12000, "keyName": "CP", "keyType": "A", "currency": "CP ", "description": "DUST - CP Account"}
18	13000	{"_key": 13000, "keyName": "DK", "keyType": "A", "currency": "DK ", "description": "DUST - DK Account"}
\.


--
-- Name: accountingkeys accountingkeys_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.accountingkeys
    ADD CONSTRAINT accountingkeys_pkey PRIMARY KEY (row_no);


--
-- Name: accountingkeys_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX accountingkeys_key_idx ON sde_native.accountingkeys USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict ied2lU9Dci1uMydqKWpQN1SY55K79vceFpuXAjZtJwLe3YbNxcn6dJvuCx15K56

