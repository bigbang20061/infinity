--
-- PostgreSQL database dump
--

\restrict dh4ml8eTfNj3a1PyNkWaOPx3V2sIkuCujhIcj4i6MmM0HlBIoXe8KO0CAN1IhVG

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: effects; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.effects (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: effects; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.effects (row_no, key, data) FROM stdin;
0	effects.AbyssalDepartureObserver	{"_key": "effects.AbyssalDepartureObserver", "type": "ShipEffect", "duration": 10000.0, "graphicID": 22126, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
1	effects.AbyssalDeparturePlayer	{"_key": "effects.AbyssalDeparturePlayer", "type": "ShipEffect", "duration": 10000.0, "graphicID": 22127, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
2	effects.AbyssalReentrySplash	{"_key": "effects.AbyssalReentrySplash", "type": "JumpDriveIn", "duration": 10000.0, "graphicID": 22219, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
3	effects.AbyssalSpaceTear	{"_key": "effects.AbyssalSpaceTear", "type": "ShipEffect", "duration": 10000.0, "graphicID": 22124, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
4	effects.AbyssalSpaceTearTrace	{"_key": "effects.AbyssalSpaceTearTrace", "type": "ShipEffect", "duration": 10000.0, "graphicID": 22125, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
5	effects.AbyssalSpaceTearTraceB	{"_key": "effects.AbyssalSpaceTearTraceB", "type": "ShipEffect", "duration": 10000.0, "graphicID": 22198, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
6	effects.AbyssalWinterSpaceTearTrace	{"_key": "effects.AbyssalWinterSpaceTearTrace", "type": "ShipEffect", "duration": 10000.0, "graphicID": 24520, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
7	effects.Afterburner	{"_key": "effects.Afterburner", "type": "SoundEffect", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
8	effects.AnchorDrop	{"_key": "effects.AnchorDrop", "type": "AnchorDrop", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
9	effects.AnchorLift	{"_key": "effects.AnchorLift", "type": "AnchorLift", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
10	effects.ArmorHardening	{"_key": "effects.ArmorHardening", "type": "ImpactEffect", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "animationName": "armorhardening", "transformFlags": [0], "destinationOffset": 0.0}
11	effects.ArmorRepair	{"_key": "effects.ArmorRepair", "type": "ImpactEffect", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "animationName": "armorrepair", "transformFlags": [0], "destinationOffset": 0.0}
12	effects.AttackMode	{"_key": "effects.AttackMode", "type": "AttackMode", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [2, 1], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
13	effects.AutoMoonMinerBeam	{"_key": "effects.AutoMoonMinerBeam", "type": "CelestialBeam", "duration": 86400000.0, "graphicID": 27391, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "destinationOffset": 0.0}
14	effects.Barrage	{"_key": "effects.Barrage", "type": "StandardWeapon", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
15	effects.BeamCollecting	{"_key": "effects.BeamCollecting", "type": "StretchEffect", "duration": 10000.0, "graphicID": 20328, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
16	effects.BioluminescenceAOE	{"_key": "effects.BioluminescenceAOE", "type": "ShipRenderEffect", "duration": 86400000.0, "graphicID": 22138, "timeScale": 0.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
17	effects.BrawlLightningBooster	{"_key": "effects.BrawlLightningBooster", "type": "BrawlLightningBoosterEffect", "duration": 4000.0, "graphicID": 24576, "mergeFlags": [1, 2, 4], "sourceDamage": {"size": 0.85, "delay": 0.5, "duration": 1.3}, "sourceOffset": 0.0, "targetDamage": {"size": 1.75, "delay": 0.57, "duration": 1.75}, "destinationOffset": 0.0}
18	effects.BrawlLightningChain	{"_key": "effects.BrawlLightningChain", "type": "BrawlLightningChainEffect", "duration": 4000.0, "graphicID": 24576, "mergeFlags": [1, 2, 4], "sourceDamage": {"size": 0.85, "delay": 0.5, "duration": 1.3}, "sourceOffset": 0.0, "targetDamage": {"size": 1.75, "delay": 0.57, "duration": 1.75}, "destinationOffset": 0.0}
19	effects.CapsuleFlare	{"_key": "effects.CapsuleFlare", "type": "CapsuleFlare", "duration": 10000.0, "graphicID": 24893, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "destinationOffset": 0.0}
20	effects.CargoScan	{"_key": "effects.CargoScan", "type": "LocatorStretchEffect", "duration": 10000.0, "graphicID": 21019, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
21	effects.CausticWaveAOE	{"_key": "effects.CausticWaveAOE", "type": "ShipRenderEffect", "duration": 86400000.0, "graphicID": 22139, "timeScale": 0.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
22	effects.CelestialBeam	{"_key": "effects.CelestialBeam", "type": "CelestialBeam", "duration": 10000.0, "graphicID": 27391, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "destinationOffset": 0.0}
23	effects.Cloak	{"_key": "effects.Cloak", "type": "Cloak", "duration": 6000.0, "graphicID": 21040, "timeScale": 0.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
24	effects.CloakNoAmim	{"_key": "effects.CloakNoAmim", "type": "CloakNoAnim", "duration": 6000.0, "graphicID": 21024, "timeScale": 0.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
25	effects.CloakRegardless	{"_key": "effects.CloakRegardless", "type": "CloakRegardless", "duration": 6000.0, "graphicID": 21040, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
26	effects.Cloaking	{"_key": "effects.Cloaking", "type": "Cloaking", "duration": 10000.0, "timeScale": 0.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
27	effects.CloakingCovertOps	{"_key": "effects.CloakingCovertOps", "type": "Cloak", "duration": 6000.0, "graphicID": 21015, "timeScale": 0.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
28	effects.CloakingPrototype	{"_key": "effects.CloakingPrototype", "type": "Cloak", "duration": 6000.0, "graphicID": 21030, "timeScale": 0.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
29	effects.CloudMining	{"_key": "effects.CloudMining", "type": "CloudMining", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
30	effects.DataLink	{"_key": "effects.DataLink", "type": "EveStretch3", "duration": 10000.0, "graphicID": 26604, "mergeFlags": [1, 2], "sourceOffset": 0.0, "destinationOffset": 0.0}
31	effects.DecloakStructureEmpAOE	{"_key": "effects.DecloakStructureEmpAOE", "type": "ControllerTrigger", "duration": 15000.0, "graphicID": 24977, "mergeFlags": [4], "sourceOffset": 0.0, "destinationOffset": 0.0, "controllerVariableTriggers": {"EMP_Scale": 25000.0, "Triggered": 1.0}}
32	effects.DeconstructionBeam	{"_key": "effects.DeconstructionBeam", "type": "LocatorStretchEffect", "duration": 10000.0, "graphicID": 21080, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
33	effects.DeployableDecloakDeviceShipEffect	{"_key": "effects.DeployableDecloakDeviceShipEffect", "type": "ChildEffect", "duration": 15000.0, "graphicID": 25010, "mergeFlags": [1, 2], "sourceOffset": 0.0, "destinationOffset": 0.0}
34	effects.DrifterControlled	{"_key": "effects.DrifterControlled", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21396, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 5], "destinationOffset": 0.0}
35	effects.DynamicDisruptionBubble	{"_key": "effects.DynamicDisruptionBubble", "type": "ControllerTrigger", "duration": 86400000.0, "graphicID": 25027, "mergeFlags": [4, 1], "sourceOffset": 0.0, "destinationOffset": 0.0, "controllerVariableTriggers": {"bubble_radius": 150000.0}}
36	effects.ECMBurst	{"_key": "effects.ECMBurst", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21020, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 6], "destinationOffset": 0.0}
37	effects.EMPWave	{"_key": "effects.EMPWave", "type": "EMPWave", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
38	effects.ElectronicAttributeModifyActivate	{"_key": "effects.ElectronicAttributeModifyActivate", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21016, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [1, 6], "destinationOffset": 0.0}
39	effects.ElectronicAttributeModifyTarget	{"_key": "effects.ElectronicAttributeModifyTarget", "type": "LocatorStretchEffect", "duration": 10000.0, "graphicID": 21034, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
40	effects.EnergyDestabilization	{"_key": "effects.EnergyDestabilization", "type": "LocatorStretchEffect", "duration": 10000.0, "graphicID": 21023, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
41	effects.EnergyTransfer	{"_key": "effects.EnergyTransfer", "type": "LocatorStretchEffect", "duration": 10000.0, "graphicID": 21010, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
42	effects.EnergyVampire	{"_key": "effects.EnergyVampire", "type": "LocatorStretchEffect", "duration": 10000.0, "graphicID": 21046, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
43	effects.EntosisBeam	{"_key": "effects.EntosisBeam", "type": "LocatorStretchEffect", "duration": 80000.0, "graphicID": 21099, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
44	effects.FilamentAOE	{"_key": "effects.FilamentAOE", "type": "ShipRenderEffect", "duration": 86400000.0, "graphicID": 22140, "timeScale": 0.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
45	effects.FractureSpaceTear	{"_key": "effects.FractureSpaceTear", "type": "SpaceTear", "duration": 86400000.0, "graphicID": 28758, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "destinationOffset": 0.0}
46	effects.GateActivity	{"_key": "effects.GateActivity", "type": "GateActivity", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
47	effects.GenericMultiEffect	{"_key": "effects.GenericMultiEffect", "type": "GenericMultiEffect", "duration": 86400000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
48	effects.HarvestingBeam	{"_key": "effects.HarvestingBeam", "type": "LocatorStretchEffect", "duration": 10000.0, "graphicID": 21097, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
49	effects.HybridFired	{"_key": "effects.HybridFired", "type": "StandardWeapon", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
50	effects.IndicatorBeamMoving	{"_key": "effects.IndicatorBeamMoving", "type": "SlashWeapon", "duration": 10000.0, "graphicID": 21274, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
51	effects.IndicatorBeamStationary	{"_key": "effects.IndicatorBeamStationary", "type": "DirectionalWeapon", "duration": 10000.0, "graphicID": 21274, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
52	effects.Invulnerability	{"_key": "effects.Invulnerability", "type": "ShipRenderEffect", "duration": 10000.0, "graphicID": 21258, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
53	effects.Jettison	{"_key": "effects.Jettison", "type": "ShipEffect", "duration": 10000.0, "graphicID": 20306, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 6], "destinationOffset": 0.0}
54	effects.JumpBridgeIn	{"_key": "effects.JumpBridgeIn", "type": "JumpDriveIn", "duration": 10000.0, "graphicID": 21025, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3, 4], "destinationOffset": 0.0}
55	effects.JumpBridgeOut	{"_key": "effects.JumpBridgeOut", "type": "JumpDriveOut", "duration": 10000.0, "graphicID": 21014, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 4], "destinationOffset": 0.0, "secondaryGraphicID": 22071}
56	effects.JumpDriveIn	{"_key": "effects.JumpDriveIn", "type": "JumpDriveIn", "duration": 10000.0, "graphicID": 21006, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3, 4], "destinationOffset": 0.0}
57	effects.JumpDriveInBO	{"_key": "effects.JumpDriveInBO", "type": "JumpDriveInBO", "duration": 10000.0, "graphicID": 21039, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3, 4], "destinationOffset": 0.0}
58	effects.JumpDriveOut	{"_key": "effects.JumpDriveOut", "type": "JumpDriveOut", "duration": 10000.0, "graphicID": 21002, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 4], "destinationOffset": 0.0, "secondaryGraphicID": 22071}
59	effects.JumpDriveOutBO	{"_key": "effects.JumpDriveOutBO", "type": "JumpDriveOutBO", "duration": 10000.0, "graphicID": 21027, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 4], "destinationOffset": 0.0, "secondaryGraphicID": 22071}
60	effects.JumpIn	{"_key": "effects.JumpIn", "type": "JumpIn", "duration": 10000.0, "graphicID": 21025, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3, 4], "destinationOffset": 0.0}
61	effects.JumpOut	{"_key": "effects.JumpOut", "type": "JumpOut", "duration": 10000.0, "graphicID": 21014, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3, 4], "destinationOffset": 0.0, "secondaryGraphicID": 22071}
62	effects.JumpOutAbyssal	{"_key": "effects.JumpOutAbyssal", "type": "JumpOutAbyssal", "duration": 10000.0, "graphicID": 21014, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3, 4], "destinationOffset": 0.0, "secondaryGraphicID": 22072}
63	effects.JumpOutAbyssalBetween	{"_key": "effects.JumpOutAbyssalBetween", "type": "JumpOutAbyssalBetween", "duration": 10000.0, "graphicID": 21014, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3, 4], "destinationOffset": 0.0, "secondaryGraphicID": 22073}
64	effects.JumpOutWormhole	{"_key": "effects.JumpOutWormhole", "type": "JumpOutWormhole", "duration": 10000.0, "graphicID": 21041, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3, 4], "destinationOffset": 0.0}
65	effects.JumpPortal	{"_key": "effects.JumpPortal", "type": "JumpPortal", "duration": 10000.0, "graphicID": 21008, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
66	effects.JumpPortalBO	{"_key": "effects.JumpPortalBO", "type": "JumpPortalBO", "duration": 10000.0, "graphicID": 21043, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [1, 3, 4], "destinationOffset": 0.0}
67	effects.Laser	{"_key": "effects.Laser", "type": "StandardWeapon", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
68	effects.LinkWithShipComponent	{"_key": "effects.LinkWithShipComponent", "type": "EveStretch3", "duration": 10000.0, "graphicID": 25114, "timeScale": 1.0, "mergeFlags": [1, 4, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
69	effects.LinkedToTraceGate	{"_key": "effects.LinkedToTraceGate", "type": "GenericEffect", "duration": 86400000.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "destinationOffset": 0.0}
70	effects.M2Monument	{"_key": "effects.M2Monument", "type": "ProximityEffect", "duration": 86400.0, "graphicID": 24982, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
71	effects.MainBankHackingBeam	{"_key": "effects.MainBankHackingBeam", "type": "EveStretch3", "duration": 10000.0, "graphicID": 25030, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
72	effects.MicroJumpDriveEngage	{"_key": "effects.MicroJumpDriveEngage", "type": "MicroJumpDriveEngage", "duration": 10000.0, "graphicID": 21232, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [7, 3, 6], "destinationOffset": 0.0, "secondaryGraphicID": 21230}
73	effects.MicroJumpDriveJump	{"_key": "effects.MicroJumpDriveJump", "type": "MicroJumpDriveJump", "duration": 10000.0, "graphicID": 21229, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
74	effects.MicroJumpFieldEngage	{"_key": "effects.MicroJumpFieldEngage", "type": "MicroJumpDriveEngage", "duration": 10000.0, "graphicID": 21235, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [7, 3], "destinationOffset": 0.0, "secondaryGraphicID": 21234}
75	effects.MicroJumpFieldEngageCapital	{"_key": "effects.MicroJumpFieldEngageCapital", "type": "MicroJumpDriveEngage", "duration": 10000.0, "graphicID": 27593, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [7, 3], "destinationOffset": 0.0, "secondaryGraphicID": 27594}
76	effects.MicroJumpFieldJump	{"_key": "effects.MicroJumpFieldJump", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21233, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 6], "destinationOffset": 0.0}
77	effects.MicroWarpDrive	{"_key": "effects.MicroWarpDrive", "type": "SoundEffect", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
78	effects.Mining	{"_key": "effects.Mining", "type": "StandardWeapon", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
79	effects.MissileDeployment	{"_key": "effects.MissileDeployment", "type": "MissileLaunch", "duration": 12000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
80	effects.ModifyShieldResonance	{"_key": "effects.ModifyShieldResonance", "type": "ImpactEffect", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "animationName": "shieldhardening", "transformFlags": [0], "destinationOffset": 0.0}
81	effects.ModifyTargetSpeed	{"_key": "effects.ModifyTargetSpeed", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21037, "timeScale": 1.0, "mergeFlags": [1, 4], "sourceOffset": 0.0, "transformFlags": [2, 4], "destinationOffset": 0.0}
82	effects.MoonMiningExtraction	{"_key": "effects.MoonMiningExtraction", "type": "StandardWeapon", "duration": 250000.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "destinationOffset": 0.0}
83	effects.MultiEffect	{"_key": "effects.MultiEffect", "type": "MultiEffect", "duration": 86400000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
84	effects.NPEBoardShip	{"_key": "effects.NPEBoardShip", "type": "MultiEffectControllerTrigger", "duration": 86400000.0, "graphicID": 25061, "mergeFlags": [1, 2], "sourceOffset": 0.0, "destinationOffset": 0.0, "controllerVariableTriggers": {"board": 0.0}}
85	effects.OutOfBoundsOverlay	{"_key": "effects.OutOfBoundsOverlay", "type": "ShipRenderEffect", "duration": 86400000.0, "graphicID": 22135, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
86	effects.OutOfBoundsOverlayDeathzone	{"_key": "effects.OutOfBoundsOverlayDeathzone", "type": "ShipRenderEffect", "duration": 86400000.0, "graphicID": 26255, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
87	effects.OutOfBoundsScreen	{"_key": "effects.OutOfBoundsScreen", "type": "PostProcess", "duration": 86400000.0, "graphicID": 22095, "mergeFlags": [1, 2], "sourceOffset": 0.0, "destinationOffset": 0.0}
88	effects.OutOfBoundsShip	{"_key": "effects.OutOfBoundsShip", "type": "ShipEffect", "duration": 86400000.0, "graphicID": 22136, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 6], "destinationOffset": 0.0}
89	effects.OutOfBoundsShipDeathzone	{"_key": "effects.OutOfBoundsShipDeathzone", "type": "ShipEffect", "duration": 86400000.0, "graphicID": 26254, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 6], "destinationOffset": 0.0}
90	effects.OutOfBoundsShipWinter	{"_key": "effects.OutOfBoundsShipWinter", "type": "ShipEffect", "duration": 86400000.0, "graphicID": 22328, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 6], "destinationOffset": 0.0}
91	effects.PointDefense	{"_key": "effects.PointDefense", "type": "PointDefense", "duration": 10000.0, "graphicID": 21331, "timeScale": 1.0, "mergeFlags": [3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
92	effects.ProjectileFired	{"_key": "effects.ProjectileFired", "type": "StandardWeapon", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
93	effects.ProjectileFiredForEntities	{"_key": "effects.ProjectileFiredForEntities", "type": "StandardWeapon", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
94	effects.ProximityEffect	{"_key": "effects.ProximityEffect", "type": "ProximityEffect", "duration": 10000.0, "graphicID": 24968, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
95	effects.ProximityTrapExplosiveAOE	{"_key": "effects.ProximityTrapExplosiveAOE", "type": "ControllerTrigger", "duration": 15000.0, "graphicID": 24976, "mergeFlags": [4], "sourceOffset": 0.0, "destinationOffset": 0.0, "controllerVariableTriggers": {"Triggered": 1.0, "Blast_Scale": 25000.0}}
96	effects.PulseSphere30K	{"_key": "effects.PulseSphere30K", "type": "ShipEffect", "duration": 86400000.0, "graphicID": 22204, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
97	effects.PulseSphere80K	{"_key": "effects.PulseSphere80K", "type": "ShipEffect", "duration": 86400000.0, "graphicID": 22205, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
98	effects.PulseSphereAOE	{"_key": "effects.PulseSphereAOE", "type": "ShipRenderEffect", "duration": 86400000.0, "graphicID": 22141, "timeScale": 0.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
99	effects.RemoteArmorRepairDrone	{"_key": "effects.RemoteArmorRepairDrone", "type": "LocatorStretchEffect", "duration": 10000.0, "graphicID": 21347, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
100	effects.RemoteArmourRepair	{"_key": "effects.RemoteArmourRepair", "type": "EveStretch3", "duration": 10000.0, "graphicID": 21038, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
101	effects.RemoteECM	{"_key": "effects.RemoteECM", "type": "LocatorStretchEffect", "duration": 10000.0, "graphicID": 21045, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
102	effects.RemoteHullRepair	{"_key": "effects.RemoteHullRepair", "type": "EveStretch3", "duration": 10000.0, "graphicID": 28008, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
103	effects.RemoteTriglavianMaterialization	{"_key": "effects.RemoteTriglavianMaterialization", "type": "LocatorStretchEffect", "duration": 10000.0, "graphicID": 24495, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
104	effects.ReserveBankHackingBeam	{"_key": "effects.ReserveBankHackingBeam", "type": "EveStretch3", "duration": 10000.0, "graphicID": 25031, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
105	effects.SWDamageBeamAmarr	{"_key": "effects.SWDamageBeamAmarr", "type": "DirectionalWeapon", "duration": 10000.0, "graphicID": 21296, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
106	effects.SWDamageBeamCaldari	{"_key": "effects.SWDamageBeamCaldari", "type": "DirectionalWeapon", "duration": 10000.0, "graphicID": 21297, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
107	effects.SWDamageBeamGallente	{"_key": "effects.SWDamageBeamGallente", "type": "DirectionalWeapon", "duration": 10000.0, "graphicID": 21298, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
108	effects.SWDamageBeamMinmatar	{"_key": "effects.SWDamageBeamMinmatar", "type": "DirectionalWeapon", "duration": 10000.0, "graphicID": 21299, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
109	effects.SWLightningFirstStrike	{"_key": "effects.SWLightningFirstStrike", "type": "TurretStretchEffect", "duration": 10000.0, "graphicID": 21325, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
110	effects.SWLightningSecondStrike	{"_key": "effects.SWLightningSecondStrike", "type": "DamageLocatorToDamageLocatorStretchEffect", "duration": 10000.0, "graphicID": 21326, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
111	effects.SWSlashBeamAmarr	{"_key": "effects.SWSlashBeamAmarr", "type": "SlashWeapon", "duration": 10000.0, "graphicID": 21296, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
112	effects.SWSlashBeamCaldari	{"_key": "effects.SWSlashBeamCaldari", "type": "SlashWeapon", "duration": 10000.0, "graphicID": 21297, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
113	effects.SWSlashBeamGallente	{"_key": "effects.SWSlashBeamGallente", "type": "SlashWeapon", "duration": 10000.0, "graphicID": 21298, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
114	effects.SWSlashBeamMinmatar	{"_key": "effects.SWSlashBeamMinmatar", "type": "SlashWeapon", "duration": 10000.0, "graphicID": 21299, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
115	effects.Salvaging	{"_key": "effects.Salvaging", "type": "StandardWeapon", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
116	effects.ScanningPulseVolumeAsteroid	{"_key": "effects.ScanningPulseVolumeAsteroid", "type": "ShipEffect", "duration": 10000.0, "graphicID": 28753, "mergeFlags": [], "sourceOffset": 0.0, "transformFlags": [1], "destinationOffset": 0.0}
117	effects.ScorchMultiEffect	{"_key": "effects.ScorchMultiEffect", "type": "MultiEffectControllerTrigger", "duration": 86400000.0, "graphicID": 25626, "mergeFlags": [1, 2], "sourceOffset": 0.0, "destinationOffset": 0.0, "controllerVariableTriggers": {"skipDelay": 0.0}}
118	effects.SensorDampening	{"_key": "effects.SensorDampening", "type": "LocatorStretchEffect", "duration": 10000.0, "graphicID": 21351, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
119	effects.ShieldBoosting	{"_key": "effects.ShieldBoosting", "type": "ImpactEffect", "duration": 10000.0, "timeScale": 0.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "animationName": "shieldboost", "transformFlags": [0], "destinationOffset": 0.0}
120	effects.ShieldTransfer	{"_key": "effects.ShieldTransfer", "type": "EveStretch3", "duration": 10000.0, "graphicID": 21003, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
121	effects.ShipEjector	{"_key": "effects.ShipEjector", "type": "ShipEjector", "duration": 20000.0, "graphicID": 24890, "timeScale": 1.0, "mergeFlags": [4], "sourceOffset": 0.0, "destinationOffset": 0.0}
122	effects.ShipScan	{"_key": "effects.ShipScan", "type": "LocatorStretchEffect", "duration": 10000.0, "graphicID": 21007, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
123	effects.SiegeMode	{"_key": "effects.SiegeMode", "type": "SiegeMode", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [2, 1], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
124	effects.SkinChange	{"_key": "effects.SkinChange", "type": "SkinChange", "duration": 10000.0, "graphicID": 21060, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
125	effects.SlashStretch	{"_key": "effects.SlashStretch", "type": "SlashWeapon", "duration": 10000.0, "graphicID": 21004, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0, "secondaryGraphicID": 24538}
126	effects.SleeperScannerShip	{"_key": "effects.SleeperScannerShip", "type": "ShipRenderEffect", "duration": 10000.0, "graphicID": 21028, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
127	effects.SleeperScannerStretch	{"_key": "effects.SleeperScannerStretch", "type": "StretchEffect", "duration": 10000.0, "graphicID": 21017, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
128	effects.SpeedBoost	{"_key": "effects.SpeedBoost", "type": "GenericEffect", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
129	effects.StellarHarvester	{"_key": "effects.StellarHarvester", "type": "StellarHarvester", "duration": 86400000.0, "graphicID": 24565, "mergeFlags": [1, 4], "sourceOffset": 0.0, "destinationOffset": 0.0}
130	effects.StructureECMBurst	{"_key": "effects.StructureECMBurst", "type": "ShipEffect", "duration": 10000.0, "graphicID": 22002, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 5], "destinationOffset": 0.0}
131	effects.StructureOffline	{"_key": "effects.StructureOffline", "type": "StructureOffline", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
132	effects.StructureOnline	{"_key": "effects.StructureOnline", "type": "StructureOnline", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
133	effects.StructureOnlined	{"_key": "effects.StructureOnlined", "type": "StructureOnlined", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
134	effects.StructureRepair	{"_key": "effects.StructureRepair", "type": "ImpactEffect", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "animationName": "hullrepair", "transformFlags": [0], "destinationOffset": 0.0}
135	effects.StructureRepairStateComplete	{"_key": "effects.StructureRepairStateComplete", "type": "ShipRenderEffect", "duration": 20000.0, "graphicID": 22003, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
136	effects.StructureRepairStateFailed	{"_key": "effects.StructureRepairStateFailed", "type": "ShipRenderEffect", "duration": 20000.0, "graphicID": 22004, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
137	effects.SunHarvestingBeam	{"_key": "effects.SunHarvestingBeam", "type": "SunHarvestingBeam", "duration": 86400000.0, "graphicID": 24565, "mergeFlags": [], "sourceOffset": 0.0, "destinationOffset": 0.0}
138	effects.SunHarvestingBeamJove	{"_key": "effects.SunHarvestingBeamJove", "type": "SunHarvestingBeam", "duration": 86400000.0, "graphicID": 26384, "mergeFlags": [], "sourceOffset": 0.0, "destinationOffset": 0.0, "controllerVariableTriggers": {"star_state": 1.0}}
139	effects.SuperDefenseShield	{"_key": "effects.SuperDefenseShield", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21376, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [1, 3, 8], "destinationOffset": 0.0}
140	effects.SuperDefenseShieldBeam	{"_key": "effects.SuperDefenseShieldBeam", "type": "StretchEffect", "duration": 10000.0, "graphicID": 21375, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
141	effects.SuperDefenseShieldSource	{"_key": "effects.SuperDefenseShieldSource", "type": "ChildEffect", "duration": 10000.0, "graphicID": 21374, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [1, 3, 8], "destinationOffset": 0.0}
142	effects.SuperWeaponAOECycle	{"_key": "effects.SuperWeaponAOECycle", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21271, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [1], "destinationOffset": 0.0}
143	effects.SuperWeaponAOEGuidanceDisruption	{"_key": "effects.SuperWeaponAOEGuidanceDisruption", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21342, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1], "destinationOffset": 0.0}
144	effects.SuperWeaponAOEPulse	{"_key": "effects.SuperWeaponAOEPulse", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21272, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [1], "destinationOffset": 0.0}
145	effects.SuperWeaponAOESensorDampener	{"_key": "effects.SuperWeaponAOESensorDampener", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21336, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1], "destinationOffset": 0.0}
146	effects.SuperWeaponAOEStasisWeb	{"_key": "effects.SuperWeaponAOEStasisWeb", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21337, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1], "destinationOffset": 0.0}
147	effects.SuperWeaponAOETargetPainter	{"_key": "effects.SuperWeaponAOETargetPainter", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21339, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1], "destinationOffset": 0.0}
148	effects.SuperWeaponAOETrackingDisruption	{"_key": "effects.SuperWeaponAOETrackingDisruption", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21340, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1], "destinationOffset": 0.0}
149	effects.SuperWeaponAOEWarpDisruption	{"_key": "effects.SuperWeaponAOEWarpDisruption", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21341, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1], "destinationOffset": 0.0}
150	effects.SuperWeaponAmarr	{"_key": "effects.SuperWeaponAmarr", "type": "SuperWeapon", "duration": 10000.0, "graphicID": 21004, "timeScale": 0.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 500.0, "secondaryGraphicID": 24538}
151	effects.SuperWeaponBeaconLighter	{"_key": "effects.SuperWeaponBeaconLighter", "type": "BoundsToCenterStretchEffect", "duration": 10000.0, "graphicID": 21317, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
152	effects.SuperWeaponCaldari	{"_key": "effects.SuperWeaponCaldari", "type": "SuperWeapon", "duration": 10000.0, "graphicID": 21013, "timeScale": 0.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
153	effects.SuperWeaponCone	{"_key": "effects.SuperWeaponCone", "type": "DirectionalWeapon", "duration": 10000.0, "graphicID": 21300, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
154	effects.SuperWeaponEnergyDrain	{"_key": "effects.SuperWeaponEnergyDrain", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21316, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1], "destinationOffset": 0.0}
155	effects.SuperWeaponGallente	{"_key": "effects.SuperWeaponGallente", "type": "SuperWeapon", "duration": 10000.0, "graphicID": 21031, "timeScale": 0.0, "mergeFlags": [1, 3, 2], "sourceOffset": 7000.0, "transformFlags": [0], "destinationOffset": 500.0}
156	effects.SuperWeaponLanceAmarr	{"_key": "effects.SuperWeaponLanceAmarr", "type": "SuperWeapon", "duration": 10000.0, "graphicID": 21296, "timeScale": 0.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
157	effects.SuperWeaponLanceCaldari	{"_key": "effects.SuperWeaponLanceCaldari", "type": "SuperWeapon", "duration": 10000.0, "graphicID": 21297, "timeScale": 0.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
158	effects.SuperWeaponLanceGallente	{"_key": "effects.SuperWeaponLanceGallente", "type": "SuperWeapon", "duration": 10000.0, "graphicID": 21298, "timeScale": 0.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
159	effects.SuperWeaponLanceMinmatar	{"_key": "effects.SuperWeaponLanceMinmatar", "type": "SuperWeapon", "duration": 10000.0, "graphicID": 21299, "timeScale": 0.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
160	effects.SuperWeaponMinmatar	{"_key": "effects.SuperWeaponMinmatar", "type": "SuperWeapon", "duration": 10000.0, "graphicID": 21009, "timeScale": 0.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
161	effects.SurveyScan	{"_key": "effects.SurveyScan", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21035, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [1, 4], "destinationOffset": 0.0}
162	effects.TargetBreaker	{"_key": "effects.TargetBreaker", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21012, "timeScale": 0.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 6], "destinationOffset": 0.0}
163	effects.TargetPaint	{"_key": "effects.TargetPaint", "type": "EveStretch3", "duration": 10000.0, "graphicID": 21033, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
164	effects.TargetScan	{"_key": "effects.TargetScan", "type": "LocatorStretchEffect", "duration": 10000.0, "graphicID": 21044, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
165	effects.Tethering	{"_key": "effects.Tethering", "type": "ShipRenderTargetedEffect", "duration": 86400000.0, "graphicID": 21190, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
166	effects.TetheringRepair	{"_key": "effects.TetheringRepair", "type": "ImpactEffect", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "animationName": "armorrepair", "transformFlags": [0], "destinationOffset": 0.0}
167	effects.TorpedoDeployment	{"_key": "effects.TorpedoDeployment", "type": "GenericEffect", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
168	effects.TrackingDisruption	{"_key": "effects.TrackingDisruption", "type": "LocatorStretchEffect", "duration": 10000.0, "graphicID": 21350, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
169	effects.TractorBeam	{"_key": "effects.TractorBeam", "type": "StandardWeapon", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
170	effects.TriGlavianBS01a	{"_key": "effects.TriGlavianBS01a", "type": "PointDefense", "duration": 10000.0, "graphicID": 22049, "timeScale": 1.0, "mergeFlags": [3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
171	effects.TriGlavianBS01b	{"_key": "effects.TriGlavianBS01b", "type": "PointDefense", "duration": 10000.0, "graphicID": 22050, "timeScale": 1.0, "mergeFlags": [3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
172	effects.TriGlavianScannerShip	{"_key": "effects.TriGlavianScannerShip", "type": "ShipRenderEffect", "duration": 10000.0, "graphicID": 24472, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
173	effects.TriGlavianScannerStretch	{"_key": "effects.TriGlavianScannerStretch", "type": "StretchEffect", "duration": 10000.0, "graphicID": 24474, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
174	effects.TriageMode	{"_key": "effects.TriageMode", "type": "TriageMode", "duration": 10000.0, "graphicID": 21022, "timeScale": 0.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
175	effects.TriglavianBeam	{"_key": "effects.TriglavianBeam", "type": "TriglavianBeam", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
176	effects.TriglavianRiftLarge	{"_key": "effects.TriglavianRiftLarge", "type": "WormholeActivity", "duration": 47000.0, "graphicID": 24420, "mergeFlags": [], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
177	effects.TriglavianRiftSmall	{"_key": "effects.TriglavianRiftSmall", "type": "WormholeActivity", "duration": 47000.0, "graphicID": 24422, "mergeFlags": [], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
178	effects.TurboLaser	{"_key": "effects.TurboLaser", "type": "SuperWeapon", "duration": 10000.0, "graphicID": 21053, "timeScale": 0.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
179	effects.TurboLaserXL	{"_key": "effects.TurboLaserXL", "type": "SuperWeapon", "duration": 10000.0, "graphicID": 28128, "timeScale": 0.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
180	effects.TurboShield	{"_key": "effects.TurboShield", "type": "ShipRenderEffect", "duration": 10000.0, "graphicID": 21054, "timeScale": 0.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
181	effects.TurretWeaponRangeTrackingSpeedMultiplyActivate	{"_key": "effects.TurretWeaponRangeTrackingSpeedMultiplyActivate", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21047, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 6], "destinationOffset": 0.0}
182	effects.TurretWeaponRangeTrackingSpeedMultiplyTarget	{"_key": "effects.TurretWeaponRangeTrackingSpeedMultiplyTarget", "type": "LocatorStretchEffect", "duration": 10000.0, "graphicID": 21026, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
183	effects.Uncloak	{"_key": "effects.Uncloak", "type": "Uncloak", "duration": 6000.0, "graphicID": 21040, "timeScale": 0.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [1, 3], "destinationOffset": 0.0}
184	effects.UpwellChainWeaponLarge	{"_key": "effects.UpwellChainWeaponLarge", "type": "ChainWeaponEffect", "duration": 5000.0, "graphicID": 24577, "mergeFlags": [1, 2, 4], "sourceDamage": {"size": 1.0, "delay": 0.5, "duration": 1.55}, "sourceOffset": 0.0, "targetDamage": {"size": 2.0, "delay": 0.57, "duration": 2.05}, "destinationOffset": 0.0}
185	effects.UpwellChainWeaponMedium	{"_key": "effects.UpwellChainWeaponMedium", "type": "ChainWeaponEffect", "duration": 4000.0, "graphicID": 24576, "mergeFlags": [1, 2, 4], "sourceDamage": {"size": 0.85, "delay": 0.5, "duration": 1.3}, "sourceOffset": 0.0, "targetDamage": {"size": 1.75, "delay": 0.57, "duration": 1.75}, "destinationOffset": 0.0}
186	effects.UpwellChainWeaponSmall	{"_key": "effects.UpwellChainWeaponSmall", "type": "ChainWeaponEffect", "duration": 3000.0, "graphicID": 24575, "mergeFlags": [1, 2, 4], "sourceDamage": {"size": 0.75, "delay": 0.5, "duration": 1.05}, "sourceOffset": 0.0, "targetDamage": {"size": 1.5, "delay": 0.57, "duration": 1.5}, "destinationOffset": 0.0}
187	effects.VisualDamageSystemShipEffect	{"_key": "effects.VisualDamageSystemShipEffect", "type": "ChildEffect", "duration": 36000000.0, "graphicID": 27886, "mergeFlags": [1, 2], "sourceOffset": 0.0, "destinationOffset": 0.0}
188	effects.VisualModuleEffect	{"_key": "effects.VisualModuleEffect", "type": "ModuleEffect", "duration": 36000000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2, 4], "sourceOffset": 0.0, "destinationOffset": 0.0}
189	effects.WarfareLinkArmor	{"_key": "effects.WarfareLinkArmor", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21382, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [1, 6], "destinationOffset": 0.0}
190	effects.WarfareLinkInformation	{"_key": "effects.WarfareLinkInformation", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21383, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [1, 6], "destinationOffset": 0.0}
191	effects.WarfareLinkMining	{"_key": "effects.WarfareLinkMining", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21384, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [1, 6], "destinationOffset": 0.0}
192	effects.WarfareLinkShield	{"_key": "effects.WarfareLinkShield", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21385, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [1, 6], "destinationOffset": 0.0}
193	effects.WarfareLinkSkirmish	{"_key": "effects.WarfareLinkSkirmish", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21386, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [1, 6], "destinationOffset": 0.0}
194	effects.WarfareLinkSphereArmor	{"_key": "effects.WarfareLinkSphereArmor", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21377, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [7], "destinationOffset": 0.0}
195	effects.WarfareLinkSphereInformation	{"_key": "effects.WarfareLinkSphereInformation", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21378, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [7], "destinationOffset": 0.0}
196	effects.WarfareLinkSphereMining	{"_key": "effects.WarfareLinkSphereMining", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21379, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [7], "destinationOffset": 0.0}
197	effects.WarfareLinkSphereShield	{"_key": "effects.WarfareLinkSphereShield", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21380, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [7], "destinationOffset": 0.0}
198	effects.WarfareLinkSphereSkirmish	{"_key": "effects.WarfareLinkSphereSkirmish", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21381, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [7], "destinationOffset": 0.0}
199	effects.WarfareLinkedGeneric	{"_key": "effects.WarfareLinkedGeneric", "type": "ShipEffect", "duration": 10000.0, "graphicID": 21387, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [1, 6], "destinationOffset": 0.0}
200	effects.WarpDisrupt	{"_key": "effects.WarpDisrupt", "type": "LocatorStretchEffect", "duration": 10000.0, "graphicID": 21395, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
201	effects.WarpDisruptFieldGenerating	{"_key": "effects.WarpDisruptFieldGenerating", "type": "WarpDisruptFieldGenerating", "duration": 10000.0, "graphicID": 20396, "timeScale": 0.0, "mergeFlags": [3], "sourceOffset": 0.0, "transformFlags": [1], "destinationOffset": 0.0}
202	effects.WarpGateEffect	{"_key": "effects.WarpGateEffect", "type": "AccelerationGate", "duration": 10000.0, "timeScale": 0.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
203	effects.WarpIn	{"_key": "effects.WarpIn", "type": "WarpFlashIn", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
204	effects.WarpOut	{"_key": "effects.WarpOut", "type": "WarpFlashOut", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
205	effects.WarpScramble	{"_key": "effects.WarpScramble", "type": "LocatorStretchEffect", "duration": 10000.0, "graphicID": 21036, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
206	effects.Warping	{"_key": "effects.Warping", "type": "Warping", "duration": 1200000.0, "graphicID": 21048, "timeScale": 0.0, "mergeFlags": [1, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
207	effects.WhiteOut	{"_key": "effects.WhiteOut", "type": "CameraAttachmentEffect", "duration": 86400000.0, "graphicID": 25550, "mergeFlags": [1, 2], "sourceOffset": 0.0, "destinationOffset": 0.0}
208	effects.WormholeActivity	{"_key": "effects.WormholeActivity", "type": "WormholeActivity", "duration": 10000.0, "timeScale": 1.0, "mergeFlags": [1, 3, 2], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
209	effects.ZarzakhBoundaryBubble	{"_key": "effects.ZarzakhBoundaryBubble", "type": "ControllerTrigger", "duration": 86400000.0, "graphicID": 26241, "mergeFlags": [1, 4], "sourceOffset": 0.0, "destinationOffset": 0.0, "controllerVariableTriggers": {"bubbleRadius": 25000.0}}
210	effects.phaseLinkDeployable2PhasedObject	{"_key": "effects.phaseLinkDeployable2PhasedObject", "type": "EveStretch3", "duration": 10000.0, "graphicID": 28756, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "destinationOffset": 0.0, "locatorSetOverride": "phaseBeamTarget"}
211	effects.phaseLinkDeployable2PhasedObjectFAKE	{"_key": "effects.phaseLinkDeployable2PhasedObjectFAKE", "type": "EveStretch3", "duration": 10000.0, "graphicID": 29102, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "destinationOffset": 0.0, "locatorSetOverride": "phaseBeamTarget"}
212	effects.phaseLinkShip2Deployable	{"_key": "effects.phaseLinkShip2Deployable", "type": "EveStretch3", "duration": 10000.0, "graphicID": 29102, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "destinationOffset": 0.0, "locatorSetOverride": "linktarget"}
213	effects.phaseLinkShip2DeployableFAKE	{"_key": "effects.phaseLinkShip2DeployableFAKE", "type": "EveStretch3", "duration": 10000.0, "graphicID": 29103, "timeScale": 1.0, "mergeFlags": [1, 2, 4], "sourceOffset": 0.0, "destinationOffset": 0.0, "locatorSetOverride": "linktarget", "controllerVariableTriggers": {"linkState": 2.0}}
214	effects.vanguardDamageControlModule	{"_key": "effects.vanguardDamageControlModule", "type": "ShipRenderEffect", "duration": 10000.0, "graphicID": 34698, "mergeFlags": [1], "sourceOffset": 0.0, "transformFlags": [0], "destinationOffset": 0.0}
\.


--
-- Name: effects effects_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.effects
    ADD CONSTRAINT effects_pkey PRIMARY KEY (row_no);


--
-- Name: effects_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX effects_key_idx ON sde_native.effects USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict dh4ml8eTfNj3a1PyNkWaOPx3V2sIkuCujhIcj4i6MmM0HlBIoXe8KO0CAN1IhVG

