--
-- PostgreSQL database dump
--

\restrict D2EKelvrdNXyXKa3Keylit6KhV7mhceXRPUYj6QPc2upyZFfMq0cDACMX3NvB0m

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: empiretechnologies; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.empiretechnologies (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: empiretechnologies; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.empiretechnologies (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "icon": "res:/UI/Texture/classes/EmpireSelection/subnavShips.png", "order": 2, "title": 525504, "examples": {"1": {"iconAmarr": "res:/UI/Texture/Shared/Brackets/battleship_32.png", "titleAmarr": 527286, "iconCaldari": "res:/UI/Texture/Shared/Brackets/battleship_32.png", "iconGallente": "res:/UI/Texture/Shared/Brackets/battleship_32.png", "iconMinmatar": "res:/UI/Texture/Shared/Brackets/battleship_32.png", "titleCaldari": 527287, "subtitleAmarr": 527290, "titleGallente": 527288, "titleMinmatar": 527289, "subtitleCaldari": 527291, "subtitleGallente": 527292, "subtitleMinmatar": 527293}, "2": {"iconAmarr": "res:/UI/Texture/Shared/Brackets/frigate_32.png", "titleAmarr": 527294, "iconCaldari": "res:/UI/Texture/Shared/Brackets/frigate_32.png", "iconGallente": "res:/UI/Texture/Shared/Brackets/frigate_32.png", "iconMinmatar": "res:/UI/Texture/Shared/Brackets/frigate_32.png", "titleCaldari": 527295, "subtitleAmarr": 527298, "titleGallente": 527296, "titleMinmatar": 527297, "subtitleCaldari": 527299, "subtitleGallente": 527300, "subtitleMinmatar": 527301}, "3": {"iconAmarr": "res:/UI/Texture/Shared/Brackets/industrial_32.png", "titleAmarr": 527310, "iconCaldari": "res:/UI/Texture/Shared/Brackets/industrial_32.png", "iconGallente": "res:/UI/Texture/Shared/Brackets/industrial_32.png", "iconMinmatar": "res:/UI/Texture/Shared/Brackets/industrial_32.png", "titleCaldari": 527311, "subtitleAmarr": 527314, "titleGallente": 527312, "titleMinmatar": 527313, "subtitleCaldari": 527315, "subtitleGallente": 527316, "subtitleMinmatar": 527317}, "4": {"iconAmarr": "res:/UI/Texture/Shared/Brackets/frigate_32.png", "titleAmarr": 527272, "iconCaldari": "res:/UI/Texture/Shared/Brackets/frigate_32.png", "iconGallente": "res:/UI/Texture/Shared/Brackets/frigate_32.png", "iconMinmatar": "res:/UI/Texture/Shared/Brackets/frigate_32.png", "titleCaldari": 527273, "subtitleAmarr": 527276, "titleGallente": 527274, "titleMinmatar": 527275, "subtitleCaldari": 527277, "subtitleGallente": 527278, "subtitleMinmatar": 527279}, "5": {"iconAmarr": "res:/UI/Texture/Shared/Brackets/rookie_32.png", "titleAmarr": 527302, "iconCaldari": "res:/UI/Texture/Shared/Brackets/rookie_32.png", "iconGallente": "res:/UI/Texture/Shared/Brackets/rookie_32.png", "iconMinmatar": "res:/UI/Texture/Shared/Brackets/rookie_32.png", "titleCaldari": 527303, "subtitleAmarr": 527306, "titleGallente": 527304, "titleMinmatar": 527305, "subtitleCaldari": 527307, "subtitleGallente": 527308, "subtitleMinmatar": 527309}}, "isDisplayed": true, "mainViewAmarr": "res:/UI/Texture/classes/EmpireSelection/Ships/fleetAmarr_base.png", "mainViewCaldari": "res:/UI/Texture/classes/EmpireSelection/Ships/fleetCaldari_base.png", "mainViewGallente": "res:/UI/Texture/classes/EmpireSelection/Ships/fleetGallente_base.png", "mainViewMinmatar": "res:/UI/Texture/classes/EmpireSelection/Ships/fleetMinmatar_base.png"}
1	2	{"_key": 2, "icon": "res:/UI/Texture/classes/EmpireSelection/subnavTech.png", "order": 3, "title": 525565, "examples": {"1": {"iconAmarr": "res:/UI/Texture/classes/ShipTree/attributes/energyTurrets.png", "titleAmarr": 525582, "iconCaldari": "res:/UI/Texture/classes/ShipTree/attributes/energyTurrets.png", "iconGallente": "res:/UI/Texture/classes/ShipTree/attributes/energyTurrets.png", "iconMinmatar": "res:/UI/Texture/classes/ShipTree/attributes/energyTurrets.png", "titleCaldari": 525583, "subtitleAmarr": 525586, "titleGallente": 525584, "titleMinmatar": 525585, "subtitleCaldari": 525587, "subtitleGallente": 525588, "subtitleMinmatar": 525589}, "2": {"iconAmarr": "res:/UI/Texture/classes/ShipTree/attributes/armor.png", "titleAmarr": 525590, "iconCaldari": "res:/UI/Texture/classes/ShipTree/attributes/armor.png", "iconGallente": "res:/UI/Texture/classes/ShipTree/attributes/armor.png", "iconMinmatar": "res:/UI/Texture/classes/ShipTree/attributes/armor.png", "titleCaldari": 525591, "subtitleAmarr": 525594, "titleGallente": 525592, "titleMinmatar": 525593, "subtitleCaldari": 525595, "subtitleGallente": 525596, "subtitleMinmatar": 525597}}, "isDisplayed": true, "mainTextAmarr": 526188, "mainViewAmarr": "res:/UI/Texture/classes/EmpireSelection/turretAmarr.webm", "mainTextCaldari": 526189, "mainViewCaldari": "res:/UI/Texture/classes/EmpireSelection/turretCaldari.webm", "mainTextGallente": 526190, "mainTextMinmatar": 526191, "mainViewGallente": "res:/UI/Texture/classes/EmpireSelection/turretGallente.webm", "mainViewMinmatar": "res:/UI/Texture/classes/EmpireSelection/turretMinmatar.webm"}
2	4	{"_key": 4, "icon": "res:/UI/Texture/classes/EmpireSelection/subnavPolitics.png", "order": 4, "title": 525607, "examples": {"1": {"iconAmarr": "res:/UI/Texture/classes/EmpireSelection/factionBanner.png", "titleAmarr": 525608, "iconCaldari": "res:/UI/Texture/classes/EmpireSelection/factionBanner.png", "iconGallente": "res:/UI/Texture/classes/EmpireSelection/factionBanner.png", "iconMinmatar": "res:/UI/Texture/classes/EmpireSelection/factionBanner.png", "titleCaldari": 525609, "subtitleAmarr": 525612, "titleGallente": 525610, "titleMinmatar": 525611, "subtitleCaldari": 525613, "subtitleGallente": 525614, "subtitleMinmatar": 525615}, "2": {"iconAmarr": "res:/UI/Texture/classes/EmpireSelection/factionBanner.png", "titleAmarr": 526224, "iconCaldari": "res:/UI/Texture/classes/EmpireSelection/factionBanner.png", "iconGallente": "res:/UI/Texture/classes/EmpireSelection/factionBanner.png", "iconMinmatar": "res:/UI/Texture/classes/EmpireSelection/factionBanner.png", "titleCaldari": 526225, "subtitleAmarr": 526228, "titleGallente": 526226, "titleMinmatar": 526227, "subtitleCaldari": 526229, "subtitleGallente": 526230, "subtitleMinmatar": 526231}}, "isDisplayed": true, "mainTextAmarr": 526220, "mainViewAmarr": "res:/UI/Texture/classes/EmpireSelection/peoplePortraitAmarr.png", "mainTextCaldari": 526221, "mainViewCaldari": "res:/UI/Texture/classes/EmpireSelection/peoplePortraitCaldari.png", "mainTextGallente": 526222, "mainTextMinmatar": 526223, "mainViewGallente": "res:/UI/Texture/classes/EmpireSelection/peoplePortraitGallente.png", "mainViewMinmatar": "res:/UI/Texture/classes/EmpireSelection/peoplePortraitMinmatar.png"}
3	21	{"_key": 21, "icon": "res:/UI/Texture/classes/EmpireSelection/subnavIntro.png", "order": 1, "title": 526575, "examples": {}, "isDisplayed": false}
\.


--
-- Name: empiretechnologies empiretechnologies_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.empiretechnologies
    ADD CONSTRAINT empiretechnologies_pkey PRIMARY KEY (row_no);


--
-- Name: empiretechnologies_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX empiretechnologies_key_idx ON sde_native.empiretechnologies USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict D2EKelvrdNXyXKa3Keylit6KhV7mhceXRPUYj6QPc2upyZFfMq0cDACMX3NvB0m

