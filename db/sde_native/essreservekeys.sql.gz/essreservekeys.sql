--
-- PostgreSQL database dump
--

\restrict Lo1WTbawsQcyyxzKvoZGWBkDhSTd3pz8tfIyYz8gAYwEfCre4RTRc8hHIntXhXu

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: essreservekeys; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.essreservekeys (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: essreservekeys; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.essreservekeys (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "keyTypeID": 57714, "totalPulses": 15, "locationListID": 4609}
1	2	{"_key": 2, "keyTypeID": 57715, "totalPulses": 45, "locationListID": 4609}
2	3	{"_key": 3, "keyTypeID": 57716, "totalPulses": 15, "locationListID": 4610}
3	4	{"_key": 4, "keyTypeID": 57719, "totalPulses": 45, "locationListID": 4610}
4	5	{"_key": 5, "keyTypeID": 57717, "totalPulses": 15, "locationListID": 4612}
5	6	{"_key": 6, "keyTypeID": 57718, "totalPulses": 45, "locationListID": 4612}
6	7	{"_key": 7, "keyTypeID": 57720, "totalPulses": 15, "locationListID": 4611}
7	8	{"_key": 8, "keyTypeID": 57721, "totalPulses": 45, "locationListID": 4611}
\.


--
-- Name: essreservekeys essreservekeys_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.essreservekeys
    ADD CONSTRAINT essreservekeys_pkey PRIMARY KEY (row_no);


--
-- Name: essreservekeys_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX essreservekeys_key_idx ON sde_native.essreservekeys USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict Lo1WTbawsQcyyxzKvoZGWBkDhSTd3pz8tfIyYz8gAYwEfCre4RTRc8hHIntXhXu

