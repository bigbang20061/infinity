--
-- PostgreSQL database dump
--

\restrict PCn2Drz4GmoUdBiRtaaHenP2TMnxi1Wt9uH1pKZTGdbFdUSEWk6l73eX6F9InNe

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: uihighlights; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.uihighlights (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: uihighlights; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.uihighlights (row_no, key, data) FROM stdin;
0	107	{"_key": 107, "name": "AS0104", "title": 534309, "offset": -20, "message": 534310, "uiClass": "AuraBlue", "uiElementName": "inFlightHighSlot1", "defaultDirection": "up"}
1	108	{"_key": 108, "name": "AS0301", "title": 534361, "message": 534362, "uiClass": "AuraBlue", "uiElementName": "agency"}
2	110	{"_key": 110, "name": "AS0303", "title": 534371, "message": 534372, "uiClass": "AuraBlue", "uiElementName": "careerAgentCardPrimaryButton"}
3	111	{"_key": 111, "name": "AS0304", "title": 534381, "offset": -30, "message": 534382, "uiClass": "AuraBlue", "uiElementName": "undockBtn"}
4	112	{"_key": 112, "name": "AS0302", "title": 535009, "message": 535010, "uiClass": "AuraBlue", "uiElementName": "TutorialCard", "defaultDirection": "down"}
5	113	{"_key": 113, "name": "Industry 2 miner", "title": 537821, "message": 537820, "uiClass": "AuraBlue", "uiElementName": "inFlightHighSlot2", "secondsTilFadeout": 20}
6	118	{"_key": 118, "name": "Mid Slot 1", "title": 538237, "message": 538238, "uiClass": "AuraBlue", "uiElementName": "inFlightMediumSlot1", "defaultDirection": "up"}
7	119	{"_key": 119, "name": "Market", "title": 538244, "message": 538245, "uiClass": "AuraBlue", "uiElementName": "market"}
8	121	{"_key": 121, "name": "Fitting", "title": 540337, "message": 538398, "uiClass": "AuraBlue", "uiElementName": "neocom.fitting"}
9	122	{"_key": 122, "name": "Capacitor", "title": 538428, "message": 538429, "uiClass": "AuraBlue", "uiElementName": "CapacitorContainer"}
10	124	{"_key": 124, "name": "Inventory", "title": 540295, "message": 540294, "uiClass": "AuraBlue", "uiElementName": "inventory"}
11	125	{"_key": 125, "name": "NEOCOM Menu", "title": 540296, "message": 540297, "uiClass": "AuraBlue", "uiElementName": "eveMenuBtn"}
12	126	{"_key": 126, "name": "Character Sheet", "title": 540299, "message": 540300, "uiClass": "AuraBlue", "uiElementName": "charSheetBtn"}
13	127	{"_key": 127, "name": "The Agency", "title": 540301, "message": 540302, "uiClass": "AuraBlue", "uiElementName": "agency"}
14	128	{"_key": 128, "name": "The Agency Filter Settings", "title": 542632, "message": 541971, "uiClass": "AuraBlue", "uiElementName": "contentTypeCombo", "defaultDirection": "up"}
15	133	{"_key": 133, "name": "Handoff 3: Set Destination", "title": 542626, "message": 542024, "uiClass": "AuraBlue", "uiElementName": "careerAgentCardPrimaryButton", "defaultDirection": "up"}
16	134	{"_key": 134, "name": "Undock", "title": 542627, "message": 542087, "uiClass": "AuraBlue", "uiElementName": "undockButton"}
17	135	{"_key": 135, "name": "Handoff 5: Jump through Stargate (Overview)", "title": 542088, "iconID": 24247, "message": 542089, "uiClass": "AuraBlue", "iconSize": 32, "iconColor": [1.0, 1.0, 0.0, 1.0], "uiElementName": "overviewscroll2", "defaultDirection": "left"}
18	136	{"_key": 136, "name": "Handoff 6: Reach destination (Autopilot)", "title": 542628, "offset": -20, "message": 542090, "uiClass": "AuraBlue", "uiElementName": "inFlightAutopilotBtn", "defaultDirection": "left"}
19	137	{"_key": 137, "name": "Handoff 7: Dock at a Career Agent Station", "title": 542629, "iconID": 24240, "message": 542091, "uiClass": "AuraBlue", "iconSize": 32, "iconColor": [1.0, 1.0, 0.0, 1.0], "uiElementName": "overviewscroll2", "defaultDirection": "left"}
20	142	{"_key": 142, "name": "AS01B07: Activate Weapon (Actvate weapon hint)", "title": 542625, "offset": -20, "message": 542107, "uiClass": "AuraBlue", "uiElementName": "inFlightHighSlot1", "defaultDirection": "up"}
21	148	{"_key": 148, "name": "Inventory Item: Light Electron Blaster I", "title": 544773, "message": 544774, "uiClass": "AuraBlue", "uiElementName": "ItemEntry_562", "defaultDirection": "down"}
22	149	{"_key": 149, "name": "Inventory Item: 125mm Railgun I", "title": 544775, "message": 544776, "uiClass": "AuraBlue", "uiElementName": "ItemEntry_10678", "defaultDirection": "down"}
23	150	{"_key": 150, "name": "Inventory Item: 125mm Gatling AutoCannon I", "title": 544777, "message": 544778, "uiClass": "AuraBlue", "uiElementName": "ItemEntry_484", "defaultDirection": "down"}
24	151	{"_key": 151, "name": "Inventory Item: Dual Light Pulse Laser I", "title": 544779, "message": 544780, "uiClass": "AuraBlue", "uiElementName": "ItemEntry_451", "defaultDirection": "down"}
25	152	{"_key": 152, "name": "Inventory Item: Iron Charge S", "title": 544783, "message": 544784, "uiClass": "AuraBlue", "uiElementName": "ItemEntry_215", "defaultDirection": "down"}
26	153	{"_key": 153, "name": "Inventory Item: Carbonized Lead S", "title": 544785, "message": 544786, "uiClass": "AuraBlue", "uiElementName": "ItemEntry_178", "defaultDirection": "down"}
27	154	{"_key": 154, "name": "Inventory Item: Infrared S", "title": 544787, "message": 544788, "uiClass": "AuraBlue", "uiElementName": "ItemEntry_241", "defaultDirection": "down"}
28	165	{"_key": 165, "name": "pointerNeocom", "title": 545076, "message": 545077, "uiClass": "AuraBlue", "uiElementName": "unique_UI_Neocom", "defaultDirection": "right"}
29	167	{"_key": 167, "name": "pointerStationServices", "title": 545080, "offset": 10, "message": 545081, "uiClass": "AuraBlue", "uiElementName": "serviceButtons", "defaultDirection": "left"}
30	180	{"_key": 180, "name": "Battle Intro: Primary Weapon", "title": 545572, "offset": -20, "message": 545573, "uiClass": "AuraBlue", "uiElementName": "ModuleButton_3634", "defaultDirection": "up"}
31	181	{"_key": 181, "name": "Battle Intro: Repairer", "title": 545928, "offset": -20, "message": 545929, "uiClass": "AuraBlue", "uiElementName": "ModuleButton_21853", "defaultDirection": "up"}
32	2217	{"_key": 2217, "name": "Skills Window", "title": 549217, "message": 549218, "uiClass": "AuraBlue", "uiElementName": "neocom.skills"}
33	2218	{"_key": 2218, "name": "Board My Corvette", "title": 549450, "message": 549451, "uiClass": "AuraBlue", "uiElementName": "corvetteButton"}
34	2223	{"_key": 2223, "name": "Tutorial tab in The Agency", "title": 550414, "message": 550415, "uiClass": "AuraBlue", "uiElementName": "AgencyWndNewTabTutorials", "defaultDirection": "up"}
35	2224	{"_key": 2224, "name": "Agents & Missions Tab in The Agency", "title": 550975, "message": 550976, "uiClass": "AuraBlue", "uiElementName": "AgencyWndNewTabAgents&missions", "defaultDirection": "up"}
36	2225	{"_key": 2225, "name": "Career Agents Navigation Card", "title": 550980, "message": 550981, "uiClass": "AuraBlue", "uiElementName": "CareerAgentsNavigationCard", "defaultDirection": "up"}
37	2228	{"_key": 2228, "name": "TutorialInfoPanel", "title": 551540, "message": 551541, "uiClass": "AuraBlue", "uiElementName": "InfoPanelOperations", "defaultDirection": "down"}
38	2229	{"_key": 2229, "name": "overviewHighlight", "title": 552004, "message": 552005, "uiClass": "AuraBlue", "uiElementName": "unique_UI_overviewWnd"}
39	2231	{"_key": 2231, "name": "Inventory Loot All Button", "title": 552156, "message": 552157, "uiClass": "AuraBlue", "uiElementName": "invLootAllBtn"}
40	2235	{"_key": 2235, "name": "Wallet", "title": 552577, "message": 552578, "uiClass": "AuraBlue", "uiElementName": "wallet"}
41	2237	{"_key": 2237, "name": "Dock in Station (overview hint)", "title": 553512, "iconID": 24240, "message": 553513, "uiClass": "AuraBlue", "iconSize": 32, "uiElementName": "overviewscroll2"}
42	2238	{"_key": 2238, "name": "Look for Scrap (Overview Highlight)", "title": 553514, "iconID": 24254, "message": 553515, "uiClass": "AuraBlue", "iconSize": 16, "uiElementName": "overviewscroll2"}
43	2241	{"_key": 2241, "name": "Breadcrumbs_NewItemsInInventory", "message": 553794, "uiClass": "RetroBlack", "audioEffectOn": 0, "uiElementName": "inventory", "secondsTilFadeout": 5}
44	2242	{"_key": 2242, "name": "Breadcrumbs_NewItemsInRedeem", "message": 553796, "uiClass": "RetroBlack", "uiElementName": "newRedeemableItemsNotification", "secondsTilFadeout": 5}
45	2243	{"_key": 2243, "name": "Breadcrumbs_SkillsTrained", "message": 553799, "uiClass": "RetroBlack", "uiElementName": "skillsBtn", "secondsTilFadeout": 10}
46	2244	{"_key": 2244, "name": "Breadcrumbs_SkillPointsAdded", "message": 553801, "uiClass": "RetroBlack", "uiElementName": "skillsBtn", "secondsTilFadeout": 10}
47	2249	{"_key": 2249, "name": "Ship Status (Destroy Seeker)", "title": 553836, "message": 553837, "uiClass": "AuraBlue", "uiElementName": "barAndImageCont", "defaultDirection": "down"}
48	2250	{"_key": 2250, "name": "Orbit Enemy (overview hint)", "title": 553868, "iconID": 24246, "message": 553869, "uiClass": "AuraBlue", "iconSize": 32, "iconColor": [1.0, 0.0, 0.0, 1.0], "uiElementName": "overviewscroll2"}
49	2251	{"_key": 2251, "name": "Lock Target (overview hint)", "title": 553870, "iconID": 24246, "message": 553871, "uiClass": "AuraBlue", "iconSize": 32, "iconColor": [1.0, 0.09804, 0.09804, 1.0], "uiElementName": "overviewscroll2"}
50	2252	{"_key": 2252, "name": "Mouse Over Weapon", "title": 554022, "message": 554023, "uiClass": "AuraBlue", "uiElementName": "inFlightHighSlot1", "defaultDirection": "right"}
51	2257	{"_key": 2257, "name": "Cargo Hold", "title": 554454, "message": 554455, "uiClass": "AuraBlue", "uiElementName": "topCont_ShipCargo"}
52	2259	{"_key": 2259, "name": "Breadcrumbs_SkillsTrainedAndSkillPointsAdded", "message": 555561, "uiClass": "RetroBlack", "uiElementName": "skillsBtn", "secondsTilFadeout": 10}
53	2261	{"_key": 2261, "name": "Breadcrumbs_Insurance", "message": 555572, "uiClass": "RetroBlack", "uiElementName": "insurance", "secondsTilFadeout": 5}
54	2263	{"_key": 2263, "name": "Chat", "title": 561309, "message": 561310, "uiClass": "AuraBlue", "uiElementName": "ChatWindowStack"}
55	2264	{"_key": 2264, "name": "Warp to Location", "title": 561569, "message": 561570, "uiClass": "AuraBlue", "uiElementName": "InfoPanelOperations", "defaultDirection": "down"}
56	2265	{"_key": 2265, "name": "[AIR] SelectedItemPanel", "title": 561575, "message": 561576, "uiClass": "AuraBlue", "uiElementName": "unique_UI_selectedItemView", "defaultDirection": "left"}
57	2266	{"_key": 2266, "name": "ShipInterface(HUD)", "title": 561585, "message": 561584, "uiClass": "AuraBlue", "uiElementName": "unique_UI_hudCenter", "defaultDirection": "up"}
58	2269	{"_key": 2269, "name": "Activate Button", "title": 563625, "message": 563273, "uiClass": "AuraBlue", "uiElementName": "primaryButton"}
59	2272	{"_key": 2272, "name": "Find Tower", "title": 563626, "message": 563627, "uiClass": "AuraBlue", "uiElementName": "overviewscroll2"}
60	2275	{"_key": 2275, "name": "Unfit Weapon", "title": 563967, "message": 563968, "uiClass": "AuraBlue", "uiElementName": "27", "defaultDirection": "left"}
61	2311	{"_key": 2311, "name": "[AIR] Scene 2 - Afterburner Highlight", "message": 577347, "uiClass": "AuraBlue", "uiElementName": "ModuleButton_21857", "defaultDirection": "down"}
62	2312	{"_key": 2312, "name": "[AIR] Scene 2 - Turret", "offset": 64, "message": 577424, "uiClass": "AuraBlue", "uiElementName": "ModuleButton_3634", "defaultDirection": "right"}
63	2314	{"_key": 2314, "name": "[AIR] Scene 2 - Webifier", "message": 577427, "uiClass": "AuraBlue", "uiElementName": "ModuleButton_30328", "defaultDirection": "down"}
64	2315	{"_key": 2315, "name": "[AIR] Scene 2 - ECM", "message": 577430, "uiClass": "AuraBlue", "uiElementName": "ModuleButton_1957", "defaultDirection": "down"}
65	2317	{"_key": 2317, "name": "[AIR] ShipHUD - Blink Shield", "message": 577735, "uiClass": "AuraBlue", "uiElementName": "unique_UI_hudCenter", "additionalEffects": ["blinkShieldGauge"]}
66	2318	{"_key": 2318, "name": "[AIR] ShipHUD - Blink Armor", "message": 577736, "uiClass": "AuraBlue", "uiElementName": "unique_UI_hudCenter", "additionalEffects": ["blinkArmorGauge"]}
67	2319	{"_key": 2319, "name": "ShipHUD - Blink Structure", "message": 577737, "uiClass": "AuraBlue", "uiElementName": "unique_UI_hudCenter", "additionalEffects": ["blinkStructureGauge"]}
68	2324	{"_key": 2324, "name": "[AIR]ShipHUD - Blink Shield", "message": 580873, "uiClass": "AuraBlue", "uiElementName": "unique_UI_hudCenter", "additionalEffects": ["blinkShieldGauge"]}
69	2325	{"_key": 2325, "name": "[AIR]ShipHUD - Blink Armor", "message": 580874, "uiClass": "AuraBlue", "uiElementName": "unique_UI_hudCenter", "additionalEffects": ["blinkArmorGauge"]}
70	2326	{"_key": 2326, "name": "[AIR]ShipHUD - Blink Structure", "message": 580875, "uiClass": "AuraBlue", "uiElementName": "unique_UI_hudCenter", "additionalEffects": ["blinkStructureGauge"]}
71	2332	{"_key": 2332, "name": "[AIR]SelectedItem - Look At", "title": 580953, "message": 580954, "uiClass": "AuraBlue", "uiElementName": "selectedItemLookAt", "defaultDirection": "left"}
72	2335	{"_key": 2335, "name": "[AIR]SelectedItem - Approach", "title": 581000, "message": 581001, "uiClass": "AuraBlue", "uiElementName": "selectedItemApproach"}
73	2337	{"_key": 2337, "name": "[AIR]SelectedItems - Board Ship", "message": 581070, "uiClass": "AuraBlue", "uiElementName": "selectedItemBoardShip"}
74	2339	{"_key": 2339, "name": "Inventory Item: Civilian Gatling Autocannon", "title": 581260, "message": 581261, "uiClass": "AuraBlue", "uiElementName": "ItemEntry_3636", "defaultDirection": "down"}
75	2340	{"_key": 2340, "name": "Inventory Item: Nanofiber Internal Structure", "title": 581262, "message": 581263, "uiClass": "AuraBlue", "uiElementName": "ItemEntry_2603", "defaultDirection": "down"}
76	2341	{"_key": 2341, "name": "Inventory Item: 1MN Civilian Afterburner", "title": 581264, "message": 581265, "uiClass": "AuraBlue", "uiElementName": "ItemEntry_21857", "defaultDirection": "down"}
77	2342	{"_key": 2342, "name": "[AIR] Item Hangar", "title": 581279, "message": 581280, "uiClass": "AuraBlue", "uiElementName": "StationItems", "defaultDirection": "down"}
78	2343	{"_key": 2343, "name": "Inventory Item: Hull Uppgrades", "title": 581382, "message": 581383, "uiClass": "AuraBlue", "uiElementName": "ItemEntry_3394", "defaultDirection": "down"}
79	2344	{"_key": 2344, "name": "Training Que Window", "title": 581400, "message": 581401, "uiClass": "AuraBlue", "uiElementName": "SkillQueuePanel"}
80	2345	{"_key": 2345, "name": "[AIR] Inventory Item: Small Skill Injector", "message": 581837, "uiClass": "AuraBlue", "uiElementName": "ItemEntry_60033", "defaultDirection": "down"}
81	2347	{"_key": 2347, "name": "Corporation", "title": 581867, "message": 581868, "uiClass": "AuraBlue", "uiElementName": "unique_panel.neocom.corporation"}
82	2348	{"_key": 2348, "name": "Station Ship Hangar", "title": 582176, "message": 582177, "uiClass": "AuraBlue", "uiElementName": "topCont_StationShips"}
83	2349	{"_key": 2349, "name": "StationService_Fitting", "title": 582237, "message": 582238, "uiClass": "AuraBlue", "uiElementName": "unique_ui_stationSvc_fitting", "defaultDirection": "up"}
84	2350	{"_key": 2350, "name": "StationService_Inventory", "title": 582266, "message": 582267, "uiClass": "AuraBlue", "uiElementName": "Button_InventoryPanel", "defaultDirection": "up"}
85	2351	{"_key": 2351, "name": "Skill: Armor", "title": 582268, "message": 582269, "uiClass": "AuraBlue", "uiElementName": "SkillGroup_1210"}
86	2352	{"_key": 2352, "name": "[AIR] Skill Points", "message": 582270, "uiClass": "AuraBlue", "uiElementName": "ApplySkillPointsButtonIcon"}
87	2353	{"_key": 2353, "name": "[AIR] Board My Corvette", "title": 584158, "message": 583970, "uiClass": "AuraBlue", "uiElementName": "unique_UI_corvetteBtn"}
88	2354	{"_key": 2354, "name": "[AIR] Inventory Item: Small Armor Repairer I", "title": 584232, "message": 584233, "uiClass": "AuraBlue", "uiElementName": "ItemEntry_523", "defaultDirection": "down"}
89	2355	{"_key": 2355, "name": "[AIR] Inventory Item: Repair Systems", "title": 584599, "message": 584600, "uiClass": "AuraBlue", "uiElementName": "ItemEntry_3393", "defaultDirection": "down"}
90	2356	{"_key": 2356, "name": "[AIR] Agents & Missions Tab in The Agency", "title": 585054, "message": 585055, "uiClass": "AuraBlue", "uiElementName": "AgencyWndNewTabAgents&missions", "defaultDirection": "down"}
91	2357	{"_key": 2357, "name": "[AIR] Career Agents", "message": 585073, "uiClass": "AuraBlue", "audioEffectOn": 0, "uiElementName": "unique_ui_agency_card_21", "defaultDirection": "up"}
92	2358	{"_key": 2358, "name": "[AIR] Career Agent Set Destination Button", "message": 585257, "uiClass": "AuraBlue", "uiElementName": "Agency_CareerAgents_InteractionButton", "defaultDirection": "right"}
93	2359	{"_key": 2359, "name": "[AIR] NPC Corporation Dashboard", "message": 585262, "uiClass": "AuraBlue", "uiElementName": "unique_ui_agency_card_62", "defaultDirection": "up"}
94	2360	{"_key": 2360, "name": "[AIR] Jump Button", "message": 585310, "uiClass": "AuraBlue", "uiElementName": "selectedItemJump"}
95	2361	{"_key": 2361, "name": "[AIR] Dock Button", "message": 585311, "uiClass": "AuraBlue", "uiElementName": "selectedItemDock"}
96	2365	{"_key": 2365, "name": "[AIR] Agents Start Conversation", "message": 585408, "uiClass": "AuraBlue", "uiElementName": "Agency_CareerAgents_InteractionButton", "defaultDirection": "right"}
97	2366	{"_key": 2366, "name": "[AIR] Agents Accept Button", "message": 585409, "uiClass": "AuraBlue", "uiElementName": "Accept_Btn", "defaultDirection": "down"}
98	2367	{"_key": 2367, "name": "[AIR]SelectedItems - Orbit Enemy", "message": 585690, "uiClass": "AuraBlue", "uiElementName": "selectedItemOrbit"}
99	2368	{"_key": 2368, "name": "[AIR]SelectedItems - Lock", "message": 585691, "uiClass": "AuraBlue", "uiElementName": "selectedItemLockTarget"}
100	2370	{"_key": 2370, "name": "[AIR] Confirm Skill Injector", "message": 586292, "uiClass": "AuraBlue", "uiElementName": "Confirm_Btn", "defaultDirection": "down"}
101	2371	{"_key": 2371, "name": "[AIR] Close Window", "message": 586293, "uiClass": "AuraBlue", "uiElementName": "Close_Btn", "defaultDirection": "down"}
102	2372	{"_key": 2372, "name": "[AIR] Skills Window", "message": 586373, "uiClass": "AuraBlue", "uiElementName": "neocom.skills"}
103	2373	{"_key": 2373, "name": "[AIR] AIR Skill plan ", "message": 586375, "uiClass": "AuraBlue", "uiElementName": "SkillPlanEntry_AIR"}
104	2374	{"_key": 2374, "name": "[AIR] Skill Plan Start Training Button", "message": 586376, "uiClass": "AuraBlue", "uiElementName": "startTrainingButton", "defaultDirection": "down"}
105	2375	{"_key": 2375, "name": "[AIR] Fitting Window Attributes", "message": 587102, "uiClass": "AuraBlue", "uiElementName": "ExpandableMenuContainer", "defaultDirection": "up"}
106	2378	{"_key": 2378, "name": "[AIR NPE] Unidentified Signal Source Overview", "message": 587112, "uiClass": "AuraBlue", "uiElementName": "scrollentry_60144", "defaultDirection": "left"}
107	2379	{"_key": 2379, "name": "[AIR NPE] Balin Overview", "message": 587113, "uiClass": "AuraBlue", "uiElementName": "scrollentry_57788", "defaultDirection": "left"}
108	2380	{"_key": 2380, "name": "[AIR]SelectedItems - Orbit Balin", "message": 587554, "uiClass": "AuraBlue", "uiElementName": "selectedItemOrbit"}
109	2382	{"_key": 2382, "name": "[AIR] Inventory Item: Ore", "message": 589337, "uiClass": "AuraBlue", "uiElementName": "ItemEntry_60771", "defaultDirection": "right"}
110	2383	{"_key": 2383, "name": "[AIR] Station Inventory Tree - Ship Cargo", "message": 589338, "uiClass": "AuraBlue", "uiElementName": "ShipHangar"}
111	2384	{"_key": 2384, "name": "[AIR] Station Inventory Tree - Item Hangar", "message": 589339, "uiClass": "AuraBlue", "uiElementName": "ItemHangar", "defaultDirection": "down"}
112	2385	{"_key": 2385, "name": "[AIR] SelectedMiningItems - Lock", "message": 589527, "uiClass": "AuraBlue", "uiElementName": "selectedItemLockTarget"}
113	2386	{"_key": 2386, "name": "[AIR] Scene 4 - Civilian Mining Laser", "message": 589528, "uiClass": "AuraBlue", "uiElementName": "ModuleButton_3651", "defaultDirection": "right"}
114	2387	{"_key": 2387, "name": "[AIR NPE] 5.2 - Sell button", "message": 589687, "uiClass": "AuraBlue", "uiElementName": "Sell_Btn", "defaultDirection": "down"}
115	2388	{"_key": 2388, "name": "[AIR NPE] 5.2 - OK button", "message": 589688, "uiClass": "AuraBlue", "uiElementName": "OK_Btn", "defaultDirection": "down"}
116	2389	{"_key": 2389, "name": "[AIR NPE] 5.3 - Wallet Neocom", "message": 589689, "uiClass": "AuraBlue", "uiElementName": "wallet", "defaultDirection": "right"}
117	2390	{"_key": 2390, "name": "[AIR NPE] 5.4 - Agency Resources tab", "message": 589690, "uiClass": "AuraBlue", "uiElementName": "AgencyWndNewTabResourceharvesting"}
118	2391	{"_key": 2391, "name": "[AIR] Inventory Item: Laser Upgrade I", "title": 590610, "message": 590611, "uiClass": "AuraBlue", "uiElementName": "ItemEntry_22542", "defaultDirection": "down"}
119	2392	{"_key": 2392, "name": "[AIR NPE] 5.3 - Wallet Transactions Tab", "message": 590721, "uiClass": "AuraBlue", "uiElementName": "IskPanelTab_Transactions", "defaultDirection": "down"}
120	2393	{"_key": 2393, "name": "[AIR NPE] 5.3 - Ore Transaction", "message": 590722, "uiClass": "AuraBlue", "uiElementName": "entry_1", "defaultDirection": "down", "secondsTilFadeout": 5}
121	2394	{"_key": 2394, "name": "[AIR] Fitting Window: Incomplete skills", "title": 590801, "message": 590802, "uiClass": "AuraBlue", "uiElementName": "SkillWarningIcon", "defaultDirection": "right"}
122	2395	{"_key": 2395, "name": "[AIR NPE] Overview Tab Mining ", "title": 597777, "message": 591311, "uiClass": "AuraBlue", "uiElementName": "OverviewTab_DefaultPreset_639442", "defaultDirection": "left"}
123	2396	{"_key": 2396, "name": "[AIR NPE] Overview Tab General", "message": 591312, "uiClass": "AuraBlue", "uiElementName": "OverviewTab_General"}
124	2397	{"_key": 2397, "name": "[AIR NPE] Align to", "message": 591313, "uiClass": "AuraBlue", "uiElementName": "selectedItemAlignTo"}
125	2398	{"_key": 2398, "name": "[AIR NPE] Stop Ship", "message": 591317, "uiClass": "AuraBlue", "uiElementName": "unique_UI_StopButton", "defaultDirection": "left"}
126	2399	{"_key": 2399, "name": "[AIR NPE] 4.3 - Open Cargo", "message": 592745, "uiClass": "AuraBlue", "uiElementName": "selectedItemOpenCargo"}
127	2406	{"_key": 2406, "name": "[AIR NPE] 4.3 - Fitting Window: Incomplete skills", "title": 592909, "message": 592911, "uiClass": "AuraBlue", "uiElementName": "TrainNowButton", "defaultDirection": "right"}
128	2407	{"_key": 2407, "name": "[AIR NPE] 4.3 - Loot Wreck", "message": 593089, "uiClass": "AuraBlue", "uiElementName": "invLootAllBtn"}
129	2408	{"_key": 2408, "name": "[AIR NPE] Career Path Generic", "message": 593130, "uiClass": "AuraBlue", "uiElementName": "CareerPathButton_Explorer", "defaultDirection": "down"}
130	2409	{"_key": 2409, "name": "[AIR NPE] Career Path Race Generic", "message": 593587, "uiClass": "AuraBlue", "uiElementName": "", "defaultDirection": "down"}
131	2410	{"_key": 2410, "name": "[AIR NPE] Career Path AIR Skillplan Generic", "message": 593588, "uiClass": "AuraBlue", "uiElementName": "", "defaultDirection": "down"}
132	2411	{"_key": 2411, "name": "[AIR NPE] Object Tracker", "title": 597778, "message": 597779, "uiClass": "AuraBlue", "uiElementName": "ObjectiveLocationButton", "defaultDirection": "right"}
133	2412	{"_key": 2412, "name": "[AIR] Missiondetail", "title": 597865, "message": 597866, "uiClass": "AuraBlue", "uiElementName": "", "defaultDirection": "right"}
134	2413	{"_key": 2413, "name": "[AIR] Undock", "title": 599121, "message": 599122, "uiClass": "AuraBlue", "uiElementName": "unique_UI_undockBtn"}
135	2414	{"_key": 2414, "name": "[AIR]Mission Journal", "title": 599123, "message": 599124, "uiClass": "AuraBlue", "uiElementName": "utilmenu_MissionReadDetails", "defaultDirection": "right"}
136	2419	{"_key": 2419, "name": "Unfit Module", "message": 631740, "uiClass": "AuraBlue", "uiElementName": "", "defaultDirection": "up"}
137	2420	{"_key": 2420, "name": "Fit Module", "message": 631742, "uiClass": "AuraBlue", "uiElementName": "", "defaultDirection": "right"}
138	2422	{"_key": 2422, "name": "Station Services - Reprocessing Plant Button", "message": 635097, "uiClass": "AuraBlue", "uiElementName": ""}
139	2423	{"_key": 2423, "name": "Station Services - Industry", "message": 635098, "uiClass": "AuraBlue", "uiElementName": ""}
140	2424	{"_key": 2424, "name": "Stacking Guidance", "message": 635790, "uiClass": "AuraBlue", "uiElementName": "", "defaultDirection": "right"}
141	2425	{"_key": 2425, "name": "Combine items in one inventory container", "message": 635818, "uiClass": "AuraBlue", "uiElementName": "", "defaultDirection": "right"}
142	2426	{"_key": 2426, "name": "Assemble and Activate ship", "title": 636096, "message": 636097, "uiClass": "AuraBlue", "uiElementName": "", "defaultDirection": "right"}
143	2427	{"_key": 2427, "name": "Ore Anomalies Window - Security Status", "message": 638143, "uiClass": "AuraBlue", "uiElementName": "", "defaultDirection": "left"}
144	2435	{"_key": 2435, "name": "Drag The Item Here", "message": 639727, "uiClass": "AuraBlue", "uiElementName": "", "defaultDirection": "down"}
145	2440	{"_key": 2440, "name": "[NES Intro] Highlight NES button", "title": 641499, "message": 641500, "uiClass": "AuraBlue", "uiElementName": "AurumStoreBtnDataNode"}
146	2441	{"_key": 2441, "name": "[NES Intro] Highlight Redeem Queue", "title": 641501, "message": 641502, "uiClass": "AuraBlue", "uiElementName": "newRedeemableItemsNotification"}
147	2444	{"_key": 2444, "name": "changefittingplan", "message": 655328, "uiClass": "AuraBlue", "uiElementName": "changefittingplan", "defaultDirection": "up"}
148	2445	{"_key": 2445, "name": "brawlfittingplanentry1", "message": 655328, "uiClass": "AuraBlue", "uiElementName": "brawlfittingplanentry1", "defaultDirection": "up"}
149	2446	{"_key": 2446, "name": "confirmselected", "message": 655328, "uiClass": "AuraBlue", "uiElementName": "confirmselected", "defaultDirection": "up"}
150	2447	{"_key": 2447, "name": "startsearch", "message": 655328, "uiClass": "AuraBlue", "uiElementName": "startsearch", "defaultDirection": "up"}
151	2448	{"_key": 2448, "name": "brawlmapzonenode1152923", "message": 655328, "uiClass": "AuraBlue", "uiElementName": "brawlmapzonenode1152923", "defaultDirection": "up"}
152	2449	{"_key": 2449, "name": "map_container", "message": 656092, "uiClass": "AuraBlue", "uiElementName": "map_container", "defaultDirection": "down"}
153	2450	{"_key": 2450, "name": "skillCont", "message": 656092, "uiClass": "AuraBlue", "uiElementName": "skillCont", "defaultDirection": "up"}
154	2451	{"_key": 2451, "name": "skillUpgradeButton", "message": 655328, "uiClass": "AuraBlue", "uiElementName": "skillUpgradeButton", "defaultDirection": "up"}
155	2452	{"_key": 2452, "name": "inFlightCargoBtn", "message": 655328, "uiClass": "AuraBlue", "uiElementName": "inFlightCargoBtn", "defaultDirection": "up"}
156	2453	{"_key": 2453, "name": "ItemEntry_76471", "message": 656092, "uiClass": "AuraBlue", "uiElementName": "ItemEntry_76471", "defaultDirection": "right"}
157	2454	{"_key": 2454, "name": "overview", "message": 656092, "uiClass": "AuraBlue", "uiElementName": "overview", "defaultDirection": "up"}
158	2455	{"_key": 2455, "name": "invLootAllBtn", "message": 655328, "uiClass": "AuraBlue", "uiElementName": "invLootAllBtn", "defaultDirection": "up"}
159	2456	{"_key": 2456, "name": "ItemEntry_73357", "message": 656976, "uiClass": "AuraBlue", "uiElementName": "ItemEntry_73357", "defaultDirection": "up"}
160	2457	{"_key": 2457, "name": "14", "offset": 50, "message": 656977, "uiClass": "AuraBlue", "uiElementName": "14", "defaultDirection": "up"}
161	2458	{"_key": 2458, "name": "quickfittingbtn", "message": 655328, "uiClass": "AuraBlue", "uiElementName": "quickfittingbtn", "defaultDirection": "up"}
162	2459	{"_key": 2459, "name": "fitting", "message": 655328, "uiClass": "AuraBlue", "uiElementName": "fitting", "defaultDirection": "right"}
163	2460	{"_key": 2460, "name": "brawlmapzonenode1152935", "message": 656092, "uiClass": "AuraBlue", "uiElementName": "brawlmapzonenode1152935", "defaultDirection": "down"}
164	2461	{"_key": 2461, "name": "overviewscroll2", "message": 657175, "uiClass": "AuraBlue", "uiElementName": "overviewscroll2", "defaultDirection": "left"}
165	2462	{"_key": 2462, "name": "selectedItemApproach", "message": 655328, "uiClass": "AuraBlue", "uiElementName": "selectedItemApproach", "defaultDirection": "left"}
166	2463	{"_key": 2463, "name": "selectedItemActivateGate", "message": 655328, "uiClass": "AuraBlue", "uiElementName": "selectedItemActivateGate", "defaultDirection": "up"}
167	2464	{"_key": 2464, "name": "BrawlGasCloudEntry", "message": 655328, "uiClass": "AuraBlue", "uiElementName": "BrawlGasCloudEntry", "defaultDirection": "up"}
168	2465	{"_key": 2465, "name": "BrawlSkillEntry", "message": 655328, "uiClass": "AuraBlue", "uiElementName": "BrawlSkillEntry", "defaultDirection": "left"}
169	2466	{"_key": 2466, "name": "[AIR] 2.4.01 - Agent Panel", "message": 696718, "uiClass": "AuraBlue", "uiElementName": "", "defaultDirection": "left"}
170	2467	{"_key": 2467, "name": "[AIR] 2.2.04 - ACP Nodes", "message": 696719, "uiClass": "AuraBlue", "uiElementName": ""}
171	2468	{"_key": 2468, "name": "[AIR] 1.5.07 - Accept", "message": 696720, "uiClass": "AuraBlue", "uiElementName": "", "defaultDirection": "right"}
172	2469	{"_key": 2469, "name": "[AIR] 1.5.07 - Opportunity Section", "message": 696744, "uiClass": "AuraBlue", "uiElementName": "", "defaultDirection": "right"}
173	2470	{"_key": 2470, "name": "[AIR] 2.1.01 - Warp", "message": 696745, "uiClass": "AuraBlue", "uiElementName": "", "defaultDirection": "down"}
174	2471	{"_key": 2471, "name": "[AIR] 1.3.02 - Claim Reward", "message": 696746, "uiClass": "AuraBlue", "uiElementName": "", "defaultDirection": "right"}
175	2472	{"_key": 2472, "name": "[AIR] 1.3.03 - Redeeming", "message": 641502, "uiClass": "AuraBlue", "uiElementName": "", "defaultDirection": "right"}
176	2473	{"_key": 2473, "name": "[AIR] 2.4.03 - Details", "message": 597866, "uiClass": "AuraBlue", "uiElementName": "", "defaultDirection": "up"}
177	2474	{"_key": 2474, "name": "[AIR] 2.4.03 - Skill Warning", "message": 590802, "uiClass": "AuraBlue", "uiElementName": "", "defaultDirection": "right"}
178	2475	{"_key": 2475, "name": "[AIR] 1.5.04 - Wait For Skill", "message": 697777, "uiClass": "AuraBlue", "uiElementName": "", "defaultDirection": "left"}
179	2479	{"_key": 2479, "name": "TransferredItems", "message": 863245, "uiClass": "RetroBlack", "uiElementName": "inventory", "secondsTilFadeout": 5}
180	2480	{"_key": 2480, "name": "[GREAD] M2 - Mining Surveyor", "title": 1030696, "message": 1030695, "uiClass": "AuraBlue", "uiElementName": "LeftSideButtonMiningScan", "defaultDirection": "up"}
181	2482	{"_key": 2482, "name": "[AIR]SelectedItem - Approach (Generic)", "title": 580999, "message": 581001, "uiClass": "AuraBlue", "uiElementName": "selectedItemApproach"}
\.


--
-- Name: uihighlights uihighlights_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.uihighlights
    ADD CONSTRAINT uihighlights_pkey PRIMARY KEY (row_no);


--
-- Name: uihighlights_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX uihighlights_key_idx ON sde_native.uihighlights USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict PCn2Drz4GmoUdBiRtaaHenP2TMnxi1Wt9uH1pKZTGdbFdUSEWk6l73eX6F9InNe

