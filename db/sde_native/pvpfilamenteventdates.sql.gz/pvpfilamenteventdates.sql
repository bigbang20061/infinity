--
-- PostgreSQL database dump
--

\restrict cnIbbVfMdANoNeIrBI1AgsbVEPGb5eZVmtxgJlFuwBjqCESGjps9a0RhHNQi25o

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: pvpfilamenteventdates; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.pvpfilamenteventdates (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: pvpfilamenteventdates; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.pvpfilamenteventdates (row_no, key, data) FROM stdin;
0	1	{"QA": 1, "_key": 1, "region": "ccp", "endDate": "2020-07-13", "startDate": "2020-06-30", "matchTypeID": 1}
1	11	{"QA": 1, "_key": 11, "region": "ccp", "endDate": "2020-07-10", "startDate": "2020-06-30", "matchTypeID": 4}
2	12	{"QA": 1, "_key": 12, "region": "ccp", "endDate": "2020-07-13", "startDate": "2020-06-30", "matchTypeID": 7}
3	13	{"QA": 1, "_key": 13, "region": "ccp", "endDate": "2020-07-13", "startDate": "2020-06-30", "matchTypeID": 8}
4	14	{"QA": 1, "_key": 14, "region": "ccp", "endDate": "2020-07-13", "startDate": "2020-06-30", "matchTypeID": 6}
5	15	{"QA": 0, "_key": 15, "region": "ccp", "endDate": "2020-07-09", "startDate": "2020-06-30", "matchTypeID": 9}
6	16	{"QA": 0, "_key": 16, "region": "ccp", "endDate": "2020-07-14", "startDate": "2020-07-09", "matchTypeID": 11}
7	20	{"QA": 0, "_key": 20, "region": "ccp", "endDate": "2020-07-28", "startDate": "2020-07-16", "matchTypeID": 9}
8	21	{"QA": 0, "_key": 21, "region": "optic", "endDate": "2020-08-03", "startDate": "2020-07-23", "matchTypeID": 9}
9	22	{"QA": 0, "_key": 22, "region": "ccp", "endDate": "2020-08-04", "startDate": "2020-07-31", "matchTypeID": 11}
10	23	{"QA": 0, "_key": 23, "region": "ccp", "endDate": "2020-08-11", "startDate": "2020-08-07", "matchTypeID": 14}
11	24	{"QA": 0, "_key": 24, "region": "optic", "endDate": "2020-08-10", "startDate": "2020-08-06", "matchTypeID": 11}
12	25	{"QA": 0, "_key": 25, "region": "optic", "endDate": "2020-08-17", "startDate": "2020-08-13", "matchTypeID": 14}
13	26	{"QA": 0, "_key": 26, "region": "ccp", "endDate": "2020-08-25", "startDate": "2020-08-21", "matchTypeID": 15}
14	27	{"QA": 0, "_key": 27, "region": "ccp", "endDate": "2020-09-01", "startDate": "2020-08-28", "matchTypeID": 16}
15	28	{"QA": 0, "_key": 28, "region": "ccp", "endDate": "2020-09-08", "startDate": "2020-09-04", "matchTypeID": 17}
16	29	{"QA": 0, "_key": 29, "region": "optic", "endDate": "2020-08-31", "startDate": "2020-08-27", "matchTypeID": 15}
17	30	{"QA": 0, "_key": 30, "region": "optic", "endDate": "2020-09-07", "startDate": "2020-09-03", "matchTypeID": 16}
18	31	{"QA": 0, "_key": 31, "region": "optic", "endDate": "2020-09-14", "startDate": "2020-09-10", "matchTypeID": 17}
19	34	{"QA": 0, "_key": 34, "region": "ccp", "endDate": "2020-09-22", "startDate": "2020-09-18", "matchTypeID": 19}
20	35	{"QA": 0, "_key": 35, "region": "ccp", "endDate": "2020-09-29", "startDate": "2020-09-25", "matchTypeID": 20}
21	36	{"QA": 0, "_key": 36, "region": "ccp", "endDate": "2020-10-06", "startDate": "2020-10-02", "matchTypeID": 21}
22	38	{"QA": 0, "_key": 38, "region": "optic", "endDate": "2020-09-28", "startDate": "2020-09-24", "matchTypeID": 19}
23	39	{"QA": 0, "_key": 39, "region": "optic", "endDate": "2020-10-08", "startDate": "2020-10-01", "matchTypeID": 20}
24	40	{"QA": 0, "_key": 40, "region": "optic", "endDate": "2020-10-19", "startDate": "2020-10-15", "matchTypeID": 21}
25	44	{"QA": 0, "_key": 44, "region": "ccp", "endDate": "2020-11-03", "startDate": "2020-10-30", "matchTypeID": 22}
26	45	{"QA": 0, "_key": 45, "region": "optic", "endDate": "2020-11-09", "startDate": "2020-11-05", "matchTypeID": 22}
27	46	{"QA": 0, "_key": 46, "region": "ccp", "endDate": "2020-11-24", "startDate": "2020-11-20", "matchTypeID": 23}
28	47	{"QA": 0, "_key": 47, "region": "optic", "endDate": "2020-11-30", "startDate": "2020-11-26", "matchTypeID": 23}
29	50	{"QA": 0, "_key": 50, "region": "ccp", "endDate": "2020-12-08", "startDate": "2020-12-04", "matchTypeID": 25}
30	53	{"QA": 0, "_key": 53, "region": "ccp", "endDate": "2020-12-22", "startDate": "2020-12-18", "matchTypeID": 27}
31	54	{"QA": 0, "_key": 54, "region": "ccp", "endDate": "2021-01-05", "startDate": "2021-01-01", "matchTypeID": 28}
32	55	{"QA": 0, "_key": 55, "region": "optic", "endDate": "2020-12-21", "startDate": "2020-12-17", "matchTypeID": 25}
33	56	{"QA": 0, "_key": 56, "region": "optic", "endDate": "2020-12-28", "startDate": "2020-12-24", "matchTypeID": 27}
34	57	{"QA": 0, "_key": 57, "region": "optic", "endDate": "2021-01-11", "startDate": "2021-01-07", "matchTypeID": 28}
35	58	{"QA": 0, "_key": 58, "region": "ccp", "endDate": "2021-01-19", "startDate": "2021-01-15", "matchTypeID": 29}
36	59	{"QA": 0, "_key": 59, "region": "ccp", "endDate": "2021-02-02", "startDate": "2021-01-29", "matchTypeID": 30}
37	60	{"QA": 0, "_key": 60, "region": "optic", "endDate": "2021-01-31", "startDate": "2021-01-28", "matchTypeID": 29}
38	61	{"QA": 0, "_key": 61, "region": "optic", "endDate": "2021-02-07", "startDate": "2021-02-04", "matchTypeID": 30}
39	62	{"QA": 0, "_key": 62, "region": "ccp", "endDate": "2021-02-16", "startDate": "2021-02-12", "matchTypeID": 31}
40	63	{"QA": 0, "_key": 63, "region": "ccp", "endDate": "2021-03-02", "startDate": "2021-02-26", "matchTypeID": 32}
41	64	{"QA": 0, "_key": 64, "region": "optic", "endDate": "2021-02-28", "startDate": "2021-02-25", "matchTypeID": 31}
42	65	{"QA": 0, "_key": 65, "region": "optic", "endDate": "2021-03-07", "startDate": "2021-03-04", "matchTypeID": 32}
43	66	{"QA": 0, "_key": 66, "region": "ccp", "endDate": "2021-03-16", "startDate": "2021-03-12", "matchTypeID": 33}
44	67	{"QA": 0, "_key": 67, "region": "ccp", "endDate": "2021-03-30", "startDate": "2021-03-26", "matchTypeID": 34}
45	68	{"QA": 0, "_key": 68, "region": "ccp", "endDate": "2021-04-13", "startDate": "2021-04-09", "matchTypeID": 35}
46	69	{"QA": 0, "_key": 69, "region": "optic", "endDate": "2021-03-22", "startDate": "2021-03-19", "matchTypeID": 33}
47	70	{"QA": 0, "_key": 70, "region": "optic", "endDate": "2021-04-06", "startDate": "2021-04-02", "matchTypeID": 34}
48	71	{"QA": 0, "_key": 71, "region": "optic", "endDate": "2021-04-27", "startDate": "2021-04-23", "matchTypeID": 35}
49	72	{"QA": 0, "_key": 72, "region": "ccp", "endDate": "2021-04-27", "startDate": "2021-04-23", "matchTypeID": 36}
50	73	{"QA": 0, "_key": 73, "region": "optic", "endDate": "2021-05-06", "startDate": "2021-04-30", "matchTypeID": 36}
51	74	{"QA": 0, "_key": 74, "region": "ccp", "endDate": "2021-05-11", "startDate": "2021-05-07", "matchTypeID": 38}
52	75	{"QA": 0, "_key": 75, "region": "ccp", "endDate": "2021-05-25", "startDate": "2021-05-21", "matchTypeID": 39}
53	76	{"QA": 0, "_key": 76, "region": "optic", "endDate": "2021-06-01", "startDate": "2021-05-28", "matchTypeID": 39}
54	78	{"QA": 0, "_key": 78, "region": "ccp", "endDate": "2021-06-22", "startDate": "2021-06-18", "matchTypeID": 41}
55	79	{"QA": 0, "_key": 79, "region": "ccp", "endDate": "2021-06-06", "startDate": "2021-06-05", "matchTypeID": 40}
56	83	{"QA": 0, "_key": 83, "region": "optic", "endDate": "2021-06-29", "startDate": "2021-06-25", "matchTypeID": 41}
57	84	{"QA": 0, "_key": 84, "region": "optic", "endDate": "2021-06-20", "startDate": "2021-06-19", "matchTypeID": 40}
58	85	{"QA": 0, "_key": 85, "region": "ccp", "endDate": "2021-07-06", "startDate": "2021-07-02", "matchTypeID": 42}
59	86	{"QA": 0, "_key": 86, "region": "ccp", "endDate": "2021-07-20", "startDate": "2021-07-16", "matchTypeID": 43}
60	87	{"QA": 0, "_key": 87, "region": "optic", "endDate": "2021-07-27", "startDate": "2021-07-23", "matchTypeID": 43}
61	88	{"QA": 0, "_key": 88, "region": "ccp", "endDate": "2021-08-01", "startDate": "2021-07-31", "matchTypeID": 44}
62	89	{"QA": 0, "_key": 89, "region": "ccp", "endDate": "2021-08-10", "startDate": "2021-08-06", "matchTypeID": 45}
63	90	{"QA": 0, "_key": 90, "region": "optic", "endDate": "2021-08-08", "startDate": "2021-08-07", "matchTypeID": 44}
64	91	{"QA": 0, "_key": 91, "region": "optic", "endDate": "2021-08-17", "startDate": "2021-08-13", "matchTypeID": 45}
65	93	{"QA": 0, "_key": 93, "region": "optic", "endDate": "2021-08-31", "startDate": "2021-08-27", "matchTypeID": 50}
66	95	{"QA": 0, "_key": 95, "region": "ccp", "endDate": "2021-08-31", "startDate": "2021-08-27", "matchTypeID": 50}
67	96	{"QA": 0, "_key": 96, "region": "ccp", "endDate": "2021-09-07", "startDate": "2021-09-03", "matchTypeID": 51}
68	97	{"QA": 0, "_key": 97, "region": "optic", "endDate": "2021-09-14", "startDate": "2021-09-10", "matchTypeID": 51}
69	99	{"QA": 0, "_key": 99, "region": "ccp", "endDate": "2021-09-21", "startDate": "2021-09-17", "matchTypeID": 52}
70	104	{"QA": 0, "_key": 104, "region": "ccp", "endDate": "2021-10-05", "startDate": "2021-10-01", "matchTypeID": 53}
71	105	{"QA": 0, "_key": 105, "region": "ccp", "endDate": "2021-10-10", "startDate": "2021-10-09", "matchTypeID": 54}
72	106	{"QA": 0, "_key": 106, "region": "ccp", "endDate": "2021-10-17", "startDate": "2021-10-16", "matchTypeID": 63}
73	114	{"QA": 0, "_key": 114, "region": "optic", "endDate": "2021-12-20", "startDate": "2021-09-30", "matchTypeID": 69}
74	115	{"QA": 0, "_key": 115, "region": "optic", "endDate": "2021-12-20", "startDate": "2021-09-30", "matchTypeID": 70}
75	116	{"QA": 0, "_key": 116, "region": "optic", "endDate": "2021-12-20", "startDate": "2021-10-05", "matchTypeID": 71}
76	117	{"QA": 0, "_key": 117, "region": "optic", "endDate": "2021-12-20", "startDate": "2021-10-05", "matchTypeID": 72}
77	118	{"QA": 0, "_key": 118, "region": "ccp", "endDate": "2021-11-02", "startDate": "2021-10-29", "matchTypeID": 73}
78	119	{"QA": 0, "_key": 119, "region": "ccp", "endDate": "2021-11-07", "startDate": "2021-11-06", "matchTypeID": 74}
79	120	{"QA": 0, "_key": 120, "region": "ccp", "endDate": "2021-11-08", "startDate": "2021-11-07", "matchTypeID": 75}
80	122	{"QA": 0, "_key": 122, "region": "ccp", "endDate": "2021-11-14", "startDate": "2021-11-13", "matchTypeID": 80}
81	123	{"QA": 0, "_key": 123, "region": "ccp", "endDate": "2021-11-15", "startDate": "2021-11-14", "matchTypeID": 81}
82	124	{"QA": 0, "_key": 124, "region": "ccp", "endDate": "2021-11-30", "startDate": "2021-11-26", "matchTypeID": 82}
83	125	{"QA": 0, "_key": 125, "region": "ccp", "endDate": "2021-12-14", "startDate": "2021-12-10", "matchTypeID": 83}
84	126	{"QA": 0, "_key": 126, "region": "ccp", "endDate": "2021-12-19", "startDate": "2021-12-18", "matchTypeID": 84}
85	127	{"QA": 0, "_key": 127, "region": "ccp", "endDate": "2022-01-04", "startDate": "2021-12-31", "matchTypeID": 85}
86	128	{"QA": 0, "_key": 128, "region": "ccp", "endDate": "2022-01-09", "startDate": "2022-01-08", "matchTypeID": 86}
87	129	{"QA": 0, "_key": 129, "region": "ccp", "endDate": "2022-01-23", "startDate": "2022-01-22", "matchTypeID": 88}
88	130	{"QA": 0, "_key": 130, "region": "ccp", "endDate": "2022-02-01", "startDate": "2022-01-28", "matchTypeID": 89}
89	131	{"QA": 0, "_key": 131, "region": "ccp", "endDate": "2022-02-15", "startDate": "2022-02-11", "matchTypeID": 90}
90	132	{"QA": 0, "_key": 132, "region": "ccp", "endDate": "2022-02-28", "startDate": "2022-02-26", "matchTypeID": 91}
91	133	{"QA": 0, "_key": 133, "region": "ccp", "endDate": "2022-03-14", "startDate": "2022-03-12", "matchTypeID": 93}
92	136	{"QA": 0, "_key": 136, "region": "optic", "endDate": "2022-03-28", "startDate": "2022-03-17", "matchTypeID": 94}
93	137	{"QA": 0, "_key": 137, "region": "ccp", "endDate": "2022-03-22", "startDate": "2022-03-18", "matchTypeID": 96}
94	138	{"QA": 0, "_key": 138, "region": "ccp", "endDate": "2022-04-05", "startDate": "2022-04-01", "matchTypeID": 97}
95	140	{"QA": 0, "_key": 140, "region": "ccp", "endDate": "2022-04-18", "startDate": "2022-04-15", "matchTypeID": 98}
96	141	{"QA": 0, "_key": 141, "region": "ccp", "endDate": "2022-04-24", "startDate": "2022-04-23", "matchTypeID": 99}
97	142	{"QA": 0, "_key": 142, "region": "ccp", "endDate": "2022-05-09", "startDate": "2022-05-06", "matchTypeID": 100}
98	144	{"QA": 0, "_key": 144, "region": "ccp", "endDate": "2022-05-23", "startDate": "2022-05-20", "matchTypeID": 101}
99	145	{"QA": 0, "_key": 145, "region": "ccp", "endDate": "2022-06-05", "startDate": "2022-06-04", "matchTypeID": 105}
100	146	{"QA": 0, "_key": 146, "region": "optic", "endDate": "2022-06-20", "startDate": "2022-06-09", "matchTypeID": 89}
101	147	{"QA": 0, "_key": 147, "region": "ccp", "endDate": "2022-06-06", "startDate": "2022-06-05", "matchTypeID": 106}
102	148	{"QA": 0, "_key": 148, "region": "ccp", "endDate": "2022-06-12", "startDate": "2022-06-11", "matchTypeID": 107}
103	149	{"QA": 0, "_key": 149, "region": "ccp", "endDate": "2022-06-13", "startDate": "2022-06-12", "matchTypeID": 108}
104	150	{"QA": 0, "_key": 150, "region": "ccp", "endDate": "2022-06-27", "startDate": "2022-06-24", "matchTypeID": 109}
105	151	{"QA": 0, "_key": 151, "region": "ccp", "endDate": "2022-07-18", "startDate": "2022-07-15", "matchTypeID": 110}
106	154	{"QA": 0, "_key": 154, "region": "ccp", "endDate": "2022-07-25", "startDate": "2022-07-23", "matchTypeID": 111}
107	155	{"QA": 0, "_key": 155, "region": "ccp", "endDate": "2022-08-08", "startDate": "2022-08-05", "matchTypeID": 113}
108	156	{"QA": 0, "_key": 156, "region": "ccp", "endDate": "2022-08-22", "startDate": "2022-08-19", "matchTypeID": 114}
109	157	{"QA": 0, "_key": 157, "region": "ccp", "endDate": "2022-09-05", "startDate": "2022-09-02", "matchTypeID": 115}
110	158	{"QA": 0, "_key": 158, "region": "ccp", "endDate": "2022-09-12", "startDate": "2022-09-10", "matchTypeID": 116}
111	159	{"QA": 0, "_key": 159, "region": "ccp", "endDate": "2022-09-26", "startDate": "2022-09-24", "matchTypeID": 117}
112	160	{"QA": 0, "_key": 160, "region": "ccp", "endDate": "2022-10-16", "startDate": "2022-10-15", "matchTypeID": 118}
113	161	{"QA": 0, "_key": 161, "region": "ccp", "endDate": "2022-10-31", "startDate": "2022-10-28", "matchTypeID": 119}
114	162	{"QA": 0, "_key": 162, "region": "ccp", "endDate": "2022-11-13", "startDate": "2022-11-12", "matchTypeID": 120}
115	163	{"QA": 0, "_key": 163, "region": "ccp", "endDate": "2022-11-14", "startDate": "2022-11-13", "matchTypeID": 121}
116	164	{"QA": 0, "_key": 164, "region": "ccp", "endDate": "2022-11-20", "startDate": "2022-11-19", "matchTypeID": 122}
117	165	{"QA": 0, "_key": 165, "region": "ccp", "endDate": "2022-11-21", "startDate": "2022-11-20", "matchTypeID": 123}
118	166	{"QA": 0, "_key": 166, "region": "ccp", "endDate": "2022-11-28", "startDate": "2022-11-25", "matchTypeID": 124}
119	167	{"QA": 0, "_key": 167, "region": "ccp", "endDate": "2022-12-12", "startDate": "2022-12-10", "matchTypeID": 125}
120	168	{"QA": 0, "_key": 168, "region": "ccp", "endDate": "2022-12-19", "startDate": "2022-12-16", "matchTypeID": 126}
121	169	{"QA": 0, "_key": 169, "region": "ccp", "endDate": "2023-01-02", "startDate": "2022-12-30", "matchTypeID": 127}
122	170	{"QA": 0, "_key": 170, "region": "ccp", "endDate": "2023-01-08", "startDate": "2023-01-07", "matchTypeID": 128}
123	171	{"QA": 0, "_key": 171, "region": "ccp", "endDate": "2023-01-16", "startDate": "2023-01-14", "matchTypeID": 129}
\.


--
-- Name: pvpfilamenteventdates pvpfilamenteventdates_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.pvpfilamenteventdates
    ADD CONSTRAINT pvpfilamenteventdates_pkey PRIMARY KEY (row_no);


--
-- Name: pvpfilamenteventdates_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX pvpfilamenteventdates_key_idx ON sde_native.pvpfilamenteventdates USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict cnIbbVfMdANoNeIrBI1AgsbVEPGb5eZVmtxgJlFuwBjqCESGjps9a0RhHNQi25o

