--
-- PostgreSQL database dump
--

\restrict pJKp7zbOshMbD785h8l5KPq8PNPoXRX9yrDk6gsnJFLvEn1ksZauvq2RAxCHiUq

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: character_colornames; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.character_colornames (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: character_colornames; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.character_colornames (row_no, key, data) FROM stdin;
0	2	{"_key": 2, "colorName": "gold", "hairColor": 0}
1	3	{"_key": 3, "colorName": "03_a", "hairColor": 1}
2	4	{"_key": 4, "colorName": "intaki_dark", "hairColor": 0}
3	5	{"_key": 5, "colorName": "vherokior_default", "hairColor": 0}
4	6	{"_key": 6, "colorName": "generic02", "hairColor": 0}
5	7	{"_key": 7, "colorName": "pink_medium", "hairColor": 0}
6	8	{"_key": 8, "colorName": "yellow", "hairColor": 0}
7	9	{"_key": 9, "colorName": "generic01", "hairColor": 0}
8	10	{"_key": 10, "colorName": "13_a", "hairColor": 1}
9	11	{"_key": 11, "colorName": "aqua_a", "hairColor": 0}
10	12	{"_key": 12, "colorName": "greenblue_abc", "hairColor": 0}
11	13	{"_key": 13, "colorName": "red_matte", "hairColor": 0}
12	14	{"_key": 14, "colorName": "20_a", "hairColor": 1}
13	15	{"_key": 15, "colorName": "08_bc", "hairColor": 1}
14	16	{"_key": 16, "colorName": "gallente", "hairColor": 0}
15	17	{"_key": 17, "colorName": "orange_a", "hairColor": 0}
16	18	{"_key": 18, "colorName": "amarr_dark", "hairColor": 0}
17	19	{"_key": 19, "colorName": "rosered_a", "hairColor": 0}
18	20	{"_key": 20, "colorName": "green_abc", "hairColor": 0}
19	21	{"_key": 21, "colorName": "16_bc", "hairColor": 1}
20	22	{"_key": 22, "colorName": "28_bc", "hairColor": 1}
21	23	{"_key": 23, "colorName": "14_bc", "hairColor": 1}
22	24	{"_key": 24, "colorName": "black", "hairColor": 0}
23	25	{"_key": 25, "colorName": "05_a", "hairColor": 1}
24	26	{"_key": 26, "colorName": "nikunni_light", "hairColor": 0}
25	27	{"_key": 27, "colorName": "silver_light_medium", "hairColor": 0}
26	28	{"_key": 28, "colorName": "orange", "hairColor": 0}
27	29	{"_key": 29, "colorName": "22_a", "hairColor": 1}
28	30	{"_key": 30, "colorName": "24_bc", "hairColor": 1}
29	31	{"_key": 31, "colorName": "gallente_dark", "hairColor": 0}
30	32	{"_key": 32, "colorName": "warmgray_bc", "hairColor": 0}
31	33	{"_key": 33, "colorName": "goldgreen_a", "hairColor": 0}
32	34	{"_key": 34, "colorName": "brown", "hairColor": 0}
33	35	{"_key": 35, "colorName": "silver_a", "hairColor": 0}
34	36	{"_key": 36, "colorName": "deteis", "hairColor": 0}
35	37	{"_key": 37, "colorName": "09_a", "hairColor": 1}
36	38	{"_key": 38, "colorName": "amarr", "hairColor": 0}
37	39	{"_key": 39, "colorName": "blue_medium", "hairColor": 0}
38	40	{"_key": 40, "colorName": "circlewhite", "hairColor": 0}
39	41	{"_key": 41, "colorName": "warmgray_a", "hairColor": 0}
40	42	{"_key": 42, "colorName": "civire_light", "hairColor": 0}
41	43	{"_key": 43, "colorName": "intaki_midlight", "hairColor": 0}
42	44	{"_key": 44, "colorName": "07_a", "hairColor": 1}
43	45	{"_key": 45, "colorName": "vherockior", "hairColor": 0}
44	46	{"_key": 46, "colorName": "silver", "hairColor": 0}
45	47	{"_key": 47, "colorName": "gold_bc", "hairColor": 0}
46	48	{"_key": 48, "colorName": "aqua_bc", "hairColor": 0}
47	49	{"_key": 49, "colorName": "hazel_abc", "hairColor": 0}
48	50	{"_key": 50, "colorName": "darkgreen_abc", "hairColor": 0}
49	51	{"_key": 51, "colorName": "03_bc", "hairColor": 1}
50	52	{"_key": 52, "colorName": "01_a", "hairColor": 1}
51	53	{"_key": 53, "colorName": "vherokior_light", "hairColor": 0}
52	54	{"_key": 54, "colorName": "sebiestor_default", "hairColor": 0}
53	55	{"_key": 55, "colorName": "goldengraved", "hairColor": 0}
54	56	{"_key": 56, "colorName": "gallente_middark", "hairColor": 0}
55	57	{"_key": 57, "colorName": "deteis_midlight", "hairColor": 0}
56	58	{"_key": 58, "colorName": "purple_bc", "hairColor": 0}
57	59	{"_key": 59, "colorName": "silver_dark_glossy", "hairColor": 0}
58	60	{"_key": 60, "colorName": "07_bc", "hairColor": 1}
59	61	{"_key": 61, "colorName": "turkish_bc", "hairColor": 0}
60	62	{"_key": 62, "colorName": "blue_a", "hairColor": 0}
61	63	{"_key": 63, "colorName": "green_bc", "hairColor": 0}
62	64	{"_key": 64, "colorName": "brown_bc", "hairColor": 0}
63	65	{"_key": 65, "colorName": "26_bc", "hairColor": 1}
64	66	{"_key": 66, "colorName": "deteis_default", "hairColor": 0}
65	67	{"_key": 67, "colorName": "11_bc", "hairColor": 1}
66	68	{"_key": 68, "colorName": "turkish_a", "hairColor": 0}
67	69	{"_key": 69, "colorName": "green_matte", "hairColor": 0}
68	70	{"_key": 70, "colorName": "jinmei_midlight", "hairColor": 0}
69	71	{"_key": 71, "colorName": "achura_dark", "hairColor": 0}
70	72	{"_key": 72, "colorName": "19_a", "hairColor": 1}
71	73	{"_key": 73, "colorName": "mossgreen_bc", "hairColor": 0}
72	74	{"_key": 74, "colorName": "jinmei_dark", "hairColor": 0}
73	75	{"_key": 75, "colorName": "khanid_midlight", "hairColor": 0}
74	76	{"_key": 76, "colorName": "jinmei", "hairColor": 0}
75	77	{"_key": 77, "colorName": "rustred_bc", "hairColor": 0}
76	78	{"_key": 78, "colorName": "02_a", "hairColor": 1}
77	79	{"_key": 79, "colorName": "nikunni_midlight", "hairColor": 0}
78	80	{"_key": 80, "colorName": "extra02", "hairColor": 0}
79	81	{"_key": 81, "colorName": "extra01", "hairColor": 0}
80	82	{"_key": 82, "colorName": "redbrown_abc", "hairColor": 0}
81	83	{"_key": 83, "colorName": "extra03", "hairColor": 0}
82	84	{"_key": 84, "colorName": "04_bc", "hairColor": 1}
83	85	{"_key": 85, "colorName": "sebiestor_middark", "hairColor": 0}
84	86	{"_key": 86, "colorName": "blue", "hairColor": 0}
85	87	{"_key": 87, "colorName": "deteis_light", "hairColor": 0}
86	88	{"_key": 88, "colorName": "06_a", "hairColor": 1}
87	89	{"_key": 89, "colorName": "silver_light_glossy", "hairColor": 0}
88	90	{"_key": 90, "colorName": "purple", "hairColor": 0}
89	91	{"_key": 91, "colorName": "amarr_midlight", "hairColor": 0}
90	92	{"_key": 92, "colorName": "gold_a", "hairColor": 0}
91	93	{"_key": 93, "colorName": "silver_bc", "hairColor": 0}
92	94	{"_key": 94, "colorName": "silver_light_matte", "hairColor": 0}
93	95	{"_key": 95, "colorName": "goldgreen_bc", "hairColor": 0}
94	96	{"_key": 96, "colorName": "darkgray_abc", "hairColor": 0}
95	97	{"_key": 97, "colorName": "purplish", "hairColor": 0}
96	98	{"_key": 98, "colorName": "04_a", "hairColor": 1}
97	99	{"_key": 99, "colorName": "red", "hairColor": 0}
98	100	{"_key": 100, "colorName": "pink_glossy", "hairColor": 0}
99	101	{"_key": 101, "colorName": "brutor_dark", "hairColor": 0}
100	102	{"_key": 102, "colorName": "darkred_glossy", "hairColor": 0}
101	103	{"_key": 103, "colorName": "black_a", "hairColor": 0}
102	104	{"_key": 104, "colorName": "rosie", "hairColor": 0}
103	105	{"_key": 105, "colorName": "rosered_bc", "hairColor": 0}
104	106	{"_key": 106, "colorName": "black_glossy", "hairColor": 0}
105	107	{"_key": 107, "colorName": "khanid_middark", "hairColor": 0}
106	108	{"_key": 108, "colorName": "olivegreen_a", "hairColor": 0}
107	109	{"_key": 109, "colorName": "yellow_bc", "hairColor": 0}
108	110	{"_key": 110, "colorName": "08_a", "hairColor": 1}
109	111	{"_key": 111, "colorName": "silver_dark_medium", "hairColor": 0}
110	112	{"_key": 112, "colorName": "purple_a", "hairColor": 0}
111	113	{"_key": 113, "colorName": "amarr_middark", "hairColor": 0}
112	114	{"_key": 114, "colorName": "achura", "hairColor": 0}
113	115	{"_key": 115, "colorName": "27_bc", "hairColor": 1}
114	116	{"_key": 116, "colorName": "achura_midlight", "hairColor": 0}
115	117	{"_key": 117, "colorName": "civire_middark", "hairColor": 0}
116	118	{"_key": 118, "colorName": "brutor_default", "hairColor": 0}
117	119	{"_key": 119, "colorName": "darkbrown_abc", "hairColor": 0}
118	120	{"_key": 120, "colorName": "achura_default", "hairColor": 0}
119	121	{"_key": 121, "colorName": "25_bc", "hairColor": 1}
120	122	{"_key": 122, "colorName": "gallente_light", "hairColor": 0}
121	123	{"_key": 123, "colorName": "civire_default", "hairColor": 0}
122	124	{"_key": 124, "colorName": "olivegreen_bc", "hairColor": 0}
123	125	{"_key": 125, "colorName": "09_bc", "hairColor": 1}
124	126	{"_key": 126, "colorName": "mossgreen_a", "hairColor": 0}
125	127	{"_key": 127, "colorName": "deteis_middark", "hairColor": 0}
126	128	{"_key": 128, "colorName": "21_bc", "hairColor": 1}
127	129	{"_key": 129, "colorName": "gray_abc", "hairColor": 0}
128	130	{"_key": 130, "colorName": "intaki_light", "hairColor": 0}
129	131	{"_key": 131, "colorName": "yellow_a", "hairColor": 0}
130	132	{"_key": 132, "colorName": "coldgray_a", "hairColor": 0}
131	133	{"_key": 133, "colorName": "nikunni_default", "hairColor": 0}
132	134	{"_key": 134, "colorName": "lightgreen_bc", "hairColor": 0}
133	135	{"_key": 135, "colorName": "brutor_midlight", "hairColor": 0}
134	136	{"_key": 136, "colorName": "civire_dark", "hairColor": 0}
135	137	{"_key": 137, "colorName": "15_bc", "hairColor": 1}
136	138	{"_key": 138, "colorName": "orange_bc", "hairColor": 0}
137	139	{"_key": 139, "colorName": "bluish", "hairColor": 0}
138	140	{"_key": 140, "colorName": "blue_matte", "hairColor": 0}
139	141	{"_key": 141, "colorName": "gold_matte", "hairColor": 0}
140	142	{"_key": 142, "colorName": "22_bc", "hairColor": 1}
141	143	{"_key": 143, "colorName": "14_a", "hairColor": 1}
142	144	{"_key": 144, "colorName": "red_a", "hairColor": 0}
143	145	{"_key": 145, "colorName": "brown_a", "hairColor": 0}
144	146	{"_key": 146, "colorName": "green_medium", "hairColor": 0}
145	147	{"_key": 147, "colorName": "10_bc", "hairColor": 1}
146	148	{"_key": 148, "colorName": "nikunni", "hairColor": 0}
147	149	{"_key": 149, "colorName": "lightblue_bc", "hairColor": 0}
148	150	{"_key": 150, "colorName": "sebiestor_midlight", "hairColor": 0}
149	151	{"_key": 151, "colorName": "grayblue_abc", "hairColor": 0}
150	152	{"_key": 152, "colorName": "gallente_default", "hairColor": 0}
151	153	{"_key": 153, "colorName": "blue_abc", "hairColor": 0}
152	154	{"_key": 154, "colorName": "red_medium", "hairColor": 0}
153	155	{"_key": 155, "colorName": "khanid", "hairColor": 0}
154	156	{"_key": 156, "colorName": "white", "hairColor": 0}
155	157	{"_key": 157, "colorName": "jinmei_middark", "hairColor": 0}
156	158	{"_key": 158, "colorName": "navyblue_bc", "hairColor": 0}
157	159	{"_key": 159, "colorName": "khanid_dark", "hairColor": 0}
158	160	{"_key": 160, "colorName": "nikunni_dark", "hairColor": 0}
159	161	{"_key": 161, "colorName": "vherokior_midlight", "hairColor": 0}
160	162	{"_key": 162, "colorName": "rustred_a", "hairColor": 0}
161	163	{"_key": 163, "colorName": "sebiestor", "hairColor": 0}
162	164	{"_key": 164, "colorName": "vherokior_dark", "hairColor": 0}
163	165	{"_key": 165, "colorName": "06_bc", "hairColor": 1}
164	166	{"_key": 166, "colorName": "vherokior_middark", "hairColor": 0}
165	167	{"_key": 167, "colorName": "11_a", "hairColor": 1}
166	168	{"_key": 168, "colorName": "brutor_middark", "hairColor": 0}
167	169	{"_key": 169, "colorName": "jinmei_default", "hairColor": 0}
168	170	{"_key": 170, "colorName": "navyblue_a", "hairColor": 0}
169	171	{"_key": 171, "colorName": "17_bc", "hairColor": 1}
170	172	{"_key": 172, "colorName": "olive", "hairColor": 0}
171	173	{"_key": 173, "colorName": "deteis_dark", "hairColor": 0}
172	174	{"_key": 174, "colorName": "sebiestor_light", "hairColor": 0}
173	175	{"_key": 175, "colorName": "silver_dark_matte", "hairColor": 0}
174	176	{"_key": 176, "colorName": "15_a", "hairColor": 1}
175	177	{"_key": 177, "colorName": "12_bc", "hairColor": 1}
176	178	{"_key": 178, "colorName": "reddish", "hairColor": 0}
177	179	{"_key": 179, "colorName": "default", "hairColor": 0}
178	180	{"_key": 180, "colorName": "gold_medium", "hairColor": 0}
179	181	{"_key": 181, "colorName": "intaki", "hairColor": 0}
180	182	{"_key": 182, "colorName": "05_bc", "hairColor": 1}
181	183	{"_key": 183, "colorName": "nikunni_middark", "hairColor": 0}
182	184	{"_key": 184, "colorName": "khanid_light", "hairColor": 0}
183	185	{"_key": 185, "colorName": "intaki_default", "hairColor": 0}
184	186	{"_key": 186, "colorName": "17_a", "hairColor": 1}
185	187	{"_key": 187, "colorName": "gold_glossy", "hairColor": 0}
186	188	{"_key": 188, "colorName": "blue_bc", "hairColor": 0}
187	189	{"_key": 189, "colorName": "white_a", "hairColor": 0}
188	190	{"_key": 190, "colorName": "red_glossy", "hairColor": 0}
189	191	{"_key": 191, "colorName": "green_a", "hairColor": 0}
190	192	{"_key": 192, "colorName": "intaki_middark", "hairColor": 0}
191	193	{"_key": 193, "colorName": "green_glossy", "hairColor": 0}
192	194	{"_key": 194, "colorName": "18_bc", "hairColor": 1}
193	195	{"_key": 195, "colorName": "iceblue_abc", "hairColor": 0}
194	196	{"_key": 196, "colorName": "gallente_midlight", "hairColor": 0}
195	197	{"_key": 197, "colorName": "brutor", "hairColor": 0}
196	198	{"_key": 198, "colorName": "brown_abc", "hairColor": 0}
197	199	{"_key": 199, "colorName": "pink_bc", "hairColor": 0}
198	200	{"_key": 200, "colorName": "blond", "hairColor": 0}
199	201	{"_key": 201, "colorName": "civire", "hairColor": 0}
200	202	{"_key": 202, "colorName": "achura_light", "hairColor": 0}
201	203	{"_key": 203, "colorName": "lightgreen_a", "hairColor": 0}
202	204	{"_key": 204, "colorName": "redish", "hairColor": 0}
203	205	{"_key": 205, "colorName": "darkred_medium", "hairColor": 0}
204	206	{"_key": 206, "colorName": "amarr_default", "hairColor": 0}
205	207	{"_key": 207, "colorName": "sebiestor_dark", "hairColor": 0}
206	208	{"_key": 208, "colorName": "01_bc", "hairColor": 1}
207	209	{"_key": 209, "colorName": "19_bc", "hairColor": 1}
208	210	{"_key": 210, "colorName": "khanid_default", "hairColor": 0}
209	211	{"_key": 211, "colorName": "red_bc", "hairColor": 0}
210	212	{"_key": 212, "colorName": "amarr_light", "hairColor": 0}
211	213	{"_key": 213, "colorName": "bloodred_bc", "hairColor": 0}
212	214	{"_key": 214, "colorName": "black_bc", "hairColor": 0}
213	215	{"_key": 215, "colorName": "13_bc", "hairColor": 1}
214	216	{"_key": 216, "colorName": "02_bc", "hairColor": 1}
215	217	{"_key": 217, "colorName": "pink_a", "hairColor": 0}
216	218	{"_key": 218, "colorName": "blue_glossy", "hairColor": 0}
217	219	{"_key": 219, "colorName": "black_matte", "hairColor": 0}
218	220	{"_key": 220, "colorName": "vherokior", "hairColor": 0}
219	221	{"_key": 221, "colorName": "bloodred_a", "hairColor": 0}
220	222	{"_key": 222, "colorName": "10_a", "hairColor": 1}
221	223	{"_key": 223, "colorName": "20_bc", "hairColor": 1}
222	224	{"_key": 224, "colorName": "darkblue_abc", "hairColor": 0}
223	225	{"_key": 225, "colorName": "12_a", "hairColor": 1}
224	226	{"_key": 226, "colorName": "darkred_matte", "hairColor": 0}
225	227	{"_key": 227, "colorName": "achura_middark", "hairColor": 0}
226	228	{"_key": 228, "colorName": "pink_matte", "hairColor": 0}
227	229	{"_key": 229, "colorName": "21_a", "hairColor": 1}
228	230	{"_key": 230, "colorName": "civire_midlight", "hairColor": 0}
229	231	{"_key": 231, "colorName": "lightblue_a", "hairColor": 0}
230	232	{"_key": 232, "colorName": "dark", "hairColor": 0}
231	233	{"_key": 233, "colorName": "jinmei_light", "hairColor": 0}
232	234	{"_key": 234, "colorName": "white_bc", "hairColor": 0}
233	235	{"_key": 235, "colorName": "black_medium", "hairColor": 0}
234	236	{"_key": 236, "colorName": "23_bc", "hairColor": 1}
235	237	{"_key": 237, "colorName": "green", "hairColor": 0}
236	238	{"_key": 238, "colorName": "16_a", "hairColor": 1}
237	239	{"_key": 239, "colorName": "coldgray_bc", "hairColor": 0}
238	240	{"_key": 240, "colorName": "brutor_light", "hairColor": 0}
239	241	{"_key": 241, "colorName": "18_a", "hairColor": 1}
240	242	{"_key": 242, "colorName": "generic03", "hairColor": 0}
241	243	{"_key": 243, "colorName": "default_a", "hairColor": 0}
242	253	{"_key": 253, "colorName": "skirtmilf01_v0", "hairColor": 0}
243	254	{"_key": 254, "colorName": "skirtmilf01_v1", "hairColor": 0}
244	255	{"_key": 255, "colorName": "shirtqf01", "hairColor": 0}
245	256	{"_key": 256, "colorName": "skirtmilf02", "hairColor": 0}
246	257	{"_key": 257, "colorName": "shirtqm01", "hairColor": 0}
247	355	{"_key": 355, "colorName": "dust", "hairColor": 0}
248	356	{"_key": 356, "colorName": "steampunk", "hairColor": 0}
249	357	{"_key": 357, "colorName": "ishukone", "hairColor": 0}
250	358	{"_key": 358, "colorName": "pantsmilm01_v0", "hairColor": 0}
251	359	{"_key": 359, "colorName": "camo", "hairColor": 0}
252	360	{"_key": 360, "colorName": "rbvf", "hairColor": 0}
253	361	{"_key": 361, "colorName": "generic", "hairColor": 0}
254	362	{"_key": 362, "colorName": "v0", "hairColor": 0}
255	363	{"_key": 363, "colorName": "lightgray", "hairColor": 0}
256	364	{"_key": 364, "colorName": "pantsmilm01_v1", "hairColor": 0}
257	365	{"_key": 365, "colorName": "mattered", "hairColor": 0}
258	366	{"_key": 366, "colorName": "p03", "hairColor": 0}
259	367	{"_key": 367, "colorName": "p01", "hairColor": 0}
260	368	{"_key": 368, "colorName": "p07", "hairColor": 0}
261	369	{"_key": 369, "colorName": "p05", "hairColor": 0}
262	370	{"_key": 370, "colorName": "p04", "hairColor": 0}
263	371	{"_key": 371, "colorName": "p08", "hairColor": 0}
264	372	{"_key": 372, "colorName": "x02", "hairColor": 0}
265	373	{"_key": 373, "colorName": "x01", "hairColor": 0}
266	374	{"_key": 374, "colorName": "blackwhithe", "hairColor": 0}
267	375	{"_key": 375, "colorName": "orangesatin", "hairColor": 0}
268	376	{"_key": 376, "colorName": "dirtygray", "hairColor": 0}
269	377	{"_key": 377, "colorName": "whiteblue", "hairColor": 0}
270	378	{"_key": 378, "colorName": "p02", "hairColor": 0}
271	379	{"_key": 379, "colorName": "darkgray", "hairColor": 0}
272	380	{"_key": 380, "colorName": "p06", "hairColor": 0}
273	381	{"_key": 381, "colorName": "p_desertcamo", "hairColor": 0}
274	382	{"_key": 382, "colorName": "matbrown", "hairColor": 0}
275	383	{"_key": 383, "colorName": "matolive", "hairColor": 0}
276	384	{"_key": 384, "colorName": "whiteblack", "hairColor": 0}
277	385	{"_key": 385, "colorName": "thickpurple", "hairColor": 0}
278	386	{"_key": 386, "colorName": "darkred", "hairColor": 0}
279	387	{"_key": 387, "colorName": "thickmatblack", "hairColor": 0}
280	388	{"_key": 388, "colorName": "caldari_blue_v10", "hairColor": 0}
281	389	{"_key": 389, "colorName": "goldsilver", "hairColor": 0}
282	390	{"_key": 390, "colorName": "blackgreengold", "hairColor": 0}
283	391	{"_key": 391, "colorName": "thickgray", "hairColor": 0}
284	392	{"_key": 392, "colorName": "matblack", "hairColor": 0}
285	393	{"_key": 393, "colorName": "blackred", "hairColor": 0}
286	394	{"_key": 394, "colorName": "tan", "hairColor": 0}
287	395	{"_key": 395, "colorName": "pink", "hairColor": 0}
288	396	{"_key": 396, "colorName": "p_greencamo", "hairColor": 0}
289	397	{"_key": 397, "colorName": "matred", "hairColor": 0}
290	398	{"_key": 398, "colorName": "light", "hairColor": 0}
291	399	{"_key": 399, "colorName": "blackgold", "hairColor": 0}
292	400	{"_key": 400, "colorName": "graystripes", "hairColor": 0}
293	401	{"_key": 401, "colorName": "matgraphite", "hairColor": 0}
294	402	{"_key": 402, "colorName": "blackleather", "hairColor": 0}
295	403	{"_key": 403, "colorName": "redstripes", "hairColor": 0}
296	404	{"_key": 404, "colorName": "trueblack", "hairColor": 0}
297	405	{"_key": 405, "colorName": "brownblack", "hairColor": 0}
298	406	{"_key": 406, "colorName": "lighgray", "hairColor": 0}
299	407	{"_key": 407, "colorName": "_x01", "hairColor": 0}
300	408	{"_key": 408, "colorName": "_x02", "hairColor": 0}
301	409	{"_key": 409, "colorName": "redblackleather", "hairColor": 0}
302	410	{"_key": 410, "colorName": "matgreen", "hairColor": 0}
303	411	{"_key": 411, "colorName": "greengold", "hairColor": 0}
304	412	{"_key": 412, "colorName": "greenblack", "hairColor": 0}
305	413	{"_key": 413, "colorName": "blue2", "hairColor": 0}
306	414	{"_key": 414, "colorName": "marine", "hairColor": 0}
307	415	{"_key": 415, "colorName": "greensatin", "hairColor": 0}
308	416	{"_key": 416, "colorName": "wornbrown", "hairColor": 0}
309	417	{"_key": 417, "colorName": "goldblack", "hairColor": 0}
310	418	{"_key": 418, "colorName": "blackredgold", "hairColor": 0}
311	419	{"_key": 419, "colorName": "guristas_orange_v11", "hairColor": 0}
312	420	{"_key": 420, "colorName": "matteblue", "hairColor": 0}
313	421	{"_key": 421, "colorName": "yellowblack", "hairColor": 0}
314	422	{"_key": 422, "colorName": "gray", "hairColor": 0}
315	423	{"_key": 423, "colorName": "darkcyan", "hairColor": 0}
316	424	{"_key": 424, "colorName": "p_browncamo", "hairColor": 0}
317	425	{"_key": 425, "colorName": "darkblue", "hairColor": 0}
318	426	{"_key": 426, "colorName": "whitestripes", "hairColor": 0}
319	427	{"_key": 427, "colorName": "concord_green_v12", "hairColor": 0}
320	428	{"_key": 428, "colorName": "minmatar_darkred_v8", "hairColor": 0}
321	429	{"_key": 429, "colorName": "redgold", "hairColor": 0}
322	430	{"_key": 430, "colorName": "matgray", "hairColor": 0}
323	431	{"_key": 431, "colorName": "thickblack", "hairColor": 0}
324	432	{"_key": 432, "colorName": "goldleather", "hairColor": 0}
325	433	{"_key": 433, "colorName": "blackredsilver", "hairColor": 0}
326	434	{"_key": 434, "colorName": "darkbrown", "hairColor": 0}
327	435	{"_key": 435, "colorName": "matturquoise", "hairColor": 0}
328	436	{"_key": 436, "colorName": "bloodriders_v13", "hairColor": 0}
329	437	{"_key": 437, "colorName": "matblue", "hairColor": 0}
330	438	{"_key": 438, "colorName": "blacksilver", "hairColor": 0}
331	439	{"_key": 439, "colorName": "turquoise", "hairColor": 0}
332	440	{"_key": 440, "colorName": "brownleather", "hairColor": 0}
333	441	{"_key": 441, "colorName": "redleather", "hairColor": 0}
334	442	{"_key": 442, "colorName": "khaki", "hairColor": 0}
335	443	{"_key": 443, "colorName": "bloodraiders_v13", "hairColor": 0}
336	444	{"_key": 444, "colorName": "gallente_green_v9", "hairColor": 0}
337	445	{"_key": 445, "colorName": "blackgoldline", "hairColor": 0}
338	446	{"_key": 446, "colorName": "greenstripes", "hairColor": 0}
339	447	{"_key": 447, "colorName": "thickblue", "hairColor": 0}
340	448	{"_key": 448, "colorName": "graphite", "hairColor": 0}
341	449	{"_key": 449, "colorName": "cream", "hairColor": 0}
342	450	{"_key": 450, "colorName": "redblack", "hairColor": 0}
343	451	{"_key": 451, "colorName": "p_darkcaldaricamo", "hairColor": 0}
344	452	{"_key": 452, "colorName": "redsatin", "hairColor": 0}
345	453	{"_key": 453, "colorName": "amarr_brown_v7", "hairColor": 0}
346	454	{"_key": 454, "colorName": "blackbluegold", "hairColor": 0}
347	455	{"_key": 455, "colorName": "blackwhite", "hairColor": 0}
348	474	{"_key": 474, "colorName": "rosie_matte", "hairColor": 0}
349	475	{"_key": 475, "colorName": "blue_stell", "hairColor": 0}
350	476	{"_key": 476, "colorName": "red_02_medium", "hairColor": 0}
351	477	{"_key": 477, "colorName": "golden", "hairColor": 0}
352	478	{"_key": 478, "colorName": "bluessteel", "hairColor": 0}
353	479	{"_key": 479, "colorName": "darkred_02_glossy", "hairColor": 0}
354	480	{"_key": 480, "colorName": "rosie_glossy", "hairColor": 0}
355	481	{"_key": 481, "colorName": "darkred_02_matte", "hairColor": 0}
356	482	{"_key": 482, "colorName": "white_matte", "hairColor": 0}
357	483	{"_key": 483, "colorName": "darkred_02_medium", "hairColor": 0}
358	484	{"_key": 484, "colorName": "grey", "hairColor": 0}
359	485	{"_key": 485, "colorName": "rosie_medium", "hairColor": 0}
360	486	{"_key": 486, "colorName": "red_02_glossy", "hairColor": 0}
361	487	{"_key": 487, "colorName": "jenlura", "hairColor": 0}
362	488	{"_key": 488, "colorName": "light_blue", "hairColor": 0}
363	489	{"_key": 489, "colorName": "aqua", "hairColor": 0}
364	490	{"_key": 490, "colorName": "light_purple", "hairColor": 0}
365	491	{"_key": 491, "colorName": "dirty", "hairColor": 0}
366	492	{"_key": 492, "colorName": "whiteblacknexon", "hairColor": 0}
367	493	{"_key": 493, "colorName": "shirtqm02", "hairColor": 0}
368	494	{"_key": 494, "colorName": "shirtqf02", "hairColor": 0}
369	587	{"_key": 587, "colorName": "c6", "hairColor": 0}
370	588	{"_key": 588, "colorName": "redblackdark", "hairColor": 0}
371	589	{"_key": 589, "colorName": "c3", "hairColor": 0}
372	590	{"_key": 590, "colorName": "c9", "hairColor": 0}
373	591	{"_key": 591, "colorName": "c8", "hairColor": 0}
374	592	{"_key": 592, "colorName": "c2", "hairColor": 0}
375	593	{"_key": 593, "colorName": "c1", "hairColor": 0}
376	594	{"_key": 594, "colorName": "c7", "hairColor": 0}
377	595	{"_key": 595, "colorName": "c5", "hairColor": 0}
378	596	{"_key": 596, "colorName": "c4", "hairColor": 0}
379	597	{"_key": 597, "colorName": "c14", "hairColor": 0}
380	598	{"_key": 598, "colorName": "c13", "hairColor": 0}
381	599	{"_key": 599, "colorName": "c12", "hairColor": 0}
382	600	{"_key": 600, "colorName": "c11", "hairColor": 0}
383	601	{"_key": 601, "colorName": "c10", "hairColor": 0}
384	602	{"_key": 602, "colorName": "blueblack", "hairColor": 0}
385	1004	{"_key": 1004, "colorName": "silverv2", "hairColor": 0}
386	1011	{"_key": 1011, "colorName": "blackv2", "hairColor": 0}
\.


--
-- Name: character_colornames character_colornames_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.character_colornames
    ADD CONSTRAINT character_colornames_pkey PRIMARY KEY (row_no);


--
-- Name: character_colornames_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX character_colornames_key_idx ON sde_native.character_colornames USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict pJKp7zbOshMbD785h8l5KPq8PNPoXRX9yrDk6gsnJFLvEn1ksZauvq2RAxCHiUq

