--
-- PostgreSQL database dump
--

\restrict gLTuDnYggFnmksQ8aNw2SOOquhltiYhJY7JEpkLdVpa9dkMHB6GQ3tMbOHgSkxX

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dungeonobjectives; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.dungeonobjectives (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: dungeonobjectives; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.dungeonobjectives (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "clientObjectives": {"overrides": {"destroy_targets": {"title": "UI/Objectives/Titles/Fight", "description": "UI/Objectives/Descriptions/HoldOut"}}, "nodeGraphID": 1, "objectiveChainID": 26, "blackboardParameters": [{"parameterKey": "some_server_value_to_client"}, {"parameterKey": "objective_timer"}, {"defaultValue": "something random", "parameterKey": "random_client_key"}]}}
1	2	{"_key": 2, "clientObjectives": {"nodeGraphID": 641, "objectiveChainID": 38, "blackboardParameters": []}}
2	3	{"_key": 3, "clientObjectives": {"nodeGraphID": 648, "objectiveChainID": 40, "blackboardParameters": []}}
3	4	{"_key": 4, "clientObjectives": {"nodeGraphID": 651, "objectiveChainID": 41, "blackboardParameters": []}}
4	7	{"_key": 7, "clientObjectives": {"nodeGraphID": 657, "objectiveChainID": 42, "blackboardParameters": []}}
5	8	{"_key": 8, "clientObjectives": {"nodeGraphID": 658, "objectiveChainID": 43, "blackboardParameters": []}}
6	9	{"_key": 9, "clientObjectives": {"nodeGraphID": 661, "objectiveChainID": 44, "blackboardParameters": []}}
7	11	{"_key": 11, "clientObjectives": {"blackboardParameters": []}}
8	12	{"_key": 12, "clientObjectives": {"nodeGraphID": 706, "objectiveChainID": 57, "blackboardParameters": []}}
9	13	{"_key": 13, "clientObjectives": {"nodeGraphID": 735, "objectiveChainID": 60, "blackboardParameters": []}}
10	16	{"_key": 16, "clientObjectives": {"nodeGraphID": 784, "objectiveChainID": 64, "blackboardParameters": []}}
11	17	{"_key": 17, "clientObjectives": {"nodeGraphID": 785, "objectiveChainID": 65, "blackboardParameters": []}}
12	19	{"_key": 19, "clientObjectives": {"nodeGraphID": 788, "objectiveChainID": 67, "blackboardParameters": []}}
13	20	{"_key": 20, "clientObjectives": {"objectiveChainID": 69, "blackboardParameters": []}}
14	21	{"_key": 21, "clientObjectives": {"nodeGraphID": 826, "objectiveChainID": 70, "blackboardParameters": []}}
15	22	{"_key": 22, "clientObjectives": {"nodeGraphID": 827, "objectiveChainID": 71, "blackboardParameters": []}}
16	23	{"_key": 23, "clientObjectives": {"nodeGraphID": 828, "objectiveChainID": 72, "blackboardParameters": []}}
17	24	{"_key": 24, "clientObjectives": {"objectiveChainID": 75, "blackboardParameters": [{"defaultValue": [1194449, 1194460], "parameterKey": "dungeon_object_ids"}]}}
18	25	{"_key": 25, "clientObjectives": {"objectiveChainID": 76, "blackboardParameters": [{"defaultValue": [149146, 149147, 149148], "parameterKey": "entity_group_ids"}]}}
19	28	{"_key": 28, "clientObjectives": {"nodeGraphID": 804, "objectiveChainID": 68, "blackboardParameters": []}}
20	29	{"_key": 29, "clientObjectives": {"objectiveChainID": 75, "blackboardParameters": [{"defaultValue": [1234189, 1234188], "parameterKey": "dungeon_object_ids"}]}}
21	30	{"_key": 30, "clientObjectives": {"objectiveChainID": 75, "blackboardParameters": [{"defaultValue": [1234253, 1234255], "parameterKey": "dungeon_object_ids"}]}}
22	31	{"_key": 31, "clientObjectives": {"objectiveChainID": 75, "blackboardParameters": [{"defaultValue": [1234291, 1234285], "parameterKey": "dungeon_object_ids"}]}}
23	32	{"_key": 32, "clientObjectives": {"objectiveChainID": 75, "blackboardParameters": [{"defaultValue": [1234327, 1234339], "parameterKey": "dungeon_object_ids"}]}}
24	33	{"_key": 33, "clientObjectives": {"objectiveChainID": 75, "blackboardParameters": [{"defaultValue": [1234346, 1234350], "parameterKey": "dungeon_object_ids"}]}}
25	34	{"_key": 34, "clientObjectives": {"objectiveChainID": 76, "blackboardParameters": [{"defaultValue": [149468, 149469, 149471], "parameterKey": "entity_group_ids"}]}}
26	35	{"_key": 35, "clientObjectives": {"objectiveChainID": 76, "blackboardParameters": [{"defaultValue": [149483, 149482, 149480], "parameterKey": "entity_group_ids"}]}}
27	36	{"_key": 36, "clientObjectives": {"objectiveChainID": 76, "blackboardParameters": [{"defaultValue": [149511, 149510, 149508], "parameterKey": "entity_group_ids"}]}}
28	37	{"_key": 37, "clientObjectives": {"objectiveChainID": 76, "blackboardParameters": [{"defaultValue": [149491, 149490, 149488], "parameterKey": "entity_group_ids"}]}}
29	38	{"_key": 38, "clientObjectives": {"objectiveChainID": 76, "blackboardParameters": [{"defaultValue": [149495, 149496, 149498], "parameterKey": "entity_group_ids"}]}}
30	40	{"_key": 40, "clientObjectives": {"nodeGraphID": 863, "objectiveChainID": 79, "blackboardParameters": []}}
31	41	{"_key": 41, "clientObjectives": {"objectiveChainID": 102, "blackboardParameters": []}}
32	42	{"_key": 42, "clientObjectives": {"nodeGraphID": 882, "objectiveChainID": 81, "blackboardParameters": []}}
33	43	{"_key": 43, "clientObjectives": {"nodeGraphID": 884, "blackboardParameters": []}}
34	44	{"_key": 44, "clientObjectives": {"nodeGraphID": 886, "objectiveChainID": 83, "blackboardParameters": []}}
35	45	{"_key": 45, "clientObjectives": {"nodeGraphID": 891, "objectiveChainID": 85, "blackboardParameters": []}}
36	46	{"_key": 46, "clientObjectives": {"blackboardParameters": []}}
37	51	{"_key": 51, "clientObjectives": {"objectiveChainID": 88, "blackboardParameters": []}}
38	52	{"_key": 52, "clientObjectives": {"blackboardParameters": []}}
39	53	{"_key": 53, "clientObjectives": {"nodeGraphID": 916, "objectiveChainID": 92, "blackboardParameters": []}}
40	54	{"_key": 54, "clientObjectives": {"nodeGraphID": 911, "objectiveChainID": 89, "blackboardParameters": []}}
41	55	{"_key": 55, "clientObjectives": {"nodeGraphID": 912, "objectiveChainID": 90, "blackboardParameters": []}}
42	56	{"_key": 56, "clientObjectives": {"nodeGraphID": 914, "objectiveChainID": 91, "blackboardParameters": []}}
43	57	{"_key": 57, "clientObjectives": {"nodeGraphID": 924, "objectiveChainID": 96, "blackboardParameters": []}}
44	58	{"_key": 58, "clientObjectives": {"nodeGraphID": 924, "objectiveChainID": 96, "blackboardParameters": []}}
45	59	{"_key": 59, "clientObjectives": {"nodeGraphID": 924, "objectiveChainID": 96, "blackboardParameters": []}}
46	60	{"_key": 60, "clientObjectives": {"nodeGraphID": 924, "objectiveChainID": 96, "blackboardParameters": []}}
47	61	{"_key": 61, "clientObjectives": {"nodeGraphID": 927, "objectiveChainID": 100, "blackboardParameters": []}}
48	64	{"_key": 64, "clientObjectives": {"nodeGraphID": 928, "objectiveChainID": 102, "blackboardParameters": []}}
49	66	{"_key": 66, "clientObjectives": {"nodeGraphID": 931, "objectiveChainID": 57, "blackboardParameters": []}}
50	67	{"_key": 67, "clientObjectives": {"nodeGraphID": 933, "objectiveChainID": 104, "blackboardParameters": []}}
51	68	{"_key": 68, "clientObjectives": {"nodeGraphID": 933, "objectiveChainID": 108, "blackboardParameters": []}}
52	69	{"_key": 69, "clientObjectives": {"nodeGraphID": 927, "objectiveChainID": 107, "blackboardParameters": []}}
53	71	{"_key": 71, "clientObjectives": {"nodeGraphID": 940, "objectiveChainID": 109, "blackboardParameters": []}}
54	72	{"_key": 72, "clientObjectives": {"nodeGraphID": 946, "objectiveChainID": 113, "blackboardParameters": []}}
55	73	{"_key": 73, "clientObjectives": {"blackboardParameters": []}}
56	74	{"_key": 74, "clientObjectives": {"nodeGraphID": 952, "objectiveChainID": 115, "blackboardParameters": []}}
57	75	{"_key": 75, "clientObjectives": {"nodeGraphID": 961, "objectiveChainID": 120, "blackboardParameters": []}}
58	76	{"_key": 76, "clientObjectives": {"nodeGraphID": 963, "objectiveChainID": 122, "blackboardParameters": []}}
59	77	{"_key": 77, "clientObjectives": {"nodeGraphID": 962, "objectiveChainID": 121, "blackboardParameters": []}}
60	78	{"_key": 78, "clientObjectives": {"nodeGraphID": 969, "objectiveChainID": 123, "blackboardParameters": []}}
61	79	{"_key": 79, "clientObjectives": {"nodeGraphID": 973, "objectiveChainID": 125, "blackboardParameters": []}}
62	80	{"_key": 80, "clientObjectives": {"objectiveChainID": 127, "blackboardParameters": []}}
63	81	{"_key": 81, "clientObjectives": {"nodeGraphID": 1000, "objectiveChainID": 129, "blackboardParameters": []}}
64	83	{"_key": 83, "clientObjectives": {"objectiveChainID": 102, "blackboardParameters": []}}
65	84	{"_key": 84, "clientObjectives": {"blackboardParameters": []}}
66	85	{"_key": 85, "clientObjectives": {"nodeGraphID": 1013, "objectiveChainID": 131, "blackboardParameters": []}}
67	86	{"_key": 86, "clientObjectives": {"nodeGraphID": 1030, "objectiveChainID": 140, "blackboardParameters": []}}
68	87	{"_key": 87, "clientObjectives": {"nodeGraphID": 1026, "objectiveChainID": 136, "blackboardParameters": []}}
69	88	{"_key": 88, "clientObjectives": {"nodeGraphID": 1027, "objectiveChainID": 137, "blackboardParameters": []}}
70	89	{"_key": 89, "clientObjectives": {"nodeGraphID": 1028, "objectiveChainID": 138, "blackboardParameters": []}}
71	90	{"_key": 90, "clientObjectives": {"nodeGraphID": 1029, "objectiveChainID": 139, "blackboardParameters": []}}
72	91	{"_key": 91, "clientObjectives": {"nodeGraphID": 1039, "objectiveChainID": 142, "blackboardParameters": []}}
73	92	{"_key": 92, "clientObjectives": {"nodeGraphID": 1036, "objectiveChainID": 141, "blackboardParameters": []}}
74	93	{"_key": 93, "clientObjectives": {"objectiveChainID": 102, "blackboardParameters": []}}
75	94	{"_key": 94, "clientObjectives": {"nodeGraphID": 1040, "objectiveChainID": 143, "blackboardParameters": []}}
76	95	{"_key": 95, "clientObjectives": {"nodeGraphID": 1030, "objectiveChainID": 140, "blackboardParameters": []}}
77	96	{"_key": 96, "clientObjectives": {"nodeGraphID": 1052, "objectiveChainID": 147, "blackboardParameters": []}}
78	98	{"_key": 98, "clientObjectives": {"objectiveChainID": 148, "blackboardParameters": []}}
79	99	{"_key": 99, "clientObjectives": {"nodeGraphID": 1055, "objectiveChainID": 149, "blackboardParameters": []}}
80	100	{"_key": 100, "clientObjectives": {"objectiveChainID": 150, "blackboardParameters": []}}
81	101	{"_key": 101, "clientObjectives": {"nodeGraphID": 1058, "objectiveChainID": 151, "blackboardParameters": []}}
82	102	{"_key": 102, "clientObjectives": {"objectiveChainID": 152, "blackboardParameters": []}}
\.


--
-- Name: dungeonobjectives dungeonobjectives_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.dungeonobjectives
    ADD CONSTRAINT dungeonobjectives_pkey PRIMARY KEY (row_no);


--
-- Name: dungeonobjectives_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX dungeonobjectives_key_idx ON sde_native.dungeonobjectives USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict gLTuDnYggFnmksQ8aNw2SOOquhltiYhJY7JEpkLdVpa9dkMHB6GQ3tMbOHgSkxX

