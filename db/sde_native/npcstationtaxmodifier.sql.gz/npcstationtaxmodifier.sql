--
-- PostgreSQL database dump
--

\restrict R4gFd53bjdGFWLghcNBWXwZaG0ZKbvCIoXS6E9i8LyyMxfLAIf8wzApGiRuNIWX

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: npcstationtaxmodifier; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.npcstationtaxmodifier (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: npcstationtaxmodifier; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.npcstationtaxmodifier (row_no, key, data) FROM stdin;
0	60015187	{"_key": 60015187, "warFactionID": {"taxModifierByValue": {"500010": 0.1, "500011": 0.1}}}
\.


--
-- Name: npcstationtaxmodifier npcstationtaxmodifier_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.npcstationtaxmodifier
    ADD CONSTRAINT npcstationtaxmodifier_pkey PRIMARY KEY (row_no);


--
-- Name: npcstationtaxmodifier_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX npcstationtaxmodifier_key_idx ON sde_native.npcstationtaxmodifier USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict R4gFd53bjdGFWLghcNBWXwZaG0ZKbvCIoXS6E9i8LyyMxfLAIf8wzApGiRuNIWX

