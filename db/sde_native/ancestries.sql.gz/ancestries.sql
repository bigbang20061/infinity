--
-- PostgreSQL database dump
--

\restrict ZHYDJCJ9Ihesej92AOSPH8akVIE7cLwRJ6KdDm6gRIaC1fjAKWsooGLL6aOOVhG

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ancestries; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.ancestries (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: ancestries; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.ancestries (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "iconID": 1641, "memory": 0, "nameID": 59507, "charisma": 3, "willpower": 1, "perception": 0, "bloodlineID": 5, "intelligence": 0, "descriptionID": 59464, "shortDescription": "Progressive members of the upper class who have rejected their traditional ways."}
1	2	{"_key": 2, "iconID": 1642, "memory": 3, "nameID": 59508, "charisma": 1, "willpower": 0, "perception": 0, "bloodlineID": 5, "intelligence": 0, "descriptionID": 59465, "shortDescription": "Commoners who have transcended their class through shrewd business sense."}
2	3	{"_key": 3, "iconID": 1643, "memory": 0, "nameID": 59483, "charisma": 0, "willpower": 4, "perception": 0, "bloodlineID": 5, "intelligence": 0, "descriptionID": 59440, "shortDescription": "Traditionalists who wish to see the Empire regain its former glory."}
3	4	{"_key": 4, "iconID": 1644, "memory": 0, "nameID": 59484, "charisma": 4, "willpower": 0, "perception": 0, "bloodlineID": 6, "intelligence": 0, "descriptionID": 59441, "shortDescription": "Roaming businessmen who find opportunity in any marketplace."}
4	5	{"_key": 5, "iconID": 1645, "memory": 0, "nameID": 59485, "charisma": 0, "willpower": 0, "perception": 3, "bloodlineID": 6, "intelligence": 1, "descriptionID": 59442, "shortDescription": "Wily smugglers, bound by no border."}
5	6	{"_key": 6, "memory": 0, "nameID": 59514, "charisma": 0, "willpower": 4, "perception": 0, "bloodlineID": 6, "intelligence": 0, "descriptionID": 59471, "shortDescription": "Those who have escaped poverty through enlisted service on behalf of the Empire."}
6	7	{"_key": 7, "iconID": 1647, "memory": 4, "nameID": 59499, "charisma": 0, "willpower": 0, "perception": 0, "bloodlineID": 2, "intelligence": 0, "descriptionID": 59456, "shortDescription": "Warriors of the board room."}
7	8	{"_key": 8, "iconID": 1648, "memory": 0, "nameID": 59494, "charisma": 0, "willpower": 4, "perception": 0, "bloodlineID": 2, "intelligence": 0, "descriptionID": 59451, "shortDescription": "Guns for hire that are always available to the highest bidder."}
8	9	{"_key": 9, "iconID": 1649, "memory": 0, "nameID": 59493, "charisma": 2, "willpower": 2, "perception": 0, "bloodlineID": 2, "intelligence": 0, "descriptionID": 59450, "shortDescription": "Unhappy cogs in the capitalist machine."}
9	10	{"_key": 10, "iconID": 1650, "memory": 4, "nameID": 59498, "charisma": 0, "willpower": 0, "perception": 0, "bloodlineID": 1, "intelligence": 0, "descriptionID": 59455, "shortDescription": "Intrepid industrialists with a passion for mastery of production."}
10	11	{"_key": 11, "iconID": 1651, "memory": 0, "nameID": 59497, "charisma": 0, "willpower": 0, "perception": 1, "bloodlineID": 1, "intelligence": 3, "descriptionID": 59454, "shortDescription": "Combining efficiency with inventiveness, Deteis scientists are on the bleeding edge of technology."}
11	12	{"_key": 12, "iconID": 1652, "memory": 0, "nameID": 59496, "charisma": 0, "willpower": 4, "perception": 0, "bloodlineID": 1, "intelligence": 0, "descriptionID": 59453, "shortDescription": "Manufactured citizens of the State."}
12	13	{"_key": 13, "iconID": 1653, "memory": 0, "nameID": 59489, "charisma": 4, "willpower": 0, "perception": 0, "bloodlineID": 7, "intelligence": 0, "descriptionID": 59446, "shortDescription": "Making the universe a better place, one fight at a time."}
13	14	{"_key": 14, "iconID": 1654, "memory": 4, "nameID": 59512, "charisma": 0, "willpower": 0, "perception": 0, "bloodlineID": 7, "intelligence": 0, "descriptionID": 59469, "shortDescription": "The backbone of a core national industry."}
14	15	{"_key": 15, "iconID": 1655, "memory": 0, "nameID": 59513, "charisma": 0, "willpower": 2, "perception": 2, "bloodlineID": 7, "intelligence": 0, "descriptionID": 59470, "shortDescription": "Recent arrivals to the land of plenty."}
15	16	{"_key": 16, "iconID": 1656, "memory": 0, "nameID": 59490, "charisma": 2, "willpower": 0, "perception": 2, "bloodlineID": 8, "intelligence": 0, "descriptionID": 59447, "shortDescription": "Intaki sculptors and painters are among the most revered artists in the cluster."}
16	17	{"_key": 17, "iconID": 1657, "memory": 0, "nameID": 59491, "charisma": 4, "willpower": 0, "perception": 0, "bloodlineID": 8, "intelligence": 0, "descriptionID": 59448, "shortDescription": "Those who build bridges between cultures."}
17	18	{"_key": 18, "iconID": 1658, "memory": 4, "nameID": 59492, "charisma": 0, "willpower": 0, "perception": 0, "bloodlineID": 8, "intelligence": 0, "descriptionID": 59449, "shortDescription": "Those who have been There and Back."}
18	19	{"_key": 19, "iconID": 1659, "memory": 0, "nameID": 59502, "charisma": 0, "willpower": 0, "perception": 0, "bloodlineID": 3, "intelligence": 4, "descriptionID": 59459, "shortDescription": "Natural engineers and inventors."}
19	20	{"_key": 20, "iconID": 1660, "memory": 0, "nameID": 59481, "charisma": 4, "willpower": 0, "perception": 0, "bloodlineID": 3, "intelligence": 0, "descriptionID": 59438, "shortDescription": "Nomadic merchants looking to strike it rich."}
20	21	{"_key": 21, "iconID": 1661, "memory": 0, "nameID": 59482, "charisma": 0, "willpower": 1, "perception": 3, "bloodlineID": 3, "intelligence": 0, "descriptionID": 59439, "shortDescription": "Those who will never forget."}
21	22	{"_key": 22, "iconID": 1662, "memory": 4, "nameID": 59503, "charisma": 0, "willpower": 0, "perception": 0, "bloodlineID": 4, "intelligence": 0, "descriptionID": 59460, "shortDescription": "People of the fields, mines and factories."}
22	23	{"_key": 23, "iconID": 1663, "memory": 0, "nameID": 59505, "charisma": 1, "willpower": 3, "perception": 0, "bloodlineID": 4, "intelligence": 0, "descriptionID": 59462, "shortDescription": "Staying true to the Way."}
23	24	{"_key": 24, "iconID": 1664, "memory": 0, "nameID": 59504, "charisma": 0, "willpower": 2, "perception": 2, "bloodlineID": 4, "intelligence": 0, "descriptionID": 59461, "shortDescription": "Torn from the cold and brought to the warmth of a new life."}
24	25	{"_key": 25, "memory": 1, "nameID": 59473, "charisma": 0, "willpower": 3, "perception": 0, "bloodlineID": 9, "intelligence": 0, "descriptionID": 59430, "shortDescription": ""}
25	26	{"_key": 26, "memory": 0, "nameID": 59474, "charisma": 4, "willpower": 0, "perception": 0, "bloodlineID": 9, "intelligence": 0, "descriptionID": 59431, "shortDescription": ""}
26	27	{"_key": 27, "memory": 0, "nameID": 59475, "charisma": 0, "willpower": 0, "perception": 4, "bloodlineID": 9, "intelligence": 0, "descriptionID": 59432, "shortDescription": ""}
27	28	{"_key": 28, "memory": 0, "nameID": 59476, "charisma": 0, "willpower": 0, "perception": 1, "bloodlineID": 10, "intelligence": 3, "descriptionID": 59433, "shortDescription": ""}
28	29	{"_key": 29, "memory": 4, "nameID": 59477, "charisma": 0, "willpower": 0, "perception": 0, "bloodlineID": 10, "intelligence": 0, "descriptionID": 59434, "shortDescription": ""}
29	30	{"_key": 30, "memory": 0, "nameID": 59478, "charisma": 0, "willpower": 4, "perception": 0, "bloodlineID": 10, "intelligence": 0, "descriptionID": 59435, "shortDescription": ""}
30	31	{"_key": 31, "iconID": 3025, "memory": 0, "nameID": 59500, "charisma": 0, "willpower": 0, "perception": 0, "bloodlineID": 11, "intelligence": 4, "descriptionID": 59457, "shortDescription": "Those sufficiently attuned with the universe to receive its idea-gifts."}
31	32	{"_key": 32, "iconID": 3027, "memory": 0, "nameID": 59501, "charisma": 0, "willpower": 2, "perception": 2, "bloodlineID": 11, "intelligence": 0, "descriptionID": 59458, "shortDescription": "Aspirants of Achur spiritualism and the quest for perfect understanding."}
32	33	{"_key": 33, "iconID": 3026, "memory": 3, "nameID": 59495, "charisma": 0, "willpower": 0, "perception": 1, "bloodlineID": 11, "intelligence": 0, "descriptionID": 59452, "shortDescription": "Seers of the hidden mysteries before our very eyes."}
33	34	{"_key": 34, "iconID": 3028, "memory": 0, "nameID": 59486, "charisma": 1, "willpower": 3, "perception": 0, "bloodlineID": 12, "intelligence": 0, "descriptionID": 59443, "shortDescription": "Benevolent and charitable, the Sang Do are the ruling class of Jin-Mei society."}
34	35	{"_key": 35, "iconID": 3029, "memory": 2, "nameID": 59487, "charisma": 0, "willpower": 0, "perception": 0, "bloodlineID": 12, "intelligence": 2, "descriptionID": 59444, "shortDescription": "Well-educated and practical thinkers, the Saan Go are the administrative class of the Jin-Mei."}
35	36	{"_key": 36, "iconID": 3030, "memory": 0, "nameID": 59488, "charisma": 0, "willpower": 0, "perception": 4, "bloodlineID": 12, "intelligence": 0, "descriptionID": 59445, "shortDescription": "Traditionally regulated to the lowest tier of Jin-Mei society, exceptional Jing Ko are driven and highly disciplined."}
36	37	{"_key": 37, "iconID": 3031, "memory": 0, "nameID": 59509, "charisma": 0, "willpower": 0, "perception": 3, "bloodlineID": 13, "intelligence": 1, "descriptionID": 59466, "shortDescription": "Spacefaring crusaders, bred for combat superiority."}
37	38	{"_key": 38, "iconID": 3032, "memory": 0, "nameID": 59510, "charisma": 2, "willpower": 0, "perception": 0, "bloodlineID": 13, "intelligence": 2, "descriptionID": 59467, "shortDescription": "Those who would see the Khanid Kingdom and the Amarr Empire reunited."}
38	39	{"_key": 39, "iconID": 3033, "memory": 2, "nameID": 59511, "charisma": 0, "willpower": 2, "perception": 0, "bloodlineID": 13, "intelligence": 0, "descriptionID": 59468, "shortDescription": "Religious fanatics who pursue their faith with fervor."}
39	40	{"_key": 40, "iconID": 3036, "memory": 0, "nameID": 59479, "charisma": 0, "willpower": 0, "perception": 2, "bloodlineID": 14, "intelligence": 2, "descriptionID": 59436, "shortDescription": "Wandering the cluster in search of adventure."}
40	41	{"_key": 41, "iconID": 3034, "memory": 0, "nameID": 59480, "charisma": 0, "willpower": 3, "perception": 0, "bloodlineID": 14, "intelligence": 1, "descriptionID": 59437, "shortDescription": "Revered keepers of ancient, sacred traditions."}
41	42	{"_key": 42, "iconID": 3035, "memory": 3, "nameID": 59506, "charisma": 1, "willpower": 0, "perception": 0, "bloodlineID": 14, "intelligence": 0, "descriptionID": 59463, "shortDescription": "Business owners and purveyors of everyday goods."}
42	64	{"_key": 64, "memory": 0, "nameID": 569662, "charisma": 4, "willpower": 0, "perception": 0, "bloodlineID": 19, "intelligence": 0, "descriptionID": 569663}
\.


--
-- Name: ancestries ancestries_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.ancestries
    ADD CONSTRAINT ancestries_pkey PRIMARY KEY (row_no);


--
-- Name: ancestries_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX ancestries_key_idx ON sde_native.ancestries USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict ZHYDJCJ9Ihesej92AOSPH8akVIE7cLwRJ6KdDm6gRIaC1fjAKWsooGLL6aOOVhG

