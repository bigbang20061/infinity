--
-- PostgreSQL database dump
--

\restrict 5cFZWpQQeyUrE246qti4Zch0AseFkKaPAgbkskSG4eXIjFEZBogVX6JSD8ics51

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: amplificationconstant; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.amplificationconstant (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: amplificationconstant; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.amplificationconstant (row_no, key, data) FROM stdin;
0	0	{"_key": 0, "iskTicket": 79120, "expItemType": 79072, "stageUpTicket": 79074, "matrixGroupType": 4632, "regenerateTicket": 79073, "maxSecondaryLevel": 100, "partialRegenerateCostRate": 10}
\.


--
-- Name: amplificationconstant amplificationconstant_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.amplificationconstant
    ADD CONSTRAINT amplificationconstant_pkey PRIMARY KEY (row_no);


--
-- Name: amplificationconstant_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX amplificationconstant_key_idx ON sde_native.amplificationconstant USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 5cFZWpQQeyUrE246qti4Zch0AseFkKaPAgbkskSG4eXIjFEZBogVX6JSD8ics51

