--
-- PostgreSQL database dump
--

\restrict qu8PHUmXnyyPq0yaW0Q5NyTpQlRscxwfssevlMz8UimFAcv52U0cuU6qUWtGDP0

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: archetypes; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.archetypes (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: archetypes; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.archetypes (row_no, key, data) FROM stdin;
0	0	{"_key": 0, "__repr__": "<archetypesLoader.unnamed_10253632224563664616 object at 0x0000020AB0BEAAB0>", "__type__": "unnamed_10253632224563664616"}
1	1	{"_key": 1, "location": ""}
2	2	{"_key": 2, "titleID": 660909, "location": "", "contentTags": ["career_path_explorer", "feature_landmarks", "activity_travel"], "descriptionID": 660908}
3	3	{"_key": 3, "location": ""}
4	4	{"_key": 4, "location": "Planet"}
5	5	{"_key": 5, "location": "Planet"}
6	6	{"_key": 6, "location": ""}
7	7	{"_key": 7, "location": ""}
8	8	{"_key": 8, "location": "Planet"}
9	9	{"_key": 9, "location": "Sun"}
10	10	{"_key": 10, "location": ""}
11	11	{"_key": 11, "location": "Planet"}
12	12	{"_key": 12, "location": "Planet"}
13	13	{"_key": 13, "location": ""}
14	14	{"_key": 14, "location": ""}
15	15	{"_key": 15, "location": ""}
16	16	{"_key": 16, "location": ""}
17	17	{"_key": 17, "location": ""}
18	18	{"_key": 18, "location": ""}
19	19	{"_key": 19, "location": ""}
20	20	{"_key": 20, "location": "Mission Specific"}
21	21	{"_key": 21, "location": "Mission Specific"}
22	22	{"_key": 22, "location": "Varies"}
23	23	{"_key": 23, "location": "Asteroid belt"}
24	24	{"_key": 24, "titleID": 660871, "location": "", "contentTags": ["feature_combat_anomalies", "career_path_enforcer", "activity_combat"], "descriptionID": 660870}
25	25	{"_key": 25, "location": ""}
26	26	{"_key": 26, "location": ""}
27	27	{"_key": 27, "titleID": 660913, "location": "", "contentTags": ["activity_mining", "career_path_industrialist", "feature_ore_anomalies"], "descriptionID": 660912}
28	28	{"_key": 28, "titleID": 660917, "location": "", "contentTags": ["activity_ice_harvesting", "career_path_industrialist", "feature_ice_belts"], "descriptionID": 660916}
29	29	{"_key": 29, "titleID": 660878, "location": "", "contentTags": ["career_path_enforcer", "career_path_explorer", "activity_combat", "activity_hacking"], "descriptionID": 660877}
30	30	{"_key": 30, "location": ""}
31	31	{"_key": 31, "titleID": 660874, "location": "", "contentTags": ["activity_combat", "career_path_enforcer", "feature_escalation_dungeon"], "descriptionID": 660873}
32	33	{"_key": 33, "titleID": 660881, "contentTags": ["career_path_soldier_of_fortune", "career_path_enforcer", "feature_factional_warfare", "activity_combat"], "descriptionID": 660880}
33	34	{"_key": 34, "titleID": 660883, "contentTags": ["career_path_soldier_of_fortune", "career_path_enforcer", "feature_factional_warfare", "activity_combat"], "descriptionID": 660882}
34	35	{"_key": 35, "titleID": 660885, "contentTags": ["career_path_soldier_of_fortune", "career_path_enforcer", "feature_factional_warfare", "activity_combat"], "descriptionID": 660884}
35	36	{"_key": 36, "titleID": 660887, "contentTags": ["career_path_soldier_of_fortune", "career_path_enforcer", "feature_factional_warfare", "activity_combat"], "descriptionID": 660886}
36	37	{"_key": 37, "location": "Varies"}
37	38	{"_key": 38, "__repr__": "<archetypesLoader.unnamed_10253632224563664616 object at 0x0000020AB0BEAAB0>", "__type__": "unnamed_10253632224563664616"}
38	39	{"_key": 39, "location": "Dungeon Specific"}
39	42	{"_key": 42, "location": ""}
40	43	{"_key": 43, "contentTags": ["career_path_enforcer", "feature_seasons"], "descriptionID": 662247}
41	44	{"_key": 44, "__repr__": "<archetypesLoader.unnamed_10253632224563664616 object at 0x0000020AB0BEAAB0>", "__type__": "unnamed_10253632224563664616"}
42	45	{"_key": 45, "__repr__": "<archetypesLoader.unnamed_10253632224563664616 object at 0x0000020AB0BEAAB0>", "__type__": "unnamed_10253632224563664616"}
43	46	{"_key": 46, "titleID": 660891, "contentTags": ["career_path_enforcer", "feature_sansha_incursions", "activity_combat", "activity_fleet"], "descriptionID": 660890}
44	47	{"_key": 47, "contentTags": ["activity_combat", "activity_mining", "activity_fleet"]}
45	48	{"_key": 48, "__repr__": "<archetypesLoader.unnamed_10253632224563664616 object at 0x0000020AB0BEAAB0>", "__type__": "unnamed_10253632224563664616"}
46	49	{"_key": 49, "__repr__": "<archetypesLoader.unnamed_10253632224563664616 object at 0x0000020AB0BEAAB0>", "__type__": "unnamed_10253632224563664616"}
47	50	{"_key": 50, "titleID": 660911, "descriptionID": 660910}
48	51	{"_key": 51, "__repr__": "<archetypesLoader.unnamed_10253632224563664616 object at 0x0000020AB0BEAAB0>", "__type__": "unnamed_10253632224563664616"}
49	60	{"_key": 60, "titleID": 660893, "contentTags": ["career_path_enforcer", "feature_sansha_incursions", "activity_combat", "activity_fleet"], "descriptionID": 660892}
50	61	{"_key": 61, "titleID": 660895, "contentTags": ["career_path_enforcer", "feature_sansha_incursions", "activity_combat", "activity_fleet"], "descriptionID": 660894}
51	62	{"_key": 62, "titleID": 660897, "contentTags": ["career_path_enforcer", "feature_sansha_incursions", "activity_combat", "activity_fleet"], "descriptionID": 660896}
52	63	{"_key": 63, "titleID": 660899, "contentTags": ["career_path_enforcer", "feature_sansha_incursions", "activity_combat", "activity_fleet"], "descriptionID": 660898}
53	64	{"_key": 64, "titleID": 660901, "contentTags": ["career_path_enforcer", "feature_sansha_incursions", "activity_combat", "activity_fleet"], "descriptionID": 660900}
54	65	{"_key": 65, "titleID": 660903, "contentTags": ["career_path_enforcer", "feature_triglavian", "activity_combat", "activity_fleet"], "descriptionID": 660902}
55	66	{"_key": 66, "titleID": 660919, "contentTags": ["career_path_soldier_of_fortune", "feature_ess", "activity_combat"], "descriptionID": 660918}
56	67	{"_key": 67, "titleID": 660905, "contentTags": ["career_path_soldier_of_fortune", "feature_factional_warfare", "activity_combat"], "descriptionID": 660904}
57	68	{"_key": 68, "titleID": 660907, "contentTags": ["career_path_soldier_of_fortune", "career_path_enforcer", "feature_factional_warfare", "activity_combat"], "descriptionID": 660906}
58	69	{"_key": 69, "__repr__": "<archetypesLoader.unnamed_10253632224563664616 object at 0x0000020AB0BEAAB0>", "__type__": "unnamed_10253632224563664616"}
59	70	{"_key": 70, "titleID": 659479, "contentTags": ["feature_homefront_operations", "activity_fleet"], "descriptionID": 659478}
60	71	{"_key": 71, "titleID": 665279, "contentTags": ["career_path_explorer"], "descriptionID": 665280}
61	72	{"_key": 72, "titleID": 667160, "contentTags": ["feature_pirate_insurgencies", "career_path_soldier_of_fortune", "activity_combat"], "descriptionID": 667159}
62	73	{"_key": 73, "titleID": 667162, "contentTags": ["feature_pirate_insurgencies", "career_path_soldier_of_fortune", "activity_combat"], "descriptionID": 667161}
63	74	{"_key": 74, "titleID": 669950, "contentTags": ["feature_pirate_insurgencies", "career_path_soldier_of_fortune", "activity_combat"], "descriptionID": 669949}
64	75	{"_key": 75, "titleID": 684453, "contentTags": ["feature_pirate_insurgencies", "career_path_soldier_of_fortune", "activity_combat"], "descriptionID": 684452}
65	76	{"_key": 76, "titleID": 684455, "contentTags": ["feature_pirate_insurgencies", "career_path_soldier_of_fortune", "activity_combat"], "descriptionID": 684454}
66	77	{"_key": 77, "titleID": 684457, "contentTags": ["feature_pirate_insurgencies", "career_path_soldier_of_fortune", "activity_combat"], "descriptionID": 684456}
67	78	{"_key": 78, "titleID": 684464, "contentTags": ["feature_pirate_insurgencies", "career_path_soldier_of_fortune", "activity_combat"], "descriptionID": 684463}
68	79	{"_key": 79, "titleID": 684466, "contentTags": ["feature_pirate_insurgencies", "career_path_soldier_of_fortune", "activity_combat"], "descriptionID": 684465}
69	80	{"_key": 80, "titleID": 871834, "contentTags": ["activity_combat", "career_path_enforcer"], "descriptionID": 871833}
70	81	{"_key": 81, "titleID": 1019640, "contentTags": ["activity_mining", "career_path_industrialist", "career_path_explorer"], "descriptionID": 1019639}
\.


--
-- Name: archetypes archetypes_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.archetypes
    ADD CONSTRAINT archetypes_pkey PRIMARY KEY (row_no);


--
-- Name: archetypes_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX archetypes_key_idx ON sde_native.archetypes USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict qu8PHUmXnyyPq0yaW0Q5NyTpQlRscxwfssevlMz8UimFAcv52U0cuU6qUWtGDP0

