--
-- PostgreSQL database dump
--

\restrict aMbCslWJdJJUwRpveZ7abSX3yzDbGZP8YuVYxIMRSrpzesZVnYmNGw1ITO5tNqw

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: community_track_templates; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.community_track_templates (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: community_track_templates; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.community_track_templates (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "goal": 100, "name": "Vanguard Nemesis Event", "tale_templates": [466, 470, 467, 471, 474, 468, 472, 469, 473, 475, 476, 480, 477, 481, 484, 478, 482, 479, 483, 485]}
\.


--
-- Name: community_track_templates community_track_templates_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.community_track_templates
    ADD CONSTRAINT community_track_templates_pkey PRIMARY KEY (row_no);


--
-- Name: community_track_templates_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX community_track_templates_key_idx ON sde_native.community_track_templates USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict aMbCslWJdJJUwRpveZ7abSX3yzDbGZP8YuVYxIMRSrpzesZVnYmNGw1ITO5tNqw

