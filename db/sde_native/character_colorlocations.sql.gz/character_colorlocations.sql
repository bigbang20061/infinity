--
-- PostgreSQL database dump
--

\restrict 9qyPiZB8Zw68kbqbfo68gymPzHuuZ5BaCRusWQvIrf3CjklJ09S4d2Vmj8NRzH7

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: character_colorlocations; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.character_colorlocations (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: character_colorlocations; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.character_colorlocations (row_no, key, data) FROM stdin;
0	2	{"_key": 2, "colorKey": "topouter", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
1	3	{"_key": 3, "colorKey": "makeup/implants", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
2	4	{"_key": 4, "colorKey": "accessories/earslow", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
3	5	{"_key": 5, "colorKey": "skintone", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
4	6	{"_key": 6, "colorKey": "hair", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 1}
5	7	{"_key": 7, "colorKey": "makeup/eyes", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
6	8	{"_key": 8, "colorKey": "makeup/lipstick", "hasGloss": 1, "hasWeight": 1, "hasSecondary": 0}
7	9	{"_key": 9, "colorKey": "makeup/blush", "hasGloss": 0, "hasWeight": 1, "hasSecondary": 0}
8	10	{"_key": 10, "colorKey": "makeup/eyeshadow", "hasGloss": 0, "hasWeight": 1, "hasSecondary": 1}
9	11	{"_key": 11, "colorKey": "outer", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
10	12	{"_key": 12, "colorKey": "accessories/nose", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
11	13	{"_key": 13, "colorKey": "accessories/nostril", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
12	14	{"_key": 14, "colorKey": "accessories/lips", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
13	15	{"_key": 15, "colorKey": "beard", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
14	16	{"_key": 16, "colorKey": "makeup/eyeliner", "hasGloss": 0, "hasWeight": 1, "hasSecondary": 0}
15	17	{"_key": 17, "colorKey": "topmiddle", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
16	18	{"_key": 18, "colorKey": "accessories/earshigh", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
17	19	{"_key": 19, "colorKey": "makeup/eyebrows", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
18	20	{"_key": 20, "colorKey": "accessories/glasses", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
19	21	{"_key": 21, "colorKey": "feet", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
20	22	{"_key": 22, "colorKey": "bottominner", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
21	23	{"_key": 23, "colorKey": "bottomouter", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
22	24	{"_key": 24, "colorKey": "accessories/brow", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
23	25	{"_key": 25, "colorKey": "topinner", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
24	26	{"_key": 26, "colorKey": "tattoo/head", "hasGloss": 1, "hasWeight": 1, "hasSecondary": 0}
25	27	{"_key": 27, "colorKey": "accessories/piercings", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
26	88	{"_key": 88, "colorKey": "topunderwear", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
27	89	{"_key": 89, "colorKey": "bottomunderwear", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
28	90	{"_key": 90, "colorKey": "bottommiddle", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
29	115	{"_key": 115, "colorKey": "paperdoll/makeup/eyeshadow", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 1}
30	116	{"_key": 116, "colorKey": "paperdoll/makeup/lipstick", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
31	117	{"_key": 117, "colorKey": "paperdoll/bottomunderwear", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
32	118	{"_key": 118, "colorKey": "paperdoll/bottominner", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
33	119	{"_key": 119, "colorKey": "paperdoll/topunderwear", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
34	120	{"_key": 120, "colorKey": "paperdoll/topinner", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
35	121	{"_key": 121, "colorKey": "paperdoll/makeup/eyes", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
36	122	{"_key": 122, "colorKey": "paperdoll/outer", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
37	123	{"_key": 123, "colorKey": "paperdoll/bottomouter", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
38	124	{"_key": 124, "colorKey": "paperdoll/makeup/eyeliner", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
39	125	{"_key": 125, "colorKey": "paperdoll/accessories/brow", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
40	126	{"_key": 126, "colorKey": "paperdoll/accessories/glasses", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
41	127	{"_key": 127, "colorKey": "paperdoll/makeup/blush", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
42	128	{"_key": 128, "colorKey": "paperdoll/feet", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
43	129	{"_key": 129, "colorKey": "paperdoll/topouter", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
44	130	{"_key": 130, "colorKey": "paperdoll/bottommiddle", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
45	131	{"_key": 131, "colorKey": "paperdoll/topmiddle", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
46	132	{"_key": 132, "colorKey": "paperdoll/accessories/piercings", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
47	133	{"_key": 133, "colorKey": "paperdoll/skintone", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
48	134	{"_key": 134, "colorKey": "paperdoll/hair", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 1}
49	135	{"_key": 135, "colorKey": "paperdoll/tattoo/head", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
50	136	{"_key": 136, "colorKey": "paperdoll/beard", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
51	137	{"_key": 137, "colorKey": "paperdoll/makeup/eyebrows", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
52	138	{"_key": 138, "colorKey": "paperdoll/makeup/implants", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
53	139	{"_key": 139, "colorKey": "paperdoll/makeup/eyelashes", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
54	140	{"_key": 140, "colorKey": "paperdoll/skintype", "hasGloss": 0, "hasWeight": 0, "hasSecondary": 0}
\.


--
-- Name: character_colorlocations character_colorlocations_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.character_colorlocations
    ADD CONSTRAINT character_colorlocations_pkey PRIMARY KEY (row_no);


--
-- Name: character_colorlocations_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX character_colorlocations_key_idx ON sde_native.character_colorlocations USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 9qyPiZB8Zw68kbqbfo68gymPzHuuZ5BaCRusWQvIrf3CjklJ09S4d2Vmj8NRzH7

