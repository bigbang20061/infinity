--
-- PostgreSQL database dump
--

\restrict 3NsIgJ3Hk5urzozImIforQJdgDIXPYDGJ175RDaMfHChzt8fXeTRIMugc8KVd6X

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bracketsbycategory; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.bracketsbycategory (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: bracketsbycategory; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.bracketsbycategory (row_no, key, data) FROM stdin;
0	11	{"_key": 11, "value": 2366}
1	18	{"_key": 18, "value": 2399}
2	22	{"_key": 22, "value": 2370}
3	23	{"_key": 23, "value": 2370}
4	25	{"_key": 25, "value": 2423}
5	40	{"_key": 40, "value": 2370}
6	65	{"_key": 65, "value": 2370}
\.


--
-- Name: bracketsbycategory bracketsbycategory_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.bracketsbycategory
    ADD CONSTRAINT bracketsbycategory_pkey PRIMARY KEY (row_no);


--
-- Name: bracketsbycategory_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX bracketsbycategory_key_idx ON sde_native.bracketsbycategory USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 3NsIgJ3Hk5urzozImIforQJdgDIXPYDGJ175RDaMfHChzt8fXeTRIMugc8KVd6X

