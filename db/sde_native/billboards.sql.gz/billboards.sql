--
-- PostgreSQL database dump
--

\restrict FvUripyWuo68b9mPgGJqq552SuMweuc2fIvdgAAUk6iL6SjdTCfCiV53ETPcZKk

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: billboards; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.billboards (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: billboards; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.billboards (row_no, key, data) FROM stdin;
0	hangar	{"_key": "hangar", "hangarvideos": {"size": [1024.0, 576.0], "sound": 0, "folders": {"default": ["res:/video/billboards/common"], "languageOverrides": {"zh": ["res:/video/billboards_zn/common"]}}, "description": "All hangar videos", "fallbackImage": "res:/video/billboards/fallback.png", "gameplayFolderOverrides": {"triglavianInvasion": {"default": ["res:/video/billboards/takeover"], "languageOverrides": {"zh": ["res:/video/billboards_zn/takeover"]}}, "triglavianOvertaken": {"default": ["res:/video/billboards/triglavianhangar"], "languageOverrides": {"zh": ["res:/video/billboards_zn/triglavianhangar"]}}}}}
1	inflight	{"_key": "inflight", "inspacevideos": {"size": [1024.0, 576.0], "sound": 0, "folders": {"default": ["res:/video/billboards/common", "res:/video/billboards/space"], "languageOverrides": {"zh": ["res:/video/billboards_zn/common", "res:/video/billboards_zn/space"]}}, "description": "All in space videos, around stations, jump gates etc", "fallbackImage": "res:/video/billboards/fallback.png", "gameplayFolderOverrides": {"triglavianInvasion": {"default": ["res:/video/billboards/takeover"], "languageOverrides": {"zh": ["res:/video/billboards_zn/takeover"]}}}}}
\.


--
-- Name: billboards billboards_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.billboards
    ADD CONSTRAINT billboards_pkey PRIMARY KEY (row_no);


--
-- Name: billboards_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX billboards_key_idx ON sde_native.billboards USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict FvUripyWuo68b9mPgGJqq552SuMweuc2fIvdgAAUk6iL6SjdTCfCiV53ETPcZKk

