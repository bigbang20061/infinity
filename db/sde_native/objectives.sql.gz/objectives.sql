--
-- PostgreSQL database dump
--

\restrict nxExIARtMH0u53EqooZ2U55bWW5JWOGAwHARqWXVrmYrZXtOFKfEQkhrOS6UUcy

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: objectives; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.objectives (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: objectives; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.objectives (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "name": "[AIR NPE] 4.1 Before warp", "text": 595705, "title": 595706, "dungeonID": 9245, "titleIcon": "res:/UI/Texture/classes/MissionTracker/tracker_destination.png"}
1	3	{"_key": 3, "name": "[AIR NPE] 4.2", "text": 595710, "title": 595711, "titleIcon": "res:/UI/Texture/classes/MissionTracker/tracker_mining.png", "iconTypeID": 60771}
2	5	{"_key": 5, "name": "[AIR NPE] 4.3", "text": 595716, "title": 595717, "titleIcon": "res:/UI/Texture/classes/MissionTracker/wreckNPC.png"}
3	6	{"_key": 6, "name": "[AIR NPE] 4.4", "text": 595718, "title": 595719, "titleIcon": "res:/UI/Texture/classes/MissionTracker/tracker_dropoff.png", "iconTypeID": 60784}
4	7	{"_key": 7, "name": "[NES Intro] Return to station", "text": 639668, "title": 639669, "titleIcon": "res:/UI/Texture/classes/MissionTracker/tracker_destination.png"}
5	8	{"_key": 8, "name": "[NES Intro] Do the mission", "text": 639670, "title": 639671, "titleIcon": "res:/UI/Texture/classes/MissionTracker/tracker_dropoff.png"}
6	11	{"_key": 11, "name": "[MAP Onboarding] Return to Station", "text": 1022938, "title": 1022939, "titleIcon": "res:/UI/Texture/classes/MissionTracker/tracker_destination.png"}
7	12	{"_key": 12, "name": "[MAP onboarding] Do the mission", "text": 1022943, "title": 1022944, "titleIcon": "res:/UI/Texture/classes/MissionTracker/tracker_dropoff.png"}
\.


--
-- Name: objectives objectives_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.objectives
    ADD CONSTRAINT objectives_pkey PRIMARY KEY (row_no);


--
-- Name: objectives_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX objectives_key_idx ON sde_native.objectives USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict nxExIARtMH0u53EqooZ2U55bWW5JWOGAwHARqWXVrmYrZXtOFKfEQkhrOS6UUcy

