--
-- PostgreSQL database dump
--

\restrict o3zBPQgGr1IT7SZdfuNebFksLvYozsr2MDRw7NzvCJR4y49HxUtqdAnFF8qkgHI

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: seasonselection; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.seasonselection (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: seasonselection; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.seasonselection (row_no, key, data) FROM stdin;
0	\N	{"seasonSelectionHintID": 583335, "seasonSelectionTitleID": 583333, "navigation_card_picture_path": "res:/UI/Texture/classes/Seasons/Agency/NavigationCard/GallenteElection_Agency_Navicons_400x666.png", "seasonSelectionDescriptionID": 583334, "agencyLargeSeasonSelectionTitleID": 583380}
\.


--
-- Name: seasonselection seasonselection_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.seasonselection
    ADD CONSTRAINT seasonselection_pkey PRIMARY KEY (row_no);


--
-- Name: seasonselection_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX seasonselection_key_idx ON sde_native.seasonselection USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict o3zBPQgGr1IT7SZdfuNebFksLvYozsr2MDRw7NzvCJR4y49HxUtqdAnFF8qkgHI

