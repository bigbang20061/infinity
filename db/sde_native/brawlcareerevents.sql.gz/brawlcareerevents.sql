--
-- PostgreSQL database dump
--

\restrict r30nqbnr0aLgLuGOoCF5aGL2mZyqTccGCGRIebI7lHhzHMAp0hSLft0cPYEdnIW

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: brawlcareerevents; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.brawlcareerevents (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: brawlcareerevents; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.brawlcareerevents (row_no, key, data) FROM stdin;
0	10100	{"_key": 10100, "name": "FightResult", "conditions": [{"name": "FightResultFight", "condition_type": 10101}, {"name": "FightResultCharacter", "condition_type": 10102}, {"name": "FightResultFittingPlan", "condition_type": 10103}, {"name": "FightResultKillCount", "condition_type": 10104}, {"name": "FightResultRank", "condition_type": 10105}, {"name": "FightResultTotalDoDamage", "condition_type": 10106}, {"name": "FightResultTotalBeDamaged", "condition_type": 10107}, {"name": "FightResultCargoOverload", "condition_type": 10108}, {"name": "FightItemPickCount", "condition_type": 10109}, {"name": "FightUnlockedSkills", "condition_type": 10110}, {"name": "FightUpgradedSkills", "condition_type": 10111}, {"name": "FightSkillEjectCount", "condition_type": 10112}, {"name": "FightCloudEjectOrder", "condition_type": 10113}, {"name": "FightKillOrder", "condition_type": 10114}, {"name": "FightMovementOrder", "condition_type": 10115}, {"name": "ModuleSuitCollectedSuit", "condition_type": 10116}, {"name": "ShipModuleFlagsAllFitFight", "condition_type": 10117}]}
\.


--
-- Name: brawlcareerevents brawlcareerevents_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.brawlcareerevents
    ADD CONSTRAINT brawlcareerevents_pkey PRIMARY KEY (row_no);


--
-- Name: brawlcareerevents_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX brawlcareerevents_key_idx ON sde_native.brawlcareerevents USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict r30nqbnr0aLgLuGOoCF5aGL2mZyqTccGCGRIebI7lHhzHMAp0hSLft0cPYEdnIW

