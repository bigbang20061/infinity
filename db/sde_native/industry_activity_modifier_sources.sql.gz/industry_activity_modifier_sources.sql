--
-- PostgreSQL database dump
--

\restrict K0eYQ1kxwoBbhPHd8J40U1cayDpmKJw9lqeFV0lTWqH93qRVbSs8oFvY3ymCoB0

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: industry_activity_modifier_sources; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.industry_activity_modifier_sources (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: industry_activity_modifier_sources; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.industry_activity_modifier_sources (row_no, key, data) FROM stdin;
0	35825	{"_key": 35825, "copying": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "manufacturing": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}}
1	35826	{"_key": 35826, "copying": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "manufacturing": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}}
2	35827	{"_key": 35827, "copying": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "manufacturing": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}}
3	35836	{"_key": 35836, "reaction": {"cost": [], "time": [{"dogmaAttributeID": 2721}], "material": []}}
4	37146	{"_key": 37146, "manufacturing": {"material": [{"filterID": 7, "dogmaAttributeID": 2546}]}}
5	37147	{"_key": 37147, "manufacturing": {"material": [{"filterID": 7, "dogmaAttributeID": 2546}]}}
6	37148	{"_key": 37148, "manufacturing": {"cost": [], "time": [{"filterID": 1, "dogmaAttributeID": 2543}], "material": []}}
7	37149	{"_key": 37149, "manufacturing": {"time": [{"filterID": 1, "dogmaAttributeID": 2543}]}}
8	37150	{"_key": 37150, "manufacturing": {"time": [{"filterID": 4, "dogmaAttributeID": 2541}]}}
9	37151	{"_key": 37151, "manufacturing": {"time": [{"filterID": 4, "dogmaAttributeID": 2541}]}}
10	37152	{"_key": 37152, "manufacturing": {"material": [{"filterID": 9, "dogmaAttributeID": 2548}]}}
11	37153	{"_key": 37153, "manufacturing": {"time": [{"filterID": 7, "dogmaAttributeID": 2547}]}}
12	37154	{"_key": 37154, "manufacturing": {"material": [{"filterID": 5, "dogmaAttributeID": 2544}]}}
13	37155	{"_key": 37155, "manufacturing": {"material": [{"filterID": 5, "dogmaAttributeID": 2544}]}}
14	37156	{"_key": 37156, "manufacturing": {"material": [{"filterID": 1, "dogmaAttributeID": 2542}]}}
15	37157	{"_key": 37157, "manufacturing": {"material": [{"filterID": 1, "dogmaAttributeID": 2542}]}}
16	37158	{"_key": 37158, "manufacturing": {"material": [{"filterID": 4, "dogmaAttributeID": 2540}]}}
17	37159	{"_key": 37159, "manufacturing": {"material": [{"filterID": 4, "dogmaAttributeID": 2540}]}}
18	37160	{"_key": 37160, "manufacturing": {"time": [{"filterID": 2, "dogmaAttributeID": 2539}]}}
19	37161	{"_key": 37161, "manufacturing": {"time": [{"filterID": 2, "dogmaAttributeID": 2539}]}}
20	37162	{"_key": 37162, "manufacturing": {"time": [{"filterID": 5, "dogmaAttributeID": 2545}]}}
21	37163	{"_key": 37163, "manufacturing": {"time": [{"filterID": 5, "dogmaAttributeID": 2545}]}}
22	37164	{"_key": 37164, "manufacturing": {"time": [{"filterID": 4, "dogmaAttributeID": 2541}], "material": [{"filterID": 4, "dogmaAttributeID": 2540}]}}
23	37165	{"_key": 37165, "manufacturing": {"time": [{"filterID": 4, "dogmaAttributeID": 2541}], "material": [{"filterID": 4, "dogmaAttributeID": 2540}]}}
24	37166	{"_key": 37166, "manufacturing": {"time": [{"filterID": 9, "dogmaAttributeID": 2549}], "material": [{"filterID": 9, "dogmaAttributeID": 2548}]}}
25	37167	{"_key": 37167, "manufacturing": {"time": [{"filterID": 9, "dogmaAttributeID": 2549}], "material": [{"filterID": 9, "dogmaAttributeID": 2548}]}}
26	37168	{"_key": 37168, "manufacturing": {"time": [{"filterID": 10, "dogmaAttributeID": 2556}], "material": [{"filterID": 10, "dogmaAttributeID": 2555}]}}
27	37169	{"_key": 37169, "manufacturing": {"time": [{"filterID": 10, "dogmaAttributeID": 2556}], "material": [{"filterID": 10, "dogmaAttributeID": 2555}]}}
28	37170	{"_key": 37170, "manufacturing": {"time": [{"filterID": 2, "dogmaAttributeID": 2539}], "material": [{"filterID": 2, "dogmaAttributeID": 2538}]}}
29	37171	{"_key": 37171, "manufacturing": {"time": [{"filterID": 2, "dogmaAttributeID": 2539}], "material": [{"filterID": 2, "dogmaAttributeID": 2538}]}}
30	37172	{"_key": 37172, "manufacturing": {"time": [{"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"filterID": 11, "dogmaAttributeID": 2575}]}}
31	37173	{"_key": 37173, "manufacturing": {"time": [{"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"filterID": 11, "dogmaAttributeID": 2575}]}}
32	37174	{"_key": 37174, "manufacturing": {"cost": [], "time": [{"filterID": 14, "dogmaAttributeID": 2558}, {"filterID": 15, "dogmaAttributeID": 2659}], "material": [{"filterID": 14, "dogmaAttributeID": 2557}, {"filterID": 15, "dogmaAttributeID": 2658}]}}
33	37175	{"_key": 37175, "manufacturing": {"cost": [], "time": [{"filterID": 14, "dogmaAttributeID": 2558}, {"filterID": 15, "dogmaAttributeID": 2659}], "material": [{"filterID": 14, "dogmaAttributeID": 2557}, {"filterID": 15, "dogmaAttributeID": 2658}]}}
34	37178	{"_key": 37178, "manufacturing": {"cost": [], "time": [{"filterID": 2, "dogmaAttributeID": 2539}, {"filterID": 4, "dogmaAttributeID": 2541}, {"filterID": 1, "dogmaAttributeID": 2543}], "material": [{"filterID": 2, "dogmaAttributeID": 2538}, {"filterID": 4, "dogmaAttributeID": 2540}, {"filterID": 1, "dogmaAttributeID": 2542}]}}
35	37179	{"_key": 37179, "manufacturing": {"time": [{"filterID": 2, "dogmaAttributeID": 2539}, {"filterID": 4, "dogmaAttributeID": 2541}, {"filterID": 1, "dogmaAttributeID": 2543}], "material": [{"filterID": 2, "dogmaAttributeID": 2538}, {"filterID": 4, "dogmaAttributeID": 2540}, {"filterID": 1, "dogmaAttributeID": 2542}]}}
36	37180	{"_key": 37180, "manufacturing": {"time": [{"filterID": 3, "dogmaAttributeID": 2591}], "material": [{"filterID": 3, "dogmaAttributeID": 2592}]}}
37	37181	{"_key": 37181, "manufacturing": {"time": [{"filterID": 3, "dogmaAttributeID": 2591}], "material": [{"filterID": 3, "dogmaAttributeID": 2592}]}}
38	37182	{"_key": 37182, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}]}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [{"dogmaAttributeID": 2564}]}, "research_time": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}]}, "research_material": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}]}}
39	37183	{"_key": 37183, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}]}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [{"dogmaAttributeID": 2564}]}, "research_time": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}]}, "research_material": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}]}}
40	43704	{"_key": 43704, "manufacturing": {"cost": [], "time": [{"filterID": 14, "dogmaAttributeID": 2558}, {"filterID": 13, "dogmaAttributeID": 2560}, {"filterID": 12, "dogmaAttributeID": 2562}, {"filterID": 15, "dogmaAttributeID": 2659}], "material": [{"filterID": 14, "dogmaAttributeID": 2557}, {"filterID": 13, "dogmaAttributeID": 2559}, {"filterID": 12, "dogmaAttributeID": 2561}, {"filterID": 15, "dogmaAttributeID": 2658}]}}
41	43705	{"_key": 43705, "manufacturing": {"cost": [], "time": [{"filterID": 14, "dogmaAttributeID": 2558}, {"filterID": 13, "dogmaAttributeID": 2560}, {"filterID": 12, "dogmaAttributeID": 2562}, {"filterID": 15, "dogmaAttributeID": 2659}], "material": [{"filterID": 14, "dogmaAttributeID": 2557}, {"filterID": 13, "dogmaAttributeID": 2559}, {"filterID": 12, "dogmaAttributeID": 2561}, {"filterID": 15, "dogmaAttributeID": 2658}]}}
42	43707	{"_key": 43707, "manufacturing": {"cost": [], "time": [{"filterID": 6, "dogmaAttributeID": 2551}], "material": [{"filterID": 6, "dogmaAttributeID": 2550}]}}
43	43708	{"_key": 43708, "manufacturing": {"time": [{"filterID": 6, "dogmaAttributeID": 2551}], "material": [{"filterID": 6, "dogmaAttributeID": 2550}]}}
44	43709	{"_key": 43709, "manufacturing": {"time": [{"filterID": 8, "dogmaAttributeID": 2553}], "material": [{"filterID": 8, "dogmaAttributeID": 2552}]}}
45	43711	{"_key": 43711, "manufacturing": {"time": [{"filterID": 8, "dogmaAttributeID": 2553}], "material": [{"filterID": 8, "dogmaAttributeID": 2552}]}}
46	43712	{"_key": 43712, "manufacturing": {"cost": [], "time": [{"filterID": 1, "dogmaAttributeID": 2543}], "material": [{"filterID": 1, "dogmaAttributeID": 2542}]}}
47	43713	{"_key": 43713, "manufacturing": {"time": [{"filterID": 1, "dogmaAttributeID": 2543}], "material": [{"filterID": 1, "dogmaAttributeID": 2542}]}}
48	43714	{"_key": 43714, "manufacturing": {"time": [{"filterID": 5, "dogmaAttributeID": 2545}], "material": [{"filterID": 5, "dogmaAttributeID": 2544}]}}
49	43715	{"_key": 43715, "manufacturing": {"time": [{"filterID": 5, "dogmaAttributeID": 2545}], "material": [{"filterID": 5, "dogmaAttributeID": 2544}]}}
50	43716	{"_key": 43716, "manufacturing": {"time": [{"filterID": 7, "dogmaAttributeID": 2547}], "material": [{"filterID": 7, "dogmaAttributeID": 2546}]}}
51	43717	{"_key": 43717, "manufacturing": {"time": [{"filterID": 7, "dogmaAttributeID": 2547}], "material": [{"filterID": 7, "dogmaAttributeID": 2546}]}}
52	43718	{"_key": 43718, "manufacturing": {"time": [{"filterID": 13, "dogmaAttributeID": 2560}], "material": [{"filterID": 13, "dogmaAttributeID": 2559}]}}
53	43719	{"_key": 43719, "manufacturing": {"time": [{"filterID": 13, "dogmaAttributeID": 2560}], "material": [{"filterID": 13, "dogmaAttributeID": 2559}]}}
54	43720	{"_key": 43720, "manufacturing": {"time": [{"filterID": 12, "dogmaAttributeID": 2562}], "material": [{"filterID": 12, "dogmaAttributeID": 2561}]}}
55	43721	{"_key": 43721, "manufacturing": {"time": [{"filterID": 12, "dogmaAttributeID": 2562}], "material": [{"filterID": 12, "dogmaAttributeID": 2561}]}}
56	43722	{"_key": 43722, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [{"dogmaAttributeID": 2564}]}}
57	43723	{"_key": 43723, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [{"dogmaAttributeID": 2564}]}}
58	43724	{"_key": 43724, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}]}}
59	43725	{"_key": 43725, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}]}}
60	43726	{"_key": 43726, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}]}}
61	43727	{"_key": 43727, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}]}}
62	43729	{"_key": 43729, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}]}}
63	43730	{"_key": 43730, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}]}}
64	43732	{"_key": 43732, "manufacturing": {"material": [{"filterID": 9, "dogmaAttributeID": 2548}]}}
65	43733	{"_key": 43733, "manufacturing": {"time": [{"filterID": 9, "dogmaAttributeID": 2549}]}}
66	43734	{"_key": 43734, "manufacturing": {"time": [{"filterID": 9, "dogmaAttributeID": 2549}]}}
67	43854	{"_key": 43854, "manufacturing": {"material": [{"filterID": 6, "dogmaAttributeID": 2550}]}}
68	43855	{"_key": 43855, "manufacturing": {"material": [{"filterID": 6, "dogmaAttributeID": 2550}]}}
69	43856	{"_key": 43856, "manufacturing": {"time": [{"filterID": 6, "dogmaAttributeID": 2551}]}}
70	43857	{"_key": 43857, "manufacturing": {"time": [{"filterID": 6, "dogmaAttributeID": 2551}]}}
71	43858	{"_key": 43858, "manufacturing": {"material": [{"filterID": 8, "dogmaAttributeID": 2552}]}}
72	43859	{"_key": 43859, "manufacturing": {"material": [{"filterID": 8, "dogmaAttributeID": 2552}]}}
73	43860	{"_key": 43860, "manufacturing": {"time": [{"filterID": 8, "dogmaAttributeID": 2553}]}}
74	43861	{"_key": 43861, "manufacturing": {"time": [{"filterID": 8, "dogmaAttributeID": 2553}]}}
75	43862	{"_key": 43862, "manufacturing": {"material": [{"filterID": 10, "dogmaAttributeID": 2555}]}}
76	43863	{"_key": 43863, "manufacturing": {"material": [{"filterID": 10, "dogmaAttributeID": 2555}]}}
77	43864	{"_key": 43864, "manufacturing": {"time": [{"filterID": 10, "dogmaAttributeID": 2556}]}}
78	43865	{"_key": 43865, "manufacturing": {"time": [{"filterID": 10, "dogmaAttributeID": 2556}]}}
79	43866	{"_key": 43866, "manufacturing": {"cost": [], "time": [], "material": [{"filterID": 14, "dogmaAttributeID": 2557}, {"filterID": 15, "dogmaAttributeID": 2658}]}}
80	43867	{"_key": 43867, "manufacturing": {"cost": [], "time": [], "material": [{"filterID": 14, "dogmaAttributeID": 2557}, {"filterID": 15, "dogmaAttributeID": 2658}]}}
81	43868	{"_key": 43868, "manufacturing": {"cost": [], "time": [{"filterID": 14, "dogmaAttributeID": 2558}, {"filterID": 15, "dogmaAttributeID": 2659}], "material": []}}
82	43869	{"_key": 43869, "manufacturing": {"cost": [], "time": [{"filterID": 14, "dogmaAttributeID": 2558}, {"filterID": 15, "dogmaAttributeID": 2659}], "material": []}}
83	43870	{"_key": 43870, "manufacturing": {"material": [{"filterID": 13, "dogmaAttributeID": 2559}]}}
84	43871	{"_key": 43871, "manufacturing": {"material": [{"filterID": 13, "dogmaAttributeID": 2559}]}}
85	43872	{"_key": 43872, "manufacturing": {"time": [{"filterID": 13, "dogmaAttributeID": 2560}]}}
86	43873	{"_key": 43873, "manufacturing": {"time": [{"filterID": 13, "dogmaAttributeID": 2560}]}}
87	43874	{"_key": 43874, "manufacturing": {"material": [{"filterID": 12, "dogmaAttributeID": 2561}]}}
88	43875	{"_key": 43875, "manufacturing": {"material": [{"filterID": 12, "dogmaAttributeID": 2561}]}}
89	43876	{"_key": 43876, "manufacturing": {"time": [{"filterID": 12, "dogmaAttributeID": 2562}]}}
90	43877	{"_key": 43877, "manufacturing": {"time": [{"filterID": 12, "dogmaAttributeID": 2562}]}}
91	43878	{"_key": 43878, "invention": {"cost": [{"dogmaAttributeID": 2563}]}}
92	43879	{"_key": 43879, "invention": {"cost": [{"dogmaAttributeID": 2563}]}}
93	43880	{"_key": 43880, "invention": {"time": [{"dogmaAttributeID": 2564}]}}
94	43881	{"_key": 43881, "invention": {"time": [{"dogmaAttributeID": 2564}]}}
95	43882	{"_key": 43882, "research_material": {"time": [{"dogmaAttributeID": 2566}]}}
96	43883	{"_key": 43883, "research_material": {"time": [{"dogmaAttributeID": 2566}]}}
97	43884	{"_key": 43884, "research_material": {"cost": [{"dogmaAttributeID": 2565}]}}
98	43885	{"_key": 43885, "research_material": {"cost": [{"dogmaAttributeID": 2565}]}}
99	43886	{"_key": 43886, "research_time": {"cost": [{"dogmaAttributeID": 2567}]}}
100	43887	{"_key": 43887, "research_time": {"cost": [{"dogmaAttributeID": 2567}]}}
101	43888	{"_key": 43888, "research_time": {"time": [{"dogmaAttributeID": 2568}]}}
102	43889	{"_key": 43889, "research_time": {"time": [{"dogmaAttributeID": 2568}]}}
103	43890	{"_key": 43890, "copying": {"cost": [{"dogmaAttributeID": 2569}]}}
104	43891	{"_key": 43891, "copying": {"cost": [{"dogmaAttributeID": 2569}]}}
105	43892	{"_key": 43892, "copying": {"time": [{"dogmaAttributeID": 2570}]}}
106	43893	{"_key": 43893, "copying": {"time": [{"dogmaAttributeID": 2570}]}}
107	43919	{"_key": 43919, "manufacturing": {"time": [{"filterID": 7, "dogmaAttributeID": 2547}]}}
108	43920	{"_key": 43920, "manufacturing": {"material": [{"filterID": 2, "dogmaAttributeID": 2538}]}}
109	43921	{"_key": 43921, "manufacturing": {"material": [{"filterID": 2, "dogmaAttributeID": 2538}]}}
110	45544	{"_key": 45544, "manufacturing": {"cost": [], "time": [], "material": [{"filterID": 13, "dogmaAttributeID": 2559}]}}
111	45546	{"_key": 45546, "manufacturing": {"cost": [], "time": [{"filterID": 13, "dogmaAttributeID": 2560}], "material": [{"filterID": 13, "dogmaAttributeID": 2559}]}}
112	45548	{"_key": 45548, "manufacturing": {"cost": [], "time": [{"filterID": 14, "dogmaAttributeID": 2558}, {"filterID": 13, "dogmaAttributeID": 2560}, {"filterID": 12, "dogmaAttributeID": 2562}, {"filterID": 15, "dogmaAttributeID": 2659}], "material": [{"filterID": 14, "dogmaAttributeID": 2557}, {"filterID": 13, "dogmaAttributeID": 2559}, {"filterID": 12, "dogmaAttributeID": 2561}, {"filterID": 15, "dogmaAttributeID": 2658}]}}
113	45640	{"_key": 45640, "manufacturing": {"cost": [], "time": [], "material": [{"filterID": 14, "dogmaAttributeID": 2557}, {"filterID": 15, "dogmaAttributeID": 2658}]}}
114	45641	{"_key": 45641, "manufacturing": {"cost": [], "time": [{"filterID": 14, "dogmaAttributeID": 2558}, {"filterID": 15, "dogmaAttributeID": 2659}], "material": [{"filterID": 14, "dogmaAttributeID": 2557}, {"filterID": 15, "dogmaAttributeID": 2658}]}}
115	46484	{"_key": 46484, "reaction": {"cost": [], "time": [{"filterID": 18, "dogmaAttributeID": 2717}], "material": []}}
116	46485	{"_key": 46485, "reaction": {"cost": [], "time": [{"filterID": 18, "dogmaAttributeID": 2717}], "material": []}}
117	46486	{"_key": 46486, "reaction": {"cost": [], "time": [], "material": [{"filterID": 18, "dogmaAttributeID": 2718}]}}
118	46487	{"_key": 46487, "reaction": {"cost": [], "time": [], "material": [{"filterID": 18, "dogmaAttributeID": 2718}]}}
119	46488	{"_key": 46488, "reaction": {"cost": [], "time": [{"filterID": 16, "dogmaAttributeID": 2715}], "material": []}}
120	46489	{"_key": 46489, "reaction": {"cost": [], "time": [{"filterID": 16, "dogmaAttributeID": 2715}], "material": []}}
121	46490	{"_key": 46490, "reaction": {"cost": [], "time": [], "material": [{"filterID": 16, "dogmaAttributeID": 2716}]}}
122	46491	{"_key": 46491, "reaction": {"cost": [], "time": [], "material": [{"filterID": 16, "dogmaAttributeID": 2716}]}}
123	46492	{"_key": 46492, "reaction": {"cost": [], "time": [{"filterID": 17, "dogmaAttributeID": 2719}], "material": []}}
124	46493	{"_key": 46493, "reaction": {"cost": [], "time": [{"filterID": 17, "dogmaAttributeID": 2719}], "material": []}}
125	46494	{"_key": 46494, "reaction": {"cost": [], "time": [], "material": [{"filterID": 17, "dogmaAttributeID": 2720}]}}
126	46495	{"_key": 46495, "reaction": {"cost": [], "time": [], "material": [{"filterID": 17, "dogmaAttributeID": 2720}]}}
127	46496	{"_key": 46496, "reaction": {"cost": [], "time": [{"filterID": 16, "dogmaAttributeID": 2715}, {"filterID": 18, "dogmaAttributeID": 2717}, {"filterID": 17, "dogmaAttributeID": 2719}], "material": [{"filterID": 16, "dogmaAttributeID": 2716}, {"filterID": 18, "dogmaAttributeID": 2718}, {"filterID": 17, "dogmaAttributeID": 2720}]}}
128	46497	{"_key": 46497, "reaction": {"cost": [], "time": [{"filterID": 16, "dogmaAttributeID": 2715}, {"filterID": 18, "dogmaAttributeID": 2717}, {"filterID": 17, "dogmaAttributeID": 2719}], "material": [{"filterID": 16, "dogmaAttributeID": 2716}, {"filterID": 18, "dogmaAttributeID": 2718}, {"filterID": 17, "dogmaAttributeID": 2720}]}}
129	47512	{"_key": 47512, "copying": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "manufacturing": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}}
130	47513	{"_key": 47513, "manufacturing": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}}
131	47514	{"_key": 47514, "copying": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}}
132	47883	{"_key": 47883, "manufacturing": {"cost": [], "time": [{"filterID": 5, "dogmaAttributeID": 2545}, {"filterID": 7, "dogmaAttributeID": 2547}, {"filterID": 9, "dogmaAttributeID": 2549}, {"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"dogmaAttributeID": 2600}]}}
133	47981	{"_key": 47981, "manufacturing": {"cost": [], "time": [{"filterID": 5, "dogmaAttributeID": 2545}, {"filterID": 7, "dogmaAttributeID": 2547}, {"filterID": 9, "dogmaAttributeID": 2549}, {"filterID": 6, "dogmaAttributeID": 2551}, {"filterID": 8, "dogmaAttributeID": 2553}, {"filterID": 10, "dogmaAttributeID": 2556}, {"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"dogmaAttributeID": 2600}]}}
134	47982	{"_key": 47982, "manufacturing": {"cost": [], "time": [{"filterID": 5, "dogmaAttributeID": 2545}, {"filterID": 7, "dogmaAttributeID": 2547}, {"filterID": 9, "dogmaAttributeID": 2549}, {"filterID": 6, "dogmaAttributeID": 2551}, {"filterID": 8, "dogmaAttributeID": 2553}, {"filterID": 10, "dogmaAttributeID": 2556}, {"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"dogmaAttributeID": 2600}]}}
135	47984	{"_key": 47984, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
136	47985	{"_key": 47985, "manufacturing": {"cost": [], "time": [{"filterID": 6, "dogmaAttributeID": 2551}, {"filterID": 8, "dogmaAttributeID": 2553}, {"filterID": 10, "dogmaAttributeID": 2556}], "material": [{"dogmaAttributeID": 2600}]}}
137	47986	{"_key": 47986, "manufacturing": {"cost": [], "time": [{"filterID": 5, "dogmaAttributeID": 2545}, {"filterID": 7, "dogmaAttributeID": 2547}, {"filterID": 9, "dogmaAttributeID": 2549}, {"filterID": 6, "dogmaAttributeID": 2551}, {"filterID": 8, "dogmaAttributeID": 2553}, {"filterID": 10, "dogmaAttributeID": 2556}, {"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"dogmaAttributeID": 2600}]}}
138	47987	{"_key": 47987, "manufacturing": {"cost": [], "time": [{"filterID": 5, "dogmaAttributeID": 2545}, {"filterID": 7, "dogmaAttributeID": 2547}, {"filterID": 9, "dogmaAttributeID": 2549}, {"filterID": 6, "dogmaAttributeID": 2551}, {"filterID": 8, "dogmaAttributeID": 2553}, {"filterID": 10, "dogmaAttributeID": 2556}, {"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"dogmaAttributeID": 2600}]}}
139	47990	{"_key": 47990, "manufacturing": {"cost": [], "time": [{"filterID": 5, "dogmaAttributeID": 2545}, {"filterID": 7, "dogmaAttributeID": 2547}, {"filterID": 9, "dogmaAttributeID": 2549}, {"filterID": 6, "dogmaAttributeID": 2551}, {"filterID": 8, "dogmaAttributeID": 2553}, {"filterID": 10, "dogmaAttributeID": 2556}, {"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"dogmaAttributeID": 2600}]}}
140	47991	{"_key": 47991, "manufacturing": {"cost": [], "time": [{"filterID": 5, "dogmaAttributeID": 2545}, {"filterID": 7, "dogmaAttributeID": 2547}, {"filterID": 9, "dogmaAttributeID": 2549}, {"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"dogmaAttributeID": 2600}]}}
141	47992	{"_key": 47992, "manufacturing": {"cost": [], "time": [{"filterID": 13, "dogmaAttributeID": 2560}], "material": []}}
142	47993	{"_key": 47993, "manufacturing": {"cost": [], "time": [], "material": [{"dogmaAttributeID": 2600}]}}
143	47997	{"_key": 47997, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
144	47998	{"_key": 47998, "manufacturing": {"cost": [], "time": [], "material": [{"dogmaAttributeID": 2600}]}}
145	47999	{"_key": 47999, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [{"dogmaAttributeID": 2564}], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [], "material": []}}
146	48001	{"_key": 48001, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [{"dogmaAttributeID": 2564}], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
147	48002	{"_key": 48002, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
148	48003	{"_key": 48003, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
149	48007	{"_key": 48007, "manufacturing": {"cost": [], "time": [], "material": [{"dogmaAttributeID": 2600}]}}
150	48008	{"_key": 48008, "manufacturing": {"cost": [], "time": [{"filterID": 13, "dogmaAttributeID": 2560}], "material": [{"dogmaAttributeID": 2600}]}}
151	48009	{"_key": 48009, "manufacturing": {"cost": [], "time": [], "material": [{"dogmaAttributeID": 2600}]}}
152	48010	{"_key": 48010, "manufacturing": {"cost": [], "time": [], "material": [{"dogmaAttributeID": 2600}]}}
153	48011	{"_key": 48011, "manufacturing": {"cost": [], "time": [{"filterID": 13, "dogmaAttributeID": 2560}], "material": [{"dogmaAttributeID": 2600}]}}
154	48012	{"_key": 48012, "manufacturing": {"cost": [], "time": [{"filterID": 5, "dogmaAttributeID": 2545}, {"filterID": 7, "dogmaAttributeID": 2547}, {"filterID": 9, "dogmaAttributeID": 2549}, {"filterID": 6, "dogmaAttributeID": 2551}, {"filterID": 8, "dogmaAttributeID": 2553}, {"filterID": 10, "dogmaAttributeID": 2556}, {"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"dogmaAttributeID": 2600}]}}
155	48013	{"_key": 48013, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [{"dogmaAttributeID": 2564}], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
156	48014	{"_key": 48014, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
157	48015	{"_key": 48015, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [{"dogmaAttributeID": 2564}], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
158	48016	{"_key": 48016, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [{"dogmaAttributeID": 2564}], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
159	48017	{"_key": 48017, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [{"dogmaAttributeID": 2564}], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
160	48018	{"_key": 48018, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [{"dogmaAttributeID": 2564}], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [], "material": []}}
161	48019	{"_key": 48019, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [], "material": []}}
162	48020	{"_key": 48020, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
163	48022	{"_key": 48022, "manufacturing": {"cost": [], "time": [{"filterID": 2, "dogmaAttributeID": 2539}], "material": [{"dogmaAttributeID": 2600}]}}
164	48023	{"_key": 48023, "manufacturing": {"cost": [], "time": [{"filterID": 2, "dogmaAttributeID": 2539}], "material": [{"dogmaAttributeID": 2600}]}}
165	48024	{"_key": 48024, "manufacturing": {"cost": [], "time": [{"filterID": 2, "dogmaAttributeID": 2539}], "material": []}}
166	48025	{"_key": 48025, "manufacturing": {"cost": [], "time": [{"filterID": 2, "dogmaAttributeID": 2539}], "material": []}}
167	48026	{"_key": 48026, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [{"dogmaAttributeID": 2564}], "material": []}, "manufacturing": {"cost": [], "time": [{"filterID": 14, "dogmaAttributeID": 2558}, {"filterID": 15, "dogmaAttributeID": 2659}], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
168	48027	{"_key": 48027, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "manufacturing": {"cost": [], "time": [{"filterID": 5, "dogmaAttributeID": 2545}, {"filterID": 7, "dogmaAttributeID": 2547}, {"filterID": 9, "dogmaAttributeID": 2549}, {"filterID": 6, "dogmaAttributeID": 2551}, {"filterID": 8, "dogmaAttributeID": 2553}, {"filterID": 10, "dogmaAttributeID": 2556}, {"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [], "material": []}}
169	48028	{"_key": 48028, "manufacturing": {"cost": [], "time": [{"filterID": 5, "dogmaAttributeID": 2545}, {"filterID": 7, "dogmaAttributeID": 2547}, {"filterID": 9, "dogmaAttributeID": 2549}, {"filterID": 6, "dogmaAttributeID": 2551}, {"filterID": 8, "dogmaAttributeID": 2553}, {"filterID": 10, "dogmaAttributeID": 2556}, {"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"dogmaAttributeID": 2600}]}}
170	48029	{"_key": 48029, "manufacturing": {"cost": [], "time": [{"filterID": 5, "dogmaAttributeID": 2545}, {"filterID": 7, "dogmaAttributeID": 2547}, {"filterID": 9, "dogmaAttributeID": 2549}, {"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"dogmaAttributeID": 2600}]}}
171	48030	{"_key": 48030, "manufacturing": {"cost": [], "time": [{"filterID": 5, "dogmaAttributeID": 2545}, {"filterID": 7, "dogmaAttributeID": 2547}, {"filterID": 9, "dogmaAttributeID": 2549}, {"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"dogmaAttributeID": 2600}]}}
172	48031	{"_key": 48031, "manufacturing": {"cost": [], "time": [{"filterID": 5, "dogmaAttributeID": 2545}, {"filterID": 7, "dogmaAttributeID": 2547}, {"filterID": 9, "dogmaAttributeID": 2549}, {"filterID": 6, "dogmaAttributeID": 2551}, {"filterID": 8, "dogmaAttributeID": 2553}, {"filterID": 10, "dogmaAttributeID": 2556}, {"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"dogmaAttributeID": 2600}]}}
173	48032	{"_key": 48032, "manufacturing": {"cost": [], "time": [], "material": [{"dogmaAttributeID": 2600}]}}
174	48033	{"_key": 48033, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [], "material": []}}
175	48034	{"_key": 48034, "manufacturing": {"cost": [], "time": [], "material": [{"dogmaAttributeID": 2600}]}}
176	48035	{"_key": 48035, "manufacturing": {"cost": [], "time": [], "material": [{"dogmaAttributeID": 2600}]}}
177	48036	{"_key": 48036, "manufacturing": {"cost": [], "time": [], "material": [{"dogmaAttributeID": 2600}]}}
178	48037	{"_key": 48037, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [], "material": []}, "manufacturing": {"cost": [], "time": [{"filterID": 13, "dogmaAttributeID": 2560}], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [], "material": []}}
179	48038	{"_key": 48038, "manufacturing": {"cost": [], "time": [{"filterID": 2, "dogmaAttributeID": 2539}], "material": []}}
180	48039	{"_key": 48039, "manufacturing": {"cost": [], "time": [], "material": [{"dogmaAttributeID": 2600}]}}
181	48040	{"_key": 48040, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "manufacturing": {"cost": [], "time": [], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
182	48041	{"_key": 48041, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "manufacturing": {"cost": [], "time": [], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
183	48042	{"_key": 48042, "manufacturing": {"cost": [], "time": [{"filterID": 6, "dogmaAttributeID": 2551}, {"filterID": 8, "dogmaAttributeID": 2553}, {"filterID": 10, "dogmaAttributeID": 2556}], "material": [{"dogmaAttributeID": 2600}]}}
184	48043	{"_key": 48043, "manufacturing": {"cost": [], "time": [{"filterID": 5, "dogmaAttributeID": 2545}, {"filterID": 7, "dogmaAttributeID": 2547}, {"filterID": 9, "dogmaAttributeID": 2549}, {"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"dogmaAttributeID": 2600}]}}
185	48044	{"_key": 48044, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [], "material": []}, "manufacturing": {"cost": [], "time": [{"filterID": 14, "dogmaAttributeID": 2558}, {"filterID": 15, "dogmaAttributeID": 2659}], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
186	48045	{"_key": 48045, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
187	48046	{"_key": 48046, "manufacturing": {"cost": [], "time": [{"filterID": 5, "dogmaAttributeID": 2545}, {"filterID": 7, "dogmaAttributeID": 2547}, {"filterID": 9, "dogmaAttributeID": 2549}, {"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"dogmaAttributeID": 2600}]}}
188	48047	{"_key": 48047, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [{"dogmaAttributeID": 2564}], "material": []}, "manufacturing": {"cost": [], "time": [{"filterID": 14, "dogmaAttributeID": 2558}, {"filterID": 15, "dogmaAttributeID": 2659}], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
189	48048	{"_key": 48048, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
190	48049	{"_key": 48049, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [{"dogmaAttributeID": 2564}], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
191	48050	{"_key": 48050, "manufacturing": {"cost": [], "time": [], "material": [{"dogmaAttributeID": 2600}]}}
192	48051	{"_key": 48051, "manufacturing": {"cost": [], "time": [], "material": [{"dogmaAttributeID": 2600}]}}
193	48052	{"_key": 48052, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
194	48053	{"_key": 48053, "manufacturing": {"cost": [], "time": [{"filterID": 6, "dogmaAttributeID": 2551}, {"filterID": 8, "dogmaAttributeID": 2553}, {"filterID": 10, "dogmaAttributeID": 2556}], "material": [{"dogmaAttributeID": 2600}]}}
195	48054	{"_key": 48054, "manufacturing": {"cost": [], "time": [{"filterID": 13, "dogmaAttributeID": 2560}], "material": [{"dogmaAttributeID": 2600}]}}
196	48055	{"_key": 48055, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "manufacturing": {"cost": [], "time": [], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
197	48056	{"_key": 48056, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "manufacturing": {"cost": [], "time": [{"filterID": 5, "dogmaAttributeID": 2545}, {"filterID": 7, "dogmaAttributeID": 2547}, {"filterID": 9, "dogmaAttributeID": 2549}, {"filterID": 6, "dogmaAttributeID": 2551}, {"filterID": 8, "dogmaAttributeID": 2553}, {"filterID": 10, "dogmaAttributeID": 2556}, {"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [], "material": []}}
198	48057	{"_key": 48057, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
199	48058	{"_key": 48058, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
200	48059	{"_key": 48059, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [], "material": []}}
201	48060	{"_key": 48060, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "manufacturing": {"cost": [], "time": [], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
202	48061	{"_key": 48061, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [], "material": []}, "manufacturing": {"cost": [], "time": [{"filterID": 14, "dogmaAttributeID": 2558}, {"filterID": 15, "dogmaAttributeID": 2659}], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
203	48062	{"_key": 48062, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [{"dogmaAttributeID": 2564}], "material": []}, "manufacturing": {"cost": [], "time": [{"filterID": 14, "dogmaAttributeID": 2558}, {"filterID": 15, "dogmaAttributeID": 2659}], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
204	48063	{"_key": 48063, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [{"dogmaAttributeID": 2564}], "material": []}, "manufacturing": {"cost": [], "time": [{"filterID": 14, "dogmaAttributeID": 2558}, {"filterID": 15, "dogmaAttributeID": 2659}], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
205	48064	{"_key": 48064, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "manufacturing": {"cost": [], "time": [{"filterID": 6, "dogmaAttributeID": 2551}, {"filterID": 8, "dogmaAttributeID": 2553}, {"filterID": 10, "dogmaAttributeID": 2556}], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [], "material": []}}
206	48065	{"_key": 48065, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [], "material": []}, "manufacturing": {"cost": [], "time": [{"filterID": 13, "dogmaAttributeID": 2560}], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [], "material": []}}
207	48066	{"_key": 48066, "manufacturing": {"cost": [], "time": [{"filterID": 13, "dogmaAttributeID": 2560}], "material": []}}
208	48067	{"_key": 48067, "manufacturing": {"cost": [], "time": [{"filterID": 13, "dogmaAttributeID": 2560}], "material": [{"dogmaAttributeID": 2600}]}}
209	48068	{"_key": 48068, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [], "material": []}, "manufacturing": {"cost": [], "time": [{"filterID": 14, "dogmaAttributeID": 2558}, {"filterID": 15, "dogmaAttributeID": 2659}], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
210	48069	{"_key": 48069, "manufacturing": {"cost": [], "time": [{"filterID": 5, "dogmaAttributeID": 2545}, {"filterID": 7, "dogmaAttributeID": 2547}, {"filterID": 9, "dogmaAttributeID": 2549}, {"filterID": 6, "dogmaAttributeID": 2551}, {"filterID": 8, "dogmaAttributeID": 2553}, {"filterID": 10, "dogmaAttributeID": 2556}, {"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"dogmaAttributeID": 2600}]}}
211	48070	{"_key": 48070, "manufacturing": {"cost": [], "time": [{"filterID": 5, "dogmaAttributeID": 2545}, {"filterID": 7, "dogmaAttributeID": 2547}, {"filterID": 9, "dogmaAttributeID": 2549}, {"filterID": 6, "dogmaAttributeID": 2551}, {"filterID": 8, "dogmaAttributeID": 2553}, {"filterID": 10, "dogmaAttributeID": 2556}, {"filterID": 11, "dogmaAttributeID": 2576}], "material": [{"dogmaAttributeID": 2600}]}}
212	48071	{"_key": 48071, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
213	48072	{"_key": 48072, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
214	48073	{"_key": 48073, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [{"dogmaAttributeID": 2564}], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
215	48074	{"_key": 48074, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [{"dogmaAttributeID": 2564}], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
216	48075	{"_key": 48075, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
217	48076	{"_key": 48076, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [{"dogmaAttributeID": 2570}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2563}], "time": [], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [], "material": []}}
218	48077	{"_key": 48077, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [{"dogmaAttributeID": 2568}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [], "material": []}}
219	48078	{"_key": 48078, "copying": {"cost": [{"dogmaAttributeID": 2569}], "time": [], "material": []}, "manufacturing": {"cost": [], "time": [], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2567}], "time": [], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2565}], "time": [{"dogmaAttributeID": 2566}], "material": []}}
220	75846	{"_key": 75846, "reaction": {"cost": [], "time": [{"dogmaAttributeID": 2721}], "material": []}}
221	75847	{"_key": 75847, "reaction": {"cost": [], "time": [{"dogmaAttributeID": 2721}], "material": []}}
222	77464	{"_key": 77464, "copying": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "manufacturing": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}}
223	77465	{"_key": 77465, "copying": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "invention": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "manufacturing": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": [{"dogmaAttributeID": 2600}]}, "research_time": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}, "research_material": {"cost": [{"dogmaAttributeID": 2601}], "time": [{"dogmaAttributeID": 2602}], "material": []}}
\.


--
-- Name: industry_activity_modifier_sources industry_activity_modifier_sources_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.industry_activity_modifier_sources
    ADD CONSTRAINT industry_activity_modifier_sources_pkey PRIMARY KEY (row_no);


--
-- Name: industry_activity_modifier_sources_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX industry_activity_modifier_sources_key_idx ON sde_native.industry_activity_modifier_sources USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict K0eYQ1kxwoBbhPHd8J40U1cayDpmKJw9lqeFV0lTWqH93qRVbSs8oFvY3ymCoB0

