--
-- PostgreSQL database dump
--

\restrict C4S0C9lVEuJAl0fTGEl0GrrkP7JfslC6zl0rLPbDO97du537OSbbn2ROumCBPqU

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: factionsowningsolarsystems; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.factionsowningsolarsystems (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: factionsowningsolarsystems; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.factionsowningsolarsystems (row_no, key, data) FROM stdin;
0	\N	{"value": 500001, "_index": 0}
1	\N	{"value": 500002, "_index": 1}
2	\N	{"value": 500003, "_index": 2}
3	\N	{"value": 500004, "_index": 3}
4	\N	{"value": 500005, "_index": 4}
5	\N	{"value": 500006, "_index": 5}
6	\N	{"value": 500007, "_index": 6}
7	\N	{"value": 500008, "_index": 7}
8	\N	{"value": 500010, "_index": 8}
9	\N	{"value": 500011, "_index": 9}
10	\N	{"value": 500012, "_index": 10}
11	\N	{"value": 500013, "_index": 11}
12	\N	{"value": 500014, "_index": 12}
13	\N	{"value": 500015, "_index": 13}
14	\N	{"value": 500016, "_index": 14}
15	\N	{"value": 500017, "_index": 15}
16	\N	{"value": 500018, "_index": 16}
17	\N	{"value": 500019, "_index": 17}
18	\N	{"value": 500020, "_index": 18}
19	\N	{"value": 500026, "_index": 19}
20	\N	{"value": 500027, "_index": 20}
21	\N	{"value": 500029, "_index": 21}
\.


--
-- Name: factionsowningsolarsystems factionsowningsolarsystems_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.factionsowningsolarsystems
    ADD CONSTRAINT factionsowningsolarsystems_pkey PRIMARY KEY (row_no);


--
-- Name: factionsowningsolarsystems_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX factionsowningsolarsystems_key_idx ON sde_native.factionsowningsolarsystems USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict C4S0C9lVEuJAl0fTGEl0GrrkP7JfslC6zl0rLPbDO97du537OSbbn2ROumCBPqU

