--
-- PostgreSQL database dump
--

\restrict GojfWlRlNScz6YSymVYyMfcITXTClcmBBVFGT2hajwFz622NXbf3oz4BFcgrHl6

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: podguide; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.podguide (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: podguide; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.podguide (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "termID": 1, "groupID": 1, "imageSize": "Large", "longTextID": 502584, "loreTextID": 502766, "shortTextID": 502585, "termTitleID": 502583, "texturePath": "res:/UI/Texture/Icons/56_64_10.png"}
1	2	{"_key": 2, "termID": 2, "groupID": 1, "imageSize": "Large", "longTextID": 502590, "loreTextID": 502767, "shortTextID": 502591, "termTitleID": 502589, "texturePath": "res:/UI/Texture/Icons/56_64_10.png"}
2	3	{"_key": 3, "termID": 3, "groupID": 1, "imageSize": "Medium", "longTextID": 502593, "loreTextID": 502768, "shortTextID": 502594, "termTitleID": 502592, "texturePath": "res:/UI/Texture/Icons/1_64_1.png"}
3	4	{"_key": 4, "termID": 4, "groupID": 2, "imageSize": "Small", "longTextID": 502596, "loreTextID": 502769, "shortTextID": 502597, "termTitleID": 502595, "texturePath": "res:/UI/Texture/Icons/1_64_2.png"}
4	5	{"_key": 5, "termID": 5, "groupID": 2, "imageSize": "Large", "longTextID": 502599, "loreTextID": 502770, "shortTextID": 502600, "termTitleID": 502598, "texturePath": "res:/UI/Texture/Icons/1_64_3.png"}
5	6	{"_key": 6, "termID": 6, "groupID": 2, "imageSize": "Large", "longTextID": 502602, "loreTextID": 502771, "shortTextID": 502603, "termTitleID": 502601, "texturePath": "res:/UI/Texture/Icons/1_64_4.png"}
6	7	{"_key": 7, "termID": 7, "groupID": 3, "imageSize": "Large", "longTextID": 502605, "loreTextID": 502772, "shortTextID": 502606, "termTitleID": 502604, "texturePath": "res:/UI/Texture/Icons/1_64_11.png"}
7	8	{"_key": 8, "termID": 8, "groupID": 3, "imageSize": "Large", "longTextID": 502608, "loreTextID": 502773, "shortTextID": 502609, "termTitleID": 502607, "texturePath": "res:/UI/Texture/Icons/1_64_7.png"}
8	9	{"_key": 9, "termID": 9, "groupID": 4, "imageSize": "Large", "longTextID": 502611, "loreTextID": 502774, "shortTextID": 502612, "termTitleID": 502610, "texturePath": "res:/UI/Texture/Icons/1_64_8.png"}
9	10	{"_key": 10, "termID": 10, "groupID": 4, "imageSize": "Large", "longTextID": 502614, "loreTextID": 502775, "shortTextID": 502615, "termTitleID": 502613, "texturePath": "res:/UI/Texture/Icons/1_64_9.png"}
10	11	{"_key": 11, "termID": 11, "groupID": 4, "imageSize": "Large", "longTextID": 502617, "loreTextID": 502776, "shortTextID": 502618, "termTitleID": 502616, "texturePath": "res:/UI/Texture/Icons/1_64_10.png"}
11	12	{"_key": 12, "termID": 12, "groupID": 4, "imageSize": "Large", "longTextID": 502620, "loreTextID": 502777, "shortTextID": 502621, "termTitleID": 502619, "texturePath": "res:/UI/Texture/Icons/1_64_12.png"}
12	13	{"_key": 13, "termID": 13, "groupID": 5, "imageSize": "Large", "longTextID": 502623, "loreTextID": 502778, "shortTextID": 502624, "termTitleID": 502622, "texturePath": "res:/UI/Texture/Icons/1_64_13.png"}
13	14	{"_key": 14, "termID": 14, "groupID": 5, "imageSize": "Large", "longTextID": 502626, "loreTextID": 502779, "shortTextID": 502627, "termTitleID": 502625, "texturePath": "res:/UI/Texture/Icons/1_64_14.png"}
14	15	{"_key": 15, "termID": 15, "groupID": 5, "imageSize": "Large", "longTextID": 502629, "loreTextID": 502780, "shortTextID": 502630, "termTitleID": 502628, "texturePath": "res:/UI/Texture/Icons/1_64_15.png"}
15	16	{"_key": 16, "termID": 16, "groupID": 5, "imageSize": "Large", "longTextID": 502632, "loreTextID": 502781, "shortTextID": 502633, "termTitleID": 502631, "texturePath": "res:/UI/Texture/Icons/2_64_1.png"}
16	17	{"_key": 17, "termID": 17, "groupID": 5, "imageSize": "Large", "longTextID": 502635, "loreTextID": 502782, "shortTextID": 502636, "termTitleID": 502634, "texturePath": "res:/UI/Texture/Icons/2_64_2.png"}
17	18	{"_key": 18, "termID": 18, "groupID": 5, "imageSize": "Large", "longTextID": 502638, "loreTextID": 502783, "shortTextID": 502639, "termTitleID": 502637, "texturePath": "res:/UI/Texture/Icons/2_64_3.png"}
18	19	{"_key": 19, "termID": 19, "groupID": 6, "imageSize": "Large", "longTextID": 502641, "loreTextID": 502784, "shortTextID": 502642, "termTitleID": 502640, "texturePath": "res:/UI/Texture/Icons/2_64_4.png"}
19	20	{"_key": 20, "termID": 20, "groupID": 6, "imageSize": "Large", "longTextID": 502644, "loreTextID": 502785, "shortTextID": 502645, "termTitleID": 502643, "texturePath": "res:/UI/Texture/Icons/2_64_5.png"}
20	21	{"_key": 21, "termID": 21, "groupID": 6, "imageSize": "Large", "longTextID": 502647, "loreTextID": 502786, "shortTextID": 502648, "termTitleID": 502646, "texturePath": "res:/UI/Texture/Icons/2_64_6.png"}
21	22	{"_key": 22, "termID": 22, "groupID": 7, "imageSize": "Large", "longTextID": 502650, "loreTextID": 502787, "shortTextID": 502651, "termTitleID": 502649, "texturePath": "res:/UI/Texture/Icons/2_64_7.png"}
22	23	{"_key": 23, "termID": 23, "groupID": 7, "imageSize": "Large", "longTextID": 502653, "loreTextID": 502788, "shortTextID": 502654, "termTitleID": 502652, "texturePath": "res:/UI/Texture/Icons/2_64_8.png"}
23	24	{"_key": 24, "termID": 24, "groupID": 7, "imageSize": "Large", "longTextID": 502656, "loreTextID": 502789, "shortTextID": 502657, "termTitleID": 502655, "texturePath": "res:/UI/Texture/Icons/2_64_9.png"}
24	25	{"_key": 25, "termID": 25, "groupID": 7, "imageSize": "Large", "longTextID": 502659, "loreTextID": 502790, "shortTextID": 502660, "termTitleID": 502658, "texturePath": "res:/UI/Texture/Icons/2_64_10.png"}
25	26	{"_key": 26, "termID": 26, "groupID": 8, "imageSize": "Large", "longTextID": 502662, "loreTextID": 502791, "shortTextID": 502663, "termTitleID": 502661, "texturePath": "res:/UI/Texture/Icons/2_64_11.png"}
26	27	{"_key": 27, "termID": 27, "groupID": 8, "imageSize": "Large", "longTextID": 502665, "loreTextID": 502792, "shortTextID": 502666, "termTitleID": 502664, "texturePath": "res:/UI/Texture/Icons/2_64_12.png"}
27	28	{"_key": 28, "termID": 28, "groupID": 8, "imageSize": "Large", "longTextID": 502668, "loreTextID": 502793, "shortTextID": 502669, "termTitleID": 502667, "texturePath": "res:/UI/Texture/Icons/2_64_13.png"}
28	29	{"_key": 29, "termID": 29, "groupID": 8, "imageSize": "Large", "longTextID": 502671, "loreTextID": 502794, "shortTextID": 502672, "termTitleID": 502670, "texturePath": "res:/UI/Texture/Icons/2_64_14.png"}
29	30	{"_key": 30, "termID": 30, "groupID": 8, "imageSize": "Large", "longTextID": 502674, "loreTextID": 502795, "shortTextID": 502675, "termTitleID": 502673, "texturePath": "res:/UI/Texture/Icons/2_64_15.png"}
30	31	{"_key": 31, "termID": 31, "groupID": 9, "imageSize": "Large", "longTextID": 502677, "loreTextID": 502796, "shortTextID": 502678, "termTitleID": 502676, "texturePath": "res:/UI/Texture/Icons/2_64_16.png"}
31	32	{"_key": 32, "termID": 32, "groupID": 9, "imageSize": "Large", "longTextID": 502680, "loreTextID": 502797, "shortTextID": 502681, "termTitleID": 502679, "texturePath": "res:/UI/Texture/Icons/3_64_1.png"}
32	33	{"_key": 33, "termID": 33, "groupID": 9, "imageSize": "Large", "longTextID": 502683, "loreTextID": 502798, "shortTextID": 502684, "termTitleID": 502682, "texturePath": "res:/UI/Texture/Icons/3_64_2.png"}
33	34	{"_key": 34, "termID": 34, "groupID": 9, "imageSize": "Large", "longTextID": 502686, "loreTextID": 502799, "shortTextID": 502687, "termTitleID": 502685, "texturePath": "res:/UI/Texture/Icons/3_64_3.png"}
34	35	{"_key": 35, "termID": 35, "groupID": 9, "imageSize": "Large", "longTextID": 502689, "loreTextID": 502800, "shortTextID": 502690, "termTitleID": 502688, "texturePath": "res:/UI/Texture/Icons/3_64_4.png"}
35	36	{"_key": 36, "termID": 36, "groupID": 9, "imageSize": "Large", "longTextID": 502692, "loreTextID": 502801, "shortTextID": 502693, "termTitleID": 502691, "texturePath": "res:/UI/Texture/Icons/3_64_5.png"}
36	37	{"_key": 37, "termID": 37, "groupID": 9, "imageSize": "Large", "longTextID": 502695, "loreTextID": 502802, "shortTextID": 502696, "termTitleID": 502694, "texturePath": "res:/UI/Texture/Icons/3_64_6.png"}
37	38	{"_key": 38, "termID": 38, "groupID": 9, "imageSize": "Large", "longTextID": 502698, "loreTextID": 502803, "shortTextID": 502699, "termTitleID": 502697, "texturePath": "res:/UI/Texture/Icons/3_64_7.png"}
38	39	{"_key": 39, "termID": 39, "groupID": 9, "imageSize": "Large", "longTextID": 502701, "loreTextID": 502804, "shortTextID": 502702, "termTitleID": 502700, "texturePath": "res:/UI/Texture/Icons/3_64_8.png"}
39	40	{"_key": 40, "termID": 40, "groupID": 10, "imageSize": "Large", "longTextID": 502704, "loreTextID": 502805, "shortTextID": 502705, "termTitleID": 502703, "texturePath": "res:/UI/Texture/Icons/3_64_9.png"}
40	41	{"_key": 41, "termID": 41, "groupID": 10, "imageSize": "Large", "longTextID": 502707, "loreTextID": 502809, "shortTextID": 502708, "termTitleID": 502706, "texturePath": "res:/UI/Texture/Icons/3_64_10.png"}
41	42	{"_key": 42, "termID": 42, "groupID": 10, "imageSize": "Large", "longTextID": 502710, "loreTextID": 502806, "shortTextID": 502711, "termTitleID": 502709, "texturePath": "res:/UI/Texture/Icons/3_64_11.png"}
42	43	{"_key": 43, "termID": 43, "groupID": 10, "imageSize": "Large", "longTextID": 502713, "loreTextID": 502807, "shortTextID": 502714, "termTitleID": 502712, "texturePath": "res:/UI/Texture/Icons/3_64_12.png"}
43	44	{"_key": 44, "termID": 44, "groupID": 10, "imageSize": "Large", "longTextID": 502716, "loreTextID": 502808, "shortTextID": 502717, "termTitleID": 502715, "texturePath": "res:/UI/Texture/Icons/3_64_13.png"}
\.


--
-- Name: podguide podguide_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.podguide
    ADD CONSTRAINT podguide_pkey PRIMARY KEY (row_no);


--
-- Name: podguide_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX podguide_key_idx ON sde_native.podguide USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict GojfWlRlNScz6YSymVYyMfcITXTClcmBBVFGT2hajwFz622NXbf3oz4BFcgrHl6

