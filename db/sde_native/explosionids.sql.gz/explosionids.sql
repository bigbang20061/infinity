--
-- PostgreSQL database dump
--

\restrict XgxwX3LRKJZGjexFjpSYU2H9slPfMzIbWgLEXZKZaffLDAbvSYECm50C9XpRRML

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: explosionids; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.explosionids (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: explosionids; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.explosionids (row_no, key, data) FROM stdin;
0	concord_structure_l_explosive_01a	{"_key": "concord_structure_l_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_concord_structure_l_01a.red", "childExplosionType": 1, "modelSwitchDelayInMs": 4500}
1	deathless_structure_large_explosive_01a	{"_key": "deathless_structure_large_explosive_01a", "filePath": "res:/FisFX/Explosion/ECX_Deathless_Structure_L_Explosive_01a.red", "childExplosionType": 1, "modelSwitchDelayInMs": 4000}
2	drifter_cruiser_explosive_01a	{"_key": "drifter_cruiser_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_drifter_cruiser_explosive_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 504}
3	drifter_explosive_01a	{"_key": "drifter_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_drifter_explosive_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 504}
4	drifter_explosive_short_01a	{"_key": "drifter_explosive_short_01a", "filePath": "res:/fisfx/explosion/ecx_drifter_explosive_short_01a.red", "childExplosionType": 1, "modelSwitchDelayInMs": 200}
5	drifter_structure_explosive_01a	{"_key": "drifter_structure_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_drifter_structure_l_explosive_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 1605}
6	edencom_structure_extra_large_explosive_01a	{"_key": "edencom_structure_extra_large_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_edencom_structure_xl_explosive_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 4500}
7	edencom_structure_large_explosive_01a	{"_key": "edencom_structure_large_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_edencom_structure_l_explosive_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 4500}
8	generic_asteroid_01a	{"_key": "generic_asteroid_01a", "filePath": "res:/fisfx/explosion/ecx_generic_asteroid_rw_01a.red", "childExplosionType": 0, "modelSwitchDelayInMs": 0}
9	generic_container_explosive_01a	{"_key": "generic_container_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_generic_container_explosion_01a.red", "childExplosionType": 1, "modelSwitchDelayInMs": 0}
10	generic_corpse_explosive_01a	{"_key": "generic_corpse_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_generic_corpse_explosive_01a.red", "childExplosionType": 1, "modelSwitchDelayInMs": 0}
11	generic_explosive_01a	{"_key": "generic_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_generic_explosive_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 1000}
12	generic_explosive_01b	{"_key": "generic_explosive_01b", "filePath": "res:/fisfx/explosion/ecx_Generic_Explosive_01b.red", "childExplosionType": 2, "modelSwitchDelayInMs": 1000}
13	generic_explosive_01c	{"_key": "generic_explosive_01c", "filePath": "res:/fisfx/explosion/ecx_Generic_Explosive_01c.red", "childExplosionType": 2, "modelSwitchDelayInMs": 1000}
14	generic_explosive_Long_01a	{"_key": "generic_explosive_Long_01a", "filePath": "res:/fisfx/explosion/ecx_Generic_Explosive_Long_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 2018}
15	generic_explosive_Long_01b	{"_key": "generic_explosive_Long_01b", "filePath": "res:/fisfx/explosion/ecx_Generic_Explosive_Long_01b.red", "childExplosionType": 2, "modelSwitchDelayInMs": 2016}
16	generic_explosive_Long_01c	{"_key": "generic_explosive_Long_01c", "filePath": "res:/fisfx/explosion/ecx_Generic_Explosive_Long_01c.red", "childExplosionType": 2, "modelSwitchDelayInMs": 1314}
17	generic_explosive_short_01a	{"_key": "generic_explosive_short_01a", "filePath": "res:/fisfx/explosion/ecx_generic_explosive_short_01a.red", "childExplosionType": 1, "modelSwitchDelayInMs": 200}
18	generic_explosive_short_01b	{"_key": "generic_explosive_short_01b", "filePath": "res:/fisfx/explosion/ecx_generic_explosive_short_01b.red", "childExplosionType": 1, "modelSwitchDelayInMs": 200}
19	generic_structure_extra_large_explosion	{"_key": "generic_structure_extra_large_explosion", "filePath": "res:/fisfx/explosion/ecx_generic_structure_xl_01a.red", "childExplosionType": 0, "modelSwitchDelayInMs": 6024}
20	generic_structure_large_explosion	{"_key": "generic_structure_large_explosion", "filePath": "res:/fisfx/explosion/ecx_generic_structure_l_01a.red", "childExplosionType": 1, "modelSwitchDelayInMs": 2000}
21	generic_structure_medium_explosion	{"_key": "generic_structure_medium_explosion", "filePath": "res:/fisfx/explosion/ecx_generic_structure_m_01a.red", "childExplosionType": 1, "modelSwitchDelayInMs": 2873}
22	holographic_large	{"_key": "holographic_large", "filePath": "res:/FisFX/Explosion/Holographic/ECX_Holographic_Large_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 760}
23	holographic_medium	{"_key": "holographic_medium", "filePath": "res:/FisFX/Explosion/Holographic/ECX_Holographic_Medium_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 760}
24	holographic_small	{"_key": "holographic_small", "filePath": "res:/FisFX/Explosion/Holographic/ECX_Holographic_Small_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 760}
25	holographic_xl	{"_key": "holographic_xl", "filePath": "res:/FisFX/Explosion/Holographic/ECX_Holographic_XL_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 760}
26	lco_fast_explosive_01a	{"_key": "lco_fast_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_lco_fast_explosive_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 0}
27	lco_generic_explosive_01a	{"_key": "lco_generic_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_lco_generic_explosive_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 5334}
28	lco_generic_explosive_01b	{"_key": "lco_generic_explosive_01b", "filePath": "res:/fisfx/explosion/ecx_lco_generic_explosive_01b.red", "childExplosionType": 2, "modelSwitchDelayInMs": 5226}
29	lco_generic_explosive_01c	{"_key": "lco_generic_explosive_01c", "filePath": "res:/fisfx/explosion/ecx_lco_generic_explosive_01c.red", "childExplosionType": 2, "modelSwitchDelayInMs": 5422}
30	moonchunk_explosive_01a	{"_key": "moonchunk_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_moonchunk_explosive_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 1175}
31	moonchunk_explosivespecial_01a	{"_key": "moonchunk_explosivespecial_01a", "filePath": "res:/fisfx/explosion/ecx_moonchunk_explosivespecial_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 1175}
32	ore_strucuture_small_explosive_01a	{"_key": "ore_strucuture_small_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_ore_explosive_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 100}
33	pod_generic_explosive_01a	{"_key": "pod_generic_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_pod_generic_explosive_01a.red", "childExplosionType": 1, "modelSwitchDelayInMs": 0}
34	sleeper_explosive_01a	{"_key": "sleeper_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_sleeper_explosive_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 763}
35	titan_amarr_explosive_01a	{"_key": "titan_amarr_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_titan_amarr_explosive_01a.red", "childExplosionType": 1, "modelSwitchDelayInMs": 3367}
36	titan_angel_explosive_01a	{"_key": "titan_angel_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_titan_angel_explosive_01a.red", "childExplosionType": 1, "modelSwitchDelayInMs": 1650}
37	titan_caldari_explosive_01a	{"_key": "titan_caldari_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_titan_caldari_explosive_01a.red", "childExplosionType": 1, "modelSwitchDelayInMs": 3367}
38	titan_gallente_explosive_01a	{"_key": "titan_gallente_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_titan_gallente_explosive_01a.red", "childExplosionType": 1, "modelSwitchDelayInMs": 3367}
39	titan_minmatar_explosive_01a	{"_key": "titan_minmatar_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_titan_minmatar_explosive_01a.red", "childExplosionType": 1, "modelSwitchDelayInMs": 3367}
40	triglavian_explosive_01a	{"_key": "triglavian_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_triglavian_explosive_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 504}
41	triglavian_explosive_Dreadnought_01a	{"_key": "triglavian_explosive_Dreadnought_01a", "filePath": "res:/fisfx/explosion/ecx_triglavian_explosive_TGDN01_t1.red", "childExplosionType": 2, "modelSwitchDelayInMs": 5000}
42	triglavian_explosive_sentry_01a	{"_key": "triglavian_explosive_sentry_01a", "filePath": "res:/fisfx/explosion/ecx_triglavian_explosive_sentry_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 5000}
43	triglavian_explosive_short_01a	{"_key": "triglavian_explosive_short_01a", "filePath": "res:/fisfx/explosion/ecx_triglavian_explosive_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 300}
44	triglavian_lootcontainer_01a	{"_key": "triglavian_lootcontainer_01a", "filePath": "res:/fisfx/explosion/ecx_triglavian_lootcontainer_01a.red", "childExplosionType": 0, "modelSwitchDelayInMs": 1035}
45	triglavian_structure_s_explosive_01a	{"_key": "triglavian_structure_s_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_triglavian_structure_s_explosive_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 250}
46	triglavian_structure_tfu_explosive_01a	{"_key": "triglavian_structure_tfu_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_triglavian_structure_tfu_explosive_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 6000}
47	triglavian_structure_xl_explosive_01a	{"_key": "triglavian_structure_xl_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_triglavian_structure_xl_explosive_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 2871}
48	triglavian_structure_xl_explosive_02a	{"_key": "triglavian_structure_xl_explosive_02a", "filePath": "res:/fisfx/explosion/ecx_triglavian_structure_xl_explosive_02a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 6000}
49	upwell_explosive_01a	{"_key": "upwell_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_upwell_explosive_01a.red", "childExplosionType": 0, "modelSwitchDelayInMs": 1000}
50	upwell_explosive_long_01a	{"_key": "upwell_explosive_long_01a", "filePath": "res:/fisfx/explosion/ecx_upwell_explosive_long_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 1000}
51	upwell_explosive_short_01a	{"_key": "upwell_explosive_short_01a", "filePath": "res:/fisfx/explosion/ecx_upwell_explosive_short_01a.red", "childExplosionType": 1, "modelSwitchDelayInMs": 200}
52	upwell_freighter_explosive_01a	{"_key": "upwell_freighter_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_upwell_freighter_explosive_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 1605}
53	upwell_industrial_explosive_01a	{"_key": "upwell_industrial_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_upwell_industrial_explosive_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 1670}
54	upwell_skyhook_explosive_01a	{"_key": "upwell_skyhook_explosive_01a", "filePath": "res:/fisfx/explosion/ecx_upwell_skyhook_explosive_01a.red", "childExplosionType": 2, "modelSwitchDelayInMs": 4000}
\.


--
-- Name: explosionids explosionids_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.explosionids
    ADD CONSTRAINT explosionids_pkey PRIMARY KEY (row_no);


--
-- Name: explosionids_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX explosionids_key_idx ON sde_native.explosionids USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict XgxwX3LRKJZGjexFjpSYU2H9slPfMzIbWgLEXZKZaffLDAbvSYECm50C9XpRRML

