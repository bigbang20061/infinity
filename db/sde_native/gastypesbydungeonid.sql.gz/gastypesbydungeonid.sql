--
-- PostgreSQL database dump
--

\restrict IKbkK84uIVwOgVlofPAbJjwak0lhjmJ1TCvNS2JsYPXA0VkZnuUg8UAJ1uNa0XT

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: gastypesbydungeonid; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.gastypesbydungeonid (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: gastypesbydungeonid; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.gastypesbydungeonid (row_no, key, data) FROM stdin;
0	1161	{"_key": 1161, "value": [25278]}
1	1171	{"_key": 1171, "value": [25278]}
2	1351	{"_key": 1351, "value": [25273]}
3	1352	{"_key": 1352, "value": [25268]}
4	1353	{"_key": 1353, "value": [25275]}
5	1354	{"_key": 1354, "value": [25274]}
6	1355	{"_key": 1355, "value": [25276]}
7	1356	{"_key": 1356, "value": [25278]}
8	1357	{"_key": 1357, "value": [25277]}
9	1358	{"_key": 1358, "value": [25279]}
10	1359	{"_key": 1359, "value": [25273]}
11	1360	{"_key": 1360, "value": [25268]}
12	1361	{"_key": 1361, "value": [25275]}
13	1362	{"_key": 1362, "value": [25276]}
14	1363	{"_key": 1363, "value": [25278]}
15	1364	{"_key": 1364, "value": [25277]}
16	1365	{"_key": 1365, "value": [25279]}
17	1366	{"_key": 1366, "value": [25273]}
18	1367	{"_key": 1367, "value": [25268]}
19	1368	{"_key": 1368, "value": [25275]}
20	1369	{"_key": 1369, "value": [25274]}
21	1370	{"_key": 1370, "value": [25274]}
22	1371	{"_key": 1371, "value": [25276]}
23	1372	{"_key": 1372, "value": [25278]}
24	1373	{"_key": 1373, "value": [25277]}
25	1374	{"_key": 1374, "value": [25279]}
26	1414	{"_key": 1414, "value": [25278]}
27	1415	{"_key": 1415, "value": [25279]}
28	1416	{"_key": 1416, "value": [25273]}
29	1417	{"_key": 1417, "value": [25268]}
30	1418	{"_key": 1418, "value": [25277]}
31	1419	{"_key": 1419, "value": [25274]}
32	1420	{"_key": 1420, "value": [25275]}
33	1421	{"_key": 1421, "value": [25276]}
34	1427	{"_key": 1427, "value": [25278]}
35	1440	{"_key": 1440, "value": [25273]}
36	1441	{"_key": 1441, "value": [25276]}
37	1442	{"_key": 1442, "value": [25275]}
38	1444	{"_key": 1444, "value": [25279]}
39	1445	{"_key": 1445, "value": [25277]}
40	1446	{"_key": 1446, "value": [25274]}
41	1447	{"_key": 1447, "value": [25268]}
42	1569	{"_key": 1569, "value": [25268]}
43	1717	{"_key": 1717, "value": [25278]}
44	1724	{"_key": 1724, "value": [25268]}
45	2475	{"_key": 2475, "value": [28630]}
46	2476	{"_key": 2476, "value": [28630]}
47	2482	{"_key": 2482, "value": [28629]}
48	2527	{"_key": 2527, "value": [28700]}
49	2528	{"_key": 2528, "value": [28695]}
50	2529	{"_key": 2529, "value": [28694]}
51	2530	{"_key": 2530, "value": [28697]}
52	2531	{"_key": 2531, "value": [28698]}
53	2532	{"_key": 2532, "value": [28699]}
54	2533	{"_key": 2533, "value": [28701]}
55	2534	{"_key": 2534, "value": [28696]}
56	2535	{"_key": 2535, "value": [28700]}
57	2536	{"_key": 2536, "value": [28695]}
58	2537	{"_key": 2537, "value": [28694]}
59	2538	{"_key": 2538, "value": [28697]}
60	2539	{"_key": 2539, "value": [28698]}
61	2540	{"_key": 2540, "value": [28699]}
62	2541	{"_key": 2541, "value": [28701]}
63	2542	{"_key": 2542, "value": [28696]}
64	3394	{"_key": 3394, "value": [25268]}
65	3395	{"_key": 3395, "value": [25279]}
66	3396	{"_key": 3396, "value": [25273]}
67	3397	{"_key": 3397, "value": [25274]}
68	3398	{"_key": 3398, "value": [25275]}
69	3399	{"_key": 3399, "value": [25278]}
70	3403	{"_key": 3403, "value": [25277]}
71	3404	{"_key": 3404, "value": [25276]}
72	3555	{"_key": 3555, "value": [30370, 30371]}
73	3556	{"_key": 3556, "value": [30371, 30372]}
74	3557	{"_key": 3557, "value": [30372, 30373]}
75	3558	{"_key": 3558, "value": [30373, 30374]}
76	3559	{"_key": 3559, "value": [30370, 30374]}
77	3560	{"_key": 3560, "value": [30375, 30376]}
78	3561	{"_key": 3561, "value": [30375, 30376]}
79	3562	{"_key": 3562, "value": [30377, 30378]}
80	3563	{"_key": 3563, "value": [30377, 30378]}
81	4093	{"_key": 4093, "value": [28695]}
82	6438	{"_key": 6438, "value": [49787]}
83	9307	{"_key": 9307, "value": [30370, 30371]}
84	9308	{"_key": 9308, "value": [30371, 30372]}
85	9309	{"_key": 9309, "value": [30372, 30373]}
86	9310	{"_key": 9310, "value": [30373, 30374]}
87	9311	{"_key": 9311, "value": [30370, 30374]}
88	9312	{"_key": 9312, "value": [30375, 30376]}
89	9313	{"_key": 9313, "value": [30377, 30378]}
90	9314	{"_key": 9314, "value": [30377, 30378]}
\.


--
-- Name: gastypesbydungeonid gastypesbydungeonid_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.gastypesbydungeonid
    ADD CONSTRAINT gastypesbydungeonid_pkey PRIMARY KEY (row_no);


--
-- Name: gastypesbydungeonid_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX gastypesbydungeonid_key_idx ON sde_native.gastypesbydungeonid USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict IKbkK84uIVwOgVlofPAbJjwak0lhjmJ1TCvNS2JsYPXA0VkZnuUg8UAJ1uNa0XT

