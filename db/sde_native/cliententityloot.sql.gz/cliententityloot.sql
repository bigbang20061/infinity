--
-- PostgreSQL database dump
--

\restrict SGnSXGxqBVsd5cijz9TCSFudmHH4dt3opTN2llW5846NtvecdSmtyn3tRBxXtrU

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cliententityloot; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.cliententityloot (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: cliententityloot; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.cliententityloot (row_no, key, data) FROM stdin;
0	72678	{"_key": 72678, "types": [44951, 57310]}
1	77736	{"_key": 77736, "types": [77500, 77787, 77788, 77789, 77790, 77791, 77793, 77792, 77794]}
2	79054	{"_key": 79054, "types": [79058, 32790, 53196, 48734, 63417, 34660, 55314, 48365, 52433, 52891, 46016, 46557, 52753, 63492, 77925, 77926, 77927, 77928, 77929, 77930, 77931, 77932, 77933, 79067]}
\.


--
-- Name: cliententityloot cliententityloot_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.cliententityloot
    ADD CONSTRAINT cliententityloot_pkey PRIMARY KEY (row_no);


--
-- Name: cliententityloot_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX cliententityloot_key_idx ON sde_native.cliententityloot USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict SGnSXGxqBVsd5cijz9TCSFudmHH4dt3opTN2llW5846NtvecdSmtyn3tRBxXtrU

