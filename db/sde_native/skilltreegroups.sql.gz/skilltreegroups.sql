--
-- PostgreSQL database dump
--

\restrict 8uutVdv2QDZntZbAIz0NPACyXdze00SwwoMOsGUfvaRtGXUtBY2bn3NIeRuMLIg

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: skilltreegroups; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.skilltreegroups (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: skilltreegroups; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.skilltreegroups (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "childSkillTreeGroups": [2, 3]}
1	2	{"_key": 2, "skills": [3330]}
2	3	{"_key": 3, "skills": [3331]}
\.


--
-- Name: skilltreegroups skilltreegroups_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.skilltreegroups
    ADD CONSTRAINT skilltreegroups_pkey PRIMARY KEY (row_no);


--
-- Name: skilltreegroups_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX skilltreegroups_key_idx ON sde_native.skilltreegroups USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 8uutVdv2QDZntZbAIz0NPACyXdze00SwwoMOsGUfvaRtGXUtBY2bn3NIeRuMLIg

