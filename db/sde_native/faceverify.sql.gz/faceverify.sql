--
-- PostgreSQL database dump
--

\restrict 1StXtN3uNWRuy9Ikaw7EcntsB4lTo93mxITXUvFjvk2vhehuBJZguF7lz4u6U9t

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: faceverify; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.faceverify (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: faceverify; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.faceverify (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "contact": "112233", "verifycount": 3}
\.


--
-- Name: faceverify faceverify_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.faceverify
    ADD CONSTRAINT faceverify_pkey PRIMARY KEY (row_no);


--
-- Name: faceverify_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX faceverify_key_idx ON sde_native.faceverify USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 1StXtN3uNWRuy9Ikaw7EcntsB4lTo93mxITXUvFjvk2vhehuBJZguF7lz4u6U9t

