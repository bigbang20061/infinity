--
-- PostgreSQL database dump
--

\restrict BsT5mcLZXefbqXj4kX8KcnNpmO8QfwBawbtMa4akSZ7YGSOJxqeRfrCpbTCgUQm

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.categories (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.categories (row_no, key, data) FROM stdin;
0	0	{"_key": 0, "published": 0, "categoryID": 0, "categoryNameID": 63539}
1	1	{"_key": 1, "published": 0, "categoryID": 1, "categoryNameID": 63540}
2	2	{"_key": 2, "published": 1, "categoryID": 2, "categoryNameID": 63541}
3	3	{"_key": 3, "published": 0, "categoryID": 3, "categoryNameID": 63542}
4	4	{"_key": 4, "iconID": 22, "published": 1, "categoryID": 4, "categoryNameID": 63543}
5	5	{"_key": 5, "iconID": 33, "published": 1, "categoryID": 5, "categoryNameID": 63560}
6	6	{"_key": 6, "published": 1, "categoryID": 6, "categoryNameID": 63544}
7	7	{"_key": 7, "iconID": 67, "published": 1, "categoryID": 7, "categoryNameID": 63545}
8	8	{"_key": 8, "published": 1, "categoryID": 8, "categoryNameID": 63546}
9	9	{"_key": 9, "iconID": 21, "published": 1, "categoryID": 9, "categoryNameID": 63547}
10	10	{"_key": 10, "published": 0, "categoryID": 10, "categoryNameID": 63548}
11	11	{"_key": 11, "published": 0, "categoryID": 11, "categoryNameID": 63549}
12	14	{"_key": 14, "iconID": 0, "published": 0, "categoryID": 14, "categoryNameID": 63550}
13	16	{"_key": 16, "iconID": 33, "published": 1, "categoryID": 16, "categoryNameID": 63551}
14	17	{"_key": 17, "iconID": 0, "published": 1, "categoryID": 17, "categoryNameID": 63552}
15	18	{"_key": 18, "iconID": 0, "published": 1, "categoryID": 18, "sofBuildClass": "ship", "categoryNameID": 63553}
16	20	{"_key": 20, "iconID": 0, "published": 1, "categoryID": 20, "categoryNameID": 63554}
17	22	{"_key": 22, "iconID": 0, "published": 1, "categoryID": 22, "categoryNameID": 63555}
18	23	{"_key": 23, "iconID": 0, "published": 0, "categoryID": 23, "categoryNameID": 63556}
19	24	{"_key": 24, "iconID": 0, "published": 1, "categoryID": 24, "categoryNameID": 63557}
20	25	{"_key": 25, "published": 1, "categoryID": 25, "categoryNameID": 63558}
21	26	{"_key": 26, "published": 0, "categoryID": 26, "categoryNameID": 63568}
22	29	{"_key": 29, "published": 0, "categoryID": 29, "categoryNameID": 63559}
23	30	{"_key": 30, "published": 1, "categoryID": 30, "categoryNameID": 63572}
24	32	{"_key": 32, "published": 1, "categoryID": 32, "categoryNameID": 63562}
25	34	{"_key": 34, "published": 1, "categoryID": 34, "categoryNameID": 63561}
26	35	{"_key": 35, "published": 1, "categoryID": 35, "categoryNameID": 63563}
27	39	{"_key": 39, "published": 1, "categoryID": 39, "categoryNameID": 63565}
28	40	{"_key": 40, "published": 1, "categoryID": 40, "categoryNameID": 63564}
29	41	{"_key": 41, "published": 1, "categoryID": 41, "categoryNameID": 63569}
30	42	{"_key": 42, "published": 1, "categoryID": 42, "categoryNameID": 63566}
31	43	{"_key": 43, "published": 1, "categoryID": 43, "categoryNameID": 63567}
32	46	{"_key": 46, "published": 1, "categoryID": 46, "categoryNameID": 63570}
33	49	{"_key": 49, "published": 0, "categoryID": 49, "categoryNameID": 63571}
34	53	{"_key": 53, "published": 0, "categoryID": 53, "categoryNameID": 63573}
35	54	{"_key": 54, "published": 0, "categoryID": 54, "categoryNameID": 63574}
36	59	{"_key": 59, "published": 0, "categoryID": 59, "categoryNameID": 235965}
37	63	{"_key": 63, "published": 1, "categoryID": 63, "categoryNameID": 285070}
38	65	{"_key": 65, "published": 1, "categoryID": 65, "categoryNameID": 308338}
39	66	{"_key": 66, "published": 1, "categoryID": 66, "categoryNameID": 308340}
40	87	{"_key": 87, "published": 1, "categoryID": 87, "categoryNameID": 510368}
41	91	{"_key": 91, "published": 1, "categoryID": 91, "categoryNameID": 531338}
42	2100	{"_key": 2100, "published": 1, "categoryID": 2100, "categoryNameID": 573416}
43	2107	{"_key": 2107, "published": 0, "categoryID": 2107, "categoryNameID": 587126}
44	2113	{"_key": 2113, "published": 1, "categoryID": 2113, "categoryNameID": 609214}
45	2116	{"_key": 2116, "published": 1, "categoryID": 2116, "categoryNameID": 611502}
46	2117	{"_key": 2117, "published": 1, "categoryID": 2117, "categoryNameID": 623061}
47	2118	{"_key": 2118, "published": 1, "categoryID": 2118, "categoryNameID": 631766}
48	2120	{"_key": 2120, "published": 0, "categoryID": 2120, "categoryNameID": 640542}
49	2125	{"_key": 2125, "published": 1, "categoryID": 2125, "categoryNameID": 626770}
50	2126	{"_key": 2126, "published": 1, "categoryID": 2126, "categoryNameID": 666796}
51	2127	{"_key": 2127, "published": 1, "categoryID": 2127, "categoryNameID": 687799}
52	2128	{"_key": 2128, "published": 0, "categoryID": 2128, "categoryNameID": 689669}
53	2143	{"_key": 2143, "iconID": 24296, "published": 1, "categoryID": 2143, "categoryNameID": 709447}
54	2152	{"_key": 2152, "published": 0, "categoryID": 2152, "categoryNameID": 1025580}
55	350001	{"_key": 350001, "published": 0, "categoryID": 350001, "categoryNameID": 267649}
\.


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (row_no);


--
-- Name: categories_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX categories_key_idx ON sde_native.categories USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict BsT5mcLZXefbqXj4kX8KcnNpmO8QfwBawbtMa4akSZ7YGSOJxqeRfrCpbTCgUQm

