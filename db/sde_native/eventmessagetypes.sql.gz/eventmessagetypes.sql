--
-- PostgreSQL database dump
--

\restrict PNfoelSIRgF3FaEvsKGeEtjUb3MEZzVcIrt4dO3c6vseh4hcKE7PUsewyEWkiRd

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: eventmessagetypes; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.eventmessagetypes (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: eventmessagetypes; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.eventmessagetypes (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "messageTypeName": "Imminent Danger"}
1	2	{"_key": 2, "messageTypeName": "NPC"}
2	3	{"_key": 3, "messageTypeName": "Environment"}
3	4	{"_key": 4, "messageTypeName": "Mood"}
4	5	{"_key": 5, "messageTypeName": "Story"}
5	6	{"_key": 6, "messageTypeName": "Mission Objective"}
6	7	{"_key": 7, "messageTypeName": "Mission Instruction"}
7	8	{"_key": 8, "messageTypeName": "Warning"}
\.


--
-- Name: eventmessagetypes eventmessagetypes_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.eventmessagetypes
    ADD CONSTRAINT eventmessagetypes_pkey PRIMARY KEY (row_no);


--
-- Name: eventmessagetypes_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX eventmessagetypes_key_idx ON sde_native.eventmessagetypes USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict PNfoelSIRgF3FaEvsKGeEtjUb3MEZzVcIrt4dO3c6vseh4hcKE7PUsewyEWkiRd

