--
-- PostgreSQL database dump
--

\restrict qiOifgnu4wpbVulw77CG3oUQc1muMBahhTTvPcSTsOf2oHOBUYYkjJvgdWYQL6P

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: contrabandtypes; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.contrabandtypes (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: contrabandtypes; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.contrabandtypes (row_no, key, data) FROM stdin;
0	3713	{"_key": 3713, "factions": {"500005": {"fineByValue": 4.5, "attackMinSec": 1.1, "standingLoss": 0.2, "confiscateMinSec": 0.4}, "500017": {"fineByValue": 1.5, "attackMinSec": 1.1, "standingLoss": 0.05, "confiscateMinSec": 0.5}}}
1	3721	{"_key": 3721, "factions": {"500001": {"fineByValue": 5.0, "attackMinSec": 1.1, "standingLoss": 0.2, "confiscateMinSec": -1.0}, "500002": {"fineByValue": 10.0, "attackMinSec": 1.1, "standingLoss": 0.5, "confiscateMinSec": -1.0}, "500004": {"fineByValue": 8.0, "attackMinSec": 1.1, "standingLoss": 0.3, "confiscateMinSec": -1.0}, "500005": {"fineByValue": 5.0, "attackMinSec": 1.1, "standingLoss": 0.2, "confiscateMinSec": -1.0}, "500006": {"fineByValue": 8.0, "attackMinSec": 1.1, "standingLoss": 0.0, "confiscateMinSec": -1.0}, "500009": {"fineByValue": 4.0, "attackMinSec": 1.1, "standingLoss": 0.15, "confiscateMinSec": -1.0}, "500014": {"fineByValue": 5.0, "attackMinSec": 1.1, "standingLoss": 0.2, "confiscateMinSec": -1.0}, "500015": {"fineByValue": 9.0, "attackMinSec": 1.1, "standingLoss": 0.4, "confiscateMinSec": -1.0}, "500016": {"fineByValue": 6.0, "attackMinSec": 1.1, "standingLoss": 0.3, "confiscateMinSec": -1.0}, "500017": {"fineByValue": 8.0, "attackMinSec": 1.1, "standingLoss": 0.3, "confiscateMinSec": -1.0}, "500018": {"fineByValue": 5.0, "attackMinSec": 1.1, "standingLoss": 0.2, "confiscateMinSec": -1.0}}}
2	3727	{"_key": 3727, "factions": {"500003": {"fineByValue": 1.2, "attackMinSec": 1.1, "standingLoss": 0.05, "confiscateMinSec": 0.6}, "500005": {"fineByValue": 3.0, "attackMinSec": 1.1, "standingLoss": 0.1, "confiscateMinSec": 0.5}, "500007": {"fineByValue": 1.2, "attackMinSec": 1.1, "standingLoss": 0.05, "confiscateMinSec": 0.6}, "500008": {"fineByValue": 1.2, "attackMinSec": 1.1, "standingLoss": 0.05, "confiscateMinSec": 0.5}, "500017": {"fineByValue": 2.0, "attackMinSec": 1.1, "standingLoss": 0.05, "confiscateMinSec": 0.4}}}
3	3729	{"_key": 3729, "factions": {"500001": {"fineByValue": 2.0, "attackMinSec": 1.1, "standingLoss": 0.1, "confiscateMinSec": 0.4}, "500002": {"fineByValue": 1.1, "attackMinSec": 1.1, "standingLoss": 0.05, "confiscateMinSec": 0.8}, "500004": {"fineByValue": 2.5, "attackMinSec": 1.1, "standingLoss": 0.15, "confiscateMinSec": 0.4}, "500005": {"fineByValue": 2.0, "attackMinSec": 1.1, "standingLoss": 0.05, "confiscateMinSec": 0.7}, "500006": {"fineByValue": 2.5, "attackMinSec": 1.1, "standingLoss": 0.0, "confiscateMinSec": 0.4}, "500009": {"fineByValue": 1.5, "attackMinSec": 1.1, "standingLoss": 0.05, "confiscateMinSec": 0.2}, "500014": {"fineByValue": 1.2, "attackMinSec": 1.1, "standingLoss": 0.05, "confiscateMinSec": 1.1}, "500015": {"fineByValue": 1.1, "attackMinSec": 1.1, "standingLoss": 0.05, "confiscateMinSec": -1.0}, "500016": {"fineByValue": 2.0, "attackMinSec": 1.1, "standingLoss": 0.1, "confiscateMinSec": -1.0}, "500017": {"fineByValue": 2.5, "attackMinSec": 1.1, "standingLoss": 0.15, "confiscateMinSec": -1.0}, "500018": {"fineByValue": 2.0, "attackMinSec": 1.1, "standingLoss": 0.05, "confiscateMinSec": -1.0}}}
4	9844	{"_key": 9844, "factions": {"500001": {"fineByValue": 5.0, "attackMinSec": 1.1, "standingLoss": 0.2, "confiscateMinSec": -1.0}, "500003": {"fineByValue": 3.0, "attackMinSec": 1.1, "standingLoss": 0.1, "confiscateMinSec": 0.5}, "500007": {"fineByValue": 1.5, "attackMinSec": 1.1, "standingLoss": 0.05, "confiscateMinSec": 0.6}, "500008": {"fineByValue": 4.0, "attackMinSec": 1.1, "standingLoss": 0.15, "confiscateMinSec": 0.3}, "500014": {"fineByValue": 1.1, "attackMinSec": 1.1, "standingLoss": 0.05, "confiscateMinSec": 0.4}, "500018": {"fineByValue": 3.0, "attackMinSec": 1.1, "standingLoss": 0.1, "confiscateMinSec": -1.0}}}
5	11855	{"_key": 11855, "factions": {"500004": {"fineByValue": 1.2, "attackMinSec": 1.1, "standingLoss": 0.05, "confiscateMinSec": 0.8}, "500009": {"fineByValue": 1.2, "attackMinSec": 1.1, "standingLoss": 0.05, "confiscateMinSec": 0.3}, "500014": {"fineByValue": 1.2, "attackMinSec": 1.1, "standingLoss": 0.05, "confiscateMinSec": 0.2}, "500016": {"fineByValue": 1.2, "attackMinSec": 1.1, "standingLoss": 0.05, "confiscateMinSec": -1.0}}}
6	12478	{"_key": 12478, "factions": {"500003": {"fineByValue": 10.0, "attackMinSec": 1.1, "standingLoss": 0.3, "confiscateMinSec": -1.0}, "500007": {"fineByValue": 10.0, "attackMinSec": 1.1, "standingLoss": 0.4, "confiscateMinSec": -1.0}, "500008": {"fineByValue": 7.0, "attackMinSec": 1.1, "standingLoss": 0.2, "confiscateMinSec": -1.0}}}
7	17796	{"_key": 17796, "factions": {"500001": {"fineByValue": 0.0, "attackMinSec": 1.1, "standingLoss": 0.0, "confiscateMinSec": 1.0}, "500002": {"fineByValue": 0.0, "attackMinSec": 1.1, "standingLoss": 0.0, "confiscateMinSec": 1.0}, "500004": {"fineByValue": 0.0, "attackMinSec": 1.1, "standingLoss": 0.0, "confiscateMinSec": 1.0}, "500006": {"fineByValue": 0.0, "attackMinSec": 1.1, "standingLoss": 0.0, "confiscateMinSec": 1.0}, "500013": {"fineByValue": 0.0, "attackMinSec": 1.1, "standingLoss": 0.0, "confiscateMinSec": 1.0}, "500014": {"fineByValue": 0.0, "attackMinSec": 1.1, "standingLoss": 0.0, "confiscateMinSec": 1.0}, "500016": {"fineByValue": 0.0, "attackMinSec": 1.1, "standingLoss": 0.0, "confiscateMinSec": 1.0}, "500017": {"fineByValue": 0.0, "attackMinSec": 1.1, "standingLoss": 0.0, "confiscateMinSec": 1.0}}}
\.


--
-- Name: contrabandtypes contrabandtypes_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.contrabandtypes
    ADD CONSTRAINT contrabandtypes_pkey PRIMARY KEY (row_no);


--
-- Name: contrabandtypes_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX contrabandtypes_key_idx ON sde_native.contrabandtypes USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict qiOifgnu4wpbVulw77CG3oUQc1muMBahhTTvPcSTsOf2oHOBUYYkjJvgdWYQL6P

