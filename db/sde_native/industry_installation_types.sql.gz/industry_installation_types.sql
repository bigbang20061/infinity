--
-- PostgreSQL database dump
--

\restrict ru46lyQrAdoP7LsxTmlWNR8HlJDsap8SFcEvhc3d7s0oWhR5hLKO27dCIVabUIp

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: industry_installation_types; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.industry_installation_types (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: industry_installation_types; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.industry_installation_types (row_no, key, data) FROM stdin;
0	3962	{"_key": 3962, "type_id": 3962, "assembly_lines": [{"assemblyLine": 22}]}
1	13780	{"_key": 13780, "type_id": 13780, "assembly_lines": [{"assemblyLine": 24}]}
2	16216	{"_key": 16216, "type_id": 16216, "assembly_lines": [{"assemblyLine": 28}, {"assemblyLine": 29}]}
3	16220	{"_key": 16220, "type_id": 16220, "assembly_lines": [{"assemblyLine": 23}]}
4	21642	{"_key": 21642, "type_id": 21642, "assembly_lines": [{"assemblyLine": 37}, {"assemblyLine": 3}, {"assemblyLine": 6}, {"assemblyLine": 32}, {"assemblyLine": 33}, {"assemblyLine": 34}, {"assemblyLine": 40}]}
5	21644	{"_key": 21644, "type_id": 21644, "assembly_lines": [{"assemblyLine": 37}, {"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}]}
6	21645	{"_key": 21645, "type_id": 21645, "assembly_lines": [{"assemblyLine": 37}, {"assemblyLine": 5}, {"assemblyLine": 6}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 38}]}
7	21646	{"_key": 21646, "type_id": 21646, "assembly_lines": [{"assemblyLine": 6}]}
8	24567	{"_key": 24567, "type_id": 24567, "assembly_lines": [{"assemblyLine": 158}]}
9	24574	{"_key": 24574, "type_id": 24574, "assembly_lines": [{"assemblyLine": 17}]}
10	24575	{"_key": 24575, "type_id": 24575, "assembly_lines": [{"assemblyLine": 10}]}
11	24653	{"_key": 24653, "type_id": 24653, "assembly_lines": [{"assemblyLine": 18}]}
12	24654	{"_key": 24654, "type_id": 24654, "assembly_lines": [{"assemblyLine": 19}]}
13	24655	{"_key": 24655, "type_id": 24655, "assembly_lines": [{"assemblyLine": 20}]}
14	24656	{"_key": 24656, "type_id": 24656, "assembly_lines": [{"assemblyLine": 21}]}
15	24657	{"_key": 24657, "type_id": 24657, "assembly_lines": [{"assemblyLine": 22}]}
16	24658	{"_key": 24658, "type_id": 24658, "assembly_lines": [{"assemblyLine": 25}]}
17	24659	{"_key": 24659, "type_id": 24659, "assembly_lines": [{"assemblyLine": 26}]}
18	24660	{"_key": 24660, "type_id": 24660, "assembly_lines": [{"assemblyLine": 27}]}
19	25305	{"_key": 25305, "type_id": 25305, "assembly_lines": [{"assemblyLine": 37}]}
20	28076	{"_key": 28076, "type_id": 28076, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
21	28077	{"_key": 28077, "type_id": 28077, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
22	28078	{"_key": 28078, "type_id": 28078, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
23	28079	{"_key": 28079, "type_id": 28079, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
24	28080	{"_key": 28080, "type_id": 28080, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
25	28081	{"_key": 28081, "type_id": 28081, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
26	28082	{"_key": 28082, "type_id": 28082, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
27	28083	{"_key": 28083, "type_id": 28083, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
28	28084	{"_key": 28084, "type_id": 28084, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
29	28085	{"_key": 28085, "type_id": 28085, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
30	28086	{"_key": 28086, "type_id": 28086, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
31	28087	{"_key": 28087, "type_id": 28087, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
32	28088	{"_key": 28088, "type_id": 28088, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
33	28089	{"_key": 28089, "type_id": 28089, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
34	28090	{"_key": 28090, "type_id": 28090, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
35	28091	{"_key": 28091, "type_id": 28091, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
36	28092	{"_key": 28092, "type_id": 28092, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
37	28093	{"_key": 28093, "type_id": 28093, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
38	28094	{"_key": 28094, "type_id": 28094, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
39	28095	{"_key": 28095, "type_id": 28095, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
40	28096	{"_key": 28096, "type_id": 28096, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
41	28097	{"_key": 28097, "type_id": 28097, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
42	28098	{"_key": 28098, "type_id": 28098, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
43	28099	{"_key": 28099, "type_id": 28099, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
44	28100	{"_key": 28100, "type_id": 28100, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
45	28101	{"_key": 28101, "type_id": 28101, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
46	28102	{"_key": 28102, "type_id": 28102, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
47	28103	{"_key": 28103, "type_id": 28103, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
48	28104	{"_key": 28104, "type_id": 28104, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
49	28105	{"_key": 28105, "type_id": 28105, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
50	28106	{"_key": 28106, "type_id": 28106, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
51	28107	{"_key": 28107, "type_id": 28107, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
52	28108	{"_key": 28108, "type_id": 28108, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
53	28109	{"_key": 28109, "type_id": 28109, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
54	28110	{"_key": 28110, "type_id": 28110, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
55	28111	{"_key": 28111, "type_id": 28111, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
56	28112	{"_key": 28112, "type_id": 28112, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
57	28113	{"_key": 28113, "type_id": 28113, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
58	28114	{"_key": 28114, "type_id": 28114, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
59	28115	{"_key": 28115, "type_id": 28115, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
60	28116	{"_key": 28116, "type_id": 28116, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
61	28117	{"_key": 28117, "type_id": 28117, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
62	28118	{"_key": 28118, "type_id": 28118, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
63	28119	{"_key": 28119, "type_id": 28119, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
64	28120	{"_key": 28120, "type_id": 28120, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
65	28121	{"_key": 28121, "type_id": 28121, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
66	28122	{"_key": 28122, "type_id": 28122, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
67	28123	{"_key": 28123, "type_id": 28123, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
68	28124	{"_key": 28124, "type_id": 28124, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
69	28125	{"_key": 28125, "type_id": 28125, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
70	28126	{"_key": 28126, "type_id": 28126, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
71	28127	{"_key": 28127, "type_id": 28127, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
72	28128	{"_key": 28128, "type_id": 28128, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
73	28129	{"_key": 28129, "type_id": 28129, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
74	28130	{"_key": 28130, "type_id": 28130, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
75	28131	{"_key": 28131, "type_id": 28131, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
76	28132	{"_key": 28132, "type_id": 28132, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
77	28133	{"_key": 28133, "type_id": 28133, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
78	28134	{"_key": 28134, "type_id": 28134, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
79	28135	{"_key": 28135, "type_id": 28135, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
80	28183	{"_key": 28183, "type_id": 28183, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
81	28184	{"_key": 28184, "type_id": 28184, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
82	28185	{"_key": 28185, "type_id": 28185, "assembly_lines": [{"assemblyLine": 5}, {"assemblyLine": 7}, {"assemblyLine": 8}, {"assemblyLine": 31}, {"assemblyLine": 37}]}
83	28351	{"_key": 28351, "type_id": 28351, "assembly_lines": [{"assemblyLine": 146}, {"assemblyLine": 149}]}
84	28352	{"_key": 28352, "type_id": 28352, "assembly_lines": [{"assemblyLine": 145}]}
85	28606	{"_key": 28606, "type_id": 28606, "assembly_lines": [{"assemblyLine": 145}]}
86	29613	{"_key": 29613, "type_id": 29613, "assembly_lines": [{"assemblyLine": 155}]}
87	30389	{"_key": 30389, "type_id": 30389, "assembly_lines": [{"assemblyLine": 159}]}
88	32245	{"_key": 32245, "type_id": 32245, "assembly_lines": [{"assemblyLine": 168}, {"assemblyLine": 169}]}
89	33685	{"_key": 33685, "type_id": 33685, "assembly_lines": [{"assemblyLine": 145}]}
90	33687	{"_key": 33687, "type_id": 33687, "assembly_lines": [{"assemblyLine": 145}]}
91	33867	{"_key": 33867, "type_id": 33867, "assembly_lines": [{"assemblyLine": 171}]}
92	35877	{"_key": 35877, "type_id": 35877, "assembly_lines": [{"assemblyLine": 176}, {"assemblyLine": 177}]}
93	35878	{"_key": 35878, "type_id": 35878, "assembly_lines": [{"assemblyLine": 175}]}
94	35880	{"_key": 35880, "type_id": 35880, "assembly_lines": [{"assemblyLine": 37}]}
95	35881	{"_key": 35881, "type_id": 35881, "assembly_lines": [{"assemblyLine": 176}]}
96	35886	{"_key": 35886, "type_id": 35886, "assembly_lines": [{"assemblyLine": 181}]}
97	35891	{"_key": 35891, "type_id": 35891, "assembly_lines": [{"assemblyLine": 179}, {"assemblyLine": 178}, {"assemblyLine": 180}]}
98	45537	{"_key": 45537, "type_id": 45537, "assembly_lines": [{"assemblyLine": 182}]}
99	45538	{"_key": 45538, "type_id": 45538, "assembly_lines": [{"assemblyLine": 183}]}
100	45539	{"_key": 45539, "type_id": 45539, "assembly_lines": [{"assemblyLine": 184}]}
101	45550	{"_key": 45550, "type_id": 45550, "assembly_lines": [{"assemblyLine": 178}, {"assemblyLine": 179}, {"assemblyLine": 180}]}
\.


--
-- Name: industry_installation_types industry_installation_types_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.industry_installation_types
    ADD CONSTRAINT industry_installation_types_pkey PRIMARY KEY (row_no);


--
-- Name: industry_installation_types_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX industry_installation_types_key_idx ON sde_native.industry_installation_types USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict ru46lyQrAdoP7LsxTmlWNR8HlJDsap8SFcEvhc3d7s0oWhR5hLKO27dCIVabUIp

