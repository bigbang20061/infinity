--
-- PostgreSQL database dump
--

\restrict DhUCasoxefvBpESvPYiSpmjjmfgG8bsWA90bvVON5Wk19tIENmYGKKhlNELhQd4

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: contenttagtypes; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.contenttagtypes (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: contenttagtypes; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.contenttagtypes (row_no, key, data) FROM stdin;
0	activity	{"_key": "activity", "title": 659160}
1	career_path	{"_key": "career_path", "title": 659158}
2	feature	{"_key": "feature", "title": 659159}
\.


--
-- Name: contenttagtypes contenttagtypes_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.contenttagtypes
    ADD CONSTRAINT contenttagtypes_pkey PRIMARY KEY (row_no);


--
-- Name: contenttagtypes_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX contenttagtypes_key_idx ON sde_native.contenttagtypes USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict DhUCasoxefvBpESvPYiSpmjjmfgG8bsWA90bvVON5Wk19tIENmYGKKhlNELhQd4

