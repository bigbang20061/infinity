--
-- PostgreSQL database dump
--

\restrict eT98L6XKo4G8dkZ8MVrmtfcci4a7lcq7CCi9BM4j1qR6HBcczyn50RM4astCOXy

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: iconids; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.iconids (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: iconids; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.iconids (row_no, key, data) FROM stdin;
0	0	{"_key": 0, "iconFile": "res:/ui/texture/icons/7_64_15.png"}
1	15	{"_key": 15, "iconFile": "res:/ui/texture/icons/5_64_11.png"}
2	16	{"_key": 16, "iconFile": "res:/ui/texture/icons/26_64_11.png"}
3	21	{"_key": 21, "iconFile": "res:/ui/texture/icons/6_64_3.png"}
4	22	{"_key": 22, "iconFile": "res:/ui/texture/icons/6_64_14.png"}
5	26	{"_key": 26, "iconFile": "res:/ui/texture/icons/6_64_5.png"}
6	27	{"_key": 27, "iconFile": "res:/ui/texture/icons/6_64_11.png"}
7	28	{"_key": 28, "iconFile": "res:/ui/texture/icons/6_64_9.png"}
8	29	{"_key": 29, "iconFile": "res:/ui/texture/icons/6_64_6.png"}
9	30	{"_key": 30, "iconFile": "res:/ui/texture/icons/11_64_8.png"}
10	31	{"_key": 31, "iconFile": "res:/ui/texture/icons/6_64_10.png"}
11	33	{"_key": 33, "iconFile": "res:/ui/texture/icons/50_64_11.png"}
12	34	{"_key": 34, "iconFile": "res:/ui/texture/icons/8_64_16.png"}
13	67	{"_key": 67, "iconFile": "res:/ui/texture/icons/2_64_9.png"}
14	68	{"_key": 68, "iconFile": "res:/ui/texture/icons/1_64_9.png"}
15	69	{"_key": 69, "iconFile": "res:/ui/texture/icons/1_64_13.png"}
16	70	{"_key": 70, "iconFile": "res:/ui/texture/icons/2_64_7.png"}
17	71	{"_key": 71, "iconFile": "res:/ui/texture/icons/3_64_13.png"}
18	72	{"_key": 72, "iconFile": "res:/ui/texture/icons/3_64_1.png"}
19	73	{"_key": 73, "iconFile": "res:/ui/texture/icons/2_64_14.png"}
20	74	{"_key": 74, "iconFile": "res:/ui/texture/icons/3_64_9.png"}
21	75	{"_key": 75, "iconFile": "res:/ui/texture/icons/2_64_13.png"}
22	76	{"_key": 76, "iconFile": "res:/ui/texture/icons/2_64_10.png"}
23	77	{"_key": 77, "iconFile": "res:/ui/texture/icons/2_64_11.png"}
24	78	{"_key": 78, "iconFile": "res:/ui/texture/icons/1_64_12.png"}
25	79	{"_key": 79, "iconFile": "res:/ui/texture/icons/1_64_10.png"}
26	80	{"_key": 80, "iconFile": "res:/ui/texture/icons/1_64_11.png"}
27	81	{"_key": 81, "iconFile": "res:/ui/texture/icons/2_64_2.png"}
28	82	{"_key": 82, "iconFile": "res:/ui/texture/icons/2_64_4.png"}
29	83	{"_key": 83, "iconFile": "res:/ui/texture/icons/1_64_15.png"}
30	84	{"_key": 84, "iconFile": "res:/ui/texture/icons/2_64_3.png"}
31	85	{"_key": 85, "iconFile": "res:/ui/texture/icons/2_64_1.png"}
32	86	{"_key": 86, "iconFile": "res:/ui/texture/icons/1_64_16.png"}
33	87	{"_key": 87, "iconFile": "res:/ui/texture/icons/1_64_14.png"}
34	88	{"_key": 88, "iconFile": "res:/ui/texture/icons/4_64_8.png"}
35	89	{"_key": 89, "iconFile": "res:/ui/texture/icons/1_64_4.png"}
36	90	{"_key": 90, "iconFile": "res:/ui/texture/icons/1_64_1.png"}
37	91	{"_key": 91, "iconFile": "res:/UI/Texture/Icons/StatusEffects/tether.png"}
38	92	{"_key": 92, "iconFile": "res:/ui/texture/icons/4_64_13.png"}
39	93	{"_key": 93, "iconFile": "res:/ui/texture/icons/3_64_15.png"}
40	94	{"_key": 94, "iconFile": "res:/ui/texture/icons/4_64_14.png"}
41	95	{"_key": 95, "iconFile": "res:/ui/texture/icons/3_64_14.png"}
42	96	{"_key": 96, "iconFile": "res:/ui/texture/icons/3_64_2.png"}
43	97	{"_key": 97, "iconFile": "res:/ui/texture/icons/3_64_8.png"}
44	98	{"_key": 98, "iconFile": "res:/ui/texture/icons/3_64_5.png"}
45	104	{"_key": 104, "iconFile": "res:/ui/texture/icons/4_64_10.png"}
46	105	{"_key": 105, "iconFile": "res:/ui/texture/icons/4_64_11.png"}
47	106	{"_key": 106, "iconFile": "res:/ui/texture/icons/3_64_11.png"}
48	107	{"_key": 107, "iconFile": "res:/ui/texture/icons/3_64_10.png"}
49	109	{"_key": 109, "iconFile": "res:/ui/texture/icons/4_64_12.png"}
50	110	{"_key": 110, "iconFile": "res:/ui/texture/icons/5_64_1.png"}
51	111	{"_key": 111, "iconFile": "res:/ui/texture/icons/4_64_9.png"}
52	112	{"_key": 112, "iconFile": "res:/ui/texture/icons/3_64_4.png"}
53	138	{"_key": 138, "iconFile": "res:/ui/texture/icons/4_64_1.png"}
54	168	{"_key": 168, "iconFile": "res:/ui/texture/icons/12_64_12.png"}
55	169	{"_key": 169, "iconFile": "res:/ui/texture/icons/21_64_12.png"}
56	170	{"_key": 170, "iconFile": "res:/ui/texture/icons/21_64_16.png"}
57	182	{"_key": 182, "iconFile": "res:/ui/texture/icons/20_64_16.png"}
58	183	{"_key": 183, "iconFile": "res:/ui/texture/icons/20_64_4.png"}
59	184	{"_key": 184, "iconFile": "res:/ui/texture/icons/20_64_8.png"}
60	185	{"_key": 185, "iconFile": "res:/ui/texture/icons/20_64_12.png"}
61	186	{"_key": 186, "iconFile": "res:/ui/texture/icons/20_64_10.png"}
62	187	{"_key": 187, "iconFile": "res:/ui/texture/icons/20_64_14.png"}
63	188	{"_key": 188, "iconFile": "res:/ui/texture/icons/20_64_6.png"}
64	189	{"_key": 189, "iconFile": "res:/ui/texture/icons/20_64_2.png"}
65	190	{"_key": 190, "iconFile": "res:/ui/texture/icons/13_64_4.png"}
66	191	{"_key": 191, "iconFile": "res:/ui/texture/icons/13_64_8.png"}
67	192	{"_key": 192, "iconFile": "res:/ui/texture/icons/13_64_16.png"}
68	193	{"_key": 193, "iconFile": "res:/ui/texture/icons/13_64_12.png"}
69	230	{"_key": 230, "iconFile": "res:/ui/texture/icons/24_64_2.png"}
70	231	{"_key": 231, "iconFile": "res:/ui/texture/icons/23_64_16.png"}
71	232	{"_key": 232, "iconFile": "res:/ui/texture/icons/24_64_1.png"}
72	293	{"_key": 293, "iconFile": "res:/ui/texture/icons/8_64_11.png"}
73	294	{"_key": 294, "iconFile": "res:/ui/texture/icons/8_64_10.png"}
74	295	{"_key": 295, "iconFile": "res:/ui/texture/icons/8_64_9.png"}
75	349	{"_key": 349, "iconFile": "res:/ui/texture/icons/13_64_5.png"}
76	350	{"_key": 350, "iconFile": "res:/ui/texture/icons/13_64_13.png"}
77	352	{"_key": 352, "iconFile": "res:/ui/texture/icons/13_64_9.png"}
78	355	{"_key": 355, "iconFile": "res:/ui/texture/icons/13_64_10.png"}
79	356	{"_key": 356, "iconFile": "res:/ui/texture/icons/13_64_14.png"}
80	360	{"_key": 360, "iconFile": "res:/ui/texture/icons/13_64_15.png"}
81	361	{"_key": 361, "iconFile": "res:/ui/texture/icons/13_64_11.png"}
82	365	{"_key": 365, "iconFile": "res:/ui/texture/icons/13_64_3.png"}
83	366	{"_key": 366, "iconFile": "res:/ui/texture/icons/13_64_7.png"}
84	370	{"_key": 370, "iconFile": "res:/ui/texture/icons/13_64_6.png"}
85	371	{"_key": 371, "iconFile": "res:/ui/texture/icons/13_64_2.png"}
86	376	{"_key": 376, "iconFile": "res:/ui/texture/icons/13_64_1.png"}
87	379	{"_key": 379, "iconFile": "res:/ui/texture/icons/12_64_15.png"}
88	381	{"_key": 381, "iconFile": "res:/ui/texture/icons/12_64_11.png"}
89	384	{"_key": 384, "iconFile": "res:/ui/texture/icons/12_64_14.png"}
90	386	{"_key": 386, "iconFile": "res:/ui/texture/icons/12_64_10.png"}
91	387	{"_key": 387, "iconFile": "res:/ui/texture/icons/12_64_9.png"}
92	389	{"_key": 389, "iconFile": "res:/ui/texture/icons/12_64_13.png"}
93	398	{"_key": 398, "iconFile": "res:/ui/texture/icons/11_64_5.png"}
94	400	{"_key": 400, "iconFile": "res:/ui/texture/icons/6_64_15.png"}
95	401	{"_key": 401, "iconFile": "res:/ui/texture/icons/6_64_12.png"}
96	402	{"_key": 402, "iconFile": "res:/ui/texture/icons/6_64_16.png"}
97	404	{"_key": 404, "iconFile": "res:/ui/texture/icons/11_64_11.png"}
98	405	{"_key": 405, "iconFile": "res:/ui/texture/icons/11_64_10.png"}
99	413	{"_key": 413, "iconFile": "res:/ui/texture/icons/8_64_12.png"}
100	998	{"_key": 998, "iconFile": "res:/ui/texture/icons/9_64_9.png"}
101	999	{"_key": 999, "iconFile": "res:/ui/texture/icons/9_64_11.png"}
102	1001	{"_key": 1001, "iconFile": "res:/ui/texture/icons/9_64_10.png"}
103	1002	{"_key": 1002, "iconFile": "res:/ui/texture/icons/9_64_8.png"}
104	1004	{"_key": 1004, "iconFile": "res:/ui/texture/icons/14_64_1.png"}
105	1007	{"_key": 1007, "iconFile": "res:/ui/texture/icons/21_64_8.png"}
106	1029	{"_key": 1029, "iconFile": "res:/ui/texture/icons/1_64_3.png"}
107	1030	{"_key": 1030, "iconFile": "res:/ui/texture/icons/1_64_8.png"}
108	1031	{"_key": 1031, "iconFile": "res:/ui/texture/icons/1_64_6.png"}
109	1033	{"_key": 1033, "iconFile": "res:/ui/texture/icons/1_64_7.png"}
110	1035	{"_key": 1035, "iconFile": "res:/ui/texture/icons/1_64_2.png"}
111	1036	{"_key": 1036, "iconFile": "res:/ui/texture/icons/2_64_6.png"}
112	1041	{"_key": 1041, "iconFile": "res:/ui/texture/icons/3_64_6.png"}
113	1042	{"_key": 1042, "iconFile": "res:/ui/texture/icons/2_64_12.png"}
114	1044	{"_key": 1044, "iconFile": "res:/ui/texture/icons/2_64_5.png"}
115	1046	{"_key": 1046, "iconFile": "res:/ui/texture/icons/5_64_12.png"}
116	1047	{"_key": 1047, "iconFile": "res:/ui/texture/icons/15_64_9.png"}
117	1061	{"_key": 1061, "iconFile": "res:/ui/texture/icons/12_64_8.png"}
118	1063	{"_key": 1063, "iconFile": "res:/ui/texture/icons/5_64_16.png"}
119	1084	{"_key": 1084, "iconFile": "res:/ui/texture/icons/11_64_16.png"}
120	1131	{"_key": 1131, "iconFile": "res:/ui/texture/icons/8_64_1.png"}
121	1139	{"_key": 1139, "iconFile": "res:/ui/texture/icons/8_64_2.png"}
122	1140	{"_key": 1140, "iconFile": "res:/ui/texture/icons/8_64_3.png"}
123	1141	{"_key": 1141, "iconFile": "res:/ui/texture/icons/8_64_4.png"}
124	1142	{"_key": 1142, "iconFile": "res:/ui/texture/icons/8_64_5.png"}
125	1143	{"_key": 1143, "iconFile": "res:/ui/texture/icons/8_64_6.png"}
126	1144	{"_key": 1144, "iconFile": "res:/ui/texture/icons/8_64_7.png"}
127	1145	{"_key": 1145, "iconFile": "res:/ui/texture/icons/8_64_8.png"}
128	1156	{"_key": 1156, "iconFile": "res:/ui/texture/icons/26_64_14.png"}
129	1157	{"_key": 1157, "iconFile": "res:/ui/texture/icons/27_64_8.png"}
130	1158	{"_key": 1158, "iconFile": "res:/ui/texture/icons/27_64_7.png"}
131	1159	{"_key": 1159, "iconFile": "res:/ui/texture/icons/27_64_6.png"}
132	1162	{"_key": 1162, "iconFile": "res:/ui/texture/icons/27_64_12.png"}
133	1163	{"_key": 1163, "iconFile": "res:/ui/texture/icons/27_64_11.png"}
134	1164	{"_key": 1164, "iconFile": "res:/ui/texture/icons/27_64_10.png"}
135	1168	{"_key": 1168, "iconFile": "res:/ui/texture/icons/27_64_16.png"}
136	1169	{"_key": 1169, "iconFile": "res:/ui/texture/icons/27_64_15.png"}
137	1170	{"_key": 1170, "iconFile": "res:/ui/texture/icons/27_64_14.png"}
138	1171	{"_key": 1171, "iconFile": "res:/ui/texture/icons/27_64_5.png"}
139	1172	{"_key": 1172, "iconFile": "res:/ui/texture/icons/26_64_16.png"}
140	1173	{"_key": 1173, "iconFile": "res:/ui/texture/icons/26_64_15.png"}
141	1174	{"_key": 1174, "iconFile": "res:/ui/texture/icons/26_64_13.png"}
142	1175	{"_key": 1175, "iconFile": "res:/ui/texture/icons/26_64_12.png"}
143	1177	{"_key": 1177, "iconFile": "res:/ui/texture/icons/10_64_5.png"}
144	1178	{"_key": 1178, "iconFile": "res:/ui/texture/icons/10_64_4.png"}
145	1179	{"_key": 1179, "iconFile": "res:/ui/texture/icons/10_64_3.png"}
146	1180	{"_key": 1180, "iconFile": "res:/ui/texture/icons/10_64_1.png"}
147	1181	{"_key": 1181, "iconFile": "res:/ui/texture/icons/10_64_2.png"}
148	1182	{"_key": 1182, "iconFile": "res:/ui/texture/icons/10_64_6.png"}
149	1183	{"_key": 1183, "iconFile": "res:/ui/texture/icons/10_64_7.png"}
150	1184	{"_key": 1184, "iconFile": "res:/ui/texture/icons/10_64_8.png"}
151	1185	{"_key": 1185, "iconFile": "res:/ui/texture/icons/10_64_9.png"}
152	1186	{"_key": 1186, "iconFile": "res:/ui/texture/icons/10_64_10.png"}
153	1187	{"_key": 1187, "iconFile": "res:/ui/texture/icons/10_64_11.png"}
154	1188	{"_key": 1188, "iconFile": "res:/ui/texture/icons/10_64_12.png"}
155	1189	{"_key": 1189, "iconFile": "res:/ui/texture/icons/10_64_13.png"}
156	1190	{"_key": 1190, "iconFile": "res:/ui/texture/icons/10_64_14.png"}
157	1191	{"_key": 1191, "iconFile": "res:/ui/texture/icons/10_64_15.png"}
158	1192	{"_key": 1192, "iconFile": "res:/ui/texture/icons/10_64_16.png"}
159	1193	{"_key": 1193, "iconFile": "res:/ui/texture/icons/11_64_1.png"}
160	1194	{"_key": 1194, "iconFile": "res:/ui/texture/icons/11_64_2.png"}
161	1195	{"_key": 1195, "iconFile": "res:/ui/texture/icons/11_64_3.png"}
162	1196	{"_key": 1196, "iconFile": "res:/ui/texture/icons/11_64_4.png"}
163	1198	{"_key": 1198, "iconFile": "res:/ui/texture/icons/11_64_6.png"}
164	1199	{"_key": 1199, "iconFile": "res:/ui/texture/icons/11_64_7.png"}
165	1200	{"_key": 1200, "iconFile": "res:/ui/texture/icons/6_64_13.png"}
166	1201	{"_key": 1201, "iconFile": "res:/ui/texture/icons/11_64_9.png"}
167	1204	{"_key": 1204, "iconFile": "res:/ui/texture/icons/11_64_12.png"}
168	1205	{"_key": 1205, "iconFile": "res:/ui/texture/icons/11_64_13.png"}
169	1206	{"_key": 1206, "iconFile": "res:/ui/texture/icons/11_64_14.png"}
170	1207	{"_key": 1207, "iconFile": "res:/ui/texture/icons/11_64_15.png"}
171	1209	{"_key": 1209, "iconFile": "res:/ui/texture/icons/7_64_16.png"}
172	1269	{"_key": 1269, "iconFile": "res:/ui/texture/icons/23_64_9.png"}
173	1270	{"_key": 1270, "iconFile": "res:/ui/texture/icons/23_64_12.png"}
174	1271	{"_key": 1271, "iconFile": "res:/ui/texture/icons/23_64_13.png"}
175	1272	{"_key": 1272, "iconFile": "res:/ui/texture/icons/23_64_7.png"}
176	1273	{"_key": 1273, "iconFile": "res:/ui/texture/icons/23_64_6.png"}
177	1274	{"_key": 1274, "iconFile": "res:/ui/texture/icons/23_64_14.png"}
178	1275	{"_key": 1275, "iconFile": "res:/ui/texture/icons/23_64_8.png"}
179	1277	{"_key": 1277, "iconFile": "res:/ui/texture/icons/23_64_5.png"}
180	1279	{"_key": 1279, "iconFile": "res:/ui/texture/icons/23_64_11.png"}
181	1282	{"_key": 1282, "iconFile": "res:/ui/texture/icons/23_64_10.png"}
182	1283	{"_key": 1283, "iconFile": "res:/ui/texture/icons/12_64_4.png"}
183	1284	{"_key": 1284, "iconFile": "res:/ui/texture/icons/12_64_6.png"}
184	1285	{"_key": 1285, "iconFile": "res:/ui/texture/icons/14_64_2.png"}
185	1286	{"_key": 1286, "iconFile": "res:/ui/texture/icons/14_64_3.png"}
186	1287	{"_key": 1287, "iconFile": "res:/ui/texture/icons/14_64_4.png"}
187	1288	{"_key": 1288, "iconFile": "res:/ui/texture/icons/14_64_5.png"}
188	1289	{"_key": 1289, "iconFile": "res:/ui/texture/icons/14_64_6.png"}
189	1290	{"_key": 1290, "iconFile": "res:/ui/texture/icons/14_64_7.png"}
190	1291	{"_key": 1291, "iconFile": "res:/ui/texture/icons/14_64_8.png"}
191	1292	{"_key": 1292, "iconFile": "res:/ui/texture/icons/14_64_9.png"}
192	1293	{"_key": 1293, "iconFile": "res:/ui/texture/icons/14_64_10.png"}
193	1294	{"_key": 1294, "iconFile": "res:/ui/texture/icons/14_64_11.png"}
194	1295	{"_key": 1295, "iconFile": "res:/ui/texture/icons/14_64_12.png"}
195	1296	{"_key": 1296, "iconFile": "res:/ui/texture/icons/14_64_13.png"}
196	1297	{"_key": 1297, "iconFile": "res:/ui/texture/icons/14_64_14.png"}
197	1298	{"_key": 1298, "iconFile": "res:/ui/texture/icons/14_64_15.png"}
198	1299	{"_key": 1299, "iconFile": "res:/ui/texture/icons/14_64_16.png"}
199	1300	{"_key": 1300, "iconFile": "res:/ui/texture/icons/15_64_1.png"}
200	1301	{"_key": 1301, "iconFile": "res:/ui/texture/icons/15_64_2.png"}
201	1302	{"_key": 1302, "iconFile": "res:/ui/texture/icons/15_64_3.png"}
202	1303	{"_key": 1303, "iconFile": "res:/ui/texture/icons/15_64_4.png"}
203	1304	{"_key": 1304, "iconFile": "res:/ui/texture/icons/15_64_5.png"}
204	1305	{"_key": 1305, "iconFile": "res:/ui/texture/icons/15_64_6.png"}
205	1306	{"_key": 1306, "iconFile": "res:/ui/texture/icons/15_64_7.png"}
206	1307	{"_key": 1307, "iconFile": "res:/ui/texture/icons/15_64_8.png"}
207	1310	{"_key": 1310, "iconFile": "res:/ui/texture/icons/15_64_10.png"}
208	1311	{"_key": 1311, "iconFile": "res:/ui/texture/icons/15_64_11.png"}
209	1312	{"_key": 1312, "iconFile": "res:/ui/texture/icons/15_64_12.png"}
210	1313	{"_key": 1313, "iconFile": "res:/ui/texture/icons/15_64_13.png"}
211	1314	{"_key": 1314, "iconFile": "res:/ui/texture/icons/15_64_14.png"}
212	1315	{"_key": 1315, "iconFile": "res:/ui/texture/icons/15_64_15.png"}
213	1316	{"_key": 1316, "iconFile": "res:/ui/texture/icons/15_64_16.png"}
214	1317	{"_key": 1317, "iconFile": "res:/ui/texture/icons/16_64_1.png"}
215	1318	{"_key": 1318, "iconFile": "res:/ui/texture/icons/16_64_2.png"}
216	1319	{"_key": 1319, "iconFile": "res:/ui/texture/icons/16_64_3.png"}
217	1320	{"_key": 1320, "iconFile": "res:/ui/texture/icons/16_64_4.png"}
218	1321	{"_key": 1321, "iconFile": "res:/ui/texture/icons/16_64_5.png"}
219	1322	{"_key": 1322, "iconFile": "res:/ui/texture/icons/16_64_6.png"}
220	1323	{"_key": 1323, "iconFile": "res:/ui/texture/icons/16_64_7.png"}
221	1324	{"_key": 1324, "iconFile": "res:/ui/texture/icons/16_64_8.png"}
222	1325	{"_key": 1325, "iconFile": "res:/ui/texture/icons/16_64_9.png"}
223	1326	{"_key": 1326, "iconFile": "res:/ui/texture/icons/16_64_10.png"}
224	1327	{"_key": 1327, "iconFile": "res:/ui/texture/icons/16_64_11.png"}
225	1328	{"_key": 1328, "iconFile": "res:/ui/texture/icons/16_64_12.png"}
226	1329	{"_key": 1329, "iconFile": "res:/ui/texture/icons/16_64_13.png"}
227	1330	{"_key": 1330, "iconFile": "res:/ui/texture/icons/16_64_14.png"}
228	1331	{"_key": 1331, "iconFile": "res:/ui/texture/icons/16_64_15.png"}
229	1332	{"_key": 1332, "iconFile": "res:/ui/texture/icons/16_64_16.png"}
230	1333	{"_key": 1333, "iconFile": "res:/ui/texture/icons/20_64_1.png"}
231	1334	{"_key": 1334, "iconFile": "res:/ui/texture/icons/20_64_5.png"}
232	1335	{"_key": 1335, "iconFile": "res:/ui/texture/icons/20_64_9.png"}
233	1336	{"_key": 1336, "iconFile": "res:/ui/texture/icons/20_64_13.png"}
234	1337	{"_key": 1337, "iconFile": "res:/ui/texture/icons/20_64_7.png"}
235	1338	{"_key": 1338, "iconFile": "res:/ui/texture/icons/20_64_11.png"}
236	1339	{"_key": 1339, "iconFile": "res:/ui/texture/icons/20_64_15.png"}
237	1340	{"_key": 1340, "iconFile": "res:/ui/texture/icons/20_64_3.png"}
238	1341	{"_key": 1341, "iconFile": "res:/ui/texture/icons/21_64_1.png"}
239	1342	{"_key": 1342, "iconFile": "res:/ui/texture/icons/21_64_5.png"}
240	1343	{"_key": 1343, "iconFile": "res:/ui/texture/icons/21_64_9.png"}
241	1344	{"_key": 1344, "iconFile": "res:/ui/texture/icons/21_64_13.png"}
242	1345	{"_key": 1345, "iconFile": "res:/ui/texture/icons/12_64_16.png"}
243	1346	{"_key": 1346, "iconFile": "res:/ui/texture/icons/21_64_2.png"}
244	1347	{"_key": 1347, "iconFile": "res:/ui/texture/icons/21_64_6.png"}
245	1348	{"_key": 1348, "iconFile": "res:/ui/texture/icons/21_64_10.png"}
246	1349	{"_key": 1349, "iconFile": "res:/ui/texture/icons/21_64_14.png"}
247	1350	{"_key": 1350, "iconFile": "res:/ui/texture/icons/21_64_3.png"}
248	1351	{"_key": 1351, "iconFile": "res:/ui/texture/icons/21_64_7.png"}
249	1352	{"_key": 1352, "iconFile": "res:/ui/texture/icons/21_64_15.png"}
250	1353	{"_key": 1353, "iconFile": "res:/ui/texture/icons/21_64_11.png"}
251	1356	{"_key": 1356, "iconFile": "res:/ui/texture/icons/23_64_15.png"}
252	1357	{"_key": 1357, "iconFile": "res:/ui/texture/icons/24_64_3.png"}
253	1358	{"_key": 1358, "iconFile": "res:/ui/texture/icons/24_64_4.png"}
254	1359	{"_key": 1359, "iconFile": "res:/ui/texture/icons/24_64_5.png"}
255	1360	{"_key": 1360, "iconFile": "res:/ui/texture/icons/24_64_6.png"}
256	1361	{"_key": 1361, "iconFile": "res:/ui/texture/icons/24_64_7.png"}
257	1362	{"_key": 1362, "iconFile": "res:/ui/texture/icons/24_64_8.png"}
258	1363	{"_key": 1363, "iconFile": "res:/ui/texture/icons/24_64_9.png"}
259	1364	{"_key": 1364, "iconFile": "res:/ui/texture/icons/24_64_10.png"}
260	1365	{"_key": 1365, "iconFile": "res:/ui/texture/icons/24_64_11.png"}
261	1366	{"_key": 1366, "iconFile": "res:/ui/texture/icons/24_64_12.png"}
262	1367	{"_key": 1367, "iconFile": "res:/ui/texture/icons/24_64_13.png"}
263	1368	{"_key": 1368, "iconFile": "res:/ui/texture/icons/24_64_14.png"}
264	1369	{"_key": 1369, "iconFile": "res:/ui/texture/icons/24_64_15.png"}
265	1370	{"_key": 1370, "iconFile": "res:/ui/texture/icons/24_64_16.png"}
266	1377	{"_key": 1377, "iconFile": "res:/ui/texture/icons/25_64_1.png"}
267	1378	{"_key": 1378, "iconFile": "res:/ui/texture/icons/22_32_1.png"}
268	1379	{"_key": 1379, "iconFile": "res:/ui/texture/icons/22_32_2.png"}
269	1380	{"_key": 1380, "iconFile": "res:/ui/texture/icons/22_32_3.png"}
270	1381	{"_key": 1381, "iconFile": "res:/ui/texture/icons/22_32_4.png"}
271	1382	{"_key": 1382, "iconFile": "res:/ui/texture/icons/22_32_5.png"}
272	1383	{"_key": 1383, "iconFile": "res:/ui/texture/icons/22_32_6.png"}
273	1384	{"_key": 1384, "iconFile": "res:/ui/texture/icons/22_32_7.png"}
274	1385	{"_key": 1385, "iconFile": "res:/ui/texture/icons/22_32_9.png"}
275	1386	{"_key": 1386, "iconFile": "res:/ui/texture/icons/22_32_10.png"}
276	1387	{"_key": 1387, "iconFile": "res:/ui/texture/icons/22_32_11.png"}
277	1388	{"_key": 1388, "iconFile": "res:/ui/texture/icons/22_32_12.png"}
278	1389	{"_key": 1389, "iconFile": "res:/ui/texture/icons/22_32_13.png"}
279	1390	{"_key": 1390, "iconFile": "res:/ui/texture/icons/22_32_14.png"}
280	1391	{"_key": 1391, "iconFile": "res:/ui/texture/icons/22_32_15.png"}
281	1392	{"_key": 1392, "iconFile": "res:/ui/texture/icons/22_32_16.png"}
282	1393	{"_key": 1393, "iconFile": "res:/ui/texture/icons/22_32_9.png"}
283	1394	{"_key": 1394, "iconFile": "res:/ui/texture/icons/22_32_10.png"}
284	1395	{"_key": 1395, "iconFile": "res:/ui/texture/icons/22_32_11.png"}
285	1396	{"_key": 1396, "iconFile": "res:/ui/texture/icons/22_32_12.png"}
286	1397	{"_key": 1397, "iconFile": "res:/ui/texture/icons/22_32_21.png"}
287	1398	{"_key": 1398, "iconFile": "res:/ui/texture/icons/22_32_22.png"}
288	1399	{"_key": 1399, "iconFile": "res:/ui/texture/icons/22_32_23.png"}
289	1400	{"_key": 1400, "iconFile": "res:/ui/texture/icons/2_64_7.png"}
290	1401	{"_key": 1401, "iconFile": "res:/ui/texture/icons/22_32_24.png"}
291	1405	{"_key": 1405, "iconFile": "res:/ui/texture/icons/12_64_7.png"}
292	1406	{"_key": 1406, "iconFile": "res:/ui/texture/icons/25_64_2.png"}
293	1432	{"_key": 1432, "iconFile": "res:/ui/texture/icons/26_64_1.png"}
294	1433	{"_key": 1433, "iconFile": "res:/ui/texture/icons/26_64_2.png"}
295	1434	{"_key": 1434, "iconFile": "res:/ui/texture/icons/26_64_3.png"}
296	1435	{"_key": 1435, "iconFile": "res:/ui/texture/icons/26_64_4.png"}
297	1436	{"_key": 1436, "iconFile": "res:/ui/texture/icons/27_64_1.png"}
298	1437	{"_key": 1437, "iconFile": "res:/ui/texture/icons/27_64_2.png"}
299	1438	{"_key": 1438, "iconFile": "res:/ui/texture/icons/27_64_3.png"}
300	1439	{"_key": 1439, "iconFile": "res:/ui/texture/icons/19_128_1.png"}
301	1440	{"_key": 1440, "iconFile": "res:/ui/texture/icons/19_128_2.png"}
302	1441	{"_key": 1441, "iconFile": "res:/ui/texture/icons/19_128_3.png"}
303	1442	{"_key": 1442, "iconFile": "res:/ui/texture/icons/19_128_4.png"}
304	1443	{"_key": 1443, "iconFile": "res:/ui/texture/icons/9_64_5.png"}
305	1444	{"_key": 1444, "iconFile": "res:/ui/texture/icons/25_64_4.png"}
306	1445	{"_key": 1445, "iconFile": "res:/ui/texture/icons/3_64_7.png"}
307	1446	{"_key": 1446, "iconFile": "res:/ui/texture/icons/9_64_16.png"}
308	1447	{"_key": 1447, "iconFile": "res:/ui/texture/corps/42_128_3.png"}
309	1448	{"_key": 1448, "iconFile": "res:/ui/texture/corps/43_128_1.png"}
310	1449	{"_key": 1449, "iconFile": "res:/ui/texture/corps/39_128_4.png"}
311	1450	{"_key": 1450, "iconFile": "res:/ui/texture/corps/43_128_2.png"}
312	1451	{"_key": 1451, "iconFile": "res:/ui/texture/corps/43_128_3.png"}
313	1452	{"_key": 1452, "iconFile": "res:/ui/texture/corps/42_128_1.png"}
314	1453	{"_key": 1453, "iconFile": "res:/ui/texture/corps/10_128_2.png"}
315	1454	{"_key": 1454, "iconFile": "res:/ui/texture/corps/42_128_4.png"}
316	1455	{"_key": 1455, "iconFile": "res:/ui/texture/corps/10_128_1.png"}
317	1456	{"_key": 1456, "iconFile": "res:/ui/texture/corps/39_128_1.png"}
318	1457	{"_key": 1457, "iconFile": "res:/ui/texture/corps/41_128_4.png"}
319	1458	{"_key": 1458, "iconFile": "res:/ui/texture/corps/43_128_4.png"}
320	1459	{"_key": 1459, "iconFile": "res:/ui/texture/icons/25_64_5.png"}
321	1460	{"_key": 1460, "iconFile": "res:/ui/texture/icons/25_64_6.png"}
322	1461	{"_key": 1461, "iconFile": "res:/ui/texture/icons/25_64_7.png"}
323	1462	{"_key": 1462, "iconFile": "res:/ui/texture/icons/25_64_8.png"}
324	1463	{"_key": 1463, "iconFile": "res:/ui/texture/icons/25_64_9.png"}
325	1464	{"_key": 1464, "iconFile": "res:/ui/texture/icons/25_64_10.png"}
326	1465	{"_key": 1465, "iconFile": "res:/ui/texture/corps/7_128_4.png"}
327	1466	{"_key": 1466, "iconFile": "res:/ui/texture/corps/41_128_3.png"}
328	1467	{"_key": 1467, "iconFile": "res:/ui/texture/corps/22_128_2.png"}
329	1468	{"_key": 1468, "iconFile": "res:/ui/texture/corps/22_128_1.png"}
330	1469	{"_key": 1469, "iconFile": "res:/ui/texture/corps/23_128_1.png"}
331	1470	{"_key": 1470, "iconFile": "res:/ui/texture/corps/22_128_4.png"}
332	1471	{"_key": 1471, "iconFile": "res:/ui/texture/corps/21_128_2.png"}
333	1472	{"_key": 1472, "iconFile": "res:/ui/texture/corps/23_128_2.png"}
334	1473	{"_key": 1473, "iconFile": "res:/ui/texture/corps/21_128_3.png"}
335	1474	{"_key": 1474, "iconFile": "res:/ui/texture/corps/23_128_3.png"}
336	1475	{"_key": 1475, "iconFile": "res:/ui/texture/corps/21_128_4.png"}
337	1476	{"_key": 1476, "iconFile": "res:/ui/texture/corps/22_128_3.png"}
338	1477	{"_key": 1477, "iconFile": "res:/ui/texture/corps/23_128_4.png"}
339	1478	{"_key": 1478, "iconFile": "res:/ui/texture/corps/21_128_1.png"}
340	1479	{"_key": 1479, "iconFile": "res:/ui/texture/corps/14_128_3.png"}
341	1480	{"_key": 1480, "iconFile": "res:/ui/texture/corps/15_128_2.png"}
342	1481	{"_key": 1481, "iconFile": "res:/ui/texture/corps/14_128_2.png"}
343	1482	{"_key": 1482, "iconFile": "res:/ui/texture/corps/19_128_4.png"}
344	1483	{"_key": 1483, "iconFile": "res:/ui/texture/corps/16_128_1.png"}
345	1484	{"_key": 1484, "iconFile": "res:/ui/texture/corps/18_128_3.png"}
346	1485	{"_key": 1485, "iconFile": "res:/ui/texture/corps/17_128_2.png"}
347	1486	{"_key": 1486, "iconFile": "res:/ui/texture/corps/19_128_1.png"}
348	1487	{"_key": 1487, "iconFile": "res:/ui/texture/corps/17_128_4.png"}
349	1488	{"_key": 1488, "iconFile": "res:/ui/texture/corps/16_128_2.png"}
350	1489	{"_key": 1489, "iconFile": "res:/ui/texture/corps/13_128_2.png"}
351	1490	{"_key": 1490, "iconFile": "res:/ui/texture/corps/15_128_4.png"}
352	1491	{"_key": 1491, "iconFile": "res:/ui/texture/corps/17_128_3.png"}
353	1492	{"_key": 1492, "iconFile": "res:/ui/texture/corps/13_128_3.png"}
354	1494	{"_key": 1494, "iconFile": "res:/ui/texture/corps/18_128_4.png"}
355	1495	{"_key": 1495, "iconFile": "res:/ui/texture/corps/14_128_4.png"}
356	1496	{"_key": 1496, "iconFile": "res:/ui/texture/corps/17_128_1.png"}
357	1497	{"_key": 1497, "iconFile": "res:/ui/texture/corps/18_128_2.png"}
358	1498	{"_key": 1498, "iconFile": "res:/ui/texture/corps/16_128_3.png"}
359	1499	{"_key": 1499, "iconFile": "res:/ui/texture/corps/15_128_1.png"}
360	1500	{"_key": 1500, "iconFile": "res:/ui/texture/corps/16_128_4.png"}
361	1501	{"_key": 1501, "iconFile": "res:/ui/texture/corps/18_128_1.png"}
362	1502	{"_key": 1502, "iconFile": "res:/ui/texture/corps/12_128_1.png"}
363	1503	{"_key": 1503, "iconFile": "res:/ui/texture/corps/13_128_1.png"}
364	1504	{"_key": 1504, "iconFile": "res:/ui/texture/corps/12_128_3.png"}
365	1505	{"_key": 1505, "iconFile": "res:/ui/texture/corps/12_128_2.png"}
366	1506	{"_key": 1506, "iconFile": "res:/ui/texture/corps/12_128_4.png"}
367	1507	{"_key": 1507, "iconFile": "res:/ui/texture/corps/15_128_3.png"}
368	1508	{"_key": 1508, "iconFile": "res:/ui/texture/corps/13_128_4.png"}
369	1509	{"_key": 1509, "iconFile": "res:/ui/texture/corps/19_128_2.png"}
370	1510	{"_key": 1510, "iconFile": "res:/ui/texture/corps/33_128_1.png"}
371	1511	{"_key": 1511, "iconFile": "res:/ui/texture/corps/33_128_3.png"}
372	1512	{"_key": 1512, "iconFile": "res:/ui/texture/corps/26_128_1.png"}
373	1513	{"_key": 1513, "iconFile": "res:/ui/texture/corps/31_128_3.png"}
374	1514	{"_key": 1514, "iconFile": "res:/ui/texture/corps/28_128_2.png"}
375	1515	{"_key": 1515, "iconFile": "res:/ui/texture/corps/27_128_3.png"}
376	1516	{"_key": 1516, "iconFile": "res:/ui/texture/corps/34_128_3.png"}
377	1517	{"_key": 1517, "iconFile": "res:/ui/texture/corps/32_128_3.png"}
378	1518	{"_key": 1518, "iconFile": "res:/ui/texture/corps/29_128_4.png"}
379	1519	{"_key": 1519, "iconFile": "res:/ui/texture/corps/25_128_4.png"}
380	1520	{"_key": 1520, "iconFile": "res:/ui/texture/corps/25_128_2.png"}
381	1521	{"_key": 1521, "iconFile": "res:/ui/texture/corps/38_128_2.png"}
382	1522	{"_key": 1522, "iconFile": "res:/ui/texture/corps/25_128_3.png"}
383	1523	{"_key": 1523, "iconFile": "res:/ui/texture/corps/31_128_2.png"}
384	1524	{"_key": 1524, "iconFile": "res:/ui/texture/corps/32_128_1.png"}
385	1525	{"_key": 1525, "iconFile": "res:/ui/texture/corps/32_128_4.png"}
386	1526	{"_key": 1526, "iconFile": "res:/ui/texture/corps/33_128_2.png"}
387	1527	{"_key": 1527, "iconFile": "res:/ui/texture/corps/30_128_1.png"}
388	1528	{"_key": 1528, "iconFile": "res:/ui/texture/corps/31_128_4.png"}
389	1529	{"_key": 1529, "iconFile": "res:/ui/texture/corps/32_128_2.png"}
390	1530	{"_key": 1530, "iconFile": "res:/ui/texture/corps/25_128_1.png"}
391	1532	{"_key": 1532, "iconFile": "res:/ui/texture/corps/30_128_2.png"}
392	1533	{"_key": 1533, "iconFile": "res:/ui/texture/corps/30_128_4.png"}
393	1534	{"_key": 1534, "iconFile": "res:/ui/texture/corps/29_128_1.png"}
394	1535	{"_key": 1535, "iconFile": "res:/ui/texture/corps/29_128_2.png"}
395	1536	{"_key": 1536, "iconFile": "res:/ui/texture/corps/29_128_3.png"}
396	1537	{"_key": 1537, "iconFile": "res:/ui/texture/corps/10_128_3.png"}
397	1538	{"_key": 1538, "iconFile": "res:/ui/texture/corps/31_128_1.png"}
398	1539	{"_key": 1539, "iconFile": "res:/ui/texture/corps/35_128_2.png"}
399	1540	{"_key": 1540, "iconFile": "res:/ui/texture/corps/24_128_3.png"}
400	1541	{"_key": 1541, "iconFile": "res:/ui/texture/corps/26_128_3.png"}
401	1542	{"_key": 1542, "iconFile": "res:/ui/texture/corps/35_128_3.png"}
402	1543	{"_key": 1543, "iconFile": "res:/ui/texture/corps/28_128_3.png"}
403	1544	{"_key": 1544, "iconFile": "res:/ui/texture/corps/34_128_2.png"}
404	1545	{"_key": 1545, "iconFile": "res:/ui/texture/corps/27_128_4.png"}
405	1546	{"_key": 1546, "iconFile": "res:/ui/texture/corps/14_128_1.png"}
406	1547	{"_key": 1547, "iconFile": "res:/ui/texture/corps/36_128_2.png"}
407	1548	{"_key": 1548, "iconFile": "res:/ui/texture/corps/3_128_4.png"}
408	1549	{"_key": 1549, "iconFile": "res:/ui/texture/corps/24_128_1.png"}
409	1550	{"_key": 1550, "iconFile": "res:/ui/texture/corps/19_128_3.png"}
410	1551	{"_key": 1551, "iconFile": "res:/ui/texture/corps/38_128_1.png"}
411	1552	{"_key": 1552, "iconFile": "res:/ui/texture/corps/24_128_2.png"}
412	1553	{"_key": 1553, "iconFile": "res:/ui/texture/corps/4_128_1.png"}
413	1554	{"_key": 1554, "iconFile": "res:/ui/texture/corps/24_128_4.png"}
414	1555	{"_key": 1555, "iconFile": "res:/ui/texture/corps/35_128_4.png"}
415	1556	{"_key": 1556, "iconFile": "res:/ui/texture/corps/40_128_2.png"}
416	1557	{"_key": 1557, "iconFile": "res:/ui/texture/corps/28_128_4.png"}
417	1558	{"_key": 1558, "iconFile": "res:/ui/texture/corps/40_128_4.png"}
418	1559	{"_key": 1559, "iconFile": "res:/ui/texture/corps/26_128_4.png"}
419	1560	{"_key": 1560, "iconFile": "res:/ui/texture/corps/26_128_2.png"}
420	1561	{"_key": 1561, "iconFile": "res:/ui/texture/corps/27_128_1.png"}
421	1562	{"_key": 1562, "iconFile": "res:/ui/texture/corps/28_128_1.png"}
422	1563	{"_key": 1563, "iconFile": "res:/ui/texture/corps/27_128_2.png"}
423	1564	{"_key": 1564, "iconFile": "res:/ui/texture/corps/3_128_2.png"}
424	1565	{"_key": 1565, "iconFile": "res:/ui/texture/corps/40_128_3.png"}
425	1566	{"_key": 1566, "iconFile": "res:/ui/texture/corps/39_128_3.png"}
426	1567	{"_key": 1567, "iconFile": "res:/ui/texture/corps/11_128_4.png"}
427	1568	{"_key": 1568, "iconFile": "res:/ui/texture/corps/11_128_2.png"}
428	1569	{"_key": 1569, "iconFile": "res:/ui/texture/corps/11_128_3.png"}
429	1570	{"_key": 1570, "iconFile": "res:/ui/texture/corps/35_128_1.png"}
430	1571	{"_key": 1571, "iconFile": "res:/ui/texture/corps/41_128_1.png"}
431	1572	{"_key": 1572, "iconFile": "res:/ui/texture/corps/11_128_1.png"}
432	1573	{"_key": 1573, "iconFile": "res:/ui/texture/corps/33_128_4.png"}
433	1574	{"_key": 1574, "iconFile": "res:/ui/texture/corps/40_128_1.png"}
434	1575	{"_key": 1575, "iconFile": "res:/ui/texture/corps/36_128_3.png"}
435	1576	{"_key": 1576, "iconFile": "res:/ui/texture/corps/36_128_1.png"}
436	1577	{"_key": 1577, "iconFile": "res:/ui/texture/corps/34_128_4.png"}
437	1578	{"_key": 1578, "iconFile": "res:/ui/texture/corps/34_128_1.png"}
438	1579	{"_key": 1579, "iconFile": "res:/ui/texture/corps/36_128_4.png"}
439	1580	{"_key": 1580, "iconFile": "res:/ui/texture/corps/41_128_2.png"}
440	1581	{"_key": 1581, "iconFile": "res:/ui/texture/corps/1_128_3.png"}
441	1582	{"_key": 1582, "iconFile": "res:/ui/texture/corps/8_128_1.png"}
442	1583	{"_key": 1583, "iconFile": "res:/ui/texture/corps/1_128_4.png"}
443	1584	{"_key": 1584, "iconFile": "res:/ui/texture/corps/4_128_4.png"}
444	1585	{"_key": 1585, "iconFile": "res:/ui/texture/corps/38_128_3.png"}
445	1586	{"_key": 1586, "iconFile": "res:/ui/texture/corps/39_128_2.png"}
446	1587	{"_key": 1587, "iconFile": "res:/ui/texture/corps/3_128_3.png"}
447	1588	{"_key": 1588, "iconFile": "res:/ui/texture/corps/3_128_1.png"}
448	1589	{"_key": 1589, "iconFile": "res:/ui/texture/corps/6_128_2.png"}
449	1590	{"_key": 1590, "iconFile": "res:/ui/texture/corps/10_128_4.png"}
450	1591	{"_key": 1591, "iconFile": "res:/ui/texture/corps/9_128_4.png"}
451	1592	{"_key": 1592, "iconFile": "res:/ui/texture/corps/7_128_2.png"}
452	1593	{"_key": 1593, "iconFile": "res:/ui/texture/corps/1_128_1.png"}
453	1594	{"_key": 1594, "iconFile": "res:/ui/texture/corps/5_128_4.png"}
454	1595	{"_key": 1595, "iconFile": "res:/ui/texture/corps/2_128_4.png"}
455	1596	{"_key": 1596, "iconFile": "res:/ui/texture/corps/5_128_3.png"}
456	1597	{"_key": 1597, "iconFile": "res:/ui/texture/corps/6_128_1.png"}
457	1598	{"_key": 1598, "iconFile": "res:/ui/texture/corps/2_128_1.png"}
458	1599	{"_key": 1599, "iconFile": "res:/ui/texture/corps/2_128_3.png"}
459	1600	{"_key": 1600, "iconFile": "res:/ui/texture/corps/5_128_2.png"}
460	1601	{"_key": 1601, "iconFile": "res:/ui/texture/corps/9_128_1.png"}
461	1602	{"_key": 1602, "iconFile": "res:/ui/texture/corps/7_128_3.png"}
462	1604	{"_key": 1604, "iconFile": "res:/ui/texture/corps/8_128_4.png"}
463	1605	{"_key": 1605, "iconFile": "res:/ui/texture/corps/9_128_2.png"}
464	1606	{"_key": 1606, "iconFile": "res:/ui/texture/corps/9_128_3.png"}
465	1607	{"_key": 1607, "iconFile": "res:/ui/texture/corps/4_128_2.png"}
466	1608	{"_key": 1608, "iconFile": "res:/ui/texture/corps/5_128_1.png"}
467	1609	{"_key": 1609, "iconFile": "res:/ui/texture/corps/8_128_2.png"}
468	1610	{"_key": 1610, "iconFile": "res:/ui/texture/corps/7_128_1.png"}
469	1611	{"_key": 1611, "iconFile": "res:/ui/texture/corps/8_128_3.png"}
470	1612	{"_key": 1612, "iconFile": "res:/ui/texture/corps/4_128_3.png"}
471	1613	{"_key": 1613, "iconFile": "res:/ui/texture/corps/37_128_3.png"}
472	1614	{"_key": 1614, "iconFile": "res:/ui/texture/corps/1_128_2.png"}
473	1615	{"_key": 1615, "iconFile": "res:/ui/texture/corps/2_128_2.png"}
474	1616	{"_key": 1616, "iconFile": "res:/ui/texture/corps/6_128_3.png"}
475	1617	{"_key": 1617, "iconFile": "res:/ui/texture/corps/37_128_2.png"}
476	1618	{"_key": 1618, "iconFile": "res:/ui/texture/corps/37_128_1.png"}
477	1619	{"_key": 1619, "iconFile": "res:/ui/texture/corps/38_128_4.png"}
478	1620	{"_key": 1620, "iconFile": "res:/ui/texture/corps/6_128_4.png"}
479	1621	{"_key": 1621, "iconFile": "res:/ui/texture/corps/37_128_4.png"}
480	1624	{"_key": 1624, "iconFile": "res:/ui/texture/corps/20_128_3.png"}
481	1625	{"_key": 1625, "iconFile": "res:/ui/texture/corps/20_128_1.png"}
482	1626	{"_key": 1626, "iconFile": "res:/ui/texture/corps/20_128_4.png"}
483	1627	{"_key": 1627, "iconFile": "res:/ui/texture/corps/20_128_2.png"}
484	1628	{"_key": 1628, "iconFile": "res:/ui/texture/icons/28_128_1.png"}
485	1629	{"_key": 1629, "iconFile": "res:/ui/texture/icons/28_128_2.png"}
486	1630	{"_key": 1630, "iconFile": "res:/ui/texture/icons/28_128_3.png"}
487	1631	{"_key": 1631, "iconFile": "res:/ui/texture/icons/28_128_4.png"}
488	1632	{"_key": 1632, "iconFile": "res:/ui/texture/icons/29_128_1.png"}
489	1633	{"_key": 1633, "iconFile": "res:/ui/texture/icons/29_128_2.png"}
490	1634	{"_key": 1634, "iconFile": "res:/ui/texture/icons/29_128_3.png"}
491	1635	{"_key": 1635, "iconFile": "res:/ui/texture/icons/29_128_4.png"}
492	1639	{"_key": 1639, "iconFile": "res:/ui/texture/icons/5_64_7.png"}
493	1640	{"_key": 1640, "iconFile": "res:/ui/texture/icons/5_64_14.png"}
494	1641	{"_key": 1641, "iconFile": "res:/ui/texture/icons/30_64_1.png"}
495	1642	{"_key": 1642, "iconFile": "res:/ui/texture/icons/30_64_2.png"}
496	1643	{"_key": 1643, "iconFile": "res:/ui/texture/icons/30_64_3.png"}
497	1644	{"_key": 1644, "iconFile": "res:/ui/texture/icons/30_64_4.png"}
498	1645	{"_key": 1645, "iconFile": "res:/ui/texture/icons/31_64_3.png"}
499	1647	{"_key": 1647, "iconFile": "res:/ui/texture/icons/30_64_5.png"}
500	1648	{"_key": 1648, "iconFile": "res:/ui/texture/icons/30_64_8.png"}
501	1649	{"_key": 1649, "iconFile": "res:/ui/texture/icons/30_64_7.png"}
502	1650	{"_key": 1650, "iconFile": "res:/ui/texture/icons/30_64_13.png"}
503	1651	{"_key": 1651, "iconFile": "res:/ui/texture/icons/30_64_12.png"}
504	1652	{"_key": 1652, "iconFile": "res:/ui/texture/icons/31_64_5.png"}
505	1653	{"_key": 1653, "iconFile": "res:/ui/texture/icons/31_64_7.png"}
506	1654	{"_key": 1654, "iconFile": "res:/ui/texture/icons/30_64_14.png"}
507	1655	{"_key": 1655, "iconFile": "res:/ui/texture/icons/30_64_9.png"}
508	1656	{"_key": 1656, "iconFile": "res:/ui/texture/icons/31_64_6.png"}
509	1657	{"_key": 1657, "iconFile": "res:/ui/texture/icons/31_64_8.png"}
510	1658	{"_key": 1658, "iconFile": "res:/ui/texture/icons/30_64_11.png"}
511	1659	{"_key": 1659, "iconFile": "res:/ui/texture/icons/30_64_10.png"}
512	1660	{"_key": 1660, "iconFile": "res:/ui/texture/icons/31_64_2.png"}
513	1661	{"_key": 1661, "iconFile": "res:/ui/texture/icons/31_64_4.png"}
514	1662	{"_key": 1662, "iconFile": "res:/ui/texture/icons/31_64_1.png"}
515	1663	{"_key": 1663, "iconFile": "res:/ui/texture/icons/30_64_15.png"}
516	1664	{"_key": 1664, "iconFile": "res:/ui/texture/icons/30_64_16.png"}
517	1665	{"_key": 1665, "iconFile": "res:/ui/texture/icons/5_64_6.png"}
518	1666	{"_key": 1666, "iconFile": "res:/ui/texture/icons/5_64_2.png"}
519	1667	{"_key": 1667, "iconFile": "res:/ui/texture/icons/4_64_5.png"}
520	1668	{"_key": 1668, "iconFile": "res:/ui/texture/icons/1_64_5.png"}
521	1700	{"_key": 1700, "iconFile": "res:/ui/texture/icons/9_64_1.png"}
522	1720	{"_key": 1720, "iconFile": "res:/ui/texture/icons/27_64_4.png"}
523	1721	{"_key": 1721, "iconFile": "res:/ui/texture/icons/34_64_1.png"}
524	1722	{"_key": 1722, "iconFile": "res:/ui/texture/icons/34_64_2.png"}
525	1723	{"_key": 1723, "iconFile": "res:/ui/texture/icons/27_64_9.png"}
526	1724	{"_key": 1724, "iconFile": "res:/ui/texture/icons/33_128_2.png"}
527	2028	{"_key": 2028, "iconFile": "res:/ui/texture/icons/22_32_25.png"}
528	2029	{"_key": 2029, "iconFile": "res:/ui/texture/icons/22_32_26.png"}
529	2030	{"_key": 2030, "iconFile": "res:/ui/texture/icons/22_32_27.png"}
530	2031	{"_key": 2031, "iconFile": "res:/ui/texture/icons/22_32_28.png"}
531	2036	{"_key": 2036, "iconFile": "res:/ui/texture/icons/33_128_4.png"}
532	2037	{"_key": 2037, "iconFile": "res:/ui/texture/icons/34_64_5.png"}
533	2038	{"_key": 2038, "iconFile": "res:/ui/texture/icons/34_64_6.png"}
534	2039	{"_key": 2039, "iconFile": "res:/ui/texture/icons/34_64_7.png"}
535	2040	{"_key": 2040, "iconFile": "res:/ui/texture/icons/34_64_8.png"}
536	2041	{"_key": 2041, "iconFile": "res:/ui/texture/icons/34_64_9.png"}
537	2042	{"_key": 2042, "iconFile": "res:/ui/texture/icons/34_64_10.png"}
538	2052	{"_key": 2052, "iconFile": "res:/ui/texture/icons/34_64_11.png"}
539	2053	{"_key": 2053, "iconFile": "res:/ui/texture/icons/34_64_12.png"}
540	2054	{"_key": 2054, "iconFile": "res:/ui/texture/icons/34_64_15.png"}
541	2055	{"_key": 2055, "iconFile": "res:/ui/texture/icons/31_64_9.png"}
542	2056	{"_key": 2056, "iconFile": "res:/ui/texture/icons/31_64_10.png"}
543	2057	{"_key": 2057, "iconFile": "res:/ui/texture/icons/31_64_11.png"}
544	2058	{"_key": 2058, "iconFile": "res:/ui/texture/icons/31_64_12.png"}
545	2059	{"_key": 2059, "iconFile": "res:/ui/texture/icons/31_64_13.png"}
546	2060	{"_key": 2060, "iconFile": "res:/ui/texture/icons/31_64_14.png"}
547	2061	{"_key": 2061, "iconFile": "res:/ui/texture/icons/31_64_15.png"}
548	2062	{"_key": 2062, "iconFile": "res:/ui/texture/icons/31_64_16.png"}
549	2066	{"_key": 2066, "iconFile": "res:/ui/texture/icons/34_64_16.png"}
550	2070	{"_key": 2070, "iconFile": "res:/Texture/Landmark/A33colonialruins.jpg"}
551	2071	{"_key": 2071, "iconFile": "res:/Texture/Landmark/amarr.jpg"}
552	2072	{"_key": 2072, "iconFile": "res:/Texture/Landmark/caldari.jpg"}
553	2073	{"_key": 2073, "iconFile": "res:/Texture/Landmark/cityofgod.jpg"}
554	2074	{"_key": 2074, "iconFile": "res:/Texture/Landmark/Curse.jpg"}
555	2075	{"_key": 2075, "iconFile": "res:/Texture/Landmark/emperor.jpg"}
556	2076	{"_key": 2076, "iconFile": "res:/Texture/Landmark/galente.jpg"}
557	2077	{"_key": 2077, "iconFile": "res:/Texture/Landmark/ginnungagap.jpg"}
558	2078	{"_key": 2078, "iconFile": "res:/Texture/Landmark/golgothanfields.jpg"}
559	2079	{"_key": 2079, "iconFile": "res:/Texture/Landmark/jove.jpg"}
560	2080	{"_key": 2080, "iconFile": "res:/Texture/Landmark/khanidkingdom.jpg"}
561	2081	{"_key": 2081, "iconFile": "res:/Texture/Landmark/minmatar.jpg"}
562	2082	{"_key": 2082, "iconFile": "res:/Texture/Landmark/myridianstrip.jpg"}
563	2083	{"_key": 2083, "iconFile": "res:/Texture/Landmark/outerring.jpg"}
564	2084	{"_key": 2084, "iconFile": "res:/Texture/Landmark/pointofnoreturn.jpg"}
565	2085	{"_key": 2085, "iconFile": "res:/Texture/Landmark/serpentscoil.jpg"}
566	2086	{"_key": 2086, "iconFile": "res:/Texture/Landmark/stain.jpg"}
567	2087	{"_key": 2087, "iconFile": "res:/Texture/Landmark/thesyndicate.jpg"}
568	2088	{"_key": 2088, "iconFile": "res:/Texture/Landmark/traumark.jpg"}
569	2089	{"_key": 2089, "iconFile": "res:/Texture/Landmark/venal.jpg"}
570	2093	{"_key": 2093, "iconFile": "res:/ui/texture/icons/35_64_5.png"}
571	2094	{"_key": 2094, "iconFile": "res:/ui/texture/icons/35_64_6.png"}
572	2095	{"_key": 2095, "iconFile": "res:/ui/texture/icons/35_64_7.png"}
573	2096	{"_key": 2096, "iconFile": "res:/ui/texture/icons/35_64_9.png"}
574	2100	{"_key": 2100, "iconFile": "res:/ui/texture/icons/35_64_8.png"}
575	2101	{"_key": 2101, "iconFile": "res:/ui/texture/icons/35_64_1.png"}
576	2102	{"_key": 2102, "iconFile": "res:/ui/texture/icons/35_64_11.png"}
577	2103	{"_key": 2103, "iconFile": "res:/ui/texture/icons/35_64_2.png"}
578	2104	{"_key": 2104, "iconFile": "res:/ui/texture/icons/35_64_15.png"}
579	2105	{"_key": 2105, "iconFile": "res:/ui/texture/icons/35_64_14.png"}
580	2106	{"_key": 2106, "iconFile": "res:/ui/texture/icons/35_64_12.png"}
581	2176	{"_key": 2176, "iconFile": "res:/ui/texture/icons/35_64_4.png"}
582	2177	{"_key": 2177, "iconFile": "res:/ui/texture/icons/37_64_1.png"}
583	2178	{"_key": 2178, "iconFile": "res:/ui/texture/icons/37_64_2.png"}
584	2179	{"_key": 2179, "iconFile": "res:/ui/texture/icons/37_64_3.png"}
585	2180	{"_key": 2180, "iconFile": "res:/ui/texture/icons/37_64_4.png"}
586	2181	{"_key": 2181, "iconFile": "res:/ui/texture/icons/37_64_5.png"}
587	2182	{"_key": 2182, "iconFile": "res:/ui/texture/icons/37_64_6.png"}
588	2183	{"_key": 2183, "iconFile": "res:/ui/texture/icons/37_64_7.png"}
589	2184	{"_key": 2184, "iconFile": "res:/ui/texture/icons/37_64_8.png"}
590	2185	{"_key": 2185, "iconFile": "res:/ui/texture/icons/37_64_9.png"}
591	2186	{"_key": 2186, "iconFile": "res:/ui/texture/icons/37_64_10.png"}
592	2187	{"_key": 2187, "iconFile": "res:/ui/texture/icons/37_64_11.png"}
593	2188	{"_key": 2188, "iconFile": "res:/ui/texture/icons/37_64_12.png"}
594	2189	{"_key": 2189, "iconFile": "res:/ui/texture/icons/37_64_13.png"}
595	2190	{"_key": 2190, "iconFile": "res:/ui/texture/icons/37_64_14.png"}
596	2191	{"_key": 2191, "iconFile": "res:/ui/texture/icons/37_64_15.png"}
597	2192	{"_key": 2192, "iconFile": "res:/ui/texture/icons/37_64_16.png"}
598	2193	{"_key": 2193, "iconFile": "res:/ui/texture/icons/39_64_1.png"}
599	2194	{"_key": 2194, "iconFile": "res:/ui/texture/icons/39_64_2.png"}
600	2195	{"_key": 2195, "iconFile": "res:/ui/texture/icons/39_64_3.png"}
601	2196	{"_key": 2196, "iconFile": "res:/ui/texture/icons/39_64_4.png"}
602	2197	{"_key": 2197, "iconFile": "res:/ui/texture/icons/39_64_5.png"}
603	2198	{"_key": 2198, "iconFile": "res:/ui/texture/icons/39_64_6.png"}
604	2199	{"_key": 2199, "iconFile": "res:/ui/texture/icons/39_64_7.png"}
605	2200	{"_key": 2200, "iconFile": "res:/ui/texture/icons/39_64_8.png"}
606	2201	{"_key": 2201, "iconFile": "res:/ui/texture/icons/39_64_9.png"}
607	2202	{"_key": 2202, "iconFile": "res:/ui/texture/icons/39_64_10.png"}
608	2203	{"_key": 2203, "iconFile": "res:/ui/texture/icons/39_64_11.png"}
609	2204	{"_key": 2204, "iconFile": "res:/ui/texture/icons/39_64_12.png"}
610	2205	{"_key": 2205, "iconFile": "res:/ui/texture/icons/39_64_13.png"}
611	2206	{"_key": 2206, "iconFile": "res:/ui/texture/icons/39_64_14.png"}
612	2207	{"_key": 2207, "iconFile": "res:/ui/texture/icons/39_64_15.png"}
613	2208	{"_key": 2208, "iconFile": "res:/ui/texture/icons/39_64_16.png"}
614	2209	{"_key": 2209, "iconFile": "res:/ui/texture/icons/40_64_1.png"}
615	2210	{"_key": 2210, "iconFile": "res:/ui/texture/icons/40_64_2.png"}
616	2211	{"_key": 2211, "iconFile": "res:/ui/texture/icons/40_64_3.png"}
617	2212	{"_key": 2212, "iconFile": "res:/ui/texture/icons/40_64_4.png"}
618	2213	{"_key": 2213, "iconFile": "res:/ui/texture/icons/40_64_5.png"}
619	2214	{"_key": 2214, "iconFile": "res:/ui/texture/icons/40_64_6.png"}
620	2215	{"_key": 2215, "iconFile": "res:/ui/texture/icons/40_64_7.png"}
621	2216	{"_key": 2216, "iconFile": "res:/ui/texture/icons/40_64_8.png"}
622	2217	{"_key": 2217, "iconFile": "res:/ui/texture/icons/40_64_9.png"}
623	2218	{"_key": 2218, "iconFile": "res:/ui/texture/icons/40_64_10.png"}
624	2219	{"_key": 2219, "iconFile": "res:/ui/texture/icons/40_64_11.png"}
625	2220	{"_key": 2220, "iconFile": "res:/ui/texture/icons/40_64_12.png"}
626	2221	{"_key": 2221, "iconFile": "res:/ui/texture/icons/40_64_13.png"}
627	2222	{"_key": 2222, "iconFile": "res:/ui/texture/icons/40_64_14.png"}
628	2223	{"_key": 2223, "iconFile": "res:/ui/texture/icons/40_64_15.png"}
629	2224	{"_key": 2224, "iconFile": "res:/ui/texture/icons/40_64_16.png"}
630	2225	{"_key": 2225, "iconFile": "res:/ui/texture/icons/41_64_1.png"}
631	2226	{"_key": 2226, "iconFile": "res:/ui/texture/icons/41_64_2.png"}
632	2227	{"_key": 2227, "iconFile": "res:/ui/texture/icons/41_64_5.png"}
633	2228	{"_key": 2228, "iconFile": "res:/ui/texture/icons/41_64_7.png"}
634	2229	{"_key": 2229, "iconFile": "res:/ui/texture/icons/41_64_9.png"}
635	2230	{"_key": 2230, "iconFile": "res:/ui/texture/icons/41_64_10.png"}
636	2231	{"_key": 2231, "iconFile": "res:/ui/texture/icons/41_64_11.png"}
637	2232	{"_key": 2232, "iconFile": "res:/ui/texture/icons/41_64_12.png"}
638	2233	{"_key": 2233, "iconFile": "res:/ui/texture/icons/41_64_6.png"}
639	2234	{"_key": 2234, "iconFile": "res:/ui/texture/icons/41_64_8.png"}
640	2243	{"_key": 2243, "iconFile": "res:/ui/texture/icons/27_64_13.png"}
641	2244	{"_key": 2244, "iconFile": "res:/ui/texture/icons/41_64_3.png"}
642	2302	{"_key": 2302, "iconFile": "res:/ui/texture/icons/25_64_15.png"}
643	2304	{"_key": 2304, "iconFile": "res:/ui/texture/icons/41_64_4.png"}
644	2309	{"_key": 2309, "iconFile": "res:/ui/texture/icons/36_64_15.png"}
645	2310	{"_key": 2310, "iconFile": "res:/ui/texture/icons/41_64_15.png"}
646	2311	{"_key": 2311, "iconFile": "res:/ui/texture/icons/41_64_16.png"}
647	2312	{"_key": 2312, "iconFile": "res:/ui/texture/icons/42_64_1.png"}
648	2313	{"_key": 2313, "iconFile": "res:/ui/texture/icons/42_64_2.png"}
649	2314	{"_key": 2314, "iconFile": "res:/ui/texture/icons/42_64_3.png"}
650	2315	{"_key": 2315, "iconFile": "res:/ui/texture/icons/42_64_4.png"}
651	2316	{"_key": 2316, "iconFile": "res:/ui/texture/icons/42_64_5.png"}
652	2317	{"_key": 2317, "iconFile": "res:/ui/texture/icons/42_64_6.png"}
653	2318	{"_key": 2318, "iconFile": "res:/ui/texture/icons/42_64_7.png"}
654	2319	{"_key": 2319, "iconFile": "res:/ui/texture/icons/42_64_8.png"}
655	2320	{"_key": 2320, "iconFile": "res:/ui/texture/icons/42_64_9.png"}
656	2321	{"_key": 2321, "iconFile": "res:/ui/texture/icons/42_64_10.png"}
657	2322	{"_key": 2322, "iconFile": "res:/ui/texture/icons/42_64_11.png"}
658	2323	{"_key": 2323, "iconFile": "res:/ui/texture/icons/42_64_12.png"}
659	2324	{"_key": 2324, "iconFile": "res:/ui/texture/icons/42_64_13.png"}
660	2325	{"_key": 2325, "iconFile": "res:/ui/texture/icons/42_64_14.png"}
661	2326	{"_key": 2326, "iconFile": "res:/ui/texture/icons/42_64_15.png"}
662	2327	{"_key": 2327, "iconFile": "res:/ui/texture/icons/42_64_16.png"}
663	2328	{"_key": 2328, "iconFile": "res:/ui/texture/icons/43_64_1.png"}
664	2329	{"_key": 2329, "iconFile": "res:/ui/texture/icons/43_64_2.png"}
665	2330	{"_key": 2330, "iconFile": "res:/ui/texture/icons/43_64_3.png"}
666	2331	{"_key": 2331, "iconFile": "res:/ui/texture/icons/43_64_4.png"}
667	2332	{"_key": 2332, "iconFile": "res:/ui/texture/icons/43_64_5.png"}
668	2333	{"_key": 2333, "iconFile": "res:/ui/texture/icons/43_64_6.png"}
669	2334	{"_key": 2334, "iconFile": "res:/ui/texture/icons/43_64_7.png"}
670	2335	{"_key": 2335, "iconFile": "res:/ui/texture/icons/43_64_8.png"}
671	2336	{"_key": 2336, "iconFile": "res:/ui/texture/icons/43_64_9.png"}
672	2337	{"_key": 2337, "iconFile": "res:/ui/texture/icons/43_64_10.png"}
673	2338	{"_key": 2338, "iconFile": "res:/ui/texture/icons/43_64_11.png"}
674	2339	{"_key": 2339, "iconFile": "res:/ui/texture/icons/43_64_12.png"}
675	2340	{"_key": 2340, "iconFile": "res:/ui/texture/icons/43_64_13.png"}
676	2355	{"_key": 2355, "iconFile": "res:/ui/texture/icons/7_64_4.png"}
677	2512	{"_key": 2512, "iconFile": "res:/ui/texture/icons/7_64_12.png"}
678	2526	{"_key": 2526, "iconFile": "res:/ui/texture/icons/49_64_6.png"}
679	2527	{"_key": 2527, "iconFile": "res:/ui/texture/icons/49_64_5.png"}
680	2528	{"_key": 2528, "iconFile": "res:/ui/texture/icons/45_64_9.png"}
681	2529	{"_key": 2529, "iconFile": "res:/ui/texture/icons/45_64_10.png"}
682	2530	{"_key": 2530, "iconFile": "res:/ui/texture/icons/45_64_11.png"}
683	2531	{"_key": 2531, "iconFile": "res:/ui/texture/icons/45_64_12.png"}
684	2532	{"_key": 2532, "iconFile": "res:/ui/texture/icons/45_64_13.png"}
685	2533	{"_key": 2533, "iconFile": "res:/ui/texture/icons/45_64_14.png"}
686	2534	{"_key": 2534, "iconFile": "res:/ui/texture/icons/45_64_15.png"}
687	2535	{"_key": 2535, "iconFile": "res:/ui/texture/icons/45_64_16.png"}
688	2536	{"_key": 2536, "iconFile": "res:/ui/texture/icons/46_64_1.png"}
689	2537	{"_key": 2537, "iconFile": "res:/ui/texture/icons/46_64_2.png"}
690	2538	{"_key": 2538, "iconFile": "res:/ui/texture/icons/46_64_3.png"}
691	2539	{"_key": 2539, "iconFile": "res:/ui/texture/icons/46_64_4.png"}
692	2540	{"_key": 2540, "iconFile": "res:/ui/texture/icons/46_64_5.png"}
693	2541	{"_key": 2541, "iconFile": "res:/ui/texture/icons/46_64_6.png"}
694	2542	{"_key": 2542, "iconFile": "res:/ui/texture/icons/46_64_7.png"}
695	2543	{"_key": 2543, "iconFile": "res:/ui/texture/icons/46_64_8.png"}
696	2544	{"_key": 2544, "iconFile": "res:/ui/texture/icons/46_64_9.png"}
697	2545	{"_key": 2545, "iconFile": "res:/ui/texture/icons/46_64_10.png"}
698	2546	{"_key": 2546, "iconFile": "res:/ui/texture/icons/46_64_11.png"}
699	2547	{"_key": 2547, "iconFile": "res:/ui/texture/icons/46_64_13.png"}
700	2548	{"_key": 2548, "iconFile": "res:/ui/texture/icons/46_64_14.png"}
701	2549	{"_key": 2549, "iconFile": "res:/ui/texture/icons/46_64_15.png"}
702	2550	{"_key": 2550, "iconFile": "res:/ui/texture/icons/46_64_16.png"}
703	2551	{"_key": 2551, "iconFile": "res:/ui/texture/icons/43_64_14.png"}
704	2552	{"_key": 2552, "iconFile": "res:/ui/texture/icons/43_64_15.png"}
705	2553	{"_key": 2553, "iconFile": "res:/ui/texture/icons/43_64_16.png"}
706	2554	{"_key": 2554, "iconFile": "res:/ui/texture/icons/51_64_5.png"}
707	2555	{"_key": 2555, "iconFile": "res:/ui/texture/icons/51_64_4.png"}
708	2556	{"_key": 2556, "iconFile": "res:/ui/texture/icons/51_64_2.png"}
709	2557	{"_key": 2557, "iconFile": "res:/ui/texture/icons/51_64_3.png"}
710	2558	{"_key": 2558, "iconFile": "res:/ui/texture/icons/51_64_6.png"}
711	2559	{"_key": 2559, "iconFile": "res:/ui/texture/icons/51_64_1.png"}
712	2560	{"_key": 2560, "iconFile": "res:/ui/texture/icons/51_64_9.png"}
713	2561	{"_key": 2561, "iconFile": "res:/ui/texture/icons/51_64_8.png"}
714	2562	{"_key": 2562, "iconFile": "res:/ui/texture/icons/12_64_3.png"}
715	2563	{"_key": 2563, "iconFile": "res:/ui/texture/icons/2_64_16.png"}
716	2567	{"_key": 2567, "iconFile": "res:/ui/texture/icons/47_64_1.png"}
717	2568	{"_key": 2568, "iconFile": "res:/ui/texture/icons/47_64_2.png"}
718	2569	{"_key": 2569, "iconFile": "res:/ui/texture/icons/47_64_3.png"}
719	2570	{"_key": 2570, "iconFile": "res:/ui/texture/icons/47_64_4.png"}
720	2571	{"_key": 2571, "iconFile": "res:/ui/texture/icons/47_64_5.png"}
721	2572	{"_key": 2572, "iconFile": "res:/ui/texture/icons/47_64_6.png"}
722	2573	{"_key": 2573, "iconFile": "res:/ui/texture/icons/47_64_7.png"}
723	2574	{"_key": 2574, "iconFile": "res:/ui/texture/icons/47_64_8.png"}
724	2575	{"_key": 2575, "iconFile": "res:/ui/texture/icons/47_64_9.png"}
725	2576	{"_key": 2576, "iconFile": "res:/ui/texture/icons/47_64_10.png"}
726	2577	{"_key": 2577, "iconFile": "res:/ui/texture/icons/47_64_11.png"}
727	2578	{"_key": 2578, "iconFile": "res:/ui/texture/icons/47_64_12.png"}
728	2579	{"_key": 2579, "iconFile": "res:/ui/texture/icons/47_64_13.png"}
729	2580	{"_key": 2580, "iconFile": "res:/ui/texture/icons/47_64_14.png"}
730	2581	{"_key": 2581, "iconFile": "res:/ui/texture/icons/47_64_15.png"}
731	2582	{"_key": 2582, "iconFile": "res:/ui/texture/icons/47_64_16.png"}
732	2645	{"_key": 2645, "iconFile": "res:/ui/texture/icons/48_64_14.png"}
733	2646	{"_key": 2646, "iconFile": "res:/ui/texture/icons/48_64_13.png"}
734	2647	{"_key": 2647, "iconFile": "res:/ui/texture/icons/48_64_12.png"}
735	2648	{"_key": 2648, "iconFile": "res:/ui/texture/icons/48_64_11.png"}
736	2649	{"_key": 2649, "iconFile": "res:/ui/texture/icons/48_64_10.png"}
737	2650	{"_key": 2650, "iconFile": "res:/ui/texture/icons/48_64_9.png"}
738	2651	{"_key": 2651, "iconFile": "res:/ui/texture/icons/48_64_8.png"}
739	2652	{"_key": 2652, "iconFile": "res:/ui/texture/icons/48_64_7.png"}
740	2653	{"_key": 2653, "iconFile": "res:/ui/texture/icons/48_64_6.png"}
741	2654	{"_key": 2654, "iconFile": "res:/ui/texture/icons/48_64_16.png"}
742	2655	{"_key": 2655, "iconFile": "res:/ui/texture/icons/48_64_5.png"}
743	2656	{"_key": 2656, "iconFile": "res:/ui/texture/icons/48_64_4.png"}
744	2657	{"_key": 2657, "iconFile": "res:/ui/texture/icons/48_64_3.png"}
745	2658	{"_key": 2658, "iconFile": "res:/ui/texture/icons/48_64_2.png"}
746	2659	{"_key": 2659, "iconFile": "res:/ui/texture/icons/48_64_15.png"}
747	2660	{"_key": 2660, "iconFile": "res:/ui/texture/icons/48_64_1.png"}
748	2661	{"_key": 2661, "iconFile": "res:/ui/texture/icons/50_64_1.png"}
749	2662	{"_key": 2662, "iconFile": "res:/ui/texture/icons/50_64_2.png"}
750	2663	{"_key": 2663, "iconFile": "res:/ui/texture/icons/50_64_3.png"}
751	2664	{"_key": 2664, "iconFile": "res:/ui/texture/icons/50_64_4.png"}
752	2665	{"_key": 2665, "iconFile": "res:/ui/texture/icons/50_64_5.png"}
753	2666	{"_key": 2666, "iconFile": "res:/ui/texture/icons/50_64_6.png"}
754	2667	{"_key": 2667, "iconFile": "res:/ui/texture/icons/50_64_7.png"}
755	2668	{"_key": 2668, "iconFile": "res:/ui/texture/icons/50_64_8.png"}
756	2669	{"_key": 2669, "iconFile": "res:/ui/texture/icons/50_64_9.png"}
757	2670	{"_key": 2670, "iconFile": "res:/ui/texture/icons/50_64_10.png"}
758	2671	{"_key": 2671, "iconFile": "res:/ui/texture/icons/49_64_1.png"}
759	2672	{"_key": 2672, "iconFile": "res:/ui/texture/icons/49_64_2.png"}
760	2673	{"_key": 2673, "iconFile": "res:/ui/texture/icons/49_64_3.png"}
761	2674	{"_key": 2674, "iconFile": "res:/ui/texture/icons/49_64_4.png"}
762	2677	{"_key": 2677, "iconFile": "res:/ui/texture/icons/49_64_7.png"}
763	2678	{"_key": 2678, "iconFile": "res:/ui/texture/icons/49_64_8.png"}
764	2679	{"_key": 2679, "iconFile": "res:/ui/texture/icons/49_64_9.png"}
765	2680	{"_key": 2680, "iconFile": "res:/ui/texture/icons/49_64_10.png"}
766	2681	{"_key": 2681, "iconFile": "res:/ui/texture/icons/49_64_11.png"}
767	2682	{"_key": 2682, "iconFile": "res:/ui/texture/icons/49_64_12.png"}
768	2683	{"_key": 2683, "iconFile": "res:/ui/texture/icons/49_64_13.png"}
769	2684	{"_key": 2684, "iconFile": "res:/ui/texture/icons/49_64_14.png"}
770	2685	{"_key": 2685, "iconFile": "res:/ui/texture/icons/49_64_15.png"}
771	2686	{"_key": 2686, "iconFile": "res:/ui/texture/icons/49_64_16.png"}
772	2693	{"_key": 2693, "iconFile": "res:/ui/texture/icons/51_64_7.png"}
773	2696	{"_key": 2696, "iconFile": "res:/ui/texture/icons/51_64_10.png"}
774	2697	{"_key": 2697, "iconFile": "res:/ui/texture/icons/51_64_11.png"}
775	2698	{"_key": 2698, "iconFile": "res:/ui/texture/icons/51_64_12.png"}
776	2699	{"_key": 2699, "iconFile": "res:/ui/texture/icons/51_64_13.png"}
777	2700	{"_key": 2700, "iconFile": "res:/ui/texture/icons/51_64_14.png"}
778	2701	{"_key": 2701, "iconFile": "res:/ui/texture/icons/51_64_15.png"}
779	2702	{"_key": 2702, "iconFile": "res:/ui/texture/icons/51_64_16.png"}
780	2703	{"_key": 2703, "iconFile": "res:/ui/texture/icons/9_64_15.png"}
781	2705	{"_key": 2705, "iconFile": "res:/ui/texture/icons/50_64_16.png"}
782	2732	{"_key": 2732, "iconFile": "res:/ui/texture/icons/3_64_12.png"}
783	2733	{"_key": 2733, "iconFile": "res:/ui/texture/icons/22_32_49.png"}
784	2734	{"_key": 2734, "iconFile": "res:/ui/texture/icons/22_32_50.png"}
785	2735	{"_key": 2735, "iconFile": "res:/ui/texture/icons/22_32_51.png"}
786	2736	{"_key": 2736, "iconFile": "res:/ui/texture/icons/22_32_52.png"}
787	2754	{"_key": 2754, "iconFile": "res:/ui/texture/icons/7_64_13.png"}
788	2827	{"_key": 2827, "iconFile": "res:/ui/texture/icons/52_64_1.png"}
789	2828	{"_key": 2828, "iconFile": "res:/ui/texture/icons/52_64_2.png"}
790	2829	{"_key": 2829, "iconFile": "res:/ui/texture/icons/52_64_3.png"}
791	2830	{"_key": 2830, "iconFile": "res:/ui/texture/icons/52_64_4.png"}
792	2831	{"_key": 2831, "iconFile": "res:/ui/texture/icons/52_64_5.png"}
793	2832	{"_key": 2832, "iconFile": "res:/ui/texture/icons/52_64_6.png"}
794	2833	{"_key": 2833, "iconFile": "res:/ui/texture/icons/52_64_7.png"}
795	2834	{"_key": 2834, "iconFile": "res:/ui/texture/icons/52_64_8.png"}
796	2835	{"_key": 2835, "iconFile": "res:/ui/texture/icons/52_64_9.png"}
797	2836	{"_key": 2836, "iconFile": "res:/ui/texture/icons/52_64_10.png"}
798	2837	{"_key": 2837, "iconFile": "res:/ui/texture/icons/52_64_11.png"}
799	2838	{"_key": 2838, "iconFile": "res:/ui/texture/icons/52_64_12.png"}
800	2839	{"_key": 2839, "iconFile": "res:/ui/texture/icons/52_64_13.png"}
801	2840	{"_key": 2840, "iconFile": "res:/ui/texture/icons/52_64_14.png"}
802	2841	{"_key": 2841, "iconFile": "res:/ui/texture/icons/52_64_15.png"}
803	2842	{"_key": 2842, "iconFile": "res:/ui/texture/icons/52_64_16.png"}
804	2843	{"_key": 2843, "iconFile": "res:/ui/texture/icons/53_64_1.png"}
805	2844	{"_key": 2844, "iconFile": "res:/ui/texture/icons/53_64_2.png"}
806	2845	{"_key": 2845, "iconFile": "res:/ui/texture/icons/53_64_3.png"}
807	2846	{"_key": 2846, "iconFile": "res:/ui/texture/icons/53_64_4.png"}
808	2847	{"_key": 2847, "iconFile": "res:/ui/texture/icons/53_64_5.png"}
809	2848	{"_key": 2848, "iconFile": "res:/ui/texture/icons/53_64_6.png"}
810	2849	{"_key": 2849, "iconFile": "res:/ui/texture/icons/53_64_7.png"}
811	2850	{"_key": 2850, "iconFile": "res:/ui/texture/icons/53_64_8.png"}
812	2851	{"_key": 2851, "iconFile": "res:/ui/texture/icons/53_64_9.png"}
813	2852	{"_key": 2852, "iconFile": "res:/ui/texture/icons/53_64_10.png"}
814	2853	{"_key": 2853, "iconFile": "res:/ui/texture/icons/53_64_11.png"}
815	2854	{"_key": 2854, "iconFile": "res:/ui/texture/icons/53_64_12.png"}
816	2855	{"_key": 2855, "iconFile": "res:/ui/texture/icons/53_64_13.png"}
817	2856	{"_key": 2856, "iconFile": "res:/ui/texture/icons/53_64_14.png"}
818	2857	{"_key": 2857, "iconFile": "res:/ui/texture/icons/53_64_15.png"}
819	2858	{"_key": 2858, "iconFile": "res:/ui/texture/icons/53_64_16.png"}
820	2859	{"_key": 2859, "iconFile": "res:/ui/texture/icons/54_64_1.png"}
821	2860	{"_key": 2860, "iconFile": "res:/ui/texture/icons/54_64_2.png"}
822	2861	{"_key": 2861, "iconFile": "res:/ui/texture/icons/54_64_3.png"}
823	2862	{"_key": 2862, "iconFile": "res:/ui/texture/icons/54_64_4.png"}
824	2863	{"_key": 2863, "iconFile": "res:/ui/texture/icons/54_64_5.png"}
825	2864	{"_key": 2864, "iconFile": "res:/ui/texture/icons/54_64_6.png"}
826	2865	{"_key": 2865, "iconFile": "res:/ui/texture/icons/54_64_7.png"}
827	2866	{"_key": 2866, "iconFile": "res:/ui/texture/icons/54_64_8.png"}
828	2867	{"_key": 2867, "iconFile": "res:/ui/texture/icons/54_64_9.png"}
829	2868	{"_key": 2868, "iconFile": "res:/ui/texture/icons/54_64_10.png"}
830	2869	{"_key": 2869, "iconFile": "res:/ui/texture/icons/54_64_11.png"}
831	2870	{"_key": 2870, "iconFile": "res:/ui/texture/icons/54_64_12.png"}
832	2871	{"_key": 2871, "iconFile": "res:/ui/texture/icons/54_64_13.png"}
833	2872	{"_key": 2872, "iconFile": "res:/ui/texture/icons/54_64_14.png"}
834	2873	{"_key": 2873, "iconFile": "res:/ui/texture/icons/54_64_15.png"}
835	2874	{"_key": 2874, "iconFile": "res:/ui/texture/icons/54_64_16.png"}
836	2875	{"_key": 2875, "iconFile": "res:/ui/texture/icons/55_64_1.png"}
837	2876	{"_key": 2876, "iconFile": "res:/ui/texture/icons/55_64_2.png"}
838	2877	{"_key": 2877, "iconFile": "res:/ui/texture/icons/55_64_3.png"}
839	2878	{"_key": 2878, "iconFile": "res:/ui/texture/icons/55_64_4.png"}
840	2879	{"_key": 2879, "iconFile": "res:/ui/texture/icons/55_64_5.png"}
841	2880	{"_key": 2880, "iconFile": "res:/ui/texture/icons/55_64_6.png"}
842	2881	{"_key": 2881, "iconFile": "res:/ui/texture/icons/55_64_7.png"}
843	2882	{"_key": 2882, "iconFile": "res:/ui/texture/icons/55_64_8.png"}
844	2883	{"_key": 2883, "iconFile": "res:/ui/texture/icons/55_64_9.png"}
845	2884	{"_key": 2884, "iconFile": "res:/ui/texture/icons/55_64_10.png"}
846	2885	{"_key": 2885, "iconFile": "res:/ui/texture/icons/55_64_11.png"}
847	2886	{"_key": 2886, "iconFile": "res:/ui/texture/icons/55_64_12.png"}
848	2887	{"_key": 2887, "iconFile": "res:/ui/texture/icons/55_64_13.png"}
849	2888	{"_key": 2888, "iconFile": "res:/ui/texture/icons/55_64_14.png"}
850	2889	{"_key": 2889, "iconFile": "res:/ui/texture/icons/55_64_15.png"}
851	2890	{"_key": 2890, "iconFile": "res:/ui/texture/icons/55_64_16.png"}
852	2891	{"_key": 2891, "iconFile": "res:/ui/texture/icons/46_64_12.png"}
853	2893	{"_key": 2893, "iconFile": "res:/ui/texture/icons/4_64_16.png"}
854	2908	{"_key": 2908, "iconFile": "res:/ui/texture/icons/7_64_3.png"}
855	2934	{"_key": 2934, "iconFile": "res:/ui/texture/icons/56_64_2.png"}
856	2943	{"_key": 2943, "iconFile": "res:/ui/texture/icons/57_64_4.png"}
857	2971	{"_key": 2971, "iconFile": "res:/ui/texture/icons/36_64_13.png"}
858	2974	{"_key": 2974, "iconFile": "res:/ui/texture/icons/36_64_16.png"}
859	2983	{"_key": 2983, "iconFile": "res:/ui/texture/icons/56_64_1.png"}
860	2985	{"_key": 2985, "iconFile": "res:/ui/texture/icons/56_64_3.png"}
861	2986	{"_key": 2986, "iconFile": "res:/ui/texture/icons/56_64_4.png"}
862	2987	{"_key": 2987, "iconFile": "res:/ui/texture/icons/56_64_5.png"}
863	2988	{"_key": 2988, "iconFile": "res:/ui/texture/icons/56_64_6.png"}
864	2989	{"_key": 2989, "iconFile": "res:/ui/texture/icons/56_64_7.png"}
865	2990	{"_key": 2990, "iconFile": "res:/ui/texture/icons/56_64_8.png"}
866	2991	{"_key": 2991, "iconFile": "res:/ui/texture/icons/56_64_9.png"}
867	2992	{"_key": 2992, "iconFile": "res:/ui/texture/icons/56_64_10.png"}
868	2993	{"_key": 2993, "iconFile": "res:/ui/texture/icons/56_64_11.png"}
869	2994	{"_key": 2994, "iconFile": "res:/ui/texture/icons/56_64_12.png"}
870	2995	{"_key": 2995, "iconFile": "res:/ui/texture/icons/56_64_13.png"}
871	2996	{"_key": 2996, "iconFile": "res:/ui/texture/icons/56_64_14.png"}
872	2997	{"_key": 2997, "iconFile": "res:/ui/texture/icons/56_64_15.png"}
873	2998	{"_key": 2998, "iconFile": "res:/ui/texture/icons/56_64_16.png"}
874	2999	{"_key": 2999, "iconFile": "res:/ui/texture/icons/57_64_1.png"}
875	3000	{"_key": 3000, "iconFile": "res:/ui/texture/icons/57_64_2.png"}
876	3001	{"_key": 3001, "iconFile": "res:/ui/texture/icons/57_64_3.png"}
877	3003	{"_key": 3003, "iconFile": "res:/ui/texture/icons/57_64_6.png"}
878	3004	{"_key": 3004, "iconFile": "res:/ui/texture/icons/57_64_7.png"}
879	3005	{"_key": 3005, "iconFile": "res:/ui/texture/icons/57_64_8.png"}
880	3006	{"_key": 3006, "iconFile": "res:/ui/texture/icons/57_64_9.png"}
881	3007	{"_key": 3007, "iconFile": "res:/ui/texture/icons/57_64_10.png"}
882	3008	{"_key": 3008, "iconFile": "res:/ui/texture/icons/57_64_11.png"}
883	3009	{"_key": 3009, "iconFile": "res:/ui/texture/icons/57_64_12.png"}
884	3010	{"_key": 3010, "iconFile": "res:/ui/texture/icons/57_64_13.png"}
885	3011	{"_key": 3011, "iconFile": "res:/ui/texture/icons/57_64_14.png"}
886	3012	{"_key": 3012, "iconFile": "res:/ui/texture/icons/57_64_15.png"}
887	3013	{"_key": 3013, "iconFile": "res:/ui/texture/icons/57_64_16.png"}
888	3019	{"_key": 3019, "iconFile": "res:/ui/texture/icons/58_64_1.png"}
889	3021	{"_key": 3021, "iconFile": "res:/ui/texture/icons/59_128_1.png"}
890	3022	{"_key": 3022, "iconFile": "res:/ui/texture/icons/59_128_2.png"}
891	3023	{"_key": 3023, "iconFile": "res:/ui/texture/icons/59_128_3.png"}
892	3024	{"_key": 3024, "iconFile": "res:/ui/texture/icons/59_128_4.png"}
893	3025	{"_key": 3025, "iconFile": "res:/ui/texture/icons/58_64_2.png"}
894	3026	{"_key": 3026, "iconFile": "res:/ui/texture/icons/58_64_3.png"}
895	3027	{"_key": 3027, "iconFile": "res:/ui/texture/icons/58_64_4.png"}
896	3028	{"_key": 3028, "iconFile": "res:/ui/texture/icons/58_64_5.png"}
897	3029	{"_key": 3029, "iconFile": "res:/ui/texture/icons/58_64_6.png"}
898	3030	{"_key": 3030, "iconFile": "res:/ui/texture/icons/58_64_7.png"}
899	3031	{"_key": 3031, "iconFile": "res:/ui/texture/icons/58_64_9.png"}
900	3032	{"_key": 3032, "iconFile": "res:/ui/texture/icons/58_64_10.png"}
901	3033	{"_key": 3033, "iconFile": "res:/ui/texture/icons/58_64_11.png"}
902	3034	{"_key": 3034, "iconFile": "res:/ui/texture/icons/58_64_14.png"}
903	3035	{"_key": 3035, "iconFile": "res:/ui/texture/icons/58_64_15.png"}
904	3036	{"_key": 3036, "iconFile": "res:/ui/texture/icons/58_64_13.png"}
905	3038	{"_key": 3038, "iconFile": "res:/ui/texture/icons/17_128_3.png"}
906	3074	{"_key": 3074, "iconFile": "res:/ui/texture/icons/35_64_3.png"}
907	3127	{"_key": 3127, "iconFile": "res:/ui/texture/icons/60_128_1.png"}
908	3128	{"_key": 3128, "iconFile": "res:/ui/texture/icons/60_128_2.png"}
909	3129	{"_key": 3129, "iconFile": "res:/ui/texture/icons/60_128_3.png"}
910	3130	{"_key": 3130, "iconFile": "res:/ui/texture/icons/60_128_4.png"}
911	3131	{"_key": 3131, "iconFile": "res:/ui/texture/icons/61_128_1.png"}
912	3172	{"_key": 3172, "iconFile": "res:/ui/texture/icons/67_128_1.png"}
913	3173	{"_key": 3173, "iconFile": "res:/ui/texture/icons/67_128_2.png"}
914	3174	{"_key": 3174, "iconFile": "res:/ui/texture/icons/67_128_4.png"}
915	3175	{"_key": 3175, "iconFile": "res:/ui/texture/icons/65_128_1.png"}
916	3176	{"_key": 3176, "iconFile": "res:/ui/texture/icons/65_128_2.png"}
917	3177	{"_key": 3177, "iconFile": "res:/ui/texture/icons/65_128_4.png"}
918	3178	{"_key": 3178, "iconFile": "res:/ui/texture/icons/66_128_1.png"}
919	3179	{"_key": 3179, "iconFile": "res:/ui/texture/icons/66_128_2.png"}
920	3180	{"_key": 3180, "iconFile": "res:/ui/texture/icons/66_128_4.png"}
921	3181	{"_key": 3181, "iconFile": "res:/ui/texture/icons/63_64_1.png"}
922	3182	{"_key": 3182, "iconFile": "res:/ui/texture/icons/63_64_2.png"}
923	3183	{"_key": 3183, "iconFile": "res:/ui/texture/icons/63_64_3.png"}
924	3184	{"_key": 3184, "iconFile": "res:/ui/texture/icons/63_64_4.png"}
925	3185	{"_key": 3185, "iconFile": "res:/ui/texture/icons/63_64_5.png"}
926	3186	{"_key": 3186, "iconFile": "res:/ui/texture/icons/63_64_6.png"}
927	3187	{"_key": 3187, "iconFile": "res:/ui/texture/icons/63_64_7.png"}
928	3188	{"_key": 3188, "iconFile": "res:/ui/texture/icons/63_64_8.png"}
929	3189	{"_key": 3189, "iconFile": "res:/ui/texture/icons/63_64_9.png"}
930	3190	{"_key": 3190, "iconFile": "res:/ui/texture/icons/63_64_10.png"}
931	3191	{"_key": 3191, "iconFile": "res:/ui/texture/icons/63_64_11.png"}
932	3192	{"_key": 3192, "iconFile": "res:/ui/texture/icons/63_64_12.png"}
933	3193	{"_key": 3193, "iconFile": "res:/ui/texture/icons/68_64_9.png"}
934	3194	{"_key": 3194, "iconFile": "res:/ui/texture/icons/68_64_10.png"}
935	3195	{"_key": 3195, "iconFile": "res:/ui/texture/icons/68_64_11.png"}
936	3196	{"_key": 3196, "iconFile": "res:/ui/texture/icons/68_64_12.png"}
937	3197	{"_key": 3197, "iconFile": "res:/ui/texture/icons/68_64_13.png"}
938	3198	{"_key": 3198, "iconFile": "res:/ui/texture/icons/68_64_14.png"}
939	3199	{"_key": 3199, "iconFile": "res:/ui/texture/icons/68_64_15.png"}
940	3200	{"_key": 3200, "iconFile": "res:/ui/texture/icons/68_64_16.png"}
941	3201	{"_key": 3201, "iconFile": "res:/ui/texture/icons/68_64_2.png"}
942	3202	{"_key": 3202, "iconFile": "res:/ui/texture/icons/68_64_3.png"}
943	3203	{"_key": 3203, "iconFile": "res:/ui/texture/icons/68_64_4.png"}
944	3208	{"_key": 3208, "iconFile": "res:/ui/texture/icons/61_128_2.png"}
945	3210	{"_key": 3210, "iconFile": "res:/ui/texture/icons/62_64_1.png"}
946	3211	{"_key": 3211, "iconFile": "res:/ui/texture/icons/62_64_2.png"}
947	3212	{"_key": 3212, "iconFile": "res:/ui/texture/icons/62_64_3.png"}
948	3213	{"_key": 3213, "iconFile": "res:/ui/texture/icons/62_64_4.png"}
949	3214	{"_key": 3214, "iconFile": "res:/ui/texture/icons/62_64_5.png"}
950	3215	{"_key": 3215, "iconFile": "res:/ui/texture/icons/62_64_6.png"}
951	3216	{"_key": 3216, "iconFile": "res:/ui/texture/icons/62_64_7.png"}
952	3217	{"_key": 3217, "iconFile": "res:/ui/texture/icons/62_64_8.png"}
953	3218	{"_key": 3218, "iconFile": "res:/ui/texture/icons/62_64_9.png"}
954	3219	{"_key": 3219, "iconFile": "res:/ui/texture/icons/62_64_10.png"}
955	3220	{"_key": 3220, "iconFile": "res:/ui/texture/icons/62_64_11.png"}
956	3221	{"_key": 3221, "iconFile": "res:/ui/texture/icons/62_64_12.png"}
957	3222	{"_key": 3222, "iconFile": "res:/ui/texture/icons/62_64_13.png"}
958	3223	{"_key": 3223, "iconFile": "res:/ui/texture/icons/62_64_14.png"}
959	3224	{"_key": 3224, "iconFile": "res:/ui/texture/icons/62_64_15.png"}
960	3225	{"_key": 3225, "iconFile": "res:/ui/texture/icons/62_64_16.png"}
961	3226	{"_key": 3226, "iconFile": "res:/ui/texture/icons/63_64_13.png"}
962	3227	{"_key": 3227, "iconFile": "res:/ui/texture/icons/63_64_14.png"}
963	3228	{"_key": 3228, "iconFile": "res:/ui/texture/icons/63_64_15.png"}
964	3229	{"_key": 3229, "iconFile": "res:/ui/texture/icons/63_64_16.png"}
965	3230	{"_key": 3230, "iconFile": "res:/ui/texture/icons/64_64_1.png"}
966	3231	{"_key": 3231, "iconFile": "res:/ui/texture/icons/64_64_2.png"}
967	3232	{"_key": 3232, "iconFile": "res:/ui/texture/icons/64_64_3.png"}
968	3233	{"_key": 3233, "iconFile": "res:/ui/texture/icons/64_64_4.png"}
969	3234	{"_key": 3234, "iconFile": "res:/ui/texture/icons/64_64_5.png"}
970	3235	{"_key": 3235, "iconFile": "res:/ui/texture/icons/64_64_6.png"}
971	3236	{"_key": 3236, "iconFile": "res:/ui/texture/icons/64_64_7.png"}
972	3237	{"_key": 3237, "iconFile": "res:/ui/texture/icons/64_64_8.png"}
973	3238	{"_key": 3238, "iconFile": "res:/ui/texture/icons/64_64_9.png"}
974	3239	{"_key": 3239, "iconFile": "res:/ui/texture/icons/64_64_10.png"}
975	3240	{"_key": 3240, "iconFile": "res:/ui/texture/icons/64_64_11.png"}
976	3241	{"_key": 3241, "iconFile": "res:/ui/texture/icons/64_64_12.png"}
977	3242	{"_key": 3242, "iconFile": "res:/ui/texture/icons/64_64_13.png"}
978	3243	{"_key": 3243, "iconFile": "res:/ui/texture/icons/64_64_14.png"}
979	3244	{"_key": 3244, "iconFile": "res:/ui/texture/icons/64_64_15.png"}
980	3245	{"_key": 3245, "iconFile": "res:/ui/texture/icons/64_64_16.png"}
981	3246	{"_key": 3246, "iconFile": "res:/ui/texture/icons/68_64_5.png"}
982	3247	{"_key": 3247, "iconFile": "res:/ui/texture/icons/68_64_6.png"}
983	3248	{"_key": 3248, "iconFile": "res:/ui/texture/icons/68_64_7.png"}
984	3249	{"_key": 3249, "iconFile": "res:/ui/texture/icons/68_64_8.png"}
985	3250	{"_key": 3250, "iconFile": "res:/ui/texture/icons/69_64_1.png"}
986	3251	{"_key": 3251, "iconFile": "res:/ui/texture/icons/69_64_2.png"}
987	3252	{"_key": 3252, "iconFile": "res:/ui/texture/icons/69_64_3.png"}
988	3253	{"_key": 3253, "iconFile": "res:/ui/texture/icons/69_64_4.png"}
989	3254	{"_key": 3254, "iconFile": "res:/ui/texture/icons/69_64_5.png"}
990	3255	{"_key": 3255, "iconFile": "res:/ui/texture/icons/69_64_6.png"}
991	3256	{"_key": 3256, "iconFile": "res:/ui/texture/icons/69_64_7.png"}
992	3257	{"_key": 3257, "iconFile": "res:/ui/texture/icons/69_64_8.png"}
993	3258	{"_key": 3258, "iconFile": "res:/ui/texture/icons/69_64_9.png"}
994	3259	{"_key": 3259, "iconFile": "res:/ui/texture/icons/69_64_10.png"}
995	3260	{"_key": 3260, "iconFile": "res:/ui/texture/icons/69_64_11.png"}
996	3261	{"_key": 3261, "iconFile": "res:/ui/texture/icons/69_64_12.png"}
997	3262	{"_key": 3262, "iconFile": "res:/ui/texture/icons/69_64_13.png"}
998	3263	{"_key": 3263, "iconFile": "res:/ui/texture/icons/69_64_14.png"}
999	3264	{"_key": 3264, "iconFile": "res:/ui/texture/icons/69_64_15.png"}
1000	3265	{"_key": 3265, "iconFile": "res:/ui/texture/icons/69_64_16.png"}
1001	3266	{"_key": 3266, "iconFile": "res:/ui/texture/icons/68_64_1.png"}
1002	3267	{"_key": 3267, "iconFile": "res:/ui/texture/icons/70_64_1.png"}
1003	3268	{"_key": 3268, "iconFile": "res:/ui/texture/icons/70_64_2.png"}
1004	3278	{"_key": 3278, "iconFile": "res:/ui/texture/icons/70_64_5.png"}
1005	3279	{"_key": 3279, "iconFile": "res:/ui/texture/icons/70_64_8.png"}
1006	3280	{"_key": 3280, "iconFile": "res:/ui/texture/icons/70_64_6.png"}
1007	3281	{"_key": 3281, "iconFile": "res:/ui/texture/icons/70_64_7.png"}
1008	3282	{"_key": 3282, "iconFile": "res:/ui/texture/icons/70_64_3.png"}
1009	3283	{"_key": 3283, "iconFile": "res:/ui/texture/icons/70_64_4.png"}
1010	3299	{"_key": 3299, "iconFile": "res:/ui/texture/icons/70_64_9.png"}
1011	3300	{"_key": 3300, "iconFile": "res:/ui/texture/icons/70_64_10.png"}
1012	3301	{"_key": 3301, "iconFile": "res:/ui/texture/icons/70_64_11.png"}
1013	3302	{"_key": 3302, "iconFile": "res:/ui/texture/icons/70_64_12.png"}
1014	3303	{"_key": 3303, "iconFile": "res:/ui/texture/icons/70_64_13.png"}
1015	3304	{"_key": 3304, "iconFile": "res:/ui/texture/icons/70_64_14.png"}
1016	3305	{"_key": 3305, "iconFile": "res:/ui/texture/icons/70_64_15.png"}
1017	3306	{"_key": 3306, "iconFile": "res:/ui/texture/icons/70_64_16.png"}
1018	3307	{"_key": 3307, "iconFile": "res:/ui/texture/icons/71_64_1.png"}
1019	3308	{"_key": 3308, "iconFile": "res:/ui/texture/icons/71_64_2.png"}
1020	3309	{"_key": 3309, "iconFile": "res:/ui/texture/icons/71_64_3.png"}
1021	3310	{"_key": 3310, "iconFile": "res:/ui/texture/icons/71_64_4.png"}
1022	3311	{"_key": 3311, "iconFile": "res:/ui/texture/icons/71_64_5.png"}
1023	3312	{"_key": 3312, "iconFile": "res:/ui/texture/icons/71_64_6.png"}
1024	3313	{"_key": 3313, "iconFile": "res:/ui/texture/icons/71_64_7.png"}
1025	3314	{"_key": 3314, "iconFile": "res:/ui/texture/icons/71_64_8.png"}
1026	3315	{"_key": 3315, "iconFile": "res:/ui/texture/icons/71_64_9.png"}
1027	3316	{"_key": 3316, "iconFile": "res:/ui/texture/icons/71_64_10.png"}
1028	3317	{"_key": 3317, "iconFile": "res:/ui/texture/icons/71_64_11.png"}
1029	3318	{"_key": 3318, "iconFile": "res:/ui/texture/icons/71_64_12.png"}
1030	3319	{"_key": 3319, "iconFile": "res:/ui/texture/icons/71_64_13.png"}
1031	3320	{"_key": 3320, "iconFile": "res:/ui/texture/icons/71_64_14.png"}
1032	3321	{"_key": 3321, "iconFile": "res:/ui/texture/icons/71_64_15.png"}
1033	3322	{"_key": 3322, "iconFile": "res:/ui/texture/icons/71_64_16.png"}
1034	3323	{"_key": 3323, "iconFile": "res:/ui/texture/icons/72_64_1.png"}
1035	3324	{"_key": 3324, "iconFile": "res:/ui/texture/icons/72_64_2.png"}
1036	3325	{"_key": 3325, "iconFile": "res:/ui/texture/icons/72_64_3.png"}
1037	3326	{"_key": 3326, "iconFile": "res:/ui/texture/icons/72_64_4.png"}
1038	3327	{"_key": 3327, "iconFile": "res:/ui/texture/icons/72_64_5.png"}
1039	3328	{"_key": 3328, "iconFile": "res:/ui/texture/icons/72_64_6.png"}
1040	3329	{"_key": 3329, "iconFile": "res:/ui/texture/icons/72_64_8.png"}
1041	3330	{"_key": 3330, "iconFile": "res:/ui/texture/icons/72_64_9.png"}
1042	3333	{"_key": 3333, "iconFile": "res:/ui/texture/icons/72_64_10.png"}
1043	3334	{"_key": 3334, "iconFile": "res:/ui/texture/icons/72_64_11.png"}
1044	3335	{"_key": 3335, "iconFile": "res:/ui/texture/icons/72_64_12.png"}
1045	3336	{"_key": 3336, "iconFile": "res:/ui/texture/icons/72_64_13.png"}
1046	3337	{"_key": 3337, "iconFile": "res:/ui/texture/icons/72_64_14.png"}
1047	3338	{"_key": 3338, "iconFile": "res:/ui/texture/icons/72_64_15.png"}
1048	3339	{"_key": 3339, "iconFile": "res:/ui/texture/icons/74_64_1.png"}
1049	3340	{"_key": 3340, "iconFile": "res:/ui/texture/icons/74_64_2.png"}
1050	3341	{"_key": 3341, "iconFile": "res:/ui/texture/icons/74_64_3.png"}
1051	3342	{"_key": 3342, "iconFile": "res:/ui/texture/icons/74_64_4.png"}
1052	3343	{"_key": 3343, "iconFile": "res:/ui/texture/icons/74_64_5.png"}
1053	3344	{"_key": 3344, "iconFile": "res:/ui/texture/icons/74_64_6.png"}
1054	3345	{"_key": 3345, "iconFile": "res:/ui/texture/icons/74_64_7.png"}
1055	3346	{"_key": 3346, "iconFile": "res:/ui/texture/icons/74_64_8.png"}
1056	3347	{"_key": 3347, "iconFile": "res:/ui/texture/icons/74_64_9.png"}
1057	3348	{"_key": 3348, "iconFile": "res:/ui/texture/icons/74_64_10.png"}
1058	3369	{"_key": 3369, "iconFile": "res:/ui/texture/corps/47_128_1.png"}
1059	3370	{"_key": 3370, "iconFile": "res:/ui/texture/corps/47_128_2.png"}
1060	3371	{"_key": 3371, "iconFile": "res:/ui/texture/corps/47_128_3.png"}
1061	3372	{"_key": 3372, "iconFile": "res:/ui/texture/corps/47_128_4.png"}
1062	3433	{"_key": 3433, "iconFile": "res:/ui/texture/icons/76_64_1.png"}
1063	3435	{"_key": 3435, "iconFile": "res:/ui/texture/icons/78_64_1.png"}
1064	3436	{"_key": 3436, "iconFile": "res:/ui/texture/icons/78_64_2.png"}
1065	3437	{"_key": 3437, "iconFile": "res:/ui/texture/icons/78_64_3.png"}
1066	3438	{"_key": 3438, "iconFile": "res:/ui/texture/icons/78_64_4.png"}
1067	3439	{"_key": 3439, "iconFile": "res:/ui/texture/icons/78_64_5.png"}
1068	3440	{"_key": 3440, "iconFile": "res:/ui/texture/icons/78_64_6.png"}
1069	3441	{"_key": 3441, "iconFile": "res:/ui/texture/icons/78_64_7.png"}
1070	3442	{"_key": 3442, "iconFile": "res:/ui/texture/icons/78_64_8.png"}
1071	3443	{"_key": 3443, "iconFile": "res:/ui/texture/icons/78_64_9.png"}
1072	3444	{"_key": 3444, "iconFile": "res:/ui/texture/icons/78_64_10.png"}
1073	3445	{"_key": 3445, "iconFile": "res:/ui/texture/icons/78_64_11.png"}
1074	3446	{"_key": 3446, "iconFile": "res:/ui/texture/icons/78_64_12.png"}
1075	3447	{"_key": 3447, "iconFile": "res:/ui/texture/icons/78_64_13.png"}
1076	3448	{"_key": 3448, "iconFile": "res:/ui/texture/icons/78_64_14.png"}
1077	3449	{"_key": 3449, "iconFile": "res:/ui/texture/icons/78_64_15.png"}
1078	3450	{"_key": 3450, "iconFile": "res:/ui/texture/icons/78_64_16.png"}
1079	3626	{"_key": 3626, "iconFile": "res:/ui/texture/icons/76_64_9.png"}
1080	3631	{"_key": 3631, "iconFile": "res:/ui/texture/icons/76_64_6.png"}
1081	3636	{"_key": 3636, "iconFile": "res:/ui/texture/icons/76_64_7.png"}
1082	3641	{"_key": 3641, "iconFile": "res:/ui/texture/icons/76_64_5.png"}
1083	3646	{"_key": 3646, "iconFile": "res:/ui/texture/icons/76_64_8.png"}
1084	3716	{"_key": 3716, "iconFile": "res:/ui/texture/icons/76_64_14.png"}
1085	3717	{"_key": 3717, "iconFile": "res:/ui/texture/icons/76_64_12.png"}
1086	3718	{"_key": 3718, "iconFile": "res:/ui/texture/icons/76_64_15.png"}
1087	3719	{"_key": 3719, "iconFile": "res:/ui/texture/icons/76_64_10.png"}
1088	3720	{"_key": 3720, "iconFile": "res:/ui/texture/icons/76_64_13.png"}
1089	3721	{"_key": 3721, "iconFile": "res:/ui/texture/icons/76_64_11.png"}
1090	3722	{"_key": 3722, "iconFile": "res:/ui/texture/icons/82_64_10.png"}
1091	3723	{"_key": 3723, "iconFile": "res:/ui/texture/icons/82_64_9.png"}
1092	3724	{"_key": 3724, "iconFile": "res:/ui/texture/icons/82_64_7.png"}
1093	3725	{"_key": 3725, "iconFile": "res:/ui/texture/icons/82_64_8.png"}
1094	3726	{"_key": 3726, "iconFile": "res:/ui/texture/icons/82_64_4.png"}
1095	3727	{"_key": 3727, "iconFile": "res:/ui/texture/icons/82_64_3.png"}
1096	3728	{"_key": 3728, "iconFile": "res:/ui/texture/icons/82_64_1.png"}
1097	3729	{"_key": 3729, "iconFile": "res:/ui/texture/icons/82_64_2.png"}
1098	3730	{"_key": 3730, "iconFile": "res:/ui/texture/icons/82_64_11.png"}
1099	3731	{"_key": 3731, "iconFile": "res:/ui/texture/icons/82_64_12.png"}
1100	3732	{"_key": 3732, "iconFile": "res:/ui/texture/icons/82_64_5.png"}
1101	3733	{"_key": 3733, "iconFile": "res:/ui/texture/icons/82_64_6.png"}
1102	3734	{"_key": 3734, "iconFile": "res:/ui/texture/icons/84_64_6.png"}
1103	3735	{"_key": 3735, "iconFile": "res:/ui/texture/icons/84_64_4.png"}
1104	3736	{"_key": 3736, "iconFile": "res:/ui/texture/icons/84_64_2.png"}
1105	3737	{"_key": 3737, "iconFile": "res:/ui/texture/icons/84_64_3.png"}
1106	3738	{"_key": 3738, "iconFile": "res:/ui/texture/icons/84_64_7.png"}
1107	3739	{"_key": 3739, "iconFile": "res:/ui/texture/icons/83_64_1.png"}
1108	3740	{"_key": 3740, "iconFile": "res:/ui/texture/icons/83_64_2.png"}
1109	3741	{"_key": 3741, "iconFile": "res:/ui/texture/icons/83_64_3.png"}
1110	3742	{"_key": 3742, "iconFile": "res:/ui/texture/icons/83_64_4.png"}
1111	3743	{"_key": 3743, "iconFile": "res:/ui/texture/icons/84_64_1.png"}
1112	3744	{"_key": 3744, "iconFile": "res:/ui/texture/icons/83_64_5.png"}
1113	3745	{"_key": 3745, "iconFile": "res:/ui/texture/icons/83_64_6.png"}
1114	3746	{"_key": 3746, "iconFile": "res:/ui/texture/icons/83_64_7.png"}
1115	3747	{"_key": 3747, "iconFile": "res:/ui/texture/icons/83_64_8.png"}
1116	3748	{"_key": 3748, "iconFile": "res:/ui/texture/icons/84_64_5.png"}
1117	3749	{"_key": 3749, "iconFile": "res:/ui/texture/icons/83_64_9.png"}
1118	3750	{"_key": 3750, "iconFile": "res:/ui/texture/icons/83_64_10.png"}
1119	3751	{"_key": 3751, "iconFile": "res:/ui/texture/icons/83_64_11.png"}
1120	3752	{"_key": 3752, "iconFile": "res:/ui/texture/icons/83_64_12.png"}
1121	3753	{"_key": 3753, "iconFile": "res:/ui/texture/icons/84_64_9.png"}
1122	3754	{"_key": 3754, "iconFile": "res:/ui/texture/icons/83_64_13.png"}
1123	3755	{"_key": 3755, "iconFile": "res:/ui/texture/icons/84_64_8.png"}
1124	3756	{"_key": 3756, "iconFile": "res:/ui/texture/icons/76_64_4.png"}
1125	3759	{"_key": 3759, "iconFile": "res:/ui/texture/icons/76_64_16.png"}
1126	3762	{"_key": 3762, "iconFile": "res:/ui/texture/icons/89_128_1.png"}
1127	3763	{"_key": 3763, "iconFile": "res:/ui/texture/icons/89_128_2.png"}
1128	3764	{"_key": 3764, "iconFile": "res:/ui/texture/icons/89_128_3.png"}
1129	3765	{"_key": 3765, "iconFile": "res:/ui/texture/icons/89_128_4.png"}
1130	3766	{"_key": 3766, "iconFile": "res:/ui/texture/icons/84_64_16.png"}
1131	3801	{"_key": 3801, "iconFile": "res:/UI/netres/mission_content/agent_interaction.png"}
1132	3802	{"_key": 3802, "iconFile": "res:/UI/netres/mission_content/agent_talkto.png"}
1133	3803	{"_key": 3803, "iconFile": "res:/UI/netres/mission_content/arc_amarr.png"}
1134	3804	{"_key": 3804, "iconFile": "res:/UI/netres/mission_content/arc_caldari.png"}
1135	3805	{"_key": 3805, "iconFile": "res:/UI/netres/mission_content/arc_gallente.png"}
1136	3806	{"_key": 3806, "iconFile": "res:/UI/netres/mission_content/arc_minmatar.png"}
1137	3807	{"_key": 3807, "iconFile": "res:/UI/netres/mission_content/blood_stained.png"}
1138	3838	{"_key": 3838, "iconFile": "res:/UI/netres/mission_content/angels_and_artifacts.png"}
1139	3839	{"_key": 3839, "iconFile": "res:/UI/netres/mission_content/smash_and_grab.png"}
1140	3943	{"_key": 3943, "iconFile": "res:/ui/texture/icons/95_64_11.png"}
1141	3945	{"_key": 3945, "iconFile": "res:/ui/texture/icons/95_64_2.png"}
1142	3946	{"_key": 3946, "iconFile": "res:/ui/texture/icons/95_64_3.png"}
1143	3947	{"_key": 3947, "iconFile": "res:/ui/texture/icons/95_64_4.png"}
1144	3948	{"_key": 3948, "iconFile": "res:/ui/texture/icons/95_64_6.png"}
1145	3949	{"_key": 3949, "iconFile": "res:/ui/texture/icons/95_64_7.png"}
1146	3950	{"_key": 3950, "iconFile": "res:/ui/texture/icons/95_64_8.png"}
1147	3951	{"_key": 3951, "iconFile": "res:/ui/texture/icons/95_64_10.png"}
1148	3952	{"_key": 3952, "iconFile": "res:/ui/texture/icons/95_64_12.png"}
1149	3953	{"_key": 3953, "iconFile": "res:/ui/texture/icons/95_64_14.png"}
1150	3954	{"_key": 3954, "iconFile": "res:/ui/texture/icons/95_64_15.png"}
1151	3955	{"_key": 3955, "iconFile": "res:/ui/texture/icons/95_64_5.png"}
1152	5003	{"_key": 5003, "iconFile": "res:/Texture/Landmark/amarr.jpg"}
1153	5005	{"_key": 5005, "iconFile": "res:/Texture/Landmark/minmatar.jpg"}
1154	5006	{"_key": 5006, "iconFile": "res:/Texture/Landmark/caldari.jpg"}
1155	5007	{"_key": 5007, "iconFile": "res:/Texture/Landmark/galente.jpg"}
1156	5008	{"_key": 5008, "iconFile": "res:/Texture/Landmark/jove.jpg"}
1157	5010	{"_key": 5010, "iconFile": "res:/Texture/Landmark/khanidkingdom.jpg"}
1158	5012	{"_key": 5012, "iconFile": "res:/Texture/Landmark/Curse.jpg"}
1159	5015	{"_key": 5015, "iconFile": "res:/Texture/Landmark/outerring.jpg"}
1160	5016	{"_key": 5016, "iconFile": "res:/Texture/Landmark/stain.jpg"}
1161	5017	{"_key": 5017, "iconFile": "res:/Texture/Landmark/venal.jpg"}
1162	5020	{"_key": 5020, "iconFile": "res:/Texture/Landmark/pointofnoreturn.jpg"}
1163	5026	{"_key": 5026, "iconFile": "res:/Texture/Landmark/ginnungagap.jpg"}
1164	5027	{"_key": 5027, "iconFile": "res:/Texture/Landmark/golgothanfields.jpg"}
1165	5029	{"_key": 5029, "iconFile": "res:/Texture/Landmark/myridianstrip.jpg"}
1166	5030	{"_key": 5030, "iconFile": "res:/Texture/Landmark/A33colonialruins.jpg"}
1167	5031	{"_key": 5031, "iconFile": "res:/Texture/Landmark/serpentscoil.jpg"}
1168	5032	{"_key": 5032, "iconFile": "res:/Texture/Landmark/traumark.jpg"}
1169	5033	{"_key": 5033, "iconFile": "res:/Texture/Landmark/cityofgod.jpg"}
1170	10012	{"_key": 10012, "iconFile": "res:/ui/texture/icons/96_64_2.png"}
1171	10013	{"_key": 10013, "iconFile": "res:/ui/texture/icons/96_64_3.png"}
1172	10014	{"_key": 10014, "iconFile": "res:/ui/texture/icons/96_64_4.png"}
1173	10015	{"_key": 10015, "iconFile": "res:/ui/texture/icons/96_64_5.png"}
1174	10016	{"_key": 10016, "iconFile": "res:/ui/texture/icons/96_64_6.png"}
1175	10017	{"_key": 10017, "iconFile": "res:/ui/texture/icons/96_64_7.png"}
1176	10018	{"_key": 10018, "iconFile": "res:/ui/texture/icons/96_64_8.png"}
1177	10019	{"_key": 10019, "iconFile": "res:/ui/texture/icons/96_64_9.png"}
1178	10020	{"_key": 10020, "iconFile": "res:/ui/texture/icons/96_64_10.png"}
1179	10021	{"_key": 10021, "iconFile": "res:/ui/texture/icons/96_64_11.png"}
1180	10022	{"_key": 10022, "iconFile": "res:/ui/texture/icons/96_64_12.png"}
1181	10023	{"_key": 10023, "iconFile": "res:/ui/texture/icons/96_64_13.png"}
1182	10024	{"_key": 10024, "iconFile": "res:/ui/texture/icons/96_64_14.png"}
1183	10025	{"_key": 10025, "iconFile": "res:/ui/texture/icons/96_64_15.png"}
1184	10026	{"_key": 10026, "iconFile": "res:/ui/texture/icons/96_64_16.png"}
1185	10027	{"_key": 10027, "iconFile": "res:/ui/texture/icons/97_64_1.png"}
1186	10028	{"_key": 10028, "iconFile": "res:/ui/texture/icons/97_64_2.png"}
1187	10029	{"_key": 10029, "iconFile": "res:/ui/texture/icons/97_64_3.png"}
1188	10030	{"_key": 10030, "iconFile": "res:/ui/texture/icons/97_64_4.png"}
1189	10031	{"_key": 10031, "iconFile": "res:/ui/texture/icons/97_64_5.png"}
1190	10032	{"_key": 10032, "iconFile": "res:/ui/texture/icons/97_64_6.png"}
1191	10033	{"_key": 10033, "iconFile": "res:/ui/texture/icons/97_64_7.png"}
1192	10034	{"_key": 10034, "iconFile": "res:/ui/texture/icons/97_64_8.png"}
1193	10035	{"_key": 10035, "iconFile": "res:/ui/texture/icons/97_64_9.png"}
1194	10036	{"_key": 10036, "iconFile": "res:/ui/texture/icons/97_64_10.png"}
1195	10037	{"_key": 10037, "iconFile": "res:/ui/texture/icons/97_64_11.png"}
1196	10038	{"_key": 10038, "iconFile": "res:/ui/texture/icons/97_64_12.png"}
1197	10039	{"_key": 10039, "iconFile": "res:/ui/texture/icons/97_64_13.png"}
1198	10040	{"_key": 10040, "iconFile": "res:/ui/texture/icons/97_64_14.png"}
1199	10041	{"_key": 10041, "iconFile": "res:/ui/texture/icons/97_64_15.png"}
1200	10042	{"_key": 10042, "iconFile": "res:/ui/texture/icons/97_64_16.png"}
1201	10043	{"_key": 10043, "iconFile": "res:/ui/texture/icons/98_64_1.png"}
1202	10044	{"_key": 10044, "iconFile": "res:/ui/texture/icons/98_64_2.png"}
1203	10045	{"_key": 10045, "iconFile": "res:/ui/texture/icons/98_64_3.png"}
1204	10046	{"_key": 10046, "iconFile": "res:/ui/texture/icons/98_64_4.png"}
1205	10047	{"_key": 10047, "iconFile": "res:/ui/texture/icons/98_64_5.png"}
1206	10048	{"_key": 10048, "iconFile": "res:/ui/texture/icons/98_64_6.png"}
1207	10049	{"_key": 10049, "iconFile": "res:/ui/texture/icons/98_64_7.png"}
1208	10050	{"_key": 10050, "iconFile": "res:/ui/texture/icons/98_64_8.png"}
1209	10051	{"_key": 10051, "iconFile": "res:/ui/texture/icons/98_64_9.png"}
1210	10052	{"_key": 10052, "iconFile": "res:/ui/texture/icons/98_64_10.png"}
1211	10053	{"_key": 10053, "iconFile": "res:/ui/texture/icons/98_64_11.png"}
1212	10054	{"_key": 10054, "iconFile": "res:/ui/texture/icons/98_64_12.png"}
1213	10055	{"_key": 10055, "iconFile": "res:/ui/texture/icons/98_64_13.png"}
1214	10056	{"_key": 10056, "iconFile": "res:/ui/texture/icons/98_64_14.png"}
1215	10057	{"_key": 10057, "iconFile": "res:/ui/texture/icons/98_64_15.png"}
1216	10058	{"_key": 10058, "iconFile": "res:/ui/texture/icons/98_64_16.png"}
1217	10059	{"_key": 10059, "iconFile": "res:/ui/texture/icons/99_64_1.png"}
1218	10060	{"_key": 10060, "iconFile": "res:/ui/texture/icons/99_64_2.png"}
1219	10061	{"_key": 10061, "iconFile": "res:/ui/texture/icons/99_64_3.png"}
1220	10062	{"_key": 10062, "iconFile": "res:/ui/texture/icons/99_64_4.png"}
1221	10063	{"_key": 10063, "iconFile": "res:/ui/texture/icons/99_64_5.png"}
1222	10064	{"_key": 10064, "iconFile": "res:/ui/texture/icons/99_64_6.png"}
1223	10065	{"_key": 10065, "iconFile": "res:/ui/texture/icons/99_64_7.png"}
1224	10066	{"_key": 10066, "iconFile": "res:/ui/texture/icons/99_64_8.png"}
1225	10071	{"_key": 10071, "iconFile": "res:/ui/texture/icons/99_64_7.png"}
1226	10073	{"_key": 10073, "iconFile": "res:/ui/texture/icons/99_64_6.png"}
1227	10074	{"_key": 10074, "iconFile": "res:/ui/texture/icons/99_64_2.png"}
1228	10075	{"_key": 10075, "iconFile": "res:/ui/texture/icons/99_64_5.png"}
1229	10076	{"_key": 10076, "iconFile": "res:/ui/texture/icons/99_64_3.png"}
1230	10077	{"_key": 10077, "iconFile": "res:/ui/texture/icons/99_64_8.png"}
1231	10078	{"_key": 10078, "iconFile": "res:/ui/texture/icons/99_64_1.png"}
1232	10079	{"_key": 10079, "iconFile": "res:/ui/texture/icons/99_64_4.png"}
1233	10081	{"_key": 10081, "iconFile": "res:/ui/texture/icons/96_64_2.png"}
1234	10082	{"_key": 10082, "iconFile": "res:/ui/texture/icons/96_64_3.png"}
1235	10083	{"_key": 10083, "iconFile": "res:/ui/texture/icons/96_64_4.png"}
1236	10084	{"_key": 10084, "iconFile": "res:/ui/texture/icons/96_64_6.png"}
1237	10085	{"_key": 10085, "iconFile": "res:/ui/texture/icons/96_64_5.png"}
1238	10086	{"_key": 10086, "iconFile": "res:/ui/texture/icons/96_64_7.png"}
1239	10087	{"_key": 10087, "iconFile": "res:/ui/texture/icons/96_64_8.png"}
1240	10088	{"_key": 10088, "iconFile": "res:/ui/texture/icons/96_64_9.png"}
1241	10089	{"_key": 10089, "iconFile": "res:/ui/texture/icons/96_64_10.png"}
1242	10090	{"_key": 10090, "iconFile": "res:/ui/texture/icons/96_64_11.png"}
1243	10091	{"_key": 10091, "iconFile": "res:/ui/texture/icons/96_64_12.png"}
1244	10092	{"_key": 10092, "iconFile": "res:/ui/texture/icons/96_64_13.png"}
1245	10093	{"_key": 10093, "iconFile": "res:/ui/texture/icons/96_64_14.png"}
1246	10094	{"_key": 10094, "iconFile": "res:/ui/texture/icons/96_64_15.png"}
1247	10095	{"_key": 10095, "iconFile": "res:/ui/texture/icons/96_64_16.png"}
1248	10096	{"_key": 10096, "iconFile": "res:/ui/texture/icons/97_64_1.png"}
1249	10097	{"_key": 10097, "iconFile": "res:/ui/texture/icons/97_64_2.png"}
1250	10098	{"_key": 10098, "iconFile": "res:/ui/texture/icons/97_64_3.png"}
1251	10099	{"_key": 10099, "iconFile": "res:/ui/texture/icons/97_64_4.png"}
1252	10100	{"_key": 10100, "iconFile": "res:/ui/texture/icons/97_64_5.png"}
1253	10101	{"_key": 10101, "iconFile": "res:/ui/texture/icons/97_64_6.png"}
1254	10102	{"_key": 10102, "iconFile": "res:/ui/texture/icons/97_64_7.png"}
1255	10103	{"_key": 10103, "iconFile": "res:/ui/texture/icons/97_64_8.png"}
1256	10104	{"_key": 10104, "iconFile": "res:/ui/texture/icons/97_64_9.png"}
1257	10105	{"_key": 10105, "iconFile": "res:/ui/texture/icons/97_64_10.png"}
1258	10106	{"_key": 10106, "iconFile": "res:/ui/texture/icons/97_64_11.png"}
1259	10107	{"_key": 10107, "iconFile": "res:/ui/texture/icons/97_64_12.png"}
1260	10108	{"_key": 10108, "iconFile": "res:/ui/texture/icons/97_64_13.png"}
1261	10109	{"_key": 10109, "iconFile": "res:/ui/texture/icons/97_64_14.png"}
1262	10110	{"_key": 10110, "iconFile": "res:/ui/texture/icons/97_64_15.png"}
1263	10111	{"_key": 10111, "iconFile": "res:/ui/texture/icons/97_64_16.png"}
1264	10113	{"_key": 10113, "iconFile": "res:/ui/texture/icons/98_64_2.png"}
1265	10115	{"_key": 10115, "iconFile": "res:/ui/texture/icons/98_64_4.png"}
1266	10116	{"_key": 10116, "iconFile": "res:/ui/texture/icons/98_64_5.png"}
1267	10117	{"_key": 10117, "iconFile": "res:/ui/texture/icons/98_64_6.png"}
1268	10118	{"_key": 10118, "iconFile": "res:/ui/texture/icons/98_64_7.png"}
1269	10119	{"_key": 10119, "iconFile": "res:/ui/texture/icons/98_64_8.png"}
1270	10120	{"_key": 10120, "iconFile": "res:/ui/texture/icons/98_64_9.png"}
1271	10121	{"_key": 10121, "iconFile": "res:/ui/texture/icons/98_64_10.png"}
1272	10122	{"_key": 10122, "iconFile": "res:/ui/texture/icons/98_64_11.png"}
1273	10123	{"_key": 10123, "iconFile": "res:/ui/texture/icons/98_64_12.png"}
1274	10124	{"_key": 10124, "iconFile": "res:/ui/texture/icons/98_64_13.png"}
1275	10125	{"_key": 10125, "iconFile": "res:/ui/texture/icons/98_64_14.png"}
1276	10126	{"_key": 10126, "iconFile": "res:/ui/texture/icons/98_64_15.png"}
1277	10127	{"_key": 10127, "iconFile": "res:/ui/texture/icons/98_64_16.png"}
1278	10132	{"_key": 10132, "iconFile": "res:/ui/texture/icons/96_64_1.png"}
1279	10133	{"_key": 10133, "iconFile": "res:/ui/texture/icons/102_128_1.png"}
1280	10134	{"_key": 10134, "iconFile": "res:/ui/texture/icons/102_128_2.png"}
1281	10135	{"_key": 10135, "iconFile": "res:/ui/texture/icons/102_128_3.png"}
1282	10136	{"_key": 10136, "iconFile": "res:/ui/texture/icons/102_128_4.png"}
1283	10137	{"_key": 10137, "iconFile": "res:/ui/texture/icons/103_128_1.png"}
1284	10138	{"_key": 10138, "iconFile": "res:/ui/texture/icons/103_128_2.png"}
1285	10139	{"_key": 10139, "iconFile": "res:/ui/texture/icons/103_128_3.png"}
1286	10140	{"_key": 10140, "iconFile": "res:/ui/texture/icons/103_128_4.png"}
1287	10141	{"_key": 10141, "iconFile": "res:/ui/texture/icons/104_128_1.png"}
1288	10142	{"_key": 10142, "iconFile": "res:/ui/texture/icons/104_128_2.png"}
1289	10144	{"_key": 10144, "iconFile": "res:/ui/texture/icons/99_64_9.png"}
1290	10149	{"_key": 10149, "iconFile": "res:/ui/texture/icons/79_64_9.png"}
1291	10150	{"_key": 10150, "iconFile": "res:/ui/texture/icons/100_64_5.png"}
1292	10151	{"_key": 10151, "iconFile": "res:/ui/texture/icons/101_64_10.png"}
1293	10152	{"_key": 10152, "iconFile": "res:/ui/texture/icons/100_64_7.png"}
1294	10153	{"_key": 10153, "iconFile": "res:/ui/texture/icons/100_64_8.png"}
1295	10154	{"_key": 10154, "iconFile": "res:/ui/texture/icons/100_64_12.png"}
1296	10155	{"_key": 10155, "iconFile": "res:/ui/texture/icons/101_64_1.png"}
1297	10156	{"_key": 10156, "iconFile": "res:/ui/texture/icons/101_64_2.png"}
1298	10157	{"_key": 10157, "iconFile": "res:/ui/texture/icons/101_64_3.png"}
1299	10158	{"_key": 10158, "iconFile": "res:/ui/texture/icons/101_64_4.png"}
1300	10159	{"_key": 10159, "iconFile": "res:/ui/texture/icons/101_64_5.png"}
1301	10160	{"_key": 10160, "iconFile": "res:/ui/texture/icons/101_64_6.png"}
1302	10161	{"_key": 10161, "iconFile": "res:/ui/texture/icons/101_64_7.png"}
1303	10162	{"_key": 10162, "iconFile": "res:/ui/texture/icons/101_64_8.png"}
1304	10163	{"_key": 10163, "iconFile": "res:/ui/texture/icons/101_64_9.png"}
1305	10164	{"_key": 10164, "iconFile": "res:/ui/texture/icons/101_64_11.png"}
1306	10165	{"_key": 10165, "iconFile": "res:/ui/texture/icons/101_64_12.png"}
1307	10166	{"_key": 10166, "iconFile": "res:/ui/texture/icons/101_64_13.png"}
1308	10172	{"_key": 10172, "iconFile": "res:/ui/texture/icons/44_32_4.png"}
1309	10173	{"_key": 10173, "iconFile": "res:/ui/texture/icons/45_64_3.png"}
1310	10174	{"_key": 10174, "iconFile": "res:/ui/texture/icons/45_64_2.png"}
1311	10175	{"_key": 10175, "iconFile": "res:/ui/texture/icons/44_32_3.png"}
1312	10176	{"_key": 10176, "iconFile": "res:/ui/texture/icons/36_64_2.png"}
1313	10177	{"_key": 10177, "iconFile": "res:/ui/texture/icons/44_32_2.png"}
1314	10178	{"_key": 10178, "iconFile": "res:/ui/texture/icons/45_64_1.png"}
1315	10180	{"_key": 10180, "iconFile": "res:/ui/texture/corps/43_128_1.png"}
1316	10181	{"_key": 10181, "iconFile": "res:/ui/texture/corps/42_128_3.png"}
1317	10182	{"_key": 10182, "iconFile": "res:/ui/texture/corps/42_128_1.png"}
1318	10183	{"_key": 10183, "iconFile": "res:/ui/texture/corps/42_128_4.png"}
1319	10184	{"_key": 10184, "iconFile": "res:/ui/texture/corps/41_128_4.png"}
1320	10185	{"_key": 10185, "iconFile": "res:/ui/texture/corps/43_128_2.png"}
1321	10186	{"_key": 10186, "iconFile": "res:/ui/texture/corps/43_128_3.png"}
1322	10187	{"_key": 10187, "iconFile": "res:/ui/texture/corps/43_128_4.png"}
1323	10190	{"_key": 10190, "iconFile": "res:/ui/texture/icons/79_64_13.png"}
1324	10191	{"_key": 10191, "iconFile": "res:/ui/texture/corps/46_128_2.png"}
1325	10192	{"_key": 10192, "iconFile": "res:/ui/texture/corps/45_128_4.png"}
1326	10204	{"_key": 10204, "iconFile": "res:/UI/Asset/mannequin/bottomouter/3992_male_bottomOuter_PantsMilM01_Types_PantsMilM01_blackwaxed.png", "iconType": "png"}
1327	10205	{"_key": 10205, "iconFile": "res:/UI/Asset/mannequin/bottomouter/3997_female_bottomOuter_PantsMilF01_Types_PantsMilF01_blackgray.png", "iconType": "png"}
1328	10206	{"_key": 10206, "iconFile": "res:/UI/Asset/mannequin/bottomouter/3998_female_bottomOuter_SkirtMilF01_Types_SkirtMilF01_Gray.png", "iconType": "png"}
1329	10207	{"_key": 10207, "iconFile": "res:/UI/Asset/mannequin/bottomouter/3999_female_bottomOuter_SkirtMilF01_Types_SkirtMilF01_Blackwax.png", "iconType": "png"}
1330	10208	{"_key": 10208, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4078_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_Camo.png", "iconType": "png"}
1331	10209	{"_key": 10209, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4085_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_Black.png", "iconType": "png"}
1332	10210	{"_key": 10210, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/3958_female_Accessories_Glasses_Goggles_01_Types_goggles_01.png", "iconType": "png"}
1333	10214	{"_key": 10214, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/4037_female_Accessories_Glasses_EyeImp01_Types_EyeImpF01_RightDark.png", "iconType": "png"}
1334	10215	{"_key": 10215, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/4038_female_Accessories_Glasses_EyeImp01_Types_EyeImpF01_RightGray.png", "iconType": "png"}
1335	10216	{"_key": 10216, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/4039_female_Accessories_Glasses_EyeImp01_Types_EyeImpF01_RightGold.png", "iconType": "png"}
1336	10219	{"_key": 10219, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/4042_female_Accessories_Glasses_Monocle_01_Types_MonocleF01_RightGray.png", "iconType": "png"}
1337	10220	{"_key": 10220, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/4043_female_Accessories_Glasses_EyeImp01_Types_EyeImpF01_LeftDark.png", "iconType": "png"}
1338	10221	{"_key": 10221, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/4046_female_Accessories_Glasses_EyeImp01_Types_EyeImpF01_LeftGold.png", "iconType": "png"}
1339	10222	{"_key": 10222, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/4048_female_Accessories_Glasses_EyeImp01_Types_EyeImpF01_LeftGray.png", "iconType": "png"}
1340	10223	{"_key": 10223, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/4050_female_Accessories_Glasses_Monocle_01_Types_MonocleF01_LeftGold.png", "iconType": "png"}
1341	10224	{"_key": 10224, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/4052_female_Accessories_Glasses_Monocle_01_Types_MonocleF01_LeftGray.png", "iconType": "png"}
1342	10231	{"_key": 10231, "iconFile": "res:/UI/Asset/mannequin/hair_4086_947.png", "iconType": "png\\r"}
1343	10232	{"_key": 10232, "iconFile": "res:/UI/Asset/mannequin/hair_4088_949.png", "iconType": "png\\r"}
1344	10233	{"_key": 10233, "iconFile": "res:/UI/Asset/mannequin/hair_4096_1005.png", "iconType": "png\\r"}
1345	10234	{"_key": 10234, "iconFile": "res:/UI/Asset/mannequin/outer/4054_female_Outer_JacketMilF01_Types_JacketMilF01_blackgray.png", "iconType": "png"}
1346	10235	{"_key": 10235, "iconFile": "res:/UI/Asset/mannequin/outer/4097_male_outer_JacketMilM01_Types_JacketMilM01_blackyellow.png", "iconType": "png"}
1347	10236	{"_key": 10236, "iconFile": "res:/UI/Asset/mannequin/outer/4098_male_outer_JacketMilM02_Types_JacketMilM02_blackgray.png", "iconType": "png"}
1348	10237	{"_key": 10237, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4066_female_TopMiddle_ShirtQF01_Types_shirtqf01.png", "iconType": "png"}
1349	10238	{"_key": 10238, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4067_male_TopMiddle_ShirtQM01_Types_shirtqm01.png", "iconType": "png"}
1350	10239	{"_key": 10239, "iconFile": "res:/UI/Asset/mannequin/topouter/4057_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_black.png", "iconType": "png"}
1351	10240	{"_key": 10240, "iconFile": "res:/UI/Asset/mannequin/topouter/4058_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_blue.png", "iconType": "png"}
1352	10241	{"_key": 10241, "iconFile": "res:/UI/Asset/mannequin/topouter/4059_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_dust.png", "iconType": "png"}
1353	10242	{"_key": 10242, "iconFile": "res:/UI/Asset/mannequin/topouter/4060_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_olive.png", "iconType": "png"}
1354	10243	{"_key": 10243, "iconFile": "res:/UI/Asset/mannequin/topouter/4061_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_black.png", "iconType": "png"}
1355	10244	{"_key": 10244, "iconFile": "res:/UI/Asset/mannequin/topouter/4062_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_blue.png", "iconType": "png"}
1356	10245	{"_key": 10245, "iconFile": "res:/UI/Asset/mannequin/topouter/4063_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_dust.png", "iconType": "png"}
1357	10246	{"_key": 10246, "iconFile": "res:/UI/Asset/mannequin/topouter/4064_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_olive.png", "iconType": "png"}
1358	10247	{"_key": 10247, "iconFile": "res:/UI/Asset/mannequin/topouter/4065_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_lightgrey.png", "iconType": "png"}
1359	10248	{"_key": 10248, "iconFile": "res:/UI/Asset/mannequin/topouter/4068_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_ishukone.png", "iconType": "png"}
1360	10249	{"_key": 10249, "iconFile": "res:/UI/Asset/mannequin/outer/3975_female_Outer_JacketMilF02_Types_JacketMilF02_blue.png", "iconType": "png"}
1361	10250	{"_key": 10250, "iconFile": "res:/UI/Asset/mannequin/feet/4002_female_Feet_BootsMilF01_Types_BootsMilF01_black.png", "iconType": "png"}
1362	10251	{"_key": 10251, "iconFile": "res:/UI/Asset/mannequin/feet/4003_female_Feet_BootsMilF02_Types_BootsMilF02_black.png", "iconType": "png"}
1363	10252	{"_key": 10252, "iconFile": "res:/UI/Asset/mannequin/feet/4004_female_Feet_BootsMilF03_Types_BootsMilF03_black.png", "iconType": "png"}
1364	10253	{"_key": 10253, "iconFile": "res:/UI/Asset/mannequin/feet/4008_male_Feet_BootsMilM01_Types_BootsMilM01_black.png", "iconType": "png"}
1365	10254	{"_key": 10254, "iconFile": "res:/UI/Asset/mannequin/feet/3966_male_Feet_BootsMilM02_Types_BootsMilM02_black.png", "iconType": "png"}
1366	10255	{"_key": 10255, "iconFile": "res:/UI/Asset/mannequin/feet/4001_male_Feet_BootsMilM03_Types_BootsMilM03_black.png", "iconType": "png"}
1367	10256	{"_key": 10256, "iconFile": "res:/ui/texture/icons/65_128_3.png"}
1368	10257	{"_key": 10257, "iconFile": "res:/UI/netres/mission_content/arc_npe.png"}
1369	10545	{"_key": 10545, "iconFile": "res:/UI/Asset/mannequin/bottomouter/3992_male_bottomOuter_PantsMilM01_Types_PantsMilM01_blackwaxed.png", "iconType": "png"}
1370	10546	{"_key": 10546, "iconFile": "res:/UI/Asset/mannequin/bottomouter/3997_female_bottomOuter_PantsMilF01_Types_PantsMilF01_blackgray.png", "iconType": "png"}
1371	10547	{"_key": 10547, "iconFile": "res:/UI/Asset/mannequin/bottomouter/3998_female_bottomOuter_SkirtMilF01_Types_SkirtMilF01_Gray.png", "iconType": "png"}
1372	10548	{"_key": 10548, "iconFile": "res:/UI/Asset/mannequin/bottomouter/3999_female_bottomOuter_SkirtMilF01_Types_SkirtMilF01_Blackwax.png", "iconType": "png"}
1373	10549	{"_key": 10549, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4078_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_Camo.png", "iconType": "png"}
1374	10550	{"_key": 10550, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4085_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_Black.png", "iconType": "png"}
1375	10551	{"_key": 10551, "iconFile": "res:/UI/Asset/mannequin/feet/3966_male_Feet_BootsMilM02_Types_BootsMilM02_black.png", "iconType": "png"}
1376	10552	{"_key": 10552, "iconFile": "res:/UI/Asset/mannequin/feet/4001_male_Feet_BootsMilM03_Types_BootsMilM03_black.png", "iconType": "png"}
1377	10553	{"_key": 10553, "iconFile": "res:/UI/Asset/mannequin/feet/4002_female_Feet_BootsMilF01_Types_BootsMilF01_black.png", "iconType": "png"}
1378	10554	{"_key": 10554, "iconFile": "res:/UI/Asset/mannequin/feet/4003_female_Feet_BootsMilF02_Types_BootsMilF02_black.png", "iconType": "png"}
1379	10555	{"_key": 10555, "iconFile": "res:/UI/Asset/mannequin/feet/4004_female_Feet_BootsMilF03_Types_BootsMilF03_black.png", "iconType": "png"}
1380	10556	{"_key": 10556, "iconFile": "res:/UI/Asset/mannequin/feet/4008_male_Feet_BootsMilM01_Types_BootsMilM01_black.png", "iconType": "png"}
1381	10557	{"_key": 10557, "iconFile": "res:/UI/Asset/mannequin/Female_Accessories_Glasses_EyeImp01_Types_EyeImpF01_LeftDark.png", "iconType": "png\\r"}
1382	10558	{"_key": 10558, "iconFile": "res:/UI/Asset/mannequin/Female_Accessories_Glasses_EyeImp01_Types_EyeImpF01_LeftGold.png", "iconType": "png\\r"}
1383	10559	{"_key": 10559, "iconFile": "res:/UI/Asset/mannequin/Female_Accessories_Glasses_EyeImp01_Types_EyeImpF01_LeftGray.png", "iconType": "png\\r"}
1384	10560	{"_key": 10560, "iconFile": "res:/UI/Asset/mannequin/Female_Accessories_Glasses_EyeImp01_Types_EyeImpF01_RightDark.png", "iconType": "png\\r"}
1385	10561	{"_key": 10561, "iconFile": "res:/UI/Asset/mannequin/Female_Accessories_Glasses_EyeImp01_Types_EyeImpF01_RightGold.png", "iconType": "png\\r"}
1386	10562	{"_key": 10562, "iconFile": "res:/UI/Asset/mannequin/Female_Accessories_Glasses_EyeImp01_Types_EyeImpF01_RightGray.png", "iconType": "png\\r"}
1387	10563	{"_key": 10563, "iconFile": "res:/UI/Asset/mannequin/Female_Accessories_Glasses_Goggles_01_Types_goggles_01.png", "iconType": "png\\r"}
1388	10564	{"_key": 10564, "iconFile": "res:/UI/Asset/mannequin/Female_Accessories_Glasses_Monocle_01_Types_MonocleF01_LeftGold.png", "iconType": "png\\r"}
1389	10565	{"_key": 10565, "iconFile": "res:/UI/Asset/mannequin/Female_Accessories_Glasses_Monocle_01_Types_MonocleF01_LeftGray.png", "iconType": "png\\r"}
1390	10566	{"_key": 10566, "iconFile": "res:/UI/Asset/mannequin/Female_Accessories_Glasses_Monocle_01_Types_MonocleF01_RightGold.png", "iconType": "png\\r"}
1391	10567	{"_key": 10567, "iconFile": "res:/UI/Asset/mannequin/Female_Accessories_Glasses_Monocle_01_Types_MonocleF01_RightGray.png", "iconType": "png\\r"}
1392	10568	{"_key": 10568, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4016_female_bottomOuter_PantsMilF01_Types_PantsMilF01_black.png", "iconType": "png"}
1393	10569	{"_key": 10569, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4017_female_bottomOuter_PantsMilF01_Types_PantsMilF01_blackbluegold.png", "iconType": "png"}
1394	10570	{"_key": 10570, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4018_female_bottomOuter_PantsMilF01_Types_PantsMilF01_blackgold.png", "iconType": "png"}
1395	10571	{"_key": 10571, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4019_female_bottomOuter_PantsMilF01_Types_PantsMilF01_blackgoldline.png", "iconType": "png"}
1396	10572	{"_key": 10572, "iconFile": "res:/UI/Asset/mannequin/bottomouter/3997_female_bottomOuter_PantsMilF01_Types_PantsMilF01_blackgray.png", "iconType": "png"}
1397	10573	{"_key": 10573, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4020_female_bottomOuter_PantsMilF01_Types_PantsMilF01_blackredgold.png", "iconType": "png"}
1398	10574	{"_key": 10574, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4021_female_bottomOuter_PantsMilF01_Types_PantsMilF01_blacksilver.png", "iconType": "png"}
1399	10575	{"_key": 10575, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4022_female_bottomOuter_PantsMilF01_Types_PantsMilF01_gold.png", "iconType": "png"}
1400	10576	{"_key": 10576, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4026_female_bottomOuter_PantsMilF01_Types_PantsMilF01_matblue.png", "iconType": "png"}
1401	10577	{"_key": 10577, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4028_female_bottomOuter_PantsMilF01_Types_PantsMilF01_matgreen.png", "iconType": "png"}
1402	10578	{"_key": 10578, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4030_female_bottomOuter_PantsMilF01_Types_PantsMilF01_matred.png", "iconType": "png"}
1403	10579	{"_key": 10579, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4032_female_bottomOuter_PantsMilF01_Types_PantsMilF01_silver.png", "iconType": "png"}
1404	10580	{"_key": 10580, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4033_female_bottomOuter_SkirtMilF01_Types_SkirtMilF01_blackleather.png", "iconType": "png"}
1405	10581	{"_key": 10581, "iconFile": "res:/UI/Asset/mannequin/bottomouter/3999_female_bottomOuter_SkirtMilF01_Types_SkirtMilF01_Blackwax.png", "iconType": "png"}
1406	10582	{"_key": 10582, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4034_female_bottomOuter_SkirtMilF01_Types_SkirtMilF01_brownleather.png", "iconType": "png"}
1407	10583	{"_key": 10583, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4035_female_bottomOuter_SkirtMilF01_Types_SkirtMilF01_graphite.png", "iconType": "png"}
1408	10584	{"_key": 10584, "iconFile": "res:/UI/Asset/mannequin/bottomouter/3998_female_bottomOuter_SkirtMilF01_Types_SkirtMilF01_Gray.png", "iconType": "png"}
1409	10585	{"_key": 10585, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4036_female_bottomOuter_SkirtMilF01_Types_SkirtMilF01_greengold.png", "iconType": "png"}
1410	10586	{"_key": 10586, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4069_female_bottomOuter_SkirtMilF01_Types_SkirtMilF01_marine.png", "iconType": "png"}
1411	10587	{"_key": 10587, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4070_female_bottomOuter_SkirtMilF01_Types_SkirtMilF01_matblack.png", "iconType": "png"}
1412	10588	{"_key": 10588, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4071_female_bottomOuter_SkirtMilF01_Types_SkirtMilF01_matblue.png", "iconType": "png"}
1413	10589	{"_key": 10589, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4072_female_bottomOuter_SkirtMilF01_Types_SkirtMilF01_matred.png", "iconType": "png"}
1414	10590	{"_key": 10590, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4073_female_bottomOuter_SkirtMilF01_Types_SkirtMilF01_redgold.png", "iconType": "png"}
1415	10591	{"_key": 10591, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4074_female_bottomOuter_SkirtMilF01_Types_SkirtMilF01_silver.png", "iconType": "png"}
1416	10592	{"_key": 10592, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4075_female_bottomOuter_SkirtMilF01_Types_SkirtMilF01_white.png", "iconType": "png"}
1417	10593	{"_key": 10593, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4085_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_Black.png", "iconType": "png"}
1418	10594	{"_key": 10594, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4076_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_blackred.png", "iconType": "png"}
1419	10595	{"_key": 10595, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4101_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_blackwhite.png", "iconType": "png"}
1420	10596	{"_key": 10596, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4102_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_blue.png", "iconType": "png"}
1421	10597	{"_key": 10597, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4078_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_Camo.png", "iconType": "png"}
1422	10598	{"_key": 10598, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4103_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_graphite.png", "iconType": "png"}
1423	10599	{"_key": 10599, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4104_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_gray.png", "iconType": "png"}
1424	10600	{"_key": 10600, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4105_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_graystripes.png", "iconType": "png"}
1425	10601	{"_key": 10601, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4106_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_green.png", "iconType": "png"}
1426	10602	{"_key": 10602, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4107_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_greenblack.png", "iconType": "png"}
1427	10603	{"_key": 10603, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4108_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_greenstripes.png", "iconType": "png"}
1428	10604	{"_key": 10604, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4109_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_khaki.png", "iconType": "png"}
1429	10605	{"_key": 10605, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4110_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_marine.png", "iconType": "png"}
1430	10606	{"_key": 10606, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4111_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_matblack.png", "iconType": "png"}
1431	10607	{"_key": 10607, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4112_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_red.png", "iconType": "png"}
1432	10608	{"_key": 10608, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4113_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_redleather.png", "iconType": "png"}
1433	10609	{"_key": 10609, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4114_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_redstripes.png", "iconType": "png"}
1434	10610	{"_key": 10610, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4115_female_bottomOuter_SkirtMilF02_Types_SkirtMilF02_whitestripes.png", "iconType": "png"}
1435	10612	{"_key": 10612, "iconFile": "res:/UI/Asset/mannequin/feet/4116_female_Feet_BootsMilF01_Types_BootsMilF01_blackgold.png", "iconType": "png"}
1436	10613	{"_key": 10613, "iconFile": "res:/UI/Asset/mannequin/feet/4117_female_Feet_BootsMilF01_Types_BootsMilF01_blackred.png", "iconType": "png"}
1437	10614	{"_key": 10614, "iconFile": "res:/UI/Asset/mannequin/feet/4118_female_Feet_BootsMilF01_Types_BootsMilF01_blue.png", "iconType": "png"}
1438	10615	{"_key": 10615, "iconFile": "res:/UI/Asset/mannequin/feet/4119_female_Feet_BootsMilF01_Types_BootsMilF01_gold.png", "iconType": "png"}
1439	10616	{"_key": 10616, "iconFile": "res:/UI/Asset/mannequin/feet/4120_female_Feet_BootsMilF01_Types_BootsMilF01_graphwhite.png", "iconType": "png"}
1440	10617	{"_key": 10617, "iconFile": "res:/UI/Asset/mannequin/feet/4121_female_Feet_BootsMilF01_Types_BootsMilF01_greenblack.png", "iconType": "png"}
1441	10618	{"_key": 10618, "iconFile": "res:/UI/Asset/mannequin/feet/4122_female_Feet_BootsMilF01_Types_BootsMilF01_matblack.png", "iconType": "png"}
1442	10619	{"_key": 10619, "iconFile": "res:/UI/Asset/mannequin/feet/4123_female_Feet_BootsMilF01_Types_BootsMilF01_matred.png", "iconType": "png"}
1443	10620	{"_key": 10620, "iconFile": "res:/UI/Asset/mannequin/feet/4124_female_Feet_BootsMilF01_Types_BootsMilF01_red.png", "iconType": "png"}
1444	10621	{"_key": 10621, "iconFile": "res:/UI/Asset/mannequin/feet/4125_female_Feet_BootsMilF01_Types_BootsMilF01_silver.png", "iconType": "png"}
1445	10622	{"_key": 10622, "iconFile": "res:/UI/Asset/mannequin/feet/4126_female_Feet_BootsMilF01_Types_BootsMilF01_turquoise.png", "iconType": "png"}
1446	10624	{"_key": 10624, "iconFile": "res:/UI/Asset/mannequin/feet/4127_female_Feet_BootsMilF02_Types_BootsMilF02_blackgold.png", "iconType": "png"}
1447	10625	{"_key": 10625, "iconFile": "res:/UI/Asset/mannequin/feet/4128_female_Feet_BootsMilF02_Types_BootsMilF02_brown.png", "iconType": "png"}
1448	10626	{"_key": 10626, "iconFile": "res:/UI/Asset/mannequin/feet/4129_female_Feet_BootsMilF02_Types_BootsMilF02_matbrown.png", "iconType": "png"}
1449	10627	{"_key": 10627, "iconFile": "res:/UI/Asset/mannequin/feet/4130_female_Feet_BootsMilF02_Types_BootsMilF02_matgray.png", "iconType": "png"}
1450	10628	{"_key": 10628, "iconFile": "res:/UI/Asset/mannequin/feet/4131_female_Feet_BootsMilF02_Types_BootsMilF02_red.png", "iconType": "png"}
1451	10630	{"_key": 10630, "iconFile": "res:/UI/Asset/mannequin/feet/4132_female_Feet_BootsMilF03_Types_BootsMilF03_blackwhite.png", "iconType": "png"}
1452	10631	{"_key": 10631, "iconFile": "res:/UI/Asset/mannequin/feet/4133_female_Feet_BootsMilF03_Types_BootsMilF03_brownblack.png", "iconType": "png"}
1453	10632	{"_key": 10632, "iconFile": "res:/UI/Asset/mannequin/feet/4134_female_Feet_BootsMilF03_Types_BootsMilF03_red.png", "iconType": "png"}
1454	10633	{"_key": 10633, "iconFile": "res:/UI/Asset/mannequin/feet/4135_female_Feet_BootsMilF03_Types_BootsMilF03_whiteblack.png", "iconType": "png"}
1455	10634	{"_key": 10634, "iconFile": "res:/UI/Asset/mannequin/Female_hair_Hair_CurlyShoulderLength_01_Types_hair_curlyshoulderlength_01.png", "iconType": "png\\r"}
1456	10635	{"_key": 10635, "iconFile": "res:/UI/Asset/mannequin/Female_hair_Hair_ShortPixieTop_01_Types_hair_shortpixietop_01.png", "iconType": "png\\r"}
1457	10636	{"_key": 10636, "iconFile": "res:/UI/Asset/mannequin/outer/4136_female_Outer_JacketMilF01_Types_JacketMilF01_black.png", "iconType": "png"}
1458	10638	{"_key": 10638, "iconFile": "res:/UI/Asset/mannequin/outer/4137_female_Outer_JacketMilF01_Types_JacketMilF01_graphite.png", "iconType": "png"}
1459	10639	{"_key": 10639, "iconFile": "res:/UI/Asset/mannequin/outer/4138_female_Outer_JacketMilF01_Types_JacketMilF01_greengold.png", "iconType": "png"}
1460	10640	{"_key": 10640, "iconFile": "res:/UI/Asset/mannequin/outer/4139_female_Outer_JacketMilF01_Types_JacketMilF01_matblue.png", "iconType": "png"}
1461	10641	{"_key": 10641, "iconFile": "res:/UI/Asset/mannequin/outer/4140_female_Outer_JacketMilF01_Types_JacketMilF01_matred.png", "iconType": "png"}
1462	10642	{"_key": 10642, "iconFile": "res:/UI/Asset/mannequin/outer/4141_female_Outer_JacketMilF01_Types_JacketMilF01_redgold.png", "iconType": "png"}
1463	10643	{"_key": 10643, "iconFile": "res:/UI/Asset/mannequin/outer/4142_female_Outer_JacketMilF01_Types_JacketMilF01_silver.png", "iconType": "png"}
1464	10644	{"_key": 10644, "iconFile": "res:/UI/Asset/mannequin/outer/4143_female_Outer_JacketMilF02_Types_JacketMilF02_black.png", "iconType": "png"}
1465	10645	{"_key": 10645, "iconFile": "res:/UI/Asset/mannequin/outer/4144_female_Outer_JacketMilF02_Types_JacketMilF02_blackwhite.png", "iconType": "png"}
1466	10647	{"_key": 10647, "iconFile": "res:/UI/Asset/mannequin/outer/4145_female_Outer_JacketMilF02_Types_JacketMilF02_brown.png", "iconType": "png"}
1467	10648	{"_key": 10648, "iconFile": "res:/UI/Asset/mannequin/outer/4146_female_Outer_JacketMilF02_Types_JacketMilF02_goldblack.png", "iconType": "png"}
1468	10649	{"_key": 10649, "iconFile": "res:/UI/Asset/mannequin/outer/4149_female_Outer_JacketMilF02_Types_JacketMilF02_graphite.png", "iconType": "png"}
1469	10650	{"_key": 10650, "iconFile": "res:/UI/Asset/mannequin/outer/4150_female_Outer_JacketMilF02_Types_JacketMilF02_green.png", "iconType": "png"}
1470	10651	{"_key": 10651, "iconFile": "res:/UI/Asset/mannequin/outer/4151_female_Outer_JacketMilF02_Types_JacketMilF02_matblue.png", "iconType": "png"}
1471	10652	{"_key": 10652, "iconFile": "res:/UI/Asset/mannequin/outer/4152_female_Outer_JacketMilF02_Types_JacketMilF02_matred.png", "iconType": "png"}
1472	10653	{"_key": 10653, "iconFile": "res:/UI/Asset/mannequin/outer/4153_female_Outer_JacketMilF02_Types_JacketMilF02_red.png", "iconType": "png"}
1473	10654	{"_key": 10654, "iconFile": "res:/UI/Asset/mannequin/outer/4154_female_Outer_JacketMilF02_Types_JacketMilF02_turquoise.png", "iconType": "png"}
1474	10655	{"_key": 10655, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4201_female_TopMiddle_ShirtGF01_Types_ShirtGF01_black.png", "iconType": "png"}
1475	10656	{"_key": 10656, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4202_female_TopMiddle_ShirtGF01_Types_ShirtGF01_blue2.png", "iconType": "png"}
1476	10657	{"_key": 10657, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4203_female_TopMiddle_ShirtGF01_Types_ShirtGF01_brown.png", "iconType": "png"}
1477	10658	{"_key": 10658, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4204_female_TopMiddle_ShirtGF01_Types_ShirtGF01_cream.png", "iconType": "png"}
1478	10659	{"_key": 10659, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4205_female_TopMiddle_ShirtGF01_Types_ShirtGF01_darkblue.png", "iconType": "png"}
1479	10660	{"_key": 10660, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4206_female_TopMiddle_ShirtGF01_Types_ShirtGF01_darkred.png", "iconType": "png"}
1480	10661	{"_key": 10661, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4207_female_TopMiddle_ShirtGF01_Types_ShirtGF01_gray.png", "iconType": "png"}
1481	10662	{"_key": 10662, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4208_female_TopMiddle_ShirtGF01_Types_ShirtGF01_green.png", "iconType": "png"}
1482	10663	{"_key": 10663, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4209_female_TopMiddle_ShirtGF01_Types_ShirtGF01_khaki.png", "iconType": "png"}
1483	10664	{"_key": 10664, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4210_female_TopMiddle_ShirtGF01_Types_ShirtGF01_olive.png", "iconType": "png"}
1484	10665	{"_key": 10665, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4211_female_TopMiddle_ShirtGF01_Types_ShirtGF01_orange.png", "iconType": "png"}
1485	10666	{"_key": 10666, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4212_female_TopMiddle_ShirtGF01_Types_ShirtGF01_p_darkcaldari.png", "iconType": "png"}
1486	10667	{"_key": 10667, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4213_female_TopMiddle_ShirtGF01_Types_ShirtGF01_p_desertcamo.png", "iconType": "png"}
1487	10668	{"_key": 10668, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4214_female_TopMiddle_ShirtGF01_Types_ShirtGF01_red.png", "iconType": "png"}
1488	10669	{"_key": 10669, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4215_female_TopMiddle_ShirtGF01_Types_ShirtGF01_white.png", "iconType": "png"}
1489	10671	{"_key": 10671, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4216_female_TopMiddle_TanktopF01_Types_TanktopF01_black.png", "iconType": "png"}
1490	10672	{"_key": 10672, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4217_female_TopMiddle_TanktopF01_Types_TanktopF01_blackleather.png", "iconType": "png"}
1491	10673	{"_key": 10673, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4218_female_TopMiddle_TanktopF01_Types_TanktopF01_blue.png", "iconType": "png"}
1492	10674	{"_key": 10674, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4219_female_TopMiddle_TanktopF01_Types_TanktopF01_brown.png", "iconType": "png"}
1493	10675	{"_key": 10675, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4220_female_TopMiddle_TanktopF01_Types_TanktopF01_gray.png", "iconType": "png"}
1494	10676	{"_key": 10676, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4221_female_TopMiddle_TanktopF01_Types_TanktopF01_green.png", "iconType": "png"}
1495	10677	{"_key": 10677, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4222_female_TopMiddle_TanktopF01_Types_TanktopF01_orange.png", "iconType": "png"}
1496	10678	{"_key": 10678, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4223_female_TopMiddle_TanktopF01_Types_TanktopF01_p01.png", "iconType": "png"}
1497	10679	{"_key": 10679, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4224_female_TopMiddle_TanktopF01_Types_TanktopF01_p02.png", "iconType": "png"}
1498	10680	{"_key": 10680, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4225_female_TopMiddle_TanktopF01_Types_TanktopF01_p03.png", "iconType": "png"}
1499	10681	{"_key": 10681, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4226_female_TopMiddle_TanktopF01_Types_TanktopF01_p04.png", "iconType": "png"}
1500	10682	{"_key": 10682, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4227_female_TopMiddle_TanktopF01_Types_TanktopF01_p05.png", "iconType": "png"}
1501	10683	{"_key": 10683, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4228_female_TopMiddle_TanktopF01_Types_TanktopF01_p06.png", "iconType": "png"}
1502	10684	{"_key": 10684, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4229_female_TopMiddle_TanktopF01_Types_TanktopF01_p07.png", "iconType": "png"}
1503	10685	{"_key": 10685, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4230_female_TopMiddle_TanktopF01_Types_TanktopF01_p08.png", "iconType": "png"}
1504	10686	{"_key": 10686, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4231_female_TopMiddle_TanktopF01_Types_TanktopF01_red.png", "iconType": "png"}
1505	10687	{"_key": 10687, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4232_female_TopMiddle_TanktopF01_Types_TanktopF01_white.png", "iconType": "png"}
1506	10688	{"_key": 10688, "iconFile": "res:/UI/Asset/mannequin/topouter/4061_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_black.png", "iconType": "png"}
1507	10689	{"_key": 10689, "iconFile": "res:/UI/Asset/mannequin/topouter/4155_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_blackleather.png", "iconType": "png"}
1508	10690	{"_key": 10690, "iconFile": "res:/UI/Asset/mannequin/topouter/4156_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_blackwhite.png", "iconType": "png"}
1509	10691	{"_key": 10691, "iconFile": "res:/UI/Asset/mannequin/topouter/4062_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_blue.png", "iconType": "png"}
1510	10692	{"_key": 10692, "iconFile": "res:/UI/Asset/mannequin/topouter/4063_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_dust.png", "iconType": "png"}
1511	10693	{"_key": 10693, "iconFile": "res:/UI/Asset/mannequin/topouter/4157_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_gold.png", "iconType": "png"}
1512	10694	{"_key": 10694, "iconFile": "res:/UI/Asset/mannequin/topouter/4158_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_graphite.png", "iconType": "png"}
1513	10695	{"_key": 10695, "iconFile": "res:/UI/Asset/mannequin/topouter/4159_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_greensatin.png", "iconType": "png"}
1514	10696	{"_key": 10696, "iconFile": "res:/UI/Asset/mannequin/topouter/4065_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_lightgrey.png", "iconType": "png"}
1515	10697	{"_key": 10697, "iconFile": "res:/UI/Asset/mannequin/topouter/4160_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_matblack.png", "iconType": "png"}
1516	10698	{"_key": 10698, "iconFile": "res:/UI/Asset/mannequin/topouter/4161_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_matblue.png", "iconType": "png"}
1517	10699	{"_key": 10699, "iconFile": "res:/UI/Asset/mannequin/topouter/4162_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_matolive.png", "iconType": "png"}
1518	10700	{"_key": 10700, "iconFile": "res:/UI/Asset/mannequin/topouter/4064_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_olive.png", "iconType": "png"}
1519	10701	{"_key": 10701, "iconFile": "res:/UI/Asset/mannequin/topouter/4163_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_orangesatin.png", "iconType": "png"}
1520	10702	{"_key": 10702, "iconFile": "res:/UI/Asset/mannequin/topouter/4164_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_redsatin.png", "iconType": "png"}
1521	10703	{"_key": 10703, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/3958_female_Accessories_Glasses_Goggles_01_Types_goggles_01.png", "iconType": "png"}
1522	10704	{"_key": 10704, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/3958_female_Accessories_Glasses_Goggles_01_Types_goggles_01.png", "iconType": "png"}
1523	10736	{"_key": 10736, "iconFile": "res:/UI/Asset/mannequin/hair_4086_947.png", "iconType": "png\\r"}
1524	10737	{"_key": 10737, "iconFile": "res:/UI/Asset/mannequin/hair_4088_949.png", "iconType": "png\\r"}
1525	10738	{"_key": 10738, "iconFile": "res:/UI/Asset/mannequin/hair_4096_1005.png", "iconType": "png\\r"}
1526	10739	{"_key": 10739, "iconFile": "res:/UI/Asset/mannequin/Male_Accessories_Glasses_EyeImp01_Types_EyeImpM01_LeftDark.png", "iconType": "png\\r"}
1527	10740	{"_key": 10740, "iconFile": "res:/UI/Asset/mannequin/Male_Accessories_Glasses_EyeImp01_Types_EyeImpM01_LeftGold.png", "iconType": "png\\r"}
1528	10741	{"_key": 10741, "iconFile": "res:/UI/Asset/mannequin/Male_Accessories_Glasses_EyeImp01_Types_EyeImpM01_LeftGray.png", "iconType": "png\\r"}
1529	10742	{"_key": 10742, "iconFile": "res:/UI/Asset/mannequin/Male_Accessories_Glasses_EyeImp01_Types_EyeImpM01_RightDark.png", "iconType": "png\\r"}
1530	10743	{"_key": 10743, "iconFile": "res:/UI/Asset/mannequin/Male_Accessories_Glasses_EyeImp01_Types_EyeImpM01_RightGold.png", "iconType": "png\\r"}
1531	10744	{"_key": 10744, "iconFile": "res:/UI/Asset/mannequin/Male_Accessories_Glasses_EyeImp01_Types_EyeImpM01_RightGray.png", "iconType": "png\\r"}
1532	10745	{"_key": 10745, "iconFile": "res:/UI/Asset/mannequin/Male_Accessories_Glasses_Goggles_01_Types_goggles_01.png", "iconType": "png\\r"}
1533	10746	{"_key": 10746, "iconFile": "res:/UI/Asset/mannequin/Male_Accessories_Glasses_Monocle_01_Types_MonocleM01_LeftGold.png", "iconType": "png\\r"}
1534	10747	{"_key": 10747, "iconFile": "res:/UI/Asset/mannequin/Male_Accessories_Glasses_Monocle_01_Types_MonocleM01_LefttGray.png", "iconType": "png\\r"}
1535	10748	{"_key": 10748, "iconFile": "res:/UI/Asset/mannequin/Male_Accessories_Glasses_Monocle_01_Types_MonocleM01_RightGold.png", "iconType": "png\\r"}
1536	10749	{"_key": 10749, "iconFile": "res:/UI/Asset/mannequin/Male_Accessories_Glasses_Monocle_01_Types_MonocleM01_RightGray.png", "iconType": "png\\r"}
1537	10750	{"_key": 10750, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4165_male_bottomOuter_PantsMilM01_Types_PantsMilM01_black.png", "iconType": "png"}
1538	10751	{"_key": 10751, "iconFile": "res:/UI/Asset/mannequin/bottomouter/3992_male_bottomOuter_PantsMilM01_Types_PantsMilM01_blackwaxed.png", "iconType": "png"}
1539	10752	{"_key": 10752, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4166_male_bottomOuter_PantsMilM01_Types_PantsMilM01_blue.png", "iconType": "png"}
1540	10753	{"_key": 10753, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4167_male_bottomOuter_PantsMilM01_Types_PantsMilM01_goldblack.png", "iconType": "png"}
1541	10754	{"_key": 10754, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4168_male_bottomOuter_PantsMilM01_Types_PantsMilM01_grayblack.png", "iconType": "png"}
1542	10755	{"_key": 10755, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4169_male_bottomOuter_PantsMilM01_Types_PantsMilM01_p_browncamo.png", "iconType": "png"}
1543	10756	{"_key": 10756, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4170_male_bottomOuter_PantsMilM01_Types_PantsMilM01_p_greencamo.png", "iconType": "png"}
1544	10757	{"_key": 10757, "iconFile": "res:/UI/Asset/mannequin/bottomouter/4171_male_bottomOuter_PantsMilM01_Types_PantsMilM01_redblack.png", "iconType": "png"}
1545	10758	{"_key": 10758, "iconFile": "res:/UI/Asset/mannequin/Male_Feet_BootsMilM01_Types_BootsMilM01_black.png", "iconType": "png\\r"}
1546	10759	{"_key": 10759, "iconFile": "res:/UI/Asset/mannequin/feet/4172_male_Feet_BootsMilM01_Types_BootsMilM01_trueblack.png", "iconType": "png"}
1547	10760	{"_key": 10760, "iconFile": "res:/UI/Asset/mannequin/feet/4173_male_Feet_BootsMilM01_Types_BootsMilM01_wornbrown.png", "iconType": "png"}
1548	10762	{"_key": 10762, "iconFile": "res:/UI/Asset/mannequin/feet/4174_male_Feet_BootsMilM02_Types_BootsMilM02_brown.png", "iconType": "png"}
1549	10763	{"_key": 10763, "iconFile": "res:/UI/Asset/mannequin/feet/4175_male_Feet_BootsMilM02_Types_BootsMilM02_gray.png", "iconType": "png"}
1550	10764	{"_key": 10764, "iconFile": "res:/UI/Asset/mannequin/feet/4176_male_Feet_BootsMilM02_Types_BootsMilM02_tan.png", "iconType": "png"}
1551	10765	{"_key": 10765, "iconFile": "res:/UI/Asset/mannequin/Male_Feet_BootsMilM03_Types_BootsMilM03_black.png", "iconType": "png\\r"}
1552	10766	{"_key": 10766, "iconFile": "res:/UI/Asset/mannequin/feet/4177_male_Feet_BootsMilM03_Types_BootsMilM03_brown.png", "iconType": "png"}
1553	10767	{"_key": 10767, "iconFile": "res:/UI/Asset/mannequin/feet/4178_male_Feet_BootsMilM03_Types_BootsMilM03_gray.png", "iconType": "png"}
1554	10768	{"_key": 10768, "iconFile": "res:/UI/Asset/mannequin/feet/4179_male_Feet_BootsMilM03_Types_BootsMilM03_tan.png", "iconType": "png"}
1555	10769	{"_key": 10769, "iconFile": "res:/UI/Asset/mannequin/Male_hair_Hair_Stubble_01_Types_Hair_Stubble_01.png", "iconType": "png\\r"}
1556	10771	{"_key": 10771, "iconFile": "res:/UI/Asset/mannequin/outer/4244_male_outer_JacketMilM01_Types_JacketMilM01_green.png", "iconType": "png"}
1557	10772	{"_key": 10772, "iconFile": "res:/UI/Asset/mannequin/outer/4245_male_outer_JacketMilM01_Types_JacketMilM01_silver.png", "iconType": "png"}
1558	10773	{"_key": 10773, "iconFile": "res:/UI/Asset/mannequin/outer/4233_male_outer_JacketMilM02_Types_JacketMilM02_black.png", "iconType": "png"}
1559	10775	{"_key": 10775, "iconFile": "res:/UI/Asset/mannequin/outer/4234_male_outer_JacketMilM02_Types_JacketMilM02_greengold.png", "iconType": "png"}
1560	10776	{"_key": 10776, "iconFile": "res:/UI/Asset/mannequin/outer/4235_male_outer_JacketMilM02_Types_JacketMilM02_matgraphite.png", "iconType": "png"}
1561	10777	{"_key": 10777, "iconFile": "res:/UI/Asset/mannequin/outer/4236_male_outer_JacketMilM02_Types_JacketMilM02_matgray.png", "iconType": "png"}
1562	10778	{"_key": 10778, "iconFile": "res:/UI/Asset/mannequin/outer/4237_male_outer_JacketMilM02_Types_JacketMilM02_matgreen.png", "iconType": "png"}
1563	10779	{"_key": 10779, "iconFile": "res:/UI/Asset/mannequin/outer/4238_male_outer_JacketMilM02_Types_JacketMilM02_redgold.png", "iconType": "png"}
1564	10780	{"_key": 10780, "iconFile": "res:/UI/Asset/mannequin/outer/4239_male_outer_JacketMilM02_Types_JacketMilM02_silver.png", "iconType": "png"}
1565	10781	{"_key": 10781, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4180_male_TopMiddle_ShirtGM01_Types_ShirtGM01_black.png", "iconType": "png"}
1566	10782	{"_key": 10782, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4181_male_TopMiddle_ShirtGM01_Types_ShirtGM01_blue2.png", "iconType": "png"}
1567	10783	{"_key": 10783, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4182_male_TopMiddle_ShirtGM01_Types_ShirtGM01_brown.png", "iconType": "png"}
1568	10784	{"_key": 10784, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4183_male_TopMiddle_ShirtGM01_Types_ShirtGM01_darkblue.png", "iconType": "png"}
1569	10785	{"_key": 10785, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4184_male_TopMiddle_ShirtGM01_Types_ShirtGM01_darkred.png", "iconType": "png"}
1570	10786	{"_key": 10786, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4185_male_TopMiddle_ShirtGM01_Types_ShirtGM01_khaki.png", "iconType": "png"}
1571	10787	{"_key": 10787, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4186_male_TopMiddle_ShirtGM01_Types_ShirtGM01_lightgray.png", "iconType": "png"}
1572	10788	{"_key": 10788, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4187_male_TopMiddle_ShirtGM01_Types_ShirtGM01_olive.png", "iconType": "png"}
1573	10789	{"_key": 10789, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4188_male_TopMiddle_ShirtGM01_Types_ShirtGM01_p_darkcaldari.png", "iconType": "png"}
1574	10790	{"_key": 10790, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4189_male_TopMiddle_ShirtGM01_Types_ShirtGM01_p_desertcamo.png", "iconType": "png"}
1575	10791	{"_key": 10791, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4190_male_TopMiddle_ShirtGM01_Types_ShirtGM01_white.png", "iconType": "png"}
1576	10793	{"_key": 10793, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4191_male_TopMiddle_TanktopM01_Types_TanktopM01_black.png", "iconType": "png"}
1577	10794	{"_key": 10794, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4192_male_TopMiddle_TanktopM01_Types_TanktopM01_blue.png", "iconType": "png"}
1578	10795	{"_key": 10795, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4193_male_TopMiddle_TanktopM01_Types_TanktopM01_brown.png", "iconType": "png"}
1579	10796	{"_key": 10796, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4194_male_TopMiddle_TanktopM01_Types_TanktopM01_gray.png", "iconType": "png"}
1580	10797	{"_key": 10797, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4195_male_TopMiddle_TanktopM01_Types_TanktopM01_green.png", "iconType": "png"}
1581	10798	{"_key": 10798, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4196_male_TopMiddle_TanktopM01_Types_TanktopM01_p01.png", "iconType": "png"}
1582	10799	{"_key": 10799, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4197_male_TopMiddle_TanktopM01_Types_TanktopM01_p02.png", "iconType": "png"}
1583	10800	{"_key": 10800, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4198_male_TopMiddle_TanktopM01_Types_TanktopM01_p03.png", "iconType": "png"}
1584	10801	{"_key": 10801, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4199_male_TopMiddle_TanktopM01_Types_TanktopM01_p04.png", "iconType": "png"}
1585	10802	{"_key": 10802, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4200_male_TopMiddle_TanktopM01_Types_TanktopM01_white.png", "iconType": "png"}
1586	10803	{"_key": 10803, "iconFile": "res:/UI/Asset/mannequin/topouter/4057_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_black.png", "iconType": "png"}
1587	10804	{"_key": 10804, "iconFile": "res:/UI/Asset/mannequin/topouter/4058_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_blue.png", "iconType": "png"}
1588	10805	{"_key": 10805, "iconFile": "res:/UI/Asset/mannequin/topouter/4059_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_dust.png", "iconType": "png"}
1589	10806	{"_key": 10806, "iconFile": "res:/UI/Asset/mannequin/topouter/4240_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_goldleather.png", "iconType": "png"}
1590	10807	{"_key": 10807, "iconFile": "res:/UI/Asset/mannequin/topouter/4241_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_gray.png", "iconType": "png"}
1591	10808	{"_key": 10808, "iconFile": "res:/UI/Asset/mannequin/topouter/4068_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_ishukone.png", "iconType": "png"}
1592	10809	{"_key": 10809, "iconFile": "res:/UI/Asset/mannequin/topouter/4060_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_olive.png", "iconType": "png"}
1593	10810	{"_key": 10810, "iconFile": "res:/UI/Asset/mannequin/topouter/4242_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_redblackleather.png", "iconType": "png"}
1594	10811	{"_key": 10811, "iconFile": "res:/UI/Asset/mannequin/topouter/4243_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_whiteblue.png", "iconType": "png"}
1595	10812	{"_key": 10812, "iconFile": "res:/UI/Asset/mannequin/outer/3975_female_Outer_JacketMilF02_Types_JacketMilF02_blue.png", "iconType": "png"}
1596	10813	{"_key": 10813, "iconFile": "res:/UI/Asset/mannequin/outer/4054_female_Outer_JacketMilF01_Types_JacketMilF01_blackgray.png", "iconType": "png"}
1597	10814	{"_key": 10814, "iconFile": "res:/UI/Asset/mannequin/outer/4097_male_outer_JacketMilM01_Types_JacketMilM01_blackyellow.png", "iconType": "png"}
1598	10815	{"_key": 10815, "iconFile": "res:/UI/Asset/mannequin/outer/4098_male_outer_JacketMilM02_Types_JacketMilM02_blackgray.png", "iconType": "png"}
1599	10816	{"_key": 10816, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4066_female_TopMiddle_ShirtQF01_Types_shirtqf01.png", "iconType": "png"}
1600	10817	{"_key": 10817, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4067_male_TopMiddle_ShirtQM01_Types_shirtqm01.png", "iconType": "png"}
1601	10818	{"_key": 10818, "iconFile": "res:/UI/Asset/mannequin/topouter/4057_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_black.png", "iconType": "png"}
1602	10819	{"_key": 10819, "iconFile": "res:/UI/Asset/mannequin/topouter/4058_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_blue.png", "iconType": "png"}
1603	10820	{"_key": 10820, "iconFile": "res:/UI/Asset/mannequin/topouter/4059_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_dust.png", "iconType": "png"}
1604	10821	{"_key": 10821, "iconFile": "res:/UI/Asset/mannequin/topouter/4060_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_olive.png", "iconType": "png"}
1605	10822	{"_key": 10822, "iconFile": "res:/UI/Asset/mannequin/topouter/4061_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_black.png", "iconType": "png"}
1606	10823	{"_key": 10823, "iconFile": "res:/UI/Asset/mannequin/topouter/4062_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_blue.png", "iconType": "png"}
1607	10824	{"_key": 10824, "iconFile": "res:/UI/Asset/mannequin/topouter/4063_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_dust.png", "iconType": "png"}
1608	10825	{"_key": 10825, "iconFile": "res:/UI/Asset/mannequin/topouter/4064_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_olive.png", "iconType": "png"}
1609	10826	{"_key": 10826, "iconFile": "res:/UI/Asset/mannequin/topouter/4065_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_lightgrey.png", "iconType": "png"}
1610	10827	{"_key": 10827, "iconFile": "res:/UI/Asset/mannequin/topouter/4068_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_ishukone.png", "iconType": "png"}
1611	10828	{"_key": 10828, "iconFile": "res:/UI/Texture/market/apparel_accessories_glasses_3958_1065.png", "iconType": "png"}
1612	10829	{"_key": 10829, "iconFile": "res:/UI/Texture/market/apparel_mens_topouter_4058_1000.png", "iconType": "png"}
1613	10830	{"_key": 10830, "iconFile": "res:/UI/Texture/market/apparel_womens_outer_4054_1011.png", "iconType": "png"}
1614	10831	{"_key": 10831, "iconFile": "res:/UI/Texture/Icons/aurcoin.png", "iconType": "png"}
1615	10833	{"_key": 10833, "iconFile": "res:/UI/Texture/Icons/ComprFuel_Gallente.png"}
1616	10834	{"_key": 10834, "iconFile": "res:/UI/Texture/Icons/ComprFuel_Caldari.png"}
1617	10835	{"_key": 10835, "iconFile": "res:/UI/Texture/Icons/ComprFuel_Amarr.png"}
1618	10836	{"_key": 10836, "iconFile": "res:/UI/Texture/Icons/ComprFuel_Minmatar.png"}
1619	10838	{"_key": 10838, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/4009_female_Accessories_Glasses_Monocle_01_Types_MonocleF01_RightGold.png", "iconType": "png"}
1620	10840	{"_key": 10840, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4366_female_TopMiddle_ShirtQF01_Types_shirtqf02.png", "iconType": "png"}
1621	10841	{"_key": 10841, "iconFile": "res:/UI/Asset/mannequin/topouter/4368_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_whiteblacknexon.png", "iconType": "png"}
1622	10842	{"_key": 10842, "iconFile": "res:/UI/Asset/mannequin/topmiddle/4365_male_TopMiddle_ShirtQM01_Types_shirtqm02.png", "iconType": "png"}
1623	10843	{"_key": 10843, "iconFile": "res:/UI/Asset/mannequin/topouter/4367_male_TopOuter_ShirtMilM01_Types_ShirtMilM01_whiteblacknexon.png", "iconType": "png"}
1624	10847	{"_key": 10847, "iconFile": "res:/UI/Texture/Icons/infantry_gear.png"}
1625	10848	{"_key": 10848, "iconFile": "res:/UI/Texture/Icons/dust_icon_eq_dropuplink.png"}
1626	10849	{"_key": 10849, "iconFile": "res:/UI/Texture/Icons/dust_icon_wpn_forgegun.png"}
1627	10850	{"_key": 10850, "iconFile": "res:/UI/Texture/Icons/dust_icon_eq_nanohive.png"}
1628	10851	{"_key": 10851, "iconFile": "res:/UI/Texture/Icons/dust_icon_dropsuit_logistics.png"}
1629	10852	{"_key": 10852, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_default.png"}
1630	10853	{"_key": 10853, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_prop_overdrive.png"}
1631	10854	{"_key": 10854, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_shield_shieldhardener.png"}
1632	10855	{"_key": 10855, "iconFile": "res:/UI/Texture/Icons/dust_icon_tur_railgun_s.png"}
1633	10856	{"_key": 10856, "iconFile": "res:/UI/Texture/Icons/dust_icon_tur_railgun_l.png"}
1634	10857	{"_key": 10857, "iconFile": "res:/UI/Texture/Icons/dust_icon_tur_blaster_l.png"}
1635	10858	{"_key": 10858, "iconFile": "res:/UI/Texture/Icons/dust_icon_tur_blaster_s.png"}
1636	10859	{"_key": 10859, "iconFile": "res:/UI/Texture/Icons/dust_icon_dropsuit_heavy.png"}
1637	10860	{"_key": 10860, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_armor_remotearmorrepair.png"}
1638	10861	{"_key": 10861, "iconFile": "res:/UI/Texture/Icons/dust_icon_wpn_scramblerpistol.png"}
1639	10862	{"_key": 10862, "iconFile": "res:/UI/Texture/Icons/dust_icon_wpn_grenade.png"}
1640	10863	{"_key": 10863, "iconFile": "res:/UI/Texture/Icons/dust_icon_wpn_miasmagrenade.png"}
1641	10864	{"_key": 10864, "iconFile": "res:/UI/Texture/Icons/dust_icon_skill.png"}
1642	10866	{"_key": 10866, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_unit_scanner.png"}
1643	10867	{"_key": 10867, "iconFile": "res:/UI/Texture/Icons/dust_icon_wpn_sinperrifle.png"}
1644	10868	{"_key": 10868, "iconFile": "res:/UI/Texture/Icons/dust_icon_dropsuit_scout.png"}
1645	10869	{"_key": 10869, "iconFile": "res:/UI/Texture/Icons/dust_icon_dropsuit_assult.png"}
1646	10870	{"_key": 10870, "iconFile": "res:/UI/Texture/Icons/dust_icon_dropsuit_default.png"}
1647	10871	{"_key": 10871, "iconFile": "res:/UI/Texture/Icons/dust_icon_wpn_assultrifle.png"}
1648	10872	{"_key": 10872, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_eng_mobilecru.png"}
1649	10873	{"_key": 10873, "iconFile": "res:/UI/Texture/Icons/dust_icon_wpn_rl_std.png"}
1650	10874	{"_key": 10874, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_bio_healthbooster.png"}
1651	10875	{"_key": 10875, "iconFile": "res:/UI/Texture/Icons/dust_icon_veh_mcc.png"}
1652	10876	{"_key": 10876, "iconFile": "res:/UI/Texture/Icons/dust_icon_inst_capacitor.png"}
1653	10877	{"_key": 10877, "iconFile": "res:/UI/Texture/Icons/dust_icon_inst_clonereserveunit.png"}
1654	10878	{"_key": 10878, "iconFile": "res:/UI/Texture/Icons/dust_icon_inst_default.png"}
1655	10879	{"_key": 10879, "iconFile": "res:/UI/Texture/Icons/dust_icon_inst_supplydepot.png"}
1656	10880	{"_key": 10880, "iconFile": "res:/UI/Texture/Icons/dust_icon_tur_missile_l.png"}
1657	10881	{"_key": 10881, "iconFile": "res:/UI/Texture/Icons/dust_icon_tur_missile_s.png"}
1658	10882	{"_key": 10882, "iconFile": "res:/UI/Texture/Icons/dust_icon_tur_default.png"}
1659	10883	{"_key": 10883, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_wpnupg_damagemodifier.png"}
1660	10884	{"_key": 10884, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_shield_shieldextender.png"}
1661	10885	{"_key": 10885, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_shield_shieldrecharger.png"}
1662	10886	{"_key": 10886, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_imp_movement.png"}
1663	10887	{"_key": 10887, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_bio_healthextender.png"}
1664	10888	{"_key": 10888, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_bio_healthregenerator.png"}
1665	10889	{"_key": 10889, "iconFile": "res:/UI/Texture/Icons/dust_icon_veh_lav_ca.png"}
1666	10890	{"_key": 10890, "iconFile": "res:/UI/Texture/Icons/dust_icon_wpn_submachinegun.png"}
1667	10891	{"_key": 10891, "iconFile": "res:/UI/Texture/Icons/dust_icon_wpn_hmg_std.png"}
1668	10892	{"_key": 10892, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_eng_cpuupgrade.png"}
1669	10893	{"_key": 10893, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_eng_pgupgrade.png"}
1670	10894	{"_key": 10894, "iconFile": "res:/UI/Texture/Icons/dust_icon_wpn_swarmlauncher.png"}
1671	10895	{"_key": 10895, "iconFile": "res:/UI/Texture/Icons/dust_icon_veh_hav_ca.png"}
1672	10896	{"_key": 10896, "iconFile": "res:/UI/Texture/Icons/dust_icon_eq_nanohive_armor.png"}
1673	10897	{"_key": 10897, "iconFile": "res:/UI/Texture/Icons/dust_icon_eq_remotearmorrepair.png"}
1674	10898	{"_key": 10898, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_eng_powerdiagnostic.png"}
1675	10899	{"_key": 10899, "iconFile": "res:/UI/Texture/Icons/dust_icon_veh_lav_ga.png"}
1676	10900	{"_key": 10900, "iconFile": "res:/UI/Texture/Icons/dust_icon_tur_blaster.png"}
1677	10901	{"_key": 10901, "iconFile": "res:/UI/Texture/Icons/dust_icon_veh_rdv.png"}
1678	10902	{"_key": 10902, "iconFile": "res:/UI/Texture/Icons/dust_icon_veh_dropship_ca.png"}
1679	10903	{"_key": 10903, "iconFile": "res:/UI/Texture/Icons/dust_icon_veh_dropship_ga.png"}
1680	10904	{"_key": 10904, "iconFile": "res:/UI/Texture/Icons/dust_icon_booster_skillgain.png"}
1681	10905	{"_key": 10905, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_prop_afterburner.png"}
1682	10906	{"_key": 10906, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_armor_armorplates.png"}
1683	10907	{"_key": 10907, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_armor_lightweightchassis.png"}
1684	10908	{"_key": 10908, "iconFile": "res:/UI/Texture/Icons/dust_icon_wpn_locusgrenade.png"}
1685	10909	{"_key": 10909, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_eng_reactorcoreunit.png"}
1686	10910	{"_key": 10910, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_armor_armorrepair.png"}
1687	10911	{"_key": 10911, "iconFile": "res:/UI/Texture/Icons/dust_icon_wpn_avgrenade.png"}
1688	10912	{"_key": 10912, "iconFile": "res:/UI/Texture/Icons/dust_icon_veh_hav_ga.png"}
1689	10913	{"_key": 10913, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_shield_remoteshieldrecharger.png"}
1690	10914	{"_key": 10914, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_shield_shieldbooster.png"}
1691	10915	{"_key": 10915, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_armor_resistance.png"}
1692	10916	{"_key": 10916, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_shield_resistance.png"}
1693	10917	{"_key": 10917, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_eng_damagecontrol.png"}
1694	10926	{"_key": 10926, "iconFile": "res:/UI/Texture/Icons/dust_icon_wpn_shotgun.png"}
1695	10927	{"_key": 10927, "iconFile": "res:/UI/Texture/Icons/dust_icon_wpn_laserrifle.png"}
1696	10928	{"_key": 10928, "iconFile": "res:/UI/Texture/Icons/dust_icon_eq_naniteinjector.png"}
1697	10929	{"_key": 10929, "iconFile": "res:/UI/Texture/Icons/dust_icon_wpn_heavymachinegun.png"}
1698	10930	{"_key": 10930, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_shield_booster.png"}
1699	10932	{"_key": 10932, "iconFile": "res:/ui/texture/icons/105_32_46.png"}
1700	10933	{"_key": 10933, "iconFile": "res:/ui/texture/icons/105_32_47.png"}
1701	10934	{"_key": 10934, "iconFile": "res:/ui/texture/icons/105_32_48.png"}
1702	10935	{"_key": 10935, "iconFile": "res:/ui/texture/icons/105_32_49.png"}
1703	10936	{"_key": 10936, "iconFile": "res:/UI/Texture/Icons/dust_icon_eq_remoteexplosive.png"}
1704	10937	{"_key": 10937, "iconFile": "res:/UI/Texture/Icons/dust_icon_wpn_massdriver.png"}
1705	10939	{"_key": 10939, "iconFile": "res:/UI/Texture/Icons/dust_icon_tur_missile.png"}
1706	10940	{"_key": 10940, "iconFile": "res:/ui/texture/icons/107_64_1.png"}
1707	10941	{"_key": 10941, "iconFile": "res:/ui/texture/icons/107_64_2.png"}
1708	10942	{"_key": 10942, "iconFile": "res:/ui/texture/icons/107_64_3.png"}
1709	10946	{"_key": 10946, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_codebreaker.png"}
1710	10947	{"_key": 10947, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_shield_regulator.png"}
1711	10948	{"_key": 10948, "iconFile": "res:/UI/Texture/Icons/dust_icon_aug_voicetransmitter.png"}
1712	20939	{"_key": 20939, "iconFile": "res:/ui/texture/icons/108_64_5.png"}
1713	20940	{"_key": 20940, "iconFile": "res:/ui/texture/icons/108_64_6.png"}
1714	20941	{"_key": 20941, "iconFile": "res:/ui/texture/icons/108_64_7.png"}
1715	20942	{"_key": 20942, "iconFile": "res:/ui/texture/icons/108_64_8.png"}
1716	20943	{"_key": 20943, "iconFile": "res:/ui/texture/icons/108_64_12.png"}
1717	20944	{"_key": 20944, "iconFile": "res:/ui/texture/icons/108_64_13.png"}
1718	20945	{"_key": 20945, "iconFile": "res:/ui/texture/icons/108_64_10.png"}
1719	20946	{"_key": 20946, "iconFile": "res:/ui/texture/icons/108_64_11.png"}
1720	20947	{"_key": 20947, "iconFile": "res:/ui/texture/icons/108_64_3.png"}
1721	20948	{"_key": 20948, "iconFile": "res:/ui/texture/icons/108_64_4.png"}
1722	20949	{"_key": 20949, "iconFile": "res:/ui/texture/icons/108_64_1.png"}
1723	20950	{"_key": 20950, "iconFile": "res:/ui/texture/icons/108_64_2.png"}
1724	20951	{"_key": 20951, "iconFile": "res:/ui/texture/icons/108_64_20.png"}
1725	20952	{"_key": 20952, "iconFile": "res:/ui/texture/icons/108_64_21.png"}
1726	20953	{"_key": 20953, "iconFile": "res:/ui/texture/icons/108_64_18.png"}
1727	20954	{"_key": 20954, "iconFile": "res:/ui/texture/icons/108_64_19.png"}
1728	20955	{"_key": 20955, "iconFile": "res:/ui/texture/icons/108_64_16.png"}
1729	20956	{"_key": 20956, "iconFile": "res:/ui/texture/icons/108_64_17.png"}
1730	20957	{"_key": 20957, "iconFile": "res:/ui/texture/icons/108_64_14.png"}
1731	20958	{"_key": 20958, "iconFile": "res:/ui/texture/icons/108_64_15.png"}
1732	20959	{"_key": 20959, "iconFile": "res:/UI/Texture/Icons/MarketIcon_16px_Amarr.png"}
1733	20966	{"_key": 20966, "iconFile": "res:/UI/Texture/Icons/MarketIcon_16px_Caldari.png"}
1734	20967	{"_key": 20967, "iconFile": "res:/UI/Texture/Icons/MarketIcon_16px_Gallente.png"}
1735	20968	{"_key": 20968, "iconFile": "res:/UI/Texture/Icons/MarketIcon_16px_Minmatar.png"}
1736	20969	{"_key": 20969, "iconFile": "res:/UI/Texture/Icons/94_64_9.png"}
1737	20970	{"_key": 20970, "iconFile": "res:/UI/Texture/Icons/53_64_16.png"}
1738	20971	{"_key": 20971, "iconFile": "res:/UI/Texture/Icons/108_64_22.png"}
1739	20973	{"_key": 20973, "iconFile": "res:/UI/Texture/Icons/Icon_64px_Fireworks.png"}
1740	20974	{"_key": 20974, "iconFile": "res:/UI/Texture/Icons/Icon_64px_NEO.png"}
1741	20976	{"_key": 20976, "iconFile": "res:/UI/Texture/Icons/DudeYourChin_64px_Icon.jpg"}
1742	20977	{"_key": 20977, "iconFile": "res:/UI/Asset/mannequin/feet/33064_female_Feet_BootsMilF02_Types_BootsMilF02_bootini.png", "iconType": "png"}
1743	20979	{"_key": 20979, "iconFile": "res:/UI/Asset/mannequin/topmiddle/33063_female_TopMiddle_ShirtQF01_Types_shirtredstarf01.png", "iconType": "png"}
1744	20980	{"_key": 20980, "iconFile": "res:/UI/Texture/Corps/algintal_core.png"}
1745	20981	{"_key": 20981, "iconFile": "res:/UI/Texture/Corps/amarr_templars.png"}
1746	20982	{"_key": 20982, "iconFile": "res:/UI/Asset/mannequin/topmiddle/33062_male_TopMiddle_ShirtQM01_Types_shirtredstarm01.png", "iconType": "png"}
1747	20984	{"_key": 20984, "iconFile": "res:/UI/Texture/Corps/arkombine.png"}
1748	20985	{"_key": 20985, "iconFile": "res:/UI/Texture/Corps/bragian_order.png"}
1749	20986	{"_key": 20986, "iconFile": "res:/UI/Texture/Corps/circle_of_huskarl.png"}
1750	20987	{"_key": 20987, "iconFile": "res:/UI/Texture/Corps/crux_special_tasks_group.png"}
1751	20988	{"_key": 20988, "iconFile": "res:/UI/Texture/Corps/osmon_surveillance.png"}
1752	20989	{"_key": 20989, "iconFile": "res:/UI/Texture/Corps/royal_uhlans.png"}
1753	20990	{"_key": 20990, "iconFile": "res:/UI/Texture/Corps/sanmatar_kelkoons.png"}
1754	20991	{"_key": 20991, "iconFile": "res:/UI/Texture/Corps/seituoda_taskforce.png"}
1755	20992	{"_key": 20992, "iconFile": "res:/UI/Texture/Corps/templis_dragonaurs.png"}
1756	20993	{"_key": 20993, "iconFile": "res:/UI/Texture/Corps/tronhadar_free_guard.png"}
1757	20994	{"_key": 20994, "iconFile": "res:/UI/Texture/Corps/villore_sec_ops.png"}
1758	20995	{"_key": 20995, "iconFile": "res:/UI/Texture/Corps/zumari_force_projection.png"}
1759	20996	{"_key": 20996, "iconFile": "res:/UI/Texture/Corps/default.png"}
1760	20997	{"_key": 20997, "iconFile": "res:/UI/Texture/Corps/imperial_guard.png"}
1761	21000	{"_key": 21000, "iconFile": "res:/UI/Texture/Icons/dust_icon_wpn_knife.png", "iconType": "png"}
1762	21001	{"_key": 21001, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_eng_rangeamplifier.png", "iconType": "png"}
1763	21002	{"_key": 21002, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_eng_precisionenhancer.png", "iconType": "png"}
1764	21003	{"_key": 21003, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_prop_boost.png", "iconType": "png"}
1765	21004	{"_key": 21004, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_scanning_activescanner.png", "iconType": "png"}
1766	21005	{"_key": 21005, "iconFile": "res:/UI/Texture/Icons/dust_icon_eq_activescanner.png", "iconType": "png"}
1767	21006	{"_key": 21006, "iconFile": "res:/UI/Texture/Icons/dust_icon_mod_eng_profiledampener.png", "iconType": "png"}
1768	21011	{"_key": 21011, "iconFile": "res:/UI/Asset/mannequin/Male_Accessories_Glasses_Monocle_M_T02_Types_Monocle_M_T02_black_right.png"}
1769	21012	{"_key": 21012, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/32853_female_Accessories_Glasses_Monocle_F_T02_Types_Monocle_F_T02_black_right.png"}
1770	21013	{"_key": 21013, "iconFile": "res:/UI/Asset/mannequin/topmiddle/33107_male_TopMiddle_ShirtQM01_Types_shirtqm03.png", "iconType": "png"}
1771	21014	{"_key": 21014, "iconFile": "res:/UI/Asset/mannequin/topmiddle/33109_female_TopMiddle_ShirtQF01_Types_shirtqf03.png", "iconType": "png"}
1772	21021	{"_key": 21021, "iconFile": "res:/UI/Texture/Icons/110_128_01.png"}
1773	21022	{"_key": 21022, "iconFile": "res:/UI/Texture/Icons/110_128_02.png"}
1774	21023	{"_key": 21023, "iconFile": "res:/UI/Texture/Icons/110_128_03.png"}
1775	21025	{"_key": 21025, "iconFile": "res:/ui/texture/icons/107_64_10.png"}
1776	21026	{"_key": 21026, "iconFile": "res:/ui/texture/icons/107_64_11.png"}
1777	21027	{"_key": 21027, "iconFile": "res:/ui/texture/icons/107_64_12.png"}
1778	21028	{"_key": 21028, "iconFile": "res:/UI/Texture/Icons/icons111_02.png"}
1779	21029	{"_key": 21029, "iconFile": "res:/UI/Texture/Icons/icons111_03.png"}
1780	21030	{"_key": 21030, "iconFile": "res:/UI/Texture/Icons/icons111_04.png"}
1781	21031	{"_key": 21031, "iconFile": "res:/UI/Texture/Icons/icons111_05.png"}
1782	21032	{"_key": 21032, "iconFile": "res:/UI/Texture/Icons/icons111_06.png"}
1783	21047	{"_key": 21047, "iconFile": "res:/UI/Texture/Icons/107_64_4.png"}
1784	21048	{"_key": 21048, "iconFile": "res:/UI/Asset/mannequin/tattoo_armleft/33377_male_tattoo_armleft_sleeve04__.png", "iconType": "png"}
1785	21050	{"_key": 21050, "iconFile": "res:/UI/Asset/mannequin/tattoo_armleft/33378_male_tattoo_armleft_sleeve05__.png", "iconType": "png"}
1786	21051	{"_key": 21051, "iconFile": "res:/UI/Asset/mannequin/tattoo_armleft/33379_male_tattoo_armleft_sleeve14__.png", "iconType": "png"}
1787	21052	{"_key": 21052, "iconFile": "res:/UI/Asset/mannequin/tattoo_armleft/33380_male_tattoo_armleft_sleeve08__.png", "iconType": "png"}
1788	21053	{"_key": 21053, "iconFile": "res:/UI/Asset/mannequin/tattoo_armright/33381_male_tattoo_armright_sleeve04__.png", "iconType": "png"}
1789	21054	{"_key": 21054, "iconFile": "res:/UI/Asset/mannequin/tattoo_armright/33382_male_tattoo_armright_sleeve05__.png", "iconType": "png"}
1790	21055	{"_key": 21055, "iconFile": "res:/UI/Asset/mannequin/tattoo_armright/33383_male_tattoo_armright_sleeve14__.png", "iconType": "png"}
1791	21056	{"_key": 21056, "iconFile": "res:/UI/Asset/mannequin/tattoo_armright/33384_male_tattoo_armright_sleeve08__.png", "iconType": "png"}
1792	21057	{"_key": 21057, "iconFile": "res:/UI/Texture/Icons/113_64_1.png"}
1793	21058	{"_key": 21058, "iconFile": "res:/UI/Texture/Icons/113_64_2.png"}
1794	21059	{"_key": 21059, "iconFile": "res:/UI/Texture/Icons/113_64_3.png"}
1795	21060	{"_key": 21060, "iconFile": "res:/ui/texture/icons/115_64_1.png"}
1796	21061	{"_key": 21061, "iconFile": "res:/ui/texture/icons/115_64_2.png"}
1797	21062	{"_key": 21062, "iconFile": "res:/ui/texture/icons/115_64_3.png"}
1798	21063	{"_key": 21063, "iconFile": "res:/ui/texture/icons/115_64_4.png"}
1799	21064	{"_key": 21064, "iconFile": "res:/ui/texture/icons/115_64_5.png"}
1800	21065	{"_key": 21065, "iconFile": "res:/ui/texture/icons/114_64_1.png"}
1801	21066	{"_key": 21066, "iconFile": "res:/ui/texture/icons/114_64_2.png"}
1802	21070	{"_key": 21070, "iconFile": "res:/UI/Asset/mannequin/topmiddle/33487_female_TopMiddle_ShirtQF01_Types_lvf01.png", "iconType": "png"}
1803	21071	{"_key": 21071, "iconFile": "res:/UI/Asset/mannequin/topmiddle/33488_male_TopMiddle_ShirtQM01_Types_lvm01.png", "iconType": "png"}
1804	21074	{"_key": 21074, "iconFile": "res:/ui/texture/icons/109_64_1.png"}
1805	21075	{"_key": 21075, "iconFile": "res:/ui/texture/icons/109_64_2.png"}
1806	21078	{"_key": 21078, "iconFile": "res:/UI/Asset/mannequin/makeup_armleft/33551_male_Makeup_ArmLeft_CyborgArmM01_L_Types_CyborgArmM01_L_White.png", "iconType": "png"}
1807	21080	{"_key": 21080, "iconFile": "res:/UI/Asset/mannequin/makeup_armleft/33549_female_Makeup_ArmLeft_CyborgArmF01_L_Types_CyborgArmF01_L_WhiteGray.png", "iconType": "png"}
1808	21081	{"_key": 21081, "iconFile": "res:/UI/Asset/mannequin/makeup_armright/33550_female_Makeup_ArmRight_CyborgArmF01_R_Types_CyborgArmF01_R_WhiteGray.png", "iconType": "png"}
1809	21082	{"_key": 21082, "iconFile": "res:/UI/Asset/mannequin/makeup_armright/33552_male_Makeup_ArmRight_CyborgArmM01_R_Types_CyborgArmM01_R_White.png", "iconType": "png"}
1810	21084	{"_key": 21084, "iconFile": "res:/UI/Texture/Icons/icons111_07.png"}
1811	21085	{"_key": 21085, "iconFile": "res:/UI/Texture/Icons/icons111_08.png"}
1812	21086	{"_key": 21086, "iconFile": "res:/UI/Texture/Icons/icons111_09.png"}
1813	21089	{"_key": 21089, "iconFile": "res:/UI/Asset/mannequin/topmiddle/33579_female_TopMiddle_ShirtQF01_Types_soerff01.png", "iconType": "png"}
1814	21090	{"_key": 21090, "iconFile": "res:/UI/Asset/mannequin/topmiddle/33578_male_TopMiddle_ShirtQM01_Types_soerfm01.png", "iconType": "png"}
1815	21092	{"_key": 21092, "iconFile": "res:/UI/Texture/Corps/state_peacekeepers.png"}
1816	21093	{"_key": 21093, "iconFile": "res:/UI/Texture/Corps/federal_marines.png"}
1817	21094	{"_key": 21094, "iconFile": "res:/UI/Texture/Corps/republic_command.png"}
1818	21095	{"_key": 21095, "iconFile": "res:/ui/texture/icons/107_64_14.png"}
1819	21096	{"_key": 21096, "iconFile": "res:/ui/texture/icons/107_64_13.png"}
1820	21097	{"_key": 21097, "iconFile": "res:/ui/texture/icons/107_64_16.png"}
1821	21098	{"_key": 21098, "iconFile": "res:/ui/texture/icons/107_64_15.png"}
1822	21100	{"_key": 21100, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33744_female_bottomOuter_PantsALF_01_Types_PantsALF_01_blackleather.png", "iconType": "png"}
1823	21101	{"_key": 21101, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33745_female_bottomOuter_PantsALF_01_Types_PantsALF_01_blackmatte.png", "iconType": "png"}
1824	21102	{"_key": 21102, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33746_female_bottomOuter_PantsALF_01_Types_PantsALF_01_brownpattern.png", "iconType": "png"}
1825	21103	{"_key": 21103, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33747_female_bottomOuter_PantsALF_01_Types_PantsALF_01_cream.png", "iconType": "png"}
1826	21104	{"_key": 21104, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33748_female_bottomOuter_PantsALF_01_Types_PantsALF_01_green.png", "iconType": "png"}
1827	21105	{"_key": 21105, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33749_female_bottomOuter_PantsALF_01_Types_PantsALF_01_gunpattern.png", "iconType": "png"}
1828	21106	{"_key": 21106, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33750_female_bottomOuter_PantsALF_01_Types_PantsALF_01_gunshiny.png", "iconType": "png"}
1829	21107	{"_key": 21107, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33751_female_bottomOuter_PantsALF_01_Types_PantsALF_01_navy.png", "iconType": "png"}
1830	21108	{"_key": 21108, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33752_female_bottomOuter_PantsALF_01_Types_PantsALF_01_red.png", "iconType": "png"}
1831	21109	{"_key": 21109, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33753_female_bottomOuter_PantsALF_01_Types_PantsALF_01_redleather.png", "iconType": "png"}
1832	21110	{"_key": 21110, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33754_female_bottomOuter_PantsSLF_01_Types_PantsSLF_01_black.png", "iconType": "png"}
1833	21111	{"_key": 21111, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33755_female_bottomOuter_PantsSLF_01_Types_PantsSLF_01_blue.png", "iconType": "png"}
1834	21112	{"_key": 21112, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33756_female_bottomOuter_PantsSLF_01_Types_PantsSLF_01_camo.png", "iconType": "png"}
1835	21113	{"_key": 21113, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33757_female_bottomOuter_PantsSLF_01_Types_PantsSLF_01_greyflat.png", "iconType": "png"}
1836	21114	{"_key": 21114, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33758_female_bottomOuter_PantsSLF_01_Types_PantsSLF_01_orangegloss.png", "iconType": "png"}
1837	21115	{"_key": 21115, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33759_female_bottomOuter_PantsSLF_01_Types_PantsSLF_01_red.png", "iconType": "png"}
1838	21116	{"_key": 21116, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33760_female_bottomOuter_PantsSLF_01_Types_PantsSLF_01_reddark.png", "iconType": "png"}
1839	21117	{"_key": 21117, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33761_female_bottomOuter_PantsSLF_01_Types_PantsSLF_01_yellowgloss.png", "iconType": "png"}
1840	21118	{"_key": 21118, "iconFile": "res:/UI/Asset/mannequin/feet/33714_female_Feet_BootsALF_01_Types_BootsALF_01_blackgold.png", "iconType": "png"}
1841	21119	{"_key": 21119, "iconFile": "res:/UI/Asset/mannequin/feet/33716_female_Feet_BootsALF_01_Types_BootsALF_01_brown.png", "iconType": "png"}
1842	21120	{"_key": 21120, "iconFile": "res:/UI/Asset/mannequin/feet/33717_female_Feet_BootsALF_01_Types_BootsALF_01_cream.png", "iconType": "png"}
1843	21121	{"_key": 21121, "iconFile": "res:/UI/Asset/mannequin/feet/33718_female_Feet_BootsALF_01_Types_BootsALF_01_navy.png", "iconType": "png"}
1844	21122	{"_key": 21122, "iconFile": "res:/UI/Asset/mannequin/feet/33719_female_Feet_BootsALF_01_Types_BootsALF_01_red.png", "iconType": "png"}
1845	21123	{"_key": 21123, "iconFile": "res:/UI/Asset/mannequin/feet/33720_female_Feet_BootsSLF_01_Types_BootsSLF_01_black.png", "iconType": "png"}
1846	21124	{"_key": 21124, "iconFile": "res:/UI/Asset/mannequin/feet/33721_female_Feet_BootsSLF_01_Types_BootsSLF_01_blue.png", "iconType": "png"}
1847	21125	{"_key": 21125, "iconFile": "res:/UI/Asset/mannequin/feet/33722_female_Feet_BootsSLF_01_Types_BootsSLF_01_brown.png", "iconType": "png"}
1848	21126	{"_key": 21126, "iconFile": "res:/UI/Asset/mannequin/feet/33723_female_Feet_BootsSLF_01_Types_BootsSLF_01_felt.png", "iconType": "png"}
1849	21127	{"_key": 21127, "iconFile": "res:/UI/Asset/mannequin/feet/33724_female_Feet_BootsSLF_01_Types_BootsSLF_01_mouse.png", "iconType": "png"}
1850	21128	{"_key": 21128, "iconFile": "res:/UI/Asset/mannequin/feet/33725_female_Feet_BootsSLF_01_Types_BootsSLF_01_red.png", "iconType": "png"}
1851	21129	{"_key": 21129, "iconFile": "res:/UI/Asset/mannequin/outer/33726_female_Outer_JacketALF_01_Types_JacketALF_01_blackgold.png", "iconType": "png"}
1852	21130	{"_key": 21130, "iconFile": "res:/UI/Asset/mannequin/outer/33728_female_Outer_JacketALF_01_Types_JacketALF_01_bluesilver.png", "iconType": "png"}
1853	21131	{"_key": 21131, "iconFile": "res:/UI/Asset/mannequin/outer/33727_female_Outer_JacketALF_01_Types_JacketALF_01_brownpattern.png", "iconType": "png"}
1854	21132	{"_key": 21132, "iconFile": "res:/UI/Asset/mannequin/outer/33715_female_Outer_JacketALF_01_Types_JacketALF_01_creamgold.png", "iconType": "png"}
1855	21133	{"_key": 21133, "iconFile": "res:/UI/Asset/mannequin/outer/33729_female_Outer_JacketALF_01_Types_JacketALF_01_darkgreen.png", "iconType": "png"}
1856	21134	{"_key": 21134, "iconFile": "res:/UI/Asset/mannequin/outer/33730_female_Outer_JacketALF_01_Types_JacketALF_01_darkredgun.png", "iconType": "png"}
1857	21135	{"_key": 21135, "iconFile": "res:/UI/Asset/mannequin/outer/33731_female_Outer_JacketALF_01_Types_JacketALF_01_greengold.png", "iconType": "png"}
1858	21136	{"_key": 21136, "iconFile": "res:/UI/Asset/mannequin/outer/33732_female_Outer_JacketALF_01_Types_JacketALF_01_redsilver.png", "iconType": "png"}
1859	21137	{"_key": 21137, "iconFile": "res:/UI/Asset/mannequin/outer/33733_female_Outer_JacketSLF_01_Types_JacketSLF_01_black.png", "iconType": "png"}
1860	21138	{"_key": 21138, "iconFile": "res:/UI/Asset/mannequin/outer/33734_female_Outer_JacketSLF_01_Types_JacketSLF_01_blackv1.png", "iconType": "png"}
1861	21139	{"_key": 21139, "iconFile": "res:/UI/Asset/mannequin/outer/33735_female_Outer_JacketSLF_01_Types_JacketSLF_01_blue.png", "iconType": "png"}
1862	21140	{"_key": 21140, "iconFile": "res:/UI/Asset/mannequin/outer/33736_female_Outer_JacketSLF_01_Types_JacketSLF_01_coppstars.png", "iconType": "png"}
1863	21141	{"_key": 21141, "iconFile": "res:/UI/Asset/mannequin/outer/33738_female_Outer_JacketSLF_01_Types_JacketSLF_01_copv1.png", "iconType": "png"}
1864	21142	{"_key": 21142, "iconFile": "res:/UI/Asset/mannequin/outer/33737_female_Outer_JacketSLF_01_Types_JacketSLF_01_darkgrey.png", "iconType": "png"}
1865	21143	{"_key": 21143, "iconFile": "res:/UI/Asset/mannequin/outer/33739_female_Outer_JacketSLF_01_Types_JacketSLF_01_green.png", "iconType": "png"}
1866	21144	{"_key": 21144, "iconFile": "res:/UI/Asset/mannequin/outer/33740_female_Outer_JacketSLF_01_Types_JacketSLF_01_movcircles.png", "iconType": "png"}
1867	21145	{"_key": 21145, "iconFile": "res:/UI/Asset/mannequin/outer/33741_female_Outer_JacketSLF_01_Types_JacketSLF_01_redv1.png", "iconType": "png"}
1868	21146	{"_key": 21146, "iconFile": "res:/UI/Asset/mannequin/outer/33742_female_Outer_JacketSLF_01_Types_JacketSLF_01_white.png", "iconType": "png"}
1869	21147	{"_key": 21147, "iconFile": "res:/UI/Asset/mannequin/outer/33743_female_Outer_JacketSLF_01_Types_JacketSLF_01_whitegreen.png", "iconType": "png"}
1870	21148	{"_key": 21148, "iconFile": "res:/UI/Asset/mannequin/topmiddle/33767_female_TopMiddle_ShirtQF01_Types_neof2014A.png", "iconType": "png"}
1871	21149	{"_key": 21149, "iconFile": "res:/UI/Asset/mannequin/topmiddle/33768_female_TopMiddle_ShirtQF01_Types_neof2014B.png", "iconType": "png"}
1872	21150	{"_key": 21150, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33790_male_bottomOuter_PantsALM01_Types_PantsALM01_BlackSilver.png", "iconType": "png"}
1873	21152	{"_key": 21152, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33789_male_bottomOuter_PantsALM01_Types_PantsALM01_BlueShiny.png", "iconType": "png"}
1874	21153	{"_key": 21153, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33788_male_bottomOuter_PantsALM01_Types_PantsALM01_DarkredBlackGold.png", "iconType": "png"}
1875	21154	{"_key": 21154, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33787_male_bottomOuter_PantsALM01_Types_PantsALM01_Royal.png", "iconType": "png"}
1876	21155	{"_key": 21155, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33786_male_bottomOuter_PantsALM01_Types_PantsALM01_WhiteBlackGold.png", "iconType": "png"}
1877	21156	{"_key": 21156, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33785_male_bottomOuter_PantsCLM01_Types_PantsCLM01_BlackLeather.png", "iconType": "png"}
1878	21157	{"_key": 21157, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33784_male_bottomOuter_PantsCLM01_Types_PantsCLM01_DarkRed.png", "iconType": "png"}
1879	21158	{"_key": 21158, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33783_male_bottomOuter_PantsCLM01_Types_PantsCLM01_Graphite.png", "iconType": "png"}
1880	21159	{"_key": 21159, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33782_male_bottomOuter_PantsCLM01_Types_PantsCLM01_GreenCamo.png", "iconType": "png"}
1881	21160	{"_key": 21160, "iconFile": "res:/UI/Asset/mannequin/bottomouter/33781_male_bottomOuter_PantsCLM01_Types_PantsCLM01_White.png", "iconType": "png"}
1882	21161	{"_key": 21161, "iconFile": "res:/UI/Asset/mannequin/feet/33780_male_Feet_BootsALM01_Types_BootsALM01_BrownGold.png", "iconType": "png"}
1883	21162	{"_key": 21162, "iconFile": "res:/UI/Asset/mannequin/feet/33779_male_Feet_BootsALM01_Types_BootsALM01_DarkRedBlack.png", "iconType": "png"}
1884	21163	{"_key": 21163, "iconFile": "res:/UI/Asset/mannequin/feet/33778_male_Feet_BootsALM01_Types_BootsALM01_GreySilver.png", "iconType": "png"}
1885	21164	{"_key": 21164, "iconFile": "res:/UI/Asset/mannequin/feet/33777_male_Feet_BootsALM01_Types_BootsALM01_Royal.png", "iconType": "png"}
1886	21165	{"_key": 21165, "iconFile": "res:/UI/Asset/mannequin/feet/33776_male_Feet_BootsALM01_Types_BootsALM01_WhiteGold.png", "iconType": "png"}
1887	21166	{"_key": 21166, "iconFile": "res:/UI/Asset/mannequin/feet/33775_male_Feet_BootsCLM01_Types_BootsCLM01_Black.png", "iconType": "png"}
1888	21167	{"_key": 21167, "iconFile": "res:/UI/Asset/mannequin/feet/33774_male_Feet_BootsCLM01_Types_BootsCLM01_BlueShiny.png", "iconType": "png"}
1889	21168	{"_key": 21168, "iconFile": "res:/UI/Asset/mannequin/feet/33773_male_Feet_BootsCLM01_Types_BootsCLM01_Brown.png", "iconType": "png"}
1890	21169	{"_key": 21169, "iconFile": "res:/UI/Asset/mannequin/feet/33772_male_Feet_BootsCLM01_Types_BootsCLM01_Graphite.png", "iconType": "png"}
1891	21170	{"_key": 21170, "iconFile": "res:/UI/Asset/mannequin/feet/33771_male_Feet_BootsCLM01_Types_BootsCLM01_White.png", "iconType": "png"}
1892	21171	{"_key": 21171, "iconFile": "res:/UI/Asset/mannequin/outer/33800_male_outer_JacketALM01_Types_JacketALM01_BlackSilver.png", "iconType": "png"}
1893	21172	{"_key": 21172, "iconFile": "res:/UI/Asset/mannequin/outer/33799_male_outer_JacketALM01_Types_JacketALM01_BrownBlackGold.png", "iconType": "png"}
1894	21173	{"_key": 21173, "iconFile": "res:/UI/Asset/mannequin/outer/33798_male_outer_JacketALM01_Types_JacketALM01_RedGold.png", "iconType": "png"}
1895	21174	{"_key": 21174, "iconFile": "res:/UI/Asset/mannequin/outer/33797_male_outer_JacketALM01_Types_JacketALM01_Royal.png", "iconType": "png"}
1896	21175	{"_key": 21175, "iconFile": "res:/UI/Asset/mannequin/outer/33796_male_outer_JacketALM01_Types_JacketALM01_WhiteGold.png", "iconType": "png"}
1897	21176	{"_key": 21176, "iconFile": "res:/UI/Asset/mannequin/outer/33795_male_outer_JacketCLM01_Types_JacketCLM01_BlueShiny.png", "iconType": "png"}
1898	21177	{"_key": 21177, "iconFile": "res:/UI/Asset/mannequin/outer/33794_male_outer_JacketCLM01_Types_JacketCLM01_DarkRed.png", "iconType": "png"}
1899	21178	{"_key": 21178, "iconFile": "res:/UI/Asset/mannequin/outer/33793_male_outer_JacketCLM01_Types_JacketCLM01_Graphite.png", "iconType": "png"}
1900	21179	{"_key": 21179, "iconFile": "res:/UI/Asset/mannequin/outer/33792_male_outer_JacketCLM01_Types_JacketCLM01_GreenCamo.png", "iconType": "png"}
1901	21180	{"_key": 21180, "iconFile": "res:/UI/Asset/mannequin/outer/33791_male_outer_JacketCLM01_Types_JacketCLM01_White.png", "iconType": "png"}
1902	21181	{"_key": 21181, "iconFile": "res:/UI/Asset/mannequin/topmiddle/33769_male_TopMiddle_ShirtQM01_Types_neom2014A.png", "iconType": "png"}
1903	21182	{"_key": 21182, "iconFile": "res:/UI/Asset/mannequin/topmiddle/33770_male_TopMiddle_ShirtQM01_Types_neom2014B.png", "iconType": "png"}
1904	21183	{"_key": 21183, "iconFile": "res:/UI/Asset/mannequin/outer/33804_female_Outer_JacketMilF01_Types_JacketMilF01_silverV2.png", "iconType": "png"}
1905	21184	{"_key": 21184, "iconFile": "res:/UI/Asset/mannequin/outer/33803_male_outer_JacketMilM02_Types_JacketMilM02_blackV2.png", "iconType": "png"}
1906	21186	{"_key": 21186, "iconFile": "res:/UI/Texture/Icons/sourceBook.png", "iconType": "png"}
1907	21192	{"_key": 21192, "iconFile": "res:/UI/Asset/mannequin/topmiddle/33813_female_TopMiddle_ShirtQF01_Types_shirtqf04.png", "iconType": "png"}
1908	21193	{"_key": 21193, "iconFile": "res:/UI/Asset/mannequin/topmiddle/33812_male_TopMiddle_ShirtQM01_Types_shirtqm04.png", "iconType": "png"}
1909	21195	{"_key": 21195, "iconFile": "res:/UI/Asset/mannequin/hair/34056_male_hair_HeadWear_Amarr_Types_HeadWear_Amarr_Black.png", "iconType": "png"}
1910	21197	{"_key": 21197, "iconFile": "res:/UI/Asset/mannequin/hair/34057_male_hair_HeadWear_Caldari_Types_HeadWear_Caldari_Black.png", "iconType": "png"}
1911	21198	{"_key": 21198, "iconFile": "res:/UI/Asset/mannequin/hair/34058_male_hair_HeadWear_Caldari_Types_HeadWear_Caldari_White.png", "iconType": "png"}
1912	21199	{"_key": 21199, "iconFile": "res:/UI/Asset/mannequin/hair/34059_male_hair_HeadWear_Amarr_Types_HeadWear_Amarr_Silver.png", "iconType": "png"}
1913	21200	{"_key": 21200, "iconFile": "res:/UI/Asset/mannequin/hair/34060_male_hair_HeadWear_Amarr_Types_HeadWear_Amarr_Gold.png", "iconType": "png"}
1914	21201	{"_key": 21201, "iconFile": "res:/UI/Asset/mannequin/hair/34061_male_hair_HeadWear_Amarr_Types_HeadWear_Amarr_Bronze.png", "iconType": "png"}
1915	21202	{"_key": 21202, "iconFile": "res:/UI/Asset/mannequin/hair/34062_male_hair_HeadWear_Caldari_Types_HeadWear_Caldari_Metal.png", "iconType": "png"}
1916	21203	{"_key": 21203, "iconFile": "res:/UI/Asset/mannequin/hair/34063_male_hair_HeadWear_Caldari_Types_HeadWear_Caldari_BlackShiny.png", "iconType": "png"}
1917	21204	{"_key": 21204, "iconFile": "res:/UI/Asset/mannequin/hair/34064_female_hair_Hair_Bun_Hp_02_Types_Hair_Bun_Hp_02_Cyan.png", "iconType": "png"}
1918	21205	{"_key": 21205, "iconFile": "res:/UI/Asset/mannequin/hair/34065_female_hair_Hair_Medium_Hp_01_Types_Hair_Medium_Hp_01_Gunmetal.png", "iconType": "png"}
1919	21206	{"_key": 21206, "iconFile": "res:/UI/Asset/mannequin/hair/34066_female_hair_Hair_Bun_Hp_02_Types_Hair_Bun_Hp_02_Blue.png", "iconType": "png"}
1920	21207	{"_key": 21207, "iconFile": "res:/UI/Asset/mannequin/hair/34067_female_hair_Hair_Medium_Hp_01_Types_Hair_Medium_Hp_01_Platinum.png", "iconType": "png"}
1921	21208	{"_key": 21208, "iconFile": "res:/UI/Asset/mannequin/hair/34068_female_hair_Hair_Lace_01_Types_Hair_Lace_01_Black.png", "iconType": "png"}
1922	21209	{"_key": 21209, "iconFile": "res:/UI/Asset/mannequin/hair/34069_female_hair_Hair_Medium_Hp_01_Types_Hair_Medium_Hp_01_Gold.png", "iconType": "png"}
1923	21210	{"_key": 21210, "iconFile": "res:/UI/Asset/mannequin/hair/34070_female_hair_Hair_Bun_Hp_02_Types_Hair_Bun_Hp_02_Orange.png", "iconType": "png"}
1924	21211	{"_key": 21211, "iconFile": "res:/UI/Asset/mannequin/hair/34071_female_hair_Hair_Medium_Hp_01_Types_Hair_Medium_Hp_01_Black.png", "iconType": "png"}
1925	21212	{"_key": 21212, "iconFile": "res:/UI/Asset/mannequin/hair/34072_female_hair_Hair_Lace_01_Types_Hair_Lace_01_Copper.png", "iconType": "png"}
1926	21213	{"_key": 21213, "iconFile": "res:/UI/Asset/mannequin/hair/34073_female_hair_Hair_Lace_01_Types_Hair_Lace_01_Metallic.png", "iconType": "png"}
1927	21214	{"_key": 21214, "iconFile": "res:/UI/Asset/mannequin/hair/34074_female_hair_Hair_Medium_Hp_01_Types_Hair_Medium_Hp_01_Jade.png", "iconType": "png"}
1928	21215	{"_key": 21215, "iconFile": "res:/UI/Asset/mannequin/hair/34075_female_hair_Hair_Medium_Hp_01_Types_Hair_Medium_Hp_01_Simple.png", "iconType": "png"}
1929	21216	{"_key": 21216, "iconFile": "res:/UI/Asset/mannequin/hair/34076_female_hair_Hair_Bun_Hp_02_Types_Hair_Bun_Hp_02_Clear.png", "iconType": "png"}
1930	21217	{"_key": 21217, "iconFile": "res:/UI/Asset/mannequin/hair/34077_female_hair_Hair_Lace_01_Types_Hair_Lace_01_Gold.png", "iconType": "png"}
1931	21218	{"_key": 21218, "iconFile": "res:/UI/Asset/mannequin/hair/34078_female_hair_Hair_Bun_Hp_02_Types_Hair_Bun_Hp_02_Black.png", "iconType": "png"}
1932	21219	{"_key": 21219, "iconFile": "res:/UI/Asset/mannequin/tattoo_armright/34006_male_tattoo_armright_sleeve01__.png", "iconType": "png"}
1933	21220	{"_key": 21220, "iconFile": "res:/UI/Asset/mannequin/tattoo_armright/34007_male_tattoo_armright_sleeve02__.png", "iconType": "png"}
1934	21221	{"_key": 21221, "iconFile": "res:/UI/Asset/mannequin/tattoo_armright/34008_male_tattoo_armright_sleeve03__.png", "iconType": "png"}
1935	21222	{"_key": 21222, "iconFile": "res:/UI/Asset/mannequin/tattoo_armright/34009_male_tattoo_armright_sleeve06__.png", "iconType": "png"}
1936	21223	{"_key": 21223, "iconFile": "res:/UI/Asset/mannequin/tattoo_armright/34010_male_tattoo_armright_sleeve07__.png", "iconType": "png"}
1937	21224	{"_key": 21224, "iconFile": "res:/UI/Asset/mannequin/tattoo_armright/34011_male_tattoo_armright_sleeve09__.png", "iconType": "png"}
1938	21225	{"_key": 21225, "iconFile": "res:/UI/Asset/mannequin/tattoo_armright/34012_male_tattoo_armright_sleeve10__.png", "iconType": "png"}
1939	21226	{"_key": 21226, "iconFile": "res:/UI/Asset/mannequin/tattoo_armright/34013_male_tattoo_armright_sleeve11__.png", "iconType": "png"}
1940	21227	{"_key": 21227, "iconFile": "res:/UI/Asset/mannequin/tattoo_armright/34014_male_tattoo_armright_sleeve12__.png", "iconType": "png"}
1941	21228	{"_key": 21228, "iconFile": "res:/UI/Asset/mannequin/tattoo_armright/34015_male_tattoo_armright_sleeve13__.png", "iconType": "png"}
1942	21229	{"_key": 21229, "iconFile": "res:/UI/Asset/mannequin/tattoo_armright/34016_male_tattoo_armright_sleeve15__.png", "iconType": "png"}
1943	21230	{"_key": 21230, "iconFile": "res:/UI/Asset/mannequin/tattoo_armleft/33995_male_tattoo_armleft_sleeve01__.png", "iconType": "png"}
1944	21231	{"_key": 21231, "iconFile": "res:/UI/Asset/mannequin/tattoo_armleft/33996_male_tattoo_armleft_sleeve02__.png", "iconType": "png"}
1945	21232	{"_key": 21232, "iconFile": "res:/UI/Asset/mannequin/tattoo_armleft/33997_male_tattoo_armleft_sleeve03__.png", "iconType": "png"}
1946	21233	{"_key": 21233, "iconFile": "res:/UI/Asset/mannequin/tattoo_armleft/33998_male_tattoo_armleft_sleeve06__.png", "iconType": "png"}
1947	21234	{"_key": 21234, "iconFile": "res:/UI/Asset/mannequin/tattoo_armleft/33999_male_tattoo_armleft_sleeve07__.png", "iconType": "png"}
1948	21235	{"_key": 21235, "iconFile": "res:/UI/Asset/mannequin/tattoo_armleft/34000_male_tattoo_armleft_sleeve09__.png", "iconType": "png"}
1949	21236	{"_key": 21236, "iconFile": "res:/UI/Asset/mannequin/tattoo_armleft/34001_male_tattoo_armleft_sleeve10__.png", "iconType": "png"}
1950	21237	{"_key": 21237, "iconFile": "res:/UI/Asset/mannequin/tattoo_armleft/34002_male_tattoo_armleft_sleeve11__.png", "iconType": "png"}
1951	21238	{"_key": 21238, "iconFile": "res:/UI/Asset/mannequin/tattoo_armleft/34003_male_tattoo_armleft_sleeve12__.png", "iconType": "png"}
1952	21239	{"_key": 21239, "iconFile": "res:/UI/Asset/mannequin/tattoo_armleft/34004_male_tattoo_armleft_sleeve13__.png", "iconType": "png"}
1953	21240	{"_key": 21240, "iconFile": "res:/UI/Asset/mannequin/tattoo_armleft/34005_male_tattoo_armleft_sleeve15__.png", "iconType": "png"}
1954	21241	{"_key": 21241, "iconFile": "res:/UI/Asset/mannequin/makeup_armright/34031_female_Makeup_ArmRight_CyborgArmF01_R_Types_CyborgArmF01_R_Black.png", "iconType": "png"}
1955	21242	{"_key": 21242, "iconFile": "res:/UI/Asset/mannequin/makeup_armright/34032_female_Makeup_ArmRight_CyborgArmF01_R_Types_CyborgArmF01_R_BlackOrangeMech.png", "iconType": "png"}
1956	21243	{"_key": 21243, "iconFile": "res:/UI/Asset/mannequin/makeup_armright/34033_female_Makeup_ArmRight_CyborgArmF01_R_Types_CyborgArmF01_R_BlackShinyMech.png", "iconType": "png"}
1957	21244	{"_key": 21244, "iconFile": "res:/UI/Asset/mannequin/makeup_armright/34034_female_Makeup_ArmRight_CyborgArmF01_R_Types_CyborgArmF01_R_BlackYellow.png", "iconType": "png"}
1958	21245	{"_key": 21245, "iconFile": "res:/UI/Asset/mannequin/makeup_armright/34035_female_Makeup_ArmRight_CyborgArmF01_R_Types_CyborgArmF01_R_BlueBlackShinyMech.png", "iconType": "png"}
1959	21246	{"_key": 21246, "iconFile": "res:/UI/Asset/mannequin/makeup_armright/34036_female_Makeup_ArmRight_CyborgArmF01_R_Types_CyborgArmF01_R_BlueWhite.png", "iconType": "png"}
1960	21247	{"_key": 21247, "iconFile": "res:/UI/Asset/mannequin/makeup_armright/34037_female_Makeup_ArmRight_CyborgArmF01_R_Types_CyborgArmF01_R_WhiteGrayMech.png", "iconType": "png"}
1961	21248	{"_key": 21248, "iconFile": "res:/UI/Asset/mannequin/makeup_armright/34038_male_Makeup_ArmRight_CyborgArmM01_R_Types_CyborgArmM01_R_BlackOrange.png", "iconType": "png"}
1962	21249	{"_key": 21249, "iconFile": "res:/UI/Asset/mannequin/makeup_armright/34039_male_Makeup_ArmRight_CyborgArmM01_R_Types_CyborgArmM01_R_BlackRed.png", "iconType": "png"}
1963	21250	{"_key": 21250, "iconFile": "res:/UI/Asset/mannequin/makeup_armright/34040_male_Makeup_ArmRight_CyborgArmM01_R_Types_CyborgArmM01_R_BlackYellow.png", "iconType": "png"}
1964	21251	{"_key": 21251, "iconFile": "res:/UI/Asset/mannequin/makeup_armright/34041_male_Makeup_ArmRight_CyborgArmM01_R_Types_CyborgArmM01_R_BlueWhite.png", "iconType": "png"}
1965	21252	{"_key": 21252, "iconFile": "res:/UI/Asset/mannequin/makeup_armright/34042_male_Makeup_ArmRight_CyborgArmM01_R_Types_CyborgArmM01_R_GreenCamo.png", "iconType": "png"}
1966	21253	{"_key": 21253, "iconFile": "res:/UI/Asset/mannequin/makeup_armright/34043_male_Makeup_ArmRight_CyborgArmM01_R_Types_CyborgArmM01_R_GreenYellow.png", "iconType": "png"}
1967	21254	{"_key": 21254, "iconFile": "res:/UI/Asset/mannequin/makeup_armright/34044_male_Makeup_ArmRight_CyborgArmM01_R_Types_CyborgArmM01_R_Gunmetal.png", "iconType": "png"}
1968	21255	{"_key": 21255, "iconFile": "res:/UI/Asset/mannequin/makeup_armleft/34017_female_Makeup_ArmLeft_CyborgArmF01_L_Types_CyborgArmF01_L_Black.png", "iconType": "png"}
1969	21256	{"_key": 21256, "iconFile": "res:/UI/Asset/mannequin/makeup_armleft/34018_female_Makeup_ArmLeft_CyborgArmF01_L_Types_CyborgArmF01_L_BlackOrangeMech.png", "iconType": "png"}
1970	21257	{"_key": 21257, "iconFile": "res:/UI/Asset/mannequin/makeup_armleft/34019_female_Makeup_ArmLeft_CyborgArmF01_L_Types_CyborgArmF01_L_BlackShinyMech.png", "iconType": "png"}
1971	21258	{"_key": 21258, "iconFile": "res:/UI/Asset/mannequin/makeup_armleft/34020_female_Makeup_ArmLeft_CyborgArmF01_L_Types_CyborgArmF01_L_BlackYellow.png", "iconType": "png"}
1972	21259	{"_key": 21259, "iconFile": "res:/UI/Asset/mannequin/makeup_armleft/34021_female_Makeup_ArmLeft_CyborgArmF01_L_Types_CyborgArmF01_L_BlueBlackShinyMech.png", "iconType": "png"}
1973	21260	{"_key": 21260, "iconFile": "res:/UI/Asset/mannequin/makeup_armleft/34022_female_Makeup_ArmLeft_CyborgArmF01_L_Types_CyborgArmF01_L_BlueWhite.png", "iconType": "png"}
1974	21261	{"_key": 21261, "iconFile": "res:/UI/Asset/mannequin/makeup_armleft/34023_female_Makeup_ArmLeft_CyborgArmF01_L_Types_CyborgArmF01_L_WhiteGrayMech.png", "iconType": "png"}
1975	21262	{"_key": 21262, "iconFile": "res:/UI/Asset/mannequin/makeup_armleft/34024_male_Makeup_ArmLeft_CyborgArmM01_L_Types_CyborgArmM01_L_BlackOrange.png", "iconType": "png"}
1976	21263	{"_key": 21263, "iconFile": "res:/UI/Asset/mannequin/makeup_armleft/34025_male_Makeup_ArmLeft_CyborgArmM01_L_Types_CyborgArmM01_L_BlackRed.png", "iconType": "png"}
1977	21264	{"_key": 21264, "iconFile": "res:/UI/Asset/mannequin/makeup_armleft/34026_male_Makeup_ArmLeft_CyborgArmM01_L_Types_CyborgArmM01_L_BlackYellow.png", "iconType": "png"}
1978	21265	{"_key": 21265, "iconFile": "res:/UI/Asset/mannequin/makeup_armleft/34027_male_Makeup_ArmLeft_CyborgArmM01_L_Types_CyborgArmM01_L_BlueWhite.png", "iconType": "png"}
1979	21266	{"_key": 21266, "iconFile": "res:/UI/Asset/mannequin/makeup_armleft/34028_male_Makeup_ArmLeft_CyborgArmM01_L_Types_CyborgArmM01_L_GreenCamo.png", "iconType": "png"}
1980	21267	{"_key": 21267, "iconFile": "res:/UI/Asset/mannequin/makeup_armleft/34029_male_Makeup_ArmLeft_CyborgArmM01_L_Types_CyborgArmM01_L_GreenYellow.png", "iconType": "png"}
1981	21268	{"_key": 21268, "iconFile": "res:/UI/Asset/mannequin/makeup_armleft/34030_male_Makeup_ArmLeft_CyborgArmM01_L_Types_CyborgArmM01_L_Gunmetal.png", "iconType": "png"}
1982	21269	{"_key": 21269, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/33992_female_Accessories_Glasses_Monocle_01_Types_MonocleF01_RightBlack.png", "iconType": "png"}
1983	21270	{"_key": 21270, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/33993_female_Accessories_Glasses_Monocle_F_T02_Types_Monocle_F_T02_black_left.png", "iconType": "png"}
1984	21271	{"_key": 21271, "iconFile": "res:/UI/Asset/mannequin/bottommiddle/33989_female_bottomMiddle_TightsF01_Types_TightsF01_black.png", "iconType": "png"}
1985	21272	{"_key": 21272, "iconFile": "res:/UI/Asset/mannequin/bottommiddle/34045_female_bottomMiddle_TightsF01_Types_TightsF01_light.png", "iconType": "png"}
1986	21273	{"_key": 21273, "iconFile": "res:/UI/Asset/mannequin/bottommiddle/34046_female_bottomMiddle_TightsF01_Types_TightsF01_orange.png", "iconType": "png"}
1987	21274	{"_key": 21274, "iconFile": "res:/UI/Asset/mannequin/bottommiddle/34047_female_bottomMiddle_TightsF01_Types_TightsF01_pink.png", "iconType": "png"}
1988	21275	{"_key": 21275, "iconFile": "res:/UI/Asset/mannequin/bottommiddle/34048_female_bottomMiddle_TightsF01_Types_TightsF01_red.png", "iconType": "png"}
1989	21276	{"_key": 21276, "iconFile": "res:/UI/Asset/mannequin/bottommiddle/34049_female_bottomMiddle_TightsF01_Types_TightsF01_thickblack.png", "iconType": "png"}
1990	21277	{"_key": 21277, "iconFile": "res:/UI/Asset/mannequin/bottommiddle/34051_female_bottomMiddle_TightsF01_Types_TightsF01_thickgray.png", "iconType": "png"}
1991	21278	{"_key": 21278, "iconFile": "res:/UI/Asset/mannequin/bottommiddle/34053_female_bottomMiddle_TightsF01_Types_TightsF01_thickpurple.png", "iconType": "png"}
1992	21279	{"_key": 21279, "iconFile": "res:/UI/Asset/mannequin/bottommiddle/34054_female_bottomMiddle_TightsF01_Types_TightsF01_white.png", "iconType": "png"}
1993	21280	{"_key": 21280, "iconFile": "res:/UI/Asset/mannequin/bottommiddle/34055_female_bottomMiddle_TightsF01_Types_TightsF01_yellow.png", "iconType": "png"}
1994	21281	{"_key": 21281, "iconFile": "res:/UI/Asset/mannequin/bottommiddle/34050_female_bottomMiddle_TightsF01_Types_TightsF01_thickblue.png", "iconType": "png"}
1995	21282	{"_key": 21282, "iconFile": "res:/UI/Asset/mannequin/bottommiddle/34052_female_bottomMiddle_TightsF01_Types_TightsF01_thickmatblack.png", "iconType": "png"}
1996	21283	{"_key": 21283, "iconFile": "res:/UI/Asset/mannequin/bottomouter/34101_female_bottomOuter_SpaceSuit_01_Types_spacesuit_01_f_black.png", "iconType": "png"}
1997	21284	{"_key": 21284, "iconFile": "res:/UI/Asset/mannequin/bottomouter/34102_female_bottomOuter_SpaceSuit_01_Types_spacesuit_01_f_blackgold.png", "iconType": "png"}
1998	21285	{"_key": 21285, "iconFile": "res:/UI/Asset/mannequin/bottomouter/34103_female_bottomOuter_SpaceSuit_01_Types_spacesuit_01_f_blue.png", "iconType": "png"}
1999	21286	{"_key": 21286, "iconFile": "res:/UI/Asset/mannequin/bottomouter/34104_female_bottomOuter_SpaceSuit_01_Types_spacesuit_01_f_brown.png", "iconType": "png"}
2000	21287	{"_key": 21287, "iconFile": "res:/UI/Asset/mannequin/bottomouter/34105_female_bottomOuter_SpaceSuit_01_Types_spacesuit_01_f_greengold.png", "iconType": "png"}
2001	21288	{"_key": 21288, "iconFile": "res:/UI/Asset/mannequin/bottomouter/34106_female_bottomOuter_SpaceSuit_01_Types_spacesuit_01_f_orange.png", "iconType": "png"}
2002	21289	{"_key": 21289, "iconFile": "res:/UI/Asset/mannequin/bottomouter/34107_female_bottomOuter_SpaceSuit_01_Types_spacesuit_01_f_red.png", "iconType": "png"}
2003	21290	{"_key": 21290, "iconFile": "res:/UI/Asset/mannequin/bottomouter/34108_female_bottomOuter_SpaceSuit_01_Types_spacesuit_01_f_redblack.png", "iconType": "png"}
2004	21291	{"_key": 21291, "iconFile": "res:/UI/Asset/mannequin/bottomouter/34109_female_bottomOuter_SpaceSuit_01_Types_spacesuit_01_f_stealth.png", "iconType": "png"}
2005	21292	{"_key": 21292, "iconFile": "res:/UI/Asset/mannequin/bottomouter/34110_female_bottomOuter_SpaceSuit_01_Types_spacesuit_01_f_white.png", "iconType": "png"}
2006	21293	{"_key": 21293, "iconFile": "res:/UI/Asset/mannequin/bottomouter/34111_female_bottomOuter_SpaceSuit_01_Types_spacesuit_01_f_yellow.png", "iconType": "png"}
2007	21294	{"_key": 21294, "iconFile": "res:/UI/Asset/mannequin/feet/34079_female_Feet_SpaceBoots01F_Types_spaceboots01f_black.png", "iconType": "png"}
2008	21295	{"_key": 21295, "iconFile": "res:/UI/Asset/mannequin/feet/34080_female_Feet_SpaceBoots01F_Types_spaceboots01f_blackgold.png", "iconType": "png"}
2009	21296	{"_key": 21296, "iconFile": "res:/UI/Asset/mannequin/feet/34081_female_Feet_SpaceBoots01F_Types_spaceboots01f_blue.png", "iconType": "png"}
2010	21297	{"_key": 21297, "iconFile": "res:/UI/Asset/mannequin/feet/34082_female_Feet_SpaceBoots01F_Types_spaceboots01f_brown.png", "iconType": "png"}
2011	21298	{"_key": 21298, "iconFile": "res:/UI/Asset/mannequin/feet/34083_female_Feet_SpaceBoots01F_Types_spaceboots01f_greengold.png", "iconType": "png"}
2012	21299	{"_key": 21299, "iconFile": "res:/UI/Asset/mannequin/feet/34084_female_Feet_SpaceBoots01F_Types_spaceboots01f_orange.png", "iconType": "png"}
2013	21300	{"_key": 21300, "iconFile": "res:/UI/Asset/mannequin/feet/34085_female_Feet_SpaceBoots01F_Types_spaceboots01f_red.png", "iconType": "png"}
2014	21301	{"_key": 21301, "iconFile": "res:/UI/Asset/mannequin/feet/34086_female_Feet_SpaceBoots01F_Types_spaceboots01f_redblack.png", "iconType": "png"}
2015	21302	{"_key": 21302, "iconFile": "res:/UI/Asset/mannequin/feet/34087_female_Feet_SpaceBoots01F_Types_spaceboots01f_stealth.png", "iconType": "png"}
2016	21303	{"_key": 21303, "iconFile": "res:/UI/Asset/mannequin/feet/34088_female_Feet_SpaceBoots01F_Types_spaceboots01f_white.png", "iconType": "png"}
2017	21304	{"_key": 21304, "iconFile": "res:/UI/Asset/mannequin/feet/34089_female_Feet_SpaceBoots01F_Types_spaceboots01f_yellow.png", "iconType": "png"}
2018	21305	{"_key": 21305, "iconFile": "res:/UI/Asset/mannequin/outer/34090_female_Outer_SpaceSuit_Top_01_Types_spacesuit_01_top_f_black.png", "iconType": "png"}
2019	21306	{"_key": 21306, "iconFile": "res:/UI/Asset/mannequin/outer/34091_female_Outer_SpaceSuit_Top_01_Types_spacesuit_01_top_f_blackgold.png", "iconType": "png"}
2020	21307	{"_key": 21307, "iconFile": "res:/UI/Asset/mannequin/outer/34092_female_Outer_SpaceSuit_Top_01_Types_spacesuit_01_top_f_blue.png", "iconType": "png"}
2021	21308	{"_key": 21308, "iconFile": "res:/UI/Asset/mannequin/outer/34093_female_Outer_SpaceSuit_Top_01_Types_spacesuit_01_top_f_brown.png", "iconType": "png"}
2022	21309	{"_key": 21309, "iconFile": "res:/UI/Asset/mannequin/outer/34094_female_Outer_SpaceSuit_Top_01_Types_spacesuit_01_top_f_greengold.png", "iconType": "png"}
2023	21310	{"_key": 21310, "iconFile": "res:/UI/Asset/mannequin/outer/34095_female_Outer_SpaceSuit_Top_01_Types_spacesuit_01_top_f_orange.png", "iconType": "png"}
2024	21311	{"_key": 21311, "iconFile": "res:/UI/Asset/mannequin/outer/34096_female_Outer_SpaceSuit_Top_01_Types_spacesuit_01_top_f_red.png", "iconType": "png"}
2025	21312	{"_key": 21312, "iconFile": "res:/UI/Asset/mannequin/outer/34097_female_Outer_SpaceSuit_Top_01_Types_spacesuit_01_top_f_redblack.png", "iconType": "png"}
2026	21313	{"_key": 21313, "iconFile": "res:/UI/Asset/mannequin/outer/34098_female_Outer_SpaceSuit_Top_01_Types_spacesuit_01_top_f_stealth.png", "iconType": "png"}
2027	21314	{"_key": 21314, "iconFile": "res:/UI/Asset/mannequin/outer/34099_female_Outer_SpaceSuit_Top_01_Types_spacesuit_01_top_f_white.png", "iconType": "png"}
2028	21315	{"_key": 21315, "iconFile": "res:/UI/Asset/mannequin/outer/34100_female_Outer_SpaceSuit_Top_01_Types_spacesuit_01_top_f_yellow.png", "iconType": "png"}
2029	21335	{"_key": 21335, "iconFile": "res:/UI/Texture/Icons/character_resculpt.png", "iconType": "png"}
2030	21336	{"_key": 21336, "iconFile": "res:/UI/Texture/Icons/multiple_training.png", "iconType": "png"}
2031	21347	{"_key": 21347, "iconFile": "res:/UI/Asset/mannequin/outer/34156_male_outer_JacketMFBR01_Types_JacketMFBR01_Caldari.png", "iconType": "png"}
2032	21348	{"_key": 21348, "iconFile": "res:/UI/Asset/mannequin/outer/34157_male_outer_JacketMFBR01_Types_JacketMFBR01_Amarr.png", "iconType": "png"}
2033	21349	{"_key": 21349, "iconFile": "res:/UI/Asset/mannequin/outer/34158_male_outer_JacketMFBR01_Types_JacketMFBR01_Minmatar.png", "iconType": "png"}
2034	21350	{"_key": 21350, "iconFile": "res:/UI/Asset/mannequin/outer/34159_male_outer_JacketMFBR01_Types_JacketMFBR01_Gallente.png", "iconType": "png"}
2035	21351	{"_key": 21351, "iconFile": "res:/UI/Asset/mannequin/outer/34160_male_outer_JacketMFBR01_Types_JacketMFBR01_ORE.png", "iconType": "png"}
2036	21352	{"_key": 21352, "iconFile": "res:/UI/Asset/mannequin/outer/34161_male_outer_JacketMFBR01_Types_JacketMFBR01_SOE.png", "iconType": "png"}
2037	21353	{"_key": 21353, "iconFile": "res:/UI/Asset/mannequin/outer/34162_male_outer_JacketMFBR01_Types_JacketMFBR01_Mordus.png", "iconType": "png"}
2038	21354	{"_key": 21354, "iconFile": "res:/UI/Asset/mannequin/outer/34163_male_outer_JacketMFBR01_Types_JacketMFBR01_Interbus.png", "iconType": "png"}
2039	21355	{"_key": 21355, "iconFile": "res:/UI/Asset/mannequin/outer/34164_male_outer_JacketMFBR01_Types_JacketMFBR01_Angel.png", "iconType": "png"}
2040	21356	{"_key": 21356, "iconFile": "res:/UI/Asset/mannequin/outer/34165_male_outer_JacketMFBR01_Types_JacketMFBR01_Sansha.png", "iconType": "png"}
2041	21357	{"_key": 21357, "iconFile": "res:/UI/Asset/mannequin/outer/34166_male_outer_JacketMFBR01_Types_JacketMFBR01_Bloodraiders.png", "iconType": "png"}
2042	21358	{"_key": 21358, "iconFile": "res:/UI/Asset/mannequin/outer/34167_male_outer_JacketMFBR01_Types_JacketMFBR01_Guristas.png", "iconType": "png"}
2043	21359	{"_key": 21359, "iconFile": "res:/UI/Asset/mannequin/outer/34168_male_outer_JacketMFBR01_Types_JacketMFBR01_Serpentis.png", "iconType": "png"}
2044	21360	{"_key": 21360, "iconFile": "res:/UI/Asset/mannequin/outer/34169_female_Outer_JacketFBR01_Types_JacketFBR01_caldari.png", "iconType": "png"}
2045	21361	{"_key": 21361, "iconFile": "res:/UI/Asset/mannequin/outer/34170_female_Outer_JacketFBR01_Types_JacketFBR01_amarr.png", "iconType": "png"}
2046	21362	{"_key": 21362, "iconFile": "res:/UI/Asset/mannequin/outer/34171_female_Outer_JacketFBR01_Types_JacketFBR01_minmatar.png", "iconType": "png"}
2047	21363	{"_key": 21363, "iconFile": "res:/UI/Asset/mannequin/outer/34173_female_Outer_JacketFBR01_Types_JacketFBR01_ore.png", "iconType": "png"}
2048	21364	{"_key": 21364, "iconFile": "res:/UI/Asset/mannequin/outer/34174_female_Outer_JacketFBR01_Types_JacketFBR01_soe.png", "iconType": "png"}
2049	21365	{"_key": 21365, "iconFile": "res:/UI/Asset/mannequin/outer/34175_female_Outer_JacketFBR01_Types_JacketFBR01_mordus.png", "iconType": "png"}
2050	21366	{"_key": 21366, "iconFile": "res:/UI/Asset/mannequin/outer/34176_female_Outer_JacketFBR01_Types_JacketFBR01_interbus.png", "iconType": "png"}
2051	21367	{"_key": 21367, "iconFile": "res:/UI/Asset/mannequin/outer/34177_female_Outer_JacketFBR01_Types_JacketFBR01_angel.png", "iconType": "png"}
2052	21368	{"_key": 21368, "iconFile": "res:/UI/Asset/mannequin/outer/34178_female_Outer_JacketFBR01_Types_JacketFBR01_sansha.png", "iconType": "png"}
2053	21369	{"_key": 21369, "iconFile": "res:/UI/Asset/mannequin/outer/34179_female_Outer_JacketFBR01_Types_JacketFBR01_bloodraiders.png", "iconType": "png"}
2054	21370	{"_key": 21370, "iconFile": "res:/UI/Asset/mannequin/outer/34180_female_Outer_JacketFBR01_Types_JacketFBR01_guristas.png", "iconType": "png"}
2055	21371	{"_key": 21371, "iconFile": "res:/UI/Asset/mannequin/outer/34181_female_Outer_JacketFBR01_Types_JacketFBR01_serpentis.png", "iconType": "png"}
2056	21373	{"_key": 21373, "iconFile": "res:/UI/Asset/mannequin/outer/34172_female_Outer_JacketFBR01_Types_JacketFBR01_gallente.png"}
2057	21375	{"_key": 21375, "iconFile": "res:/UI/Asset/mannequin/topmiddle/34210_male_TopMiddle_ShirtQM01_Types_lvm02.png", "iconType": "png"}
2058	21376	{"_key": 21376, "iconFile": "res:/UI/Asset/mannequin/topmiddle/34211_female_TopMiddle_ShirtQF01_Types_lvf02.png", "iconType": "png"}
2059	21378	{"_key": 21378, "iconFile": "res:/ui/texture/icons/1337_64_22.png"}
2060	21379	{"_key": 21379, "iconFile": "res:/ui/texture/icons/1337_64_21.png"}
2061	21380	{"_key": 21380, "iconFile": "res:/UI/Texture/Icons/commendationAmarr.png"}
2062	21381	{"_key": 21381, "iconFile": "res:/UI/Texture/Icons/commendationCaldari.png"}
2063	21382	{"_key": 21382, "iconFile": "res:/UI/Texture/Icons/commendationGallente.png"}
2064	21383	{"_key": 21383, "iconFile": "res:/UI/Texture/Icons/commendationMinmatar.png"}
2065	21384	{"_key": 21384, "iconFile": "res:/UI/Asset/mannequin/outer/34347_male_outer_JacketPrtm01_Types_JacketPrtm01_bloodraiders.png", "iconType": "png"}
2066	21385	{"_key": 21385, "iconFile": "res:/UI/Asset/mannequin/outer/34348_male_outer_JacketPrtm01_Types_JacketPrtm01_sansha.png", "iconType": "png"}
2067	21386	{"_key": 21386, "iconFile": "res:/UI/Asset/mannequin/outer/34349_male_outer_JacketPrtm01_Types_JacketPrtm01_guristas.png", "iconType": "png"}
2068	21387	{"_key": 21387, "iconFile": "res:/UI/Asset/mannequin/outer/34393_male_outer_JacketPrtm01_Types_JacketPrtm01_orange.png", "iconType": "png"}
2069	21388	{"_key": 21388, "iconFile": "res:/UI/Asset/mannequin/outer/34350_female_Outer_JacketPrtF01_Types_JacketPrtF01_sansha.png", "iconType": "png"}
2070	21389	{"_key": 21389, "iconFile": "res:/UI/Asset/mannequin/outer/34353_female_Outer_JacketPrtF01_Types_JacketPrtF01_bloodraiders.png", "iconType": "png"}
2071	21390	{"_key": 21390, "iconFile": "res:/UI/Asset/mannequin/outer/34394_female_Outer_JacketPrtF01_Types_JacketPrtF01_orange.png", "iconType": "png"}
2072	21391	{"_key": 21391, "iconFile": "res:/UI/Asset/mannequin/bottomouter/34354_male_bottomOuter_PantsPrtm01_Types_PantsPrtm01_bloodraiders.png", "iconType": "png"}
2073	21392	{"_key": 21392, "iconFile": "res:/UI/Asset/mannequin/bottomouter/34355_male_bottomOuter_PantsPrtm01_Types_PantsPrtm01_sansha.png", "iconType": "png"}
2074	21393	{"_key": 21393, "iconFile": "res:/UI/Asset/mannequin/bottomouter/34356_male_bottomOuter_PantsPrtm01_Types_PantsPrtm01_guristas.png", "iconType": "png"}
2075	21394	{"_key": 21394, "iconFile": "res:/UI/Asset/mannequin/bottomouter/34357_female_bottomOuter_PantsPrtF01_Types_PantsPrtF01_bloodraiders.png", "iconType": "png"}
2076	21395	{"_key": 21395, "iconFile": "res:/UI/Asset/mannequin/bottomouter/34358_female_bottomOuter_PantsPrtF01_Types_PantsPrtF01_sansha.png", "iconType": "png"}
2077	21396	{"_key": 21396, "iconFile": "res:/UI/Asset/mannequin/bottomouter/34359_female_bottomOuter_PantsPrtF01_Types_PantsPrtF01_guristas.png", "iconType": "png"}
2078	21397	{"_key": 21397, "iconFile": "res:/UI/Asset/mannequin/feet/34360_male_Feet_BootsPrtm01_Types_BootsPrtm01_bloodraiders.png", "iconType": "png"}
2079	21398	{"_key": 21398, "iconFile": "res:/UI/Asset/mannequin/feet/34361_male_Feet_BootsPrtm01_Types_BootsPrtm01_sansha.png", "iconType": "png"}
2080	21399	{"_key": 21399, "iconFile": "res:/UI/Asset/mannequin/feet/34362_male_Feet_BootsPrtm01_Types_BootsPrtm01_guristas.png", "iconType": "png"}
2081	21400	{"_key": 21400, "iconFile": "res:/UI/Asset/mannequin/feet/34363_female_Feet_BootsPrtF01_Types_BootsPrtF01_bloodraiders.png", "iconType": "png"}
2082	21401	{"_key": 21401, "iconFile": "res:/UI/Asset/mannequin/feet/34364_female_Feet_BootsPrtF01_Types_BootsPrtF01_sansha.png", "iconType": "png"}
2083	21402	{"_key": 21402, "iconFile": "res:/UI/Asset/mannequin/feet/34365_female_Feet_BootsPrtF01_Types_BootsPrtF01_guristas.png", "iconType": "png"}
2084	21403	{"_key": 21403, "iconFile": "res:/UI/Asset/mannequin/outer/34351_female_Outer_JacketPrtF01_Types_JacketPrtF01_guristas.png", "iconType": "png"}
2085	21404	{"_key": 21404, "iconFile": "res:/ui/texture/icons/117_64_2.png", "iconType": ""}
2086	21408	{"_key": 21408, "iconFile": "res:/ui/texture/icons/118_64_1.png"}
2087	21409	{"_key": 21409, "iconFile": "res:/ui/texture/icons/119_64_1.png"}
2088	21412	{"_key": 21412, "iconFile": "res:/UI/Asset/mannequin/topmiddle/34824_male_topMiddle_ShirtQM01_Types_ff2015m01.png", "iconType": "png"}
2089	21413	{"_key": 21413, "iconFile": "res:/UI/Asset/mannequin/topmiddle/34825_female_TopMiddle_ShirtQF01_Types_ff2015f01.png", "iconType": "png"}
2090	21414	{"_key": 21414, "iconFile": "res:/UI/Asset/mannequin/topmiddle/34824_male_topMiddle_ShirtQM01_Types_ff2015m01.png", "iconType": "png"}
2091	21415	{"_key": 21415, "iconFile": "res:/UI/Asset/mannequin/topmiddle/34825_female_TopMiddle_ShirtQF01_Types_ff2015f01.png", "iconType": "png"}
2092	21417	{"_key": 21417, "iconFile": "res:/ui/texture/icons/99_64_10.png"}
2093	21418	{"_key": 21418, "iconFile": "res:/ui/texture/icons/99_64_11.png"}
2094	21419	{"_key": 21419, "iconFile": "res:/ui/texture/icons/99_64_12.png"}
2095	21420	{"_key": 21420, "iconFile": "res:/UI/Texture/Icons/skin-icon-16.png", "iconType": "png"}
2096	21421	{"_key": 21421, "iconFile": "res:/UI/Texture/Icons/118_64_7.png"}
2097	21424	{"_key": 21424, "iconFile": "res:/UI/Asset/mannequin/topmiddle/35681_male_topMiddle_ShirtQM01_Types_soerfm02.png", "iconType": "png"}
2098	21425	{"_key": 21425, "iconFile": "res:/UI/Asset/mannequin/topmiddle/35682_female_TopMiddle_ShirtQF01_Types_soerff02.png", "iconType": "png"}
2099	21426	{"_key": 21426, "iconFile": "res:/UI/Texture/Icons/remote_armor_repair.png"}
2100	21428	{"_key": 21428, "iconFile": "res:/UI/Texture/Icons/remote_hull_repairer.png"}
2101	21430	{"_key": 21430, "iconFile": "res:/UI/Texture/classes/Sov/stationServiceResearch.png", "iconType": "png"}
2102	21431	{"_key": 21431, "iconFile": "res:/UI/Texture/WindowIcons/fitting.png", "iconType": "png"}
2103	21432	{"_key": 21432, "iconFile": "res:/UI/Texture/WindowIcons/Reprocess.png", "iconType": "png"}
2104	21433	{"_key": 21433, "iconFile": "res:/UI/Texture/WindowIcons/Industry.png", "iconType": "png"}
2105	21434	{"_key": 21434, "iconFile": "res:/UI/Texture/WindowIcons/cloneBay.png", "iconType": "png"}
2106	21435	{"_key": 21435, "iconFile": "res:/UI/Texture/WindowIcons/repairshop.png", "iconType": "png"}
2107	21437	{"_key": 21437, "iconFile": "res:/UI/Texture/Icons/5_64_17.png"}
2108	21439	{"_key": 21439, "iconFile": "res:/UI/Texture/Icons/5_64_18.png"}
2109	21440	{"_key": 21440, "iconFile": "res:/UI/Texture/Icons/5_64_19.png"}
2110	21441	{"_key": 21441, "iconFile": "res:/UI/Texture/Icons/5_64_20.png"}
2111	21442	{"_key": 21442, "iconFile": "res:/UI/Texture/Icons/5_64_21.png"}
2112	21445	{"_key": 21445, "iconFile": "res:/UI/Asset/mannequin/topmiddle/36480_male_topMiddle_ShirtEngM01_Types_ShirtEngM01_blueorange.png", "iconType": "png"}
2113	21446	{"_key": 21446, "iconFile": "res:/UI/Asset/mannequin/topmiddle/36481_male_topMiddle_ShirtEngM01_Types_ShirtEngM01_redwhite.png", "iconType": "png"}
2114	21447	{"_key": 21447, "iconFile": "res:/UI/Asset/mannequin/topmiddle/36482_male_topMiddle_ShirtEngM01_Types_ShirtEngM01_camo.png", "iconType": "png"}
2115	21448	{"_key": 21448, "iconFile": "res:/UI/Asset/mannequin/topmiddle/36483_male_topMiddle_ShirtEngM01_Types_ShirtEngM01_cyan.png", "iconType": "png"}
2116	21449	{"_key": 21449, "iconFile": "res:/UI/Asset/mannequin/topmiddle/36484_male_topMiddle_ShirtEngM01_Types_ShirtEngM01_oregreen.png", "iconType": "png"}
2117	21450	{"_key": 21450, "iconFile": "res:/UI/Asset/mannequin/topmiddle/36485_male_topMiddle_ShirtEngM01_Types_ShirtEngM01_oreorange.png", "iconType": "png"}
2118	21451	{"_key": 21451, "iconFile": "res:/UI/Asset/mannequin/topmiddle/36486_female_TopMiddle_ShirtEngF01_Types_ShirtEngF01_BlueOrange.png", "iconType": "png"}
2119	21452	{"_key": 21452, "iconFile": "res:/UI/Asset/mannequin/topmiddle/36487_female_TopMiddle_ShirtEngF01_Types_ShirtEngF01_RedWhite.png", "iconType": "png"}
2120	21453	{"_key": 21453, "iconFile": "res:/UI/Asset/mannequin/topmiddle/36488_female_TopMiddle_ShirtEngF01_Types_ShirtEngF01_Camo.png", "iconType": "png"}
2121	21454	{"_key": 21454, "iconFile": "res:/UI/Asset/mannequin/topmiddle/36489_female_TopMiddle_ShirtEngF01_Types_ShirtEngF01_Cyan.png", "iconType": "png"}
2122	21455	{"_key": 21455, "iconFile": "res:/UI/Asset/mannequin/topmiddle/36490_female_TopMiddle_ShirtEngF01_Types_ShirtEngF01_OreGreen.png", "iconType": "png"}
2123	21456	{"_key": 21456, "iconFile": "res:/UI/Asset/mannequin/topmiddle/36491_female_TopMiddle_ShirtEngF01_Types_ShirtEngF01_OreOrange.png", "iconType": "png"}
2124	21457	{"_key": 21457, "iconFile": "res:/UI/Asset/mannequin/bottomouter/36493_male_bottomOuter_PantsEngM01_Types_PantsEngM01_blueorange.png", "iconType": "png"}
2125	21458	{"_key": 21458, "iconFile": "res:/UI/Asset/mannequin/bottomouter/36494_male_bottomOuter_PantsEngM01_Types_PantsEngM01_redwhite.png", "iconType": "png"}
2126	21459	{"_key": 21459, "iconFile": "res:/UI/Asset/mannequin/bottomouter/36495_male_bottomOuter_PantsEngM01_Types_PantsEngM01_camo.png", "iconType": "png"}
2127	21460	{"_key": 21460, "iconFile": "res:/UI/Asset/mannequin/bottomouter/36496_male_bottomOuter_PantsEngM01_Types_PantsEngM01_cyan.png", "iconType": "png"}
2128	21461	{"_key": 21461, "iconFile": "res:/UI/Asset/mannequin/bottomouter/36497_male_bottomOuter_PantsEngM01_Types_PantsEngM01_oregreen.png", "iconType": "png"}
2129	21462	{"_key": 21462, "iconFile": "res:/UI/Asset/mannequin/bottomouter/36498_male_bottomOuter_PantsEngM01_Types_PantsEngM01_oreorange.png", "iconType": "png"}
2130	21463	{"_key": 21463, "iconFile": "res:/UI/Asset/mannequin/bottomouter/36499_female_bottomOuter_PantsEngF01_Types_PantsEngF01_BlueOrange.png", "iconType": "png"}
2131	21464	{"_key": 21464, "iconFile": "res:/UI/Asset/mannequin/bottomouter/36500_female_bottomOuter_PantsEngF01_Types_PantsEngF01_RedWhite.png", "iconType": "png"}
2132	21465	{"_key": 21465, "iconFile": "res:/UI/Asset/mannequin/bottomouter/36501_female_bottomOuter_PantsEngF01_Types_PantsEngF01_Camo.png", "iconType": "png"}
2133	21466	{"_key": 21466, "iconFile": "res:/UI/Asset/mannequin/bottomouter/36502_female_bottomOuter_PantsEngF01_Types_PantsEngF01_Cyan.png", "iconType": "png"}
2134	21467	{"_key": 21467, "iconFile": "res:/UI/Asset/mannequin/bottomouter/36503_female_bottomOuter_PantsEngF01_Types_PantsEngF01_OreGreen.png", "iconType": "png"}
2135	21468	{"_key": 21468, "iconFile": "res:/UI/Asset/mannequin/bottomouter/36504_female_bottomOuter_PantsEngF01_Types_PantsEngF01_OreOrange.png", "iconType": "png"}
2136	21469	{"_key": 21469, "iconFile": "res:/UI/Asset/mannequin/feet/36505_male_Feet_ShoesEngM01_Types_ShoesEngM01_blueorange.png", "iconType": "png"}
2137	21470	{"_key": 21470, "iconFile": "res:/UI/Asset/mannequin/feet/36506_male_Feet_ShoesEngM01_Types_ShoesEngM01_redwhite.png", "iconType": "png"}
2138	21471	{"_key": 21471, "iconFile": "res:/UI/Asset/mannequin/feet/36507_male_Feet_ShoesEngM01_Types_ShoesEngM01_camo.png", "iconType": "png"}
2139	21472	{"_key": 21472, "iconFile": "res:/UI/Asset/mannequin/feet/36508_male_Feet_ShoesEngM01_Types_ShoesEngM01_cyan.png", "iconType": "png"}
2140	21473	{"_key": 21473, "iconFile": "res:/UI/Asset/mannequin/feet/36509_male_Feet_ShoesEngM01_Types_ShoesEngM01_oregreen.png", "iconType": "png"}
2141	21474	{"_key": 21474, "iconFile": "res:/UI/Asset/mannequin/feet/36510_male_Feet_ShoesEngM01_Types_ShoesEngM01_oreorange.png", "iconType": "png"}
2142	21475	{"_key": 21475, "iconFile": "res:/UI/Asset/mannequin/feet/36511_female_Feet_ShoesEngF01_Types_ShoesEngF01_BlueOrange.png", "iconType": "png"}
2143	21476	{"_key": 21476, "iconFile": "res:/UI/Asset/mannequin/feet/36512_female_Feet_ShoesEngF01_Types_ShoesEngF01_RedWhite.png", "iconType": "png"}
2144	21477	{"_key": 21477, "iconFile": "res:/UI/Asset/mannequin/feet/36513_female_Feet_ShoesEngF01_Types_ShoesEngF01_Camo.png", "iconType": "png"}
2145	21478	{"_key": 21478, "iconFile": "res:/UI/Asset/mannequin/feet/36514_female_Feet_ShoesEngF01_Types_ShoesEngF01_Cyan.png", "iconType": "png"}
2146	21479	{"_key": 21479, "iconFile": "res:/UI/Asset/mannequin/feet/36515_female_Feet_ShoesEngF01_Types_ShoesEngF01_OreGreen.png", "iconType": "png"}
2147	21480	{"_key": 21480, "iconFile": "res:/UI/Asset/mannequin/feet/36516_female_Feet_ShoesEngF01_Types_ShoesEngF01_OreOrange.png", "iconType": "png"}
2148	21481	{"_key": 21481, "iconFile": "res:/UI/Texture/Plex/plex_128_gradient_yellow.png"}
2149	21482	{"_key": 21482, "iconFile": "res:/ui/texture/icons/118_64_5.png"}
2150	21483	{"_key": 21483, "iconFile": "res:/ui/texture/icons/118_64_9.png"}
2151	21484	{"_key": 21484, "iconFile": "res:/ui/texture/icons/118_64_10.png"}
2152	21485	{"_key": 21485, "iconFile": "res:/ui/texture/icons/118_64_11.png"}
2153	21486	{"_key": 21486, "iconFile": "res:/ui/texture/icons/118_64_13.png"}
2154	21487	{"_key": 21487, "iconFile": "res:/ui/texture/icons/118_64_14.png"}
2155	21489	{"_key": 21489, "iconFile": "res:/ui/texture/icons/118_64_2.png"}
2156	21493	{"_key": 21493, "iconFile": "res:/UI/Asset/mannequin/outer/37600_female_Outer_ArmorSuitCF01_Types_ArmorSuitCF01_Black.png", "iconType": "png"}
2157	21494	{"_key": 21494, "iconFile": "res:/UI/Asset/mannequin/outer/37601_female_Outer_ArmorSuitCF01_Types_ArmorSuitCF01_Blue.png", "iconType": "png"}
2158	21495	{"_key": 21495, "iconFile": "res:/UI/Asset/mannequin/outer/37602_female_Outer_ArmorSuitCF01_Types_ArmorSuitCF01_Copper.png", "iconType": "png"}
2159	21496	{"_key": 21496, "iconFile": "res:/UI/Asset/mannequin/outer/37603_female_Outer_ArmorSuitCF01_Types_ArmorSuitCF01_SOERed.png", "iconType": "png"}
2160	21497	{"_key": 21497, "iconFile": "res:/UI/Asset/mannequin/outer/37863_female_Outer_ArmorSuitCF01_Types_ArmorSuitCF01_BlueWhite.png", "iconType": "png"}
2161	21498	{"_key": 21498, "iconFile": "res:/UI/Asset/mannequin/outer/37810_male_outer_ArmorSuitMM01_Types_ArmorSuitMM01_Black.png", "iconType": "png"}
2162	21499	{"_key": 21499, "iconFile": "res:/UI/Asset/mannequin/outer/37811_male_outer_ArmorSuitMM01_Types_ArmorSuitMM01_Copper.png", "iconType": "png"}
2163	21500	{"_key": 21500, "iconFile": "res:/UI/Asset/mannequin/outer/37815_male_outer_ArmorSuitMM01_Types_ArmorSuitMM01_SOERed.png", "iconType": "png"}
2164	21501	{"_key": 21501, "iconFile": "res:/UI/Asset/mannequin/outer/37818_male_outer_ArmorSuitMM01_Types_ArmorSuitMM01_Blue.png", "iconType": "png"}
2165	21502	{"_key": 21502, "iconFile": "res:/UI/Asset/mannequin/outer/37864_male_outer_ArmorSuitMM01_Types_ArmorSuitMM01_BlueWhite.png", "iconType": "png"}
2166	21503	{"_key": 21503, "iconFile": "res:/UI/Asset/mannequin/outer/37816_female_Outer_JacketSLF_01_Types_JacketSLF_01_redcicles.png", "iconType": "png"}
2167	21504	{"_key": 21504, "iconFile": "res:/UI/Asset/mannequin/outer/37817_male_outer_JacketALM01_Types_JacketALM01_PurpleGold.png", "iconType": "png"}
2168	21505	{"_key": 21505, "iconFile": "res:/UI/Asset/mannequin/outer/37806_female_Outer_JacketFBR01_Types_JacketFBR01_concord.png", "iconType": "png"}
2169	21506	{"_key": 21506, "iconFile": "res:/UI/Asset/mannequin/outer/37807_male_outer_JacketCLM01_Types_JacketCLM01_Concord.png", "iconType": "png"}
2170	21507	{"_key": 21507, "iconFile": "res:/UI/Asset/mannequin/topmiddle/37808_female_TopMiddle_ShirtQF01_Types_ShirtQF01_Concord.png", "iconType": "png"}
2171	21508	{"_key": 21508, "iconFile": "res:/UI/Asset/mannequin/topmiddle/37809_male_topMiddle_ShirtQM01_Types_ShirtQM01_Concord.png", "iconType": "png"}
2172	21509	{"_key": 21509, "iconFile": "res:/UI/Asset/mannequin/topmiddle/37865_female_TopMiddle_ShirtCF01_Types_ShirtF01_Serpentis.png", "iconType": "png"}
2173	21510	{"_key": 21510, "iconFile": "res:/UI/Asset/mannequin/topmiddle/37866_male_topMiddle_ShirtCM01_Types_ShirtM01_Serpentis.png", "iconType": "png"}
2174	21512	{"_key": 21512, "iconFile": "res:/UI/Texture/classes/Fitting/stationServiceSlot.png", "iconType": "png"}
2175	21513	{"_key": 21513, "iconFile": "res:/ui/texture/icons/118_64_12.png"}
2176	21514	{"_key": 21514, "iconFile": "res:/UI/Asset/mannequin/outer/40522_male_outer_JacketMilM02_Types_JacketMilM02_upwell.png"}
2177	21515	{"_key": 21515, "iconFile": "res:/UI/Asset/mannequin/outer/40523_female_Outer_JacketMilF01_Types_JacketMilF01_upwell.png"}
2178	21517	{"_key": 21517, "iconFile": "res:/UI/Asset/mannequin/topmiddle/40526_male_topMiddle_ShirtQM01_Types_shirtqm01_upwell.png"}
2179	21518	{"_key": 21518, "iconFile": "res:/UI/Asset/mannequin/topmiddle/40527_female_TopMiddle_ShirtQF01_Types_shirtqf01_upwell.png"}
2180	21519	{"_key": 21519, "iconFile": "res:/UI/Asset/mannequin/bottomouter/40524_male_bottomOuter_PantsMilM01_Types_PantsMilM01_upwell.png"}
2181	21520	{"_key": 21520, "iconFile": "res:/UI/Asset/mannequin/bottomouter/40525_female_bottomOuter_PantsMilF01_Types_PantsMilF01_upwell.png"}
2182	21522	{"_key": 21522, "iconFile": "res:/UI/Asset/mannequin/outer/40457_female_Outer_LabCoatF01_Types_LabCoatF01_BlackRed.png"}
2183	21523	{"_key": 21523, "iconFile": "res:/UI/Asset/mannequin/outer/40458_female_Outer_LabCoatF01_Types_LabCoatF01_Cyan.png"}
2184	21524	{"_key": 21524, "iconFile": "res:/UI/Asset/mannequin/outer/40459_female_Outer_LabCoatF01_Types_LabCoatF01_Orange.png"}
2185	21525	{"_key": 21525, "iconFile": "res:/UI/Asset/mannequin/outer/40460_female_Outer_LabCoatF01_Types_LabCoatF01_Green.png"}
2186	21526	{"_key": 21526, "iconFile": "res:/UI/Asset/mannequin/outer/40461_male_outer_LabCoatM01_Types_LabCoatM01_BlackRed.png"}
2187	21527	{"_key": 21527, "iconFile": "res:/UI/Asset/mannequin/outer/40462_male_outer_LabCoatM01_Types_LabCoatM01_Cyan.png"}
2188	21528	{"_key": 21528, "iconFile": "res:/UI/Asset/mannequin/outer/40463_male_outer_LabCoatM01_Types_LabCoatM01_Green.png"}
2189	21529	{"_key": 21529, "iconFile": "res:/UI/Asset/mannequin/outer/40464_male_outer_LabCoatM01_Types_LabCoatM01_Orange.png"}
2190	21530	{"_key": 21530, "iconFile": "res:/UI/Texture/Icons/skillExtractor_64.png", "iconType": "png"}
2191	21531	{"_key": 21531, "iconFile": "res:/UI/Texture/Icons/skillInjector_64.png", "iconType": "png"}
2192	21532	{"_key": 21532, "iconFile": "res:/ui/texture/icons/118_64_3.png"}
2193	21533	{"_key": 21533, "iconFile": "res:/ui/texture/icons/118_64_4.png"}
2194	21534	{"_key": 21534, "iconFile": "res:/ui/texture/icons/118_64_8.png"}
2195	21560	{"_key": 21560, "iconFile": "res:/ui/texture/icons/123_64_5.png"}
2196	21561	{"_key": 21561, "iconFile": "res:/ui/texture/icons/123_64_6.png"}
2197	21562	{"_key": 21562, "iconFile": "res:/ui/texture/icons/123_64_7.png"}
2198	21563	{"_key": 21563, "iconFile": "res:/ui/texture/icons/123_64_8.png"}
2199	21564	{"_key": 21564, "iconFile": "res:/ui/texture/icons/123_64_9.png"}
2200	21565	{"_key": 21565, "iconFile": "res:/ui/texture/icons/123_64_10.png"}
2201	21566	{"_key": 21566, "iconFile": "res:/ui/texture/icons/123_64_11.png"}
2202	21567	{"_key": 21567, "iconFile": "res:/ui/texture/icons/124_64_5.png"}
2203	21568	{"_key": 21568, "iconFile": "res:/ui/texture/icons/124_64_6.png"}
2204	21569	{"_key": 21569, "iconFile": "res:/ui/texture/icons/124_64_7.png"}
2205	21570	{"_key": 21570, "iconFile": "res:/ui/texture/icons/124_64_9.png"}
2206	21571	{"_key": 21571, "iconFile": "res:/ui/texture/icons/124_64_10.png"}
2207	21572	{"_key": 21572, "iconFile": "res:/ui/texture/icons/124_64_11.png"}
2208	21573	{"_key": 21573, "iconFile": "res:/ui/texture/icons/124_64_13.png"}
2209	21574	{"_key": 21574, "iconFile": "res:/ui/texture/icons/124_64_14.png"}
2210	21575	{"_key": 21575, "iconFile": "res:/ui/texture/icons/124_64_15.png"}
2211	21578	{"_key": 21578, "iconFile": "res:/ui/texture/icons/1337_64_23.png"}
2212	21579	{"_key": 21579, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/41049_female_Makeup_Augmentations_Face_01_Types_Face_01_F_V0_.png", "iconType": "png"}
2213	21581	{"_key": 21581, "iconFile": "res:/UI/Texture/Icons/125_64_1.png"}
2214	21582	{"_key": 21582, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/41036_male_Makeup_Augmentations_Face_01_Types_Face_01_M_V2_.png", "iconType": "png"}
2215	21583	{"_key": 21583, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/41050_female_Makeup_Augmentations_Face_01_Types_Face_01_F_V4_.png", "iconType": "png"}
2216	21584	{"_key": 21584, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/41051_female_Makeup_Augmentations_Face_01_Types_Face_01_F_V3_.png", "iconType": "png"}
2217	21585	{"_key": 21585, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/41047_male_Makeup_Augmentations_Face_01_Types_Face_01_M_V1_.png", "iconType": "png"}
2218	21586	{"_key": 21586, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/41052_female_Makeup_Augmentations_Face_01_Types_Face_01_F_V1_.png", "iconType": "png"}
2219	21587	{"_key": 21587, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/41053_female_Makeup_Augmentations_Face_01_Types_Face_01_F_V5_.png", "iconType": "png"}
2220	21588	{"_key": 21588, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/41046_male_Makeup_Augmentations_Face_01_Types_Face_01_M_V5_.png", "iconType": "png"}
2221	21589	{"_key": 21589, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/41043_male_Makeup_Augmentations_Face_01_Types_Face_01_M_V4_.png", "iconType": "png"}
2222	21590	{"_key": 21590, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/41044_male_Makeup_Augmentations_Face_01_Types_Face_01_M_V3_.png", "iconType": "png"}
2223	21591	{"_key": 21591, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/41048_female_Makeup_Augmentations_Face_01_Types_Face_01_F_V2_.png", "iconType": "png"}
2224	21592	{"_key": 21592, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/41045_male_Makeup_Augmentations_Face_01_Types_Face_01_M_V0_.png", "iconType": "png"}
2225	21593	{"_key": 21593, "iconFile": "res:/UI/Texture/Icons/126_64_1.png"}
2226	21594	{"_key": 21594, "iconFile": "res:/ui/texture/icons/127_64_9.png"}
2227	21595	{"_key": 21595, "iconFile": "res:/ui/texture/icons/127_64_2.png"}
2228	21596	{"_key": 21596, "iconFile": "res:/ui/texture/icons/127_64_1.png"}
2229	21597	{"_key": 21597, "iconFile": "res:/ui/texture/icons/127_64_3.png"}
2230	21598	{"_key": 21598, "iconFile": "res:/ui/texture/icons/127_64_4.png"}
2231	21599	{"_key": 21599, "iconFile": "res:/ui/texture/icons/127_64_5.png"}
2232	21600	{"_key": 21600, "iconFile": "res:/ui/texture/icons/127_64_6.png"}
2233	21601	{"_key": 21601, "iconFile": "res:/ui/texture/icons/127_64_10.png"}
2234	21602	{"_key": 21602, "iconFile": "res:/ui/texture/icons/127_64_7.png"}
2235	21603	{"_key": 21603, "iconFile": "res:/UI/Texture/Icons/Modules/emergencyHullEnergizer.png"}
2236	21604	{"_key": 21604, "iconFile": "res:/UI/Texture/Icons/Modules/burstProjectorECM.png"}
2237	21605	{"_key": 21605, "iconFile": "res:/UI/Texture/Icons/Modules/burstProjectorEnergyNeutralization.png"}
2238	21606	{"_key": 21606, "iconFile": "res:/UI/Texture/Icons/Modules/burstProjectorGuidanceDisruption.png"}
2239	21607	{"_key": 21607, "iconFile": "res:/UI/Texture/Icons/Modules/burstProjectorSensorDampening.png"}
2240	21608	{"_key": 21608, "iconFile": "res:/UI/Texture/Icons/Modules/burstProjectorStasisWebification.png"}
2241	21609	{"_key": 21609, "iconFile": "res:/UI/Texture/Icons/Modules/burstProjectorTargetIllumination.png"}
2242	21610	{"_key": 21610, "iconFile": "res:/UI/Texture/Icons/Modules/burstProjectorTrackingDisruption.png"}
2243	21611	{"_key": 21611, "iconFile": "res:/UI/Texture/Icons/Modules/burstProjectorWarpDisruption.png"}
2244	21613	{"_key": 21613, "iconFile": "res:/ui/texture/icons/4_64_9.png"}
2245	21614	{"_key": 21614, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/41575_female_Accessories_Glasses_Glasses_Citadel_F01_Types_GlassesCitadelF01_black.png"}
2246	21615	{"_key": 21615, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/41576_male_Accessories_Glasses_Glasses_Citadel_M01_Types_GlassesCitadelM01_black.png"}
2247	21617	{"_key": 21617, "iconFile": "res:/UI/Texture/Icons/Modules/emergencyHullEnergizer.png"}
2248	21618	{"_key": 21618, "iconFile": "res:/UI/Texture/Icons/Modules/multiUseAnalyzer_64.png"}
2249	21620	{"_key": 21620, "iconFile": "res:/UI/Texture/Icons/Inventory/serpentisContainerBronze_64.png"}
2250	21621	{"_key": 21621, "iconFile": "res:/UI/Texture/Icons/Inventory/serpentisContainerSilver_64.png"}
2251	21622	{"_key": 21622, "iconFile": "res:/UI/Texture/Icons/Inventory/serpentisContainerGold_64.png"}
2252	21624	{"_key": 21624, "iconFile": "res:/UI/Asset/mannequin/hair/42698_female_hair_HeadWear_Beret_F01_Types_HeadWear_Beret_GuristasF01B.png"}
2253	21626	{"_key": 21626, "iconFile": "res:/UI/Asset/mannequin/hair/42699_male_hair_HeadWear_Beret_M01_Types_HeadWear_Beret_GuristasM01B.png"}
2254	21627	{"_key": 21627, "iconFile": "res:/UI/Asset/mannequin/hair/42708_male_hair_HeadWear_Beret_M01_Types_HeadWear_Beret_BloodraidersM01.png"}
2255	21628	{"_key": 21628, "iconFile": "res:/UI/Asset/mannequin/hair/42709_female_hair_HeadWear_Beret_F01_Types_HeadWear_Beret_GallenteF01.png"}
2256	21629	{"_key": 21629, "iconFile": "res:/UI/Asset/mannequin/hair/42710_male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_Gallente.png"}
2257	21630	{"_key": 21630, "iconFile": "res:/UI/Asset/mannequin/hair/42711_male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_Green.png"}
2258	21631	{"_key": 21631, "iconFile": "res:/UI/Asset/mannequin/hair/42712_male_hair_HeadWear_Beret_M01_Types_HeadWear_Beret_MinmatarM01.png"}
2259	21632	{"_key": 21632, "iconFile": "res:/UI/Asset/mannequin/hair/42713_male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_Orange.png"}
2260	21633	{"_key": 21633, "iconFile": "res:/UI/Asset/mannequin/hair/42714_male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_WhiteBlack.png"}
2261	21634	{"_key": 21634, "iconFile": "res:/UI/Asset/mannequin/hair/42715_female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_Minmatar.png"}
2262	21635	{"_key": 21635, "iconFile": "res:/UI/Asset/mannequin/hair/42716_female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_WhiteBlack.png"}
2263	21636	{"_key": 21636, "iconFile": "res:/UI/Asset/mannequin/hair/42717_female_hair_HeadWear_Beret_F01_Types_HeadWear_Beret_GuristasF01.png"}
2264	21637	{"_key": 21637, "iconFile": "res:/UI/Asset/mannequin/hair/42718_female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_Blood.png"}
2265	21638	{"_key": 21638, "iconFile": "res:/UI/Asset/mannequin/hair/42719_male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_Concord.png"}
2266	21640	{"_key": 21640, "iconFile": "res:/UI/Asset/mannequin/hair/42720_female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_Caldari.png"}
2267	21641	{"_key": 21641, "iconFile": "res:/UI/Asset/mannequin/hair/42721_male_hair_HeadWear_Beret_M01_Types_HeadWear_Beret_GuristasM01.png"}
2268	21642	{"_key": 21642, "iconFile": "res:/UI/Asset/mannequin/hair/42722_female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_Guristas.png"}
2269	21643	{"_key": 21643, "iconFile": "res:/UI/Asset/mannequin/hair/42723_male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_Black.png"}
2270	21644	{"_key": 21644, "iconFile": "res:/UI/Asset/mannequin/hair/42724_male_hair_HeadWear_Beret_M01_Types_HeadWear_Beret_ConcordM01.png"}
2271	21645	{"_key": 21645, "iconFile": "res:/UI/Asset/mannequin/hair/42725_female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_Amarr.png"}
2272	21646	{"_key": 21646, "iconFile": "res:/UI/Asset/mannequin/hair/42726_male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_Blood.png"}
2273	21647	{"_key": 21647, "iconFile": "res:/UI/Asset/mannequin/hair/42727_female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_Green.png"}
2274	21648	{"_key": 21648, "iconFile": "res:/UI/Asset/mannequin/hair/42728_male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_Amarr.png"}
2275	21649	{"_key": 21649, "iconFile": "res:/UI/Asset/mannequin/hair/42729_female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_Camo.png"}
2276	21650	{"_key": 21650, "iconFile": "res:/UI/Asset/mannequin/hair/42730_male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_Minmatar.png"}
2277	21651	{"_key": 21651, "iconFile": "res:/UI/Asset/mannequin/hair/42731_male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_Caldari.png"}
2278	21652	{"_key": 21652, "iconFile": "res:/UI/Asset/mannequin/hair/42732_male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_Camo.png"}
2279	21654	{"_key": 21654, "iconFile": "res:/UI/Asset/mannequin/hair/42733_female_hair_HeadWear_Beret_F01_Types_HeadWear_Beret_BloodraidersF01.png"}
2280	21655	{"_key": 21655, "iconFile": "res:/UI/Asset/mannequin/hair/42734_female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_Black.png"}
2281	21656	{"_key": 21656, "iconFile": "res:/UI/Asset/mannequin/hair/42735_female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_Orange.png"}
2282	21657	{"_key": 21657, "iconFile": "res:/UI/Asset/mannequin/hair/42736_male_hair_HeadWear_Beret_M01_Types_HeadWear_Beret_CaldariM01.png"}
2283	21658	{"_key": 21658, "iconFile": "res:/UI/Asset/mannequin/hair/42737_female_hair_HeadWear_Beret_F01_Types_HeadWear_Beret_ConcordF01.png"}
2284	21659	{"_key": 21659, "iconFile": "res:/UI/Asset/mannequin/hair/42738_female_hair_HeadWear_Beret_F01_Types_HeadWear_Beret_MinmatarF01.png"}
2285	21660	{"_key": 21660, "iconFile": "res:/UI/Asset/mannequin/hair/42739_male_hair_HeadWear_Beret_M01_Types_HeadWear_Beret_GallenteM01.png"}
2286	21661	{"_key": 21661, "iconFile": "res:/UI/Asset/mannequin/hair/42740_female_hair_HeadWear_Beret_F01_Types_HeadWear_Beret_CaldariF01.png"}
2287	21662	{"_key": 21662, "iconFile": "res:/UI/Asset/mannequin/hair/42741_male_hair_HeadWear_Beret_M01_Types_HeadWear_Beret_AmarrM01.png"}
2288	21663	{"_key": 21663, "iconFile": "res:/UI/Asset/mannequin/hair/42742_female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_Concord.png"}
2289	21664	{"_key": 21664, "iconFile": "res:/UI/Asset/mannequin/hair/42743_male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_Guristas.png"}
2290	21665	{"_key": 21665, "iconFile": "res:/UI/Asset/mannequin/hair/42744_female_hair_HeadWear_Beret_F01_Types_HeadWear_Beret_AmarrF01.png"}
2291	21666	{"_key": 21666, "iconFile": "res:/UI/Asset/mannequin/hair/42745_female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_Gallente.png"}
2292	21667	{"_key": 21667, "iconFile": "res:/UI/Asset/mannequin/topouter/42707_female_TopOuter_ShirtMilF01_Types_ShirtMilF01_bloodraiders.png"}
2293	21668	{"_key": 21668, "iconFile": "res:/UI/Asset/mannequin/topmiddle/42700_female_TopMiddle_ShirtQF01_Types_ShirtBloodraidersF01.png"}
2294	21669	{"_key": 21669, "iconFile": "res:/UI/Asset/mannequin/topmiddle/42704_male_topMiddle_ShirtQM01_Types_ShirtBloodraidersM01.png"}
2295	21670	{"_key": 21670, "iconFile": "res:/UI/Asset/mannequin/outer/42702_male_outer_JacketMFBR01_Types_JacketMFBR02_Bloodraiders.png"}
2296	21671	{"_key": 21671, "iconFile": "res:/UI/Asset/mannequin/outer/42703_female_Outer_JacketFBR01_Types_JacketFBR02_bloodraiders.png"}
2297	21672	{"_key": 21672, "iconFile": "res:/UI/Asset/mannequin/outer/42705_male_outer_JacketPrtm01_Types_JacketPrtm01_bloodraiders_spec.png"}
2298	21673	{"_key": 21673, "iconFile": "res:/UI/Asset/mannequin/outer/42706_female_Outer_JacketPrtF01_Types_JacketPrtF01_bloodraiders_spec.png"}
2299	21674	{"_key": 21674, "iconFile": "res:/UI/Asset/mannequin/bottomouter/42701_female_bottomOuter_PantsMilF01_Types_PantsMilF01_bloodraiders.png"}
2300	21675	{"_key": 21675, "iconFile": "res:/ui/texture/icons/cmd_brst_info_ph.png"}
2301	21676	{"_key": 21676, "iconFile": "res:/ui/texture/icons/cmd_brst_skrmsh_ph.png"}
2302	21677	{"_key": 21677, "iconFile": "res:/ui/texture/icons/cmd_brst_mine_ph.png"}
2303	21678	{"_key": 21678, "iconFile": "res:/ui/texture/icons/cmd_brst_armor_ph.png"}
2304	21679	{"_key": 21679, "iconFile": "res:/ui/texture/icons/cmd_brst_shield_ph.png"}
2305	21680	{"_key": 21680, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/42905_female_Accessories_Glasses_Goggles_01_Types_goggles_01_orange.png"}
2306	21681	{"_key": 21681, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/42906_male_Accessories_Glasses_Goggles_01_Types_goggles_01_orange.png"}
2307	21683	{"_key": 21683, "iconFile": "res:/UI/Texture/Icons/Modules/titanGeneratorAmarr.png"}
2308	21684	{"_key": 21684, "iconFile": "res:/UI/Texture/Icons/Modules/titanGeneratorCaldari.png"}
2309	21685	{"_key": 21685, "iconFile": "res:/UI/Texture/Icons/Modules/titanGeneratorGallente.png"}
2310	21686	{"_key": 21686, "iconFile": "res:/UI/Texture/Icons/Modules/titanGeneratorMinmatar.png"}
2311	21687	{"_key": 21687, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_ArmorBase.png"}
2312	21688	{"_key": 21688, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_ArmorBuffer.png"}
2313	21689	{"_key": 21689, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_ArmorRepair.png"}
2314	21690	{"_key": 21690, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_ArmorResists.png"}
2315	21691	{"_key": 21691, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_InfoBase.png"}
2316	21692	{"_key": 21692, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_InfoEwar.png"}
2317	21693	{"_key": 21693, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_InfoSensors.png"}
2318	21694	{"_key": 21694, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_InfoTargeting.png"}
2319	21695	{"_key": 21695, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_MiningBase.png"}
2320	21696	{"_key": 21696, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_MiningCrystal.png"}
2321	21698	{"_key": 21698, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_MiningCycle.png"}
2322	21699	{"_key": 21699, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_MiningRange.png"}
2323	21700	{"_key": 21700, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_ShieldBase.png"}
2324	21701	{"_key": 21701, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_ShieldBuffer.png"}
2325	21702	{"_key": 21702, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_ShieldRepair.png"}
2326	21703	{"_key": 21703, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_ShieldResists.png"}
2327	21704	{"_key": 21704, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_SkirmishBase.png"}
2328	21705	{"_key": 21705, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_SkirmishSignature.png"}
2329	21706	{"_key": 21706, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_SkirmishSpeed.png"}
2330	21707	{"_key": 21707, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_SkirmishWeb.png"}
2331	21708	{"_key": 21708, "iconFile": "res:/UI/Texture/Shared/Effects/fleetBoostEffect_ArmorBuffer.png"}
2332	21709	{"_key": 21709, "iconFile": "res:/UI/Texture/Shared/Effects/fleetBoostEffect_ArmorRepair.png"}
2333	21710	{"_key": 21710, "iconFile": "res:/UI/Texture/Shared/Effects/fleetBoostEffect_ArmorResists.png"}
2334	21711	{"_key": 21711, "iconFile": "res:/UI/Texture/Shared/Effects/fleetBoostEffect_Base.png"}
2335	21712	{"_key": 21712, "iconFile": "res:/UI/Texture/Shared/Effects/fleetBoostEffect_InfoEwar.png"}
2336	21713	{"_key": 21713, "iconFile": "res:/UI/Texture/Shared/Effects/fleetBoostEffect_InfoSensors.png"}
2337	21714	{"_key": 21714, "iconFile": "res:/UI/Texture/Shared/Effects/fleetBoostEffect_InfoTargeting.png"}
2338	21715	{"_key": 21715, "iconFile": "res:/UI/Texture/Shared/Effects/fleetBoostEffect_MiningCrystal.png"}
2339	21716	{"_key": 21716, "iconFile": "res:/UI/Texture/Shared/Effects/fleetBoostEffect_MiningCycle.png"}
2340	21717	{"_key": 21717, "iconFile": "res:/UI/Texture/Shared/Effects/fleetBoostEffect_MiningRange.png"}
2341	21718	{"_key": 21718, "iconFile": "res:/UI/Texture/Shared/Effects/fleetBoostEffect_ShieldBuffer.png"}
2342	21719	{"_key": 21719, "iconFile": "res:/UI/Texture/Shared/Effects/fleetBoostEffect_ShieldRepair.png"}
2343	21720	{"_key": 21720, "iconFile": "res:/UI/Texture/Shared/Effects/fleetBoostEffect_ShieldResists.png"}
2344	21721	{"_key": 21721, "iconFile": "res:/UI/Texture/Shared/Effects/fleetBoostEffect_SkirmishSignature.png"}
2345	21722	{"_key": 21722, "iconFile": "res:/UI/Texture/Shared/Effects/fleetBoostEffect_SkirmishSpeed.png"}
2346	21723	{"_key": 21723, "iconFile": "res:/UI/Texture/Shared/Effects/fleetBoostEffect_SkirmishWeb.png"}
2347	21724	{"_key": 21724, "iconFile": "res:/UI/Texture/Icons/Modules/titanGeneratorMultiple.png"}
2348	21725	{"_key": 21725, "iconFile": "res:/ui/texture/icons/inventory/empireCrate.png"}
2349	21729	{"_key": 21729, "iconFile": "res:/ui/texture/icons/127_64_8.png"}
2350	21730	{"_key": 21730, "iconFile": "res:/UI/Texture/Icons/Modules/panicModule.png"}
2351	21731	{"_key": 21731, "iconFile": "res:/UI/texture/icons/inventory/skillInjectorMini_64.png", "iconType": "png"}
2352	21732	{"_key": 21732, "iconFile": "res:/ui/texture/icons/50_64_11.png"}
2353	21734	{"_key": 21734, "iconFile": "res:/UI/Asset/mannequin/bottomouter/44121_female_bottomOuter_PantsMilF01_Types_PantsMilF01_C16.png", "iconType": "png"}
2354	21735	{"_key": 21735, "iconFile": "res:/UI/Asset/mannequin/bottomouter/44124_male_bottomOuter_PantsMilM01_Types_PantsMilM01_C16.png", "iconType": "png"}
2355	21736	{"_key": 21736, "iconFile": "res:/UI/Asset/mannequin/hair/44122_female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_C16.png", "iconType": "png"}
2356	21738	{"_key": 21738, "iconFile": "res:/UI/Asset/mannequin/hair/44125_male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_C16.png", "iconType": "png"}
2357	21739	{"_key": 21739, "iconFile": "res:/UI/Asset/mannequin/topmiddle/44120_female_TopMiddle_TshirtF01_Types_TshirtF01_C16.png", "iconType": "png"}
2358	21740	{"_key": 21740, "iconFile": "res:/UI/Asset/mannequin/topmiddle/44123_male_topMiddle_TshirtM01_Types_TshirtM01_C16.png", "iconType": "png"}
2359	21741	{"_key": 21741, "iconFile": "res:/UI/Texture/Icons/Inventory/starterPack.png"}
2360	21742	{"_key": 21742, "iconFile": "res:/UI/Texture/Icons/Inventory/holidayCrate.png"}
2361	21743	{"_key": 21743, "iconFile": "res:/ui/texture/icons/118_64_15.png"}
2362	21744	{"_key": 21744, "iconFile": "res:/UI/Asset/mannequin/outer/45514_female_Outer_ExplorationSuit_F01_Types_ExplorationSuit_F01_SOE.png", "iconType": "png"}
2363	21745	{"_key": 21745, "iconFile": "res:/UI/Asset/mannequin/outer/45515_female_Outer_ExplorationSuit_F01_Types_ExplorationSuit_F01_Caldari.png", "iconType": "png"}
2364	21746	{"_key": 21746, "iconFile": "res:/UI/Asset/mannequin/outer/45516_female_Outer_ExplorationSuit_F01_Types_ExplorationSuit_F01_Minmatar.png", "iconType": "png"}
2365	21747	{"_key": 21747, "iconFile": "res:/UI/Asset/mannequin/outer/45517_female_Outer_ExplorationSuit_F01_Types_ExplorationSuit_F01_Gallente.png", "iconType": "png"}
2366	21748	{"_key": 21748, "iconFile": "res:/UI/Asset/mannequin/outer/45518_female_Outer_ExplorationSuit_F01_Types_ExplorationSuit_F01_Amarr.png", "iconType": "png"}
2367	21749	{"_key": 21749, "iconFile": "res:/UI/Asset/mannequin/outer/45519_female_Outer_ExplorationSuit_F01_Types_ExplorationSuit_F01_CaldariOrange.png", "iconType": "png"}
2368	21750	{"_key": 21750, "iconFile": "res:/UI/Asset/mannequin/outer/45520_female_Outer_ExplorationSuit_F01_Types_ExplorationSuit_F01_ORE.png", "iconType": "png"}
2369	21751	{"_key": 21751, "iconFile": "res:/UI/Asset/mannequin/outer/45521_male_outer_ExplorationSuit_M01_Types_ExplorationSuit_M01_Gallente.png", "iconType": "png"}
2370	21752	{"_key": 21752, "iconFile": "res:/UI/Asset/mannequin/outer/45522_male_outer_ExplorationSuit_M01_Types_ExplorationSuit_M01_ORE.png", "iconType": "png"}
2371	21753	{"_key": 21753, "iconFile": "res:/UI/Asset/mannequin/outer/45523_male_outer_ExplorationSuit_M01_Types_ExplorationSuit_M01_SOE.png", "iconType": "png"}
2372	21754	{"_key": 21754, "iconFile": "res:/UI/Asset/mannequin/outer/45524_male_outer_ExplorationSuit_M01_Types_ExplorationSuit_M01_Caldari.png", "iconType": "png"}
2373	21755	{"_key": 21755, "iconFile": "res:/UI/Asset/mannequin/outer/45525_male_outer_ExplorationSuit_M01_Types_ExplorationSuit_M01_Minmatar.png", "iconType": "png"}
2374	21756	{"_key": 21756, "iconFile": "res:/UI/Asset/mannequin/outer/45526_male_outer_ExplorationSuit_M01_Types_ExplorationSuit_M01_Amarr.png", "iconType": "png"}
2375	21757	{"_key": 21757, "iconFile": "res:/UI/Asset/mannequin/outer/45527_male_outer_ExplorationSuit_M01_Types_ExplorationSuit_M01_CaldariOrange.png", "iconType": "png"}
2376	21760	{"_key": 21760, "iconFile": "res:/UI/Texture/classes/ItemPacks/SplashImages/ProjectDiscoveryPlaceholder.png"}
2377	21763	{"_key": 21763, "iconFile": "res:/UI/Asset/mannequin/topmiddle/45734_female_TopMiddle_TshirtF01_Types_TshirtF01_Exo.png", "iconType": "png"}
2378	21764	{"_key": 21764, "iconFile": "res:/UI/Asset/mannequin/outer/45735_female_Outer_ExplorationSuit_F01_Types_ExplorationSuit_F01_Exo.png", "iconType": "png"}
2379	21765	{"_key": 21765, "iconFile": "res:/UI/Asset/mannequin/outer/45737_female_Outer_LabCoatF01_Types_LabCoatF01_Exo.png", "iconType": "png"}
2380	21766	{"_key": 21766, "iconFile": "res:/UI/Asset/mannequin/outer/45738_female_Outer_JacketMilF01_Types_JacketMilF01_exo.png", "iconType": "png"}
2381	21767	{"_key": 21767, "iconFile": "res:/UI/Asset/mannequin/hair/45739_female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_Exo.png", "iconType": "png"}
2382	21768	{"_key": 21768, "iconFile": "res:/UI/Asset/mannequin/hair/45740_male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_Exo.png", "iconType": "png"}
2383	21769	{"_key": 21769, "iconFile": "res:/UI/Asset/mannequin/outer/45741_male_outer_ExplorationSuit_M01_Types_ExplorationSuit_M01_Exo.png", "iconType": "png"}
2384	21770	{"_key": 21770, "iconFile": "res:/UI/Asset/mannequin/outer/45742_male_outer_JacketMilM02_Types_JacketMilM02_exo.png", "iconType": "png"}
2385	21771	{"_key": 21771, "iconFile": "res:/UI/Asset/mannequin/topmiddle/45743_male_TopMiddle_TshirtM01_Types_TshirtM01_Exo.png", "iconType": "png", "obsolete": 0}
2386	21772	{"_key": 21772, "iconFile": "res:/UI/Asset/mannequin/outer/45744_male_outer_LabCoatM01_Types_LabCoatM01_Exo.png", "iconType": "png"}
2387	21773	{"_key": 21773, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/45745_male_Accessories_Glasses_Glasses_Exo_M01_Types_Glasses_Exo_M01_clear.png", "iconType": "png"}
2388	21774	{"_key": 21774, "iconFile": "res:/UI/Texture/Icons/128_64_1.png", "iconType": "png"}
2389	21775	{"_key": 21775, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/45736_female_Accessories_Glasses_Glasses_Exo_F01_Types_Glasses_Exo_F01_clear.png", "iconType": "png"}
2390	21778	{"_key": 21778, "iconFile": "res:/UI/Asset/mannequin/outer/46038_male_outer_ExplorationSuit_M01_Types_ExplorationSuit_M01_IGC.png", "iconType": "png"}
2391	21779	{"_key": 21779, "iconFile": "res:/UI/Asset/mannequin/outer/46039_female_Outer_ExplorationSuit_F01_Types_ExplorationSuit_F01_IGC.png", "iconType": "png"}
2392	21780	{"_key": 21780, "iconFile": "res:/UI/Asset/mannequin/outer/46274_male_outer_JacketPrtm01_Types_JacketPrtm01_valkyrie.png", "iconType": "png"}
2393	21781	{"_key": 21781, "iconFile": "res:/UI/Asset/mannequin/outer/46273_female_Outer_JacketPrtF01_Types_JacketPrtF01_valkyrie.png", "iconType": "png"}
2394	21783	{"_key": 21783, "iconFile": "res:/ui/texture/icons/reaction.png"}
2395	21784	{"_key": 21784, "iconFile": "res:/UI/Texture/Icons/Inventory/dataCore.png", "iconType": "png"}
2396	21785	{"_key": 21785, "iconFile": "res:/UI/Texture/Icons/Inventory/relicVault.png", "iconType": "png"}
2397	21787	{"_key": 21787, "iconFile": "res:/UI/Texture/Icons/Modules/refinery_ChunkStabilization.png"}
2398	21788	{"_key": 21788, "iconFile": "res:/UI/Texture/Icons/Modules/refinery_MiningYield.png"}
2399	21789	{"_key": 21789, "iconFile": "res:/UI/Texture/Icons/Modules/refinery_BoosterReactions.png"}
2400	21790	{"_key": 21790, "iconFile": "res:/UI/Texture/Icons/Modules/refinery_HybridReactions.png"}
2401	21791	{"_key": 21791, "iconFile": "res:/UI/Texture/Icons/Modules/refinery_T2Reactions.png"}
2402	21792	{"_key": 21792, "iconFile": "res:/UI/Texture/Icons/Inventory/moonAsteroid_R4.png"}
2403	21793	{"_key": 21793, "iconFile": "res:/UI/Texture/Icons/Inventory/moonAsteroid_R8.png"}
2404	21794	{"_key": 21794, "iconFile": "res:/UI/Texture/Icons/Inventory/moonAsteroid_R16.png"}
2405	21795	{"_key": 21795, "iconFile": "res:/UI/Texture/Icons/Inventory/moonAsteroid_R32.png"}
2406	21796	{"_key": 21796, "iconFile": "res:/UI/Texture/Icons/Inventory/moonAsteroid_R64.png"}
2407	21797	{"_key": 21797, "iconFile": "res:/UI/Texture/Icons/Inventory/moonAsteroid_JackpotR4.png"}
2408	21798	{"_key": 21798, "iconFile": "res:/UI/Texture/Icons/Inventory/moonAsteroid_JackpotR8.png"}
2409	21799	{"_key": 21799, "iconFile": "res:/UI/Texture/Icons/Inventory/moonAsteroid_JackpotR16.png"}
2410	21800	{"_key": 21800, "iconFile": "res:/UI/Texture/Icons/Inventory/moonAsteroid_JackpotR32.png"}
2411	21801	{"_key": 21801, "iconFile": "res:/UI/Texture/Icons/Inventory/moonAsteroid_JackpotR64.png"}
2412	21802	{"_key": 21802, "iconFile": "res:/ui/texture/corps/federalStrategicMateriel.png"}
2413	21803	{"_key": 21803, "iconFile": "res:/ui/texture/corps/imperialWarReserves.png"}
2414	21804	{"_key": 21804, "iconFile": "res:/ui/texture/corps/republicFleetOrdnance.png"}
2415	21805	{"_key": 21805, "iconFile": "res:/ui/texture/corps/stateMilitaryStockpile.png"}
2416	21807	{"_key": 21807, "iconFile": "res:/UI/Asset/mannequin/outer/46658_female_Outer_JacketAGF01_Types_JacketAGF01_Gallente_RW.png", "iconType": "png"}
2417	21808	{"_key": 21808, "iconFile": "res:/UI/Asset/mannequin/outer/46659_male_outer_JacketCMM01_Types_JacketCMM01_Caldari.png", "iconType": "png"}
2418	21809	{"_key": 21809, "iconFile": "res:/UI/Asset/mannequin/outer/46660_female_Outer_JacketAGF01_Types_JacketAGF01_Gallente.png", "iconType": "png"}
2419	21810	{"_key": 21810, "iconFile": "res:/UI/Asset/mannequin/outer/46661_female_Outer_JacketCMF01_Types_JacketCMF01_Minmatar_RW.png", "iconType": "png"}
2420	21811	{"_key": 21811, "iconFile": "res:/UI/Asset/mannequin/outer/46662_male_outer_JacketAGM01_Types_JacketAGM01_Amarr.png", "iconType": "png"}
2421	21812	{"_key": 21812, "iconFile": "res:/UI/Asset/mannequin/outer/46663_female_Outer_JacketAGF01_Types_JacketAGF01_Amarr.png", "iconType": "png"}
2422	21813	{"_key": 21813, "iconFile": "res:/UI/Asset/mannequin/outer/46664_male_outer_JacketCMM01_Types_JacketCMM01_Minmatar.png", "iconType": "png"}
2423	21814	{"_key": 21814, "iconFile": "res:/UI/Asset/mannequin/outer/46665_male_outer_JacketAGM01_Types_JacketAGM01_Gallente.png", "iconType": "png"}
2424	21815	{"_key": 21815, "iconFile": "res:/UI/Asset/mannequin/outer/46666_male_outer_JacketAGM01_Types_JacketAGM01_Amarr_RW.png", "iconType": "png"}
2425	21816	{"_key": 21816, "iconFile": "res:/UI/Asset/mannequin/outer/46667_male_outer_JacketAGM01_Types_JacketAGM01_Gallente_RW.png", "iconType": "png"}
2426	21817	{"_key": 21817, "iconFile": "res:/UI/Asset/mannequin/outer/46668_female_Outer_JacketAGF01_Types_JacketAGF01_Amarr_RW.png", "iconType": "png"}
2427	21818	{"_key": 21818, "iconFile": "res:/UI/Asset/mannequin/outer/46669_female_Outer_JacketCMF01_Types_JacketCMF01_Caldari.png", "iconType": "png"}
2428	21819	{"_key": 21819, "iconFile": "res:/UI/Asset/mannequin/outer/46674_male_outer_JacketCMM01_Types_JacketCMM01_Minmatar_RW.png", "iconType": "png", "obsolete": 0}
2429	21820	{"_key": 21820, "iconFile": "res:/UI/Asset/mannequin/outer/46671_female_Outer_JacketCMF01_Types_JacketCMF01_Caldari_RW.png", "iconType": "png"}
2430	21821	{"_key": 21821, "iconFile": "res:/UI/Asset/mannequin/outer/46672_male_outer_JacketCMM01_Types_JacketCMM01_Caldari_RW.png", "iconType": "png"}
2431	21822	{"_key": 21822, "iconFile": "res:/UI/Asset/mannequin/outer/46673_female_Outer_JacketCMF01_Types_JacketCMF01_Minmatar.png", "iconType": "png"}
2432	21823	{"_key": 21823, "iconFile": "res:/UI/Texture/Icons/Inventory/rwAsteroid.png"}
2433	21829	{"_key": 21829, "iconFile": "res:/ui/texture/icons/Inventory/biochemMaterials.png"}
2434	21830	{"_key": 21830, "iconFile": "res:/UI/Texture/Icons/Inventory/crateAmarr.png"}
2435	21831	{"_key": 21831, "iconFile": "res:/UI/Texture/Icons/Inventory/crateCaldari.png"}
2436	21832	{"_key": 21832, "iconFile": "res:/UI/Texture/Icons/Inventory/crateGallente.png"}
2437	21833	{"_key": 21833, "iconFile": "res:/UI/Texture/Icons/Inventory/crateMinmatar.png"}
2438	21835	{"_key": 21835, "iconFile": "res:/UI/Texture/Icons/Inventory/skillInjectorAlpha.png"}
2439	21836	{"_key": 21836, "iconFile": "res:/UI/Asset/mannequin/outer/47031_female_Outer_JacketSLF_01_Types_JacketSLF_01_JinMeiOpera.png", "iconType": "png"}
2440	21837	{"_key": 21837, "iconFile": "res:/UI/Asset/mannequin/outer/47032_male_outer_JacketALM01_Types_JacketALM01_JinMeiOpera.png", "iconType": "png"}
2441	21839	{"_key": 21839, "iconFile": "res:/UI/Texture/Icons/Inventory/boosterAgencyDamage.png"}
2442	21840	{"_key": 21840, "iconFile": "res:/UI/Texture/Icons/Inventory/boosterAgencySpeed.png"}
2443	21841	{"_key": 21841, "iconFile": "res:/UI/Texture/Icons/Inventory/boosterAgencyTank.png"}
2444	21843	{"_key": 21843, "iconFile": "res:/ui/texture/icons/25_64_16.png"}
2445	21844	{"_key": 21844, "iconFile": "res:/ui/texture/icons/25_64_3.png"}
2446	21845	{"_key": 21845, "iconFile": "res:/UI/Asset/mannequin/hair/47191_male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_XV_BlackOrange.png", "iconType": "png"}
2447	21846	{"_key": 21846, "iconFile": "res:/UI/Asset/mannequin/topmiddle/47192_female_TopMiddle_TshirtF01_Types_TshirtF01_XV_StarOrange.png", "iconType": "png"}
2448	21847	{"_key": 21847, "iconFile": "res:/UI/Asset/mannequin/topmiddle/47182_male_TopMiddle_TshirtM01_Types_TshirtM01_XV_Amarr.png", "iconType": "png"}
2449	21848	{"_key": 21848, "iconFile": "res:/UI/Asset/mannequin/topmiddle/47183_male_TopMiddle_TshirtM01_Types_TshirtM01_XV_Minmatar.png", "iconType": "png"}
2450	21849	{"_key": 21849, "iconFile": "res:/UI/Asset/mannequin/topmiddle/47184_male_TopMiddle_TshirtM01_Types_TshirtM01_XV_Gallente.png", "iconType": "png"}
2451	21850	{"_key": 21850, "iconFile": "res:/UI/Asset/mannequin/topmiddle/47185_female_TopMiddle_TshirtF01_Types_TshirtF01_XV_Gallente.png", "iconType": "png"}
2452	21851	{"_key": 21851, "iconFile": "res:/UI/Asset/mannequin/topmiddle/47186_female_TopMiddle_TshirtF01_Types_TshirtF01_XV_Amarr.png", "iconType": "png"}
2453	21853	{"_key": 21853, "iconFile": "res:/UI/Asset/mannequin/topmiddle/47188_male_TopMiddle_TshirtM01_Types_TshirtM01_XV_Caldari.png", "iconType": "png"}
2454	21854	{"_key": 21854, "iconFile": "res:/UI/Asset/mannequin/topmiddle/47189_female_TopMiddle_TshirtF01_Types_TshirtF01_XV_Caldari.png", "iconType": "png"}
2455	21855	{"_key": 21855, "iconFile": "res:/UI/Asset/mannequin/topmiddle/47190_male_TopMiddle_TshirtM01_Types_TshirtM01_XV_StarOrange.png", "iconType": "png"}
2456	21857	{"_key": 21857, "iconFile": "res:/UI/Asset/mannequin/topmiddle/47187_female_TopMiddle_TshirtF01_Types_TshirtF01_XV_Minmatar.png", "iconType": "png"}
2457	21858	{"_key": 21858, "iconFile": "res:/UI/Asset/mannequin/hair/47193_female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_XV_BlackOrange.png", "iconType": "png"}
2458	21860	{"_key": 21860, "iconFile": "res:/UI/Texture/Icons/Modules/AssaultDamageControl.png"}
2459	21872	{"_key": 21872, "iconFile": "res:/UI/Asset/mannequin/outer/47287_female_Outer_ArmorSuitCF01_Types_ArmorSuitCF01_SWAT.png", "iconType": "png"}
2460	21873	{"_key": 21873, "iconFile": "res:/UI/Asset/mannequin/outer/47286_male_outer_ArmorSuitMM01_Types_ArmorSuitMM01_SWAT.png", "iconType": "png"}
2461	21877	{"_key": 21877, "iconFile": "res:/UI/Texture/Icons/StatusEffects/tetherDisabled.png"}
2462	21878	{"_key": 21878, "iconFile": "res:/UI/Asset/mannequin/hair/47477_female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_XV_FF.png", "iconType": "png"}
2463	21879	{"_key": 21879, "iconFile": "res:/UI/Asset/mannequin/hair/47478_male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_XV_FF.png", "iconType": "png"}
2464	21880	{"_key": 21880, "iconFile": "res:/UI/Asset/mannequin/outer/47475_female_Outer_ExplorationSuit_F01_Types_ExplorationSuit_F01_XV.png", "iconType": "png"}
2465	21881	{"_key": 21881, "iconFile": "res:/UI/Asset/mannequin/outer/47476_male_outer_ExplorationSuit_M01_Types_ExplorationSuit_M01_XV.png", "iconType": "png"}
2466	21882	{"_key": 21882, "iconFile": "res:/UI/Asset/mannequin/topmiddle/47479_female_TopMiddle_TshirtF01_Types_TshirtF01_XV_FF.png", "iconType": "png"}
2467	21883	{"_key": 21883, "iconFile": "res:/UI/Asset/mannequin/topmiddle/47480_male_TopMiddle_TshirtM01_Types_TshirtM01_XV_FF.png", "iconType": "png"}
2468	21888	{"_key": 21888, "iconFile": "res:/ui/texture/icons/Modules/mutatorDecayed.png"}
2469	21890	{"_key": 21890, "iconFile": "res:/ui/texture/icons/Modules/mutatorGravid.png"}
2470	21891	{"_key": 21891, "iconFile": "res:/ui/texture/icons/Modules/mutatorUnstable.png"}
2471	21892	{"_key": 21892, "iconFile": "res:/ui/texture/icons/Modules/abyssalAfterburner.png"}
2472	21893	{"_key": 21893, "iconFile": "res:/ui/texture/icons/Modules/abyssalMWD.png"}
2473	21894	{"_key": 21894, "iconFile": "res:/ui/texture/icons/Modules/abyssalPlate.png"}
2474	21895	{"_key": 21895, "iconFile": "res:/ui/texture/icons/Modules/abyssalRepairer.png"}
2475	21896	{"_key": 21896, "iconFile": "res:/ui/texture/icons/Modules/abyssalNeut.png"}
2476	21897	{"_key": 21897, "iconFile": "res:/ui/texture/icons/Modules/abyssalNosferatu.png"}
2477	21898	{"_key": 21898, "iconFile": "res:/UI/Texture/Icons/Inventory/crateCapsuleerDay.png"}
2478	21899	{"_key": 21899, "iconFile": "res:/UI/Texture/Icons/Inventory/crateChristmas.png"}
2479	21900	{"_key": 21900, "iconFile": "res:/UI/Texture/Icons/Inventory/crateCrimsonHarvest.png"}
2480	21901	{"_key": 21901, "iconFile": "res:/UI/Texture/Icons/Inventory/crateGuardiansGala.png"}
2481	21902	{"_key": 21902, "iconFile": "res:/UI/Texture/Icons/Inventory/crateNewYears.png"}
2482	21903	{"_key": 21903, "iconFile": "res:/UI/Texture/Icons/StatusEffects/weatherLightning.png"}
2483	21904	{"_key": 21904, "iconFile": "res:/UI/Texture/Icons/StatusEffects/weatherXenonGas.png"}
2484	21905	{"_key": 21905, "iconFile": "res:/UI/Texture/Icons/StatusEffects/weatherCaustic.png"}
2485	21906	{"_key": 21906, "iconFile": "res:/UI/Texture/Icons/StatusEffects/weatherDarkness.png"}
2486	21907	{"_key": 21907, "iconFile": "res:/UI/Texture/Icons/StatusEffects/weatherInfernal.png"}
2487	21909	{"_key": 21909, "iconFile": "res:/ui/texture/icons/Modules/abyssalPlate.png"}
2488	21910	{"_key": 21910, "iconFile": "res:/ui/texture/icons/Modules/abyssalStasisWebifier.png"}
2489	21911	{"_key": 21911, "iconFile": "res:/ui/texture/icons/Modules/abyssalWarpScrambler.png"}
2490	21912	{"_key": 21912, "iconFile": "res:/ui/texture/icons/Modules/abyssalWarpDisruptor.png"}
2491	21913	{"_key": 21913, "iconFile": "res:/ui/texture/icons/Modules/abyssalShieldBooster.png"}
2492	21914	{"_key": 21914, "iconFile": "res:/ui/texture/icons/Modules/abyssalShieldExtender.png"}
2493	21916	{"_key": 21916, "iconFile": "res:/ui/texture/icons/ammo/disintegratorChargeGluon.png"}
2494	21917	{"_key": 21917, "iconFile": "res:/ui/texture/icons/ammo/disintegratorChargeLepton.png"}
2495	21918	{"_key": 21918, "iconFile": "res:/ui/texture/icons/ammo/disintegratorChargeQuark.png"}
2496	21919	{"_key": 21919, "iconFile": "res:/ui/texture/icons/ammo/disintegratorChargeMystic.png"}
2497	21920	{"_key": 21920, "iconFile": "res:/ui/texture/icons/ammo/disintegratorChargeOccult.png"}
2498	21921	{"_key": 21921, "iconFile": "res:/ui/texture/icons/Modules/Disintegrator_L.png", "iconType": "png"}
2499	21922	{"_key": 21922, "iconFile": "res:/ui/texture/icons/Modules/Disintegrator_M.png", "iconType": "png"}
2500	21923	{"_key": 21923, "iconFile": "res:/ui/texture/icons/Modules/Disintegrator_S.png", "iconType": "png"}
2501	21924	{"_key": 21924, "iconFile": "res:/UI/Texture/Icons/Inventory/abyssalFilamentL1.png"}
2502	21925	{"_key": 21925, "iconFile": "res:/UI/Texture/Icons/Inventory/abyssalFilamentL2.png"}
2503	21926	{"_key": 21926, "iconFile": "res:/UI/Texture/Icons/Inventory/abyssalFilamentL3.png"}
2504	21927	{"_key": 21927, "iconFile": "res:/UI/Texture/Icons/Inventory/abyssalFilamentL4.png"}
2505	21928	{"_key": 21928, "iconFile": "res:/UI/Texture/Icons/Inventory/abyssalFilamentL5.png"}
2506	21931	{"_key": 21931, "iconFile": "res:/UI/Asset/mannequin/outer/48081_female_Outer_VanguardF01_Types_VanguardF01_TG.png", "iconType": "png"}
2507	21932	{"_key": 21932, "iconFile": "res:/UI/Asset/mannequin/outer/48082_male_outer_VanguardM01_Types_VanguardM01_TG.png", "iconType": "png"}
2508	21933	{"_key": 21933, "iconFile": "res:/UI/Asset/mannequin/bottomouter/48083_male_bottomOuter_PantsEngM01_Types_PantsEngM01_silver.png", "iconType": "png"}
2509	21934	{"_key": 21934, "iconFile": "res:/ui/texture/icons/86_64_2.png"}
2510	21936	{"_key": 21936, "iconFile": "res:/UI/Texture/Icons/StatusEffects/bioluminescence.png"}
2511	21937	{"_key": 21937, "iconFile": "res:/UI/Texture/Icons/StatusEffects/causticCloud.png"}
2512	21938	{"_key": 21938, "iconFile": "res:/UI/Texture/Icons/StatusEffects/filamentCloud.png"}
2513	21939	{"_key": 21939, "iconFile": "res:/UI/Texture/Icons/StatusEffects/pointDefenseBattery.png"}
2514	21941	{"_key": 21941, "iconFile": "res:/UI/Texture/Icons/StatusEffects/pulseBattery.png"}
2515	21980	{"_key": 21980, "iconFile": "res:/UI/Texture/Icons/Inventory/crystallineIsogen10.png"}
2516	21981	{"_key": 21981, "iconFile": "res:/UI/Texture/Icons/Inventory/mutaPlasmidResidue.png"}
2517	21982	{"_key": 21982, "iconFile": "res:/UI/Texture/Icons/Inventory/triglavianSurveyData.png"}
2518	21983	{"_key": 21983, "iconFile": "res:/UI/Texture/Icons/Inventory/zeroPointCondensate.png"}
2519	21984	{"_key": 21984, "iconFile": "res:/ui/texture/icons/modules/mutaDecayedAfterburner.png"}
2520	21985	{"_key": 21985, "iconFile": "res:/ui/texture/icons/Modules/mutaDecayedExtender.png"}
2521	21986	{"_key": 21986, "iconFile": "res:/ui/texture/icons/Modules/mutaDecayedMWD.png"}
2522	21987	{"_key": 21987, "iconFile": "res:/ui/texture/icons/Modules/mutaDecayedNeut.png"}
2523	21988	{"_key": 21988, "iconFile": "res:/ui/texture/icons/Modules/mutaDecayedNosferatu.png"}
2524	21989	{"_key": 21989, "iconFile": "res:/ui/texture/icons/Modules/mutaDecayedPlate.png"}
2525	21990	{"_key": 21990, "iconFile": "res:/ui/texture/icons/Modules/mutaDecayedRepairer.png"}
2526	21991	{"_key": 21991, "iconFile": "res:/ui/texture/icons/Modules/mutaDecayedShieldBooster.png"}
2527	21992	{"_key": 21992, "iconFile": "res:/ui/texture/icons/Modules/mutaDecayedStasisWebifier.png"}
2528	21993	{"_key": 21993, "iconFile": "res:/ui/texture/icons/Modules/mutaDecayedWarpDisruptor.png"}
2529	21994	{"_key": 21994, "iconFile": "res:/ui/texture/icons/Modules/mutaDecayedWarpScrambler.png"}
2530	21995	{"_key": 21995, "iconFile": "res:/ui/texture/icons/modules/mutaGravidAfterburner.png"}
2531	21996	{"_key": 21996, "iconFile": "res:/ui/texture/icons/modules/mutaGravidExtender.png"}
2532	21997	{"_key": 21997, "iconFile": "res:/ui/texture/icons/modules/mutaGravidMWD.png"}
2533	21998	{"_key": 21998, "iconFile": "res:/ui/texture/icons/modules/mutaGravidNeut.png"}
2534	21999	{"_key": 21999, "iconFile": "res:/ui/texture/icons/modules/mutaGravidNosferatu.png"}
2535	22000	{"_key": 22000, "iconFile": "res:/ui/texture/icons/modules/mutaGravidPlate.png"}
2536	22001	{"_key": 22001, "iconFile": "res:/ui/texture/icons/modules/mutaGravidRepairer.png"}
2537	22002	{"_key": 22002, "iconFile": "res:/ui/texture/icons/modules/mutaGravidShieldBooster.png"}
2538	22003	{"_key": 22003, "iconFile": "res:/ui/texture/icons/modules/mutaGravidStasisWebifier.png"}
2539	22004	{"_key": 22004, "iconFile": "res:/ui/texture/icons/modules/mutaGravidWarpDisruptor.png"}
2540	22005	{"_key": 22005, "iconFile": "res:/ui/texture/icons/modules/mutaGravidWarpScrambler.png"}
2541	22006	{"_key": 22006, "iconFile": "res:/ui/texture/icons/modules/mutaUnstableAfterburner.png"}
2542	22007	{"_key": 22007, "iconFile": "res:/ui/texture/icons/modules/mutaUnstableExtender.png"}
2543	22008	{"_key": 22008, "iconFile": "res:/ui/texture/icons/modules/mutaUnstableMWD.png"}
2544	22009	{"_key": 22009, "iconFile": "res:/ui/texture/icons/modules/mutaUnstableNeut.png"}
2545	22010	{"_key": 22010, "iconFile": "res:/ui/texture/icons/modules/mutaUnstableNosferatu.png"}
2546	22011	{"_key": 22011, "iconFile": "res:/ui/texture/icons/modules/mutaUnstablePlate.png"}
2547	22012	{"_key": 22012, "iconFile": "res:/ui/texture/icons/modules/mutaUnstableRepairer.png"}
2548	22013	{"_key": 22013, "iconFile": "res:/ui/texture/icons/modules/mutaUnstableShieldBooster.png"}
2549	22014	{"_key": 22014, "iconFile": "res:/ui/texture/icons/modules/mutaUnstableStasisWebifier.png"}
2550	22016	{"_key": 22016, "iconFile": "res:/ui/texture/icons/modules/mutaUnstableWarpDisruptor.png"}
2551	22018	{"_key": 22018, "iconFile": "res:/ui/texture/icons/modules/mutaUnstableWarpScrambler.png"}
2552	22020	{"_key": 22020, "iconFile": "res:/UI/Texture/Icons/StatusEffects/boundary.png"}
2553	22021	{"_key": 22021, "iconFile": "res:/UI/Asset/mannequin/outer/48386_female_Outer_VanguardF01_Types_VanguardF01_RED.png", "iconType": "png"}
2554	22022	{"_key": 22022, "iconFile": "res:/UI/Asset/mannequin/outer/48380_female_Outer_VanguardF01_Types_VanguardF01_GREEN.png", "iconType": "png"}
2555	22023	{"_key": 22023, "iconFile": "res:/UI/Asset/mannequin/outer/48381_female_Outer_VanguardF01_Types_VanguardF01_GOLD.png", "iconType": "png"}
2556	22024	{"_key": 22024, "iconFile": "res:/UI/Asset/mannequin/outer/48382_female_Outer_VanguardF01_Types_VanguardF01_BLUE.png", "iconType": "png"}
2557	22025	{"_key": 22025, "iconFile": "res:/UI/Asset/mannequin/outer/48383_male_outer_VanguardM01_Types_VanguardM01_GREEN.png", "iconType": "png"}
2558	22026	{"_key": 22026, "iconFile": "res:/UI/Asset/mannequin/outer/48384_male_outer_VanguardM01_Types_VanguardM01_GOLD.png", "iconType": "png"}
2559	22027	{"_key": 22027, "iconFile": "res:/UI/Asset/mannequin/outer/48385_male_outer_VanguardM01_Types_VanguardM01_BLUE.png", "iconType": "png"}
2560	22028	{"_key": 22028, "iconFile": "res:/UI/Asset/mannequin/outer/48387_male_outer_VanguardM01_Types_VanguardM01_RED.png", "iconType": "png"}
2561	22029	{"_key": 22029, "iconFile": "res:/ui/texture/icons/Modules/mutaDecayedCapBattery.png"}
2562	22030	{"_key": 22030, "iconFile": "res:/ui/texture/icons/Modules/mutaGravidCapBattery.png"}
2563	22031	{"_key": 22031, "iconFile": "res:/ui/texture/icons/Modules/mutaUnstableCapBattery.png"}
2564	22034	{"_key": 22034, "iconFile": "res:/ui/texture/icons/25_64_13.png"}
2565	22036	{"_key": 22036, "iconFile": "res:/ui/texture/icons/medicinal_herbs.png"}
2566	22037	{"_key": 22037, "iconFile": "res:/ui/texture/icons/soda_pop_brown.png"}
2567	22038	{"_key": 22038, "iconFile": "res:/ui/texture/icons/soda_pop_green.png"}
2568	22039	{"_key": 22039, "iconFile": "res:/ui/texture/icons/soft_drink_bottles.png"}
2569	22040	{"_key": 22040, "iconFile": "res:/ui/texture/icons/tea_service.png"}
2570	22041	{"_key": 22041, "iconFile": "res:/ui/texture/icons/4_64_4.png"}
2571	22042	{"_key": 22042, "iconFile": "res:/ui/texture/icons/1337_64_15.png"}
2572	22043	{"_key": 22043, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49668_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V0.png", "iconType": "png"}
2573	22044	{"_key": 22044, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49669_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V1.png", "iconType": "png"}
2574	22045	{"_key": 22045, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49670_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V2.png", "iconType": "png"}
2575	22046	{"_key": 22046, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49671_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V3.png", "iconType": "png"}
2576	22047	{"_key": 22047, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49672_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V4.png", "iconType": "png"}
2577	22048	{"_key": 22048, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49673_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V5.png", "iconType": "png"}
2578	22049	{"_key": 22049, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49674_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V6.png", "iconType": "png"}
2579	22050	{"_key": 22050, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49675_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V7.png", "iconType": "png"}
2580	22051	{"_key": 22051, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49676_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V8.png", "iconType": "png"}
2581	22052	{"_key": 22052, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49677_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V0.png", "iconType": "png"}
2582	22053	{"_key": 22053, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49678_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V1.png", "iconType": "png"}
2583	22054	{"_key": 22054, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49679_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V2.png", "iconType": "png"}
2584	22055	{"_key": 22055, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49680_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V3.png", "iconType": "png"}
2585	22056	{"_key": 22056, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49681_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V4.png", "iconType": "png"}
2586	22057	{"_key": 22057, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49682_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V5.png", "iconType": "png"}
2587	22058	{"_key": 22058, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49683_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V6.png", "iconType": "png"}
2588	22059	{"_key": 22059, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49684_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V7.png", "iconType": "png"}
2589	22060	{"_key": 22060, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49685_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V8.png", "iconType": "png"}
2590	22061	{"_key": 22061, "iconFile": "res:/UI/Texture/Icons/Inventory/FacialAugmentOrange.png", "iconType": "png"}
2591	22062	{"_key": 22062, "iconFile": "res:/UI/Texture/Icons/Inventory/FacialAugmentBlue.png", "iconType": "png"}
2592	22063	{"_key": 22063, "iconFile": "res:/UI/Texture/Icons/Inventory/FacialAugmentsPackBlue.png", "iconType": "png"}
2593	22064	{"_key": 22064, "iconFile": "res:/UI/Texture/Icons/Modules/mutaDecayedGyro.png", "iconType": "png"}
2594	22065	{"_key": 22065, "iconFile": "res:/UI/Texture/Icons/Modules/mutaGravidGyro.png", "iconType": "png"}
2595	22066	{"_key": 22066, "iconFile": "res:/UI/Texture/Icons/Modules/mutaUnstableGyro.png", "iconType": "png"}
2596	22067	{"_key": 22067, "iconFile": "res:/UI/Texture/Icons/Modules/mutaUnstableBallisticControl.png", "iconType": "png"}
2597	22068	{"_key": 22068, "iconFile": "res:/UI/Texture/Icons/Modules/mutaGravidBallisticControl.png", "iconType": "png"}
2598	22069	{"_key": 22069, "iconFile": "res:/UI/Texture/Icons/Modules/mutaDecayedBallisticControl.png", "iconType": "png"}
2599	22070	{"_key": 22070, "iconFile": "res:/UI/Texture/Icons/Modules/mutaDecayedDroneDamage.png", "iconType": "png"}
2600	22071	{"_key": 22071, "iconFile": "res:/UI/Texture/Icons/Modules/mutaGravidDroneDamage.png", "iconType": "png"}
2601	22072	{"_key": 22072, "iconFile": "res:/UI/Texture/Icons/Modules/mutaUnstableDroneDamage.png", "iconType": "png"}
2602	22073	{"_key": 22073, "iconFile": "res:/UI/Texture/Icons/Modules/navigation_CynoBeacon.png", "iconType": "png"}
2603	22074	{"_key": 22074, "iconFile": "res:/UI/Texture/Icons/Modules/navigation_CynoJammer.png", "iconType": "png"}
2604	22075	{"_key": 22075, "iconFile": "res:/UI/Texture/Icons/Modules/navigation_JumpGate.png", "iconType": "png"}
2605	22076	{"_key": 22076, "iconFile": "res:/ui/texture/icons/76_64_3.png"}
2606	22077	{"_key": 22077, "iconFile": "res:/UI/Asset/mannequin/outer/49978_Male_outer_ExplorationSuit_M01_Types_ExplorationSuit_M01_W.png", "iconType": "png"}
2607	22078	{"_key": 22078, "iconFile": "res:/UI/Asset/mannequin/outer/49980_Female_Outer_ExplorationSuit_F01_Types_ExplorationSuit_F01_W.png", "iconType": "png"}
2608	22079	{"_key": 22079, "iconFile": "res:/UI/Texture/Icons/RewardTrack/reward_Holiday2018_Augmentation1.png", "iconType": "png"}
2609	22080	{"_key": 22080, "iconFile": "res:/UI/Texture/Icons/RewardTrack/reward_Holiday2018_Augmentation2.png", "iconType": "png"}
2610	22081	{"_key": 22081, "iconFile": "res:/UI/Texture/classes/ItemPacks/SplashImages/Holiday2018/splash_Holiday2018_DrakeRupture.png", "iconType": "png"}
2611	22082	{"_key": 22082, "iconFile": "res:/UI/Texture/classes/ItemPacks/SplashImages/Holiday2018/splash_Holiday2018_ExplorationSuits.png", "iconType": "png"}
2612	22084	{"_key": 22084, "iconFile": "res:/UI/Texture/classes/ItemPacks/SplashImages/Holiday2018/splash_Holiday2018_FaceAugmentation1.png", "iconType": "png"}
2613	22085	{"_key": 22085, "iconFile": "res:/UI/Texture/classes/ItemPacks/SplashImages/Holiday2018/splash_Holiday2018_FaceAugmentation2.png", "iconType": "png"}
2614	22086	{"_key": 22086, "iconFile": "res:/UI/Texture/classes/ItemPacks/SplashImages/Holiday2018/splash_Holiday2018_GnosisPunisher.png", "iconType": "png"}
2615	22087	{"_key": 22087, "iconFile": "res:/UI/Asset/mannequin/outer/49978_Male_outer_ExplorationSuit_M01_Types_ExplorationSuit_M01_W.png", "iconType": "png"}
2616	22088	{"_key": 22088, "iconFile": "res:/UI/Asset/mannequin/outer/49980_Female_Outer_ExplorationSuit_F01_Types_ExplorationSuit_F01_W.png", "iconType": "png"}
2617	22089	{"_key": 22089, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49984_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V0_Blue.png", "iconType": "png"}
2618	22090	{"_key": 22090, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49985_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V10_W.png", "iconType": "png"}
2619	22091	{"_key": 22091, "iconFile": "res:/ui/texture/icons/modules/abyssalRemoteRepairer.png", "iconType": "png"}
2620	22092	{"_key": 22092, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49987_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V6_Blue.png", "iconType": "png"}
2621	22093	{"_key": 22093, "iconFile": "res:/UI/Texture/Icons/RewardTrack/crateSkinContainer.png", "iconType": "png"}
2622	22094	{"_key": 22094, "iconFile": "res:/UI/Texture/Icons/RewardTrack/crateWinterExplorationSuit.png", "iconType": "png"}
2623	22095	{"_key": 22095, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/49986_male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V10_W.png", "iconType": "png"}
2624	22096	{"_key": 22096, "iconFile": "res:/UI/Texture/LoginCampaigns/Winter_2018.png", "iconType": "png"}
2625	22097	{"_key": 22097, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/50043_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V30_ChOper.png", "iconType": "png"}
2626	22098	{"_key": 22098, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/50044_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V5_Purple.png", "iconType": "png"}
2627	22099	{"_key": 22099, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/50049_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V5_Purple.png", "iconType": "png"}
2628	22100	{"_key": 22100, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/50051_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V5_Purple.png", "iconType": "png"}
2629	22101	{"_key": 22101, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/50052_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V5_Purple.png", "iconType": "png"}
2630	22102	{"_key": 22102, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/50050_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V30_ChOper.png", "iconType": "png"}
2631	22103	{"_key": 22103, "iconFile": "res:/UI/Texture/classes/ItemPacks/SplashImages/Holiday2018/splash_GuardiansGala_FaceAugmentation1.png", "iconType": "png"}
2632	22104	{"_key": 22104, "iconFile": "res:/UI/Texture/Icons/Inventory/FacialAugmentPurple.png", "iconType": "png"}
2633	22105	{"_key": 22105, "iconFile": "res:/UI/Asset/mannequin/topmiddle/50130_Female_TopMiddle_TshirtF01_Types_TshirtF01_PWT.png", "iconType": "png"}
2634	22106	{"_key": 22106, "iconFile": "res:/UI/Asset/mannequin/topmiddle/50131_Male_topMiddle_TshirtM01_Types_TshirtM01_PWT.png", "iconType": "png"}
2635	22107	{"_key": 22107, "iconFile": "res:/UI/Asset/mannequin/hair/50132_Female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_PWT.png", "iconType": "png"}
2636	22108	{"_key": 22108, "iconFile": "res:/UI/Asset/mannequin/hair/50133_Male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_PWT.png", "iconType": "png"}
2637	22111	{"_key": 22111, "iconFile": "res:/ui/texture/icons/inventory/triglavianCommunicator_Perun.png", "iconType": "png"}
2638	22112	{"_key": 22112, "iconFile": "res:/ui/texture/icons/inventory/triglavianCommunicator_Svarog.png", "iconType": "png"}
2639	22114	{"_key": 22114, "iconFile": "res:/ui/texture/icons/inventory/triglavianCommunicator_Veles.png", "iconType": "png"}
2640	22115	{"_key": 22115, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/52188_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V31_XVI_FF.png", "iconType": "png"}
2641	22116	{"_key": 22116, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/52189_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V32_XVI_FF.png", "iconType": "png"}
2642	22117	{"_key": 22117, "iconFile": "res:/UI/Asset/mannequin/topmiddle/52198_Female_TopMiddle_TshirtF01_Types_TshirtF01_XVI.png", "iconType": "png"}
2643	22119	{"_key": 22119, "iconFile": "res:/UI/Asset/mannequin/topmiddle/52200_Male_topMiddle_TshirtM01_Types_TshirtM01_XVI.png", "iconType": "png"}
2644	22120	{"_key": 22120, "iconFile": "res:/UI/Asset/mannequin/hair/52201_Female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_XVI.png", "iconType": "png"}
2645	22121	{"_key": 22121, "iconFile": "res:/UI/Asset/mannequin/hair/52202_Male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_XVI.png", "iconType": "png"}
2646	24116	{"_key": 24116, "iconFile": "res:/UI/Texture/Icons/Inventory/cratePermabandCap.png", "iconType": "png"}
2647	24117	{"_key": 24117, "iconFile": "res:/UI/Texture/Icons/Inventory/cratePermabandShirt.png", "iconType": "png"}
2648	24118	{"_key": 24118, "iconFile": "res:/UI/Texture/Icons/Inventory/crateSilverMonocle.png", "iconType": "png"}
2649	24119	{"_key": 24119, "iconFile": "res:/UI/Texture/Icons/Inventory/crateXVICap.png", "iconType": "png"}
2650	24120	{"_key": 24120, "iconFile": "res:/UI/Texture/Icons/Inventory/crateXVIShirt.png", "iconType": "png"}
2651	24121	{"_key": 24121, "iconFile": "res:/UI/Texture/Icons/Inventory/FacialAugmentXVI.png", "iconType": "png"}
2652	24122	{"_key": 24122, "iconFile": "res:/UI/Texture/Icons/Inventory/crateApotheosis+SKIN.png", "iconType": "png"}
2653	24123	{"_key": 24123, "iconFile": "res:/UI/Texture/Icons/Inventory/crateGnosis+SKIN.png", "iconType": "png"}
2654	24124	{"_key": 24124, "iconFile": "res:/UI/Texture/Icons/Inventory/cratePraxis+SKIN.png", "iconType": "png"}
2655	24125	{"_key": 24125, "iconFile": "res:/UI/Texture/Icons/Inventory/crateSunesis+SKIN.png", "iconType": "png"}
2656	24128	{"_key": 24128, "iconFile": "res:/UI/Texture/Icons/Modules/mutaDecayedAssaultDamageControl.png"}
2657	24129	{"_key": 24129, "iconFile": "res:/UI/Texture/Icons/Modules/mutaDecayedDamageControl.png"}
2658	24130	{"_key": 24130, "iconFile": "res:/UI/Texture/Icons/Modules/mutaGravidAssaultDamageControl.png"}
2659	24131	{"_key": 24131, "iconFile": "res:/UI/Texture/Icons/Modules/mutaGravidDamageControl.png"}
2660	24132	{"_key": 24132, "iconFile": "res:/UI/Texture/Icons/Modules/mutaUnstableAssaultDamageControl.png"}
2661	24133	{"_key": 24133, "iconFile": "res:/UI/Texture/Icons/Modules/mutaUnstableDamageControl.png"}
2662	24135	{"_key": 24135, "iconFile": "res:/ui/texture/icons/triglavianCollective.png"}
2663	24136	{"_key": 24136, "iconFile": "res:/UI/Texture/Icons/Inventory/Asteroid_Talassonite.png", "iconType": "png"}
2664	24137	{"_key": 24137, "iconFile": "res:/UI/Texture/Icons/Inventory/IndustryDatacore.png", "iconType": "png"}
2665	24138	{"_key": 24138, "iconFile": "res:/UI/Texture/Icons/Inventory/Radiation_absorption_thruster.png", "iconType": "png"}
2666	24139	{"_key": 24139, "iconFile": "res:/UI/Texture/Icons/Inventory/Lattice_locked_dekaisogen.png", "iconType": "png"}
2667	24140	{"_key": 24140, "iconFile": "res:/UI/Texture/Icons/Inventory/Singularity_radiation_convertor.png", "iconType": "png"}
2668	24141	{"_key": 24141, "iconFile": "res:/UI/Texture/Icons/Inventory/Trinary_state_processor.png", "iconType": "png"}
2669	24142	{"_key": 24142, "iconFile": "res:/UI/Texture/Icons/Inventory/Zero_point_field_manipulator.png", "iconType": "png"}
2670	24143	{"_key": 24143, "iconFile": "res:/UI/Texture/Icons/Inventory/Asteroid_Bezdnacine.png", "iconType": "png"}
2671	24144	{"_key": 24144, "iconFile": "res:/UI/Texture/Icons/Inventory/Asteroid_Rakovene.png", "iconType": "png"}
2672	24146	{"_key": 24146, "iconFile": "res:/UI/Texture/Icons/73_16_246.png"}
2673	24147	{"_key": 24147, "iconFile": "res:/UI/Texture/Icons/73_16_245.png"}
2674	24148	{"_key": 24148, "iconFile": "res:/UI/Texture/Icons/73_16_247.png"}
2675	24149	{"_key": 24149, "iconFile": "res:/UI/Texture/Icons/73_16_248.png"}
2676	24150	{"_key": 24150, "iconFile": "res:/UI/Texture/Icons/73_16_242.png"}
2677	24151	{"_key": 24151, "iconFile": "res:/UI/Texture/Icons/73_16_243.png"}
2678	24152	{"_key": 24152, "iconFile": "res:/UI/Texture/Icons/ItemOverlay/abyssal.png"}
2679	24153	{"_key": 24153, "iconFile": "res:/UI/Texture/Icons/ItemOverlay/nes.png"}
2680	24154	{"_key": 24154, "iconFile": "res:/UI/Texture/Icons/ItemOverlay/timeLimited.png"}
2681	24155	{"_key": 24155, "iconFile": "res:/UI/Texture/Shared/structureOverlayFaction.png"}
2682	24156	{"_key": 24156, "iconFile": "res:/UI/Texture/Shared/structureOverlayT2.png"}
2683	24157	{"_key": 24157, "iconFile": "res:/UI/Texture/Shared/structureOverlay.png"}
2684	24158	{"_key": 24158, "iconFile": "res:/UI/Texture/Icons/SkillPoints/25k.png", "iconType": "png"}
2685	24159	{"_key": 24159, "iconFile": "res:/UI/Texture/Icons/SkillPoints/50k.png", "iconType": "png"}
2686	24160	{"_key": 24160, "iconFile": "res:/UI/Texture/Icons/SkillPoints/100k.png", "iconType": "png"}
2687	24161	{"_key": 24161, "iconFile": "res:/UI/Texture/Icons/SkillPoints/150k.png", "iconType": "png"}
2688	24162	{"_key": 24162, "iconFile": "res:/UI/Texture/Icons/SkillPoints/250k.png", "iconType": "png"}
2689	24163	{"_key": 24163, "iconFile": "res:/UI/Texture/Icons/SkillPoints/500k.png", "iconType": "png"}
2690	24164	{"_key": 24164, "iconFile": "res:/UI/Texture/Icons/SkillPoints/10k.png", "iconType": "png"}
2691	24165	{"_key": 24165, "iconFile": "res:/UI/Texture/Icons/SkillPoints/750k.png", "iconType": "png"}
2692	24166	{"_key": 24166, "iconFile": "res:/UI/Texture/Icons/SkillPoints/1m.png", "iconType": "png"}
2693	24167	{"_key": 24167, "iconFile": "res:/UI/Asset/mannequin/makeup_bodyaugmentations/53038_Male_Makeup_BodyAugmentations_BodyAugmentation_M01_Types_BodyAugmentationM01_Black.png", "iconType": "png"}
2694	24168	{"_key": 24168, "iconFile": "res:/UI/Asset/mannequin/makeup_bodyaugmentations/53039_Male_Makeup_BodyAugmentations_BodyAugmentation_M01_Types_BodyAugmentationM01_Blue.png", "iconType": "png"}
2695	24169	{"_key": 24169, "iconFile": "res:/UI/Asset/mannequin/makeup_bodyaugmentations/53040_Male_Makeup_BodyAugmentations_BodyAugmentation_M01_Types_BodyAugmentationM01_GoldDesign.png", "iconType": "png"}
2696	24170	{"_key": 24170, "iconFile": "res:/UI/Asset/mannequin/makeup_bodyaugmentations/53041_Male_Makeup_BodyAugmentations_BodyAugmentation_M01_Types_BodyAugmentationM01_Red.png", "iconType": "png"}
2697	24171	{"_key": 24171, "iconFile": "res:/UI/Asset/mannequin/makeup_bodyaugmentations/53042_Male_Makeup_BodyAugmentations_BodyAugmentation_M01_Types_BodyAugmentationM01_WhiteDesign.png", "iconType": "png"}
2698	24172	{"_key": 24172, "iconFile": "res:/UI/Asset/mannequin/makeup_bodyaugmentations/53043_Male_Makeup_BodyAugmentations_BodyAugmentation_M01_Types_BodyAugmentationM01_YellowDesign.png", "iconType": "png"}
2699	24175	{"_key": 24175, "iconFile": "res:/UI/Texture/Icons/Inventory/halloweenCrate.png", "iconType": "png"}
2700	24192	{"_key": 24192, "iconFile": "res:/UI/Asset/mannequin/makeup_bodyaugmentations/53226_Female_Makeup_BodyAugmentations_BodyAugmentation_F01_Types_BodyAugmentationF01_Black.png", "iconType": "png"}
2701	24193	{"_key": 24193, "iconFile": "res:/UI/Asset/mannequin/makeup_bodyaugmentations/53227_Female_Makeup_BodyAugmentations_BodyAugmentation_F01_Types_BodyAugmentationF01_Blue.png", "iconType": "png"}
2702	24194	{"_key": 24194, "iconFile": "res:/UI/Asset/mannequin/makeup_bodyaugmentations/53228_Female_Makeup_BodyAugmentations_BodyAugmentation_F01_Types_BodyAugmentationF01_GoldCamo.png", "iconType": "png"}
2703	24195	{"_key": 24195, "iconFile": "res:/UI/Asset/mannequin/makeup_bodyaugmentations/53229_Female_Makeup_BodyAugmentations_BodyAugmentation_F01_Types_BodyAugmentationF01_Red.png", "iconType": "png"}
2704	24196	{"_key": 24196, "iconFile": "res:/UI/Asset/mannequin/makeup_bodyaugmentations/53230_Female_Makeup_BodyAugmentations_BodyAugmentation_F01_Types_BodyAugmentationF01_WhiteCamo.png", "iconType": "png"}
2705	24197	{"_key": 24197, "iconFile": "res:/UI/Asset/mannequin/makeup_bodyaugmentations/53231_Female_Makeup_BodyAugmentations_BodyAugmentation_F01_Types_BodyAugmentationF01_YellowCamo.png", "iconType": "png"}
2706	24205	{"_key": 24205, "iconFile": "res:/ui/texture/icons/inventory/hypercore.png", "iconType": "png"}
2707	24228	{"_key": 24228, "iconFile": "res:/UI/Texture/Icons/Inventory/capitalLauncherHardpoint.png", "iconType": "png"}
2708	24229	{"_key": 24229, "iconFile": "res:/UI/Texture/Icons/Inventory/capitalPowerGenerator_64.png", "iconType": "png"}
2709	24230	{"_key": 24230, "iconFile": "res:/UI/Texture/Icons/Inventory/capitalPropulsionEngine_64.png", "iconType": "png"}
2710	24237	{"_key": 24237, "iconFile": "res:/ui/texture/icons/Modules/Disintegrator_XL.png"}
2711	24240	{"_key": 24240, "iconFile": "res:/ui/texture/shared/brackets/station_32.png", "iconType": "png"}
2712	24242	{"_key": 24242, "iconFile": "res:/ui/texture/windowicons/theagency.png", "iconType": "png"}
2713	24243	{"_key": 24243, "iconFile": "res:/ui/texture/icons/44_32_18.png", "iconType": "png"}
2714	24244	{"_key": 24244, "iconFile": "res:/ui/texture/shared/brackets/warpgate_32.png", "iconType": "png"}
2715	24246	{"_key": 24246, "iconFile": "res:/ui/texture/shared/brackets/npccruiser_32.png", "iconType": "png"}
2716	24247	{"_key": 24247, "iconFile": "res:/ui/texture/shared/brackets/stargate_32.png", "iconType": "png"}
2717	24248	{"_key": 24248, "iconFile": "res:/ui/texture/classes/achievements/mouseBtnLeft.png", "iconType": "png"}
2718	24250	{"_key": 24250, "iconFile": "res:/ui/texture/icons/44_32_12.png", "iconType": "png"}
2719	24251	{"_key": 24251, "iconFile": "res:/UI/Texture/Icons/9_64_6.png", "iconType": "png"}
2720	24252	{"_key": 24252, "iconFile": "res:/ui/texture/icons/13_64_13.png", "iconType": "png"}
2721	24253	{"_key": 24253, "iconFile": "res:/ui/texture/icons/1_64_11.png", "iconType": "png"}
2722	24254	{"_key": 24254, "iconFile": "res:/UI/Texture/Shared/Brackets/Wreck_Large.png", "iconType": "png"}
2723	24256	{"_key": 24256, "iconFile": "res:/UI/Asset/mannequin/outer/53357_Female_Outer_ExplorationSuit_F01_Types_ExplorationSuit_F01_Aurora.png", "iconType": "png"}
2724	24257	{"_key": 24257, "iconFile": "res:/UI/Asset/mannequin/topmiddle/53380_Female_TopMiddle_TshirtF01_Types_TshirtF01_Aurora.png", "iconType": "png"}
2725	24258	{"_key": 24258, "iconFile": "res:/UI/Asset/mannequin/hair/53381_Female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_Aurora.png", "iconType": "png"}
2726	24259	{"_key": 24259, "iconFile": "res:/UI/Asset/mannequin/outer/53382_Male_outer_ExplorationSuit_M01_Types_ExplorationSuit_M01_ Aurora.png", "iconType": "png"}
2727	24260	{"_key": 24260, "iconFile": "res:/UI/Asset/mannequin/topmiddle/53383_Male_topMiddle_TshirtM01_Types_TshirtM01_ Aurora.png", "iconType": "png"}
2728	24261	{"_key": 24261, "iconFile": "res:/UI/Asset/mannequin/hair/53384_Male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_ Aurora.png", "iconType": "png"}
2729	24262	{"_key": 24262, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/53385_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V10_Red.png", "iconType": "png"}
2730	24263	{"_key": 24263, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/53386_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V32_Aurora.png", "iconType": "png"}
2731	24264	{"_key": 24264, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/53393_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V33_ Aurora.png", "iconType": "png"}
2732	24265	{"_key": 24265, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/53394_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V10_Red.png", "iconType": "png"}
2733	24266	{"_key": 24266, "iconFile": "res:/UI/Texture/Icons/Inventory/FilamentAllOtherReindeer.png"}
2734	24267	{"_key": 24267, "iconFile": "res:/UI/Texture/Icons/Inventory/FilamentRudolph.png"}
2735	24268	{"_key": 24268, "iconFile": "res:/UI/Texture/Icons/Inventory/Alpha1.png", "iconType": "png"}
2736	24270	{"_key": 24270, "iconFile": "res:/UI/Texture/Icons/Inventory/Alpha2.png", "iconType": "png"}
2737	24271	{"_key": 24271, "iconFile": "res:/UI/Texture/Icons/Inventory/Alpha3.png", "iconType": "png"}
2738	24272	{"_key": 24272, "iconFile": "res:/UI/Texture/Icons/Inventory/Alpha4.png", "iconType": "png"}
2739	24273	{"_key": 24273, "iconFile": "res:/UI/Texture/Icons/Inventory/Alpha5.png", "iconType": "png"}
2740	24274	{"_key": 24274, "iconFile": "res:/UI/Texture/Icons/Inventory/Alpha6.png", "iconType": "png"}
2741	24275	{"_key": 24275, "iconFile": "res:/UI/Texture/Icons/Inventory/Alpha7.png", "iconType": "png"}
2742	24276	{"_key": 24276, "iconFile": "res:/UI/Texture/Icons/Inventory/Alpha8.png", "iconType": "png"}
2743	24277	{"_key": 24277, "iconFile": "res:/UI/Texture/Icons/Inventory/Alpha9.png", "iconType": "png"}
2744	24278	{"_key": 24278, "iconFile": "res:/UI/Texture/Icons/Inventory/Alpha10.png", "iconType": "png"}
2745	24279	{"_key": 24279, "iconFile": "res:/UI/Texture/Icons/Inventory/Alpha11.png", "iconType": "png"}
2746	24280	{"_key": 24280, "iconFile": "res:/UI/Texture/Icons/Inventory/Alpha12.png", "iconType": "png"}
2747	24281	{"_key": 24281, "iconFile": "res:/UI/Texture/Icons/Inventory/Alpha13.png", "iconType": "png"}
2748	24283	{"_key": 24283, "iconFile": "res:/UI/Texture/Icons/Inventory/Omega1.png", "iconType": "png"}
2749	24284	{"_key": 24284, "iconFile": "res:/UI/Texture/Icons/Inventory/Omega2.png", "iconType": "png"}
2750	24285	{"_key": 24285, "iconFile": "res:/UI/Texture/Icons/Inventory/Omega3.png", "iconType": "png"}
2751	24286	{"_key": 24286, "iconFile": "res:/UI/Texture/Icons/Inventory/Omega4.png", "iconType": "png"}
2752	24287	{"_key": 24287, "iconFile": "res:/UI/Texture/Icons/Inventory/Omega5.png", "iconType": "png"}
2753	24288	{"_key": 24288, "iconFile": "res:/UI/Texture/Icons/Inventory/Omega6.png", "iconType": "png"}
2754	24289	{"_key": 24289, "iconFile": "res:/UI/Texture/Icons/Inventory/Omega7.png", "iconType": "png"}
2755	24290	{"_key": 24290, "iconFile": "res:/UI/Texture/Icons/Inventory/Omega8.png", "iconType": "png"}
2756	24291	{"_key": 24291, "iconFile": "res:/UI/Texture/Icons/Inventory/Omega9.png", "iconType": "png"}
2757	24292	{"_key": 24292, "iconFile": "res:/UI/Texture/Icons/Inventory/Omega10.png", "iconType": "png"}
2758	24293	{"_key": 24293, "iconFile": "res:/UI/Texture/Icons/Inventory/Omega11.png", "iconType": "png"}
2759	24294	{"_key": 24294, "iconFile": "res:/UI/Texture/Icons/Inventory/Omega12.png", "iconType": "png"}
2760	24295	{"_key": 24295, "iconFile": "res:/UI/Texture/Icons/Inventory/Omega13.png", "iconType": "png"}
2761	24296	{"_key": 24296, "iconFile": "res:/ui/texture/icons/celestial/planetaryLaunchContainer.png"}
2762	24297	{"_key": 24297, "iconFile": "res:/ui/texture/icons/inventory/CoercerBundleCrate.png"}
2763	24298	{"_key": 24298, "iconFile": "res:/ui/texture/icons/inventory/CatalystBundleCrate.png"}
2764	24299	{"_key": 24299, "iconFile": "res:/ui/texture/icons/inventory/CormorantBundleCrate.png"}
2765	24300	{"_key": 24300, "iconFile": "res:/ui/texture/icons/inventory/ThrasherBundleCrate.png"}
2766	24303	{"_key": 24303, "iconFile": "res:/ui/texture/icons/StatusEffects/blackHole.png"}
2767	24304	{"_key": 24304, "iconFile": "res:/ui/texture/icons/StatusEffects/cataclysmicVariable.png"}
2768	24305	{"_key": 24305, "iconFile": "res:/ui/texture/icons/StatusEffects/magnatar.png"}
2769	24306	{"_key": 24306, "iconFile": "res:/ui/texture/icons/StatusEffects/pulsae.png"}
2770	24307	{"_key": 24307, "iconFile": "res:/ui/texture/icons/StatusEffects/redGiant.png"}
2771	24308	{"_key": 24308, "iconFile": "res:/ui/texture/icons/StatusEffects/wolfRayet.png"}
2772	24309	{"_key": 24309, "iconFile": "res:/ui/texture/icons/StatusEffects/triglavianInvasions.png"}
2773	24310	{"_key": 24310, "iconFile": "res:/ui/texture/icons/StatusEffects/sanshaIncursion.png"}
2774	24312	{"_key": 24312, "iconFile": "res:/UI/Asset/mannequin/outer/54158_Female_Outer_LabCoatF01_Types_LabCoatF01_ConcordFF.png", "iconType": "png"}
2775	24319	{"_key": 24319, "iconFile": "res:/UI/Asset/mannequin/outer/54177_Male_outer_LabCoatM01_Types_LabCoatM01_ConcordFF.png", "iconType": "png"}
2776	24320	{"_key": 24320, "iconFile": "res:/UI/Asset/mannequin/topmiddle/54193_Female_TopMiddle_TshirtF01_Types_TshirtF01_RFS.png", "iconType": "png"}
2777	24321	{"_key": 24321, "iconFile": "res:/UI/Asset/mannequin/topmiddle/54194_Male_topMiddle_TshirtM01_Types_TshirtM01_RFS.png", "iconType": "png"}
2778	24322	{"_key": 24322, "iconFile": "res:/UI/Texture/Icons/Inventory/AbyssalRandomFilament_L1.png"}
2779	24323	{"_key": 24323, "iconFile": "res:/UI/Texture/Icons/Inventory/AbyssalRandomFilament_L1Active.png"}
2780	24324	{"_key": 24324, "iconFile": "res:/UI/Texture/Icons/Inventory/AbyssalRandomFilament_L3.png"}
2781	24325	{"_key": 24325, "iconFile": "res:/UI/Texture/Icons/Inventory/AbyssalRandomFilament_L3Active.png"}
2782	24326	{"_key": 24326, "iconFile": "res:/UI/Texture/Icons/Inventory/AbyssalRandomFilament_L5.png"}
2783	24327	{"_key": 24327, "iconFile": "res:/UI/Texture/Icons/Inventory/AbyssalRandomFilament_L5Active.png"}
2784	24328	{"_key": 24328, "iconFile": "res:/UI/Texture/Shared/mouse_button_middle.png", "iconType": "png"}
2785	24329	{"_key": 24329, "iconFile": "res:/UI/Asset/mannequin/outer/54299_Female_Outer_JacketPrtF01_Types_JacketPrtF01_guristashunt.png", "iconType": "png"}
2786	24330	{"_key": 24330, "iconFile": "res:/UI/Asset/mannequin/feet/54303_Female_Feet_BootsPrtF01_Types_BootsPrtF01_guristashunt.png", "iconType": "png"}
2787	24331	{"_key": 24331, "iconFile": "res:/UI/Asset/mannequin/hair/54304_Female_hair_HeadWear_Beret_F01_Types_HeadWear_Beret_GuristasHuntF01.png", "iconType": "png"}
2788	24332	{"_key": 24332, "iconFile": "res:/UI/Asset/mannequin/bottomouter/54306_Female_bottomOuter_PantsPrtF01_Types_PantsPrtF01_guristashunt.png", "iconType": "png"}
2789	24343	{"_key": 24343, "iconFile": "res:/UI/Asset/mannequin/outer/54307_Male_outer_JacketPrtm01_Types_JacketPrtm01_guristashunt.png", "iconType": "png"}
2790	24344	{"_key": 24344, "iconFile": "res:/UI/Asset/mannequin/bottomouter/54308_Male_bottomOuter_PantsPrtm01_Types_PantsPrtm01_guristashunt.png", "iconType": "png"}
2791	24345	{"_key": 24345, "iconFile": "res:/UI/Asset/mannequin/feet/54309_Male_Feet_BootsPrtm01_Types_BootsPrtm01_guristashunt.png", "iconType": "png"}
2792	24346	{"_key": 24346, "iconFile": "res:/UI/Asset/mannequin/hair/54310_Male_hair_HeadWear_Beret_M01_Types_HeadWear_Beret_GuristasHuntM01.png", "iconType": "png"}
2793	24350	{"_key": 24350, "iconFile": "res:/UI/Asset/mannequin/topmiddle/54320_Female_TopMiddle_TshirtF01_Types_TshirtF01_XVII.png", "iconType": "png"}
2794	24351	{"_key": 24351, "iconFile": "res:/UI/Asset/mannequin/hair/54322_Female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_XVII.png", "iconType": "png"}
2795	24352	{"_key": 24352, "iconFile": "res:/UI/Asset/mannequin/hair/54327_Male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_XVII.png", "iconType": "png"}
2796	24353	{"_key": 24353, "iconFile": "res:/UI/Asset/mannequin/topmiddle/54328_Male_topMiddle_TshirtM01_Types_TshirtM01_XVII.png", "iconType": "png"}
2797	24363	{"_key": 24363, "iconFile": "res:/UI/Asset/mannequin/outer/54359_Female_Outer_JacketCorpBusinessF01_Types_JacketCorpBusinessF01_Black.png", "iconType": "png"}
2798	24364	{"_key": 24364, "iconFile": "res:/UI/Asset/mannequin/outer/54360_Female_Outer_JacketCorpBusinessF01_Types_JacketCorpBusinessF01_Blue_Tie.png", "iconType": "png"}
2799	24365	{"_key": 24365, "iconFile": "res:/UI/Asset/mannequin/outer/54361_Female_Outer_JacketCorpBusinessF01_Types_JacketCorpBusinessF01_BrownStripes.png", "iconType": "png"}
2800	24366	{"_key": 24366, "iconFile": "res:/UI/Asset/mannequin/outer/54362_Female_Outer_JacketCorpBusinessF01_Types_JacketCorpBusinessF01_GrayDark_Tie.png", "iconType": "png"}
2801	24367	{"_key": 24367, "iconFile": "res:/UI/Asset/mannequin/outer/54363_Female_Outer_JacketCorpBusinessF01_Types_JacketCorpBusinessF01_Red.png", "iconType": "png"}
2802	24368	{"_key": 24368, "iconFile": "res:/UI/Asset/mannequin/outer/54364_Female_Outer_JacketCorpBusinessF01_Types_JacketCorpBusinessF01_White_Tie.png", "iconType": "png"}
2803	24369	{"_key": 24369, "iconFile": "res:/UI/Asset/mannequin/bottomouter/54365_Female_bottomOuter_PantsCorpBusinessF01_Types_PantsCorpBusinessF01_Black.png", "iconType": "png"}
2804	24370	{"_key": 24370, "iconFile": "res:/UI/Asset/mannequin/bottomouter/54366_Female_bottomOuter_PantsCorpBusinessF01_Types_PantsCorpBusinessF01_Blue.png", "iconType": "png"}
2805	24371	{"_key": 24371, "iconFile": "res:/UI/Asset/mannequin/bottomouter/54367_Female_bottomOuter_PantsCorpBusinessF01_Types_PantsCorpBusinessF01_BrownStripes.png", "iconType": "png"}
2806	24372	{"_key": 24372, "iconFile": "res:/UI/Asset/mannequin/bottomouter/54368_Female_bottomOuter_PantsCorpBusinessF01_Types_PantsCorpBusinessF01_GrayDark.png", "iconType": "png"}
2807	24373	{"_key": 24373, "iconFile": "res:/UI/Asset/mannequin/bottomouter/54369_Female_bottomOuter_PantsCorpBusinessF01_Types_PantsCorpBusinessF01_Red.png", "iconType": "png"}
2808	24374	{"_key": 24374, "iconFile": "res:/UI/Asset/mannequin/bottomouter/54370_Female_bottomOuter_PantsCorpBusinessF01_Types_PantsCorpBusinessF01_White.png", "iconType": "png"}
2809	24375	{"_key": 24375, "iconFile": "res:/UI/Asset/mannequin/bottomouter/54371_Male_bottomOuter_PantsCorpBusinessM01_Types_PantsCorpBusinessM01_Black.png", "iconType": "png"}
2810	24376	{"_key": 24376, "iconFile": "res:/UI/Asset/mannequin/bottomouter/54372_Male_bottomOuter_PantsCorpBusinessM01_Types_PantsCorpBusinessM01_Blue.png", "iconType": "png"}
2811	24377	{"_key": 24377, "iconFile": "res:/UI/Asset/mannequin/bottomouter/54373_Male_bottomOuter_PantsCorpBusinessM01_Types_PantsCorpBusinessM01_BrownStripes.png", "iconType": "png"}
2812	24378	{"_key": 24378, "iconFile": "res:/UI/Asset/mannequin/bottomouter/54374_Male_bottomOuter_PantsCorpBusinessM01_Types_PantsCorpBusinessM01_GrayDark.png", "iconType": "png"}
2813	24379	{"_key": 24379, "iconFile": "res:/UI/Asset/mannequin/bottomouter/54375_Male_bottomOuter_PantsCorpBusinessM01_Types_PantsCorpBusinessM01_Red.png", "iconType": "png"}
2814	24380	{"_key": 24380, "iconFile": "res:/UI/Asset/mannequin/bottomouter/54376_Male_bottomOuter_PantsCorpBusinessM01_Types_PantsCorpBusinessM01_White.png", "iconType": "png"}
2815	24381	{"_key": 24381, "iconFile": "res:/UI/Asset/mannequin/outer/54377_Male_outer_JacketCorpBusinessM01_Types_JacketCorpBusinessM01_Black.png", "iconType": "png"}
2816	24382	{"_key": 24382, "iconFile": "res:/UI/Asset/mannequin/outer/54378_Male_outer_JacketCorpBusinessM01_Types_JacketCorpBusinessM01_Blue_Tie.png", "iconType": "png"}
2817	24383	{"_key": 24383, "iconFile": "res:/UI/Asset/mannequin/outer/54379_Male_outer_JacketCorpBusinessM01_Types_JacketCorpBusinessM01_BrownStripes.png", "iconType": "png"}
2818	24384	{"_key": 24384, "iconFile": "res:/UI/Asset/mannequin/outer/54380_Male_outer_JacketCorpBusinessM01_Types_JacketCorpBusinessM01_GreyDark_Tie.png", "iconType": "png"}
2819	24385	{"_key": 24385, "iconFile": "res:/UI/Asset/mannequin/outer/54381_Male_outer_JacketCorpBusinessM01_Types_JacketCorpBusinessM01_Red.png", "iconType": "png"}
2820	24386	{"_key": 24386, "iconFile": "res:/UI/Asset/mannequin/outer/54382_Male_outer_JacketCorpBusinessM01_Types_JacketCorpBusinessM01_White_Tie.png", "iconType": "png"}
2821	24387	{"_key": 24387, "iconFile": "res:/UI/Asset/mannequin/feet/54383_Male_Feet_ShoesCorpBusinessM01_Types_ShoesCorpBusinessM01_black.png", "iconType": "png"}
2822	24388	{"_key": 24388, "iconFile": "res:/UI/Asset/mannequin/feet/54384_Male_Feet_ShoesCorpBusinessM01_Types_ShoesCorpBusinessM01_brown.png", "iconType": "png"}
2823	24389	{"_key": 24389, "iconFile": "res:/UI/Asset/mannequin/feet/54385_Male_Feet_ShoesCorpBusinessM01_Types_ShoesCorpBusinessM01_darkbrown.png", "iconType": "png"}
2824	24390	{"_key": 24390, "iconFile": "res:/UI/Asset/mannequin/feet/54386_Male_Feet_ShoesCorpBusinessM01_Types_ShoesCorpBusinessM01_white.png", "iconType": "png"}
2825	24392	{"_key": 24392, "iconFile": "res:/ui/texture/icons/inventory/DLI_blue_1.png"}
2826	24393	{"_key": 24393, "iconFile": "res:/ui/texture/icons/inventory/DLI_blue_2.png"}
2827	24394	{"_key": 24394, "iconFile": "res:/ui/texture/icons/inventory/DLI_blue_3.png"}
2828	24395	{"_key": 24395, "iconFile": "res:/ui/texture/icons/inventory/DLI_extra_1.png"}
2829	24396	{"_key": 24396, "iconFile": "res:/ui/texture/icons/inventory/DLI_extra_2.png"}
2830	24397	{"_key": 24397, "iconFile": "res:/ui/texture/icons/inventory/DLI_extra_3.png"}
2831	24398	{"_key": 24398, "iconFile": "res:/ui/texture/icons/inventory/DLI_gold_1.png"}
2832	24399	{"_key": 24399, "iconFile": "res:/ui/texture/icons/inventory/DLI_gold_2.png"}
2833	24400	{"_key": 24400, "iconFile": "res:/ui/texture/icons/inventory/DLI_gold_3.png"}
2834	24401	{"_key": 24401, "iconFile": "res:/ui/texture/icons/inventory/DLI_green_1.png"}
2835	24402	{"_key": 24402, "iconFile": "res:/ui/texture/icons/inventory/DLI_gray_1.png"}
2836	24403	{"_key": 24403, "iconFile": "res:/ui/texture/icons/inventory/DLI_gray_2.png"}
2837	24404	{"_key": 24404, "iconFile": "res:/ui/texture/icons/inventory/DLI_gray_3.png"}
2838	24405	{"_key": 24405, "iconFile": "res:/ui/texture/icons/inventory/DLI_green_2.png"}
2839	24406	{"_key": 24406, "iconFile": "res:/ui/texture/icons/inventory/DLI_green_3.png"}
2840	24407	{"_key": 24407, "iconFile": "res:/ui/texture/icons/inventory/DLI_purple_1.png"}
2841	24408	{"_key": 24408, "iconFile": "res:/ui/texture/icons/inventory/DLI_purple_2.png"}
2842	24409	{"_key": 24409, "iconFile": "res:/ui/texture/icons/inventory/DLI_purple_3.png"}
2843	24411	{"_key": 24411, "iconFile": "res:/UI/Asset/mannequin/accessories_masks/54714_Female_Accessories_Masks_Mask_F_Types_Mask_F_cyan.png", "iconType": "png"}
2844	24412	{"_key": 24412, "iconFile": "res:/UI/Asset/mannequin/accessories_masks/54715_Female_Accessories_Masks_Mask_F_Types_Mask_F_blackredsoe.png", "iconType": "png"}
2845	24413	{"_key": 24413, "iconFile": "res:/UI/Asset/mannequin/accessories_masks/54716_Female_Accessories_Masks_Mask_F_Types_Mask_F_darkblue.png", "iconType": "png"}
2846	24415	{"_key": 24415, "iconFile": "res:/UI/Asset/mannequin/accessories_masks/54718_Male_Accessories_Masks_Mask_M_Types_Mask_M_blue.png", "iconType": "png"}
2847	24416	{"_key": 24416, "iconFile": "res:/UI/Asset/mannequin/accessories_masks/54719_Male_Accessories_Masks_Mask_M_Types_Mask_M_blackredsoe.png", "iconType": "png"}
2848	24417	{"_key": 24417, "iconFile": "res:/UI/Asset/mannequin/accessories_masks/54720_Male_Accessories_Masks_Mask_M_Types_Mask_M_darkblue.png", "iconType": "png"}
2849	24418	{"_key": 24418, "iconFile": "res:/UI/Asset/mannequin/accessories_masks/54830_Male_Accessories_Masks_Mask_M_Types_Mask_M_cyan.png", "iconType": "png"}
2850	24419	{"_key": 24419, "iconFile": "res:/UI/Texture/Corps/edencom.png", "iconType": "png"}
2851	24421	{"_key": 24421, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/54926_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V3_GoldBlue.png", "iconType": "png"}
2852	24422	{"_key": 24422, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/54927_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V7_Blue.png", "iconType": "png"}
2853	24429	{"_key": 24429, "iconFile": "res:/UI/Asset/mannequin/topmiddle/54943_Male_topMiddle_TshirtM01_Types_TshirtM01_Covid.png", "iconType": "png"}
2854	24430	{"_key": 24430, "iconFile": "res:/UI/Asset/mannequin/topmiddle/54944_Female_TopMiddle_TshirtF01_Types_TshirtF01_Covid.png", "iconType": "png"}
2855	24434	{"_key": 24434, "iconFile": "res:/UI/Asset/mannequin/hair/54948_Male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_Covid.png", "iconType": "png"}
2856	24435	{"_key": 24435, "iconFile": "res:/UI/Asset/mannequin/hair/54949_Female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_Covid.png", "iconType": "png"}
2857	24457	{"_key": 24457, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/54965_Female_Accessories_Glasses_Glasses_Slick_01_Types_Glasses_Slick_01_clear.png", "iconType": "png"}
2858	24458	{"_key": 24458, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/54966_Male_Accessories_Glasses_Glasses_Slick_01_Types_Glasses_Slick_01_clear.png", "iconType": "png"}
2859	24460	{"_key": 24460, "iconFile": "res:/UI/Texture/Icons/SkillPoints/Broken_Skill_Canister.png", "iconType": "png"}
2860	24462	{"_key": 24462, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/55627_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V6_White.png", "iconType": "png"}
2861	24463	{"_key": 24463, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/55636_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V7_White.png", "iconType": "png"}
2862	24464	{"_key": 24464, "iconFile": "res:/UI/Texture/Icons/Modules/upwell_weapon_small.png"}
2863	24465	{"_key": 24465, "iconFile": "res:/UI/Texture/Icons/Modules/upwell_weapon_medium.png"}
2864	24466	{"_key": 24466, "iconFile": "res:/UI/Texture/Icons/Modules/upwell_weapon_large.png"}
2865	24467	{"_key": 24467, "iconFile": "res:/UI/Texture/Icons/Modules/upwell_modifier_amplifier.png"}
2866	24468	{"_key": 24468, "iconFile": "res:/UI/Texture/Icons/Ammo/upwell_ammo_small_black.png"}
2867	24469	{"_key": 24469, "iconFile": "res:/UI/Texture/Icons/Ammo/upwell_ammo_small_blue.png"}
2868	24470	{"_key": 24470, "iconFile": "res:/UI/Texture/Icons/Ammo/upwell_ammo_small_green.png"}
2869	24471	{"_key": 24471, "iconFile": "res:/UI/Texture/Icons/Ammo/upwell_ammo_small_orange.png"}
2870	24472	{"_key": 24472, "iconFile": "res:/UI/Texture/Icons/Ammo/upwell_ammo_small_white.png"}
2871	24473	{"_key": 24473, "iconFile": "res:/UI/Texture/Icons/Ammo/upwell_ammo_small_yellow.png"}
2872	24474	{"_key": 24474, "iconFile": "res:/UI/Texture/Icons/Ammo/upwell_ammo_medium_black.png"}
2873	24475	{"_key": 24475, "iconFile": "res:/UI/Texture/Icons/Ammo/upwell_ammo_medium_blue.png"}
2874	24476	{"_key": 24476, "iconFile": "res:/UI/Texture/Icons/Ammo/upwell_ammo_medium_green.png"}
2875	24477	{"_key": 24477, "iconFile": "res:/UI/Texture/Icons/Ammo/upwell_ammo_medium_orange.png"}
2876	24478	{"_key": 24478, "iconFile": "res:/UI/Texture/Icons/Ammo/upwell_ammo_medium_white.png"}
2877	24479	{"_key": 24479, "iconFile": "res:/UI/Texture/Icons/Ammo/upwell_ammo_medium_yellow.png"}
2878	24480	{"_key": 24480, "iconFile": "res:/UI/Texture/Icons/Ammo/upwell_ammo_large_black.png"}
2879	24481	{"_key": 24481, "iconFile": "res:/UI/Texture/Icons/Ammo/upwell_ammo_large_blue.png"}
2880	24482	{"_key": 24482, "iconFile": "res:/UI/Texture/Icons/Ammo/upwell_ammo_large_green.png"}
2881	24483	{"_key": 24483, "iconFile": "res:/UI/Texture/Icons/Ammo/upwell_ammo_large_orange.png"}
2882	24484	{"_key": 24484, "iconFile": "res:/UI/Texture/Icons/Ammo/upwell_ammo_large_white.png"}
2883	24485	{"_key": 24485, "iconFile": "res:/UI/Texture/Icons/Ammo/upwell_ammo_large_yellow.png"}
2884	24486	{"_key": 24486, "iconFile": "res:/UI/Texture/Icons/Inventory/upwell_industry_array.png"}
2885	24487	{"_key": 24487, "iconFile": "res:/UI/Texture/Icons/Inventory/upwell_industry_electricsheeting.png"}
2886	24488	{"_key": 24488, "iconFile": "res:/UI/Texture/Icons/Inventory/upwell_industry_nanocable.png"}
2887	24489	{"_key": 24489, "iconFile": "res:/UI/Asset/mannequin/hair/55751_Female_hair_HeadWear_Beret_F01_Types_HeadWear_Beret_AmarrFoundationF01.png", "iconType": "png"}
2888	24490	{"_key": 24490, "iconFile": "res:/UI/Asset/mannequin/hair/55752_Female_hair_HeadWear_Beret_F01_Types_HeadWear_Beret_CaldariUnionF01.png", "iconType": "png"}
2889	24491	{"_key": 24491, "iconFile": "res:/UI/Asset/mannequin/hair/55753_Female_hair_HeadWear_Beret_F01_Types_HeadWear_Beret_GallenteFederationF01.png", "iconType": "png"}
2890	24492	{"_key": 24492, "iconFile": "res:/UI/Asset/mannequin/hair/55754_Female_hair_HeadWear_Beret_F01_Types_HeadWear_Beret_MinmatarLiberationF01.png", "iconType": "png"}
2891	24493	{"_key": 24493, "iconFile": "res:/UI/Asset/mannequin/hair/55755_Male_hair_HeadWear_Beret_M01_Types_HeadWear_Beret_AmarrFoundationM01.png", "iconType": "png"}
2892	24494	{"_key": 24494, "iconFile": "res:/UI/Asset/mannequin/hair/55756_Male_hair_HeadWear_Beret_M01_Types_HeadWear_Beret_CaldariUnionM01.png", "iconType": "png"}
2893	24495	{"_key": 24495, "iconFile": "res:/UI/Asset/mannequin/hair/55757_Male_hair_HeadWear_Beret_M01_Types_HeadWear_Beret_GallenteFederationM01.png", "iconType": "png"}
2894	24496	{"_key": 24496, "iconFile": "res:/UI/Asset/mannequin/hair/55758_Male_hair_HeadWear_Beret_M01_Types_HeadWear_Beret_MinmatarLiberationM01.png", "iconType": "png"}
2895	24497	{"_key": 24497, "iconFile": "res:/UI/Texture/Icons/Inventory/AbyssalArenaFilaments_1v1.png"}
2896	24498	{"_key": 24498, "iconFile": "res:/UI/Texture/Icons/Inventory/AbyssalArenaFilaments_2v2.png"}
2897	24499	{"_key": 24499, "iconFile": "res:/UI/Texture/Icons/Inventory/AbyssalArenaFilaments_3v3.png"}
2898	24501	{"_key": 24501, "iconFile": "res:/UI/Texture/Icons/Inventory/AbyssalArenaFilaments_5v5.png"}
2899	24502	{"_key": 24502, "iconFile": "res:/UI/Asset/mannequin/outer/55855_Female_Outer_VanguardF01_Types_VanguardF01_TG_PVP_Arena.png", "iconType": "png"}
2900	24503	{"_key": 24503, "iconFile": "res:/UI/Asset/mannequin/outer/55856_Female_Outer_ArmorSuitCF01_Types_ArmorSuitCF01_TG_PVP_Arena.png", "iconType": "png"}
2901	24504	{"_key": 24504, "iconFile": "res:/UI/Asset/mannequin/outer/55857_Male_outer_ArmorSuitMM01_Types_ArmorSuitMM01_TG_PVP_Arena.png", "iconType": "png"}
2902	24505	{"_key": 24505, "iconFile": "res:/UI/Asset/mannequin/outer/55858_Male_outer_VanguardM01_Types_VanguardM01_TG_PVP_Arena.png", "iconType": "png"}
2903	24506	{"_key": 24506, "iconFile": "res:/UI/Asset/mannequin/hair/56144_Female_hair_HeadWear_Beret_F01_Types_HeadWear_Beret_EdencomF01.png", "iconType": "png"}
2904	24507	{"_key": 24507, "iconFile": "res:/UI/Asset/mannequin/hair/56145_Male_hair_HeadWear_Beret_M01_Types_HeadWear_Beret_EdencomM01.png", "iconType": "png"}
2905	24508	{"_key": 24508, "iconFile": "res:/UI/Asset/mannequin/topmiddle/56146_Female_TopMiddle_TshirtF01_Types_TshirtF01_Edencom.png", "iconType": "png"}
2906	24509	{"_key": 24509, "iconFile": "res:/UI/Asset/mannequin/topmiddle/56147_Male_topMiddle_TshirtM01_Types_TshirtM01_Edencom.png", "iconType": "png"}
2907	24510	{"_key": 24510, "iconFile": "res:/UI/Texture/Icons/Inventory/abyssalFilamentL0.png"}
2908	24511	{"_key": 24511, "iconFile": "res:/UI/Texture/Icons/Inventory/abyssalFilamentL6.png"}
2909	24512	{"_key": 24512, "iconFile": "res:/UI/Asset/mannequin/hair/56209_Female_hair_HeadWear_Beret_F01_Types_HeadWear_Beret_TriglavianF01.png", "iconType": "png"}
2910	24513	{"_key": 24513, "iconFile": "res:/UI/Asset/mannequin/hair/56210_Male_hair_HeadWear_Beret_M01_Types_HeadWear_Beret_TriglavianM01.png", "iconType": "png"}
2911	24514	{"_key": 24514, "iconFile": "res:/UI/Asset/mannequin/topmiddle/56211_Female_TopMiddle_TshirtF01_Types_TshirtF01_Triglavian.png", "iconType": "png"}
2912	24515	{"_key": 24515, "iconFile": "res:/UI/Asset/mannequin/topmiddle/56212_Male_topMiddle_TshirtM01_Types_TshirtM01_Triglavian.png", "iconType": "png"}
2913	24516	{"_key": 24516, "iconFile": "res:/UI/Asset/mannequin/outer/56223_Female_Outer_JacketCMF01_Types_JacketCMF01_Edencom.png", "iconType": "png"}
2914	24517	{"_key": 24517, "iconFile": "res:/UI/Asset/mannequin/outer/56224_Male_outer_JacketCMM01_Types_JacketCMM01_Edencom.png", "iconType": "png"}
2915	24518	{"_key": 24518, "iconFile": "res:/UI/Asset/mannequin/outer/56225_Female_Outer_VanguardF01_Types_VanguardF01_TG_LP.png", "iconType": "png"}
2916	24519	{"_key": 24519, "iconFile": "res:/UI/Asset/mannequin/outer/56226_Male_outer_VanguardM01_Types_VanguardM01_TG_LP.png", "iconType": "png"}
2917	24525	{"_key": 24525, "iconFile": "res:/UI/Asset/mannequin/outer/56264_Female_Outer_ArmorSuitCF01_Types_ArmorSuitCF01_TG_LP.png", "iconType": "png"}
2918	24526	{"_key": 24526, "iconFile": "res:/UI/Asset/mannequin/outer/56265_Female_Outer_ArmorSuitCF01_Types_ArmorSuitCF01_Edencom.png", "iconType": "png"}
2919	24527	{"_key": 24527, "iconFile": "res:/UI/Asset/mannequin/outer/56266_Male_outer_ArmorSuitMM01_Types_ArmorSuitMM01_TG_LP.png", "iconType": "png"}
2920	24528	{"_key": 24528, "iconFile": "res:/UI/Asset/mannequin/outer/56267_Male_outer_ArmorSuitMM01_Types_ArmorSuitMM01_Edencom.png", "iconType": "png"}
2921	24529	{"_key": 24529, "iconFile": "res:/UI/Texture/Icons/Conversations/theAgency.png", "iconType": "png"}
2922	24530	{"_key": 24530, "iconFile": "res:/UI/Texture/Icons/Inventory/FilamentTSpace1.png", "iconType": "png"}
2923	24531	{"_key": 24531, "iconFile": "res:/UI/Texture/Icons/Inventory/FilamentTSpace2.png", "iconType": "png"}
2924	24532	{"_key": 24532, "iconFile": "res:/UI/Texture/Icons/Inventory/FilamentTSpace3.png", "iconType": "png"}
2925	24533	{"_key": 24533, "iconFile": "res:/ui/texture/icons/upwell/QuantumCoreM.png", "iconType": "png"}
2926	24534	{"_key": 24534, "iconFile": "res:/ui/texture/icons/upwell/QuantumCoreL.png", "iconType": "png"}
2927	24535	{"_key": 24535, "iconFile": "res:/ui/texture/icons/upwell/QuantumCoreXL.png", "iconType": "png"}
2928	24536	{"_key": 24536, "iconFile": "res:/UI/Asset/mannequin/hair/56634_Female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_BR_CrimonHarvest.png", "iconType": "png"}
2929	24537	{"_key": 24537, "iconFile": "res:/UI/Asset/mannequin/outer/56635_Female_Outer_JacketFBR01_Types_JacketFBR01_BR_CrimsonHarvest.png", "iconType": "png"}
2930	24538	{"_key": 24538, "iconFile": "res:/UI/Asset/mannequin/topmiddle/56636_Female_TopMiddle_TshirtF01_Types_TshirtF01_BR_CrimsonHarvest.png", "iconType": "png"}
2931	24539	{"_key": 24539, "iconFile": "res:/UI/Asset/mannequin/hair/56637_Male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_BR_CrimsonHarvest.png", "iconType": "png"}
2932	24540	{"_key": 24540, "iconFile": "res:/UI/Asset/mannequin/outer/56638_Male_outer_JacketMFBR01_Types_JacketMFBR01_BR_CrimsonHarvest.png", "iconType": "png"}
2933	24541	{"_key": 24541, "iconFile": "res:/UI/Asset/mannequin/topmiddle/56639_Male_topMiddle_TshirtM01_Types_TshirtM01_BR_CrimsonHarvest.png", "iconType": "png"}
2934	24543	{"_key": 24543, "iconFile": "res:/UI/Texture/Icons/Ammo/probe_charge_green.png"}
2935	24544	{"_key": 24544, "iconFile": "res:/UI/Texture/Icons/Ammo/probe_charge_coral.png"}
2936	24545	{"_key": 24545, "iconFile": "res:/UI/Texture/Icons/Ammo/probe_charge_olive.png"}
2937	24546	{"_key": 24546, "iconFile": "res:/UI/Texture/Icons/Ammo/probe_charge_violet.png"}
2938	24547	{"_key": 24547, "iconFile": "res:/UI/Texture/Icons/Modules/SuperCarrierCloneBay.png"}
2939	24548	{"_key": 24548, "iconFile": "res:/UI/Asset/mannequin/feet/56844_Female_Feet_ShoesEngF01_Types_ShoesEngF01_Jita.png", "iconType": "png"}
2940	24549	{"_key": 24549, "iconFile": "res:/UI/Asset/mannequin/topmiddle/56845_Female_TopMiddle_ShirtEngF01_Types_ShirtEngF01_Jita.png", "iconType": "png"}
2941	24550	{"_key": 24550, "iconFile": "res:/UI/Asset/mannequin/bottomouter/56846_Female_bottomOuter_PantsEngF01_Types_PantsEngF01_Jita.png", "iconType": "png"}
2942	24551	{"_key": 24551, "iconFile": "res:/UI/Asset/mannequin/feet/56847_Male_Feet_ShoesEngM01_Types_ShoesEngM01_jita.png", "iconType": "png"}
2943	24552	{"_key": 24552, "iconFile": "res:/UI/Asset/mannequin/topmiddle/56848_Male_topMiddle_ShirtEngM01_Types_ShirtEngM01_jita.png", "iconType": "png"}
2944	24553	{"_key": 24553, "iconFile": "res:/UI/Asset/mannequin/bottomouter/56849_Male_bottomOuter_PantsEngM01_Types_PantsEngM01_jita.png", "iconType": "png"}
2945	24554	{"_key": 24554, "iconFile": "res:/UI/Asset/mannequin/bottomouter/56850_Male_bottomOuter_PantsCorpBusinessM01_Types_PantsCorpBusinessM01_Jita.png", "iconType": "png"}
2946	24555	{"_key": 24555, "iconFile": "res:/UI/Asset/mannequin/outer/56851_Male_outer_JacketCorpBusinessM01_Types_JacketCorpBusinessM01_Jita_Tie.png", "iconType": "png"}
2947	24556	{"_key": 24556, "iconFile": "res:/UI/Asset/mannequin/outer/56852_Female_Outer_JacketCorpBusinessF01_Types_JacketCorpBusinessF01_Jita_Tie.png", "iconType": "png"}
2948	24557	{"_key": 24557, "iconFile": "res:/UI/Asset/mannequin/bottomouter/56853_Female_bottomOuter_PantsCorpBusinessF01_Types_PantsCorpBusinessF01_Jita.png", "iconType": "png"}
2949	24558	{"_key": 24558, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/56854_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V33_Japan.png", "iconType": "png"}
2950	24559	{"_key": 24559, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/56855_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V34_Japan.png", "iconType": "png"}
2951	24560	{"_key": 24560, "iconFile": "res:/UI/Asset/mannequin/outer/56856_Male_outer_ExplorationSuit_M01_Types_ExplorationSuit_M01_Japan.png", "iconType": "png"}
2952	24561	{"_key": 24561, "iconFile": "res:/UI/Asset/mannequin/outer/56857_Female_Outer_ExplorationSuit_F01_Types_ExplorationSuit_F01_Japan.png", "iconType": "png"}
2953	24562	{"_key": 24562, "iconFile": "res:/UI/Texture/Icons/Inventory/encrypted_bond_1.png"}
2954	24563	{"_key": 24563, "iconFile": "res:/UI/Texture/Icons/Inventory/encrypted_bond_2.png"}
2955	24564	{"_key": 24564, "iconFile": "res:/UI/Texture/Icons/Inventory/encrypted_bond_3.png"}
2956	24565	{"_key": 24565, "iconFile": "res:/UI/Texture/Icons/Inventory/encrypted_bond_4.png"}
2957	24566	{"_key": 24566, "iconFile": "res:/UI/Texture/Icons/Inventory/StormChaserFilamentHighSec_64.png", "iconType": "png"}
2958	24567	{"_key": 24567, "iconFile": "res:/UI/Texture/Icons/Inventory/StormChaserFilamentLowSec_64.png", "iconType": "png"}
2959	24568	{"_key": 24568, "iconFile": "res:/UI/Texture/Icons/Inventory/StormChaserFilamentNullSec_64.png", "iconType": "png"}
2960	24569	{"_key": 24569, "iconFile": "res:/UI/Asset/mannequin/topmiddle/57073_Male_topMiddle_TshirtM01_Types_TshirtM01_Yoiul.png", "iconType": "png"}
2961	24570	{"_key": 24570, "iconFile": "res:/UI/Asset/mannequin/hair/57074_Male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_Yoiul.png", "iconType": "png"}
2962	24571	{"_key": 24571, "iconFile": "res:/UI/Asset/mannequin/bottomouter/57075_Male_bottomOuter_PantsMilM01_Types_PantsMilM01_Yoiul.png", "iconType": "png"}
2963	24572	{"_key": 24572, "iconFile": "res:/UI/Asset/mannequin/outer/57076_Male_outer_ExplorationSuit_M01_Types_ExplorationSuit_M01_Yoiul.png", "iconType": "png"}
2964	24573	{"_key": 24573, "iconFile": "res:/UI/Asset/mannequin/topmiddle/57077_Female_TopMiddle_TshirtF01_Types_TshirtF01_Yoiul.png", "iconType": "png"}
2965	24574	{"_key": 24574, "iconFile": "res:/UI/Asset/mannequin/bottomouter/57078_Female_bottomOuter_PantsMilF01_Types_PantsMilF01_Yoiul.png", "iconType": "png"}
2966	24575	{"_key": 24575, "iconFile": "res:/UI/Asset/mannequin/hair/57079_Female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_Yoiul.png", "iconType": "png"}
2967	24576	{"_key": 24576, "iconFile": "res:/UI/Asset/mannequin/outer/57080_Female_Outer_ExplorationSuit_F01_Types_ExplorationSuit_F01_Yoiul.png", "iconType": "png"}
2968	24577	{"_key": 24577, "iconFile": "res:/UI/Texture/Icons/StatusEffects/YoiulMetaliminalStorm.png"}
2969	24578	{"_key": 24578, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_Xin.png", "iconType": "png"}
2970	24579	{"_key": 24579, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_Nian.png", "iconType": "png"}
2971	24580	{"_key": 24580, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_Kuai.png", "iconType": "png"}
2972	24581	{"_key": 24581, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_Le.png", "iconType": "png"}
2973	24582	{"_key": 24582, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_Bull20.png", "iconType": "png"}
2974	24583	{"_key": 24583, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_Bull21.png", "iconType": "png"}
2975	24584	{"_key": 24584, "iconFile": "res:/UI/Texture/Icons/Inventory/BullCrate_64.png", "iconType": "png"}
2976	24585	{"_key": 24585, "iconFile": "res:/UI/Texture/Icons/Inventory/ExpertSystems/BaseSystem.png", "iconType": "png"}
2977	24587	{"_key": 24587, "iconFile": "res:/UI/Texture/Icons/Inventory/Accelerator_ZN_A.png", "iconType": "png"}
2978	24588	{"_key": 24588, "iconFile": "res:/UI/Texture/Icons/Inventory/Accelerator_ZN_B.png", "iconType": "png"}
2979	24589	{"_key": 24589, "iconFile": "res:/UI/Texture/Icons/Inventory/Accelerator_ZN_C.png", "iconType": "png"}
2980	24590	{"_key": 24590, "iconFile": "res:/UI/Texture/Icons/Inventory/Accelerator_ZN_X.png", "iconType": "png"}
2981	24591	{"_key": 24591, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_ZN01.png", "iconType": "png"}
2982	24592	{"_key": 24592, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_ZN02.png", "iconType": "png"}
2983	24593	{"_key": 24593, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_ZN03.png", "iconType": "png"}
2984	24594	{"_key": 24594, "iconFile": "res:/UI/Texture/Icons/Inventory/Crate_NewYear_64.png", "iconType": "png"}
2985	24595	{"_key": 24595, "iconFile": "res:/UI/Texture/Icons/Inventory/Crate_ShipSkin_64.png", "iconType": "png"}
2986	24597	{"_key": 24597, "iconFile": "res:/UI/Texture/Icons/Inventory/ExpertSystems/CoreShipSystems.png", "iconType": "png"}
2987	24600	{"_key": 24600, "iconFile": "res:/UI/Texture/Icons/Inventory/ExpertSystems/HighSecuritySpaceExplorer.png", "iconType": "png"}
2988	24601	{"_key": 24601, "iconFile": "res:/UI/Texture/Icons/Inventory/ExpertSystems/InterceptorEventSystem.png", "iconType": "png"}
2989	24602	{"_key": 24602, "iconFile": "res:/UI/Texture/Icons/Inventory/ExpertSystems/MiningBargeSystem.png", "iconType": "png"}
2990	24603	{"_key": 24603, "iconFile": "res:/UI/Texture/Icons/Inventory/ExpertSystems/Science.png", "iconType": "png"}
2991	24604	{"_key": 24604, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Capital_Core_Temperature_Regulator.png", "iconType": "png"}
2992	24605	{"_key": 24605, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Core_Temperature_Regulator.png", "iconType": "png"}
2993	24606	{"_key": 24606, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Counter-Subversion_Sensor_Array.png", "iconType": "png"}
2994	24607	{"_key": 24607, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/CV-Composite_Molecular_Condenser.png", "iconType": "png"}
2995	24608	{"_key": 24608, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Electro-Neural_Signaller.png", "iconType": "png"}
2996	24609	{"_key": 24609, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Enhanced_Electro-Neural_Signaller.png", "iconType": "png"}
2997	24610	{"_key": 24610, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/G-O_Trigger_Neurolink_Conduit.png", "iconType": "png"}
2998	24611	{"_key": 24611, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Genetic_Lock_Preserver.png", "iconType": "png"}
2999	24612	{"_key": 24612, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Genetic_Mutation_Inhibiter.png", "iconType": "png"}
3000	24613	{"_key": 24613, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Genetic_Safeguard_Filter.png", "iconType": "png"}
3001	24614	{"_key": 24614, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Genetic_Structure_Repairer.png", "iconType": "png"}
3002	24615	{"_key": 24615, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Goal-Orienting_Neurolink_Stabilizer.png", "iconType": "png"}
3003	24616	{"_key": 24616, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Gravimetric-FTL_Interlink_Communicator.png", "iconType": "png"}
3004	24617	{"_key": 24617, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Isotropic_Neofullerene_Alpha-3.png", "iconType": "png"}
3005	24618	{"_key": 24618, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Isotropic_Neofullerene_Beta-6.png", "iconType": "png"}
3006	24619	{"_key": 24619, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Isotropic_Neofullerene_Gamma-9.png", "iconType": "png"}
3007	24620	{"_key": 24620, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Ladar-FTL_Interlink_Communicator.png", "iconType": "png"}
3008	24621	{"_key": 24621, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/LM-Composite_Molecular_Condenser.png", "iconType": "png"}
3009	24622	{"_key": 24622, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Magnetometric-FTL_Interlink_Communicator.png", "iconType": "png"}
3010	24623	{"_key": 24623, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Meta-Molecular_Combiner.png", "iconType": "png"}
3011	24624	{"_key": 24624, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Meta-Operant_Neurolink_Booster.png", "iconType": "png"}
3012	24625	{"_key": 24625, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Nanoscale_Filter_Plate.png", "iconType": "png"}
3013	24626	{"_key": 24626, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Nano_Regulation_Gate.png", "iconType": "png"}
3014	24627	{"_key": 24627, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Neurolink_Booster_Reservoir.png", "iconType": "png"}
3015	24628	{"_key": 24628, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Programmable_Purification_Membrane.png", "iconType": "png"}
3016	24629	{"_key": 24629, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/R-O_Trigger_Neurolink_Conduit.png", "iconType": "png"}
3017	24630	{"_key": 24630, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Radar-FTL_Interlink_Communicator.png", "iconType": "png"}
3018	24631	{"_key": 24631, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Reaction-Orienting_Neurolink_Stabilizer.png", "iconType": "png"}
3019	24632	{"_key": 24632, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/S-R_Trigger_Neurolink_Conduit.png", "iconType": "png"}
3020	24633	{"_key": 24633, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Solid_Gas_Merger.png", "iconType": "png"}
3021	24634	{"_key": 24634, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Stress-Responding_Neurolink_Stabilizer.png", "iconType": "png"}
3022	24635	{"_key": 24635, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/U-C_Trigger_Neurolink_Conduit.png", "iconType": "png"}
3023	24636	{"_key": 24636, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Ultradian-Cycling_Neurolink_Stabilizer.png", "iconType": "png"}
3024	24637	{"_key": 24637, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/AG-Composite_Molecular_Condenser.png", "iconType": "png"}
3025	24638	{"_key": 24638, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Auto-Preservation_Component.png", "iconType": "png"}
3026	24639	{"_key": 24639, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/AV-Composite_Molecular_Condenser.png", "iconType": "png"}
3027	24640	{"_key": 24640, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/LifeSupport_unit.png", "iconType": "LifeSupport_unit.png"}
3028	24641	{"_key": 24641, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Neurolink_Cell.png", "iconType": "png"}
3029	24642	{"_key": 24642, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Neurolink_Cell_Enhanced.png", "iconType": "png"}
3030	24643	{"_key": 24643, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Fortitude_liquid_A.png", "iconType": "png"}
3031	24644	{"_key": 24644, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Fortitude_liquid_B.png", "iconType": "png"}
3032	24645	{"_key": 24645, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Fortitude_liquid_C.png", "iconType": "png"}
3033	24646	{"_key": 24646, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Fortitude_liquid_D.png", "iconType": "png"}
3034	24655	{"_key": 24655, "iconFile": "res:/ui/Texture/Shared/hamburgerMenu_Large.png", "iconType": "png"}
3035	24656	{"_key": 24656, "iconFile": "res:/UI/Texture/classes/Industry/activity/manufacturing.png", "iconType": "png"}
3036	24657	{"_key": 24657, "iconFile": "res:/UI/Texture/classes/Industry/activity/copying.png", "iconType": "png"}
3037	24658	{"_key": 24658, "iconFile": "res:/UI/Texture/classes/Industry/activity/researchMaterial.png", "iconType": "png"}
3038	24659	{"_key": 24659, "iconFile": "res:/UI/Texture/classes/Industry/activity/researchTime.png", "iconType": "png"}
3039	24660	{"_key": 24660, "iconFile": "res:/UI/Texture/classes/Industry/activity/invention.png", "iconType": "png"}
3040	24661	{"_key": 24661, "iconFile": "res:/UI/Texture/classes/Industry/activity/reaction.png", "iconType": "png"}
3041	24662	{"_key": 24662, "iconFile": "res:/UI/Texture/SettingsCogwheel.png", "iconType": "png"}
3042	24663	{"_key": 24663, "iconFile": "res:/UI/Texture/classes/MapView/focusIcon.png", "iconType": "png"}
3043	24664	{"_key": 24664, "iconFile": "res:/UI/Texture/classes/Fitting/tabSkins.png", "iconType": "png"}
3044	24665	{"_key": 24665, "iconFile": "res:/UI/Texture/classes/Fitting/tabHardware.png", "iconType": "png"}
3045	24666	{"_key": 24666, "iconFile": "res:/UI/Texture/Icons/d-scan.png", "iconType": "png"}
3046	24667	{"_key": 24667, "iconFile": "res:/UI/Texture/Icons/probe_scan.png", "iconType": "png"}
3047	24668	{"_key": 24668, "iconFile": "res:/UI/Texture/Icons/Inventory/IconAccelerator_Anniversary_I.png", "iconType": "png"}
3048	24669	{"_key": 24669, "iconFile": "res:/UI/Texture/Icons/Inventory/IconAccelerator_Anniversary_II.png", "iconType": "png"}
3049	24670	{"_key": 24670, "iconFile": "res:/UI/Texture/Icons/Inventory/IconAccelerator_Anniversary_III.png", "iconType": "png"}
3050	24671	{"_key": 24671, "iconFile": "res:/UI/Texture/Icons/Inventory/IconAccelerator_Anniversary_IV.png", "iconType": "png"}
3051	24672	{"_key": 24672, "iconFile": "res:/UI/Texture/Icons/Inventory/IconZXJ_Anniversary_TP.png", "iconType": "png"}
3052	24673	{"_key": 24673, "iconFile": "res:/UI/Texture/Icons/Inventory/IconZXJ_Anniversary_YK.png", "iconType": "png"}
3053	24674	{"_key": 24674, "iconFile": "res:/UI/Texture/Icons/Inventory/IconZXJ_Anniversary_HQ.png", "iconType": "png"}
3054	24675	{"_key": 24675, "iconFile": "res:/UI/Texture/Icons/Inventory/IconZXJ_Anniversary_XN.png", "iconType": "png"}
3055	24676	{"_key": 24676, "iconFile": "res:/UI/Texture/Icons/Inventory/IconZXJ_Anniversary_MM.png", "iconType": "png"}
3056	24677	{"_key": 24677, "iconFile": "res:/UI/Texture/Icons/Inventory/IconCrate_ShipSkin02_64.png", "iconType": "png"}
3057	24678	{"_key": 24678, "iconFile": "res:/UI/Texture/Icons/Inventory/Icon_TravellingGallery_Amarr.png", "iconType": "png"}
3058	24679	{"_key": 24679, "iconFile": "res:/UI/Texture/Icons/Inventory/Icon_TravellingGallery_Caldari.png", "iconType": "png"}
3059	24680	{"_key": 24680, "iconFile": "res:/UI/Texture/Icons/Inventory/Icon_TravellingGallery_Gallente.png", "iconType": "png"}
3060	24681	{"_key": 24681, "iconFile": "res:/UI/Texture/Icons/Inventory/Icon_TravellingGallery_Minmatar.png", "iconType": "png"}
3061	24682	{"_key": 24682, "iconFile": "res:/UI/Texture/Icons/Inventory/Icon_TravellingGallery_StarMap.png", "iconType": "png"}
3062	24683	{"_key": 24683, "iconFile": "res:/UI/Asset/mannequin/topmiddle/58757_Male_topMiddle_TshirtM01_Types_TshirtM01_XVIII.png", "iconType": "png"}
3063	24684	{"_key": 24684, "iconFile": "res:/UI/Asset/mannequin/hair/58767_Male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_XVIII.png", "iconType": "png"}
3064	24685	{"_key": 24685, "iconFile": "res:/UI/Asset/mannequin/topmiddle/58768_Female_TopMiddle_TshirtF01_Types_TshirtF01_XVIII.png", "iconType": "png"}
3065	24686	{"_key": 24686, "iconFile": "res:/UI/Asset/mannequin/hair/58769_Female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_XVIII.png", "iconType": "png"}
3066	24687	{"_key": 24687, "iconFile": "res:/UI/Asset/mannequin/bottomouter/58785_Female_bottomOuter_PantsEngF01_Types_PantsEngF01_amarr.png", "iconType": "png"}
3067	24688	{"_key": 24688, "iconFile": "res:/UI/Asset/mannequin/bottomouter/58786_Female_bottomOuter_PantsEngF01_Types_PantsEngF01_caldari.png", "iconType": "png"}
3068	24689	{"_key": 24689, "iconFile": "res:/UI/Asset/mannequin/bottomouter/58787_Female_bottomOuter_PantsEngF01_Types_PantsEngF01_gallente.png", "iconType": "png"}
3069	24690	{"_key": 24690, "iconFile": "res:/UI/Asset/mannequin/bottomouter/58788_Female_bottomOuter_PantsEngF01_Types_PantsEngF01_minmatar.png", "iconType": "png"}
3070	24691	{"_key": 24691, "iconFile": "res:/UI/Asset/mannequin/bottomouter/58791_Male_bottomOuter_PantsEngM01_Types_PantsEngM01_amarr.png", "iconType": "png"}
3071	24692	{"_key": 24692, "iconFile": "res:/UI/Asset/mannequin/bottomouter/58792_Male_bottomOuter_PantsEngM01_Types_PantsEngM01_caldari.png", "iconType": "png"}
3072	24693	{"_key": 24693, "iconFile": "res:/UI/Asset/mannequin/bottomouter/58793_Male_bottomOuter_PantsEngM01_Types_PantsEngM01_gallente.png", "iconType": "png"}
3073	24694	{"_key": 24694, "iconFile": "res:/UI/Asset/mannequin/bottomouter/58794_Male_bottomOuter_PantsEngM01_Types_PantsEngM01_minmatar.png", "iconType": "png"}
3074	24695	{"_key": 24695, "iconFile": "res:/UI/Asset/mannequin/topmiddle/58809_Female_TopMiddle_ShirtEngF01_Types_ShirtEngF01_amarr.png", "iconType": "png"}
3075	24696	{"_key": 24696, "iconFile": "res:/UI/Asset/mannequin/topmiddle/58810_Female_TopMiddle_ShirtEngF01_Types_ShirtEngF01_caldari.png", "iconType": "png"}
3076	24697	{"_key": 24697, "iconFile": "res:/UI/Asset/mannequin/topmiddle/58811_Female_TopMiddle_ShirtEngF01_Types_ShirtEngF01_gallente.png", "iconType": "png"}
3077	24698	{"_key": 24698, "iconFile": "res:/UI/Asset/mannequin/topmiddle/58812_Female_TopMiddle_ShirtEngF01_Types_ShirtEngF01_minmatar.png", "iconType": "png"}
3078	24699	{"_key": 24699, "iconFile": "res:/UI/Asset/mannequin/topmiddle/58813_Male_topMiddle_ShirtEngM01_Types_ShirtEngM01_amarr.png", "iconType": "png"}
3079	24700	{"_key": 24700, "iconFile": "res:/UI/Asset/mannequin/topmiddle/58814_Male_topMiddle_ShirtEngM01_Types_ShirtEngM01_caldari.png", "iconType": "png"}
3080	24701	{"_key": 24701, "iconFile": "res:/UI/Asset/mannequin/topmiddle/58815_Male_topMiddle_ShirtEngM01_Types_ShirtEngM01_gallente.png", "iconType": "png"}
3081	24702	{"_key": 24702, "iconFile": "res:/UI/Asset/mannequin/topmiddle/58816_Male_topMiddle_ShirtEngM01_Types_ShirtEngM01_minmatar.png", "iconType": "png"}
3082	24703	{"_key": 24703, "iconFile": "res:/UI/Asset/mannequin/feet/58817_Female_Feet_ShoesEngF01_Types_ShoesEngF01_amarr.png", "iconType": "png"}
3083	24704	{"_key": 24704, "iconFile": "res:/UI/Asset/mannequin/feet/58818_Female_Feet_ShoesEngF01_Types_ShoesEngF01_caldari.png", "iconType": "png"}
3084	24705	{"_key": 24705, "iconFile": "res:/UI/Asset/mannequin/feet/58819_Female_Feet_ShoesEngF01_Types_ShoesEngF01_gallente.png", "iconType": "png"}
3085	24706	{"_key": 24706, "iconFile": "res:/UI/Asset/mannequin/feet/58820_Female_Feet_ShoesEngF01_Types_ShoesEngF01_minmatar.png", "iconType": "png"}
3086	24707	{"_key": 24707, "iconFile": "res:/UI/Asset/mannequin/feet/58821_Female_Feet_ShoesEngF01_Types_ShoesEngF01_redblack.png", "iconType": "png"}
3087	24708	{"_key": 24708, "iconFile": "res:/UI/Asset/mannequin/feet/58825_Male_Feet_ShoesEngM01_Types_ShoesEngM01_amarr.png", "iconType": "png"}
3088	24709	{"_key": 24709, "iconFile": "res:/UI/Asset/mannequin/feet/58826_Male_Feet_ShoesEngM01_Types_ShoesEngM01_caldari.png", "iconType": "png"}
3089	24710	{"_key": 24710, "iconFile": "res:/UI/Asset/mannequin/feet/58827_Male_Feet_ShoesEngM01_Types_ShoesEngM01_gallente.png", "iconType": "png"}
3090	24711	{"_key": 24711, "iconFile": "res:/UI/Asset/mannequin/feet/58828_Male_Feet_ShoesEngM01_Types_ShoesEngM01_minmatar.png", "iconType": "png"}
3091	24712	{"_key": 24712, "iconFile": "res:/UI/Asset/mannequin/feet/58829_Male_Feet_ShoesEngM01_Types_ShoesEngM01_redblack.png", "iconType": "png"}
3092	24713	{"_key": 24713, "iconFile": "res:/UI/Asset/mannequin/outer/58933_Male_outer_JacketFormalMilM01_Types_JacketFormalMilM01_BlueCal.png", "iconType": "png"}
3093	24714	{"_key": 24714, "iconFile": "res:/UI/Asset/mannequin/outer/58934_Male_outer_JacketFormalMilM01_Types_JacketFormalMilM01_BrownAmarr.png", "iconType": "png"}
3094	24715	{"_key": 24715, "iconFile": "res:/UI/Asset/mannequin/outer/58935_Male_outer_JacketFormalMilM01_Types_JacketFormalMilM01_GreenGallente.png", "iconType": "png"}
3095	24716	{"_key": 24716, "iconFile": "res:/UI/Asset/mannequin/outer/58936_Male_outer_JacketFormalMilM01_Types_JacketFormalMilM01_BrownMinmatar.png", "iconType": "png"}
3096	24717	{"_key": 24717, "iconFile": "res:/UI/Asset/mannequin/outer/58941_Female_Outer_JacketFormalMilF01_Types_JacketFormalMilF01_Caldari.png", "iconType": "png"}
3097	24718	{"_key": 24718, "iconFile": "res:/UI/Asset/mannequin/outer/58942_Female_Outer_JacketFormalMilF01_Types_JacketFormalMilF01_Amarr.png", "iconType": "png"}
3098	24719	{"_key": 24719, "iconFile": "res:/UI/Asset/mannequin/outer/58943_Female_Outer_JacketFormalMilF01_Types_JacketFormalMilF01_Gallente.png", "iconType": "png"}
3099	24720	{"_key": 24720, "iconFile": "res:/UI/Asset/mannequin/outer/58944_Female_Outer_JacketFormalMilF01_Types_JacketFormalMilF01_Minmatar.png", "iconType": "png"}
3100	24721	{"_key": 24721, "iconFile": "res:/UI/Asset/mannequin/bottomouter/58946_Female_bottomOuter_PantsCorpBusinessF01_Types_PantsCorpBusinessF01_CaldariMil.png", "iconType": "png"}
3101	24722	{"_key": 24722, "iconFile": "res:/UI/Asset/mannequin/bottomouter/58947_Female_bottomOuter_PantsCorpBusinessF01_Types_PantsCorpBusinessF01_AmarrMil.png", "iconType": "png"}
3102	24723	{"_key": 24723, "iconFile": "res:/UI/Asset/mannequin/bottomouter/58948_Female_bottomOuter_PantsCorpBusinessF01_Types_PantsCorpBusinessF01_GallenteMil.png", "iconType": "png"}
3103	24724	{"_key": 24724, "iconFile": "res:/UI/Asset/mannequin/bottomouter/58949_Female_bottomOuter_PantsCorpBusinessF01_Types_PantsCorpBusinessF01_MinmatarMil.png", "iconType": "png"}
3104	24725	{"_key": 24725, "iconFile": "res:/UI/Asset/mannequin/bottomouter/58951_Male_bottomOuter_PantsCorpBusinessM01_Types_PantsCorpBusinessM01_BlueCalMil.png", "iconType": "png"}
3105	24726	{"_key": 24726, "iconFile": "res:/UI/Asset/mannequin/bottomouter/58952_Male_bottomOuter_PantsCorpBusinessM01_Types_PantsCorpBusinessM01_BrownAmarrMil.png", "iconType": "png"}
3106	24727	{"_key": 24727, "iconFile": "res:/UI/Asset/mannequin/bottomouter/58953_Male_bottomOuter_PantsCorpBusinessM01_Types_PantsCorpBusinessM01_GreenGallenteMil.png", "iconType": "png"}
3107	24728	{"_key": 24728, "iconFile": "res:/UI/Asset/mannequin/bottomouter/58954_Male_bottomOuter_PantsCorpBusinessM01_Types_PantsCorpBusinessM01_BrownMinmatarMil.png", "iconType": "png"}
3108	24730	{"_key": 24730, "iconFile": "res:/ui/texture/icons/modules/interdictionNullifier.png"}
3109	24731	{"_key": 24731, "iconFile": "res:/UI/Asset/mannequin/outer/59178_Male_outer_JacketMFBR01_Types_JacketMFBR01_MinmatarLiberation.png", "iconType": "png"}
3110	24732	{"_key": 24732, "iconFile": "res:/UI/Asset/mannequin/bottomouter/59179_Male_bottomOuter_PantsMilM01_Types_PantsMilM01_MinmatarLiberation.png", "iconType": "png"}
3111	24733	{"_key": 24733, "iconFile": "res:/UI/Asset/mannequin/outer/59180_Female_Outer_JacketFBR01_Types_JacketFBR01_MinmatarLiberation.png", "iconType": "png"}
3112	24734	{"_key": 24734, "iconFile": "res:/UI/Asset/mannequin/bottomouter/59181_Female_bottomOuter_PantsMilF01_Types_PantsMilF01_MinmatarLiberation.png", "iconType": "png"}
3113	24735	{"_key": 24735, "iconFile": "res:/UI/Asset/mannequin/outer/59185_Male_outer_JacketMFBR01_Types_JacketMFBR01_GallenteFederation.png", "iconType": "png"}
3114	24737	{"_key": 24737, "iconFile": "res:/UI/Asset/mannequin/bottomouter/59187_Male_bottomOuter_PantsMilM01_Types_PantsMilM01_GallenteFederation.png", "iconType": "png"}
3115	24738	{"_key": 24738, "iconFile": "res:/UI/Asset/mannequin/outer/59196_Female_Outer_JacketFBR01_Types_JacketFBR01_GallenteFederation.png", "iconType": "png"}
3116	24739	{"_key": 24739, "iconFile": "res:/UI/Asset/mannequin/bottomouter/59198_Female_bottomOuter_PantsMilF01_Types_PantsMilF01_GallenteFederation.png", "iconType": "png"}
3117	24740	{"_key": 24740, "iconFile": "res:/UI/Asset/mannequin/tattoo_head/59199_Male_Tattoo_Head_TattooElabM_LD_01_Types_TattooElabM_LD_01.png", "iconType": "png"}
3118	24741	{"_key": 24741, "iconFile": "res:/UI/Asset/mannequin/tattoo_head/59200_Female_Tattoo_Head_TattooElabM_LD_01_Types_TattooElabM_LD_01.png", "iconType": "png"}
3119	24742	{"_key": 24742, "iconFile": "res:/UI/Asset/mannequin/tattoo_head/59201_Male_Tattoo_Head_TattooElabM_LD_02_Types_TattooElabM_LD_02.png", "iconType": "png"}
3120	24743	{"_key": 24743, "iconFile": "res:/UI/Asset/mannequin/tattoo_head/59202_Female_Tattoo_Head_TattooElabM_LD_02_Types_TattooElabM_LD_02.png", "iconType": "png"}
3121	24744	{"_key": 24744, "iconFile": "res:/UI/Asset/mannequin/tattoo_head/59221_Male_Tattoo_Head_TattooElabM_LD_03_Types_TattooElabM_LD_03.png", "iconType": "png"}
3122	24745	{"_key": 24745, "iconFile": "res:/UI/Asset/mannequin/tattoo_head/59223_Female_Tattoo_Head_TattooElabM_LD_03_Types_TattooElabM_LD_03.png", "iconType": "png"}
3123	24746	{"_key": 24746, "iconFile": "res:/UI/Asset/mannequin/tattoo_head/59226_Male_Tattoo_Head_TattooElabM_LD_04_Types_TattooElabM_LD_04.png", "iconType": "png"}
3124	24747	{"_key": 24747, "iconFile": "res:/UI/Asset/mannequin/tattoo_head/59227_Female_Tattoo_Head_TattooElabM_LD_04_Types_TattooElabM_LD_04.png", "iconType": "png"}
3125	24748	{"_key": 24748, "iconFile": "res:/UI/Asset/mannequin/tattoo_head/59228_Male_Tattoo_Head_TattooElabM_LD_05_Types_TattooElabM_LD_05.png", "iconType": "png"}
3126	24749	{"_key": 24749, "iconFile": "res:/UI/Asset/mannequin/tattoo_head/59229_Female_Tattoo_Head_TattooElabM_LD_05_Types_TattooElabM_LD_05.png", "iconType": "png"}
3127	24750	{"_key": 24750, "iconFile": "res:/UI/Asset/mannequin/tattoo_head/59230_Male_Tattoo_Head_TattooElabM_LD_06_Types_TattooElabM_LD_06.png", "iconType": "png"}
3128	24751	{"_key": 24751, "iconFile": "res:/UI/Asset/mannequin/tattoo_head/59231_Female_Tattoo_Head_TattooElabM_LD_06_Types_TattooElabM_LD_06.png", "iconType": "png"}
3129	24752	{"_key": 24752, "iconFile": "res:/UI/Asset/mannequin/tattoo_head/59232_Male_Tattoo_Head_TattooElabM_LD_07_Types_TattooElabM_LD_07.png", "iconType": "png"}
3130	24753	{"_key": 24753, "iconFile": "res:/UI/Asset/mannequin/tattoo_head/59233_Female_Tattoo_Head_TattooElabM_LD_07_Types_TattooElabM_LD_07.png", "iconType": "png"}
3131	24754	{"_key": 24754, "iconFile": "res:/UI/Asset/mannequin/outer/59366_Male_outer_JacketMFBR01_Types_JacketMFBR01_AmarrFoundation.png", "iconType": "png"}
3132	24755	{"_key": 24755, "iconFile": "res:/UI/Asset/mannequin/outer/59367_Female_Outer_JacketFBR01_Types_JacketFBR01_AmarrFoundation.png", "iconType": "png"}
3133	24756	{"_key": 24756, "iconFile": "res:/UI/Asset/mannequin/bottomouter/59368_Male_bottomOuter_PantsMilM01_Types_PantsMilM01_AmarrFoundation.png", "iconType": "png"}
3134	24757	{"_key": 24757, "iconFile": "res:/UI/Asset/mannequin/bottomouter/59370_Female_bottomOuter_PantsMilF01_Types_PantsMilF01_AmarrFoundation.png", "iconType": "png"}
3135	24758	{"_key": 24758, "iconFile": "res:/UI/Asset/mannequin/outer/59405_Male_outer_JacketMFBR01_Types_JacketMFBR01_CaldariUnion.png", "iconType": "png"}
3136	24759	{"_key": 24759, "iconFile": "res:/UI/Asset/mannequin/bottomouter/59406_Male_bottomOuter_PantsMilM01_Types_PantsMilM01_CaldariUnion.png", "iconType": "png"}
3137	24760	{"_key": 24760, "iconFile": "res:/UI/Asset/mannequin/outer/59407_Female_Outer_JacketFBR01_Types_JacketFBR01_CaldariUnion.png", "iconType": "png"}
3138	24761	{"_key": 24761, "iconFile": "res:/UI/Asset/mannequin/bottomouter/59408_Female_bottomOuter_PantsMilF01_Types_PantsMilF01_CaldariUnion.png", "iconType": "png"}
3139	24770	{"_key": 24770, "iconFile": "res:/UI/Texture/Icons/44_32_23.png", "iconType": "png"}
3140	24771	{"_key": 24771, "iconFile": "res:/UI/Texture/Icons/44_32_40.png", "iconType": "png"}
3141	24773	{"_key": 24773, "iconFile": "res:/UI/Texture/Icons/44_32_21.png", "iconType": "png"}
3142	24774	{"_key": 24774, "iconFile": "res:/UI/Texture/Icons/44_32_17.png", "iconType": "png"}
3143	24776	{"_key": 24776, "iconFile": "res:/UI/Texture/Icons/Inventory/ESS_reserveKey_64_NE.png"}
3144	24777	{"_key": 24777, "iconFile": "res:/UI/Texture/Icons/Inventory/ESS_reserveKey_64_NE_large.png"}
3145	24778	{"_key": 24778, "iconFile": "res:/UI/Texture/Icons/Inventory/ESS_reserveKey_64_NW.png"}
3146	24779	{"_key": 24779, "iconFile": "res:/UI/Texture/Icons/Inventory/ESS_reserveKey_64_NW_large.png"}
3147	24780	{"_key": 24780, "iconFile": "res:/UI/Texture/Icons/Inventory/ESS_reserveKey_64_SE.png"}
3148	24781	{"_key": 24781, "iconFile": "res:/UI/Texture/Icons/Inventory/ESS_reserveKey_64_SE_large.png"}
3149	24782	{"_key": 24782, "iconFile": "res:/UI/Texture/Icons/Inventory/ESS_reserveKey_64_SW.png"}
3150	24783	{"_key": 24783, "iconFile": "res:/UI/Texture/Icons/Inventory/ESS_reserveKey_64_SW_large.png"}
3151	24785	{"_key": 24785, "iconFile": "res:/ui/texture/icons/items.png"}
3152	24786	{"_key": 24786, "iconFile": "res:/ui/texture/icons/itemHangar.png"}
3153	24787	{"_key": 24787, "iconFile": "res:/ui/texture/icons/theAgency.png"}
3154	24788	{"_key": 24788, "iconFile": "res:/ui/texture/icons/[AIR] Online Button.png"}
3155	24789	{"_key": 24789, "iconFile": "res:/ui/texture/icons/applySkillpoints.png"}
3156	24790	{"_key": 24790, "iconFile": "res:/ui/texture/icons/filterIconLowSlot.png"}
3157	24791	{"_key": 24791, "iconFile": "res:/ui/texture/icons/[AIR] Neocom Menu Button.png"}
3158	24792	{"_key": 24792, "iconFile": "res:/UI/Texture/Icons/Inventory/IconAccelerator_FrekiGacha_I.png", "iconType": "png"}
3159	24793	{"_key": 24793, "iconFile": "res:/UI/Texture/Icons/Inventory/IconAccelerator_FrekiGacha_II.png", "iconType": "png"}
3160	24794	{"_key": 24794, "iconFile": "res:/UI/Texture/Icons/Inventory/IconAccelerator_FrekiGacha_III.png", "iconType": "png"}
3161	24795	{"_key": 24795, "iconFile": "res:/UI/Texture/Icons/Inventory/IconAccelerator_FrekiGacha_IV.png", "iconType": "png"}
3162	24796	{"_key": 24796, "iconFile": "res:/UI/Texture/Icons/Inventory/IconLicense_FrekiGacha_01.png", "iconType": "png"}
3163	24797	{"_key": 24797, "iconFile": "res:/UI/Texture/Icons/Inventory/IconLicense_FrekiGacha_02.png", "iconType": "png"}
3164	24798	{"_key": 24798, "iconFile": "res:/UI/Texture/Icons/Inventory/IconLicense_FrekiGacha_03.png", "iconType": "png"}
3165	24799	{"_key": 24799, "iconFile": "res:/UI/Texture/Icons/Inventory/IconZXJ_FrekiGacha_MC108.png", "iconType": "png"}
3166	24800	{"_key": 24800, "iconFile": "res:/UI/Texture/Icons/Inventory/IconZXJ_FrekiGacha_MC308.png", "iconType": "png"}
3167	24801	{"_key": 24801, "iconFile": "res:/UI/Texture/Icons/Inventory/IconZXJ_FrekiGacha_MC708.png", "iconType": "png"}
3168	24802	{"_key": 24802, "iconFile": "res:/UI/Texture/Icons/Inventory/IconZXJ_FrekiGacha_RP108.png", "iconType": "png"}
3169	24803	{"_key": 24803, "iconFile": "res:/UI/Texture/Icons/Inventory/IconZXJ_FrekiGacha_RP308.png", "iconType": "png"}
3170	24804	{"_key": 24804, "iconFile": "res:/UI/Texture/Icons/Inventory/IconZXJ_FrekiGacha_RP708.png", "iconType": "png"}
3171	24805	{"_key": 24805, "iconFile": "res:/UI/Texture/Icons/Inventory/IconCrate_FrekiGacha_01.png", "iconType": "png"}
3172	24806	{"_key": 24806, "iconFile": "res:/UI/Texture/Icons/Inventory/IconCrate_FrekiGacha_02.png", "iconType": "png"}
3173	24807	{"_key": 24807, "iconFile": "res:/UI/Texture/Icons/Inventory/IconCrate_FrekiGacha_03.png", "iconType": "png"}
3174	24808	{"_key": 24808, "iconFile": "res:/UI/Texture/Icons/Inventory/IconCrate_FrekiGacha_04.png", "iconType": "png"}
3175	24809	{"_key": 24809, "iconFile": "res:/UI/Texture/Icons/StatusEffects/Linked_Status_Icon.png"}
3176	24810	{"_key": 24810, "iconFile": "res:/ui/texture/icons/[AIR] Docking.png"}
3177	24811	{"_key": 24811, "iconFile": "res:/ui/texture/icons/[AIR] Jump.png"}
3178	24812	{"_key": 24812, "iconFile": "res:/ui/texture/icons/[AIR] Stargate.png"}
3179	24813	{"_key": 24813, "iconFile": "res:/ui/texture/shared/brackets/Homestation_Icon.png"}
3180	24815	{"_key": 24815, "iconFile": "res:/UI/Texture/Icons/Inventory/Icon_ShipCertification_01.png", "iconType": "png"}
3181	24816	{"_key": 24816, "iconFile": "res:/UI/Texture/Icons/Inventory/Icon_ShipCertification_02.png", "iconType": "png"}
3182	24817	{"_key": 24817, "iconFile": "res:/UI/Texture/Icons/Inventory/Icon_ShipCertification_03.png", "iconType": "png"}
3183	24818	{"_key": 24818, "iconFile": "res:/UI/Texture/Icons/Inventory/Icon_ShipInsurance.png", "iconType": "png"}
3184	24819	{"_key": 24819, "iconFile": "res:/UI/Texture/Icons/Inventory/IconCrate_ShipSkin03_64.png", "iconType": "png"}
3185	24820	{"_key": 24820, "iconFile": "res:/UI/Texture/Icons/Inventory/IconCrate_ShipSkin04_64.png", "iconType": "png"}
3186	24821	{"_key": 24821, "iconFile": "res:/UI/Texture/Icons/Inventory/IconCrate_ShipSkin05_64.png", "iconType": "png"}
3187	24823	{"_key": 24823, "iconFile": "res:/ui/texture/icons/[AIR] Jump Button.png"}
3188	24824	{"_key": 24824, "iconFile": "res:/UI/Texture/Icons/Inventory/IconAccelerator_Orange.png", "iconType": "png"}
3189	24826	{"_key": 24826, "iconFile": "res:/ui/texture/icons/Inventory/[AIR] Small Skill Injector.png"}
3190	24827	{"_key": 24827, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/60160_Male_Accessories_Glasses_EyeImp01_Types_EyeImpM01_Right_Ep.png", "iconType": "png"}
3191	24828	{"_key": 24828, "iconFile": "res:/UI/Asset/mannequin/bottomouter/60161_Male_bottomOuter_PantsEngM01_Types_PantsEngM01_Ep.png", "iconType": "png"}
3192	24829	{"_key": 24829, "iconFile": "res:/UI/Asset/mannequin/feet/60162_Male_Feet_ShoesEngM01_Types_ShoesEngM01_Ep.png", "iconType": "png"}
3193	24830	{"_key": 24830, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/60163_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V7_Ep.png", "iconType": "png"}
3194	24831	{"_key": 24831, "iconFile": "res:/UI/Asset/mannequin/makeup_bodyaugmentations/60164_Male_Makeup_BodyAugmentations_BodyAugmentation_M01_Types_BodyAugmentationM01_Ep.png", "iconType": "png"}
3195	24832	{"_key": 24832, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/60165_Male_Accessories_Glasses_Monocle_01_Types_MonocleM01_Right_Ep.png", "iconType": "png"}
3196	24833	{"_key": 24833, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/60166_Female_Accessories_Glasses_EyeImp01_Types_EyeImpF01_Right_Ep.png", "iconType": "png"}
3197	24834	{"_key": 24834, "iconFile": "res:/UI/Asset/mannequin/bottomouter/60167_Female_bottomOuter_PantsEngF01_Types_PantsEngF01_Ep.png", "iconType": "png"}
3198	24835	{"_key": 24835, "iconFile": "res:/UI/Asset/mannequin/feet/60168_Female_Feet_ShoesEngF01_Types_ShoesEngF01_Ep.png", "iconType": "png"}
3199	24836	{"_key": 24836, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/60169_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_Ep.png", "iconType": "png"}
3200	24837	{"_key": 24837, "iconFile": "res:/UI/Asset/mannequin/makeup_bodyaugmentations/60170_Female_Makeup_BodyAugmentations_BodyAugmentation_F01_Types_BodyAugmentationF01_Ep.png", "iconType": "png"}
3201	24838	{"_key": 24838, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/60171_Female_Accessories_Glasses_Monocle_01_Types_MonocleF01_Right_EP.png", "iconType": "png"}
3202	24839	{"_key": 24839, "iconFile": "res:/UI/Asset/mannequin/outer/60175_Male_outer_JacketMilM02_Types_JacketMilM02_AIR.png", "iconType": "png"}
3203	24840	{"_key": 24840, "iconFile": "res:/UI/Asset/mannequin/outer/60176_Female_Outer_JacketSLF_01_Types_JacketSLF_01_air.png", "iconType": "png"}
3204	24841	{"_key": 24841, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_CSYQ_04a.png", "iconType": "png"}
3205	24842	{"_key": 24842, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_CSYQ_05a.png", "iconType": "png"}
3206	24843	{"_key": 24843, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_CSYQ_02a.png", "iconType": "png"}
3207	24844	{"_key": 24844, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_CSYQ_03a.png", "iconType": "png"}
3208	24845	{"_key": 24845, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_CSYQ_01a.png", "iconType": "png"}
3209	24846	{"_key": 24846, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_CSYQ_04b.png", "iconType": "png"}
3210	24847	{"_key": 24847, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_CSYQ_05b.png", "iconType": "png"}
3211	24848	{"_key": 24848, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_CSYQ_02b.png", "iconType": "png"}
3212	24849	{"_key": 24849, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_CSYQ_03b.png", "iconType": "png"}
3213	24850	{"_key": 24850, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_CSYQ_01b.png", "iconType": "png"}
3214	24851	{"_key": 24851, "iconFile": "res:/UI/Texture/Icons/Inventory/Accelerator_CSYQ_I.png", "iconType": "png"}
3215	24852	{"_key": 24852, "iconFile": "res:/UI/Texture/Icons/Inventory/Accelerator_CSYQ_II.png", "iconType": "png"}
3216	24853	{"_key": 24853, "iconFile": "res:/UI/Texture/Icons/Inventory/Accelerator_CSYQ_III.png", "iconType": "png"}
3217	24854	{"_key": 24854, "iconFile": "res:/UI/Texture/Icons/Inventory/Accelerator_CSYQ_IV.png", "iconType": "png"}
3218	24855	{"_key": 24855, "iconFile": "res:/UI/Texture/Icons/Inventory/Crate_ShipSkin_Sakura.png", "iconType": "png"}
3219	24856	{"_key": 24856, "iconFile": "res:/UI/Texture/Icons/Inventory/Crate_Vangel.png", "iconType": "png"}
3220	24857	{"_key": 24857, "iconFile": "res:/ui/texture/icons/[AIR] PlusIcon.png"}
3221	24858	{"_key": 24858, "iconFile": "res:/UI/Texture/Icons/Inventory/Icon_BattleshipCer_Amarr.png", "iconType": "png"}
3222	24859	{"_key": 24859, "iconFile": "res:/UI/Texture/Icons/Inventory/Icon_BattleshipCer_Caldari.png", "iconType": "png"}
3223	24860	{"_key": 24860, "iconFile": "res:/UI/Texture/Icons/Inventory/Icon_BattleshipCer_Gallente.png", "iconType": "png"}
3224	24861	{"_key": 24861, "iconFile": "res:/UI/Texture/Icons/Inventory/Icon_BattleshipCer_Minmatar.png", "iconType": "png"}
3225	24862	{"_key": 24862, "iconFile": "res:/UI/Texture/Icons/Inventory/Icon_BattleshipCer_AdvancedWeaponUpgrade.png", "iconType": "png"}
3226	24872	{"_key": 24872, "iconFile": "res:/UI/Asset/mannequin/bottomouter/60432_Male_bottomOuter_PantsPrtm01_Types_PantsPrtm01_redblack.png", "iconType": "png"}
3227	24874	{"_key": 24874, "iconFile": "res:/UI/Asset/mannequin/bottomouter/60434_Female_bottomOuter_PantsPrtF01_Types_PantsPrtF01_redblack.png", "iconType": "png"}
3228	24875	{"_key": 24875, "iconFile": "res:/UI/Asset/mannequin/topmiddle/60435_Male_topMiddle_TshirtM01_Types_TshirtM01_BR_CH.png", "iconType": "png"}
3229	24876	{"_key": 24876, "iconFile": "res:/UI/Asset/mannequin/topmiddle/60436_Female_TopMiddle_TshirtF01_Types_TshirtF01_BR_CH.png", "iconType": "png"}
3230	24890	{"_key": 24890, "iconFile": "res:/UI/Texture/Icons/Inventory/Crate_ColdIron_64.png", "iconType": "png"}
3231	24891	{"_key": 24891, "iconFile": "res:/UI/Texture/Icons/Inventory/Icon_PremumInsurance.png", "iconType": "png"}
3232	24892	{"_key": 24892, "iconFile": "res:/ui/texture/icons/Modules/mutaDroneDamage.png"}
3233	24893	{"_key": 24893, "iconFile": "res:/ui/texture/icons/Modules/mutaDroneRange.png"}
3234	24894	{"_key": 24894, "iconFile": "res:/ui/texture/icons/Modules/mutaDroneSpeed.png"}
3235	24895	{"_key": 24895, "iconFile": "res:/ui/texture/icons/Modules/mutaDroneTank.png"}
3236	24896	{"_key": 24896, "iconFile": "res:/UI/Texture/Icons/Inventory/Accelerator_NationalDay_I.png", "iconType": "png"}
3237	24897	{"_key": 24897, "iconFile": "res:/UI/Texture/Icons/Inventory/Accelerator_NationalDay_II.png", "iconType": "png"}
3238	24898	{"_key": 24898, "iconFile": "res:/UI/Texture/Icons/Inventory/Accelerator_NationalDay_III.png", "iconType": "png"}
3239	24899	{"_key": 24899, "iconFile": "res:/UI/Texture/Icons/Inventory/Accelerator_NationalDay_IV.png", "iconType": "png"}
3240	24900	{"_key": 24900, "iconFile": "res:/UI/Texture/Icons/Inventory/Crate_BlueTiger.png", "iconType": "png"}
3241	24901	{"_key": 24901, "iconFile": "res:/UI/Texture/Icons/Inventory/Crate_Rabisu.png", "iconType": "png"}
3242	24903	{"_key": 24903, "iconFile": "res:/UI/Texture/Icons/Inventory/BattlePass_Icon64x64.png", "iconType": "png"}
3243	24904	{"_key": 24904, "iconFile": "res:/ui/texture/icons/quafe_green.png"}
3244	24905	{"_key": 24905, "iconFile": "res:/ui/texture/icons/Modules/mutaDroneModules.png"}
3245	24908	{"_key": 24908, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/60639_Male_Accessories_Glasses_Goggles_01_Types_goggles_01_min.png", "iconType": "png"}
3246	24914	{"_key": 24914, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/60645_Female_Accessories_Glasses_Goggles_01_Types_goggles_01_min.png", "iconType": "png"}
3247	24916	{"_key": 24916, "iconFile": "res:/UI/Asset/mannequin/outer/60647_Male_outer_ExplorationSuit_M01_Types_ExplorationSuit_M01_Min.png", "iconType": "png"}
3248	24924	{"_key": 24924, "iconFile": "res:/UI/Asset/mannequin/outer/60655_Female_Outer_ExplorationSuit_F01_Types_ExplorationSuit_F01_Min.png", "iconType": "png"}
3249	24926	{"_key": 24926, "iconFile": "res:/UI/Texture/Icons/StatusEffects/Linked_To_Beaon_Icon.png"}
3250	24927	{"_key": 24927, "iconFile": "res:/UI/Texture/Icons/Inventory/AbyssalRandomFilament_L5Active_50.png", "iconType": "png"}
3251	24928	{"_key": 24928, "iconFile": "res:/UI/Texture/Icons/Inventory/AbyssalRandomFilament_L5Active_100.png", "iconType": "png"}
3252	24929	{"_key": 24929, "iconFile": "res:/UI/Texture/Icons/Inventory/AbyssalRandomFilament_L5_50.png", "iconType": "png"}
3253	24930	{"_key": 24930, "iconFile": "res:/UI/Texture/Icons/Inventory/AbyssalRandomFilament_L5_100.png", "iconType": "png"}
3254	24931	{"_key": 24931, "iconFile": "res:/UI/Texture/Icons/Inventory/Crate_Pattern02_Yellow.png", "iconType": "png"}
3255	24932	{"_key": 24932, "iconFile": "res:/UI/Texture/Icons/Inventory/Crate_ZunXiang.png", "iconType": "png"}
3256	24968	{"_key": 24968, "iconFile": "res:/UI/Texture/Icons/Ammo/a_1_blue.png"}
3257	24969	{"_key": 24969, "iconFile": "res:/UI/Texture/Icons/Ammo/a_1_green.png"}
3258	24970	{"_key": 24970, "iconFile": "res:/UI/Texture/Icons/Ammo/a_1_red.png"}
3259	24971	{"_key": 24971, "iconFile": "res:/UI/Texture/Icons/Ammo/a_1_purple.png"}
3260	24972	{"_key": 24972, "iconFile": "res:/UI/Texture/Icons/Ammo/a_1_orange.png"}
3261	24973	{"_key": 24973, "iconFile": "res:/UI/Texture/Icons/Ammo/a_1_white.png"}
3262	24974	{"_key": 24974, "iconFile": "res:/UI/Texture/Icons/Ammo/a_2_blue.png"}
3263	24975	{"_key": 24975, "iconFile": "res:/UI/Texture/Icons/Ammo/a_2_green.png"}
3264	24976	{"_key": 24976, "iconFile": "res:/UI/Texture/Icons/Ammo/a_2_red.png"}
3265	24977	{"_key": 24977, "iconFile": "res:/UI/Texture/Icons/Ammo/a_2_purple.png"}
3266	24978	{"_key": 24978, "iconFile": "res:/UI/Texture/Icons/Ammo/a_2_orange.png"}
3267	24979	{"_key": 24979, "iconFile": "res:/UI/Texture/Icons/Ammo/a_2_white.png"}
3268	24980	{"_key": 24980, "iconFile": "res:/UI/Texture/Icons/Ammo/b_1_blue.png"}
3269	24981	{"_key": 24981, "iconFile": "res:/UI/Texture/Icons/Ammo/b_1_green.png"}
3270	24982	{"_key": 24982, "iconFile": "res:/UI/Texture/Icons/Ammo/b_1_red.png"}
3271	24983	{"_key": 24983, "iconFile": "res:/UI/Texture/Icons/Ammo/b_1_purple.png"}
3272	24984	{"_key": 24984, "iconFile": "res:/UI/Texture/Icons/Ammo/b_1_orange.png"}
3273	24985	{"_key": 24985, "iconFile": "res:/UI/Texture/Icons/Ammo/b_1_white.png"}
3274	24986	{"_key": 24986, "iconFile": "res:/UI/Texture/Icons/Ammo/b_2_blue.png"}
3275	24987	{"_key": 24987, "iconFile": "res:/UI/Texture/Icons/Ammo/b_2_green.png"}
3276	24988	{"_key": 24988, "iconFile": "res:/UI/Texture/Icons/Ammo/b_2_red.png"}
3277	24989	{"_key": 24989, "iconFile": "res:/UI/Texture/Icons/Ammo/b_2_purple.png"}
3278	24990	{"_key": 24990, "iconFile": "res:/UI/Texture/Icons/Ammo/b_2_orange.png"}
3279	24991	{"_key": 24991, "iconFile": "res:/UI/Texture/Icons/Ammo/b_2_white.png"}
3280	24992	{"_key": 24992, "iconFile": "res:/UI/Texture/Icons/Ammo/c_1_blue.png"}
3281	24993	{"_key": 24993, "iconFile": "res:/UI/Texture/Icons/Ammo/c_1_green.png"}
3282	24994	{"_key": 24994, "iconFile": "res:/UI/Texture/Icons/Ammo/c_1_red.png"}
3283	24995	{"_key": 24995, "iconFile": "res:/UI/Texture/Icons/Ammo/c_1_purple.png"}
3284	24996	{"_key": 24996, "iconFile": "res:/UI/Texture/Icons/Ammo/c_1_orange.png"}
3285	24997	{"_key": 24997, "iconFile": "res:/UI/Texture/Icons/Ammo/c_1_white.png"}
3286	24998	{"_key": 24998, "iconFile": "res:/UI/Texture/Icons/Ammo/c_2_blue.png"}
3287	24999	{"_key": 24999, "iconFile": "res:/UI/Texture/Icons/Ammo/c_2_green.png"}
3288	25000	{"_key": 25000, "iconFile": "res:/UI/Texture/Icons/Ammo/c_2_red.png"}
3289	25001	{"_key": 25001, "iconFile": "res:/UI/Texture/Icons/Ammo/c_2_purple.png"}
3290	25002	{"_key": 25002, "iconFile": "res:/UI/Texture/Icons/Ammo/c_2_orange.png"}
3291	25003	{"_key": 25003, "iconFile": "res:/UI/Texture/Icons/Ammo/c_2_white.png"}
3292	25005	{"_key": 25005, "iconFile": "res:/ui/texture/icons/60284_64.png"}
3293	25006	{"_key": 25006, "iconFile": "res:/ui/texture/icons/60285_64.png"}
3294	25007	{"_key": 25007, "iconFile": "res:/ui/texture/icons/60286_64.png"}
3295	25008	{"_key": 25008, "iconFile": "res:/ui/texture/icons/60827_64.png"}
3296	25009	{"_key": 25009, "iconFile": "res:/ui/texture/icons/60828_64.png"}
3297	25010	{"_key": 25010, "iconFile": "res:/ui/texture/icons/60830_64.png"}
3298	25011	{"_key": 25011, "iconFile": "res:/ui/texture/icons/60833_64.png"}
3299	25012	{"_key": 25012, "iconFile": "res:/ui/texture/icons/60834_64.png"}
3300	25013	{"_key": 25013, "iconFile": "res:/ui/texture/icons/60835_64.png"}
3301	25014	{"_key": 25014, "iconFile": "res:/ui/texture/icons/60836_64.png"}
3302	25015	{"_key": 25015, "iconFile": "res:/ui/texture/icons/60842_64.png"}
3303	25016	{"_key": 25016, "iconFile": "res:/ui/texture/icons/60843_64.png"}
3304	25017	{"_key": 25017, "iconFile": "res:/ui/texture/icons/60844_64.png"}
3305	25018	{"_key": 25018, "iconFile": "res:/UI/Texture/Icons/Inventory/Crate_Guristas01.png", "iconType": "png"}
3306	25019	{"_key": 25019, "iconFile": "res:/UI/Texture/Icons/Inventory/Crate_Guristas02.png", "iconType": "png"}
3307	25020	{"_key": 25020, "iconFile": "res:/UI/Texture/Icons/Inventory/BattlePass2111_Icon64x64.png", "iconType": "png"}
3308	25021	{"_key": 25021, "iconFile": "res:/UI/Texture/Icons/Ammo/a_1_blue_moon.png"}
3309	25022	{"_key": 25022, "iconFile": "res:/UI/Texture/Icons/Ammo/b_1_blue_moon.png"}
3310	25023	{"_key": 25023, "iconFile": "res:/UI/Texture/Icons/Ammo/c_1_blue_moon.png"}
3311	25024	{"_key": 25024, "iconFile": "res:/UI/Texture/Icons/Ammo/a_2_blue_moon.png"}
3312	25025	{"_key": 25025, "iconFile": "res:/UI/Texture/Icons/Ammo/b_2_blue_moon.png"}
3313	25026	{"_key": 25026, "iconFile": "res:/UI/Texture/Icons/Ammo/c_2_blue_moon.png"}
3314	25027	{"_key": 25027, "iconFile": "res:/UI/Texture/Icons/Ammo/a_1_white_moon.png"}
3315	25028	{"_key": 25028, "iconFile": "res:/UI/Texture/Icons/Ammo/b_1_white_moon.png"}
3316	25029	{"_key": 25029, "iconFile": "res:/UI/Texture/Icons/Ammo/c_1_white_moon.png"}
3317	25030	{"_key": 25030, "iconFile": "res:/UI/Texture/Icons/Ammo/a_2_white_moon.png"}
3318	25031	{"_key": 25031, "iconFile": "res:/UI/Texture/Icons/Ammo/b_2_white_moon.png"}
3319	25032	{"_key": 25032, "iconFile": "res:/UI/Texture/Icons/Ammo/c_2_white_moon.png"}
3320	25033	{"_key": 25033, "iconFile": "res:/UI/Texture/Icons/Ammo/a_1_purple_moon.png"}
3321	25034	{"_key": 25034, "iconFile": "res:/UI/Texture/Icons/Ammo/b_1_purple_moon.png"}
3322	25035	{"_key": 25035, "iconFile": "res:/UI/Texture/Icons/Ammo/c_1_purple_moon.png"}
3323	25036	{"_key": 25036, "iconFile": "res:/UI/Texture/Icons/Ammo/a_2_purple_moon.png"}
3324	25037	{"_key": 25037, "iconFile": "res:/UI/Texture/Icons/Ammo/b_2_purple_moon.png"}
3325	25038	{"_key": 25038, "iconFile": "res:/UI/Texture/Icons/Ammo/c_2_purple_moon.png"}
3326	25039	{"_key": 25039, "iconFile": "res:/UI/Texture/Icons/Ammo/a_1_red_moon.png"}
3327	25040	{"_key": 25040, "iconFile": "res:/UI/Texture/Icons/Ammo/b_1_red_moon.png"}
3328	25041	{"_key": 25041, "iconFile": "res:/UI/Texture/Icons/Ammo/c_1_red_moon.png"}
3329	25042	{"_key": 25042, "iconFile": "res:/UI/Texture/Icons/Ammo/a_2_red_moon.png"}
3330	25043	{"_key": 25043, "iconFile": "res:/UI/Texture/Icons/Ammo/b_2_red_moon.png"}
3331	25044	{"_key": 25044, "iconFile": "res:/UI/Texture/Icons/Ammo/c_2_red_moon.png"}
3332	25045	{"_key": 25045, "iconFile": "res:/UI/Texture/Icons/Ammo/a_1_orange_moon.png"}
3333	25046	{"_key": 25046, "iconFile": "res:/UI/Texture/Icons/Ammo/b_1_orange_moon.png"}
3334	25047	{"_key": 25047, "iconFile": "res:/UI/Texture/Icons/Ammo/c_1_orange_moon.png"}
3335	25048	{"_key": 25048, "iconFile": "res:/UI/Texture/Icons/Ammo/a_2_orange_moon.png"}
3336	25049	{"_key": 25049, "iconFile": "res:/UI/Texture/Icons/Ammo/b_2_orange_moon.png"}
3337	25050	{"_key": 25050, "iconFile": "res:/UI/Texture/Icons/Ammo/c_2_orange_moon.png"}
3338	25051	{"_key": 25051, "iconFile": "res:/UI/Asset/mannequin/topmiddle/61532_Female_TopMiddle_ShirtQF01_Types_shirtqf01_drw.png", "iconType": "png"}
3339	25052	{"_key": 25052, "iconFile": "res:/UI/Asset/mannequin/topmiddle/61533_Male_topMiddle_ShirtQM01_Types_shirtqm01_drw.png", "iconType": "png"}
3340	25054	{"_key": 25054, "iconFile": "res:/UI/Asset/mannequin/outer/61535_Female_Outer_ScarfF01_Types_ScarfF01_drw.png", "iconType": "png"}
3341	25055	{"_key": 25055, "iconFile": "res:/UI/Asset/mannequin/outer/61536_Male_outer_ScarfM01_Types_ScarfM01_drw.png", "iconType": "png"}
3342	25060	{"_key": 25060, "iconFile": "res:/ui/texture/icons/5_64_12.png"}
3343	25061	{"_key": 25061, "iconFile": "res:/UI/Texture/Icons/Inventory/solar_flare_certificate_D1.png", "iconType": "png"}
3344	25062	{"_key": 25062, "iconFile": "res:/UI/Texture/Icons/Inventory/solar_flare_certificate_D2.png", "iconType": "png"}
3345	25063	{"_key": 25063, "iconFile": "res:/UI/Texture/Icons/Inventory/solar_flare_certificate_D3.png", "iconType": "png"}
3346	25064	{"_key": 25064, "iconFile": "res:/UI/Texture/Icons/Inventory/solar_flare_certificate_D4.png", "iconType": "png"}
3347	25065	{"_key": 25065, "iconFile": "res:/UI/Texture/Icons/Inventory/solar_flare_certificate_D5.png", "iconType": "png"}
3348	25066	{"_key": 25066, "iconFile": "res:/UI/Texture/Icons/Inventory/solar_flare_certificate_D6.png", "iconType": "png"}
3349	25067	{"_key": 25067, "iconFile": "res:/UI/Texture/Icons/Inventory/solar_flare_certificate_D7.png", "iconType": "png"}
3350	25068	{"_key": 25068, "iconFile": "res:/UI/Texture/Icons/Inventory/WMFilamentSmall.png", "iconType": "png"}
3351	25069	{"_key": 25069, "iconFile": "res:/UI/Texture/Icons/Inventory/WMFilamentLarge.png", "iconType": "png"}
3352	25070	{"_key": 25070, "iconFile": "res:/ui/texture/icons/solarflare.png"}
3353	25071	{"_key": 25071, "iconFile": "res:/ui/texture/icons/SFmaterial/61773_64.png"}
3354	25072	{"_key": 25072, "iconFile": "res:/ui/texture/icons/SFmaterial/61774_64.png"}
3355	25073	{"_key": 25073, "iconFile": "res:/ui/texture/icons/SFmaterial/61775_64.png"}
3356	25074	{"_key": 25074, "iconFile": "res:/UI/Texture/Icons/Inventory/Crate_XJJY.png", "iconType": "png"}
3357	25076	{"_key": 25076, "iconFile": "res:/UI/Asset/mannequin/outer/61848_Female_Outer_OutfitDW_F01_Types_OutfitDW_F01.png", "iconType": "png"}
3358	25077	{"_key": 25077, "iconFile": "res:/ui/texture/icons/SFmaterial/Frame 125.png"}
3359	25079	{"_key": 25079, "iconFile": "res:/ui/texture/icons/SFmaterial/3178_64.png"}
3360	25080	{"_key": 25080, "iconFile": "res:/UI/Texture/Icons/Inventory/dg_02.png", "iconType": "png"}
3361	25081	{"_key": 25081, "iconFile": "res:/UI/Texture/Icons/Inventory/dg_01.png", "iconType": "png"}
3362	25082	{"_key": 25082, "iconFile": "res:/UI/Texture/Icons/Inventory/BattlePass_Icon_10.png", "iconType": "png"}
3363	25083	{"_key": 25083, "iconFile": "res:/UI/Texture/Icons/Inventory/BattlePass_Icon_80.png", "iconType": "png"}
3364	25084	{"_key": 25084, "iconFile": "res:/UI/Texture/Icons/Inventory/BattlePass_Icon_800.png", "iconType": "png"}
3365	25090	{"_key": 25090, "iconFile": "res:/UI/Asset/mannequin/outer/61949_Male_outer_OutfitDW_M01_Types_OutfitDW_M01.png", "iconType": "png"}
3366	25091	{"_key": 25091, "iconFile": "res:/ui/texture/icons/Inventory/AIR-NPE/air_blackbox.png"}
3367	25092	{"_key": 25092, "iconFile": "res:/ui/texture/icons/Inventory/AIR-NPE/air_asteroid.png"}
3368	25093	{"_key": 25093, "iconFile": "res:/ui/texture/icons/SFmaterial/10631_64.png"}
3369	25094	{"_key": 25094, "iconFile": "res:/ui/texture/icons/SFmaterial/61952.png"}
3370	25095	{"_key": 25095, "iconFile": "res:/ui/texture/icons/SFmaterial/61953.png"}
3371	25096	{"_key": 25096, "iconFile": "res:/ui/texture/icons/SFmaterial/61954.png"}
3372	25097	{"_key": 25097, "iconFile": "res:/ui/texture/icons/SFmaterial/3074_64.png"}
3373	25100	{"_key": 25100, "iconFile": "res:/ui/texture/icons/SFmaterial/2404_64.png"}
3374	25101	{"_key": 25101, "iconFile": "res:/ui/texture/icons/SFmaterial/3041_64.png"}
3375	25102	{"_key": 25102, "iconFile": "res:/ui/texture/icons/SFmaterial/3033_64.png"}
3376	25103	{"_key": 25103, "iconFile": "res:/ui/texture/icons/SFmaterial/2889_64.png"}
3377	25104	{"_key": 25104, "iconFile": "res:/ui/texture/icons/SFmaterial/2977_64.png"}
3378	25105	{"_key": 25105, "iconFile": "res:/ui/texture/icons/SFmaterial/3146_64.png"}
3379	25106	{"_key": 25106, "iconFile": "res:/ui/texture/icons/SFmaterial/3082_64.png"}
3380	25107	{"_key": 25107, "iconFile": "res:/ui/texture/icons/SFmaterial/25715_64.png"}
3381	25108	{"_key": 25108, "iconFile": "res:/ui/texture/icons/SFmaterial/2410_64.png"}
3382	25109	{"_key": 25109, "iconFile": "res:/ui/texture/icons/SFmaterial/3520_64.png"}
3383	25110	{"_key": 25110, "iconFile": "res:/ui/texture/icons/SFmaterial/3025_64.png"}
3384	25111	{"_key": 25111, "iconFile": "res:/ui/texture/icons/SFmaterial/2913_64.png"}
3385	25112	{"_key": 25112, "iconFile": "res:/ui/texture/icons/SFmaterial/2969_64.png"}
3386	25117	{"_key": 25117, "iconFile": "res:/ui/texture/icons/1337_64_11.png"}
3387	25120	{"_key": 25120, "iconFile": "res:/ui/texture/WindowIcons/wallet.png"}
3388	25122	{"_key": 25122, "iconFile": "res:/UI/Texture/Icons/Inventory/ZXJ_Christmas2021.png", "iconType": "png"}
3389	25123	{"_key": 25123, "iconFile": "res:/UI/Texture/Icons/Inventory/ssy.png", "iconType": "png"}
3390	25124	{"_key": 25124, "iconFile": "res:/UI/Texture/Icons/Inventory/Crate_Newyear2022.png", "iconType": "png"}
3391	25125	{"_key": 25125, "iconFile": "res:/UI/Texture/Icons/Inventory/Crate_Hydra.png", "iconType": "png"}
3392	25126	{"_key": 25126, "iconFile": "res:/ui/texture/icons/SFmaterial/3178_64 - Copy.png"}
3393	25127	{"_key": 25127, "iconFile": "res:/ui/texture/classes/Fitting/warningSkills.png"}
3394	25128	{"_key": 25128, "iconFile": "res:/UI/Texture/Icons/Inventory/DWTrinket01.png", "iconType": "png"}
3395	25129	{"_key": 25129, "iconFile": "res:/UI/Texture/Icons/Inventory/DWTrinket02.png", "iconType": "png"}
3396	25130	{"_key": 25130, "iconFile": "res:/UI/Texture/Icons/Inventory/DWTrinket03.png", "iconType": "png"}
3397	25131	{"_key": 25131, "iconFile": "res:/UI/Texture/Icons/Inventory/DWTrinket04.png", "iconType": "png"}
3398	25132	{"_key": 25132, "iconFile": "res:/UI/Texture/Icons/Inventory/DWTrinket05.png", "iconType": "png"}
3399	25133	{"_key": 25133, "iconFile": "res:/UI/Texture/Icons/Inventory/DWTrinket06.png", "iconType": "png"}
3400	25134	{"_key": 25134, "iconFile": "res:/UI/Texture/Icons/Inventory/DWTrinket07.png", "iconType": "png"}
3401	25135	{"_key": 25135, "iconFile": "res:/UI/Texture/Icons/Inventory/DWTrinket08.png", "iconType": "png"}
3402	25137	{"_key": 25137, "iconFile": "res:/ui/texture/classes/DockPanel/closeButton.png"}
3403	25138	{"_key": 25138, "iconFile": "res:/ui/texture/classes/Window/btnClose.png"}
3404	25139	{"_key": 25139, "iconFile": "res:/ui/texture/shared/Brackets/Asteroid_Small.png"}
3405	25140	{"_key": 25140, "iconFile": "res:/ui/texture/icons/44_32_35.png"}
3406	25141	{"_key": 25141, "iconFile": "res:/ui/texture/icons/44_32_59.png"}
3407	25143	{"_key": 25143, "iconFile": "res:/ui/texture/shared/actions/startConversation.png"}
3408	25145	{"_key": 25145, "iconFile": "res:/ui/texture/icons/SFmaterial/gasbooster.png"}
3409	25146	{"_key": 25146, "iconFile": "res:/ui/texture/icons/SFmaterial/icebooster.png"}
3410	25147	{"_key": 25147, "iconFile": "res:/ui/texture/icons/SFmaterial/orebooster.png"}
3411	25148	{"_key": 25148, "iconFile": "res:/UI/Texture/classes/industry/centerbar/arrows.png"}
3412	25149	{"_key": 25149, "iconFile": "res:/UI/Asset/mannequin/outer/62750_Male_outer_ExplorationSuit_M01_Types_ExplorationSuit_M01_AIR.png", "iconType": "png"}
3413	25150	{"_key": 25150, "iconFile": "res:/UI/Texture/Icons/Modules/asteroid_M.png"}
3414	25151	{"_key": 25151, "iconFile": "res:/UI/Texture/Icons/Modules/asteroid_L.png"}
3415	25152	{"_key": 25152, "iconFile": "res:/UI/Texture/Icons/Modules/asteroid_XL.png"}
3416	25153	{"_key": 25153, "iconFile": "res:/UI/Texture/Icons/Modules/gas_M.png"}
3417	25154	{"_key": 25154, "iconFile": "res:/UI/Texture/Icons/Modules/gas_L.png"}
3418	25155	{"_key": 25155, "iconFile": "res:/UI/Texture/Icons/Modules/gas_XL.png"}
3419	25156	{"_key": 25156, "iconFile": "res:/UI/Texture/Icons/Modules/ice_L.png"}
3420	25157	{"_key": 25157, "iconFile": "res:/UI/Texture/Icons/Modules/ice_XL.png"}
3421	25158	{"_key": 25158, "iconFile": "res:/UI/Texture/Icons/Modules/mercoxit_L.png"}
3422	25159	{"_key": 25159, "iconFile": "res:/UI/Texture/Icons/Modules/mercoxit_XL.png"}
3423	25160	{"_key": 25160, "iconFile": "res:/UI/Texture/Icons/Modules/moon_L.png"}
3424	25161	{"_key": 25161, "iconFile": "res:/UI/Texture/Icons/Modules/moon_XL.png"}
3425	25163	{"_key": 25163, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_Aqua.png"}
3426	25164	{"_key": 25164, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_Blue.png"}
3427	25165	{"_key": 25165, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_Green.png"}
3428	25166	{"_key": 25166, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_Lime.png"}
3429	25167	{"_key": 25167, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_Orange.png"}
3430	25168	{"_key": 25168, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_Purple.png"}
3431	25169	{"_key": 25169, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_Red.png"}
3432	25170	{"_key": 25170, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_Yellow.png"}
3433	25171	{"_key": 25171, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_Asteroid_Bezdnacine.png"}
3434	25172	{"_key": 25172, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_Asteroid_Rakovene.png"}
3435	25173	{"_key": 25173, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_Asteroid_Talassonite.png"}
3436	25174	{"_key": 25174, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_moonAsteroid_R4.png"}
3437	25175	{"_key": 25175, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_moonAsteroid_R8.png"}
3438	25176	{"_key": 25176, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_moonAsteroid_R16.png"}
3439	25177	{"_key": 25177, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_moonAsteroid_R32.png"}
3440	25178	{"_key": 25178, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_moonAsteroid_R64.png"}
3441	25179	{"_key": 25179, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_moonAsteroid_JackpotR4.png"}
3442	25180	{"_key": 25180, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_moonAsteroid_JackpotR8.png"}
3443	25181	{"_key": 25181, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_moonAsteroid_JackpotR16.png"}
3444	25182	{"_key": 25182, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_moonAsteroid_JackpotR32.png"}
3445	25183	{"_key": 25183, "iconFile": "res:/UI/Texture/Icons/Inventory/compressed_moonAsteroid_JackpotR64.png"}
3446	25185	{"_key": 25185, "iconFile": "res:/UI/Asset/mannequin/outer/63051_Male_outer_JacketCMM01_Types_JacketCMM01_ep.png", "iconType": "png"}
3447	25186	{"_key": 25186, "iconFile": "res:/UI/Asset/mannequin/outer/63052_Female_Outer_JacketCMF01_Types_JacketCMF01_ep.png", "iconType": "png"}
3448	25188	{"_key": 25188, "iconFile": "res:/UI/Asset/mannequin/bottomouter/63054_Male_bottomOuter_PantsPrtm01_Types_PantsPrtm01_ep.png", "iconType": "png"}
3449	25189	{"_key": 25189, "iconFile": "res:/UI/Asset/mannequin/bottomouter/63055_Female_bottomOuter_PantsPrtF01_Types_PantsPrtF01_ep.png", "iconType": "png"}
3450	25190	{"_key": 25190, "iconFile": "res:/UI/Asset/mannequin/outer/63056_Female_Outer_ExplorationSuit_F01_Types_ExplorationSuit_F01_Air.png", "iconType": "png"}
3451	25192	{"_key": 25192, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/63058_Male_Accessories_Glasses_Glasses_Slick_01_Types_Glasses_Slick_01_Ep.png", "iconType": "png"}
3452	25195	{"_key": 25195, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/63061_Female_Accessories_Glasses_Glasses_Slick_01_Types_Glasses_Slick_01_Ep.png", "iconType": "png"}
3453	25196	{"_key": 25196, "iconFile": "res:/UI/Texture/Classes/ShipTree/factions/solarflare.png"}
3454	25197	{"_key": 25197, "iconFile": "res:/UI/Texture/Shared/Brackets/WreckNPC_Large_.png", "iconType": "png"}
3455	25198	{"_key": 25198, "iconFile": "res:/UI/Asset/mannequin/outer/63112_Male_outer_JacketPrtm01_Types_JacketPrtm01_guristashunt_b.png", "iconType": "png"}
3456	25199	{"_key": 25199, "iconFile": "res:/UI/Asset/mannequin/feet/63113_Male_Feet_BootsPrtm01_Types_BootsPrtm01_guristashunt_b.png", "iconType": "png"}
3457	25200	{"_key": 25200, "iconFile": "res:/UI/Asset/mannequin/bottomouter/63114_Male_bottomOuter_PantsPrtm01_Types_PantsPrtm01_guristashunt_b.png", "iconType": "png"}
3458	25201	{"_key": 25201, "iconFile": "res:/UI/Asset/mannequin/outer/63115_Female_Outer_JacketPrtF01_Types_JacketPrtF01_guristashunt_b.png", "iconType": "png"}
3459	25209	{"_key": 25209, "iconFile": "res:/UI/Asset/mannequin/feet/63123_Female_Feet_BootsPrtF01_Types_BootsPrtF01_guristashunt_b.png", "iconType": "png"}
3460	25210	{"_key": 25210, "iconFile": "res:/UI/Asset/mannequin/bottomouter/63124_Female_bottomOuter_PantsPrtF01_Types_PantsPrtF01_guristashunt_b.png", "iconType": "png"}
3461	25215	{"_key": 25215, "iconFile": "res:/UI/Asset/mannequin/accessories_masks/63135_Male_Accessories_Masks_Mask_Cyberpunk_M01_Types_Mask_Cyberpunk_M01.png", "iconType": "png"}
3462	25218	{"_key": 25218, "iconFile": "res:/UI/Asset/mannequin/accessories_masks/63138_Female_Accessories_Masks_Mask_Cyberpunk_F01_Types_Mask_Cyberpunk_F01.png", "iconType": "png"}
3463	25219	{"_key": 25219, "iconFile": "res:/UI/Texture/roguelike/PrototypingTemplate_Decayed_64.png"}
3464	25220	{"_key": 25220, "iconFile": "res:/UI/Asset/mannequin/outer/63246_Male_outer_Hoodie_M01_Types_Hoodie_M01_XIX.png", "iconType": "png"}
3465	25227	{"_key": 25227, "iconFile": "res:/UI/Asset/mannequin/outer/63253_Male_outer_Hoodie_M01_Types_Hoodie_M01_XIX_HQ.png", "iconType": "png"}
3466	25231	{"_key": 25231, "iconFile": "res:/UI/Asset/mannequin/outer/63257_Female_Outer_Hoodie_F01_Types_Hoodie_F01_XIX.png", "iconType": "png"}
3467	25234	{"_key": 25234, "iconFile": "res:/UI/Asset/mannequin/outer/63260_Female_Outer_Hoodie_F01_Types_Hoodie_F01_XIX_HQ.png", "iconType": "png"}
3468	25235	{"_key": 25235, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterAGreenI.png", "iconType": "png"}
3469	25236	{"_key": 25236, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterAGreenII.png", "iconType": "png"}
3470	25237	{"_key": 25237, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterAGreenIII.png", "iconType": "png"}
3471	25238	{"_key": 25238, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterAGreenIV.png", "iconType": "png"}
3472	25239	{"_key": 25239, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterAGreenV.png", "iconType": "png"}
3473	25240	{"_key": 25240, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterABlueI.png", "iconType": "png"}
3474	25241	{"_key": 25241, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterABlueII.png", "iconType": "png"}
3475	25242	{"_key": 25242, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterABlueIII.png", "iconType": "png"}
3476	25243	{"_key": 25243, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterABlueIV.png", "iconType": "png"}
3477	25244	{"_key": 25244, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterABlueV.png", "iconType": "png"}
3478	25245	{"_key": 25245, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterARedI.png", "iconType": "png", "obsolete": 0}
3479	25246	{"_key": 25246, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterARedII.png", "iconType": "png"}
3480	25247	{"_key": 25247, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterARedIII.png", "iconType": "png"}
3481	25248	{"_key": 25248, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterARedIV.png", "iconType": "png"}
3482	25249	{"_key": 25249, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterARedV.png", "iconType": "png"}
3483	25250	{"_key": 25250, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterAYellowI.png", "iconType": "png"}
3484	25251	{"_key": 25251, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterAYellowII.png", "iconType": "png"}
3485	25252	{"_key": 25252, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterAYellowIII.png", "iconType": "png"}
3486	25253	{"_key": 25253, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterAYellowIV.png", "iconType": "png"}
3487	25254	{"_key": 25254, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterAYellowV.png", "iconType": "png"}
3488	25255	{"_key": 25255, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBGreenI.png", "iconType": "png"}
3489	25256	{"_key": 25256, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBGreenII.png", "iconType": "png"}
3490	25257	{"_key": 25257, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBGreenIII.png", "iconType": "png"}
3491	25258	{"_key": 25258, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBGreenIV.png", "iconType": "png"}
3492	25259	{"_key": 25259, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBGreenV.png", "iconType": "png"}
3493	25260	{"_key": 25260, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBBlueI.png", "iconType": "png"}
3494	25261	{"_key": 25261, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBBlueII.png", "iconType": "png"}
3495	25262	{"_key": 25262, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBBlueIII.png", "iconType": "png"}
3496	25263	{"_key": 25263, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBBlueIV.png", "iconType": "png"}
3497	25264	{"_key": 25264, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBBlueV.png", "iconType": "png"}
3498	25265	{"_key": 25265, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBRedI.png", "iconType": "png"}
3499	25266	{"_key": 25266, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBRedII.png", "iconType": "png"}
3500	25267	{"_key": 25267, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBRedIII.png", "iconType": "png"}
3501	25268	{"_key": 25268, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBRedIV.png", "iconType": "png"}
3502	25269	{"_key": 25269, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBRedV.png", "iconType": "png"}
3503	25270	{"_key": 25270, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBYellowI.png", "iconType": "png"}
3504	25271	{"_key": 25271, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBYellowII.png", "iconType": "png"}
3505	25272	{"_key": 25272, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBYellowIII.png", "iconType": "png"}
3506	25273	{"_key": 25273, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBYellowIV.png", "iconType": "png"}
3507	25274	{"_key": 25274, "iconFile": "res:/UI/Texture/Icons/Inventory/BoosterBYellowV.png", "iconType": "png"}
3508	25275	{"_key": 25275, "iconFile": "res:/UI/Texture/Icons/Inventory/Battlepass_SolarflareB_75x75.png", "iconType": "png"}
3509	25276	{"_key": 25276, "iconFile": "res:/UI/Texture/Icons/Inventory/Battlepass_SolarflareA_75x75.png", "iconType": "png"}
3510	25277	{"_key": 25277, "iconFile": "res:/ui/texture/icons/inventory/dli_booster_icon.png"}
3511	25278	{"_key": 25278, "iconFile": "res:/ui/texture/icons/inventory/dli_filament_icon.png"}
3512	25279	{"_key": 25279, "iconFile": "res:/ui/texture/icons/inventory/dli_isk_icon.png"}
3513	25280	{"_key": 25280, "iconFile": "res:/ui/texture/icons/inventory/dli_skin_icon.png"}
3514	25281	{"_key": 25281, "iconFile": "res:/ui/texture/icons/inventory/dli_sp_icon.png"}
3515	25283	{"_key": 25283, "iconFile": "res:/ui/texture/icons/5_64_3.png"}
3516	25284	{"_key": 25284, "iconFile": "res:/ui/texture/icons/inventory/dli_booster_icon_green.png", "iconType": "png"}
3517	25285	{"_key": 25285, "iconFile": "res:/ui/texture/icons/inventory/dli_booster_icon_blue.png", "iconType": "png"}
3518	25286	{"_key": 25286, "iconFile": "res:/ui/texture/icons/inventory/dli_booster_icon_purple.png", "iconType": "png"}
3519	25287	{"_key": 25287, "iconFile": "res:/ui/texture/icons/inventory/dli_filament_icon_green.png", "iconType": "png"}
3520	25288	{"_key": 25288, "iconFile": "res:/ui/texture/icons/inventory/dli_filament_icon_blue.png", "iconType": "png"}
3521	25289	{"_key": 25289, "iconFile": "res:/ui/texture/icons/inventory/dli_filament_icon_purple.png", "iconType": "png"}
3522	25290	{"_key": 25290, "iconFile": "res:/ui/texture/icons/inventory/dli_isk_icon_green.png", "iconType": "png"}
3523	25291	{"_key": 25291, "iconFile": "res:/ui/texture/icons/inventory/dli_isk_icon_blue.png", "iconType": "png"}
3524	25292	{"_key": 25292, "iconFile": "res:/ui/texture/icons/inventory/dli_isk_icon_purple.png", "iconType": "png"}
3525	25293	{"_key": 25293, "iconFile": "res:/ui/texture/icons/inventory/dli_skin_icon_green.png", "iconType": "png"}
3526	25294	{"_key": 25294, "iconFile": "res:/ui/texture/icons/inventory/dli_skin_icon_blue.png", "iconType": "png"}
3527	25295	{"_key": 25295, "iconFile": "res:/ui/texture/icons/inventory/dli_skin_icon_purple.png", "iconType": "png"}
3528	25296	{"_key": 25296, "iconFile": "res:/ui/texture/icons/inventory/dli_sp_icon_green.png", "iconType": "png"}
3529	25297	{"_key": 25297, "iconFile": "res:/ui/texture/icons/inventory/dli_sp_icon_blue.png", "iconType": "png"}
3530	25298	{"_key": 25298, "iconFile": "res:/ui/texture/icons/inventory/dli_sp_icon_purple.png", "iconType": "png"}
3531	25299	{"_key": 25299, "iconFile": "res:/UI/Asset/mannequin/outer/63747_Male_outer_JacketFormalMilM01_Types_JacketFormalMilM01_Caldari_FF.png", "iconType": "png"}
3532	25300	{"_key": 25300, "iconFile": "res:/UI/Asset/mannequin/bottomouter/63748_Male_bottomOuter_PantsCorpBusinessM01_Types_PantsCorpBusinessM01_BlackFF.png", "iconType": "png"}
3533	25301	{"_key": 25301, "iconFile": "res:/UI/Asset/mannequin/outer/63749_Female_Outer_JacketFormalMilF01_Types_JacketFormalMilF01_Caldari_FF.png", "iconType": "png"}
3534	25302	{"_key": 25302, "iconFile": "res:/UI/Asset/mannequin/bottomouter/63750_Female_bottomOuter_PantsCorpBusinessF01_Types_PantsCorpBusinessF01_BlackFF.png", "iconType": "png"}
3535	25303	{"_key": 25303, "iconFile": "res:/UI/Asset/mannequin/outer/63789_Male_outer_JacketMFBR01_Types_JacketMFBR01_Race.png", "iconType": "png"}
3536	25304	{"_key": 25304, "iconFile": "res:/UI/Asset/mannequin/outer/63790_Female_Outer_JacketFBR01_Types_JacketFBR01_race.png", "iconType": "png"}
3537	25305	{"_key": 25305, "iconFile": "res:/UI/Texture/Shared/Brackets/largeCollidableStructure.png"}
3538	25310	{"_key": 25310, "iconFile": "res:/ui/texture/repairableship/hourglass_show.png"}
3539	25311	{"_key": 25311, "iconFile": "res:/dx9/model/ship/caldari/shuttle/cs1/icons/317_128.png", "iconType": "png"}
3540	25314	{"_key": 25314, "iconFile": "res:/UI/Asset/mannequin/outer/64195_Female_Outer_JacketFBR01_Types_JacketFBR01_race_hq.png", "iconType": "png"}
3541	25315	{"_key": 25315, "iconFile": "res:/UI/Asset/mannequin/outer/64196_Male_outer_JacketMFBR01_Types_JacketMFBR01_Race_HQ.png", "iconType": "png"}
3542	25328	{"_key": 25328, "iconFile": "res:/ui/texture/icons/inventory/CareerPortal/loot_crate64_enforcer.png", "iconType": "png"}
3543	25329	{"_key": 25329, "iconFile": "res:/ui/texture/icons/inventory/CareerPortal/loot_crate64_explorer.png", "iconType": "png"}
3544	25330	{"_key": 25330, "iconFile": "res:/ui/texture/icons/inventory/CareerPortal/loot_crate64_industrial.png", "iconType": "png"}
3545	25331	{"_key": 25331, "iconFile": "res:/ui/texture/icons/inventory/CareerPortal/loot_crate64_sof.png", "iconType": "png"}
3546	25336	{"_key": 25336, "iconFile": "res:/UI/Asset/mannequin/hair/64201_Male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_Lib_HQ.png", "iconType": "png"}
3547	25337	{"_key": 25337, "iconFile": "res:/UI/Asset/mannequin/hair/64202_Female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_Lib_HQ.png", "iconType": "png"}
3548	25338	{"_key": 25338, "iconFile": "res:/UI/Asset/mannequin/topmiddle/64203_Female_TopMiddle_TshirtF01_Types_TshirtF01_Lib_HQ.png", "iconType": "png"}
3549	25339	{"_key": 25339, "iconFile": "res:/UI/Asset/mannequin/topmiddle/64204_Male_topMiddle_TshirtM01_Types_TshirtM01_Lib_HQ.png", "iconType": "png"}
3550	25340	{"_key": 25340, "iconFile": "res:/UI/Asset/mannequin/topmiddle/64268_Male_topMiddle_TshirtM01_Types_TshirtM01_Lib.png", "iconType": "png"}
3551	25341	{"_key": 25341, "iconFile": "res:/UI/Asset/mannequin/topmiddle/64269_Female_TopMiddle_TshirtF01_Types_TshirtF01_Lib.png", "iconType": "png"}
3552	25342	{"_key": 25342, "iconFile": "res:/UI/Asset/mannequin/hair/64270_Male_hair_HeadWear_Cap_M01_Types_HeadWear_Cap_M01_Lib.png", "iconType": "png"}
3553	25343	{"_key": 25343, "iconFile": "res:/UI/Asset/mannequin/hair/64271_Female_hair_HeadWear_Cap_F01_Types_HeadWear_Cap_F01_Lib.png", "iconType": "png"}
3554	25344	{"_key": 25344, "iconFile": "res:/UI/Texture/Icons/Inventory/GuristasChip_GS.png", "iconType": "png"}
3555	25345	{"_key": 25345, "iconFile": "res:/UI/Texture/Icons/Inventory/GuristasChip_LB.png", "iconType": "png"}
3556	25346	{"_key": 25346, "iconFile": "res:/UI/Texture/Icons/Inventory/GuristasChip_TS.png", "iconType": "png"}
3557	25347	{"_key": 25347, "iconFile": "res:/UI/Texture/Icons/Inventory/GuristasChip_XD.png", "iconType": "png"}
3558	25348	{"_key": 25348, "iconFile": "res:/UI/Asset/mannequin/outer/64377_Female_Outer_RobeF01_Types_RobeAF01_AmarrFoundation.png", "iconType": "png"}
3559	25349	{"_key": 25349, "iconFile": "res:/UI/Asset/mannequin/outer/64378_Female_Outer_RobeF01_Types_RobeAF01_AmarrFoundation_HQ.png", "iconType": "png"}
3560	25350	{"_key": 25350, "iconFile": "res:/UI/Asset/mannequin/outer/64379_Male_outer_RobeAM01_Types_RobeAM01_AmarrFoundation.png", "iconType": "png"}
3561	25351	{"_key": 25351, "iconFile": "res:/UI/Asset/mannequin/outer/64380_Male_outer_RobeAM01_Types_RobeAM01_AmarrFoundation_HQ.png", "iconType": "png"}
3562	25353	{"_key": 25353, "iconFile": "res:/ui/texture/repairableship/refurbishment_component.png"}
3563	25354	{"_key": 25354, "iconFile": "res:/UI/Texture/WindowIcons/airCareerProgram.png", "iconType": "png"}
3564	25355	{"_key": 25355, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Pressurized_Oxygen_64.png"}
3565	25356	{"_key": 25356, "iconFile": "res:/UI/Texture/Icons/CapitalShipProduction/Reinforce_Carbon_Fibre_64.png"}
3566	25357	{"_key": 25357, "iconFile": "res:/UI/Texture/Icons/Inventory/Dark_Crystal_Token.png", "iconType": "png"}
3567	25358	{"_key": 25358, "iconFile": "res:/UI/Texture/Icons/Inventory/DED_Cerebral_Accelerator_64x64.png", "iconType": "png"}
3568	25363	{"_key": 25363, "iconFile": "res:/ui/texture/icons/ShipKillBenefit/SDJ_l1_128.png"}
3569	25364	{"_key": 25364, "iconFile": "res:/ui/texture/icons/ShipKillBenefit/SDJ_l2_128.png"}
3570	25365	{"_key": 25365, "iconFile": "res:/ui/texture/icons/ShipKillBenefit/SDJ_l3_128.png"}
3571	25366	{"_key": 25366, "iconFile": "res:/ui/texture/icons/ShipKillBenefit/SDJ_l4_128.png"}
3572	25367	{"_key": 25367, "iconFile": "res:/ui/texture/icons/ShipKillBenefit/SDJ_l5_128.png"}
3573	25368	{"_key": 25368, "iconFile": "res:/UI/Asset/mannequin/outer/70838_Male_outer_JacketCM01_R_Types_JacketCM01_R_Commerce.png", "iconType": "png"}
3574	25369	{"_key": 25369, "iconFile": "res:/UI/Asset/mannequin/outer/70839_Male_outer_JacketCM01_R_Types_JacketCM01_R_Ishukone.png", "iconType": "png"}
3575	25370	{"_key": 25370, "iconFile": "res:/UI/Asset/mannequin/outer/70840_Male_outer_JacketCM01_R_Types_JacketCM01_R_CBD.png", "iconType": "png"}
3576	25371	{"_key": 25371, "iconFile": "res:/UI/Asset/mannequin/outer/70841_Male_outer_JacketCM01_R_Types_JacketCM01_R_Hyasyoda.png", "iconType": "png"}
3577	25372	{"_key": 25372, "iconFile": "res:/UI/Asset/mannequin/outer/70842_Male_outer_JacketCM01_R_Types_JacketCM01_R_Kaalakiota.png", "iconType": "png"}
3578	25373	{"_key": 25373, "iconFile": "res:/UI/Asset/mannequin/outer/70843_Male_outer_JacketCM01_R_Types_JacketCM01_R_Wiyrkomi.png", "iconType": "png"}
3579	25374	{"_key": 25374, "iconFile": "res:/UI/Asset/mannequin/outer/70844_Male_outer_JacketCM01_R_Types_JacketCM01_R_LaiDai.png", "iconType": "png"}
3580	25375	{"_key": 25375, "iconFile": "res:/UI/Asset/mannequin/outer/70845_Male_outer_JacketCM01_R_Types_JacketCM01_R_Sukuuvestaa.png", "iconType": "png"}
3581	25376	{"_key": 25376, "iconFile": "res:/UI/Asset/mannequin/outer/70846_Male_outer_JacketCM01_R_Types_JacketCM01_R_Nugoeihuvi.png", "iconType": "png"}
3582	25377	{"_key": 25377, "iconFile": "res:/UI/Asset/mannequin/outer/70847_Female_Outer_JacketCF01_R_Types_JacketCF01_R_Commerce.png", "iconType": "png"}
3583	25378	{"_key": 25378, "iconFile": "res:/UI/Asset/mannequin/outer/70848_Female_Outer_JacketCF01_R_Types_JacketCF01_R_Ishukone.png", "iconType": "png"}
3584	25379	{"_key": 25379, "iconFile": "res:/UI/Asset/mannequin/outer/70849_Female_Outer_JacketCF01_R_Types_JacketCF01_R_CBD.png", "iconType": "png"}
3585	25380	{"_key": 25380, "iconFile": "res:/UI/Asset/mannequin/outer/70850_Female_Outer_JacketCF01_R_Types_JacketCF01_R_Hyasyoda.png", "iconType": "png"}
3586	25381	{"_key": 25381, "iconFile": "res:/UI/Asset/mannequin/outer/70851_Female_Outer_JacketCF01_R_Types_JacketCF01_R_Kaalakiota.png", "iconType": "png"}
3587	25382	{"_key": 25382, "iconFile": "res:/UI/Asset/mannequin/outer/70852_Female_Outer_JacketCF01_R_Types_JacketCF01_R_Wiyrkomi.png", "iconType": "png"}
3588	25383	{"_key": 25383, "iconFile": "res:/UI/Asset/mannequin/outer/70853_Female_Outer_JacketCF01_R_Types_JacketCF01_R_LaiDai.png", "iconType": "png"}
3589	25384	{"_key": 25384, "iconFile": "res:/UI/Asset/mannequin/outer/70854_Female_Outer_JacketCF01_R_Types_JacketCF01_R_Sukuuvestaa.png", "iconType": "png"}
3590	25385	{"_key": 25385, "iconFile": "res:/UI/Asset/mannequin/outer/70855_Female_Outer_JacketCF01_R_Types_JacketCF01_R_Nugoeihuvi.png", "iconType": "png"}
3591	25386	{"_key": 25386, "iconFile": "res:/UI/Texture/Icons/shipAdaption/chip1-64.png"}
3592	25387	{"_key": 25387, "iconFile": "res:/UI/Texture/Icons/shipAdaption/chip2-64.png"}
3593	25388	{"_key": 25388, "iconFile": "res:/UI/Texture/Icons/shipAdaption/chip3-64.png"}
3594	25389	{"_key": 25389, "iconFile": "res:/ui/texture/icons/inventory/sp-a-icon128.png", "iconType": "png"}
3595	25390	{"_key": 25390, "iconFile": "res:/ui/texture/icons/inventory/sp-b-icon128.png", "iconType": "png"}
3596	25391	{"_key": 25391, "iconFile": "res:/ui/texture/icons/plex_voucher_64.png", "iconType": "png"}
3597	25402	{"_key": 25402, "iconFile": "res:/UI/Texture/Icons/Inventory/Icon_Silver_Gacha.png", "iconType": "png"}
3598	25403	{"_key": 25403, "iconFile": "res:/UI/Texture/Icons/Inventory/Icon_Golden_Gacha.png", "iconType": "png"}
3599	25404	{"_key": 25404, "iconFile": "res:/ui/texture/icons/inventory/icon_sp_01_128.png", "iconType": "png"}
3600	25405	{"_key": 25405, "iconFile": "res:/ui/texture/icons/inventory/icon_sp_04_128.png", "iconType": "png"}
3601	25406	{"_key": 25406, "iconFile": "res:/ui/texture/icons/inventory/icon_sp_02_128.png", "iconType": "png"}
3602	25407	{"_key": 25407, "iconFile": "res:/ui/texture/icons/inventory/icon_sp_03_128.png", "iconType": "png"}
3603	25408	{"_key": 25408, "iconFile": "res:/ui/texture/icons/inventory/Icon_Mooncake03.png", "iconType": "png"}
3604	25409	{"_key": 25409, "iconFile": "res:/ui/texture/icons/inventory/Icon_Mooncake04.png", "iconType": "png"}
3605	25410	{"_key": 25410, "iconFile": "res:/ui/texture/icons/inventory/Icon_Mooncake01.png", "iconType": "png"}
3606	25411	{"_key": 25411, "iconFile": "res:/ui/texture/icons/inventory/Icon_Mooncake05.png", "iconType": "png"}
3607	25412	{"_key": 25412, "iconFile": "res:/ui/texture/icons/inventory/Icon_Mooncake02.png", "iconType": "png"}
3608	25415	{"_key": 25415, "iconFile": "res:/ui/texture/icons/inventory/icon_sp_05_128.png", "iconType": "png"}
3609	25416	{"_key": 25416, "iconFile": "res:/ui/texture/icons/inventory/icon_sp_06_128.png", "iconType": "png"}
3610	25417	{"_key": 25417, "iconFile": "res:/ui/texture/icons/inventory/icon_sp_07_128.png", "iconType": "png"}
3611	25447	{"_key": 25447, "iconFile": "res:/UI/Asset/mannequin/bottomouter/73395_Male_bottomOuter_PantsCorpBusinessM01_Types_PantsCorpBusinessM01_DarkTurquoise.png", "iconType": "png"}
3612	25448	{"_key": 25448, "iconFile": "res:/UI/Asset/mannequin/outer/73396_Male_outer_JacketCorpBusinessM01_Types_JacketCorpBusinessM01_DarkTurquoise.png", "iconType": "png"}
3613	25451	{"_key": 25451, "iconFile": "res:/UI/Asset/mannequin/outer/73407_Female_Outer_JacketMilF02_Types_JacketMilF02_WhiteTurquoise.png", "iconType": "png"}
3614	25452	{"_key": 25452, "iconFile": "res:/UI/Asset/mannequin/accessories_masks/73423_Female_Accessories_Masks_Mask_Cyberpunk_F01_Types_Mask_Cyberpunk_F01_Tan_Worn.png", "iconType": "png"}
3615	25453	{"_key": 25453, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/73424_Female_Accessories_Glasses_Goggles_01_Types_goggles_01_tan_worn.png", "iconType": "png"}
3616	25454	{"_key": 25454, "iconFile": "res:/UI/Asset/mannequin/accessories_masks/73425_Male_Accessories_Masks_Mask_Cyberpunk_M01_Types_Mask_Cyberpunk_M01_Tan_Worn.png", "iconType": "png"}
3617	25455	{"_key": 25455, "iconFile": "res:/UI/Asset/mannequin/accessories_glasses/73426_Male_Accessories_Glasses_Goggles_01_Types_goggles_01_tan_worn.png", "iconType": "png"}
3618	25456	{"_key": 25456, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/73436_Male_Makeup_Augmentations_Face_Paint_M01_Types_Face_Paint_M01_V7_Red.png", "iconType": "png"}
3619	25457	{"_key": 25457, "iconFile": "res:/UI/Asset/mannequin/makeup_augmentations/73437_Female_Makeup_Augmentations_Face_Paint_F01_Types_Face_Paint_F01_V3_Red.png", "iconType": "png"}
3620	25458	{"_key": 25458, "iconFile": "res:/ui/texture/icons/inventory/icon_sp_common_64.png", "iconType": "png"}
3621	25463	{"_key": 25463, "iconFile": "res:/ui/texture/corps/EverMore.png", "iconType": "png"}
3622	25465	{"_key": 25465, "iconFile": "res:/ui/texture/corps/paragon.png", "iconType": "png"}
3623	25467	{"_key": 25467, "iconFile": "res:/ui/texture/classes/fitting/cosmetics/alliance_logo_128px.png", "iconType": "png"}
3624	25468	{"_key": 25468, "iconFile": "res:/ui/texture/classes/fitting/cosmetics/corp_logo_128px.png", "iconType": "png"}
3625	25469	{"_key": 25469, "iconFile": "res:/ui/texture/icons/inventory/pumpkin1.png", "iconType": "png"}
3626	25470	{"_key": 25470, "iconFile": "res:/ui/texture/icons/inventory/pumpkin2.png", "iconType": "png"}
3627	25471	{"_key": 25471, "iconFile": "res:/ui/texture/icons/inventory/candy_red.png", "iconType": "png"}
3628	25472	{"_key": 25472, "iconFile": "res:/ui/texture/icons/inventory/candy_blue.png", "iconType": "png"}
3629	25473	{"_key": 25473, "iconFile": "res:/ui/texture/icons/inventory/candy_pink.png", "iconType": "png"}
3630	25474	{"_key": 25474, "iconFile": "res:/ui/texture/icons/inventory/candy_white.png", "iconType": "png"}
3631	25475	{"_key": 25475, "iconFile": "res:/ui/texture/icons/evermarks.png"}
3632	25477	{"_key": 25477, "iconFile": "res:/ui/texture/icons/inventory/Icon_Golden_Gacha.png", "iconType": "png"}
3633	25478	{"_key": 25478, "iconFile": "res:/ui/texture/icons/inventory/20221111_Duplicate_Multiplicator_64X64.png", "iconType": "png"}
3634	25479	{"_key": 25479, "iconFile": "res:/ui/texture/icons/inventory/20221111_Carbon_Fiber_Shaft_64X64.png", "iconType": "png"}
3635	25480	{"_key": 25480, "iconFile": "res:/ui/texture/icons/inventory/20221111_Event_Certificate_64X64.png", "iconType": "png"}
3636	25493	{"_key": 25493, "iconFile": "res:/ui/texture/icons/inventory/20221121_Infinity_SKIN_Token_Icon.png", "iconType": "png"}
3637	25494	{"_key": 25494, "iconFile": "res:/ui/texture/icons/inventory/20221123_Winter_SKIN_Gacha_64X64.png", "iconType": "png"}
3638	25495	{"_key": 25495, "iconFile": "res:/ui/texture/icons/inventory/Marshlight_SKIN_Token.png", "iconType": "png"}
3639	25496	{"_key": 25496, "iconFile": "res:/ui/texture/icons/inventory/Marshlight_Gacha_64X64.png", "iconType": "png"}
3640	25497	{"_key": 25497, "iconFile": "res:/ui/texture/icons/inventory/Marshlight_SKIN_Token.png", "iconType": "png"}
3641	25498	{"_key": 25498, "iconFile": "res:/ui/texture/icons/inventory/Marshlight_Gacha_64X64.png"}
3642	25499	{"_key": 25499, "iconFile": "res:/ui/texture/icons/Inventory/dg_03.png", "iconType": "png"}
3643	25515	{"_key": 25515, "iconFile": "res:/ui/texture/icons/Inventory/Icon_skillrapidlicence_01.png", "iconType": "png"}
3644	25516	{"_key": 25516, "iconFile": "res:/ui/texture/icons/Inventory/box_221129.png", "iconType": "png"}
3645	25517	{"_key": 25517, "iconFile": "res:/ui/texture/icons/inventory/Dazzling_Snow_Universal_Token.png", "iconType": "png"}
3646	25518	{"_key": 25518, "iconFile": "res:/ui/texture/icons/inventory/Dazzling_Snow_Gacha_64.png", "iconType": "png"}
3647	25519	{"_key": 25519, "iconFile": "res:/ui/texture/icons/brawl/gascloud/74254_64.png"}
3648	25520	{"_key": 25520, "iconFile": "res:/ui/texture/icons/brawl/shipskills/ShieldResist400_64.png"}
3649	25521	{"_key": 25521, "iconFile": "res:/ui/texture/icons/brawl/shipskills/ShieldBreaker600_64.png"}
3650	25522	{"_key": 25522, "iconFile": "res:/ui/texture/icons/brawl/shipskills/ShieldResistlvl2_400_64.png"}
3651	25523	{"_key": 25523, "iconFile": "res:/ui/texture/icons/brawl/shipskills/ShieldBreakerlvl2_550_64.png"}
3652	25524	{"_key": 25524, "iconFile": "res:/ui/texture/icons/Inventory/box_221214.png", "iconType": "png"}
3653	25525	{"_key": 25525, "iconFile": "res:/ui/texture/icons/94_64_13.png", "iconType": "png"}
3654	25526	{"_key": 25526, "iconFile": "res:/ui/texture/icons/brawl/shipskills/SpeedMinus500_64.png"}
3655	25527	{"_key": 25527, "iconFile": "res:/ui/texture/icons/brawl/shipskills/SpeedMinuslv2_350_64.png"}
3656	25528	{"_key": 25528, "iconFile": "res:/ui/texture/icons/brawl/shipskills/DPSBuff250_64.png"}
3657	25529	{"_key": 25529, "iconFile": "res:/ui/texture/icons/brawl/shipskills/DPSBuff250lv2_64.png"}
3658	25530	{"_key": 25530, "iconFile": "res:/ui/texture/icons/brawl/shipskills/ECM600_64.png"}
3659	25531	{"_key": 25531, "iconFile": "res:/ui/texture/icons/brawl/shipskills/ECMlv2_400_64.png"}
3660	25532	{"_key": 25532, "iconFile": "res:/ui/texture/icons/inventory/Ocean_Master_Medal_64X64.png", "iconType": "png"}
3661	25534	{"_key": 25534, "iconFile": "res:/ui/texture/icons/inventory/ChristmasA1_64.png", "iconType": "png"}
3662	25535	{"_key": 25535, "iconFile": "res:/ui/texture/icons/inventory/ChristmasA2_64.png", "iconType": "png"}
3663	25536	{"_key": 25536, "iconFile": "res:/ui/texture/icons/inventory/ChristmasA3_64.png", "iconType": "png"}
3664	25537	{"_key": 25537, "iconFile": "res:/ui/texture/icons/inventory/ChristmasB1_64.png", "iconType": "png"}
3665	25538	{"_key": 25538, "iconFile": "res:/ui/texture/icons/inventory/ChristmasB2_64.png", "iconType": "png"}
3666	25539	{"_key": 25539, "iconFile": "res:/ui/texture/icons/inventory/ChristmasB3_64.png", "iconType": "png"}
3667	25540	{"_key": 25540, "iconFile": "res:/ui/texture/icons/inventory/Christmas_SKIN_Gacha_64.png"}
3668	25541	{"_key": 25541, "iconFile": "res:/ui/texture/icons/Inventory/box_221229.png", "iconType": "png"}
3669	25542	{"_key": 25542, "iconFile": "res:/ui/texture/icons/inventory/Token_Orange.png", "iconType": "png"}
3670	25543	{"_key": 25543, "iconFile": "res:/ui/texture/icons/Inventory/box_230105.png", "iconType": "png"}
3671	25544	{"_key": 25544, "iconFile": "res:/ui/texture/icons/Inventory/box_230105.png"}
3672	25547	{"_key": 25547, "iconFile": "res:/ui/texture/WindowIcons/assets.png"}
3673	25548	{"_key": 25548, "iconFile": "res:/ui/texture/icons/inventory/YC125.1_Harvester_Booster.png", "iconType": "png"}
3674	25549	{"_key": 25549, "iconFile": "res:/ui/texture/icons/inventory/YC125.1_Harvester_Booster.png", "iconType": "png"}
3675	25550	{"_key": 25550, "iconFile": "res:/ui/texture/icons/inventory/icon_sp_common_64.png", "iconType": "png"}
3676	25551	{"_key": 25551, "iconFile": "res:/ui/texture/icons/inventory/Rui.png", "iconType": "png"}
3677	25552	{"_key": 25552, "iconFile": "res:/ui/texture/icons/inventory/Tu.png", "iconType": "png"}
3678	25553	{"_key": 25553, "iconFile": "res:/ui/texture/icons/inventory/Ying.png", "iconType": "png"}
3679	25554	{"_key": 25554, "iconFile": "res:/ui/texture/icons/inventory/Chun.png", "iconType": "png"}
3680	25555	{"_key": 25555, "iconFile": "res:/ui/texture/icons/inventory/YC125.png", "iconType": "png"}
3681	25556	{"_key": 25556, "iconFile": "res:/ui/texture/icons/inventory/YC125_Firework_64X64.png", "iconType": "png"}
3682	25557	{"_key": 25557, "iconFile": "res:/ui/texture/icons/inventory/YC125_NewYear_SKIN_Token.png", "iconType": "png"}
3683	25558	{"_key": 25558, "iconFile": "res:/ui/texture/icons/inventory/Mysterious_Log.png", "iconType": "png"}
3684	25559	{"_key": 25559, "iconFile": "res:/ui/texture/icons/inventory/Mysterious_Log2.png", "iconType": "png"}
3685	25560	{"_key": 25560, "iconFile": "res:/ui/texture/icons/inventory/Mysterious_Log3.png", "iconType": "png"}
3686	25561	{"_key": 25561, "iconFile": "res:/ui/texture/icons/inventory/Mysterious_Log4.png", "iconType": "png"}
3687	25562	{"_key": 25562, "iconFile": "res:/ui/texture/icons/inventory/Mysterious_Log5.png", "iconType": "png"}
3688	25563	{"_key": 25563, "iconFile": "res:/ui/texture/icons/inventory/Mysterious_Log6.png", "iconType": "png"}
3689	25564	{"_key": 25564, "iconFile": "res:/ui/texture/icons/inventory/Mysterious_Log7.png", "iconType": "png"}
3690	25566	{"_key": 25566, "iconFile": "res:/UI/Texture/Icons/Inventory/StructureTransformationModule_SkyRealm_64.png", "iconType": "png"}
3691	25567	{"_key": 25567, "iconFile": "res:/UI/Texture/Icons/Inventory/StructureTransformationModule_Nobility_64.png", "iconType": "png"}
3692	25568	{"_key": 25568, "iconFile": "res:/UI/Texture/Icons/Inventory/StructureTransformationModule_Elve_64.png", "iconType": "png"}
3693	25569	{"_key": 25569, "iconFile": "res:/ui/texture/icons/Inventory/box_230112.png", "iconType": "png"}
3694	25570	{"_key": 25570, "iconFile": "res:/ui/texture/icons/Inventory/20230116_Infinity_City_SKIN_Icon.png", "iconType": "png"}
3695	25571	{"_key": 25571, "iconFile": "res:/ui/texture/icons/Inventory/box_230117.png", "iconType": "png"}
3696	25573	{"_key": 25573, "iconFile": "res:/UI/Texture/Icons/Inventory/20230116_Infinity_City_SKIN_Icon.png", "iconType": "png"}
3697	25574	{"_key": 25574, "iconFile": "res:/UI/Texture/Icons/Inventory/box_230117.png", "iconType": "png"}
3698	25575	{"_key": 25575, "iconFile": "res:/ui/texture/icons/Inventory/box_230206.png", "iconType": "png"}
3699	25576	{"_key": 25576, "iconFile": "res:/ui/texture/icons/Inventory/20230206_Infinity_Ship_Gacha_Icon.png", "iconType": "png"}
3700	25577	{"_key": 25577, "iconFile": "res:/ui/texture/icons/Inventory/box_230206.png", "iconType": "png"}
3701	25578	{"_key": 25578, "iconFile": "res:/ui/texture/icons/Inventory/20230206_Infinity_Ship_Gacha_Icon.png", "iconType": "png"}
3702	25579	{"_key": 25579, "iconFile": "res:/ui/texture/icons/inventory/Harvester_Booster.png", "iconType": "png"}
3703	25580	{"_key": 25580, "iconFile": "res:/ui/texture/icons/inventory/Harvester_Booster.png", "iconType": "png"}
3704	25581	{"_key": 25581, "iconFile": "res:/ui/texture/icons/Inventory/box_230302.png", "iconType": "png"}
3705	25582	{"_key": 25582, "iconFile": "res:/ui/texture/icons/Inventory/20230302_Infinity_Ship_Gacha_Icon.png", "iconType": "png"}
3706	25583	{"_key": 25583, "iconFile": "res:/ui/texture/icons/Inventory/box_230302.png", "iconType": "png"}
3707	25584	{"_key": 25584, "iconFile": "res:/ui/texture/icons/Inventory/20230302_Infinity_Ship_Gacha_Icon.png", "iconType": "png"}
3708	25586	{"_key": 25586, "iconFile": "res:/ui/texture/icons/Icon_Propulsion Engine Polarization Module_64.png", "iconType": "png"}
3709	25587	{"_key": 25587, "iconFile": "res:/ui/texture/icons/Inventory/20230316_Infinity_Build_Gacha_Icon.png", "iconType": "png"}
3710	25588	{"_key": 25588, "iconFile": "res:/ui/texture/icons/Inventory/box_230316.png", "iconType": "png"}
3711	25591	{"_key": 25591, "iconFile": "res:/ui/texture/icons/Inventory/box_230316.png", "iconType": "png"}
3712	25592	{"_key": 25592, "iconFile": "res:/ui/texture/icons/Inventory/20230316_Infinity_Build_Gacha_Icon.png", "iconType": "png"}
3713	25593	{"_key": 25593, "iconFile": "res:/ui/texture/icons/Inventory/Accelerator_NationalDay_1.png", "iconType": "png"}
3714	25594	{"_key": 25594, "iconFile": "res:/ui/texture/icons/Inventory/Accelerator_NationalDay_2.png", "iconType": "png"}
3715	25595	{"_key": 25595, "iconFile": "res:/ui/texture/icons/Inventory/Accelerator_NationalDay_3.png", "iconType": "png"}
3716	25596	{"_key": 25596, "iconFile": "res:/ui/texture/icons/Inventory/Accelerator_NationalDay_1.png", "iconType": "png"}
3717	25597	{"_key": 25597, "iconFile": "res:/ui/texture/icons/Inventory/Accelerator_NationalDay_2.png", "iconType": "png"}
3718	25598	{"_key": 25598, "iconFile": "res:/ui/texture/icons/Inventory/Accelerator_NationalDay_3.png", "iconType": "png"}
3719	25599	{"_key": 25599, "iconFile": "res:/ui/texture/icons/inventory/icon_letter_v2.png", "iconType": "png"}
3720	25600	{"_key": 25600, "iconFile": "res:/ui/texture/icons/inventory/icon_flower.png", "iconType": "png"}
3721	25602	{"_key": 25602, "iconFile": "res:/ui/texture/icons/inventory/Icon_Capital_Ship_Crate_64.png", "iconType": "png"}
3722	25603	{"_key": 25603, "iconFile": "res:/ui/texture/icons/brawl/shipskills/DMG_Lv1.png"}
3723	25604	{"_key": 25604, "iconFile": "res:/ui/texture/icons/brawl/shipskills/DMG_Lv2.png"}
3724	25605	{"_key": 25605, "iconFile": "res:/ui/texture/icons/Inventory/20230421_Infinity_Ship_Gacha_Icon.png", "iconType": "png"}
3725	25606	{"_key": 25606, "iconFile": "res:/ui/texture/icons/Inventory/box_230421.png", "iconType": "png"}
3726	25607	{"_key": 25607, "iconFile": "res:/ui/texture/icons/Inventory/bag_20230421.png", "iconType": "png"}
3727	25608	{"_key": 25608, "iconFile": "res:/ui/texture/icons/Inventory/20230421_Infinity_Ship_Gacha_Icon.png", "iconType": "png"}
3728	25609	{"_key": 25609, "iconFile": "res:/ui/texture/icons/Inventory/bag_20230421.png", "iconType": "png"}
3729	25610	{"_key": 25610, "iconFile": "res:/ui/texture/icons/Inventory/box_230421.png", "iconType": "png"}
3730	25611	{"_key": 25611, "iconFile": "res:/ui/texture/icons/inventory/Carrier_Manufacturing_Support_Token.png", "iconType": "png"}
3731	25612	{"_key": 25612, "iconFile": "res:/ui/texture/icons/Inventory/YC125_Guardians_Gala_Ticket.png", "iconType": "png"}
3732	25616	{"_key": 25616, "iconFile": "res:/ui/texture/icons/Inventory/20230429_Battlepass.png", "iconType": "png"}
3733	25617	{"_key": 25617, "iconFile": "res:/ui/texture/icons/Inventory/20230429_Battlepass_level.png", "iconType": "png"}
3734	25618	{"_key": 25618, "iconFile": "res:/ui/texture/icons/Inventory/20230425_Build_Snik_ticket.png", "iconType": "png"}
3735	25619	{"_key": 25619, "iconFile": "res:/ui/texture/icons/Inventory/20230525_Build_Snki_mokuai.png", "iconType": "png"}
3736	25621	{"_key": 25621, "iconFile": "res:/UI/Texture/Icons/Modules/amarrLance.png"}
3737	25622	{"_key": 25622, "iconFile": "res:/UI/Texture/Icons/Modules/caldariLance.png"}
3738	25624	{"_key": 25624, "iconFile": "res:/UI/Texture/Icons/Modules/gallenteLance.png"}
3739	25625	{"_key": 25625, "iconFile": "res:/UI/Texture/Icons/Modules/minmatarLance.png"}
3740	25626	{"_key": 25626, "iconFile": "res:/ui/texture/icons/Inventory/20230605_Ship_Gacha.png", "iconType": "png", "obsolete": 0}
3741	25627	{"_key": 25627, "iconFile": "res:/ui/texture/icons/Inventory/20230605_Ship_Gacha_mokuai.png", "iconType": "png"}
3742	25629	{"_key": 25629, "iconFile": "res:/ui/texture/icons/35_64_13.png"}
3743	25631	{"_key": 25631, "iconFile": "res:/ui/texture/icons/35_64_11.png"}
3744	25632	{"_key": 25632, "iconFile": "res:/ui/texture/icons/36_64_6.png"}
3745	25633	{"_key": 25633, "iconFile": "res:/ui/texture/icons/36_64_7.png"}
3746	25634	{"_key": 25634, "iconFile": "res:/ui/texture/icons/35_64_16.png"}
3747	25663	{"_key": 25663, "iconFile": "res:/ui/texture/icons/Inventory/20230705_Ship_Gacha.png", "iconType": "png"}
3748	25664	{"_key": 25664, "iconFile": "res:/ui/texture/icons/Inventory/skill_on_time.png", "iconType": "png"}
3749	25666	{"_key": 25666, "iconFile": "res:/ui/texture/icons/43_64_12_d.png"}
3750	25668	{"_key": 25668, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_1.png"}
3751	25669	{"_key": 25669, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_2.png"}
3752	25670	{"_key": 25670, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_3.png"}
3753	25671	{"_key": 25671, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_4.png"}
3754	25672	{"_key": 25672, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_5.png"}
3755	25673	{"_key": 25673, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_6.png"}
3756	25674	{"_key": 25674, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_7.png"}
3757	25675	{"_key": 25675, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_17.png"}
3758	25676	{"_key": 25676, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_8.png"}
3759	25677	{"_key": 25677, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_9.png"}
3760	25678	{"_key": 25678, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_10.png"}
3761	25679	{"_key": 25679, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_11.png"}
3762	25680	{"_key": 25680, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_12.png"}
3763	25681	{"_key": 25681, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_13.png"}
3764	25682	{"_key": 25682, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_14.png"}
3765	25683	{"_key": 25683, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_15.png"}
3766	25684	{"_key": 25684, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_16.png"}
3767	25685	{"_key": 25685, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_18.png"}
3768	25686	{"_key": 25686, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_19.png"}
3769	25687	{"_key": 25687, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_20.png"}
3770	25688	{"_key": 25688, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_21.png"}
3771	25689	{"_key": 25689, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_22.png"}
3772	25690	{"_key": 25690, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_23.png"}
3773	25691	{"_key": 25691, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_24.png"}
3774	25692	{"_key": 25692, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_25.png"}
3775	25693	{"_key": 25693, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_26.png"}
3776	25694	{"_key": 25694, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_27.png"}
3777	25695	{"_key": 25695, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_28.png"}
3778	25696	{"_key": 25696, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_29.png"}
3779	25697	{"_key": 25697, "iconFile": "res:/ui/texture/icons/Inventory/WVItems/64/wv_64_30.png"}
3780	25718	{"_key": 25718, "iconFile": "res:/ui/texture/icons/Inventory/20230810_Ship_Gacha_ticket.png", "iconType": "png"}
3781	25736	{"_key": 25736, "iconFile": "res:/ui/texture/icons/Inventory/20230810_ship_gacha_token.png", "iconType": "png"}
3782	25801	{"_key": 25801, "iconFile": "res:/UI/Texture/Icons/StatusEffects/safeZone.png"}
3783	25802	{"_key": 25802, "iconFile": "res:/UI/Texture/Icons/StatusEffects/deathZoneGracePeriod.png"}
3784	25803	{"_key": 25803, "iconFile": "res:/UI/Texture/Icons/StatusEffects/deathZone.png"}
3785	25824	{"_key": 25824, "iconFile": "res:/ui/texture/icons/Inventory/20230907_ship_gacha_ticket.png", "iconType": "png"}
3786	25825	{"_key": 25825, "iconFile": "res:/ui/texture/icons/Inventory/20230907_Ship_Gacha_mokuai.png"}
3787	25826	{"_key": 25826, "iconFile": "res:/UI/Texture/Icons/RenameCardIcon.png"}
3788	25827	{"_key": 25827, "iconFile": "res:/ui/texture/icons/inventory/hyperPoint.png", "iconType": "png"}
3789	25829	{"_key": 25829, "iconFile": "res:/ui/texture/icons/mutation_corrector_64.png", "iconType": "png"}
3790	25830	{"_key": 25830, "iconFile": "res:/ui/texture/icons/Inventory/20230921_Buildskin_Gacha_ticket.png", "iconType": "png"}
3791	25831	{"_key": 25831, "iconFile": "res:/ui/texture/icons/Inventory/20230921_Buildskin_Gacha_mokuai.png", "iconType": "png"}
3792	25833	{"_key": 25833, "iconFile": "res:/UI/Texture/Corps/deathlessCircleBase.png"}
3793	25849	{"_key": 25849, "iconFile": "res:/ui/texture/icons/84_64_15.png"}
3794	25850	{"_key": 25850, "iconFile": "res:/ui/texture/icons/Inventory/YC125GoldAutumn_64X64.png"}
3795	25862	{"_key": 25862, "iconFile": "res:/ui/texture/icons/26_64_5.png"}
3796	25868	{"_key": 25868, "iconFile": "res:/ui/texture/icons/Inventory/motorcityChip.png", "iconType": "png"}
3797	25869	{"_key": 25869, "iconFile": "res:/ui/texture/icons/Inventory/motorcityGacha.png", "iconType": "png"}
3798	25870	{"_key": 25870, "iconFile": "res:/UI/Texture/Icons/StatusEffects/towed_status_icon.png"}
3799	25872	{"_key": 25872, "iconFile": "res:/ui/texture/icons/GabrielChip.png", "iconType": "png"}
3800	25873	{"_key": 25873, "iconFile": "res:/ui/texture/icons/GabrielTicket.png", "iconType": "png"}
3801	25874	{"_key": 25874, "iconFile": "res:/UI/Texture/classes/Seasons/omega_32x32.png", "iconType": "png"}
3802	25875	{"_key": 25875, "iconFile": "res:/ui/texture/icons/202401dragon1.png", "iconType": "png"}
3803	25876	{"_key": 25876, "iconFile": "res:/ui/texture/icons/202401dragon2.png", "iconType": "png"}
3804	25878	{"_key": 25878, "iconFile": "res:/UI/Texture/WindowIcons/amp_matrix_64.png"}
3805	25879	{"_key": 25879, "iconFile": "res:\\\\UI\\\\Texture\\\\WindowIcons\\\\amp_matrix_64.png"}
3806	25882	{"_key": 25882, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Academy Instructor.png"}
3807	25883	{"_key": 25883, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Ameline.png"}
3808	25884	{"_key": 25884, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Angel Villain.png"}
3809	25885	{"_key": 25885, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Blood Raider Maniac.png"}
3810	25886	{"_key": 25886, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Camoul.png"}
3811	25887	{"_key": 25887, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Concord Overseer.png"}
3812	25888	{"_key": 25888, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Council Priest.png"}
3813	25889	{"_key": 25889, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Duvolle Researcher.png"}
3814	25890	{"_key": 25890, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Engineer.png"}
3815	25891	{"_key": 25891, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Federation Minuteman.png"}
3816	25892	{"_key": 25892, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Torkebaira.png"}
3817	25893	{"_key": 25893, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Guristas Veteran.png"}
3818	25894	{"_key": 25894, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Hayden.png"}
3819	25895	{"_key": 25895, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Ishukone Technician.png"}
3820	25896	{"_key": 25896, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Jill.png"}
3821	25897	{"_key": 25897, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Karth.png"}
3822	25899	{"_key": 25899, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Mila.png"}
3823	25900	{"_key": 25900, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Paladin Crusader.png"}
3824	25901	{"_key": 25901, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Pomik.png"}
3825	25903	{"_key": 25903, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Thukker Analyst.png"}
3826	25904	{"_key": 25904, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Tribal Prophet.png"}
3827	25905	{"_key": 25905, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Viola.png"}
3828	25906	{"_key": 25906, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Prospector.png"}
3829	25907	{"_key": 25907, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Material_I.png"}
3830	25908	{"_key": 25908, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Material_II.png"}
3831	25909	{"_key": 25909, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/MATRIXISK.png"}
3832	25911	{"_key": 25911, "iconFile": "res:/ui/texture/AmplificationMatrix/TypeIcon/Aura.png"}
3833	25913	{"_key": 25913, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Academy Instructor.png"}
3834	25914	{"_key": 25914, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Ameline.png"}
3835	25915	{"_key": 25915, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Angel Villain.png"}
3836	25916	{"_key": 25916, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Aura.png"}
3837	25917	{"_key": 25917, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Blood Raider Maniac.png"}
3838	25918	{"_key": 25918, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Camoul.png"}
3839	25919	{"_key": 25919, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Concord Overseer.png"}
3840	25920	{"_key": 25920, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Council Priest.png"}
3841	25921	{"_key": 25921, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/DefaultImage.png"}
3842	25922	{"_key": 25922, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Duvolle Researcher.png"}
3843	25923	{"_key": 25923, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Engineer.png"}
3844	25924	{"_key": 25924, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Federation Minuteman.png"}
3845	25925	{"_key": 25925, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Torkebaira.png"}
3846	25926	{"_key": 25926, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Guristas Veteran.png"}
3847	25927	{"_key": 25927, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Hayden.png"}
3848	25928	{"_key": 25928, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Ishukone Technician.png"}
3849	25929	{"_key": 25929, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Jill.png"}
3850	25930	{"_key": 25930, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Karth.png"}
3851	25931	{"_key": 25931, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Mila.png"}
3852	25932	{"_key": 25932, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Paladin Crusader.png"}
3853	25933	{"_key": 25933, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Pomik.png"}
3854	25934	{"_key": 25934, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Prospector.png"}
3855	25935	{"_key": 25935, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Thukker Analyst.png"}
3856	25936	{"_key": 25936, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Tribal Prophet.png"}
3857	25937	{"_key": 25937, "iconFile": "res:/ui/texture/AmplificationMatrix/Fragments Icon/Viola.png"}
3858	25940	{"_key": 25940, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/AMARR.png"}
3859	25941	{"_key": 25941, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Angel.png"}
3860	25942	{"_key": 25942, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Caldari.png"}
3861	25943	{"_key": 25943, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Gallente.png"}
3862	25944	{"_key": 25944, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Guristas.png"}
3863	25945	{"_key": 25945, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Minmatar.png"}
3864	25946	{"_key": 25946, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Mordus.png"}
3865	25947	{"_key": 25947, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/ORE.png"}
3866	25948	{"_key": 25948, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/ISHUKUNE.png"}
3867	25979	{"_key": 25979, "iconFile": "res:/UI/Texture/AmplificationMatrix/Fragments Icon/ORE.png"}
3868	25980	{"_key": 25980, "iconFile": "res:/UI/Texture/AmplificationMatrix/Fragments Icon/Angel.png"}
3869	25981	{"_key": 25981, "iconFile": "res:/UI/Texture/AmplificationMatrix/Fragments Icon/Mordus.png"}
3870	25982	{"_key": 25982, "iconFile": "res:/UI/Texture/AmplificationMatrix/Fragments Icon/Guristas.png"}
3871	25983	{"_key": 25983, "iconFile": "res:/UI/Texture/AmplificationMatrix/Fragments Icon/AMARR.png"}
3872	25984	{"_key": 25984, "iconFile": "res:/UI/Texture/AmplificationMatrix/Fragments Icon/Caldari.png"}
3873	25985	{"_key": 25985, "iconFile": "res:/UI/Texture/AmplificationMatrix/Fragments Icon/Gallente.png"}
3874	25986	{"_key": 25986, "iconFile": "res:/UI/Texture/AmplificationMatrix/Fragments Icon/Minmatar.png"}
3875	25987	{"_key": 25987, "iconFile": "res:/UI/Texture/AmplificationMatrix/Fragments Icon/ISHUKUNE.png"}
3876	25989	{"_key": 25989, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Matrix_ticket.png", "iconType": "png"}
3877	25990	{"_key": 25990, "iconFile": "res:/ui/texture/icons/202402dragon1.png", "iconType": "png"}
3878	25991	{"_key": 25991, "iconFile": "res:/ui/texture/icons/202402dragon2.png", "iconType": "png"}
3879	25992	{"_key": 25992, "iconFile": "res:/ui/texture/icons/YC126YearCardBigShipBox.png", "iconType": "png"}
3880	25993	{"_key": 25993, "iconFile": "res:/ui/texture/icons/YC126YearCardSmallShipBox.png", "iconType": "png"}
3881	25994	{"_key": 25994, "iconFile": "res:/ui/texture/icons/10_64_17.png"}
3882	25995	{"_key": 25995, "iconFile": "res:/UI/Texture/bluebird/currency/neuro.png"}
3883	25996	{"_key": 25996, "iconFile": "res:/UI/Texture/bluebird/currency/tube.png"}
3884	25997	{"_key": 25997, "iconFile": "res:/UI/Texture/bluebird/blue_bird_icon.png"}
3885	25998	{"_key": 25998, "iconFile": "res:/ui/texture/icons/43_64_12_n.png"}
3886	26002	{"_key": 26002, "iconFile": "res:/ui/texture/icons/10_64_18.png"}
3887	26004	{"_key": 26004, "iconFile": "res:/ui/texture/icons/129_reagentice_64.png"}
3888	26005	{"_key": 26005, "iconFile": "res:/ui/texture/icons/129_reagentlava_64.png"}
3889	26007	{"_key": 26007, "iconFile": "res:/UI/Texture/Classes/CloneGrade/Omega_64.png"}
3890	26008	{"_key": 26008, "iconFile": "res:/UI/Texture/AmplificationMatrix/Fragments Icon/Souro Foiritan.png"}
3891	26009	{"_key": 26009, "iconFile": "res:/UI/Texture/AmplificationMatrix/TypeIcon/Souro Foiritan.png"}
3892	26010	{"_key": 26010, "iconFile": "res:/ui/texture/icons/Matrix_Gacha_Ticket_up_240328.png", "iconType": "png"}
3893	26013	{"_key": 26013, "iconFile": "res:/ui/texture/icons/Carbon_Nanotube_Frame_Ticket.png", "iconType": "png"}
3894	26014	{"_key": 26014, "iconFile": "res:/ui/texture/icons/Silicon_Neuron_Ticket.png", "iconType": "png"}
3895	26016	{"_key": 26016, "iconFile": "res:/UI/Texture/Icons/Inventory/abyssalBattlefieldFilamentL1.png"}
3896	26017	{"_key": 26017, "iconFile": "res:/UI/Texture/Icons/Inventory/abyssalBattlefieldFilamentL2.png"}
3897	26018	{"_key": 26018, "iconFile": "res:/UI/Texture/Icons/Inventory/abyssalBattlefieldFilamentL3.png"}
3898	26019	{"_key": 26019, "iconFile": "res:/UI/Texture/Icons/Inventory/abyssalBattlefieldFilamentL4.png"}
3899	26020	{"_key": 26020, "iconFile": "res:/ui/texture/icons/green_bird_chameleon_coin.png", "iconType": "png"}
3900	26021	{"_key": 26021, "iconFile": "res:/ui/texture/icons/green_dragon_gacha.png", "iconType": "png"}
3901	26025	{"_key": 26025, "iconFile": "res:/UI/Asset/mannequin/bottomouter/82040_Female_bottomOuter_PantsALF_01_Types_PantsALF_01_jeansblue.png", "iconType": "png"}
3902	26026	{"_key": 26026, "iconFile": "res:/UI/Asset/mannequin/bottomouter/82041_Male_bottomOuter_PantsMilM01_Types_PantsMilM01_jeansblue.png", "iconType": "png"}
3903	26027	{"_key": 26027, "iconFile": "res:/ui/texture/icons/green_dragon_super_gacha.png", "iconType": "png"}
3904	26038	{"_key": 26038, "iconFile": "res:/ui/texture/icons/pirateshipneurolinks/angel_neurolink_64.png"}
3905	26039	{"_key": 26039, "iconFile": "res:/ui/texture/icons/pirateshipneurolinks/bloodraider_neurolink_64.png"}
3906	26040	{"_key": 26040, "iconFile": "res:/ui/texture/icons/pirateshipneurolinks/guristas_neurolink_64.png"}
3907	26041	{"_key": 26041, "iconFile": "res:/ui/texture/icons/pirateshipneurolinks/morduslegion_neurolink_64.png"}
3908	26042	{"_key": 26042, "iconFile": "res:/ui/texture/icons/pirateshipneurolinks/sansha_neurolink_64.png"}
3909	26043	{"_key": 26043, "iconFile": "res:/ui/texture/icons/pirateshipneurolinks/serpentis_neurolink_64.png"}
3910	26044	{"_key": 26044, "iconFile": "res:/ui/texture/icons/pirateshipneurolinks/soe_neurolink_64.png"}
3911	26045	{"_key": 26045, "iconFile": "res:/ui/texture/icons/Inventory/20230425_mountain.png", "iconType": "png"}
3912	26046	{"_key": 26046, "iconFile": "res:/ui/texture/icons/workday.png"}
3913	26048	{"_key": 26048, "iconFile": "res:/UI/Texture/Icons/Inventory/resource_icon_alignment_64.png"}
3914	26049	{"_key": 26049, "iconFile": "res:/UI/Texture/Icons/Inventory/resource_icon_fermonics_64.png"}
3915	26050	{"_key": 26050, "iconFile": "res:/UI/Texture/Icons/Inventory/resource_icon_Kerr_64.png"}
3916	26051	{"_key": 26051, "iconFile": "res:/ui/texture/icons/inventory/resource_icon_bulk_64.png"}
3917	26052	{"_key": 26052, "iconFile": "res:/UI/Texture/Icons/Inventory/metallic_64.png"}
3918	26053	{"_key": 26053, "iconFile": "res:/UI/Texture/Icons/Inventory/nanocoating_64.png"}
3919	26054	{"_key": 26054, "iconFile": "res:/UI/Texture/Icons/Inventory/pattern_64.png"}
3920	26055	{"_key": 26055, "iconFile": "res:/UI/Texture/Icons/Inventory/resource_icon_bulk_64.png"}
3921	26056	{"_key": 26056, "iconFile": "res:/UI/Texture/Icons/SKINR.png"}
3922	26058	{"_key": 26058, "iconFile": "res:/ui/texture/icons/YC126buildingskinchips.png", "iconType": "png"}
3923	26059	{"_key": 26059, "iconFile": "res:/ui/texture/icons/YC126buildingskinbox.png", "iconType": "png"}
3924	26062	{"_key": 26062, "iconFile": "res:/UI/Texture/eveicon/category_icons/sov_hub_32px.png"}
3925	26063	{"_key": 26063, "iconFile": "res:/UI/Texture/eveicon/category_icons/skyhook_32px.png"}
3926	26064	{"_key": 26064, "iconFile": "res:/UI/Texture/eveicon/category_icons/reagents_skyhook_32px.png"}
3927	26065	{"_key": 26065, "iconFile": "res:/UI/Texture/eveicon/category_icons/auto_moon_miner_32px.png"}
3928	26066	{"_key": 26066, "iconFile": "res:/ui/texture/icons/whiptailcoin.png", "iconType": "png"}
3929	26067	{"_key": 26067, "iconFile": "res:/ui/texture/icons/whiptailbox.png", "iconType": "png"}
3930	26068	{"_key": 26068, "iconFile": "res:/ui/texture/icons/whiptailsuperbox.png", "iconType": "png"}
3931	26069	{"_key": 26069, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_blue_metallic_000_080_100.png"}
3932	26070	{"_key": 26070, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_grape_satin_000_100_100.png"}
3933	26071	{"_key": 26071, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_green_satin_000_100_050.png"}
3934	26072	{"_key": 26072, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_lavender_satin_000_100_050.png"}
3935	26073	{"_key": 26073, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_orange_satin_000_080_100.png"}
3936	26074	{"_key": 26074, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_orange_satin_000_100_010.png"}
3937	26075	{"_key": 26075, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_orange_satin_000_100_100.png"}
3938	26076	{"_key": 26076, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_plum_satin_000_100_010.png"}
3939	26077	{"_key": 26077, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_purple_satin_000_100_050.png"}
3940	26078	{"_key": 26078, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_red_satin_000_080_100.png"}
3941	26079	{"_key": 26079, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_red_satin_000_100_010.png"}
3942	26080	{"_key": 26080, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_red_satin_000_100_100.png"}
3943	26081	{"_key": 26081, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_redorange_satin_000_100_100.png"}
3944	26082	{"_key": 26082, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_rosered_satin_000_080_100.png"}
3945	26083	{"_key": 26083, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_royal_satin_000_060_100.png"}
3946	26084	{"_key": 26084, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_royal_satin_000_100_010.png"}
3947	26085	{"_key": 26085, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_turmeric_satin_000_100_100.png"}
3948	26086	{"_key": 26086, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_violet_satin_000_060_100.png"}
3949	26087	{"_key": 26087, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_brass_rough_013_051_089.png"}
3950	26088	{"_key": 26088, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_azure_gloss_000_100_100.png"}
3951	26089	{"_key": 26089, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_berry_gloss_000_100_100.png"}
3952	26090	{"_key": 26090, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_blue_gloss_000_080_100.png"}
3953	26091	{"_key": 26091, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_blue_gloss_000_100_001.png"}
3954	26092	{"_key": 26092, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_blue_gloss_000_100_050.png"}
3955	26093	{"_key": 26093, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_bw_gloss_000_000_000.png"}
3956	26094	{"_key": 26094, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_bw_gloss_000_000_030.png"}
3957	26095	{"_key": 26095, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_bw_gloss_000_000_100.png"}
3958	26096	{"_key": 26096, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_chartreuse_gloss_000_100_001.png"}
3959	26097	{"_key": 26097, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_cherryred_gloss_000_100_050.png"}
3960	26098	{"_key": 26098, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_clover_gloss_000_100_100.png"}
3961	26099	{"_key": 26099, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_cyan_gloss_000_100_100.png"}
3962	26100	{"_key": 26100, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_grape_gloss_000_100_010.png"}
3963	26101	{"_key": 26101, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_grape_gloss_000_100_100.png"}
3964	26102	{"_key": 26102, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_green_gloss_000_100_050.png"}
3965	26103	{"_key": 26103, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_lavender_gloss_000_100_050.png"}
3966	26104	{"_key": 26104, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_orange_gloss_000_080_100.png"}
3967	26105	{"_key": 26105, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_orange_gloss_000_100_010.png"}
3968	26106	{"_key": 26106, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_orange_gloss_000_100_100.png"}
3969	26107	{"_key": 26107, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_plum_gloss_000_100_010.png"}
3970	26108	{"_key": 26108, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_purple_gloss_000_100_050.png"}
3971	26109	{"_key": 26109, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_red_gloss_000_080_100.png"}
3972	26110	{"_key": 26110, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_red_gloss_000_100_010.png"}
3973	26111	{"_key": 26111, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_red_gloss_000_100_100.png"}
3974	26112	{"_key": 26112, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_redorange_gloss_000_100_100.png"}
3975	26113	{"_key": 26113, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_rosered_gloss_000_080_100.png"}
3976	26114	{"_key": 26114, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_royal_gloss_000_060_100.png"}
3977	26115	{"_key": 26115, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_royal_gloss_000_100_010.png"}
3978	26116	{"_key": 26116, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_turmeric_gloss_000_100_100.png"}
3979	26117	{"_key": 26117, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_violet_gloss_000_060_100.png"}
3980	26118	{"_key": 26118, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_bw_brushed_000_000_030.png"}
3981	26119	{"_key": 26119, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_cherryred_brushed_000_100_001.png"}
3982	26120	{"_key": 26120, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_cobalt_polished_023_004_070.png"}
3983	26121	{"_key": 26121, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_gold_polished_012_060_094.png"}
3984	26122	{"_key": 26122, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_lavender_brushed_000_100_050.png"}
3985	26123	{"_key": 26123, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_pea_metallic_000_100_010.png"}
3986	26124	{"_key": 26124, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_rosered_brushed_000_030_100.png"}
3987	26125	{"_key": 26125, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_turquoise_polished_000_100_001.png"}
3988	26126	{"_key": 26126, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/patterns/cosm_AngledStripe_01_128.png"}
3989	26127	{"_key": 26127, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/patterns/cosm_Camo_01_128.png"}
3990	26128	{"_key": 26128, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/patterns/cosm_Camo_Dazzle_02_128.png"}
3991	26129	{"_key": 26129, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/patterns/cosm_Checker_01_128.png"}
3992	26130	{"_key": 26130, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/patterns/cosm_Curves_01_128.png"}
3993	26131	{"_key": 26131, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/patterns/cosm_Gradient_128.png"}
3994	26132	{"_key": 26132, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/patterns/cosm_Gradient_Crystal_128.png"}
3995	26133	{"_key": 26133, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/patterns/cosm_gradient_random_square_128.png"}
3996	26134	{"_key": 26134, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/patterns/cosm_Halfcut_Stripes_14_128.png"}
3997	26135	{"_key": 26135, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/patterns/cosm_Hex_Hex_128.png"}
3998	26136	{"_key": 26136, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/patterns/cosm_Paint_Rough_01_128.png"}
3999	26137	{"_key": 26137, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/patterns/cosm_rustGradient_02_128.png"}
4000	26138	{"_key": 26138, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/patterns/cosm_Squares_01_128.png"}
4001	26139	{"_key": 26139, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_azure_matt_000_100_010.png"}
4002	26140	{"_key": 26140, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_azure_matt_000_100_100.png"}
4003	26141	{"_key": 26141, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_berry_matt_000_100_100.png"}
4004	26142	{"_key": 26142, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_blue_matt_000_080_100.png"}
4005	26143	{"_key": 26143, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_blue_matt_000_100_001.png"}
4006	26144	{"_key": 26144, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_blue_matt_000_100_050.png"}
4007	26145	{"_key": 26145, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_bw_matt_000_000_000.png"}
4008	26146	{"_key": 26146, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_bw_matt_000_000_030.png"}
4009	26147	{"_key": 26147, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_bw_matt_000_000_100.png"}
4010	26148	{"_key": 26148, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_chartreuse_matt_000_100_001.png"}
4011	26149	{"_key": 26149, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_cherryred_matt_000_100_050.png"}
4012	26150	{"_key": 26150, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_clover_matt_000_100_100.png"}
4013	26151	{"_key": 26151, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_cyan_matt_000_100_100.png"}
4014	26152	{"_key": 26152, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_grape_matt_000_100_010.png"}
4015	26153	{"_key": 26153, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_grape_matt_000_100_100.png"}
4016	26154	{"_key": 26154, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_green_matt_000_100_050.png"}
4017	26155	{"_key": 26155, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_lavender_matt_000_100_050.png"}
4018	26156	{"_key": 26156, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_orange_matt_000_080_100.png"}
4019	26157	{"_key": 26157, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_orange_matt_000_100_010.png"}
4020	26158	{"_key": 26158, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_orange_matt_000_100_100.png"}
4021	26159	{"_key": 26159, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_plum_matt_000_100_010.png"}
4022	26160	{"_key": 26160, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_purple_matt_000_100_050.png"}
4023	26161	{"_key": 26161, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_red_matt_000_080_100.png"}
4024	26162	{"_key": 26162, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_red_matt_000_100_010.png"}
4025	26163	{"_key": 26163, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_red_matt_000_100_100.png"}
4026	26164	{"_key": 26164, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_redorange_matt_000_100_100.png"}
4027	26165	{"_key": 26165, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_rosered_matt_000_080_100.png"}
4028	26166	{"_key": 26166, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_royal_matt_000_060_100.png"}
4029	26167	{"_key": 26167, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_royal_matt_000_100_010.png"}
4030	26168	{"_key": 26168, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_turmeric_matt_000_100_100.png"}
4031	26169	{"_key": 26169, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_violet_matt_000_060_100.png"}
4032	26170	{"_key": 26170, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_azure_satin_000_100_010.png"}
4033	26171	{"_key": 26171, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_azure_satin_000_100_100.png"}
4034	26172	{"_key": 26172, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_berry_satin_000_100_100.png"}
4035	26173	{"_key": 26173, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_blue_satin_000_080_100.png"}
4036	26174	{"_key": 26174, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_blue_satin_000_100_001.png"}
4037	26175	{"_key": 26175, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_blue_satin_000_100_050.png"}
4038	26176	{"_key": 26176, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_bw_satin_000_000_000.png"}
4039	26177	{"_key": 26177, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_bw_satin_000_000_030.png"}
4040	26178	{"_key": 26178, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_bw_satin_000_000_100.png"}
4041	26179	{"_key": 26179, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_chartreuse_satin_000_100_001.png"}
4042	26180	{"_key": 26180, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_cherryred_satin_000_100_050.png"}
4043	26181	{"_key": 26181, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_clover_satin_000_100_100.png"}
4044	26182	{"_key": 26182, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_cyan_satin_000_100_100.png"}
4045	26183	{"_key": 26183, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_grape_satin_000_100_010.png"}
4046	26184	{"_key": 26184, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_azure_gloss_000_100_010.png"}
4047	26200	{"_key": 26200, "iconFile": "res:/ui/texture/icons/inventory/CareerPortal/loot_crate64_air.png"}
4048	26201	{"_key": 26201, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_royalpurple_gloss_072_061_065.png"}
4049	26202	{"_key": 26202, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_royalpurple_matt_072_061_065.png"}
4050	26203	{"_key": 26203, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_royalpurple_satin_072_061_065.png"}
4051	26205	{"_key": 26205, "iconFile": "res:/ui/texture/icons/DziewannaTicket.png", "iconType": "png"}
4052	26206	{"_key": 26206, "iconFile": "res:/ui/texture/icons/DziewannaChip.png", "iconType": "png"}
4053	26207	{"_key": 26207, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_emerald_matt_000_060_100.png"}
4054	26208	{"_key": 26208, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_redorange_matt_000_100_050.png"}
4055	26209	{"_key": 26209, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_emerald_metallic_000_100_001.png"}
4056	26210	{"_key": 26210, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/race_gallente_02a_128.png"}
4057	26211	{"_key": 26211, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/race_gallente_01a_128.png"}
4058	26212	{"_key": 26212, "iconFile": "res:/ui/texture/icons/victorcoin.png", "iconType": "png"}
4059	26213	{"_key": 26213, "iconFile": "res:/ui/texture/icons/victorbox.png", "iconType": "png"}
4060	26214	{"_key": 26214, "iconFile": "res:/ui/texture/icons/victorsuperbox.png", "iconType": "png"}
4061	26215	{"_key": 26215, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_cherryred_satin_000_100_010.png"}
4062	26216	{"_key": 26216, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_cherryred_satin_000_030_100.png"}
4063	26217	{"_key": 26217, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_cherryred_metallic_000_100_010.png"}
4064	26218	{"_key": 26218, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_cherryred_metallic_000_100_010.png"}
4065	26219	{"_key": 26219, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_cherryred_metallic_000_100_010.png"}
4066	26220	{"_key": 26220, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_cherryred_metallic_000_100_010.png"}
4067	26221	{"_key": 26221, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_cherryred_metallic_000_100_010.png"}
4068	26222	{"_key": 26222, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_cherryred_metallic_000_100_010.png"}
4069	26223	{"_key": 26223, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_cherryred_metallic_000_100_010.png"}
4070	26224	{"_key": 26224, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/component_items/materials/cosm_cherryred_metallic_000_100_010.png"}
4071	26229	{"_key": 26229, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_brushed_000_080_100.png"}
4072	26230	{"_key": 26230, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_rough_000_100_050.png"}
4073	26231	{"_key": 26231, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_satin_000_060_100.png"}
4074	26232	{"_key": 26232, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/Pattern_Min_Lvl1_01a_128.png"}
4075	26233	{"_key": 26233, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_rosered_matt_000_100_010.png"}
4076	26234	{"_key": 26234, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cherryred_satin_000_030_100.png"}
4077	26235	{"_key": 26235, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cherryred_metallic_000_100_010.png"}
4078	26236	{"_key": 26236, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/Pattern_Ama_Lvl1_01a_128.png"}
4079	26237	{"_key": 26237, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turmeric_metallic_000_080_100.png"}
4080	26238	{"_key": 26238, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turmeric_gloss_000_080_100.png"}
4081	26239	{"_key": 26239, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turmeric_gloss_000_100_001.png"}
4082	26240	{"_key": 26240, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/Pattern_Cal_Lvl1_01a_128.png"}
4083	26241	{"_key": 26241, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_polished_000_060_100.png"}
4084	26243	{"_key": 26243, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_gloss_000_030_100.png"}
4085	26244	{"_key": 26244, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_matt_000_100_100.png"}
4086	26245	{"_key": 26245, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_gloss_000_100_001.png"}
4087	26246	{"_key": 26246, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/Pattern_Min_Lvl1_02a_128.png"}
4088	26248	{"_key": 26248, "iconFile": "res:/UI/Texture/Icons/Inventory/triglavianEncryptedData.png"}
4089	26249	{"_key": 26249, "iconFile": "res:/ui/texture/icons/68_64_17.png"}
4090	26252	{"_key": 26252, "iconFile": "res:/ui/texture/icons/Inventory/YC126.8YearCardBigShipBox.png", "iconType": "png"}
4091	26253	{"_key": 26253, "iconFile": "res:/ui/texture/icons/Inventory/YC126.8YearCardSmallShipBox.png", "iconType": "png"}
4092	26255	{"_key": 26255, "iconFile": "res:/ui/texture/icons/130_SES1_64.png"}
4093	26256	{"_key": 26256, "iconFile": "res:/ui/texture/icons/130_SES3_64.png"}
4094	26257	{"_key": 26257, "iconFile": "res:/ui/texture/icons/130_SES2_64.png"}
4095	26258	{"_key": 26258, "iconFile": "res:/ui/texture/icons/YC126_7UP_chocolate.png", "iconType": "png"}
4096	26261	{"_key": 26261, "iconFile": "res:/ui/texture/icons/Alpha_Race_Logo.png"}
4097	26262	{"_key": 26262, "iconFile": "res:/ui/texture/icons/AlphaCity/processor.png"}
4098	26263	{"_key": 26263, "iconFile": "res:/ui/texture/icons/AlphaCity/reactor.png"}
4099	26264	{"_key": 26264, "iconFile": "res:/ui/texture/icons/AlphaCity/shield.png"}
4100	26265	{"_key": 26265, "iconFile": "res:/ui/texture/icons/AlphaCity/thruster.png"}
4101	26266	{"_key": 26266, "iconFile": "res:/UI/Texture/Icons/Inventory/Abyssal_Salvage_Crate_64.png", "iconType": "png"}
4102	26267	{"_key": 26267, "iconFile": "res:/ui/texture/icons/YC126.8aeroplanechip.png", "iconType": "png"}
4103	26268	{"_key": 26268, "iconFile": "res:/ui/texture/icons/YC126.8buildingskinchip.png", "iconType": "png"}
4104	26269	{"_key": 26269, "iconFile": "res:/ui/texture/icons/YC12608buildingskinsurprisebox.png", "iconType": "png"}
4105	26270	{"_key": 26270, "iconFile": "res:/ui/texture/icons/202408aeroplanecarbon.png", "iconType": "png"}
4106	26274	{"_key": 26274, "iconFile": "res:/UI/Texture/Classes/HelpPointer/agencyCardFlat.png", "iconType": "png"}
4107	26275	{"_key": 26275, "iconFile": "res:/UI/Texture/Classes/HelpPointer/buttonFlat.png", "iconType": "png"}
4108	26276	{"_key": 26276, "iconFile": "res:/UI/Texture/Classes/HelpPointer/genericCardFlat.png", "iconType": "png"}
4109	26277	{"_key": 26277, "iconFile": "res:/UI/Texture/Classes/HelpPointer/skillCardFlat.png", "iconType": "png"}
4110	26278	{"_key": 26278, "iconFile": "res:/UI/Texture/Classes/HelpPointer/tabFlat.png", "iconType": "png"}
4111	26279	{"_key": 26279, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cherryred_gloss_000_100_010.png"}
4112	26280	{"_key": 26280, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cherryred_matt_000_100_010.png"}
4113	26281	{"_key": 26281, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_red_gloss_000_100_050.png"}
4114	26282	{"_key": 26282, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cherryred_satin_000_100_001.png"}
4115	26283	{"_key": 26283, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_red_satin_000_100_050.png"}
4116	26284	{"_key": 26284, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cherryred_satin_000_100_100.png"}
4117	26285	{"_key": 26285, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_orange_vibrant_bright_matt_21_79_80.png"}
4118	26286	{"_key": 26286, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_pea_gloss_000_100_100.png"}
4119	26287	{"_key": 26287, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_pale_bright_matt_177_12_65.png"}
4120	26288	{"_key": 26288, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_red_vibrant_bright_satin_14_94_100.png"}
4121	26289	{"_key": 26289, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/scatter_flat_01_128.png"}
4122	26290	{"_key": 26290, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/blood_skull_01_128.png"}
4123	26291	{"_key": 26291, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_bw_metallic_000_000_010.png"}
4124	26292	{"_key": 26292, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_lavender_metallic_000_100_001.png"}
4125	26293	{"_key": 26293, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_violet_metallic_000_100_010.png"}
4126	26294	{"_key": 26294, "iconFile": "res:/ui/texture/icons/Tiamat_Coin.png", "iconType": "png"}
4127	26295	{"_key": 26295, "iconFile": "res:/ui/texture/icons/Tiamat_Insurance.png", "iconType": "png"}
4128	26296	{"_key": 26296, "iconFile": "res:/ui/texture/icons/Tiamat Gacha.png", "iconType": "png"}
4129	26297	{"_key": 26297, "iconFile": "res:/ui/texture/icons/Tiamat_Super_Gacha.png", "iconType": "png"}
4130	26298	{"_key": 26298, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_ASES_Line_02_128.png"}
4131	26299	{"_key": 26299, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_ASES_Square_128.png"}
4132	26300	{"_key": 26300, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Camo_Dazzle_01_128.png"}
4133	26301	{"_key": 26301, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Camo_NOH_128.png"}
4134	26302	{"_key": 26302, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Ch19_countdown_arrows_128.png"}
4135	26303	{"_key": 26303, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Checker_02_128.png"}
4136	26304	{"_key": 26304, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Circles_Stripes_04_128.png"}
4137	26305	{"_key": 26305, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Cross_05_128.png"}
4138	26306	{"_key": 26306, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Diamond_Lines_128.png"}
4139	26307	{"_key": 26307, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Gradient_04_128.png"}
4140	26308	{"_key": 26308, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Gradient_Crystal_128.png"}
4141	26309	{"_key": 26309, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Gradient_Hex_01_128.png"}
4142	26310	{"_key": 26310, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tile_hexagon_01_128.png"}
4143	26311	{"_key": 26311, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Gradient_Hex_03_128.png"}
4144	26312	{"_key": 26312, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tile_hexagon_02_128.png"}
4145	26313	{"_key": 26313, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gradient_hexagon_128.png"}
4146	26314	{"_key": 26314, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gradient_circle_01_128.png"}
4147	26315	{"_key": 26315, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Gradient_Spheres_03_128.png"}
4148	26316	{"_key": 26316, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Gradient_Star_01_128.png"}
4149	26317	{"_key": 26317, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Halfcut_Asteroids_01_128.png"}
4150	26318	{"_key": 26318, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Halfcut_Stripes_01_128.png"}
4151	26319	{"_key": 26319, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Halfcut_Stripes_03_128.png"}
4152	26320	{"_key": 26320, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Halfcut_Stripes_05_128.png"}
4153	26321	{"_key": 26321, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Halfcut_Stripes_12_128.png"}
4154	26322	{"_key": 26322, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Halfcut_Stripes_27_128.png"}
4155	26323	{"_key": 26323, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Halfcut_Stripes_32_128.png"}
4156	26324	{"_key": 26324, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Halfcut_Stripes_34_128.png"}
4157	26325	{"_key": 26325, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Halfcut_Stripes_36_128.png"}
4158	26326	{"_key": 26326, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Halfcut_Stripes_37_128.png"}
4159	26327	{"_key": 26327, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_hexagon_01_128.png"}
4160	26329	{"_key": 26329, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_hexagon_02_128.png"}
4161	26330	{"_key": 26330, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tile_hexagon_03_128.png"}
4162	26331	{"_key": 26331, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Hexes_Stripe_01_128.png"}
4163	26332	{"_key": 26332, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_petal_pattern_01_128.png"}
4164	26333	{"_key": 26333, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Pinstripe_01_128.png"}
4165	26334	{"_key": 26334, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_random_hardedges_05_128.png"}
4166	26335	{"_key": 26335, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_random_hardedgeshape_04_128.png"}
4167	26336	{"_key": 26336, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Snowfall_01_128.png"}
4168	26337	{"_key": 26337, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_SOE_unity_02_128.png"}
4169	26338	{"_key": 26338, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Stripe_04_128.png"}
4170	26339	{"_key": 26339, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Stripe_Double_09_128.png"}
4171	26340	{"_key": 26340, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Stripe_union_day_02_128.png"}
4172	26341	{"_key": 26341, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tiger_01_128.png"}
4173	26342	{"_key": 26342, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_element_wing_01_128.png"}
4174	26343	{"_key": 26343, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_Wedge_05_128.png"}
4175	26344	{"_key": 26344, "iconFile": "res:/ui/texture/icons/35_64_7.png"}
4176	26345	{"_key": 26345, "iconFile": "res:/ui/texture/icons/8_64_16.png"}
4177	26346	{"_key": 26346, "iconFile": "res:/ui/texture/icons/25_64_15.png"}
4178	26351	{"_key": 26351, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_redorange_gloss_000_100_050.png"}
4179	26352	{"_key": 26352, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_bw_satin_000_000_010.png"}
4180	26353	{"_key": 26353, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_yellow_matt_000_100_100.png"}
4181	26354	{"_key": 26354, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cherryred_metallic_000_100_001.png"}
4182	26355	{"_key": 26355, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/scatter_depth_01_128.png"}
4183	26356	{"_key": 26356, "iconFile": "res:/ui/texture/icons/131_atavum_1_64.png"}
4184	26357	{"_key": 26357, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_orange_matt_000_100_001.png"}
4185	26358	{"_key": 26358, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_safetyorange_matt_000_060_100.png"}
4186	26359	{"_key": 26359, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_purple_metallic_000_100_010.png"}
4187	26360	{"_key": 26360, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gradient_tickets_01_128.png"}
4188	26361	{"_key": 26361, "iconFile": "res:/ui/texture/icons/YC126.9marshall.png", "iconType": "png"}
4189	26371	{"_key": 26371, "iconFile": "res:/UI/Texture/Icons/132_infomorph_64.png"}
4190	26372	{"_key": 26372, "iconFile": "res:/ui/texture/icons/breacher_pod_small_64.png"}
4191	26373	{"_key": 26373, "iconFile": "res:/ui/texture/icons/breacher_pod_medium_64.png"}
4192	26374	{"_key": 26374, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cherryred_gloss_000_100_100.png"}
4193	26375	{"_key": 26375, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_bw_pale_dark_satin_0_0_5.png"}
4194	26376	{"_key": 26376, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_gloss_000_080_100.png"}
4195	26377	{"_key": 26377, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_blue_metallic_000_100_010.png"}
4196	26378	{"_key": 26378, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_eclipse_01_128.png"}
4197	26380	{"_key": 26380, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_blue_matt_000_030_100.png"}
4198	26381	{"_key": 26381, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_blue_matt_000_100_010.png"}
4199	26382	{"_key": 26382, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_blue_matt_000_100_100.png"}
4200	26383	{"_key": 26383, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_blue_satin_000_060_100.png"}
4201	26384	{"_key": 26384, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_blue_satin_000_100_010.png"}
4202	26385	{"_key": 26385, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_blue_satin_000_100_100.png"}
4203	26386	{"_key": 26386, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_blue_gloss_000_030_100.png"}
4204	26387	{"_key": 26387, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_blue_gloss_000_060_100.png"}
4205	26388	{"_key": 26388, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_gloss_000_100_100.png"}
4206	26389	{"_key": 26389, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_gloss_000_080_100.png"}
4207	26390	{"_key": 26390, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_metallic_000_100_010.png"}
4208	26391	{"_key": 26391, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_malachite_metallic_000_080_100.png"}
4209	26392	{"_key": 26392, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_metallic_000_060_100.png"}
4210	26393	{"_key": 26393, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/Pattern_WN2024_02_128.png"}
4211	26394	{"_key": 26394, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/Pattern_WN2024_03_128.png"}
4212	26395	{"_key": 26395, "iconFile": "res:/ui/texture/icons/modules/breacher_launcher_S_64.png"}
4213	26396	{"_key": 26396, "iconFile": "res:/ui/texture/icons/modules/breacher_launcher_M_64.png"}
4214	26397	{"_key": 26397, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_blue_gloss_000_100_100.png"}
4215	26398	{"_key": 26398, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_pale_bright_satin_177_12_65.png"}
4216	26399	{"_key": 26399, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_red_metallic_000_100_050.png"}
4217	26400	{"_key": 26400, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_lavender_matt_000_080_100.png"}
4218	26401	{"_key": 26401, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/Pattern_WN2024_01_128.png"}
4219	26402	{"_key": 26402, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_red_vibrant_bright_satin_0_95_80.png"}
4220	26403	{"_key": 26403, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_satin_000_100_001.png"}
4221	26404	{"_key": 26404, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_redorange_metallic_000_100_100.png"}
4222	26406	{"_key": 26406, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_moneyfriday_01_128.png"}
4223	26409	{"_key": 26409, "iconFile": "res:/ui/texture/icons/Inventory/BluePill_64.png"}
4224	26410	{"_key": 26410, "iconFile": "res:/ui/texture/icons/Inventory/BluePill_64_1.png"}
4225	26411	{"_key": 26411, "iconFile": "res:/ui/texture/icons/Inventory/BluePill_64_2.png"}
4226	26412	{"_key": 26412, "iconFile": "res:/ui/texture/icons/Inventory/BluePill_64_3.png"}
4227	26413	{"_key": 26413, "iconFile": "res:/ui/texture/icons/Inventory/BluePill_64_4.png"}
4228	26414	{"_key": 26414, "iconFile": "res:/ui/texture/icons/Inventory/Crash_64.png"}
4229	26415	{"_key": 26415, "iconFile": "res:/ui/texture/icons/Inventory/Crash_64_1.png"}
4230	26416	{"_key": 26416, "iconFile": "res:/ui/texture/icons/Inventory/Crash_64_2.png"}
4231	26417	{"_key": 26417, "iconFile": "res:/ui/texture/icons/Inventory/Crash_64_3.png"}
4232	26418	{"_key": 26418, "iconFile": "res:/ui/texture/icons/Inventory/Crash_64_4.png"}
4233	26419	{"_key": 26419, "iconFile": "res:/ui/texture/icons/Inventory/Drop_64.png"}
4234	26420	{"_key": 26420, "iconFile": "res:/ui/texture/icons/Inventory/Drop_64_1.png"}
4235	26421	{"_key": 26421, "iconFile": "res:/ui/texture/icons/Inventory/Drop_64_2.png"}
4236	26422	{"_key": 26422, "iconFile": "res:/ui/texture/icons/Inventory/Drop_64_3.png"}
4237	26423	{"_key": 26423, "iconFile": "res:/ui/texture/icons/Inventory/Drop_64_4.png"}
4238	26424	{"_key": 26424, "iconFile": "res:/ui/texture/icons/Inventory/Exile_64.png"}
4239	26425	{"_key": 26425, "iconFile": "res:/ui/texture/icons/Inventory/Exile_64_1.png"}
4240	26426	{"_key": 26426, "iconFile": "res:/ui/texture/icons/Inventory/Exile_64_2.png"}
4241	26427	{"_key": 26427, "iconFile": "res:/ui/texture/icons/Inventory/Exile_64_3.png"}
4242	26428	{"_key": 26428, "iconFile": "res:/ui/texture/icons/Inventory/Exile_64_4.png"}
4243	26429	{"_key": 26429, "iconFile": "res:/ui/texture/icons/Inventory/Frentix_64.png"}
4244	26430	{"_key": 26430, "iconFile": "res:/ui/texture/icons/Inventory/Frentix_64_1.png"}
4245	26431	{"_key": 26431, "iconFile": "res:/ui/texture/icons/Inventory/Frentix_64_2.png"}
4246	26432	{"_key": 26432, "iconFile": "res:/ui/texture/icons/Inventory/Frentix_64_3.png"}
4247	26433	{"_key": 26433, "iconFile": "res:/ui/texture/icons/Inventory/Frentix_64_4.png"}
4248	26434	{"_key": 26434, "iconFile": "res:/ui/texture/icons/Inventory/Mindflood_64.png"}
4249	26435	{"_key": 26435, "iconFile": "res:/ui/texture/icons/Inventory/Mindflood_64_1.png"}
4250	26436	{"_key": 26436, "iconFile": "res:/ui/texture/icons/Inventory/Mindflood_64_2.png"}
4251	26437	{"_key": 26437, "iconFile": "res:/ui/texture/icons/Inventory/Mindflood_64_3.png"}
4252	26438	{"_key": 26438, "iconFile": "res:/ui/texture/icons/Inventory/Mindflood_64_4.png"}
4253	26439	{"_key": 26439, "iconFile": "res:/ui/texture/icons/Inventory/SoothSayer_64.png"}
4254	26440	{"_key": 26440, "iconFile": "res:/ui/texture/icons/Inventory/SoothSayer_64_1.png"}
4255	26441	{"_key": 26441, "iconFile": "res:/ui/texture/icons/Inventory/SoothSayer_64_2.png"}
4256	26442	{"_key": 26442, "iconFile": "res:/ui/texture/icons/Inventory/SoothSayer_64_3.png"}
4257	26443	{"_key": 26443, "iconFile": "res:/ui/texture/icons/Inventory/SoothSayer_64_4.png"}
4258	26444	{"_key": 26444, "iconFile": "res:/ui/texture/icons/Inventory/X-Instinct_64.png"}
4259	26445	{"_key": 26445, "iconFile": "res:/ui/texture/icons/Inventory/X-Instinct_64_1.png"}
4260	26446	{"_key": 26446, "iconFile": "res:/ui/texture/icons/Inventory/X-Instinct_64_2.png"}
4261	26447	{"_key": 26447, "iconFile": "res:/ui/texture/icons/Inventory/X-Instinct_64_3.png"}
4262	26448	{"_key": 26448, "iconFile": "res:/ui/texture/icons/Inventory/X-Instinct_64_4.png"}
4263	26449	{"_key": 26449, "iconFile": "res:/ui/texture/icons/modules/ShieldFluxcoil_64.png"}
4264	26450	{"_key": 26450, "iconFile": "res:/ui/texture/icons/modules/ShieldPowerRelay_64.png"}
4265	26451	{"_key": 26451, "iconFile": "res:/ui/texture/icons/modules/ShieldRecharger_64.png"}
4266	26452	{"_key": 26452, "iconFile": "res:/ui/texture/icons/modules/GyroStabilizer_64.png"}
4267	26453	{"_key": 26453, "iconFile": "res:/ui/texture/icons/modules/HeatSink_64.png"}
4268	26454	{"_key": 26454, "iconFile": "res:/ui/texture/icons/modules/MagneticFieldStabilizer_64.png"}
4269	26455	{"_key": 26455, "iconFile": "res:/ui/texture/icons/modules/CapacitorPowerRelay_64.png"}
4270	26456	{"_key": 26456, "iconFile": "res:/ui/texture/icons/modules/CapactorFluxcoil_64.png"}
4271	26457	{"_key": 26457, "iconFile": "res:/ui/texture/icons/modules/CapactorRecharger_64.png"}
4272	26459	{"_key": 26459, "iconFile": "res:/UI/Texture/MutaplasmidResidue/mutaPlasmidResidue_Armor_64.png"}
4273	26460	{"_key": 26460, "iconFile": "res:/UI/Texture/MutaplasmidResidue/mutaPlasmidResidue_Astronautic_64.png"}
4274	26461	{"_key": 26461, "iconFile": "res:/UI/Texture/MutaplasmidResidue/mutaPlasmidResidue_DamageControl_64.png"}
4275	26462	{"_key": 26462, "iconFile": "res:/UI/Texture/MutaplasmidResidue/mutaPlasmidResidue_Drone_64.png"}
4276	26463	{"_key": 26463, "iconFile": "res:/UI/Texture/MutaplasmidResidue/mutaPlasmidResidue_Engineering_64.png"}
4277	26464	{"_key": 26464, "iconFile": "res:/UI/Texture/MutaplasmidResidue/mutaPlasmidResidue_Shield_64.png"}
4278	26465	{"_key": 26465, "iconFile": "res:/UI/Texture/MutaplasmidResidue/mutaPlasmidResidue_StasisWebifier_64.png"}
4279	26466	{"_key": 26466, "iconFile": "res:/UI/Texture/MutaplasmidResidue/mutaPlasmidResidue_WarpDisruption_64.png"}
4280	26467	{"_key": 26467, "iconFile": "res:/UI/Texture/MutaplasmidResidue/mutaPlasmidResidue_WeaponUpgrade_64.png"}
4281	26468	{"_key": 26468, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_matt_000_100_050.png"}
4282	26469	{"_key": 26469, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_red_matt_000_100_050.png"}
4283	26470	{"_key": 26470, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_redorange_brushed_000_100_050.png"}
4284	26471	{"_key": 26471, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_deathless_1_128.png"}
4285	26472	{"_key": 26472, "iconFile": "res:/UI/Texture/MutaplasmidResidue/mutaplasmid_s_64.png"}
4286	26473	{"_key": 26473, "iconFile": "res:/UI/Texture/MutaplasmidResidue/mutaplasmid_m_64.png"}
4287	26474	{"_key": 26474, "iconFile": "res:/UI/Texture/MutaplasmidResidue/mutaplasmid_l_64.png"}
4288	26475	{"_key": 26475, "iconFile": "res:/UI/Texture/MutaplasmidResidue/mutaplasmid_xl_64.png"}
4289	26478	{"_key": 26478, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_redorange_matt_000_100_010.png"}
4290	26479	{"_key": 26479, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_blue_metallic_000_100_050.png"}
4291	26480	{"_key": 26480, "iconFile": "res:/ui/texture/icons/202410_Xolotl_ticket.png", "iconType": "png"}
4292	26481	{"_key": 26481, "iconFile": "res:/ui/texture/icons/202410_Xolotl_chip.png", "iconType": "png"}
4293	26483	{"_key": 26483, "iconFile": "res:/UI/Texture/Icons/StatusEffects/dotStatusEffect.png"}
4294	26518	{"_key": 26518, "iconFile": "res:/UI/Texture/Icons/Inventory/Deathless_Crate_64.png"}
4295	26521	{"_key": 26521, "iconFile": "res:/ui/texture/icons/modules/EntropicRadiationSink_64.png"}
4296	26522	{"_key": 26522, "iconFile": "res:/ui/texture/icons/dragon_building_chip.png", "iconType": "png"}
4297	26523	{"_key": 26523, "iconFile": "res:/ui/texture/icons/dragon_building_gacha.png", "iconType": "png"}
4298	26525	{"_key": 26525, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_vanguard_black.png"}
4299	26526	{"_key": 26526, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_vanguard_red.png"}
4300	26527	{"_key": 26527, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_vanguard_white.png"}
4301	26529	{"_key": 26529, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/vanguard_pattern_128.png"}
4302	26531	{"_key": 26531, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/Pattern_WN2024_04_128.png"}
4303	26534	{"_key": 26534, "iconFile": "res:/ui/texture/icons/AgencyBoosters/BoosterAgencyDamage_64_1.png"}
4304	26535	{"_key": 26535, "iconFile": "res:/ui/texture/icons/AgencyBoosters/BoosterAgencyDamage_64_2.png"}
4305	26536	{"_key": 26536, "iconFile": "res:/ui/texture/icons/AgencyBoosters/BoosterAgencyDamage_64_3.png"}
4306	26537	{"_key": 26537, "iconFile": "res:/ui/texture/icons/AgencyBoosters/BoosterAgencyDamage_64_4.png"}
4307	26538	{"_key": 26538, "iconFile": "res:/ui/texture/icons/AgencyBoosters/BoosterAgencySpeed_64_1.png"}
4308	26539	{"_key": 26539, "iconFile": "res:/ui/texture/icons/AgencyBoosters/BoosterAgencySpeed_64_2.png"}
4309	26540	{"_key": 26540, "iconFile": "res:/ui/texture/icons/AgencyBoosters/BoosterAgencySpeed_64_3.png"}
4310	26541	{"_key": 26541, "iconFile": "res:/ui/texture/icons/AgencyBoosters/BoosterAgencySpeed_64_4.png"}
4311	26542	{"_key": 26542, "iconFile": "res:/ui/texture/icons/AgencyBoosters/BoosterAgencyTank_64_1.png"}
4312	26543	{"_key": 26543, "iconFile": "res:/ui/texture/icons/AgencyBoosters/BoosterAgencyTank_64_2.png"}
4313	26544	{"_key": 26544, "iconFile": "res:/ui/texture/icons/AgencyBoosters/BoosterAgencyTank_64_3.png"}
4314	26545	{"_key": 26545, "iconFile": "res:/ui/texture/icons/AgencyBoosters/BoosterAgencyTank_64_4.png"}
4315	26546	{"_key": 26546, "iconFile": "res:/ui/texture/icons/PowerDiagnosticSystem_64.png"}
4316	26547	{"_key": 26547, "iconFile": "res:/ui/texture/icons/ReactorControlUnit_64.png"}
4317	26548	{"_key": 26548, "iconFile": "res:/ui/texture/icons/boosters/BluePill_64_1.png"}
4318	26549	{"_key": 26549, "iconFile": "res:/ui/texture/icons/boosters/BluePill_64_2.png"}
4319	26550	{"_key": 26550, "iconFile": "res:/ui/texture/icons/boosters/BluePill_64_3.png"}
4320	26551	{"_key": 26551, "iconFile": "res:/ui/texture/icons/boosters/BluePill_64_4.png"}
4321	26552	{"_key": 26552, "iconFile": "res:/ui/texture/icons/boosters/Frentix_64_1.png"}
4322	26553	{"_key": 26553, "iconFile": "res:/ui/texture/icons/boosters/Frentix_64_2.png"}
4323	26554	{"_key": 26554, "iconFile": "res:/ui/texture/icons/boosters/Frentix_64_3.png"}
4324	26555	{"_key": 26555, "iconFile": "res:/ui/texture/icons/boosters/Frentix_64_4.png"}
4325	26556	{"_key": 26556, "iconFile": "res:/ui/texture/icons/boosters/Mindflood_64_1.png"}
4326	26557	{"_key": 26557, "iconFile": "res:/ui/texture/icons/boosters/Mindflood_64_2.png"}
4327	26558	{"_key": 26558, "iconFile": "res:/ui/texture/icons/boosters/Mindflood_64_3.png"}
4328	26559	{"_key": 26559, "iconFile": "res:/ui/texture/icons/boosters/Mindflood_64_4.png"}
4329	26560	{"_key": 26560, "iconFile": "res:/ui/texture/icons/stellianevent/core.png", "iconType": "png"}
4330	26561	{"_key": 26561, "iconFile": "res:/ui/texture/icons/stellianevent/nanite.png", "iconType": "png"}
4331	26562	{"_key": 26562, "iconFile": "res:/ui/texture/icons/stellianevent/plate.png", "iconType": "png"}
4332	26563	{"_key": 26563, "iconFile": "res:/ui/texture/icons/stellianevent/projecter.png", "iconType": "png"}
4333	26564	{"_key": 26564, "iconFile": "res:/ui/texture/icons/stellianevent/implantA.png", "iconType": "png"}
4334	26565	{"_key": 26565, "iconFile": "res:/ui/texture/icons/stellianevent/implantB.png", "iconType": "png"}
4335	26566	{"_key": 26566, "iconFile": "res:/ui/texture/icons/stellianevent/implantC.png", "iconType": "png"}
4336	26567	{"_key": 26567, "iconFile": "res:/ui/texture/icons/stellianevent/implantABlueprint.png", "iconType": "png"}
4337	26568	{"_key": 26568, "iconFile": "res:/ui/texture/icons/stellianevent/implantBBlueprint.png", "iconType": "png"}
4338	26569	{"_key": 26569, "iconFile": "res:/ui/texture/icons/stellianevent/implantCBlueprint.png", "iconType": "png"}
4339	26570	{"_key": 26570, "iconFile": "res:/ui/texture/icons/stellianevent/boosterGreenA.png", "iconType": "png"}
4340	26571	{"_key": 26571, "iconFile": "res:/ui/texture/icons/stellianevent/boosterGreenB.png", "iconType": "png"}
4341	26572	{"_key": 26572, "iconFile": "res:/ui/texture/icons/stellianevent/boosterWhiteA.png", "iconType": "png"}
4342	26573	{"_key": 26573, "iconFile": "res:/ui/texture/icons/stellianevent/boosterWhiteB.png", "iconType": "png"}
4343	26574	{"_key": 26574, "iconFile": "res:/ui/texture/icons/stellianevent/boosterGreenABlueprint.png", "iconType": "png"}
4344	26575	{"_key": 26575, "iconFile": "res:/ui/texture/icons/stellianevent/boosterGreenBBlurprint.png", "iconType": "png"}
4345	26576	{"_key": 26576, "iconFile": "res:/ui/texture/icons/stellianevent/boosterWhiteABlueprint.png", "iconType": "png"}
4346	26577	{"_key": 26577, "iconFile": "res:/ui/texture/icons/stellianevent/boosterWhiteBBlurprint.png", "iconType": "png"}
4347	26578	{"_key": 26578, "iconFile": "res:/ui/texture/icons/frekisuperbox.png", "iconType": "png"}
4348	26579	{"_key": 26579, "iconFile": "res:/ui/texture/icons/frekibox.png", "iconType": "png"}
4349	26580	{"_key": 26580, "iconType": "png"}
4350	26581	{"_key": 26581, "iconFile": "res:/ui/texture/icons/frekibox.png", "iconType": "png"}
4351	26582	{"_key": 26582, "iconFile": "res:/ui/texture/icons/frekicoin.png", "iconType": "png"}
4352	26583	{"_key": 26583, "iconFile": "res:/ui/texture/icons/frekisuperbox.png", "iconType": "png"}
4353	26584	{"_key": 26584, "iconFile": "res:/UI/Texture/Icons/Inventory/Drifter_loot_crate64.png", "iconType": "png"}
4354	26585	{"_key": 26585, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_green_satin_000_100_100.png"}
4355	26586	{"_key": 26586, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_blue_metallic_000_100_001.png"}
4356	26587	{"_key": 26587, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_snakescales_01_128.png"}
4357	26589	{"_key": 26589, "iconFile": "res:/ui/texture/icons/spectral_vision_capture.png"}
4358	26596	{"_key": 26596, "iconFile": "res:/ui/texture/icons/YC127YearCardShipBox.png", "iconType": "png"}
4359	26597	{"_key": 26597, "iconFile": "res:/UI/Asset/mannequin/outer/87572_Female_Outer_CostumeJF01_Types_CostumeJF01_Drifter.png", "iconType": "png"}
4360	26598	{"_key": 26598, "iconFile": "res:/UI/Asset/mannequin/outer/87573_Male_outer_CostumeJM01_Types_CostumeJM01_Drifter.png", "iconType": "png"}
4361	26604	{"_key": 26604, "iconFile": "res:/ui/texture/icons/boosters/Crash_64_1.png"}
4362	26605	{"_key": 26605, "iconFile": "res:/ui/texture/icons/boosters/Crash_64_2.png"}
4363	26606	{"_key": 26606, "iconFile": "res:/ui/texture/icons/boosters/Crash_64_3.png"}
4364	26607	{"_key": 26607, "iconFile": "res:/ui/texture/icons/boosters/Crash_64_4.png"}
4365	26608	{"_key": 26608, "iconFile": "res:/ui/texture/icons/boosters/Drop_64_1.png"}
4366	26609	{"_key": 26609, "iconFile": "res:/ui/texture/icons/boosters/Drop_64_2.png"}
4367	26610	{"_key": 26610, "iconFile": "res:/ui/texture/icons/boosters/Drop_64_3.png"}
4368	26611	{"_key": 26611, "iconFile": "res:/ui/texture/icons/boosters/Drop_64_4.png"}
4369	26612	{"_key": 26612, "iconFile": "res:/ui/texture/icons/boosters/Exile_64_1.png"}
4370	26613	{"_key": 26613, "iconFile": "res:/ui/texture/icons/boosters/Exile_64_2.png"}
4371	26614	{"_key": 26614, "iconFile": "res:/ui/texture/icons/boosters/Exile_64_3.png"}
4372	26615	{"_key": 26615, "iconFile": "res:/ui/texture/icons/boosters/Exile_64_4.png"}
4373	26616	{"_key": 26616, "iconFile": "res:/ui/texture/icons/boosters/SoothSayer_64_1.png"}
4374	26617	{"_key": 26617, "iconFile": "res:/ui/texture/icons/boosters/SoothSayer_64_2.png"}
4375	26618	{"_key": 26618, "iconFile": "res:/ui/texture/icons/boosters/SoothSayer_64_3.png"}
4376	26619	{"_key": 26619, "iconFile": "res:/ui/texture/icons/boosters/SoothSayer_64_4.png"}
4377	26620	{"_key": 26620, "iconFile": "res:/ui/texture/icons/boosters/X-Instinct_64_1.png"}
4378	26621	{"_key": 26621, "iconFile": "res:/ui/texture/icons/boosters/X-Instinct_64_2.png"}
4379	26622	{"_key": 26622, "iconFile": "res:/ui/texture/icons/boosters/X-Instinct_64_3.png"}
4380	26623	{"_key": 26623, "iconFile": "res:/ui/texture/icons/boosters/X-Instinct_64_4.png"}
4381	26631	{"_key": 26631, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_matt_000_100_010.png"}
4382	26632	{"_key": 26632, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_matt_000_100_001.png"}
4383	26633	{"_key": 26633, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_satin_000_100_001.png"}
4384	26634	{"_key": 26634, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_emerald_satin_000_060_100.png"}
4385	26635	{"_key": 26635, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_gloss_000_060_100.png"}
4386	26636	{"_key": 26636, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_matt_000_060_100.png"}
4387	26637	{"_key": 26637, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_matt_000_080_100.png"}
4388	26638	{"_key": 26638, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_satin_000_100_010.png"}
4389	26639	{"_key": 26639, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_satin_000_080_100.png"}
4390	26640	{"_key": 26640, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_gloss_000_060_100.png"}
4391	26641	{"_key": 26641, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_emerald_polished_000_080_100.png"}
4392	26642	{"_key": 26642, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_polished_000_030_100.png"}
4393	26643	{"_key": 26643, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_polished_000_080_100.png"}
4394	26644	{"_key": 26644, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_drifter_geo_t3_03_128.png"}
4395	26645	{"_key": 26645, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_drifter_geo_t3_01_128.png"}
4396	26646	{"_key": 26646, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_drifter_geo_t3_02_128.png"}
4397	26672	{"_key": 26672, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_drifter_dark_blue.png"}
4398	26673	{"_key": 26673, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_drifter_dark_blue_metallic.png"}
4399	26674	{"_key": 26674, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_drifter_dark_green.png"}
4400	26675	{"_key": 26675, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_drifter_dark_green_metallic.png"}
4401	26676	{"_key": 26676, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_drifter_mint.png"}
4402	26677	{"_key": 26677, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_drifter_mint_metallic.png"}
4403	26678	{"_key": 26678, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_drifter_white.png"}
4404	26679	{"_key": 26679, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_drifter_white_metallic.png"}
4405	26680	{"_key": 26680, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_circletwirl_t1_04_128.png"}
4406	26681	{"_key": 26681, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_drifter_geo_t1_03_128.png"}
4407	26682	{"_key": 26682, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_drifter_geo_t3_04_128.png"}
4408	26683	{"_key": 26683, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_drifter_spikes_t1_01_128.png"}
4409	26684	{"_key": 26684, "iconFile": "res:/UI/Texture/Icons/StatusEffects/linkedToTrace.png"}
4410	26704	{"_key": 26704, "iconFile": "res:/ui/texture/icons/202503_Stellian_Chip.png", "iconType": "png"}
4411	26705	{"_key": 26705, "iconFile": "res:/ui/texture/icons/202503_Stellian_Ticket.png", "iconType": "png"}
4412	26707	{"_key": 26707, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_yellow_satin_000_100_100.png"}
4413	26708	{"_key": 26708, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_matt_000_100_050.png"}
4414	26709	{"_key": 26709, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_coincamo_t2_01_128.png"}
4415	26710	{"_key": 26710, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_pea_satin_000_080_100.png"}
4416	26711	{"_key": 26711, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_guristas_camo_t1_01_128.png"}
4417	26712	{"_key": 26712, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_safetyorange_gloss_000_100_100.png"}
4418	26713	{"_key": 26713, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_safetyorange_satin_000_060_100.png"}
4419	26714	{"_key": 26714, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cherryred_metallic_000_030_100.png"}
4420	26715	{"_key": 26715, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_XXII_t1_01_128.png"}
4421	26716	{"_key": 26716, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_satin_000_100_050.png"}
4422	26717	{"_key": 26717, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_satin_000_100_100.png"}
4423	26718	{"_key": 26718, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_green_gloss_000_080_100.png"}
4424	26719	{"_key": 26719, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_malachite_polished_000_060_100.png"}
4425	26720	{"_key": 26720, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_drifter_geo_t2_01_128.png"}
4426	26721	{"_key": 26721, "iconFile": "res:/ui/texture/icons/modules/AutoTargetingSystem_64.png"}
4427	26722	{"_key": 26722, "iconFile": "res:/ui/texture/icons/modules/NetworkedSensorArray_64.png"}
4428	26723	{"_key": 26723, "iconFile": "res:/ui/texture/icons/modules/PassiveTargetingArray_64.png"}
4429	26724	{"_key": 26724, "iconFile": "res:/ui/texture/icons/modules/PassiveTargetingSystem_64.png"}
4430	26725	{"_key": 26725, "iconFile": "res:/ui/texture/icons/modules/RemoteSensorBooster_64.png"}
4431	26726	{"_key": 26726, "iconFile": "res:/ui/texture/icons/modules/SensorBooster_64.png"}
4432	26727	{"_key": 26727, "iconFile": "res:/ui/texture/icons/modules/SignalAmplifier_64.png"}
4433	26729	{"_key": 26729, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/MajorThreatDetectionArray_I_zh.png"}
4434	26730	{"_key": 26730, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/MajorThreatDetectionArray_II_zh.png"}
4435	26731	{"_key": 26731, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/MajorThreatDetectionArray_III_zh.png"}
4436	26732	{"_key": 26732, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/MinorThreatDetectionArray_I_zh.png"}
4437	26733	{"_key": 26733, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/MinorThreatDetectionArray_II_zh.png"}
4438	26734	{"_key": 26734, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/MinorThreatDetectionArray_III_zh.png"}
4439	26735	{"_key": 26735, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Tritanium_I.png"}
4440	26736	{"_key": 26736, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Tritanium_II.png"}
4441	26737	{"_key": 26737, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Tritanium_III.png"}
4442	26738	{"_key": 26738, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Pyerite_I.png"}
4443	26739	{"_key": 26739, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Pyerite_II.png"}
4444	26740	{"_key": 26740, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Pyerite_III.png"}
4445	26741	{"_key": 26741, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Mexallon_I.png"}
4446	26742	{"_key": 26742, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Mexallon_II.png"}
4447	26743	{"_key": 26743, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Mexallon_III.png"}
4448	26744	{"_key": 26744, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Isogen_I.png"}
4449	26745	{"_key": 26745, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Isogen_II.png"}
4450	26746	{"_key": 26746, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Isogen_III.png"}
4451	26747	{"_key": 26747, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Nocxium_I.png"}
4452	26748	{"_key": 26748, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Nocxium_II.png"}
4453	26749	{"_key": 26749, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Nocxium_III.png"}
4454	26750	{"_key": 26750, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Zydrine_I.png"}
4455	26751	{"_key": 26751, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Zydrine_II.png"}
4456	26752	{"_key": 26752, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Zydrine_III.png"}
4457	26753	{"_key": 26753, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Megacyte_I.png"}
4458	26754	{"_key": 26754, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Megacyte_II.png"}
4459	26755	{"_key": 26755, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Upgrade_Megacyte_III.png"}
4460	26757	{"_key": 26757, "iconFile": "res:/UI/Texture/Icons/Exploration_Upgrade_I.png"}
4461	26758	{"_key": 26758, "iconFile": "res:/UI/Texture/Icons/Exploration_Upgrade_II.png"}
4462	26759	{"_key": 26759, "iconFile": "res:/UI/Texture/Icons/Exploration_Upgrade_III.png"}
4463	26775	{"_key": 26775, "iconFile": "res:/ui/texture/icons/PowerGeneration_Upgrade.png"}
4464	26776	{"_key": 26776, "iconFile": "res:/UI/Texture/Icons/WorkforceGeneration_Upgrade.png"}
4465	26777	{"_key": 26777, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Gamma_SystemWideModifier_Upgrade.png"}
4466	26778	{"_key": 26778, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Plasma_SystemWideModifier_Upgrade.png"}
4467	26779	{"_key": 26779, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Electric_SystemWideModifier_Upgrade.png"}
4468	26780	{"_key": 26780, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Exotic_SystemWideModifier_Upgrade.png"}
4469	26781	{"_key": 26781, "iconFile": "res:/ui/texture/icons/modules/SensorBooster_Script01_64.png"}
4470	26782	{"_key": 26782, "iconFile": "res:/ui/texture/icons/modules/SensorBooster_Script02_64.png"}
4471	26783	{"_key": 26783, "iconFile": "res:/ui/texture/icons/modules/SensorBooster_Script03_64.png"}
4472	26784	{"_key": 26784, "iconFile": "res:/ui/texture/icons/Tyranite_E_Mineral_64.png"}
4473	26785	{"_key": 26785, "iconFile": "res:/ui/texture/icons/Tyranite_Ore_64.png"}
4474	26788	{"_key": 26788, "iconFile": "res:/UI/Texture/Icons/Inventory/SovHubUpgrades/Workforce_Conversion_Upgrade_I.png"}
4475	26789	{"_key": 26789, "iconFile": "res:/UI/Texture/Icons/Inventory/SovHubUpgrades/Workforce_Conversion_Upgrade_II.png"}
4476	26790	{"_key": 26790, "iconFile": "res:/UI/Texture/Icons/Inventory/SovHubUpgrades/Workforce_Conversion_Upgrade_III.png"}
4477	26791	{"_key": 26791, "iconFile": "res:/UI/Texture/Icons/Inventory/SovHubUpgrades/Power_Conversion_Upgrade_I.png"}
4478	26792	{"_key": 26792, "iconFile": "res:/UI/Texture/Icons/Inventory/SovHubUpgrades/Power_Conversion_Upgrade_II.png"}
4479	26793	{"_key": 26793, "iconFile": "res:/UI/Texture/Icons/Inventory/SovHubUpgrades/Power_Conversion_Upgrade_III.png"}
4480	26796	{"_key": 26796, "iconFile": "res:/UI/Asset/mannequin/outer/88186_Male_outer_AugmentationSuitM01_Types_AugmentationSuitM01_Black.png", "iconType": "png"}
4481	26797	{"_key": 26797, "iconFile": "res:/UI/Asset/mannequin/outer/88187_Female_Outer_AugmentationSuitF01_Types_AugmentationSuitF01_Black.png", "iconType": "png"}
4482	26798	{"_key": 26798, "iconFile": "res:/ui/texture/icons/Inventory/Drifter_Filament_64.png"}
4483	26799	{"_key": 26799, "iconFile": "res:/UI/Texture/Icons/expert_system_64.png"}
4484	26801	{"_key": 26801, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_satin_000_100_050.png"}
4485	26802	{"_key": 26802, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_satin_000_100_050.png"}
4486	26808	{"_key": 26808, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_orange_metallic_000_100_010.png"}
4487	26809	{"_key": 26809, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_orange_metallic_000_100_010.png"}
4488	26819	{"_key": 26819, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_stripe_01_128.png"}
4489	26820	{"_key": 26820, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_stripe_01_128.png"}
4490	26821	{"_key": 26821, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_lines_gradient_01_128.png"}
4491	26822	{"_key": 26822, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_lines_gradient_01_128.png"}
4492	26823	{"_key": 26823, "iconFile": "res:/ui/texture/icons/Inventory/SovHubUpgrades/Triglavian_Scanner_Upgrade.png"}
4493	26824	{"_key": 26824, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_gloss_000_100_050.png"}
4494	26825	{"_key": 26825, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_gloss_000_100_050.png"}
4495	26826	{"_key": 26826, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_satin_000_100_050.png"}
4496	26827	{"_key": 26827, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_satin_000_100_050.png"}
4497	26828	{"_key": 26828, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_gloss_000_100_050.png"}
4498	26829	{"_key": 26829, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_gloss_000_100_050.png"}
4499	26830	{"_key": 26830, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_gloss_000_100_100.png"}
4500	26831	{"_key": 26831, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_gloss_000_100_100.png"}
4501	26832	{"_key": 26832, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_satin_000_100_100.png"}
4502	26833	{"_key": 26833, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_satin_000_100_100.png"}
4503	26834	{"_key": 26834, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_matt_000_100_100.png"}
4504	26835	{"_key": 26835, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_matt_000_100_100.png"}
4505	26836	{"_key": 26836, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_matt_000_060_100.png"}
4506	26837	{"_key": 26837, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_matt_000_060_100.png"}
4507	26838	{"_key": 26838, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_chartreuse_gloss_000_100_100.png"}
4508	26839	{"_key": 26839, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_chartreuse_gloss_000_100_100.png"}
4509	26840	{"_key": 26840, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_chartreuse_satin_000_100_100.png"}
4510	26841	{"_key": 26841, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_chartreuse_satin_000_100_100.png"}
4511	26842	{"_key": 26842, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_chartreuse_highgloss_000_100_100.png"}
4512	26843	{"_key": 26843, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_chartreuse_highgloss_000_100_100.png"}
4513	26844	{"_key": 26844, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_pea_gloss_000_100_050.png"}
4514	26845	{"_key": 26845, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_pea_gloss_000_100_050.png"}
4515	26846	{"_key": 26846, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_chartreuse_gloss_000_080_100.png"}
4516	26847	{"_key": 26847, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_chartreuse_gloss_000_080_100.png"}
4517	26848	{"_key": 26848, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_green_gloss_000_060_100.png"}
4518	26849	{"_key": 26849, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_green_gloss_000_060_100.png"}
4519	26850	{"_key": 26850, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_matt_000_030_100.png"}
4520	26851	{"_key": 26851, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_matt_000_030_100.png"}
4521	26852	{"_key": 26852, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_satin_000_060_100.png"}
4522	26853	{"_key": 26853, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_satin_000_060_100.png"}
4523	26854	{"_key": 26854, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_satin_000_030_100.png"}
4524	26855	{"_key": 26855, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_satin_000_030_100.png"}
4525	26856	{"_key": 26856, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_satin_000_030_100.png"}
4526	26857	{"_key": 26857, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_satin_000_030_100.png"}
4527	26858	{"_key": 26858, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cherryred_satin_000_080_100.png"}
4528	26859	{"_key": 26859, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cherryred_satin_000_080_100.png"}
4529	26860	{"_key": 26860, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_orange_satin_000_060_100.png"}
4530	26861	{"_key": 26861, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_orange_satin_000_060_100.png"}
4531	26862	{"_key": 26862, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_bw_satin_000_000_050.png"}
4532	26863	{"_key": 26863, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_bw_satin_000_000_050.png"}
4533	26864	{"_key": 26864, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_bw_matt_000_000_010.png"}
4534	26865	{"_key": 26865, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_bw_matt_000_000_010.png"}
4535	26866	{"_key": 26866, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_grape_matt_000_080_100.png"}
4536	26867	{"_key": 26867, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_grape_matt_000_080_100.png"}
4537	26868	{"_key": 26868, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_malachite_matt_000_100_010.png"}
4538	26869	{"_key": 26869, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_malachite_matt_000_100_010.png"}
4539	26870	{"_key": 26870, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cherryred_matt_000_080_100.png"}
4540	26871	{"_key": 26871, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cherryred_matt_000_080_100.png"}
4541	26872	{"_key": 26872, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_gloss_000_100_050.png"}
4542	26873	{"_key": 26873, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_gloss_000_100_050.png"}
4543	26874	{"_key": 26874, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_berry_gloss_000_100_010.png"}
4544	26875	{"_key": 26875, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_berry_gloss_000_100_010.png"}
4545	26876	{"_key": 26876, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_rosered_gloss_000_100_010.png"}
4546	26877	{"_key": 26877, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_rosered_gloss_000_100_010.png"}
4547	26878	{"_key": 26878, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_gloss_000_100_010.png"}
4548	26879	{"_key": 26879, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_gloss_000_100_010.png"}
4549	26880	{"_key": 26880, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_emerald_gloss_000_100_050.png"}
4550	26881	{"_key": 26881, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_emerald_gloss_000_100_050.png"}
4551	26882	{"_key": 26882, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_metallic_000_100_001.png"}
4552	26883	{"_key": 26883, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_metallic_000_100_001.png"}
4553	26884	{"_key": 26884, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_green_metallic_000_100_001.png"}
4554	26885	{"_key": 26885, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_green_metallic_000_100_001.png"}
4555	26886	{"_key": 26886, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_metallic_000_100_010.png"}
4556	26887	{"_key": 26887, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_metallic_000_100_010.png"}
4557	26888	{"_key": 26888, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_chartreuse_metallic_000_100_010.png"}
4558	26889	{"_key": 26889, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_chartreuse_metallic_000_100_010.png"}
4559	26890	{"_key": 26890, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_green_metallic_000_100_010.png"}
4560	26891	{"_key": 26891, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_green_metallic_000_100_010.png"}
4561	26892	{"_key": 26892, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_metallic_000_100_010.png"}
4562	26893	{"_key": 26893, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_metallic_000_100_010.png"}
4563	26894	{"_key": 26894, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_malachite_metallic_000_100_010.png"}
4564	26895	{"_key": 26895, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_malachite_metallic_000_100_010.png"}
4565	26896	{"_key": 26896, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_grape_metallic_000_100_010.png"}
4566	26897	{"_key": 26897, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_grape_metallic_000_100_010.png"}
4567	26898	{"_key": 26898, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_brushed_000_100_050.png"}
4568	26899	{"_key": 26899, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_brushed_000_100_050.png"}
4569	26900	{"_key": 26900, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_rough_000_100_050.png"}
4570	26901	{"_key": 26901, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_rough_000_100_050.png"}
4571	26902	{"_key": 26902, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_brushed_000_100_050.png"}
4572	26903	{"_key": 26903, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_brushed_000_100_050.png"}
4573	26904	{"_key": 26904, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_brushed_000_100_100.png"}
4574	26905	{"_key": 26905, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_brushed_000_100_100.png"}
4575	26906	{"_key": 26906, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_rough_000_060_100.png"}
4576	26907	{"_key": 26907, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_rough_000_060_100.png"}
4577	26908	{"_key": 26908, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_rough_000_100_010.png"}
4578	26909	{"_key": 26909, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_rough_000_100_010.png"}
4579	26910	{"_key": 26910, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_brushed_000_100_001.png"}
4580	26911	{"_key": 26911, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_brushed_000_100_001.png"}
4581	26912	{"_key": 26912, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_pea_rough_000_100_100.png"}
4582	26913	{"_key": 26913, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_pea_rough_000_100_100.png"}
4583	26914	{"_key": 26914, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_pea_brushed_000_080_100.png"}
4584	26915	{"_key": 26915, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_pea_brushed_000_080_100.png"}
4585	26916	{"_key": 26916, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_chartreuse_rough_000_080_100.png"}
4586	26917	{"_key": 26917, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_chartreuse_rough_000_080_100.png"}
4587	26918	{"_key": 26918, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_green_brushed_000_100_001.png"}
4588	26919	{"_key": 26919, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_green_brushed_000_100_001.png"}
4589	26920	{"_key": 26920, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_green_polished_000_100_001.png"}
4590	26921	{"_key": 26921, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_green_polished_000_100_001.png"}
4591	26922	{"_key": 26922, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_brushed_000_100_001.png"}
4592	26923	{"_key": 26923, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_brushed_000_100_001.png"}
4593	26924	{"_key": 26924, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_rough_000_030_100.png"}
4594	26925	{"_key": 26925, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_rough_000_030_100.png"}
4595	26926	{"_key": 26926, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_rough_000_100_050.png"}
4596	26927	{"_key": 26927, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_rough_000_100_050.png"}
4597	26928	{"_key": 26928, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_stripe_04_128.png"}
4598	26929	{"_key": 26929, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_stripe_04_128.png"}
4599	26930	{"_key": 26930, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_stripe_02_128.png"}
4600	26931	{"_key": 26931, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_stripe_02_128.png"}
4601	26932	{"_key": 26932, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_stripe_03_128.png"}
4602	26933	{"_key": 26933, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_stripe_03_128.png"}
4603	26934	{"_key": 26934, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_stripe_15_128.png"}
4604	26935	{"_key": 26935, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_stripe_15_128.png"}
4605	26936	{"_key": 26936, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_stripe_05_128.png"}
4606	26937	{"_key": 26937, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_stripe_05_128.png"}
4607	26938	{"_key": 26938, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_stripe_07_128.png"}
4608	26939	{"_key": 26939, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_stripe_07_128.png"}
4609	26940	{"_key": 26940, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_stripe_13_128.png"}
4610	26941	{"_key": 26941, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_stripe_13_128.png"}
4611	26942	{"_key": 26942, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_stripe_14_128.png"}
4612	26943	{"_key": 26943, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_stripe_14_128.png"}
4613	26944	{"_key": 26944, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_leaf_01_128.png"}
4614	26945	{"_key": 26945, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_leaf_01_128.png"}
4615	26946	{"_key": 26946, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_decorative_01_128.png"}
4616	26947	{"_key": 26947, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_decorative_01_128.png"}
4617	26948	{"_key": 26948, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_arrows_01_128.png"}
4618	26949	{"_key": 26949, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_arrows_01_128.png"}
4619	26950	{"_key": 26950, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_arrows_02_128.png"}
4620	26951	{"_key": 26951, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_arrows_02_128.png"}
4621	26952	{"_key": 26952, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_tactical_01_128.png"}
4622	26953	{"_key": 26953, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_tactical_01_128.png"}
4623	26954	{"_key": 26954, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_circletwirl_01_128.png"}
4624	26955	{"_key": 26955, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_circletwirl_01_128.png"}
4625	26956	{"_key": 26956, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_twirl_01_128.png"}
4626	26957	{"_key": 26957, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_twirl_01_128.png"}
4627	26958	{"_key": 26958, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_camo_wave_01_128.png"}
4628	26959	{"_key": 26959, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_camo_wave_01_128.png"}
4629	26960	{"_key": 26960, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_lines_gradient_03_128.png"}
4630	26961	{"_key": 26961, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_lines_gradient_03_128.png"}
4631	26962	{"_key": 26962, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_lines_gradient_02_128.png"}
4632	26963	{"_key": 26963, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_lines_gradient_02_128.png"}
4633	26964	{"_key": 26964, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_gradient_hex_02_128.png"}
4634	26965	{"_key": 26965, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_gradient_hex_02_128.png"}
4635	26966	{"_key": 26966, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_gradient_hex_01_128.png"}
4636	26967	{"_key": 26967, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_gradient_hex_01_128.png"}
4637	26968	{"_key": 26968, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_gradient_square_01_128.png"}
4638	26969	{"_key": 26969, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_gradient_square_01_128.png"}
4639	26970	{"_key": 26970, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_lines_camo_01_128.png"}
4640	26971	{"_key": 26971, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_lines_camo_01_128.png"}
4641	26972	{"_key": 26972, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_art_03_128.png"}
4642	26973	{"_key": 26973, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_art_03_128.png"}
4643	26974	{"_key": 26974, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_art_02_128.png"}
4644	26975	{"_key": 26975, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_art_02_128.png"}
4645	26976	{"_key": 26976, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_Art_01_128.png"}
4646	26977	{"_key": 26977, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_Art_01_128.png"}
4647	26978	{"_key": 26978, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_abstract_06_128.png"}
4648	26979	{"_key": 26979, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_abstract_06_128.png"}
4649	26980	{"_key": 26980, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_abstract_08_128.png"}
4650	26981	{"_key": 26981, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_abstract_08_128.png"}
4651	26982	{"_key": 26982, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_cosm_abstract_08_128.png"}
4652	26983	{"_key": 26983, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_metallic_000_100_010.png"}
4653	26984	{"_key": 26984, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_metallic_000_100_010.png"}
4654	26985	{"_key": 26985, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_metallic_000_100_001.png"}
4655	26986	{"_key": 26986, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_metallic_000_100_001.png"}
4656	27022	{"_key": 27022, "iconFile": "res:/ui/texture/icons/PythonTicket.png", "iconType": "png"}
4657	27023	{"_key": 27023, "iconFile": "res:/ui/texture/icons/PythonChip.png", "iconType": "png"}
4658	27043	{"_key": 27043, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_highgloss_000_100_100.png"}
4659	27044	{"_key": 27044, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_rosered_satin_000_100_100.png"}
4660	27045	{"_key": 27045, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cheese_matt_000_100_100.png"}
4661	27046	{"_key": 27046, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_polished_000_100_050.png"}
4662	27047	{"_key": 27047, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_safetyorange_brushed_000_100_100.png"}
4663	27048	{"_key": 27048, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_camo_wave_02_128.png"}
4664	27049	{"_key": 27049, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_symbol_01A_128.png"}
4665	27050	{"_key": 27050, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_twirl_04_128.png"}
4666	27051	{"_key": 27051, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_highgloss_000_060_100_cs180.png"}
4667	27053	{"_key": 27053, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_ExpeditionBase.png"}
4668	27054	{"_key": 27054, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_ExpeditionProbeStrength.png"}
4669	27055	{"_key": 27055, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_ExpeditionDscanRange.png"}
4670	27056	{"_key": 27056, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_ExpeditionProbeDeviation.png"}
4671	27058	{"_key": 27058, "iconFile": "res:/ui/texture/icons/marketicon_16px_ORE.png"}
4672	27059	{"_key": 27059, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tech_02_128.png"}
4673	27060	{"_key": 27060, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tech_02_128.png"}
4674	27061	{"_key": 27061, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tech_03_128.png"}
4675	27062	{"_key": 27062, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tech_03_128.png"}
4676	27063	{"_key": 27063, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tech_04_128.png"}
4677	27064	{"_key": 27064, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tech_04_128.png"}
4678	27065	{"_key": 27065, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_redorange_polished_000_100_050.png"}
4679	27066	{"_key": 27066, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_redorange_polished_000_100_050.png"}
4680	27067	{"_key": 27067, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_brushed_000_100_010.png"}
4681	27068	{"_key": 27068, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_brushed_000_100_010.png"}
4682	27069	{"_key": 27069, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_redorange_brushed_000_100_100.png"}
4683	27070	{"_key": 27070, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_redorange_brushed_000_100_100.png"}
4684	27072	{"_key": 27072, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_orange_rough_000_100_100.png"}
4685	27073	{"_key": 27073, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_orange_rough_000_100_100.png"}
4686	27074	{"_key": 27074, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_matt_000_100_050.png"}
4687	27075	{"_key": 27075, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_matt_000_100_050.png"}
4688	27076	{"_key": 27076, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_matt_000_030_100.png"}
4689	27077	{"_key": 27077, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_matt_000_030_100.png"}
4690	27078	{"_key": 27078, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_gloss_000_030_100_cs180.png"}
4691	27079	{"_key": 27079, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_gloss_000_030_100_cs180.png"}
4692	27080	{"_key": 27080, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_gloss_000_100_010_cs180.png"}
4693	27081	{"_key": 27081, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_gloss_000_100_010_cs180.png"}
4694	27082	{"_key": 27082, "iconFile": "res:/ui/texture/icons/C4LNG/Token.png", "iconType": "png"}
4695	27083	{"_key": 27083, "iconFile": "res:/ui/texture/icons/C4LNG/Plate_Booster.png", "iconType": "png"}
4696	27084	{"_key": 27084, "iconFile": "res:/ui/texture/icons/C4LNG/Gold_A.png", "iconType": "png"}
4697	27085	{"_key": 27085, "iconFile": "res:/ui/texture/icons/C4LNG/Gold_B.png", "iconType": "png"}
4698	27086	{"_key": 27086, "iconFile": "res:/ui/texture/icons/C4LNG/Gold_C.png", "iconType": "png"}
4699	27087	{"_key": 27087, "iconFile": "res:/ui/texture/icons/C4LNG/Gold_X.png", "iconType": "png"}
4700	27088	{"_key": 27088, "iconFile": "res:/ui/texture/icons/C4LNG/Red_A.png", "iconType": "png"}
4701	27089	{"_key": 27089, "iconFile": "res:/ui/texture/icons/C4LNG/Red_B.png", "iconType": "png"}
4702	27090	{"_key": 27090, "iconFile": "res:/ui/texture/icons/C4LNG/Red_C.png", "iconType": "png"}
4703	27091	{"_key": 27091, "iconFile": "res:/ui/texture/icons/C4LNG/Red_X.png", "iconType": "png"}
4704	27092	{"_key": 27092, "iconFile": "res:/ui/texture/icons/YC127YearCardShipBox2.png", "iconType": "png"}
4705	27094	{"_key": 27094, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_berry_brushed_000_100_001.png"}
4706	27095	{"_key": 27095, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cherryred_highgloss_000_100_100.png"}
4707	27096	{"_key": 27096, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cherryred_rough_000_030_100.png"}
4708	27097	{"_key": 27097, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cherryred_rough_000_080_100.png"}
4709	27098	{"_key": 27098, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cherryred_satin_000_100_050_cs180.png"}
4710	27099	{"_key": 27099, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_satin_000_100_100_cs180.png"}
4711	27100	{"_key": 27100, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_magenta_metallic_000_030_100.png"}
4712	27101	{"_key": 27101, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cherryred_metallic_000_100_050.png"}
4713	27102	{"_key": 27102, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_rosered_metallic_000_100_001.png"}
4714	27103	{"_key": 27103, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_bw_metallic_000_000_050.png"}
4715	27104	{"_key": 27104, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_skull_t1_01_128.png"}
4716	27105	{"_key": 27105, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gradient_leak_01_128.png"}
4717	27106	{"_key": 27106, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_organic_01_128.png"}
4718	27107	{"_key": 27107, "iconFile": "res:/ui/texture/icons/Tickets/202509_Crescnet_Chip.png", "iconType": "png"}
4719	27108	{"_key": 27108, "iconFile": "res:/ui/texture/icons/Tickets/202509_Crescnet_Ticket.png", "iconType": "png"}
4720	27109	{"_key": 27109, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_groovy_01_128.png"}
4721	27110	{"_key": 27110, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_groovy_02_128.png"}
4722	27132	{"_key": 27132, "iconFile": "res:/ui/texture/icons/YC127steamBuildingBox.png", "iconType": "png"}
4723	27133	{"_key": 27133, "iconFile": "res:/ui/texture/icons/steam_building_chip.png", "iconType": "png"}
4724	27135	{"_key": 27135, "iconFile": "res:/ui/texture/icons/88_128_3.png", "iconType": "png"}
4725	27136	{"_key": 27136, "iconFile": "res:/ui/texture/icons/88_128_4.png", "iconType": "png"}
4726	27137	{"_key": 27137, "iconFile": "res:/ui/texture/icons/88_128_2.png", "iconType": "png"}
4727	27138	{"_key": 27138, "iconFile": "res:/ui/texture/icons/88_128_1.png", "iconType": "png"}
4728	27139	{"_key": 27139, "iconFile": "res:/ui/texture/icons/Prismaticite_Ore_64.png"}
4729	27147	{"_key": 27147, "iconFile": "res:/ui/texture/icons/Quafe/QuafeApple.png", "iconType": "png"}
4730	27148	{"_key": 27148, "iconFile": "res:/ui/texture/icons/Quafe/QuafeCherry.png", "iconType": "png"}
4731	27149	{"_key": 27149, "iconFile": "res:/ui/texture/icons/Quafe/QuafeBerry.png", "iconType": "png"}
4732	27150	{"_key": 27150, "iconFile": "res:/ui/texture/icons/Quafe/QuafeLemon.png", "iconType": "png"}
4733	27151	{"_key": 27151, "iconFile": "res:/ui/texture/icons/Quafe/QuafeOrange.png", "iconType": "png"}
4734	27152	{"_key": 27152, "iconFile": "res:/ui/texture/icons/Quafe/QuafePeach.png", "iconType": "QuafePeach"}
4735	27154	{"_key": 27154, "iconFile": "res:/ui/texture/icons/Prismaticite_Ore_Compressed_64.png"}
4736	27155	{"_key": 27155, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_metallic_000_100_100.png"}
4737	27156	{"_key": 27156, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_metallic_000_100_100.png"}
4738	27157	{"_key": 27157, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_purple_polished_holo_001_100_010.png"}
4739	27158	{"_key": 27158, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_purple_polished_holo_001_100_010.png"}
4740	27159	{"_key": 27159, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_orange_gloss_000_100_050.png"}
4741	27160	{"_key": 27160, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_orange_gloss_000_100_050.png"}
4742	27161	{"_key": 27161, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_safetyorange_gloss_000_100_050.png"}
4743	27162	{"_key": 27162, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_safetyorange_gloss_000_100_050.png"}
4744	27163	{"_key": 27163, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_safetyorange_matt_000_100_010.png"}
4745	27164	{"_key": 27164, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_safetyorange_matt_000_100_010.png"}
4746	27165	{"_key": 27165, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_red_matt_000_100_001.png"}
4747	27166	{"_key": 27166, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_red_matt_000_100_001.png"}
4748	27167	{"_key": 27167, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_malachite_matt_000_080_100.png"}
4749	27168	{"_key": 27168, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_malachite_matt_000_080_100.png"}
4750	27169	{"_key": 27169, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_gloss_000_100_050.png"}
4751	27170	{"_key": 27170, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_gloss_000_100_050.png"}
4752	27171	{"_key": 27171, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_bw_flat_000_000_000.png"}
4753	27172	{"_key": 27172, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_bw_flat_000_000_000.png"}
4754	27173	{"_key": 27173, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_gloss_000_030_100_cs180.png"}
4755	27174	{"_key": 27174, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_gloss_000_030_100_cs180.png"}
4756	27175	{"_key": 27175, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_orange_gloss_000_100_010_cs180.png"}
4757	27176	{"_key": 27176, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_orange_gloss_000_100_010_cs180.png"}
4758	27177	{"_key": 27177, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_rock_01_128.png"}
4759	27178	{"_key": 27178, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_rock_01_128.png"}
4760	27179	{"_key": 27179, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_rock_02_128.png"}
4761	27180	{"_key": 27180, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_rock_02_128.png"}
4762	27181	{"_key": 27181, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_rock_03_128.png"}
4763	27182	{"_key": 27182, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_rock_03_128.png"}
4764	27183	{"_key": 27183, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_geometric_01_128.png"}
4765	27184	{"_key": 27184, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_geometric_01_128.png"}
4766	27185	{"_key": 27185, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_dazzle_03_128.png"}
4767	27186	{"_key": 27186, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_dazzle_03_128.png"}
4768	27187	{"_key": 27187, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_rust_01_128.png"}
4769	27188	{"_key": 27188, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_rust_01_128.png"}
4770	27189	{"_key": 27189, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_leaf_03_128.png"}
4771	27190	{"_key": 27190, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_leaf_03_128.png"}
4772	27191	{"_key": 27191, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_drifter_circle_01_128.png"}
4773	27192	{"_key": 27192, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_drifter_circle_01_128.png"}
4774	27193	{"_key": 27193, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_abstract_01_128.png"}
4775	27194	{"_key": 27194, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_abstract_01_128.png"}
4776	27195	{"_key": 27195, "iconFile": "res:/UI/Texture/Icons/StatusEffects/mining_phase_stabilizer_64.png"}
4777	27196	{"_key": 27196, "iconFile": "res:/dx9/model/worldobject/Forcefield/icons/28907_64_bpc.png", "iconType": "png"}
4778	27197	{"_key": 27197, "iconFile": "res:/dx9/model/worldobject/Forcefield/icons/28908_64_bpc.png", "iconType": "png"}
4779	27198	{"_key": 27198, "iconFile": "res:/UI/Texture/MiningMutaplasmids/gas_cloud_harvester_decayed.png"}
4780	27199	{"_key": 27199, "iconFile": "res:/UI/Texture/MiningMutaplasmids/gas_cloud_harvester_gravid.png"}
4781	27200	{"_key": 27200, "iconFile": "res:/UI/Texture/MiningMutaplasmids/gas_cloud_harvester_unstable.png"}
4782	27201	{"_key": 27201, "iconFile": "res:/UI/Texture/MiningMutaplasmids/gas_cloud_scoop_decayed.png"}
4783	27202	{"_key": 27202, "iconFile": "res:/UI/Texture/MiningMutaplasmids/gas_cloud_scoop_gravid.png"}
4784	27203	{"_key": 27203, "iconFile": "res:/UI/Texture/MiningMutaplasmids/gas_cloud_scoop_unstable.png"}
4785	27204	{"_key": 27204, "iconFile": "res:/UI/Texture/MiningMutaplasmids/ice_harvester.png"}
4786	27205	{"_key": 27205, "iconFile": "res:/UI/Texture/MiningMutaplasmids/ice_harvester_decayed.png"}
4787	27206	{"_key": 27206, "iconFile": "res:/UI/Texture/MiningMutaplasmids/ice_harvester_gravid.png"}
4788	27207	{"_key": 27207, "iconFile": "res:/UI/Texture/MiningMutaplasmids/ice_harvester_unstable.png"}
4789	27208	{"_key": 27208, "iconFile": "res:/UI/Texture/MiningMutaplasmids/ice_mining_laser_decayed.png"}
4790	27209	{"_key": 27209, "iconFile": "res:/UI/Texture/MiningMutaplasmids/ice_mining_laser_gravid.png"}
4791	27210	{"_key": 27210, "iconFile": "res:/UI/Texture/MiningMutaplasmids/ice_mining_laser_unstable.png"}
4792	27211	{"_key": 27211, "iconFile": "res:/UI/Texture/MiningMutaplasmids/mining.png"}
4793	27212	{"_key": 27212, "iconFile": "res:/UI/Texture/MiningMutaplasmids/mining_laser_decayed.png"}
4794	27213	{"_key": 27213, "iconFile": "res:/UI/Texture/MiningMutaplasmids/mining_laser_gravid.png"}
4795	27214	{"_key": 27214, "iconFile": "res:/UI/Texture/MiningMutaplasmids/mining_laser_unstable.png"}
4796	27215	{"_key": 27215, "iconFile": "res:/UI/Texture/MiningMutaplasmids/strip_mining_laser_decayed.png"}
4797	27216	{"_key": 27216, "iconFile": "res:/UI/Texture/MiningMutaplasmids/strip_mining_laser_gravid.png"}
4798	27217	{"_key": 27217, "iconFile": "res:/UI/Texture/MiningMutaplasmids/strip_mining_laser_unstable.png"}
4799	27218	{"_key": 27218, "iconFile": "res:/UI/Texture/Icons/Ammo/erraticOreMiningCrystal_a_t1.png"}
4800	27219	{"_key": 27219, "iconFile": "res:/UI/Texture/Icons/Ammo/erraticOreMiningCrystal_a_t2.png"}
4801	27220	{"_key": 27220, "iconFile": "res:/UI/Texture/Icons/Ammo/erraticOreMiningCrystal_b_t1.png"}
4802	27221	{"_key": 27221, "iconFile": "res:/UI/Texture/Icons/Ammo/erraticOreMiningCrystal_b_t2.png"}
4803	27222	{"_key": 27222, "iconFile": "res:/UI/Texture/Icons/Ammo/erraticOreMiningCrystal_c_t1.png"}
4804	27223	{"_key": 27223, "iconFile": "res:/UI/Texture/Icons/Ammo/erraticOreMiningCrystal_c_t2.png"}
4805	27224	{"_key": 27224, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_metallic_000_080_100.png"}
4806	27225	{"_key": 27225, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_metallic_000_080_100.png"}
4807	27226	{"_key": 27226, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_metallic_000_080_100.png"}
4808	27227	{"_key": 27227, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_metallic_000_080_100.png"}
4809	27228	{"_key": 27228, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_caldari_tournament_XXI_128.png"}
4810	27229	{"_key": 27229, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_caldari_tournament_XXI_128.png"}
4811	27230	{"_key": 27230, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_caldari_tournament_XXI_128.png"}
4812	27247	{"_key": 27247, "iconFile": "res:/ui/texture/icons/inventory/mineral_unrefined_tritanium.png"}
4813	27248	{"_key": 27248, "iconFile": "res:/ui/texture/icons/inventory/mineral_unrefined_pyerite.png"}
4814	27249	{"_key": 27249, "iconFile": "res:/ui/texture/icons/inventory/mineral_unrefined_isogen.png"}
4815	27250	{"_key": 27250, "iconFile": "res:/ui/texture/icons/inventory/mineral_unrefined_nocxium.png"}
4816	27251	{"_key": 27251, "iconFile": "res:/ui/texture/icons/inventory/mineral_unrefined_morphite.png"}
4817	27252	{"_key": 27252, "iconFile": "res:/ui/texture/icons/inventory/mineral_unrefined_mexallon.png"}
4818	27253	{"_key": 27253, "iconFile": "res:/ui/texture/icons/inventory/mineral_unrefined_zydrine.png"}
4819	27254	{"_key": 27254, "iconFile": "res:/ui/texture/icons/inventory/mineral_unrefined_megacyte.png"}
4820	27255	{"_key": 27255, "iconFile": "res:/ui/texture/icons/inventory/mineral_formula_tritanium.png"}
4821	27256	{"_key": 27256, "iconFile": "res:/ui/texture/icons/inventory/mineral_formula_pyerite.png"}
4822	27257	{"_key": 27257, "iconFile": "res:/ui/texture/icons/inventory/mineral_formula_mexallon.png"}
4823	27258	{"_key": 27258, "iconFile": "res:/ui/texture/icons/inventory/mineral_formula_isogen.png"}
4824	27259	{"_key": 27259, "iconFile": "res:/ui/texture/icons/inventory/mineral_formula_nocxium.png"}
4825	27260	{"_key": 27260, "iconFile": "res:/ui/texture/icons/inventory/mineral_formula_zydrine.png"}
4826	27261	{"_key": 27261, "iconFile": "res:/ui/texture/icons/inventory/mineral_formula_megacyte.png"}
4827	27262	{"_key": 27262, "iconFile": "res:/ui/texture/icons/inventory/mineral_formula_morphite.png"}
4828	27263	{"_key": 27263, "iconFile": "res:/UI/Texture/Icons/shipAdaption/chip4-64.png", "iconType": "png"}
4829	27264	{"_key": 27264, "iconFile": "res:/UI/Texture/Icons/shipAdaption/material.png", "iconType": "png"}
4830	27265	{"_key": 27265, "iconFile": "res:/UI/Texture/Icons/shipAdaption/chip_item.png", "iconType": "png"}
4831	27266	{"_key": 27266, "iconFile": "res:/UI/Texture/Icons/Modules/fleetBoost_MiningCrit.png"}
4832	27267	{"_key": 27267, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_ama_05_128.png"}
4833	27268	{"_key": 27268, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_ama_05_128.png"}
4834	27269	{"_key": 27269, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_ama_05_128.png"}
4835	27270	{"_key": 27270, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_ornament_01_128.png"}
4836	27271	{"_key": 27271, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_ornament_01_128.png"}
4837	27272	{"_key": 27272, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_art_deco_01_2K_128.png"}
4838	27273	{"_key": 27273, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_winter_10_128.png"}
4839	27274	{"_key": 27274, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_winter_10_128.png"}
4840	27275	{"_key": 27275, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_winter_08_128.png"}
4841	27276	{"_key": 27276, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_winter_08_128.png"}
4842	27277	{"_key": 27277, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_winter_05_128.png"}
4843	27278	{"_key": 27278, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_winter_05_128.png"}
4844	27279	{"_key": 27279, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_winter_16_128.png"}
4845	27280	{"_key": 27280, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_winter_16_128.png"}
4846	27281	{"_key": 27281, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_winter_12_128.png"}
4847	27282	{"_key": 27282, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_winter_12_128.png"}
4848	27283	{"_key": 27283, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_winter_07_128.png"}
4849	27284	{"_key": 27284, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_winter_07_128.png"}
4850	27285	{"_key": 27285, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_winter_11_128.png"}
4851	27286	{"_key": 27286, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_winter_11_128.png"}
4852	27287	{"_key": 27287, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_organic_10_128.png"}
4853	27288	{"_key": 27288, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_winter_09_128.png"}
4854	27289	{"_key": 27289, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_winter_06_128.png"}
4855	27290	{"_key": 27290, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_winter_14_128.png"}
4856	27291	{"_key": 27291, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_winter_14_128.png"}
4857	27292	{"_key": 27292, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_gloss_000_060_100_cs180.png"}
4858	27293	{"_key": 27293, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_malachite_highgloss_000_100_010_cs180.png"}
4859	27294	{"_key": 27294, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_orange_matt_000_100_010_cs180.png"}
4860	27295	{"_key": 27295, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_emerald_brushed_000_060_100.png"}
4861	27296	{"_key": 27296, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_emerald_brushed_000_060_100.png"}
4862	27297	{"_key": 27297, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_polished_000_080_100.png"}
4863	27298	{"_key": 27298, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_polished_000_080_100.png"}
4864	27299	{"_key": 27299, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_emerald_polished_000_100_010.png"}
4865	27300	{"_key": 27300, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_emerald_polished_000_100_010.png"}
4866	27301	{"_key": 27301, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_gloss_000_030_100.png"}
4867	27302	{"_key": 27302, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_gloss_000_030_100.png"}
4868	27303	{"_key": 27303, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_highgloss_000_100_001.png"}
4869	27304	{"_key": 27304, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_highgloss_000_100_001.png"}
4870	27305	{"_key": 27305, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_rosered_satin_000_100_050.png"}
4871	27306	{"_key": 27306, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_rosered_satin_000_100_050.png"}
4872	27307	{"_key": 27307, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_royal_metallic_000_100_100.png"}
4873	27309	{"_key": 27309, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_brass_metallic_013_051_089.png"}
4874	27319	{"_key": 27319, "iconFile": "res:/ui/texture/icons/DHH/booster1.png", "iconType": "png"}
4875	27320	{"_key": 27320, "iconFile": "res:/ui/texture/icons/DHH/booster2.png", "iconType": "png"}
4876	27321	{"_key": 27321, "iconFile": "res:/ui/texture/icons/DHH/booster3.png", "iconType": "png"}
4877	27322	{"_key": 27322, "iconFile": "res:/ui/texture/icons/DHH/booster4.png", "iconType": "png"}
4878	27323	{"_key": 27323, "iconFile": "res:/ui/texture/icons/DHH/booster5.png", "iconType": "png"}
4879	27324	{"_key": 27324, "iconFile": "res:/ui/texture/icons/DHH/notes.png", "iconType": "png"}
4880	27325	{"_key": 27325, "iconFile": "res:/ui/texture/icons/DHH/chest.png", "iconType": "png"}
4881	27326	{"_key": 27326, "iconFile": "res:/ui/texture/icons/DHH/rum.png", "iconType": "png"}
4882	27327	{"_key": 27327, "iconFile": "res:/ui/texture/icons/DHH/driver.png", "iconType": "png"}
4883	27328	{"_key": 27328, "iconFile": "res:/ui/texture/icons/DHH/scope.png", "iconType": "png"}
4884	27329	{"_key": 27329, "iconFile": "res:/ui/texture/icons/DHH/plate.png", "iconType": "png"}
4885	27330	{"_key": 27330, "iconFile": "res:/ui/texture/icons/DHH/map.png", "iconType": "png"}
4886	27331	{"_key": 27331, "iconFile": "res:/ui/texture/icons/DHH/blueprint.png", "iconType": "png"}
4887	27332	{"_key": 27332, "iconFile": "res:/ui/texture/icons/DHH/coins.png", "iconType": "png"}
4888	27333	{"_key": 27333, "iconFile": "res:/ui/texture/icons/DHH/parts.png", "iconType": "png"}
4889	27334	{"_key": 27334, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_metallic_000_100_001.png"}
4890	27335	{"_key": 27335, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_geomask_01_128.png"}
4891	27336	{"_key": 27336, "iconFile": "res:/UI/Texture/Icons/Inventory/Drifter_Data_64.png", "iconType": "png"}
4892	27337	{"_key": 27337, "iconFile": "res:/UI/Texture/Icons/Inventory/Drifter_Key_64.png", "iconType": "png"}
4893	27340	{"_key": 27340, "iconFile": "res:/UI/Texture/Icons/Inventory/triglavianLockedData.png", "iconType": "png"}
4894	27345	{"_key": 27345, "iconFile": "res:/ui/texture/icons/inventory/icon_background_03.png"}
4895	27346	{"_key": 27346, "iconFile": "res:/UI/Texture/Icons/Inventory/amarr_yellow_128.png"}
4896	27347	{"_key": 27347, "iconFile": "res:/UI/Texture/Icons/Inventory/amarr_yellow_64.png"}
4897	27348	{"_key": 27348, "iconFile": "res:/UI/Texture/Icons/Inventory/caldari_blue_128.png"}
4898	27349	{"_key": 27349, "iconFile": "res:/UI/Texture/Icons/Inventory/caldari_blue_64.png"}
4899	27350	{"_key": 27350, "iconFile": "res:/UI/Texture/Icons/Inventory/gallente_green_64.png"}
4900	27351	{"_key": 27351, "iconFile": "res:/UI/Texture/Icons/Inventory/gallente_green_128.png"}
4901	27352	{"_key": 27352, "iconFile": "res:/UI/Texture/Icons/Inventory/minmatar_red_128.png"}
4902	27353	{"_key": 27353, "iconFile": "res:/UI/Texture/Icons/Inventory/minmatar_red_64.png"}
4903	27354	{"_key": 27354, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_voteday_128.png"}
4904	27355	{"_key": 27355, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_voteday_128.png"}
4905	27356	{"_key": 27356, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_voteday_today_128.png"}
4906	27357	{"_key": 27357, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_voteday_today_128.png"}
4907	27358	{"_key": 27358, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_highgloss_000_030_100_cs180.png"}
4908	27359	{"_key": 27359, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_highgloss_000_030_100_cs180.png"}
4909	27360	{"_key": 27360, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_matt_000_100_010_cs180.png"}
4910	27361	{"_key": 27361, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_matt_000_100_010_cs180.png"}
4911	27362	{"_key": 27362, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_malachite_matt_000_100_100_cs180.png"}
4912	27363	{"_key": 27363, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_malachite_matt_000_100_100_cs180.png"}
4913	27364	{"_key": 27364, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_brushed_000_100_001.png"}
4914	27365	{"_key": 27365, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_brushed_000_100_001.png"}
4915	27366	{"_key": 27366, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_brushed_000_100_010.png"}
4916	27367	{"_key": 27367, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_brushed_000_100_010.png"}
4917	27368	{"_key": 27368, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_brushed_000_100_010.png"}
4918	27369	{"_key": 27369, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_clover_brushed_000_100_010.png"}
4919	27370	{"_key": 27370, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_vanadium_brushed_057_004_054.png"}
4920	27371	{"_key": 27371, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_vanadium_brushed_057_004_054.png"}
4921	27372	{"_key": 27372, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_bw_brushed_000_000_000.png"}
4922	27373	{"_key": 27373, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_bw_brushed_000_000_000.png"}
4923	27383	{"_key": 27383, "iconFile": "res:/UI/Asset/mannequin/outer/92631_Female_Outer_ArmorSuitCF01_Types_ArmorSuitCF01_Glam.png", "iconType": "png"}
4924	27384	{"_key": 27384, "iconFile": "res:/UI/Asset/mannequin/outer/92644_Male_outer_ArmorSuitMM01_Types_ArmorSuitMM01_Glem.png", "iconType": "png"}
4925	27385	{"_key": 27385, "iconFile": "res:/ui/texture/icons/inventory/trading_token_elite_128.png"}
4926	27386	{"_key": 27386, "iconFile": "res:/ui/texture/icons/inventory/trading_token_regular_128.png"}
4927	27387	{"_key": 27387, "iconFile": "res:/ui/texture/icons/inventory/Gallente_crate_splashscreen_512.png"}
4928	27388	{"_key": 27388, "iconFile": "res:/ui/texture/icons/inventory/FabricatorData.png", "iconType": "png"}
4929	27393	{"_key": 27393, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_emerald_metallic_000_080_100.png"}
4930	27394	{"_key": 27394, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_emerald_matt_000_100_050.png"}
4931	27395	{"_key": 27395, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_emerald_satin_000_100_001.png"}
4932	27396	{"_key": 27396, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_safetyorange_brushed_000_100_010.png"}
4933	27397	{"_key": 27397, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_red_satin_000_100_001.png"}
4934	27398	{"_key": 27398, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_pea_matt_000_100_010.png"}
4935	27399	{"_key": 27399, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_blue_gloss_000_100_010.png"}
4936	27400	{"_key": 27400, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_aluminum_rough_063_001_092.png"}
4937	27401	{"_key": 27401, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_blue_rough_000_100_001.png"}
4938	27402	{"_key": 27402, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turmeric_metallic_000_030_100.png"}
4939	27403	{"_key": 27403, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turmeric_brushed_000_060_100.png"}
4940	27404	{"_key": 27404, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_tungsten_rough_013_005_050.png"}
4941	27405	{"_key": 27405, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_ama_19_128.png"}
4942	27406	{"_key": 27406, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_ama_02_128.png"}
4943	27407	{"_key": 27407, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_arrows_17_128.png"}
4944	27408	{"_key": 27408, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_cal_01c_128.png"}
4945	27409	{"_key": 27409, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_gal_06_128.png"}
4946	27410	{"_key": 27410, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_gal_01_128.png"}
4947	27411	{"_key": 27411, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_stripe_17_128.png"}
4948	27412	{"_key": 27412, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_min_10_128.png"}
4949	27413	{"_key": 27413, "iconFile": "res:/ui/Texture/classes/Menu/Icons/info_glyph.png", "iconType": "png"}
4950	27414	{"_key": 27414, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_anger_games_01_128.png"}
4951	27415	{"_key": 27415, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_ama_logo_01_128.png"}
4952	27416	{"_key": 27416, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_ama_logo_01_128.png"}
4953	27417	{"_key": 27417, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_logo_01_128.png"}
4954	27418	{"_key": 27418, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_logo_01_128.png"}
4955	27419	{"_key": 27419, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_cal_logo_01_128.png"}
4956	27420	{"_key": 27420, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_cal_logo_01_128.png"}
4957	27421	{"_key": 27421, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_minmatar_logo_01_128.png"}
4958	27422	{"_key": 27422, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_minmatar_logo_01_128.png"}
4959	27423	{"_key": 27423, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_jita44_01_128.png"}
4960	27424	{"_key": 27424, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_jita44_01_128.png"}
4961	27425	{"_key": 27425, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_jita444_01_128.png"}
4962	27426	{"_key": 27426, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_jita444_01_128.png"}
4963	27427	{"_key": 27427, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_groovy_03_128.png"}
4964	27428	{"_key": 27428, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_groovy_03_128.png"}
4965	27429	{"_key": 27429, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gradient_circle_02_128.png"}
4966	27430	{"_key": 27430, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gradient_circle_02_128.png"}
4967	27431	{"_key": 27431, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tactical_10_128.png"}
4968	27432	{"_key": 27432, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tactical_10_128.png"}
4969	27433	{"_key": 27433, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_splatter_04_128.png"}
4970	27434	{"_key": 27434, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_splatter_04_128.png"}
4971	27435	{"_key": 27435, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_gal_08b_128.png"}
4972	27436	{"_key": 27436, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_gal_08b_128.png"}
4973	27438	{"_key": 27438, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_ama_02_128.png"}
4974	27439	{"_key": 27439, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_ama_19_128.png"}
4975	27440	{"_key": 27440, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_tungsten_rough_013_005_050.png"}
4976	27441	{"_key": 27441, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turmeric_metallic_000_030_100.png"}
4977	27442	{"_key": 27442, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turmeric_brushed_000_060_100.png"}
4978	27443	{"_key": 27443, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_arrows_17_128.png"}
4979	27444	{"_key": 27444, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_cal_01c_128.png"}
4980	27445	{"_key": 27445, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_blue_gloss_000_100_010.png"}
4981	27446	{"_key": 27446, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_aluminum_rough_063_001_092.png"}
4982	27447	{"_key": 27447, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_blue_rough_000_100_001.png"}
4983	27448	{"_key": 27448, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_gal_06_128.png"}
4984	27449	{"_key": 27449, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_gal_01_128.png"}
4985	27450	{"_key": 27450, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_emerald_matt_000_100_050.png"}
4986	27451	{"_key": 27451, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_emerald_metallic_000_080_100.png"}
4987	27452	{"_key": 27452, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_emerald_satin_000_100_001.png"}
4988	27453	{"_key": 27453, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_stripe_17_128.png"}
4989	27454	{"_key": 27454, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_min_10_128.png"}
4990	27455	{"_key": 27455, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_safetyorange_brushed_000_100_010.png"}
4991	27456	{"_key": 27456, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_red_satin_000_100_001.png"}
4992	27457	{"_key": 27457, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_pea_matt_000_100_010.png"}
4993	27463	{"_key": 27463, "iconFile": "res:/UI/Asset/mannequin/topmiddle/93589_Female_TopMiddle_ShirtQF01_Types_soerff03.png", "iconType": "png"}
4994	27464	{"_key": 27464, "iconFile": "res:/UI/Asset/mannequin/topmiddle/93590_Male_topMiddle_ShirtQM01_Types_soerfm03.png", "iconType": "png"}
4995	27466	{"_key": 27466, "iconFile": "res:/UI/Texture/Icons/Inventory/warpath_regular_token.png"}
4996	27467	{"_key": 27467, "iconFile": "res:/UI/Texture/Icons/Inventory/warpath_elite_token.png"}
4997	27468	{"_key": 27468, "iconFile": "res:/UI/Asset/mannequin/outer/93725_Female_Outer_LabCoatF01_Types_LabCoatF01_WhiteRed.png", "iconType": "png"}
4998	27469	{"_key": 27469, "iconFile": "res:/UI/Asset/mannequin/outer/93737_Male_outer_LabCoatM01_Types_LabCoatM01_WhiteRed.png", "iconType": "png"}
4999	27470	{"_key": 27470, "iconFile": "res:/UI/Texture/Icons/skillinjector_blood_64.png", "iconType": "png"}
5000	27471	{"_key": 27471, "iconFile": "res:/ui/texture/icons/inventory/EmpireCrate_Amarr.png"}
5001	27472	{"_key": 27472, "iconFile": "res:/ui/texture/icons/inventory/EmpireCrate_Caldari.png"}
5002	27473	{"_key": 27473, "iconFile": "res:/ui/texture/icons/inventory/EmpireCrate_Gallente.png"}
5003	27474	{"_key": 27474, "iconFile": "res:/ui/texture/icons/inventory/EmpireCrate_Minmatar.png"}
5004	27475	{"_key": 27475, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_0_128.png"}
5005	27476	{"_key": 27476, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_0_128.png"}
5006	27477	{"_key": 27477, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_1_128.png"}
5007	27478	{"_key": 27478, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_1_128.png"}
5008	27479	{"_key": 27479, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_2_128.png"}
5009	27480	{"_key": 27480, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_2_128.png"}
5010	27481	{"_key": 27481, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_3_128.png"}
5011	27482	{"_key": 27482, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_3_128.png"}
5012	27483	{"_key": 27483, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_4_128.png"}
5013	27484	{"_key": 27484, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_4_128.png"}
5014	27485	{"_key": 27485, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_5_128.png"}
5015	27486	{"_key": 27486, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_5_128.png"}
5016	27487	{"_key": 27487, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_6_128.png"}
5017	27488	{"_key": 27488, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_6_128.png"}
5018	27489	{"_key": 27489, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_7_128.png"}
5019	27490	{"_key": 27490, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_7_128.png"}
5020	27491	{"_key": 27491, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_8_128.png"}
5021	27492	{"_key": 27492, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_8_128.png"}
5022	27493	{"_key": 27493, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_9_128.png"}
5023	27494	{"_key": 27494, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_gallente_nr_9_128.png"}
5024	27495	{"_key": 27495, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_ama_04_128.png"}
5025	27496	{"_key": 27496, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_ama_04_128.png"}
5026	27497	{"_key": 27497, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_gal_10_128.png"}
5027	27498	{"_key": 27498, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_gal_10_128.png"}
5028	27499	{"_key": 27499, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_cal_02_128.png"}
5029	27500	{"_key": 27500, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_cal_02_128.png"}
5030	27501	{"_key": 27501, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_min_12_128.png"}
5031	27502	{"_key": 27502, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_racial_min_12_128.png"}
5032	27503	{"_key": 27503, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_chartreuse_gloss_000_100_050.png"}
5033	27504	{"_key": 27504, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_chartreuse_gloss_000_100_050.png"}
5034	27505	{"_key": 27505, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_satin_000_100_050.png"}
5035	27506	{"_key": 27506, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turquoise_satin_000_100_050.png"}
5036	27507	{"_key": 27507, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_purple_matt_000_030_100.png"}
5037	27508	{"_key": 27508, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_purple_matt_000_030_100.png"}
5038	27509	{"_key": 27509, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_chartreuse_matt_000_080_100.png"}
5039	27510	{"_key": 27510, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_chartreuse_matt_000_080_100.png"}
5040	27511	{"_key": 27511, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_pea_gloss_000_100_100_cs180.png"}
5041	27512	{"_key": 27512, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_pea_gloss_000_100_100_cs180.png"}
5042	27513	{"_key": 27513, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_pea_metallic_000_100_050.png"}
5043	27514	{"_key": 27514, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_pea_metallic_000_100_050.png"}
5044	27515	{"_key": 27515, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_pea_polished_000_100_001.png"}
5045	27516	{"_key": 27516, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_pea_polished_000_100_001.png"}
5046	27517	{"_key": 27517, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_crack_01_128.png"}
5047	27518	{"_key": 27518, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_crack_01_128.png"}
5048	27519	{"_key": 27519, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tribal_star_01_128.png"}
5049	27520	{"_key": 27520, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tribal_star_01_128.png"}
5050	27521	{"_key": 27521, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_fw_02_128.png"}
5051	27522	{"_key": 27522, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_fw_02_128.png"}
5052	27523	{"_key": 27523, "iconFile": "res:/ui/texture/corps/IMN_128.png"}
5053	27524	{"_key": 27524, "iconFile": "res:/ui/texture/corps/VerityEnhancements_128.png"}
5054	27525	{"_key": 27525, "iconFile": "res:/ui/texture/corps/VaporSeaTechnologies_128.png"}
5055	27526	{"_key": 27526, "iconFile": "res:/ui/texture/corps/Cromeaux_128.png"}
5056	27527	{"_key": 27527, "iconFile": "res:/ui/texture/corps/AdaptiveProvisioning_128.png"}
5057	27528	{"_key": 27528, "iconFile": "res:/ui/texture/icons/icon_background_04.png"}
5058	27529	{"_key": 27529, "iconFile": "res:/ui/texture/icons/icon_background_05.png"}
5059	27533	{"_key": 27533, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_orange_metallic_000_100_050.png"}
5060	27534	{"_key": 27534, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_orange_metallic_000_100_050.png"}
5061	27535	{"_key": 27535, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_orange_polished_000_100_100.png"}
5062	27536	{"_key": 27536, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_orange_polished_000_100_100.png"}
5063	27537	{"_key": 27537, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_orange_rough_000_100_050.png"}
5064	27538	{"_key": 27538, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_orange_rough_000_100_050.png"}
5065	27539	{"_key": 27539, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_gloss_000_080_100.png"}
5066	27540	{"_key": 27540, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_gloss_000_080_100.png"}
5067	27541	{"_key": 27541, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_brushed_000_060_100.png"}
5068	27542	{"_key": 27542, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_brushed_000_060_100.png"}
5069	27543	{"_key": 27543, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_matt_000_080_100.png"}
5070	27544	{"_key": 27544, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_cyan_matt_000_080_100.png"}
5071	27545	{"_key": 27545, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_coateds180_056_100_100.png"}
5072	27546	{"_key": 27546, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_azure_coateds180_056_100_100.png"}
5073	27547	{"_key": 27547, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turmeric_gloss_000_100_100_cs180.png"}
5074	27548	{"_key": 27548, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/materials/cosm_turmeric_gloss_000_100_100_cs180.png"}
5075	27549	{"_key": 27549, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tactical_07_128.png"}
5076	27550	{"_key": 27550, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tactical_07_128.png"}
5077	27551	{"_key": 27551, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tactical_12_128.png"}
5078	27552	{"_key": 27552, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tactical_12_128.png"}
5079	27553	{"_key": 27553, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tactical_13_128.png"}
5080	27554	{"_key": 27554, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_tactical_13_128.png"}
5081	27555	{"_key": 27555, "iconFile": "res:/ui/texture/icons/inventory/icon_background_20R.png"}
5082	27556	{"_key": 27556, "iconFile": "res:/ui/texture/icons/inventory/icon_background_20B.png"}
5083	27557	{"_key": 27557, "iconFile": "res:/ui/texture/icons/inventory/icon_background_20G.png"}
5084	27558	{"_key": 27558, "iconFile": "res:/UI/Texture/Icons/Inventory/ExpertSystems/GallenteExpert.png"}
5085	27559	{"_key": 27559, "iconFile": "res:/UI/Texture/Icons/Inventory/ExpertSystems/AmarrExpert.png"}
5086	27560	{"_key": 27560, "iconFile": "res:/UI/Texture/Icons/Inventory/ExpertSystems/CaldariExpert.png"}
5087	27561	{"_key": 27561, "iconFile": "res:/UI/Texture/Icons/Inventory/ExpertSystems/MinamtarExpert.png"}
5088	27562	{"_key": 27562, "iconFile": "res:/UI/Texture/Icons/Modules/Damage_Control_Variant.png"}
5089	27572	{"_key": 27572, "iconFile": "res:/ui/texture/icons/icon_background_06.png"}
5090	27574	{"_key": 27574, "iconFile": "res:/ui/texture/icons/inventory/Background_97_thumb.png"}
5091	27575	{"_key": 27575, "iconFile": "res:/ui/texture/icons/PhyseterTicket.png", "iconType": "png"}
5092	27576	{"_key": 27576, "iconFile": "res:/ui/texture/icons/PhyseterChip.png", "iconType": "png"}
5093	27577	{"_key": 27577, "iconFile": "res:/ui/texture/icons/vanguard_token.png"}
5094	27578	{"_key": 27578, "iconFile": "res:/ui/texture/icons/vanguard_token_special.png"}
5095	27579	{"_key": 27579, "iconFile": "res:/ui/texture/icons/inventory/operation_avalon_cb.png"}
5096	27580	{"_key": 27580, "iconFile": "res:/ui/texture/icons/icon_background_07.png"}
5097	27581	{"_key": 27581, "iconFile": "res:/ui/texture/icons/icon_background_08.png"}
5098	27582	{"_key": 27582, "iconFile": "res:/ui/texture/icons/icon_background_09.png"}
5099	27583	{"_key": 27583, "iconFile": "res:/UI/Texture/Icons/Inventory/rampant_data_64.png"}
5100	27584	{"_key": 27584, "iconFile": "res:/UI/Texture/classes/Cosmetics/Ship/patterns/cosm_horde_mode_128.png"}
5101	27586	{"_key": 27586, "iconFile": "res:/ui/texture/icons/inventory/icon_background_MajBasic.png", "iconType": "png"}
5102	27587	{"_key": 27587, "iconFile": "res:/ui/texture/icons/inventory/icon_background_MajGold.png", "iconType": "png"}
5103	27588	{"_key": 27588, "iconFile": "res:/ui/texture/icons/inventory/icon_background_MajSilver.png", "iconType": "png"}
5104	27589	{"_key": 27589, "iconFile": "res:/ui/texture/icons/inventory/icon_background_MajBronze.png"}
5105	27590	{"_key": 27590, "iconFile": "res:/ui/texture/icons/inventory/icon_MajNorth.png", "iconType": "png"}
5106	27596	{"_key": 27596, "iconFile": "res:/ui/texture/icons/YC128YearCardShipBox.png", "iconType": "png"}
\.


--
-- Name: iconids iconids_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.iconids
    ADD CONSTRAINT iconids_pkey PRIMARY KEY (row_no);


--
-- Name: iconids_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX iconids_key_idx ON sde_native.iconids USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict eT98L6XKo4G8dkZ8MVrmtfcci4a7lcq7CCi9BM4j1qR6HBcczyn50RM4astCOXy

