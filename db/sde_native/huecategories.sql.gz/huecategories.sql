--
-- PostgreSQL database dump
--

\restrict 8JDUr3hTCd5e0LRFgvcbKC0SNzZqvSKzpmj3XKbU7LWIMm1RkWYG0TyTTZ1um5i

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: huecategories; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.huecategories (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: huecategories; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.huecategories (row_no, key, data) FROM stdin;
0	azure	{"hue": 200, "_key": "azure", "hueNameID": 655055}
1	berry	{"hue": 320, "_key": "berry", "hueNameID": 655074}
2	blue	{"hue": 240, "_key": "blue", "hueNameID": 655054}
3	bw	{"hue": 0, "_key": "bw", "hueNameID": 655076}
4	chartreuse	{"hue": 76, "_key": "chartreuse", "hueNameID": 655061}
5	cheese	{"hue": 50, "_key": "cheese", "hueNameID": 655058}
6	clover	{"hue": 147, "_key": "clover", "hueNameID": 655063}
7	cyan	{"hue": 180, "_key": "cyan", "hueNameID": 655066}
8	emerald	{"hue": 160, "_key": "emerald", "hueNameID": 655064}
9	grape	{"hue": 65, "_key": "grape", "hueNameID": 655060}
10	green	{"hue": 120, "_key": "green", "hueNameID": 655053}
11	lavender	{"hue": 264, "_key": "lavender", "hueNameID": 655069}
12	magenta	{"hue": 300, "_key": "magenta", "hueNameID": 655072}
13	malachite	{"hue": 172, "_key": "malachite", "hueNameID": 655065}
14	orange	{"hue": 30, "_key": "orange", "hueNameID": 655056}
15	pea	{"hue": 83, "_key": "pea", "hueNameID": 655062}
16	pink	{"hue": 310, "_key": "pink", "hueNameID": 655073}
17	plum	{"hue": 333, "_key": "plum", "hueNameID": 655075}
18	purple	{"hue": 290, "_key": "purple", "hueNameID": 655071}
19	red	{"hue": 0, "_key": "red", "hueNameID": 655052}
20	royal	{"hue": 214, "_key": "royal", "hueNameID": 655068}
21	turmeric	{"hue": 44, "_key": "turmeric", "hueNameID": 655057}
22	turquoise	{"hue": 190, "_key": "turquoise", "hueNameID": 655067}
23	violet	{"hue": 280, "_key": "violet", "hueNameID": 655070}
24	yellow	{"hue": 60, "_key": "yellow", "hueNameID": 655059}
\.


--
-- Name: huecategories huecategories_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.huecategories
    ADD CONSTRAINT huecategories_pkey PRIMARY KEY (row_no);


--
-- Name: huecategories_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX huecategories_key_idx ON sde_native.huecategories USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 8JDUr3hTCd5e0LRFgvcbKC0SNzZqvSKzpmj3XKbU7LWIMm1RkWYG0TyTTZ1um5i

