--
-- PostgreSQL database dump
--

\restrict y0gtgN5Ks59L81F0awTc3vRoF7dOYYdwEwenNNL7C2BQW280XuZdZVpWLORaknh

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: brawlmetrics; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.brawlmetrics (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: brawlmetrics; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.brawlmetrics (row_no, key, data) FROM stdin;
0	10000	{"_key": 10000, "title": 646539, "conditions": [], "event_type": 10100, "description": 646538, "record_type": 10104, "is_single_max": 0, "abort_conditions": []}
1	10001	{"_key": 10001, "title": 646547, "conditions": [], "event_type": 10100, "description": 646546, "record_type": 10104, "is_single_max": 0, "abort_conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 2}]}
2	10002	{"_key": 10002, "title": 646549, "conditions": [{"value": 6, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646548, "is_single_max": 0, "abort_conditions": []}
3	10003	{"_key": 10003, "title": 646553, "conditions": [{"value": 3, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646552, "is_single_max": 0, "abort_conditions": []}
4	10004	{"_key": 10004, "title": 646555, "conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 1}], "event_type": 10100, "description": 646554, "is_single_max": 0, "abort_conditions": []}
5	10005	{"_key": 10005, "title": 646557, "conditions": [{"value": 6, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646556, "is_single_max": 0, "abort_conditions": [{"value": 6, "event_param": 10105, "param_value": 0, "condition_type": 2}]}
6	10006	{"_key": 10006, "title": 646559, "conditions": [{"value": 3, "event_param": 10105, "param_value": 0, "condition_type": 5}], "event_type": 10100, "description": 646558, "is_single_max": 0, "abort_conditions": [{"value": 3, "event_param": 10105, "param_value": 0, "condition_type": 2}]}
7	10007	{"_key": 10007, "title": 646561, "conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 1}], "event_type": 10100, "description": 646560, "is_single_max": 0, "abort_conditions": [{"value": 1, "event_param": 10105, "param_value": 0, "condition_type": 2}]}
8	10008	{"_key": 10008, "title": 646563, "conditions": [], "event_type": 10100, "description": 646562, "record_type": 10106, "is_single_max": 1, "abort_conditions": []}
9	10009	{"_key": 10009, "title": 646565, "conditions": [], "event_type": 10100, "description": 646564, "record_type": 10107, "is_single_max": 1, "abort_conditions": []}
10	10010	{"_key": 10010, "title": 646567, "conditions": [], "event_type": 10100, "description": 646566, "record_type": 10106, "is_single_max": 0, "abort_conditions": []}
11	10011	{"_key": 10011, "title": 646569, "conditions": [], "event_type": 10100, "description": 646568, "record_type": 10107, "is_single_max": 0, "abort_conditions": []}
\.


--
-- Name: brawlmetrics brawlmetrics_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.brawlmetrics
    ADD CONSTRAINT brawlmetrics_pkey PRIMARY KEY (row_no);


--
-- Name: brawlmetrics_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX brawlmetrics_key_idx ON sde_native.brawlmetrics USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict y0gtgN5Ks59L81F0awTc3vRoF7dOYYdwEwenNNL7C2BQW280XuZdZVpWLORaknh

