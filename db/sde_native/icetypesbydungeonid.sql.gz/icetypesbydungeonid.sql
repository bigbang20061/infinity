--
-- PostgreSQL database dump
--

\restrict d61oxxD5YcU0Kxxzxfevn7CfM7QuQA2CSycsnaWTOt27EXOvvPGNK5fRh58iGEX

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: icetypesbydungeonid; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.icetypesbydungeonid (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: icetypesbydungeonid; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.icetypesbydungeonid (row_no, key, data) FROM stdin;
0	2478	{"_key": 2478, "value": [28628]}
1	2483	{"_key": 2483, "value": [28627]}
2	3117	{"_key": 3117, "value": [28627]}
3	5496	{"_key": 5496, "value": [16264]}
4	5497	{"_key": 5497, "value": [16265]}
5	5498	{"_key": 5498, "value": [16263]}
6	5499	{"_key": 5499, "value": [16262]}
7	5500	{"_key": 5500, "value": [16264, 16266]}
8	5501	{"_key": 5501, "value": [16265, 16266]}
9	5502	{"_key": 5502, "value": [16263, 16266]}
10	5503	{"_key": 5503, "value": [16262, 16266]}
11	5504	{"_key": 5504, "value": [16266, 16267, 16268, 17975]}
12	5505	{"_key": 5505, "value": [16266, 16267, 16268, 17976]}
13	5506	{"_key": 5506, "value": [16266, 16267, 16268, 17977]}
14	5507	{"_key": 5507, "value": [16266, 16267, 16268, 17978]}
15	5508	{"_key": 5508, "value": [16266, 16267, 16268, 16269, 17975]}
16	5509	{"_key": 5509, "value": [16266, 16267, 16268, 16269, 17976]}
17	5510	{"_key": 5510, "value": [16266, 16267, 16268, 16269, 17977]}
18	5511	{"_key": 5511, "value": [16266, 16267, 16268, 16269, 17978]}
19	5633	{"_key": 5633, "value": [16266, 16267, 16268, 16269, 17975, 17976, 17977, 17978]}
20	13622	{"_key": 13622, "value": [16262, 16263, 16264, 16265, 16266, 16267, 16268, 16269]}
\.


--
-- Name: icetypesbydungeonid icetypesbydungeonid_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.icetypesbydungeonid
    ADD CONSTRAINT icetypesbydungeonid_pkey PRIMARY KEY (row_no);


--
-- Name: icetypesbydungeonid_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX icetypesbydungeonid_key_idx ON sde_native.icetypesbydungeonid USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict d61oxxD5YcU0Kxxzxfevn7CfM7QuQA2CSycsnaWTOt27EXOvvPGNK5fRh58iGEX

