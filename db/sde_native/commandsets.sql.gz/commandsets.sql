--
-- PostgreSQL database dump
--

\restrict L9mK69s1WR0Bpl9di0KSHU2sIgGaR3liZXID2tueaDuqPp1GkaO55I4cbcATMZA

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: commandsets; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.commandsets (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: commandsets; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.commandsets (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "name": "All window commands", "commands": ["cmd.category.window"]}
1	2	{"_key": 2, "name": "Ship navigation", "commands": ["cmd.name.CmdToggleAutopilot", "cmd.name.CmdDecelerate", "cmd.name.CmdAccelerate", "cmd.name.CmdStopShip", "cmd.name.CmdSetShipFullSpeed", "cmd.name.CmdFlightControlsUp", "cmd.name.CmdFlightControlsDown", "cmd.name.CmdFlightControlsLeft", "cmd.name.CmdFlightControlsRight"]}
2	6	{"_key": 6, "name": "Disable full stop/warp ", "commands": ["cmd.name.CmdStopShip"], "description": "This command will prevent the player from full stopping his ship or cancel warp with short-cut commands"}
3	7	{"_key": 7, "name": "Radial menu expand", "commands": ["radialmenu.expand"]}
4	8	{"_key": 8, "name": "Context menu expand", "commands": ["menucore.expand"]}
5	10	{"_key": 10, "name": "Disable Context Menu", "inherit": [8], "commands": [], "description": "This Command Set disables Context Menu"}
6	12	{"_key": 12, "name": "Minimize windows", "commands": ["window.minimize"]}
7	14	{"_key": 14, "name": "Disable Hi/Med/Lo Slot Keyboard Shortcuts", "commands": ["cmd.name.CmdActivateHighPowerSlot1", "cmd.name.CmdActivateHighPowerSlot2", "cmd.name.CmdActivateHighPowerSlot3", "cmd.name.CmdActivateHighPowerSlot4", "cmd.name.CmdActivateHighPowerSlot5", "cmd.name.CmdActivateHighPowerSlot6", "cmd.name.CmdActivateHighPowerSlot7", "cmd.name.CmdActivateHighPowerSlot8", "cmd.name.CmdActivateMediumPowerSlot1", "cmd.name.CmdActivateMediumPowerSlot2", "cmd.name.CmdActivateMediumPowerSlot3", "cmd.name.CmdActivateMediumPowerSlot4", "cmd.name.CmdActivateMediumPowerSlot5", "cmd.name.CmdActivateMediumPowerSlot6", "cmd.name.CmdActivateMediumPowerSlot7", "cmd.name.CmdActivateMediumPowerSlot8", "cmd.name.CmdActivateLowPowerSlot1", "cmd.name.CmdActivateLowPowerSlot2", "cmd.name.CmdActivateLowPowerSlot3", "cmd.name.CmdActivateLowPowerSlot4", "cmd.name.CmdActivateLowPowerSlot5", "cmd.name.CmdActivateLowPowerSlot6", "cmd.name.CmdActivateLowPowerSlot7", "cmd.name.CmdActivateLowPowerSlot8"], "description": "Blocks players from using keyboard shortcuts to activate slotted modules."}
8	17	{"_key": 17, "name": "Open Reprocessing Window", "commands": ["window.open.reprocessingWindow"]}
9	18	{"_key": 18, "name": "[AIR NPE] Feature Blocker", "commands": ["window.open.reprocessingWindow", "window.open.market", "window.open.fleetwindow", "window.open.bookmarkLocationWindow", "window.open.corporation", "window.open.contracts", "window.open.RaffleWindow", "cmd.name.OpenReprocessingPlant", "cmd.name.OpenMarket", "cmd.name.OpenFleet", "cmd.name.OpenCorporationPanel", "cmd.name.OpenContracts", "cmd.name.OpenMarketOrders", "cmd.name.OpenMultibuy", "cmd.name.OpenRaffleWindow", "cmd.name.OpenOverviewSettings", "window.open.tradeWnd"], "description": "Commands and Windows that are blocked in the AIR NPE"}
10	19	{"_key": 19, "name": "Disable Radial Menu/Hi-Slot Shortcuts", "inherit": [7, 14], "commands": [], "description": "This Command Set disables Radial Menu and keyboard shortcuts for module activation"}
11	23	{"_key": 23, "name": "[NES Intro] Disable redeem to home station", "commands": ["redeem_to_home_station"]}
\.


--
-- Name: commandsets commandsets_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.commandsets
    ADD CONSTRAINT commandsets_pkey PRIMARY KEY (row_no);


--
-- Name: commandsets_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX commandsets_key_idx ON sde_native.commandsets USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict L9mK69s1WR0Bpl9di0KSHU2sIgGaR3liZXID2tueaDuqPp1GkaO55I4cbcATMZA

