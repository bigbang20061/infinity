--
-- PostgreSQL database dump
--

\restrict JwFRVg5rj1Xqx0u9M5Zg5lSMRUr1nm8q59U35Cm6F3pNMQqaOrwJMl2kgEFWAxN

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: globaltypes; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.globaltypes (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: globaltypes; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.globaltypes (row_no, key, data) FROM stdin;
0	11	{"_key": 11, "resourceDistribution": {"2073": 0.9, "2267": 0.0, "2268": 0.9, "2270": 0.0, "2272": 0.0, "2286": 0.0, "2287": 1.0, "2288": 0.95, "2305": 1.0, "2306": 0.0, "2307": 0.0, "2308": 0.0, "2309": 0.0, "2310": 0.0, "2311": 0.0}}
1	12	{"_key": 12, "resourceDistribution": {"2073": 0.85, "2267": 0.0, "2268": 0.95, "2270": 0.0, "2272": 1.0, "2286": 0.95, "2287": 0.0, "2288": 0.0, "2305": 0.0, "2306": 0.0, "2307": 0.0, "2308": 0.0, "2309": 0.0, "2310": 0.9, "2311": 0.0}}
2	13	{"_key": 13, "resourceDistribution": {"2073": 0.0, "2267": 0.8, "2268": 0.8, "2270": 0.0, "2272": 0.0, "2286": 0.0, "2287": 0.0, "2288": 0.0, "2305": 0.0, "2306": 0.0, "2307": 0.0, "2308": 0.0, "2309": 0.95, "2310": 1.0, "2311": 1.0}}
3	2014	{"_key": 2014, "resourceDistribution": {"2073": 0.95, "2267": 0.0, "2268": 1.0, "2270": 0.0, "2272": 0.0, "2286": 1.0, "2287": 0.95, "2288": 0.9, "2305": 0.0, "2306": 0.0, "2307": 0.0, "2308": 0.0, "2309": 0.0, "2310": 0.0, "2311": 0.0}}
4	2015	{"_key": 2015, "resourceDistribution": {"2073": 0.0, "2267": 0.9, "2268": 0.0, "2270": 0.0, "2272": 0.95, "2286": 0.0, "2287": 0.0, "2288": 0.0, "2305": 0.0, "2306": 0.95, "2307": 1.0, "2308": 0.95, "2309": 0.0, "2310": 0.0, "2311": 0.0}}
5	2016	{"_key": 2016, "resourceDistribution": {"2073": 1.0, "2267": 1.0, "2268": 0.75, "2270": 1.0, "2272": 0.0, "2286": 0.0, "2287": 0.0, "2288": 1.0, "2305": 0.0, "2306": 0.0, "2307": 0.0, "2308": 0.0, "2309": 0.0, "2310": 0.0, "2311": 0.0}}
6	2017	{"_key": 2017, "resourceDistribution": {"2073": 0.0, "2267": 0.85, "2268": 0.85, "2270": 0.0, "2272": 0.0, "2286": 0.0, "2287": 0.0, "2288": 0.0, "2305": 0.0, "2306": 0.0, "2307": 0.0, "2308": 0.9, "2309": 1.0, "2310": 0.95, "2311": 0.0}}
7	2063	{"_key": 2063, "resourceDistribution": {"2073": 0.0, "2267": 0.95, "2268": 0.0, "2270": 0.95, "2272": 0.9, "2286": 0.0, "2287": 0.0, "2288": 0.0, "2305": 0.0, "2306": 1.0, "2307": 0.0, "2308": 1.0, "2309": 0.0, "2310": 0.0, "2311": 0.0}}
\.


--
-- Name: globaltypes globaltypes_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.globaltypes
    ADD CONSTRAINT globaltypes_pkey PRIMARY KEY (row_no);


--
-- Name: globaltypes_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX globaltypes_key_idx ON sde_native.globaltypes USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict JwFRVg5rj1Xqx0u9M5Zg5lSMRUr1nm8q59U35Cm6F3pNMQqaOrwJMl2kgEFWAxN

