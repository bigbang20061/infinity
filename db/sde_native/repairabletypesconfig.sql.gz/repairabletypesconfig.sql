--
-- PostgreSQL database dump
--

\restrict 7d2O8EzZo6Ly76u6dQPpSZ3a2hjZeTGP097BOYHMM4c8STEl2HMyDee7mUzWPIB

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: repairabletypesconfig; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.repairabletypesconfig (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: repairabletypesconfig; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.repairabletypesconfig (row_no, key, data) FROM stdin;
0	\N	{"repairableShipTypes": {"28606": {"repairDuration": 150000}, "42244": {"repairDuration": 1500}, "89807": {"repairDuration": 30000}}, "repairableShipGroups": {"25": {"repairDuration": 60}, "26": {"repairDuration": 1200}, "27": {"repairDuration": 1800}, "28": {"repairDuration": 1200}, "30": {"repairDuration": 900000}, "31": {"repairDuration": 60}, "237": {"repairDuration": 60}, "324": {"repairDuration": 12000}, "358": {"repairDuration": 24000}, "380": {"repairDuration": 24000}, "419": {"repairDuration": 1500}, "420": {"repairDuration": 120}, "463": {"repairDuration": 1200}, "485": {"repairDuration": 199980}, "513": {"repairDuration": 150000}, "540": {"repairDuration": 30000}, "541": {"repairDuration": 18000}, "543": {"repairDuration": 24000}, "547": {"repairDuration": 199980}, "659": {"repairDuration": 600000}, "830": {"repairDuration": 12000}, "831": {"repairDuration": 12000}, "832": {"repairDuration": 24000}, "833": {"repairDuration": 24000}, "834": {"repairDuration": 12000}, "883": {"repairDuration": 199980}, "893": {"repairDuration": 12000}, "894": {"repairDuration": 24000}, "898": {"repairDuration": 36000}, "900": {"repairDuration": 36000}, "902": {"repairDuration": 360000}, "906": {"repairDuration": 24000}, "963": {"repairDuration": 30000}, "1022": {"repairDuration": 60}, "1201": {"repairDuration": 1500}, "1202": {"repairDuration": 24000}, "1283": {"repairDuration": 12000}, "1305": {"repairDuration": 18000}, "1527": {"repairDuration": 12000}, "1534": {"repairDuration": 18000}, "1538": {"repairDuration": 199980}, "4429": {"repairDuration": 24000}, "4436": {"repairDuration": 36000}, "4622": {"repairDuration": 86400}}, "defaultRepairableConfig": {"repairDuration": 3600, "defaultServiceLife": 100.0, "estPricePercentage": 0.16, "defaultShipRepairDuration": 3600, "defaultMaxReduceServiceLife": 50.0, "manufacturingTimePercentage": 0.1, "defaultRefurbishedComponentDropChance": 0.5, "defaultRefurbishedComponentDropMaxNum": 10, "defaultRefurbishedComponentDropMinNum": 1, "defaultRefurbishedComponentAddServiceLifeValue": 1.0}}
\.


--
-- Name: repairabletypesconfig repairabletypesconfig_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.repairabletypesconfig
    ADD CONSTRAINT repairabletypesconfig_pkey PRIMARY KEY (row_no);


--
-- Name: repairabletypesconfig_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX repairabletypesconfig_key_idx ON sde_native.repairabletypesconfig USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 7d2O8EzZo6Ly76u6dQPpSZ3a2hjZeTGP097BOYHMM4c8STEl2HMyDee7mUzWPIB

