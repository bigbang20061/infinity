--
-- PostgreSQL database dump
--

\restrict Uu8ijFPywgGivCzwp1nkBYNEjkUyOUM2YjlxaqnKwfK404kT6S80qlOnS9Fcfo0

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: checkpoints; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.checkpoints (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: checkpoints; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.checkpoints (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "name": "Testing Checkpoint", "featureID": "air_npe", "description": "Exists for development purpose"}
1	2	{"_key": 2, "name": "AIR NPE - Active", "featureID": "air_npe", "description": "AIR NPE tutorial is in progress"}
2	3	{"_key": 3, "name": "AIR NPE - Completed", "featureID": "air_npe", "description": "Character has played through the whole AIR NPE"}
3	4	{"_key": 4, "name": "AIR NPE - Skipped", "featureID": "air_npe", "description": "Character has skipped the AIR NPE"}
4	12	{"_key": 12, "name": "[AIR] 1.1.01 - Introduction", "featureID": "air_npe", "description": "Start of Scene 1.0 in the AIR NPE tutorial. Initial site."}
5	13	{"_key": 13, "name": "AIR NPE - 1.2 Ship HUD", "featureID": "air_npe", "description": "Player has boarded a ship and is ready to learn about HUD basics"}
6	14	{"_key": 14, "name": "AIR NPE - 1.3 Balin Arrives", "featureID": "air_npe", "description": "Player has learnt about his new ship and is ready to meet Balin"}
7	15	{"_key": 15, "name": "AIR NPE - 1.4 Departure with Balin", "featureID": "air_npe", "description": "Player's ship has been repaired and he is ready to warp with Balin"}
8	16	{"_key": 16, "name": "[AIR] 1.2.01 - Investigate the Signal", "featureID": "air_npe", "description": "Start of Scene 2.0 in the AIR NPE tutorial. Combat site."}
9	17	{"_key": 17, "name": "AIR NPE - 2.2 Orbit Balin", "featureID": "air_npe", "description": "Player has investigated the site and found their bearings"}
10	18	{"_key": 18, "name": "AIR NPE - 2.3 Fleet Arrived", "featureID": "air_npe", "description": "Player is orbiting Balin and ready for combat"}
11	19	{"_key": 19, "name": "AIR NPE - 2.4 Orbit Frigates", "featureID": "air_npe", "description": "Player has seen the enemy fleet arrive"}
12	20	{"_key": 20, "name": "AIR NPE - 2.5 Engage Cruisers", "featureID": "air_npe", "description": "Player has killed the enemy frigates and is ready to tackle the cruisers"}
13	21	{"_key": 21, "name": "AIR NPE - 2.6 Engage Battleship", "featureID": "air_npe", "description": "Player has killed the enemy cruisers and is ready to tackle the battleships"}
14	22	{"_key": 22, "name": "AIR NPE - 2.7 Player Ship Death", "featureID": "air_npe", "description": "Player has activated ECM on a battleship and is ready to die"}
15	23	{"_key": 23, "name": "AIR NPE - 2.8 Player Death", "featureID": "air_npe", "description": "Player is in a capsule and is ready for pod death"}
16	24	{"_key": 24, "name": "[OLD] AIR NPE - 3.1 Station Intro", "featureID": "air_npe", "description": "Start of Scene 3.0 in the AIR NPE tutorial. Station."}
17	25	{"_key": 25, "name": "[OLD] AIR NPE - 3.1.1 Board New Ship", "featureID": "air_npe", "description": "Scene 3.1 has started and player is ready to board a Corvette"}
18	26	{"_key": 26, "name": "[OLD] AIR NPE - Item: Repairer", "featureID": "air_npe", "description": "Player has just been gifted an Armor Repairer"}
19	27	{"_key": 27, "name": "[OLD] AIR NPE - 3.2 Modules Intro", "featureID": "air_npe", "description": "Player has boarded a Corvette and is ready to learn about NEOCOM and fitting"}
20	28	{"_key": 28, "name": "[OLD] AIR NPE - 3.2.1 NEOCOM Intro", "featureID": "air_npe", "description": "Scene 3.2 has started and player is ready to learn about NEOCOM"}
21	29	{"_key": 29, "name": "[OLD] AIR NPE - 3.2.2 Fit modules", "featureID": "air_npe", "description": "Player has learnt about NEOCOM and is ready to start fitting"}
22	30	{"_key": 30, "name": "[OLD] AIR NPE - 3.2.3 Module Offline Intro", "featureID": "air_npe", "description": "Player has fitted the Repairer and is ready to attempt to online it"}
23	31	{"_key": 31, "name": "[OLD] AIR NPE - Item: Repair Systems", "featureID": "air_npe", "description": "Player has just been gifted a Repair Systems skill book"}
24	32	{"_key": 32, "name": "[OLD] AIR NPE - 3.3 Skill and Skill training", "featureID": "air_npe", "description": "Player has fitted the Repairer and is ready to train the necessary skills to online it"}
25	33	{"_key": 33, "name": "[OLD] AIR NPE - 3.3.1 Skills Intro", "featureID": "air_npe", "description": "Scene 3.3 has started and player is ready to learn about skills"}
26	34	{"_key": 34, "name": "[OLD] AIR NPE - 3.3.2 Skill Training Queue", "featureID": "air_npe", "description": "Player has learnt about skills and is ready to engage with the Skill Queue"}
27	35	{"_key": 35, "name": "[OLD] AIR NPE - Item: Skill Injector", "featureID": "air_npe", "description": "Player has just been gifted a skill injector"}
28	36	{"_key": 36, "name": "[OLD] AIR NPE - 3.3.3 Inject Skill Injector", "featureID": "air_npe", "description": "Player has received a Skill Injector and is ready to use it"}
29	37	{"_key": 37, "name": "[OLD] AIR NPE - 3.4 Station Service", "featureID": "air_npe", "description": "Player has added skills to the training queue with the goal of onlining the Repair module"}
30	38	{"_key": 38, "name": "[OLD] AIR NPE - 3.4.1 Skill Injector", "featureID": "air_npe", "description": "Scene 3.4 has started and player is ready to expedite their skill training"}
31	39	{"_key": 39, "name": "[OLD] AIR NPE - 3.4.2 Online Module", "featureID": "air_npe", "description": "Player has the necessary skills to online the Repairer module"}
32	40	{"_key": 40, "name": "[OLD] AIR NPE - 3.4.3 Station Services", "featureID": "air_npe", "description": "Player has onlined the Repairer module and is ready to Undock"}
33	41	{"_key": 41, "name": "AIR NPE - 4.1 Space Navigation", "featureID": "air_npe", "description": "Start of Scene 4.0 in the AIR NPE tutorial. Travelling to the Career Agents station."}
34	42	{"_key": 42, "name": "AIR NPE - 4.2 Career Agent and Hand off", "featureID": "air_npe", "description": "Player is in a station ready to accept a Career Agent mission"}
35	44	{"_key": 44, "name": "[AIR] 1.3.01 - Wake-up", "featureID": "air_npe"}
36	45	{"_key": 45, "name": "[AIR] 1.4.01 - Item Retrieval", "featureID": "air_npe"}
37	46	{"_key": 46, "name": "[AIR] 1.5.02 - Online Module Attempt", "featureID": "air_npe"}
38	47	{"_key": 47, "name": "[AIR] 1.5.03 - Skill Introduction", "featureID": "air_npe"}
39	48	{"_key": 48, "name": "[AIR] 1.5.04 - Skill Point Introduction", "featureID": "air_npe"}
40	49	{"_key": 49, "name": "[AIR] 1.5.05 - Skill Plan Introduction", "featureID": "air_npe"}
41	50	{"_key": 50, "name": "[AIR] 2.1.01 - Enter Mining Site", "featureID": "air_npe"}
42	51	{"_key": 51, "name": "[AIR] 2.1.02 - Mine Asteroid 1", "featureID": "air_npe"}
43	52	{"_key": 52, "name": "[AIR] 2.1.03 - Mine Asteroid 2", "featureID": "air_npe"}
44	53	{"_key": 53, "name": "[AIR] 2.1.05 - Loot Wreck", "featureID": "air_npe"}
45	54	{"_key": 54, "name": "[AIR] 2.1.06 - Back to Station", "featureID": "air_npe"}
46	55	{"_key": 55, "name": "[AIR] 1.5.06 - Online Module", "featureID": "air_npe"}
47	56	{"_key": 56, "name": "[AIR] 2.1.04 - Mine Asteroid 3", "featureID": "air_npe"}
48	57	{"_key": 57, "name": "[AIR] 2.2.01 - Move Ore", "featureID": "air_npe"}
49	58	{"_key": 58, "name": "[AIR] 2.2.02 - Market Introduction", "featureID": "air_npe"}
50	59	{"_key": 59, "name": "[AIR] 2.2.03 - Wallet Introduction", "featureID": "air_npe"}
51	60	{"_key": 60, "name": "[AIR] 2.2.04 - ACP Goal Introduction", "featureID": "air_npe"}
52	62	{"_key": 62, "name": "[AIR] 2.2.05 - Undock", "featureID": "air_npe"}
53	63	{"_key": 63, "name": "[AIR] 2.3.01 - System Navigation Introduction", "featureID": "air_npe"}
54	64	{"_key": 64, "name": "[AIR] 2.4.01 - Agent Introduction", "featureID": "air_npe"}
55	65	{"_key": 65, "name": "[AIR] 2.4.02 - Skill Plan Reminder", "featureID": "air_npe"}
56	66	{"_key": 66, "name": "[AIR] 2.4.03 - Opportunities Mission Reminder", "featureID": "air_npe"}
57	67	{"_key": 67, "name": "[AIR] 2.5.01 - ACP Reward Reminder", "featureID": "air_npe"}
58	73	{"_key": 73, "name": "[NES Intro] 1 - Nes Intro Started", "featureID": "nes_intro", "description": "Beginning of NES Intro."}
59	74	{"_key": 74, "name": "[NES Intro] 2 - Crate Received", "featureID": "nes_intro", "description": "Player has received a crate in inventory"}
60	79	{"_key": 79, "name": "[NES Intro] 4 - SKIN bought", "featureID": "nes_intro", "description": "Player has purchased the SKIN"}
61	82	{"_key": 82, "name": "[NES Intro] 5 - SKIN Applied", "featureID": "nes_intro", "description": "SKIN Active"}
62	83	{"_key": 83, "name": "[NES Intro] 6 - Completed", "featureID": "nes_intro", "description": "NES Intro completed"}
63	84	{"_key": 84, "name": "[NES Intro] 3 - Crate Opened", "featureID": "nes_intro", "description": "Player has opened a paragon gift crate"}
64	85	{"_key": 85, "name": "[AIR] 1.3.02 - ACP Reward Introduction", "featureID": "air_npe"}
65	86	{"_key": 86, "name": "[AIR] 1.3.03 - Redeeming Introduction", "featureID": "air_npe"}
66	87	{"_key": 87, "name": "[AIR] 1.3.04 - Board Corvette", "featureID": "air_npe"}
67	88	{"_key": 88, "name": "[AIR] 1.3.05 - Undock", "featureID": "air_npe"}
68	89	{"_key": 89, "name": "[AIR] 1.5.01 - Fitting Introduction", "featureID": "air_npe"}
69	90	{"_key": 90, "name": "[AIR] 1.5.07 - Opportunities Mission Introduction", "featureID": "air_npe"}
70	91	{"_key": 91, "name": "[AIR] 2.5.02 - Help Section Introduction", "featureID": "air_npe"}
71	92	{"_key": 92, "name": "[AIR] 2.5.03 - Handoff", "featureID": "air_npe"}
72	101	{"_key": 101, "name": "[MAP Onboarding] 1 - Onboarding Started", "featureID": "nes_intro"}
73	102	{"_key": 102, "name": "[MAP Onboarding] 2 - Basic Navigation Finished", "featureID": "nes_intro"}
74	103	{"_key": 103, "name": "[MAP Onboarding] 3 - Filters Finished", "featureID": "nes_intro"}
75	104	{"_key": 104, "name": "[MAP Onboarding] 4 - 2D map finished", "featureID": "nes_intro"}
76	105	{"_key": 105, "name": "[MAP Onboarding] 5 - Layouts Finished", "featureID": "nes_intro"}
77	106	{"_key": 106, "name": "[MAP Onboarding] 6 - Onboarding Finished", "featureID": "nes_intro"}
\.


--
-- Name: checkpoints checkpoints_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.checkpoints
    ADD CONSTRAINT checkpoints_pkey PRIMARY KEY (row_no);


--
-- Name: checkpoints_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX checkpoints_key_idx ON sde_native.checkpoints USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict Uu8ijFPywgGivCzwp1nkBYNEjkUyOUM2YjlxaqnKwfK404kT6S80qlOnS9Fcfo0

