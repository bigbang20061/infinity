--
-- PostgreSQL database dump
--

\restrict 7hIe6W5Bzrt7cEAh3oOCSIr0eR5zpwXuHaZKbFp6iTrLcjjduucwYn9OdcuH2cf

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: corporationactivities; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.corporationactivities (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: corporationactivities; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.corporationactivities (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "nameID": 60048}
1	2	{"_key": 2, "nameID": 60049}
2	3	{"_key": 3, "nameID": 60050}
3	4	{"_key": 4, "nameID": 60051}
4	5	{"_key": 5, "nameID": 60052}
5	6	{"_key": 6, "nameID": 60053}
6	7	{"_key": 7, "nameID": 60054}
7	8	{"_key": 8, "nameID": 60055}
8	9	{"_key": 9, "nameID": 60056}
9	10	{"_key": 10, "nameID": 60057}
10	11	{"_key": 11, "nameID": 60058}
11	12	{"_key": 12, "nameID": 60059}
12	13	{"_key": 13, "nameID": 60060}
13	14	{"_key": 14, "nameID": 60061}
14	15	{"_key": 15, "nameID": 60062}
15	16	{"_key": 16, "nameID": 60063}
16	17	{"_key": 17, "nameID": 60064}
17	18	{"_key": 18, "nameID": 60065}
18	19	{"_key": 19, "nameID": 60066}
19	20	{"_key": 20, "nameID": 60067}
\.


--
-- Name: corporationactivities corporationactivities_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.corporationactivities
    ADD CONSTRAINT corporationactivities_pkey PRIMARY KEY (row_no);


--
-- Name: corporationactivities_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX corporationactivities_key_idx ON sde_native.corporationactivities USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 7hIe6W5Bzrt7cEAh3oOCSIr0eR5zpwXuHaZKbFp6iTrLcjjduucwYn9OdcuH2cf

