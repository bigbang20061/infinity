--
-- PostgreSQL database dump
--

\restrict nMe2pHc8X7XEoooaIZMtaXPKkvjBNcqG8sTKQCfs9J1kA05QkZZJO8B4aT5kOlC

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: fighterabilitiesbytype; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.fighterabilitiesbytype (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: fighterabilitiesbytype; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.fighterabilitiesbytype (row_no, key, data) FROM stdin;
0	2948	{"_key": 2948, "abilitySlot0": {"abilityID": 22}, "abilitySlot1": {"abilityID": 9, "cooldownSeconds": 60}, "abilitySlot2": {"abilityID": 38}}
1	23055	{"_key": 23055, "abilitySlot0": {"abilityID": 22}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 18, "rearmTimeSeconds": 4.0}, "abilityID": 33}}
2	23057	{"_key": 23057, "abilitySlot0": {"abilityID": 44}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 18, "rearmTimeSeconds": 4.0}, "abilityID": 35}}
3	23059	{"_key": 23059, "abilitySlot0": {"abilityID": 24}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 18, "rearmTimeSeconds": 4.0}, "abilityID": 34}}
4	23061	{"_key": 23061, "abilitySlot0": {"abilityID": 26}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 18, "rearmTimeSeconds": 4.0}, "abilityID": 36}}
5	32325	{"_key": 32325, "abilitySlot0": {"abilityID": 24}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 9, "rearmTimeSeconds": 6.0}, "abilityID": 19}}
6	32340	{"_key": 32340, "abilitySlot0": {"abilityID": 22}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 9, "rearmTimeSeconds": 6.0}, "abilityID": 18}}
7	32342	{"_key": 32342, "abilitySlot0": {"abilityID": 26}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 9, "rearmTimeSeconds": 6.0}, "abilityID": 21}}
8	32344	{"_key": 32344, "abilitySlot0": {"abilityID": 44}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 9, "rearmTimeSeconds": 6.0}, "abilityID": 20}}
9	37599	{"_key": 37599, "abilitySlot0": {"abilityID": 11}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60}}
10	40345	{"_key": 40345, "abilitySlot0": {"abilityID": 12}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60}}
11	40346	{"_key": 40346, "abilitySlot0": {"abilityID": 10}, "abilitySlot1": {"abilityID": 9, "cooldownSeconds": 60.0}}
12	40347	{"_key": 40347, "abilitySlot0": {"abilityID": 2}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60}}
13	40358	{"_key": 40358, "abilitySlot0": {"abilityID": 29}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60}, "abilitySlot2": {"abilityID": 16}}
14	40359	{"_key": 40359, "abilitySlot0": {"abilityID": 31}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60}, "abilitySlot2": {"abilityID": 16}}
15	40360	{"_key": 40360, "abilitySlot0": {"abilityID": 30}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60}, "abilitySlot2": {"abilityID": 16}}
16	40361	{"_key": 40361, "abilitySlot0": {"abilityID": 32}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60}, "abilitySlot2": {"abilityID": 16}}
17	40362	{"_key": 40362, "abilitySlot0": {"abilityID": 23}, "abilitySlot1": {"abilityID": 5, "cooldownSeconds": 90.0}, "abilitySlot2": {"charges": {"chargeCount": 3, "rearmTimeSeconds": 20.0}, "abilityID": 7}}
18	40363	{"_key": 40363, "abilitySlot0": {"abilityID": 45}, "abilitySlot1": {"abilityID": 5, "cooldownSeconds": 90.0}, "abilitySlot2": {"charges": {"chargeCount": 3, "rearmTimeSeconds": 20.0}, "abilityID": 7}}
19	40364	{"_key": 40364, "abilitySlot0": {"abilityID": 25}, "abilitySlot1": {"abilityID": 5, "cooldownSeconds": 90.0}, "abilitySlot2": {"charges": {"chargeCount": 3, "rearmTimeSeconds": 20.0}, "abilityID": 7}}
20	40365	{"_key": 40365, "abilitySlot0": {"abilityID": 27}, "abilitySlot1": {"abilityID": 5, "cooldownSeconds": 90.0}, "abilitySlot2": {"charges": {"chargeCount": 3, "rearmTimeSeconds": 20.0}, "abilityID": 7}}
21	40552	{"_key": 40552, "abilitySlot0": {"abilityID": 29}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60}, "abilitySlot2": {"abilityID": 16}}
22	40553	{"_key": 40553, "abilitySlot0": {"abilityID": 32}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60}, "abilitySlot2": {"abilityID": 16}}
23	40554	{"_key": 40554, "abilitySlot0": {"abilityID": 31}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60}, "abilitySlot2": {"abilityID": 16}}
24	40555	{"_key": 40555, "abilitySlot0": {"abilityID": 30}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60}, "abilitySlot2": {"abilityID": 16}}
25	40556	{"_key": 40556, "abilitySlot0": {"abilityID": 22}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 18, "rearmTimeSeconds": 4.0}, "abilityID": 33}}
26	40557	{"_key": 40557, "abilitySlot0": {"abilityID": 44}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 18, "rearmTimeSeconds": 4.0}, "abilityID": 35}}
27	40558	{"_key": 40558, "abilitySlot0": {"abilityID": 24}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 18, "rearmTimeSeconds": 4.0}, "abilityID": 34}}
28	40559	{"_key": 40559, "abilitySlot0": {"abilityID": 26}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 18, "rearmTimeSeconds": 4.0}, "abilityID": 36}}
29	40560	{"_key": 40560, "abilitySlot0": {"abilityID": 23}, "abilitySlot1": {"abilityID": 5, "cooldownSeconds": 90.0}, "abilitySlot2": {"charges": {"chargeCount": 5, "rearmTimeSeconds": 20.0}, "abilityID": 7}}
30	40561	{"_key": 40561, "abilitySlot0": {"abilityID": 22}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 9, "rearmTimeSeconds": 6.0}, "abilityID": 18}}
31	40562	{"_key": 40562, "abilitySlot0": {"abilityID": 25}, "abilitySlot1": {"abilityID": 5, "cooldownSeconds": 90.0}, "abilitySlot2": {"charges": {"chargeCount": 5, "rearmTimeSeconds": 20.0}, "abilityID": 7}}
32	40563	{"_key": 40563, "abilitySlot0": {"abilityID": 24}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 9, "rearmTimeSeconds": 6.0}, "abilityID": 19}}
33	40564	{"_key": 40564, "abilitySlot0": {"abilityID": 27}, "abilitySlot1": {"abilityID": 5, "cooldownSeconds": 90.0}, "abilitySlot2": {"charges": {"chargeCount": 5, "rearmTimeSeconds": 20.0}, "abilityID": 7}}
34	40565	{"_key": 40565, "abilitySlot0": {"abilityID": 26}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 9, "rearmTimeSeconds": 6.0}, "abilityID": 21}}
35	40566	{"_key": 40566, "abilitySlot0": {"abilityID": 45}, "abilitySlot1": {"abilityID": 5, "cooldownSeconds": 90.0}, "abilitySlot2": {"charges": {"chargeCount": 5, "rearmTimeSeconds": 20.0}, "abilityID": 7}}
36	40567	{"_key": 40567, "abilitySlot0": {"abilityID": 44}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 9, "rearmTimeSeconds": 6.0}, "abilityID": 20}}
37	40568	{"_key": 40568, "abilitySlot0": {"abilityID": 11}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60}}
38	40569	{"_key": 40569, "abilitySlot0": {"abilityID": 12}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60}}
39	40570	{"_key": 40570, "abilitySlot0": {"abilityID": 10}, "abilitySlot1": {"abilityID": 9, "cooldownSeconds": 60.0}}
40	40571	{"_key": 40571, "abilitySlot0": {"abilityID": 2}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60}}
41	47035	{"_key": 47035, "abilitySlot0": {"abilityID": 22}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 18, "rearmTimeSeconds": 4.0}, "abilityID": 33}}
42	47036	{"_key": 47036, "abilitySlot0": {"abilityID": 32}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60.0}, "abilitySlot2": {"abilityID": 16}}
43	47037	{"_key": 47037, "abilitySlot0": {"abilityID": 10}, "abilitySlot1": {"abilityID": 9, "cooldownSeconds": 60.0}}
44	47038	{"_key": 47038, "abilitySlot0": {"abilityID": 44}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 9, "rearmTimeSeconds": 6.0}, "abilityID": 20}}
45	47039	{"_key": 47039, "abilitySlot0": {"abilityID": 27}, "abilitySlot1": {"abilityID": 5, "cooldownSeconds": 90.0}, "abilitySlot2": {"charges": {"chargeCount": 3, "rearmTimeSeconds": 20.0}, "abilityID": 7}}
46	47116	{"_key": 47116, "abilitySlot0": {"abilityID": 22}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 9, "rearmTimeSeconds": 6.0}, "abilityID": 18}}
47	47117	{"_key": 47117, "abilitySlot0": {"abilityID": 24}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 9, "rearmTimeSeconds": 6.0}, "abilityID": 19}}
48	47118	{"_key": 47118, "abilitySlot0": {"abilityID": 26}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 9, "rearmTimeSeconds": 6.0}, "abilityID": 21}}
49	47119	{"_key": 47119, "abilitySlot0": {"abilityID": 22}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 9, "rearmTimeSeconds": 6.0}, "abilityID": 18}}
50	47120	{"_key": 47120, "abilitySlot0": {"abilityID": 44}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 9, "rearmTimeSeconds": 6.0}, "abilityID": 20}}
51	47121	{"_key": 47121, "abilitySlot0": {"abilityID": 24}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 9, "rearmTimeSeconds": 6.0}, "abilityID": 19}}
52	47122	{"_key": 47122, "abilitySlot0": {"abilityID": 26}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 9, "rearmTimeSeconds": 6.0}, "abilityID": 21}}
53	47123	{"_key": 47123, "abilitySlot0": {"abilityID": 22}, "abilitySlot1": {"abilityID": 9, "cooldownSeconds": 60}, "abilitySlot2": {"abilityID": 38}}
54	47124	{"_key": 47124, "abilitySlot0": {"abilityID": 23}, "abilitySlot1": {"abilityID": 5, "cooldownSeconds": 90}, "abilitySlot2": {"charges": {"chargeCount": 2, "rearmTimeSeconds": 20}, "abilityID": 7}}
55	47125	{"_key": 47125, "abilitySlot0": {"abilityID": 45}, "abilitySlot1": {"abilityID": 5, "cooldownSeconds": 90.0}, "abilitySlot2": {"charges": {"chargeCount": 3, "rearmTimeSeconds": 20.0}, "abilityID": 7}}
56	47126	{"_key": 47126, "abilitySlot0": {"abilityID": 25}, "abilitySlot1": {"abilityID": 5, "cooldownSeconds": 90.0}, "abilitySlot2": {"charges": {"chargeCount": 3, "rearmTimeSeconds": 20.0}, "abilityID": 7}}
57	47127	{"_key": 47127, "abilitySlot0": {"abilityID": 23}, "abilitySlot1": {"abilityID": 5, "cooldownSeconds": 90.0}, "abilitySlot2": {"charges": {"chargeCount": 5, "rearmTimeSeconds": 20.0}, "abilityID": 7}}
58	47128	{"_key": 47128, "abilitySlot0": {"abilityID": 45}, "abilitySlot1": {"abilityID": 5, "cooldownSeconds": 90.0}, "abilitySlot2": {"charges": {"chargeCount": 5, "rearmTimeSeconds": 20.0}, "abilityID": 7}}
59	47129	{"_key": 47129, "abilitySlot0": {"abilityID": 25}, "abilitySlot1": {"abilityID": 5, "cooldownSeconds": 90.0}, "abilitySlot2": {"charges": {"chargeCount": 5, "rearmTimeSeconds": 20.0}, "abilityID": 7}}
60	47130	{"_key": 47130, "abilitySlot0": {"abilityID": 27}, "abilitySlot1": {"abilityID": 5, "cooldownSeconds": 90.0}, "abilitySlot2": {"charges": {"chargeCount": 5, "rearmTimeSeconds": 20.0}, "abilityID": 7}}
61	47131	{"_key": 47131, "abilitySlot0": {"abilityID": 11}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60}}
62	47132	{"_key": 47132, "abilitySlot0": {"abilityID": 12}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60}}
63	47133	{"_key": 47133, "abilitySlot0": {"abilityID": 2}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60}}
64	47134	{"_key": 47134, "abilitySlot0": {"abilityID": 11}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60}}
65	47135	{"_key": 47135, "abilitySlot0": {"abilityID": 12}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60}}
66	47136	{"_key": 47136, "abilitySlot0": {"abilityID": 10}, "abilitySlot1": {"abilityID": 9, "cooldownSeconds": 60.0}}
67	47137	{"_key": 47137, "abilitySlot0": {"abilityID": 2}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60}}
68	47138	{"_key": 47138, "abilitySlot0": {"abilityID": 44}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 18, "rearmTimeSeconds": 4.0}, "abilityID": 35}}
69	47139	{"_key": 47139, "abilitySlot0": {"abilityID": 24}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 18, "rearmTimeSeconds": 4.0}, "abilityID": 34}}
70	47140	{"_key": 47140, "abilitySlot0": {"abilityID": 26}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 18, "rearmTimeSeconds": 4.0}, "abilityID": 36}}
71	47141	{"_key": 47141, "abilitySlot0": {"abilityID": 22}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 18, "rearmTimeSeconds": 4.0}, "abilityID": 33}}
72	47142	{"_key": 47142, "abilitySlot0": {"abilityID": 44}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 18, "rearmTimeSeconds": 4.0}, "abilityID": 35}}
73	47143	{"_key": 47143, "abilitySlot0": {"abilityID": 24}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 18, "rearmTimeSeconds": 4.0}, "abilityID": 34}}
74	47144	{"_key": 47144, "abilitySlot0": {"abilityID": 26}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 18, "rearmTimeSeconds": 4.0}, "abilityID": 36}}
75	47145	{"_key": 47145, "abilitySlot0": {"abilityID": 29}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60}, "abilitySlot2": {"abilityID": 16}}
76	47146	{"_key": 47146, "abilitySlot0": {"abilityID": 31}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60}, "abilitySlot2": {"abilityID": 16}}
77	47147	{"_key": 47147, "abilitySlot0": {"abilityID": 30}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60}, "abilitySlot2": {"abilityID": 16}}
78	47148	{"_key": 47148, "abilitySlot0": {"abilityID": 29}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60}, "abilitySlot2": {"abilityID": 16}}
79	47149	{"_key": 47149, "abilitySlot0": {"abilityID": 31}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60}, "abilitySlot2": {"abilityID": 16}}
80	47150	{"_key": 47150, "abilitySlot0": {"abilityID": 30}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60}, "abilitySlot2": {"abilityID": 16}}
81	47151	{"_key": 47151, "abilitySlot0": {"abilityID": 32}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60}, "abilitySlot2": {"abilityID": 16}}
82	77067	{"_key": 77067, "abilitySlot0": {"abilityID": 31}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60.0}, "abilitySlot2": {"abilityID": 16}}
83	77068	{"_key": 77068, "abilitySlot0": {"abilityID": 44}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 18, "rearmTimeSeconds": 4.0}, "abilityID": 35}}
84	83579	{"_key": 83579, "abilitySlot0": {"abilityID": 22}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 20, "rearmTimeSeconds": 4.0}, "abilityID": 33}}
85	83582	{"_key": 83582, "abilitySlot0": {"abilityID": 44}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 20, "rearmTimeSeconds": 4.0}, "abilityID": 35}}
86	83583	{"_key": 83583, "abilitySlot0": {"abilityID": 24}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 20, "rearmTimeSeconds": 4.0}, "abilityID": 34}}
87	83584	{"_key": 83584, "abilitySlot0": {"abilityID": 26}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 20, "rearmTimeSeconds": 4.0}, "abilityID": 36}}
88	83585	{"_key": 83585, "abilitySlot0": {"abilityID": 29}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60.0}, "abilitySlot2": {"abilityID": 16}}
89	83586	{"_key": 83586, "abilitySlot0": {"abilityID": 31}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60.0}, "abilitySlot2": {"abilityID": 16}}
90	83587	{"_key": 83587, "abilitySlot0": {"abilityID": 30}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60.0}, "abilitySlot2": {"abilityID": 16}}
91	83589	{"_key": 83589, "abilitySlot0": {"abilityID": 32}, "abilitySlot1": {"abilityID": 13, "cooldownSeconds": 60.0}, "abilitySlot2": {"abilityID": 16}}
92	83591	{"_key": 83591, "abilitySlot0": {"abilityID": 11}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}}
93	83592	{"_key": 83592, "abilitySlot0": {"abilityID": 12}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}}
94	83593	{"_key": 83593, "abilitySlot0": {"abilityID": 10}, "abilitySlot1": {"abilityID": 9, "cooldownSeconds": 60.0}}
95	83594	{"_key": 83594, "abilitySlot0": {"abilityID": 2}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}}
96	84575	{"_key": 84575, "abilitySlot0": {"abilityID": 44}, "abilitySlot1": {"abilityID": 4, "cooldownSeconds": 60.0}, "abilitySlot2": {"charges": {"chargeCount": 12, "rearmTimeSeconds": 4.0}, "abilityID": 35}}
\.


--
-- Name: fighterabilitiesbytype fighterabilitiesbytype_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.fighterabilitiesbytype
    ADD CONSTRAINT fighterabilitiesbytype_pkey PRIMARY KEY (row_no);


--
-- Name: fighterabilitiesbytype_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX fighterabilitiesbytype_key_idx ON sde_native.fighterabilitiesbytype USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict nMe2pHc8X7XEoooaIZMtaXPKkvjBNcqG8sTKQCfs9J1kA05QkZZJO8B4aT5kOlC

