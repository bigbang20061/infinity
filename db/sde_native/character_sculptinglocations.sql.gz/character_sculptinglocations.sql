--
-- PostgreSQL database dump
--

\restrict XRWAFgUu5ILlE1q5Qg7c7SRN1vTbu6Rqq5dqKzrtz64MwwHV31X17JywGpREAFX

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: character_sculptinglocations; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.character_sculptinglocations (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: character_sculptinglocations; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.character_sculptinglocations (row_no, key, data) FROM stdin;
0	2	{"_key": 2, "weightKeyPrefix": "shoulders", "weightKeyCategory": "bodyShapes"}
1	3	{"_key": 3, "weightKeyPrefix": "neck", "weightKeyCategory": "bodyShapes"}
2	4	{"_key": 4, "weightKeyPrefix": "muscular", "weightKeyCategory": "bodyShapes"}
3	5	{"_key": 5, "weightKeyPrefix": "fat", "weightKeyCategory": "bodyShapes"}
4	6	{"_key": 6, "weightKeyPrefix": "feet", "weightKeyCategory": "bodyShapes"}
5	7	{"_key": 7, "weightKeyPrefix": "pinchchest", "weightKeyCategory": "bodyShapes"}
6	8	{"_key": 8, "weightKeyPrefix": "chest", "weightKeyCategory": "bodyShapes"}
7	9	{"_key": 9, "weightKeyPrefix": "abs", "weightKeyCategory": "bodyShapes"}
8	10	{"_key": 10, "weightKeyPrefix": "thin", "weightKeyCategory": "bodyShapes"}
9	11	{"_key": 11, "weightKeyPrefix": "pelvis", "weightKeyCategory": "bodyShapes"}
10	12	{"_key": 12, "weightKeyPrefix": "legs", "weightKeyCategory": "bodyShapes"}
11	13	{"_key": 13, "weightKeyPrefix": "eyes", "weightKeyCategory": "faceModifiers"}
12	14	{"_key": 14, "weightKeyPrefix": "nosebone", "weightKeyCategory": "faceModifiers"}
13	15	{"_key": 15, "weightKeyPrefix": "jawcheek", "weightKeyCategory": "faceModifiers"}
14	16	{"_key": 16, "weightKeyPrefix": "upperlip", "weightKeyCategory": "faceModifiers"}
15	17	{"_key": 17, "weightKeyPrefix": "nostrils", "weightKeyCategory": "faceModifiers"}
16	18	{"_key": 18, "weightKeyPrefix": "jaw", "weightKeyCategory": "faceModifiers"}
17	19	{"_key": 19, "weightKeyPrefix": "outerbrow", "weightKeyCategory": "faceModifiers"}
18	20	{"_key": 20, "weightKeyPrefix": "eyesouter", "weightKeyCategory": "faceModifiers"}
19	21	{"_key": 21, "weightKeyPrefix": "eyesinner", "weightKeyCategory": "faceModifiers"}
20	22	{"_key": 22, "weightKeyPrefix": "nosetip", "weightKeyCategory": "faceModifiers"}
21	23	{"_key": 23, "weightKeyPrefix": "chin", "weightKeyCategory": "faceModifiers"}
22	24	{"_key": 24, "weightKeyPrefix": "lowerlip", "weightKeyCategory": "faceModifiers"}
23	25	{"_key": 25, "weightKeyPrefix": "innerbrow", "weightKeyCategory": "faceModifiers"}
24	26	{"_key": 26, "weightKeyPrefix": "cheeksupper", "weightKeyCategory": "faceModifiers"}
25	27	{"_key": 27, "weightKeyPrefix": "nose", "weightKeyCategory": "faceModifiers"}
26	28	{"_key": 28, "weightKeyPrefix": "mouthcorner", "weightKeyCategory": "faceModifiers"}
27	29	{"_key": 29, "weightKeyPrefix": "cheeksmiddle", "weightKeyCategory": "faceModifiers"}
28	30	{"_key": 30, "weightKeyPrefix": "ears", "weightKeyCategory": "faceModifiers"}
29	31	{"_key": 31, "weightKeyPrefix": "pinchhem", "weightKeyCategory": "utilityShapes"}
30	32	{"_key": 32, "weightKeyPrefix": "pinchchest", "weightKeyCategory": "utilityShapes"}
31	33	{"_key": 33, "weightKeyPrefix": "pinchdrapehide", "weightKeyCategory": "utilityShapes"}
32	34	{"_key": 34, "weightKeyPrefix": "pinchforearmhigh", "weightKeyCategory": "utilityShapes"}
33	35	{"_key": 35, "weightKeyPrefix": "pinchdrapefull", "weightKeyCategory": "utilityShapes"}
34	36	{"_key": 36, "weightKeyPrefix": "pincharmhigh", "weightKeyCategory": "utilityShapes"}
35	37	{"_key": 37, "weightKeyPrefix": "pinchbootankle", "weightKeyCategory": "utilityShapes"}
36	38	{"_key": 38, "weightKeyPrefix": "pantstuckknee", "weightKeyCategory": "utilityShapes"}
37	39	{"_key": 39, "weightKeyPrefix": "pinchdrape", "weightKeyCategory": "utilityShapes"}
38	40	{"_key": 40, "weightKeyPrefix": "pinchforearmlow", "weightKeyCategory": "utilityShapes"}
39	41	{"_key": 41, "weightKeyPrefix": "pantstuckmedium", "weightKeyCategory": "utilityShapes"}
40	42	{"_key": 42, "weightKeyPrefix": "pinchboothighshin", "weightKeyCategory": "utilityShapes"}
41	43	{"_key": 43, "weightKeyPrefix": "pinchbootknee", "weightKeyCategory": "utilityShapes"}
42	44	{"_key": 44, "weightKeyPrefix": "pinchtuck", "weightKeyCategory": "utilityShapes"}
43	45	{"_key": 45, "weightKeyPrefix": "pincharmlow", "weightKeyCategory": "utilityShapes"}
44	46	{"_key": 46, "weightKeyPrefix": "pantstuckshin", "weightKeyCategory": "utilityShapes"}
45	47	{"_key": 47, "weightKeyPrefix": "pinchhips", "weightKeyCategory": "utilityShapes"}
46	48	{"_key": 48, "weightKeyPrefix": "pantstucklow", "weightKeyCategory": "utilityShapes"}
47	49	{"_key": 49, "weightKeyPrefix": "pinchdfull", "weightKeyCategory": "utilityShapes"}
48	50	{"_key": 50, "weightKeyPrefix": "pantstuckhigh", "weightKeyCategory": "utilityShapes"}
49	51	{"_key": 51, "weightKeyPrefix": "pinchinner", "weightKeyCategory": "utilityShapes"}
50	52	{"_key": 52, "weightKeyPrefix": "pantstuckxhigh", "weightKeyCategory": "utilityShapes"}
51	53	{"_key": 53, "weightKeyPrefix": "pinchbootlowshin", "weightKeyCategory": "utilityShapes"}
52	726	{"_key": 726, "weightKeyPrefix": "gogglessize", "weightKeyCategory": "utilityShapes"}
53	727	{"_key": 727, "weightKeyPrefix": "gogglesunder", "weightKeyCategory": "utilityShapes"}
54	728	{"_key": 728, "weightKeyPrefix": "pinchcollar", "weightKeyCategory": "utilityShapes"}
55	729	{"_key": 729, "weightKeyPrefix": "pinchhhemlong", "weightKeyCategory": "utilityShapes"}
56	730	{"_key": 730, "weightKeyPrefix": "beltx", "weightKeyCategory": "utilityShapes"}
57	731	{"_key": 731, "weightKeyPrefix": "tighhhips", "weightKeyCategory": "utilityShapes"}
58	732	{"_key": 732, "weightKeyPrefix": "tucklow", "weightKeyCategory": "utilityShapes"}
59	733	{"_key": 733, "weightKeyPrefix": "hoodpinch", "weightKeyCategory": "utilityShapes"}
60	734	{"_key": 734, "weightKeyPrefix": "botheyepatch", "weightKeyCategory": "utilityShapes"}
61	735	{"_key": 735, "weightKeyPrefix": "tuckmed", "weightKeyCategory": "utilityShapes"}
62	736	{"_key": 736, "weightKeyPrefix": "righteyemissing", "weightKeyCategory": "utilityShapes"}
63	737	{"_key": 737, "weightKeyPrefix": "gogglesnarrow", "weightKeyCategory": "utilityShapes"}
64	738	{"_key": 738, "weightKeyPrefix": "lacenecky", "weightKeyCategory": "utilityShapes"}
65	739	{"_key": 739, "weightKeyPrefix": "laceneckx", "weightKeyCategory": "utilityShapes"}
66	740	{"_key": 740, "weightKeyPrefix": "laceneckz", "weightKeyCategory": "utilityShapes"}
67	741	{"_key": 741, "weightKeyPrefix": "cowlpinch", "weightKeyCategory": "utilityShapes"}
68	742	{"_key": 742, "weightKeyPrefix": "pinchhipleft", "weightKeyCategory": "utilityShapes"}
69	743	{"_key": 743, "weightKeyPrefix": "hatpinch", "weightKeyCategory": "utilityShapes"}
70	744	{"_key": 744, "weightKeyPrefix": "pinchhipright", "weightKeyCategory": "utilityShapes"}
71	745	{"_key": 745, "weightKeyPrefix": "pinchwaistinner", "weightKeyCategory": "utilityShapes"}
72	746	{"_key": 746, "weightKeyPrefix": "botheyemissing", "weightKeyCategory": "utilityShapes"}
73	747	{"_key": 747, "weightKeyPrefix": "hidebrowright", "weightKeyCategory": "utilityShapes"}
74	748	{"_key": 748, "weightKeyPrefix": "lefteyemissing", "weightKeyCategory": "utilityShapes"}
75	749	{"_key": 749, "weightKeyPrefix": "belthigh", "weightKeyCategory": "utilityShapes"}
76	750	{"_key": 750, "weightKeyPrefix": "tucktop", "weightKeyCategory": "utilityShapes"}
77	751	{"_key": 751, "weightKeyPrefix": "pushjacketcollar", "weightKeyCategory": "utilityShapes"}
78	752	{"_key": 752, "weightKeyPrefix": "pinchskirt", "weightKeyCategory": "utilityShapes"}
79	753	{"_key": 753, "weightKeyPrefix": "beltmid", "weightKeyCategory": "utilityShapes"}
80	754	{"_key": 754, "weightKeyPrefix": "pinchhipb", "weightKeyCategory": "utilityShapes"}
81	755	{"_key": 755, "weightKeyPrefix": "beltwith", "weightKeyCategory": "utilityShapes"}
82	756	{"_key": 756, "weightKeyPrefix": "righteyepatch", "weightKeyCategory": "utilityShapes"}
83	757	{"_key": 757, "weightKeyPrefix": "hidebrowleft", "weightKeyCategory": "utilityShapes"}
84	758	{"_key": 758, "weightKeyPrefix": "pinchskirtfull", "weightKeyCategory": "utilityShapes"}
85	759	{"_key": 759, "weightKeyPrefix": "lacelower", "weightKeyCategory": "utilityShapes"}
86	760	{"_key": 760, "weightKeyPrefix": "pushhem", "weightKeyCategory": "utilityShapes"}
87	761	{"_key": 761, "weightKeyPrefix": "pinchhhemshort", "weightKeyCategory": "utilityShapes"}
88	762	{"_key": 762, "weightKeyPrefix": "tighhtwaist", "weightKeyCategory": "utilityShapes"}
89	763	{"_key": 763, "weightKeyPrefix": "cappinch", "weightKeyCategory": "utilityShapes"}
90	764	{"_key": 764, "weightKeyPrefix": "laceupper", "weightKeyCategory": "utilityShapes"}
91	765	{"_key": 765, "weightKeyPrefix": "gogglesup", "weightKeyCategory": "utilityShapes"}
92	766	{"_key": 766, "weightKeyPrefix": "pushdrape", "weightKeyCategory": "utilityShapes"}
93	767	{"_key": 767, "weightKeyPrefix": "laceshoulder", "weightKeyCategory": "utilityShapes"}
94	768	{"_key": 768, "weightKeyPrefix": "pinchhhemfull", "weightKeyCategory": "utilityShapes"}
95	769	{"_key": 769, "weightKeyPrefix": "tuckhigh", "weightKeyCategory": "utilityShapes"}
96	770	{"_key": 770, "weightKeyPrefix": "pushjackethigh", "weightKeyCategory": "utilityShapes"}
97	771	{"_key": 771, "weightKeyPrefix": "lacewidth", "weightKeyCategory": "utilityShapes"}
98	772	{"_key": 772, "weightKeyPrefix": "lefteyepatch", "weightKeyCategory": "utilityShapes"}
99	773	{"_key": 773, "weightKeyPrefix": "hair", "weightKeyCategory": "utilityShapes"}
100	774	{"_key": 774, "weightKeyPrefix": "gogglesforward", "weightKeyCategory": "utilityShapes"}
101	775	{"_key": 775, "weightKeyPrefix": "pushjacketlow", "weightKeyCategory": "utilityShapes"}
102	776	{"_key": 776, "weightKeyPrefix": "beltlow", "weightKeyCategory": "utilityShapes"}
103	777	{"_key": 777, "weightKeyPrefix": "pinchhhemmedium", "weightKeyCategory": "utilityShapes"}
104	833	{"_key": 833, "weightKeyPrefix": "lashes", "weightKeyCategory": "faceModifiers"}
105	834	{"_key": 834, "weightKeyPrefix": "lacepinchchest", "weightKeyCategory": "utilityShapes"}
106	835	{"_key": 835, "weightKeyPrefix": "pushtopmid", "weightKeyCategory": "utilityShapes"}
107	836	{"_key": 836, "weightKeyPrefix": "pinchskirtsidesshape\\npinchtuck", "weightKeyCategory": "utilityShapes"}
108	837	{"_key": 837, "weightKeyPrefix": "pinchleftouterlowerhipsshape\\npinchskirtback", "weightKeyCategory": "utilityShapes"}
109	838	{"_key": 838, "weightKeyPrefix": "pushtophigh", "weightKeyCategory": "utilityShapes"}
110	839	{"_key": 839, "weightKeyPrefix": "gogglesnarrowshape\\nlefteyemissing", "weightKeyCategory": "utilityShapes"}
111	840	{"_key": 840, "weightKeyPrefix": "pinchleftouterhips", "weightKeyCategory": "utilityShapes"}
112	841	{"_key": 841, "weightKeyPrefix": "pinchbootlowshinshape\\npinchchest", "weightKeyCategory": "utilityShapes"}
113	842	{"_key": 842, "weightKeyPrefix": "pinchrightlowerhips", "weightKeyCategory": "utilityShapes"}
114	843	{"_key": 843, "weightKeyPrefix": "pinchrightoutermiddlehips", "weightKeyCategory": "utilityShapes"}
115	844	{"_key": 844, "weightKeyPrefix": "pushjacketchest", "weightKeyCategory": "utilityShapes"}
116	845	{"_key": 845, "weightKeyPrefix": "pinchdfullshape\\n\\ngogglesunder", "weightKeyCategory": "utilityShapes"}
117	846	{"_key": 846, "weightKeyPrefix": "pinchleftlowerhips", "weightKeyCategory": "utilityShapes"}
118	847	{"_key": 847, "weightKeyPrefix": "pinchrightouterlowerhips", "weightKeyCategory": "utilityShapes"}
119	848	{"_key": 848, "weightKeyPrefix": "beltlowshape\\ntighhhips", "weightKeyCategory": "utilityShapes"}
120	849	{"_key": 849, "weightKeyPrefix": "pincharmlowshape\\npushtopfront", "weightKeyCategory": "utilityShapes"}
121	850	{"_key": 850, "weightKeyPrefix": "lacepinchwaist", "weightKeyCategory": "utilityShapes"}
122	851	{"_key": 851, "weightKeyPrefix": "pushhemhigh", "weightKeyCategory": "utilityShapes"}
123	852	{"_key": 852, "weightKeyPrefix": "pinchhemshort", "weightKeyCategory": "utilityShapes"}
124	853	{"_key": 853, "weightKeyPrefix": "pinchleftouterupperhips", "weightKeyCategory": "utilityShapes"}
125	854	{"_key": 854, "weightKeyPrefix": "tuckmedium", "weightKeyCategory": "utilityShapes"}
126	855	{"_key": 855, "weightKeyPrefix": "pinchlefthipsshape\\n\\n\\npinchrightouterhips", "weightKeyCategory": "utilityShapes"}
127	856	{"_key": 856, "weightKeyPrefix": "lacemiddle", "weightKeyCategory": "utilityShapes"}
128	857	{"_key": 857, "weightKeyPrefix": "pushtoplowshape\\npushhemtop", "weightKeyCategory": "utilityShapes"}
129	858	{"_key": 858, "weightKeyPrefix": "pinchouterhemlong", "weightKeyCategory": "utilityShapes"}
130	859	{"_key": 859, "weightKeyPrefix": "pantstuckshoeshape\\npinchbootankle", "weightKeyCategory": "utilityShapes"}
131	860	{"_key": 860, "weightKeyPrefix": "hidebrowrightshape\\npinchhemmedium", "weightKeyCategory": "utilityShapes"}
132	861	{"_key": 861, "weightKeyPrefix": "pinchleftupperhips", "weightKeyCategory": "utilityShapes"}
133	862	{"_key": 862, "weightKeyPrefix": "pinchrightouterupperhips", "weightKeyCategory": "utilityShapes"}
134	863	{"_key": 863, "weightKeyPrefix": "pushhemlowshape\\npinchcollar", "weightKeyCategory": "utilityShapes"}
135	864	{"_key": 864, "weightKeyPrefix": "tightthighs", "weightKeyCategory": "utilityShapes"}
136	865	{"_key": 865, "weightKeyPrefix": "pushtopfrontabs\\npinchrightupperhips", "weightKeyCategory": "utilityShapes"}
137	866	{"_key": 866, "weightKeyPrefix": "pinchouterhemshort", "weightKeyCategory": "utilityShapes"}
138	867	{"_key": 867, "weightKeyPrefix": "pinchrightmiddlehips", "weightKeyCategory": "utilityShapes"}
139	868	{"_key": 868, "weightKeyPrefix": "pinchleftoutermiddlehips", "weightKeyCategory": "utilityShapes"}
140	869	{"_key": 869, "weightKeyPrefix": "cowlpinchshape\\nbeltwidthout", "weightKeyCategory": "utilityShapes"}
141	870	{"_key": 870, "weightKeyPrefix": "pinchskirtfront", "weightKeyCategory": "utilityShapes"}
142	871	{"_key": 871, "weightKeyPrefix": "pushjacketmid", "weightKeyCategory": "utilityShapes"}
143	872	{"_key": 872, "weightKeyPrefix": "pinchrighthips", "weightKeyCategory": "utilityShapes"}
144	873	{"_key": 873, "weightKeyPrefix": "tucklowshape", "weightKeyCategory": "utilityShapes"}
145	874	{"_key": 874, "weightKeyPrefix": "pushtopshoulders", "weightKeyCategory": "utilityShapes"}
146	875	{"_key": 875, "weightKeyPrefix": "tightdrapeshape\\ntucktop", "weightKeyCategory": "utilityShapes"}
147	876	{"_key": 876, "weightKeyPrefix": "lacepinchshoulders", "weightKeyCategory": "utilityShapes"}
148	877	{"_key": 877, "weightKeyPrefix": "pinchhemlong", "weightKeyCategory": "utilityShapes"}
149	878	{"_key": 878, "weightKeyPrefix": "pinchopenneck", "weightKeyCategory": "utilityShapes"}
150	879	{"_key": 879, "weightKeyPrefix": "pinchhemfullshape\\npinchouterhemmedium", "weightKeyCategory": "utilityShapes"}
151	880	{"_key": 880, "weightKeyPrefix": "pinchouterhemfullshape\\npushjackettop", "weightKeyCategory": "utilityShapes"}
152	881	{"_key": 881, "weightKeyPrefix": "pushhemmid", "weightKeyCategory": "utilityShapes"}
153	882	{"_key": 882, "weightKeyPrefix": "lacepinchabsshape\\n\\nbeltwith", "weightKeyCategory": "utilityShapes"}
154	883	{"_key": 883, "weightKeyPrefix": "pushtopwaist", "weightKeyCategory": "utilityShapes"}
155	884	{"_key": 884, "weightKeyPrefix": "pinchinnershape\\npantstuckhigh", "weightKeyCategory": "utilityShapes"}
156	885	{"_key": 885, "weightKeyPrefix": "pinchleftmiddlehips", "weightKeyCategory": "utilityShapes"}
157	886	{"_key": 886, "weightKeyPrefix": "beltwidthinshape\\npinchwaist", "weightKeyCategory": "utilityShapes"}
158	887	{"_key": 887, "weightKeyPrefix": "pushjacketlowshape\\npushtoptop", "weightKeyCategory": "utilityShapes"}
159	888	{"_key": 888, "weightKeyPrefix": "pinchrightdrapelowerhips", "weightKeyCategory": "utilityShapes"}
160	889	{"_key": 889, "weightKeyPrefix": "pinchleftdrapeupperhips", "weightKeyCategory": "utilityShapes"}
161	890	{"_key": 890, "weightKeyPrefix": "pinchskirtsidesshape\\npinchtuck", "weightKeyCategory": "utilityShapes"}
162	891	{"_key": 891, "weightKeyPrefix": "beltpinchhigh", "weightKeyCategory": "utilityShapes"}
163	892	{"_key": 892, "weightKeyPrefix": "beltfittightlow", "weightKeyCategory": "utilityShapes"}
164	893	{"_key": 893, "weightKeyPrefix": "pinchleftouterlowerhipsshape\\npinchskirtback", "weightKeyCategory": "utilityShapes"}
165	894	{"_key": 894, "weightKeyPrefix": "gogglesnarrowshape\\nlefteyemissing", "weightKeyCategory": "utilityShapes"}
166	895	{"_key": 895, "weightKeyPrefix": "beltup", "weightKeyCategory": "utilityShapes"}
167	896	{"_key": 896, "weightKeyPrefix": "pinchleftdrapelowerhipsshape\\npinchrightouterhips", "weightKeyCategory": "utilityShapes"}
168	897	{"_key": 897, "weightKeyPrefix": "pinchbootlowshinshape\\npinchchest", "weightKeyCategory": "utilityShapes"}
169	898	{"_key": 898, "weightKeyPrefix": "lacepinchabsshape\\n\\nbeltmid", "weightKeyCategory": "utilityShapes"}
170	899	{"_key": 899, "weightKeyPrefix": "pincharmlowshape\\npushtopfront", "weightKeyCategory": "utilityShapes"}
171	900	{"_key": 900, "weightKeyPrefix": "pinchrightdrapeupperhips", "weightKeyCategory": "utilityShapes"}
172	901	{"_key": 901, "weightKeyPrefix": "pinchupperhips", "weightKeyCategory": "utilityShapes"}
173	902	{"_key": 902, "weightKeyPrefix": "pushhairout", "weightKeyCategory": "utilityShapes"}
174	903	{"_key": 903, "weightKeyPrefix": "pinchshouldersshape\\ngogglesunder", "weightKeyCategory": "utilityShapes"}
175	904	{"_key": 904, "weightKeyPrefix": "pinchleftdrapehips", "weightKeyCategory": "utilityShapes"}
176	905	{"_key": 905, "weightKeyPrefix": "pushtoplowshape\\npushhemtop", "weightKeyCategory": "utilityShapes"}
177	906	{"_key": 906, "weightKeyPrefix": "beltfitloosehigh", "weightKeyCategory": "utilityShapes"}
178	907	{"_key": 907, "weightKeyPrefix": "pinchclevage", "weightKeyCategory": "utilityShapes"}
179	908	{"_key": 908, "weightKeyPrefix": "hidebrowrightshape\\npinchhemmedium", "weightKeyCategory": "utilityShapes"}
180	909	{"_key": 909, "weightKeyPrefix": "pinchhipsmiddle", "weightKeyCategory": "utilityShapes"}
181	910	{"_key": 910, "weightKeyPrefix": "beltfittighthighshape\\npantstuckhigh", "weightKeyCategory": "utilityShapes"}
182	911	{"_key": 911, "weightKeyPrefix": "beltdown", "weightKeyCategory": "utilityShapes"}
183	912	{"_key": 912, "weightKeyPrefix": "pushhemlowshape\\npinchcollar", "weightKeyCategory": "utilityShapes"}
184	913	{"_key": 913, "weightKeyPrefix": "beltpinchmedium", "weightKeyCategory": "utilityShapes"}
185	914	{"_key": 914, "weightKeyPrefix": "beltin", "weightKeyCategory": "utilityShapes"}
186	915	{"_key": 915, "weightKeyPrefix": "belttilt", "weightKeyCategory": "utilityShapes"}
187	916	{"_key": 916, "weightKeyPrefix": "pantstuckshoeshape\\npinchbootankle", "weightKeyCategory": "utilityShapes"}
188	917	{"_key": 917, "weightKeyPrefix": "hatheight", "weightKeyCategory": "utilityShapes"}
189	918	{"_key": 918, "weightKeyPrefix": "pinchopenneckshape\\nchestbridge", "weightKeyCategory": "utilityShapes"}
190	919	{"_key": 919, "weightKeyPrefix": "beltpinchlowshape\\n\\ntighhhips", "weightKeyCategory": "utilityShapes"}
191	920	{"_key": 920, "weightKeyPrefix": "tucklowshape", "weightKeyCategory": "utilityShapes"}
192	921	{"_key": 921, "weightKeyPrefix": "tightdrapeshape\\ntucktop", "weightKeyCategory": "utilityShapes"}
193	922	{"_key": 922, "weightKeyPrefix": "pinchcollarshape\\npushhemlow", "weightKeyCategory": "utilityShapes"}
194	923	{"_key": 923, "weightKeyPrefix": "pinchhemfullshape\\npinchouterhemmedium", "weightKeyCategory": "utilityShapes"}
195	924	{"_key": 924, "weightKeyPrefix": "pinchouterhemfullshape\\npushjackettop", "weightKeyCategory": "utilityShapes"}
196	925	{"_key": 925, "weightKeyPrefix": "hatflip", "weightKeyCategory": "utilityShapes"}
197	926	{"_key": 926, "weightKeyPrefix": "pinchhat", "weightKeyCategory": "utilityShapes"}
198	927	{"_key": 927, "weightKeyPrefix": "pinchhipslower", "weightKeyCategory": "utilityShapes"}
199	928	{"_key": 928, "weightKeyPrefix": "pinchinnershape\\n\\nbeltfitlooselow", "weightKeyCategory": "utilityShapes"}
200	929	{"_key": 929, "weightKeyPrefix": "hatscale", "weightKeyCategory": "utilityShapes"}
201	930	{"_key": 930, "weightKeyPrefix": "pinchcap", "weightKeyCategory": "utilityShapes"}
202	931	{"_key": 931, "weightKeyPrefix": "pushjackethighshape\\nlaceneckx", "weightKeyCategory": "utilityShapes"}
203	932	{"_key": 932, "weightKeyPrefix": "pantstuckshoes", "weightKeyCategory": "utilityShapes"}
204	933	{"_key": 933, "weightKeyPrefix": "pinchrightdrapemiddlehips", "weightKeyCategory": "utilityShapes"}
205	934	{"_key": 934, "weightKeyPrefix": "pinchleftdrapemiddlehips", "weightKeyCategory": "utilityShapes"}
206	935	{"_key": 935, "weightKeyPrefix": "pinchwaist", "weightKeyCategory": "utilityShapes"}
207	936	{"_key": 936, "weightKeyPrefix": "pushhairup", "weightKeyCategory": "utilityShapes"}
208	937	{"_key": 937, "weightKeyPrefix": "pushtoplow", "weightKeyCategory": "utilityShapes"}
209	938	{"_key": 938, "weightKeyPrefix": "pinchcowl", "weightKeyCategory": "utilityShapes"}
210	939	{"_key": 939, "weightKeyPrefix": "pinchhipsupper", "weightKeyCategory": "utilityShapes"}
211	940	{"_key": 940, "weightKeyPrefix": "pushjacketlowshape\\npushtoptop", "weightKeyCategory": "utilityShapes"}
212	941	{"_key": 941, "weightKeyPrefix": "pinchlefthipsshape\\npinchrightdrapehips", "weightKeyCategory": "utilityShapes"}
213	942	{"_key": 942, "weightKeyPrefix": "pinchhood", "weightKeyCategory": "utilityShapes"}
214	1297	{"_key": 1297, "weightKeyPrefix": "pinchhemfull", "weightKeyCategory": "utilityShapes"}
\.


--
-- Name: character_sculptinglocations character_sculptinglocations_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.character_sculptinglocations
    ADD CONSTRAINT character_sculptinglocations_pkey PRIMARY KEY (row_no);


--
-- Name: character_sculptinglocations_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX character_sculptinglocations_key_idx ON sde_native.character_sculptinglocations USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict XRWAFgUu5ILlE1q5Qg7c7SRN1vTbu6Rqq5dqKzrtz64MwwHV31X17JywGpREAFX

