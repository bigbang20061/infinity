--
-- PostgreSQL database dump
--

\restrict JtUhefTtBEcB0loxmKouBmKOVhCO6uZba6loCaGGVWqJ1EU09dTffurt04V374r

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: amplificationtransfer; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.amplificationtransfer (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: amplificationtransfer; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.amplificationtransfer (row_no, key, data) FROM stdin;
0	1	{"isk": 100000, "_key": 1, "matrixIsk": 100000}
1	2	{"isk": 10000, "_key": 2, "matrixIsk": 10000}
2	3	{"isk": 100000, "_key": 3, "matrixIsk": 100000}
3	4	{"isk": 250000, "_key": 4, "matrixIsk": 250000}
4	5	{"isk": 1000000, "_key": 5, "matrixIsk": 1000000}
\.


--
-- Name: amplificationtransfer amplificationtransfer_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.amplificationtransfer
    ADD CONSTRAINT amplificationtransfer_pkey PRIMARY KEY (row_no);


--
-- Name: amplificationtransfer_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX amplificationtransfer_key_idx ON sde_native.amplificationtransfer USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict JtUhefTtBEcB0loxmKouBmKOVhCO6uZba6loCaGGVWqJ1EU09dTffurt04V374r

