--
-- PostgreSQL database dump
--

\restrict k4VUSaYPCdZ1X5ROq9QjQheixwKSLXDBTe3Wk0hPADYtjVPcEa2bmmLYSEveIkQ

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: stationoperations; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.stationoperations (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: stationoperations; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.stationoperations (row_no, key, data) FROM stdin;
0	1	{"hub": 0.1, "_key": 1, "ratio": 0.65, "border": 0.0, "fringe": 0.7, "corridor": 0.2, "services": [3, 5, 7, 17, 19, 22, 23, 25, 26], "activityID": 1, "stationTypes": {"1": 1531, "2": 2499, "4": 1930, "8": 3866, "16": 3865}, "descriptionID": 61402, "researchFactor": 0.98, "operationNameID": 61443, "manufacturingFactor": 0.98}
1	2	{"hub": 0.5, "_key": 2, "ratio": 0.2, "border": 0.3, "fringe": 0.0, "corridor": 0.2, "services": [3, 5, 7, 17, 19, 20, 22, 23, 25, 26], "activityID": 1, "stationTypes": {"1": 4024, "2": 2497, "4": 1928, "8": 3866, "16": 3865}, "descriptionID": 61403, "researchFactor": 0.98, "operationNameID": 61444, "manufacturingFactor": 0.98}
2	3	{"hub": 0.0, "_key": 3, "ratio": 0.15, "border": 0.5, "fringe": 0.0, "corridor": 0.5, "services": [3, 5, 7, 17, 19, 20, 22, 23, 25, 26], "activityID": 1, "stationTypes": {"1": 1531, "2": 2501, "4": 1929, "8": 3870, "16": 3865}, "descriptionID": 61404, "researchFactor": 0.98, "operationNameID": 61445, "manufacturingFactor": 0.98}
3	4	{"hub": 0.0, "_key": 4, "ratio": 0.3, "border": 0.0, "fringe": 0.9, "corridor": 0.1, "services": [1, 3, 5, 7, 13, 14, 17, 19, 20, 21, 22, 23, 25, 26], "activityID": 2, "stationTypes": {"1": 1529, "2": 2499, "4": 1930, "8": 3867, "16": 3865}, "descriptionID": 61405, "researchFactor": 0.98, "operationNameID": 61446, "manufacturingFactor": 0.95}
4	5	{"hub": 0.5, "_key": 5, "ratio": 0.5, "border": 0.1, "fringe": 0.25, "corridor": 0.15, "services": [1, 3, 5, 7, 13, 14, 17, 19, 20, 21, 22, 23, 25, 26], "activityID": 2, "stationTypes": {"1": 1529, "2": 2497, "4": 1928, "8": 3867, "16": 3865}, "descriptionID": 61406, "researchFactor": 0.98, "operationNameID": 61447, "manufacturingFactor": 0.95}
5	6	{"hub": 0.0, "_key": 6, "ratio": 0.2, "border": 0.5, "fringe": 0.0, "corridor": 0.5, "services": [1, 3, 5, 7, 13, 14, 17, 19, 20, 21, 22, 23, 25, 26], "activityID": 2, "stationTypes": {"1": 1531, "2": 2501, "4": 1929, "8": 3870, "16": 3865}, "descriptionID": 61407, "researchFactor": 0.98, "operationNameID": 61448, "manufacturingFactor": 0.97}
6	7	{"hub": 0.0, "_key": 7, "ratio": 0.65, "border": 0.0, "fringe": 0.9, "corridor": 0.1, "services": [1, 3, 5, 6, 7, 13, 17, 19, 21, 22, 23, 25, 26], "activityID": 3, "stationTypes": {"1": 4023, "2": 2499, "4": 1930, "8": 3865, "16": 3865}, "descriptionID": 61408, "researchFactor": 0.98, "operationNameID": 61449, "manufacturingFactor": 0.98}
7	8	{"hub": 0.45, "_key": 8, "ratio": 0.15, "border": 0.45, "fringe": 0.0, "corridor": 0.1, "services": [1, 3, 5, 6, 7, 13, 17, 19, 21, 22, 23, 25, 26], "activityID": 3, "stationTypes": {"1": 4024, "2": 2497, "4": 1928, "8": 3867, "16": 3865}, "descriptionID": 61409, "researchFactor": 0.98, "operationNameID": 61450, "manufacturingFactor": 0.98}
8	9	{"hub": 0.0, "_key": 9, "ratio": 0.2, "border": 0.5, "fringe": 0.0, "corridor": 0.5, "services": [1, 3, 5, 7, 13, 17, 19, 20, 21, 22, 23, 25, 26], "activityID": 3, "stationTypes": {"1": 4023, "2": 2501, "4": 1929, "8": 3865, "16": 3865}, "descriptionID": 61410, "researchFactor": 0.98, "operationNameID": 61451, "manufacturingFactor": 0.98}
9	10	{"hub": 0.0, "_key": 10, "ratio": 0.1, "border": 0.0, "fringe": 0.9, "corridor": 0.1, "services": [1, 3, 5, 6, 7, 13, 14, 15, 17, 19, 21, 22, 23, 25, 26], "activityID": 4, "stationTypes": {"1": 4023, "2": 2499, "4": 1930, "8": 3867, "16": 3865}, "descriptionID": 61411, "researchFactor": 0.97, "operationNameID": 61452, "manufacturingFactor": 0.98}
10	11	{"hub": 0.9, "_key": 11, "ratio": 0.8, "border": 0.0, "fringe": 0.0, "corridor": 0.1, "services": [1, 3, 5, 6, 7, 13, 14, 15, 17, 19, 21, 22, 23, 25, 26], "activityID": 4, "stationTypes": {"1": 1529, "2": 2497, "4": 1928, "8": 3867, "16": 3865}, "descriptionID": 61412, "researchFactor": 0.97, "operationNameID": 61453, "manufacturingFactor": 0.98}
11	12	{"hub": 0.0, "_key": 12, "ratio": 0.1, "border": 0.5, "fringe": 0.0, "corridor": 0.5, "services": [1, 3, 5, 7, 13, 14, 17, 19, 20, 21, 22, 23, 25, 26], "activityID": 4, "stationTypes": {"1": 1531, "2": 2501, "4": 1929, "8": 3870, "16": 3865}, "descriptionID": 61413, "researchFactor": 0.98, "operationNameID": 61454, "manufacturingFactor": 0.97}
12	13	{"hub": 0.0, "_key": 13, "ratio": 0.2, "border": 0.0, "fringe": 0.9, "corridor": 0.1, "services": [1, 3, 5, 7, 13, 14, 15, 17, 19, 21, 22, 23, 25, 26, 27], "activityID": 5, "stationTypes": {"1": 54, "2": 2500, "4": 1931, "8": 3869, "16": 3865}, "descriptionID": 61414, "researchFactor": 0.97, "operationNameID": 61455, "manufacturingFactor": 0.97}
13	14	{"hub": 0.6, "_key": 14, "ratio": 0.55, "border": 0.3, "fringe": 0.0, "corridor": 0.1, "services": [1, 3, 5, 7, 13, 14, 17, 19, 21, 22, 23, 25, 26, 27, 10], "activityID": 5, "stationTypes": {"1": 1529, "2": 2498, "4": 1927, "8": 3867, "16": 3865}, "descriptionID": 61415, "researchFactor": 0.98, "operationNameID": 61456, "manufacturingFactor": 0.95}
14	15	{"hub": 0.0, "_key": 15, "ratio": 0.25, "border": 0.5, "fringe": 0.0, "corridor": 0.5, "services": [1, 3, 5, 7, 10, 11, 13, 17, 19, 21, 22, 23, 25, 26, 27], "activityID": 5, "stationTypes": {"1": 1530, "2": 2501, "4": 1929, "8": 3868, "16": 3865}, "descriptionID": 61416, "researchFactor": 0.98, "operationNameID": 61457, "manufacturingFactor": 0.98}
15	16	{"hub": 0.0, "_key": 16, "ratio": 0.2, "border": 0.0, "fringe": 0.7, "corridor": 0.3, "services": [1, 3, 5, 7, 10, 11, 12, 15, 17, 19, 21, 22, 23, 25, 26], "activityID": 6, "stationTypes": {"1": 54, "2": 2499, "4": 1930, "8": 3869, "16": 3865}, "descriptionID": 61417, "researchFactor": 0.95, "operationNameID": 61458, "manufacturingFactor": 0.98}
16	17	{"hub": 0.45, "_key": 17, "ratio": 0.7, "border": 0.45, "fringe": 0.0, "corridor": 0.1, "services": [1, 3, 5, 7, 10, 11, 12, 14, 17, 19, 21, 22, 23, 25, 26], "activityID": 6, "stationTypes": {"1": 1529, "2": 2497, "4": 1928, "8": 3867, "16": 3865}, "descriptionID": 61418, "researchFactor": 0.98, "operationNameID": 61459, "manufacturingFactor": 0.95}
17	18	{"hub": 0.0, "_key": 18, "ratio": 0.1, "border": 0.0, "fringe": 0.5, "corridor": 0.5, "services": [3, 5, 7, 10, 15, 17, 19, 21, 22, 23, 25, 26], "activityID": 6, "stationTypes": {"1": 54, "2": 2501, "4": 1929, "8": 3869, "16": 3865}, "descriptionID": 61419, "researchFactor": 0.95, "operationNameID": 61460, "manufacturingFactor": 0.98}
18	19	{"hub": 0.0, "_key": 19, "ratio": 0.1, "border": 0.0, "fringe": 0.7, "corridor": 0.3, "services": [1, 3, 5, 6, 7, 10, 11, 12, 13, 15, 17, 19, 21, 22, 23, 25, 26], "activityID": 7, "stationTypes": {"1": 54, "2": 2500, "4": 1931, "8": 3869, "16": 3865}, "descriptionID": 61420, "researchFactor": 0.95, "operationNameID": 61461, "manufacturingFactor": 0.98}
19	20	{"hub": 0.5, "_key": 20, "ratio": 0.8, "border": 0.4, "fringe": 0.0, "corridor": 0.1, "services": [1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 25, 26], "activityID": 7, "stationTypes": {"1": 1529, "2": 2497, "4": 1928, "8": 3867, "16": 3865}, "descriptionID": 61421, "researchFactor": 0.98, "operationNameID": 61462, "manufacturingFactor": 0.95}
20	21	{"hub": 0.0, "_key": 21, "ratio": 0.1, "border": 0.5, "fringe": 0.0, "corridor": 0.5, "services": [1, 3, 5, 7, 10, 13, 17, 19, 20, 21, 22, 23, 25, 26], "activityID": 7, "stationTypes": {"1": 1531, "2": 2501, "4": 1929, "8": 3870, "16": 3865}, "descriptionID": 61422, "researchFactor": 0.98, "operationNameID": 61463, "manufacturingFactor": 0.98}
21	22	{"hub": 0.45, "_key": 22, "ratio": 0.8, "border": 0.45, "fringe": 0.0, "corridor": 0.1, "services": [1, 3, 4, 5, 7, 9, 16, 17, 19, 21, 22, 23, 25, 26], "activityID": 8, "stationTypes": {"1": 1531, "2": 2496, "4": 1931, "8": 56, "16": 3865}, "descriptionID": 61423, "researchFactor": 0.98, "operationNameID": 61464, "manufacturingFactor": 0.98}
22	23	{"hub": 0.8, "_key": 23, "ratio": 0.2, "border": 0.1, "fringe": 0.0, "corridor": 0.1, "services": [1, 3, 4, 5, 7, 9, 16, 17, 19, 21, 22, 23, 25, 26], "activityID": 8, "stationTypes": {"1": 3872, "2": 2496, "4": 1926, "8": 57, "16": 3865}, "descriptionID": 61424, "researchFactor": 0.98, "operationNameID": 61465, "manufacturingFactor": 0.98}
23	24	{"hub": 0.9, "_key": 24, "ratio": 0.8, "border": 0.0, "fringe": 0.0, "corridor": 0.1, "services": [1, 3, 4, 5, 7, 13, 14, 17, 18, 19, 21, 22, 23, 25, 26], "activityID": 9, "stationTypes": {"1": 1530, "2": 2498, "4": 1927, "8": 3868, "16": 3865}, "descriptionID": 61425, "researchFactor": 0.98, "operationNameID": 61466, "manufacturingFactor": 0.95}
24	25	{"hub": 0.0, "_key": 25, "ratio": 0.2, "border": 0.5, "fringe": 0.0, "corridor": 0.5, "services": [1, 3, 5, 7, 13, 17, 18, 19, 20, 21, 22, 23, 25, 26], "activityID": 9, "stationTypes": {"1": 3872, "2": 2502, "4": 1929, "8": 3870, "16": 3865}, "descriptionID": 61426, "researchFactor": 0.98, "operationNameID": 61467, "manufacturingFactor": 0.98}
25	26	{"hub": 0.25, "_key": 26, "ratio": 1.0, "border": 0.25, "fringe": 0.25, "corridor": 0.25, "services": [3, 5, 7, 13, 17, 19, 20, 21, 22, 23, 25, 26], "activityID": 10, "stationTypes": {"1": 1531, "2": 2501, "4": 1929, "8": 3870, "16": 3865}, "descriptionID": 61427, "researchFactor": 0.98, "operationNameID": 61468, "manufacturingFactor": 0.98}
26	27	{"hub": 0.1, "_key": 27, "ratio": 0.7, "border": 0.25, "fringe": 0.4, "corridor": 0.25, "services": [1, 3, 5, 7, 13, 17, 19, 21, 22, 23, 25, 26], "activityID": 11, "stationTypes": {"1": 1531, "2": 2501, "4": 1929, "8": 3870, "16": 3865}, "descriptionID": 61428, "researchFactor": 0.98, "operationNameID": 61469, "manufacturingFactor": 0.98}
27	28	{"hub": 0.45, "_key": 28, "ratio": 0.3, "border": 0.45, "fringe": 0.0, "corridor": 0.1, "services": [1, 3, 4, 5, 7, 9, 10, 11, 12, 13, 17, 18, 19, 21, 22, 23, 25, 26], "activityID": 11, "stationTypes": {"1": 1531, "2": 2496, "4": 1926, "8": 57, "16": 3865}, "descriptionID": 61429, "researchFactor": 0.98, "operationNameID": 61470, "manufacturingFactor": 0.98}
28	29	{"hub": 0.0, "_key": 29, "ratio": 0.5, "border": 0.25, "fringe": 0.5, "corridor": 0.25, "services": [1, 3, 5, 7, 13, 17, 19, 20, 21, 22, 23, 25, 26], "activityID": 12, "stationTypes": {"1": 1531, "2": 2501, "4": 1929, "8": 3870, "16": 3865}, "descriptionID": 61430, "researchFactor": 0.98, "operationNameID": 61471, "manufacturingFactor": 0.98}
29	30	{"hub": 0.35, "_key": 30, "ratio": 0.5, "border": 0.5, "fringe": 0.0, "corridor": 0.15, "services": [1, 3, 5, 7, 10, 11, 13, 17, 19, 21, 22, 23, 25, 26], "activityID": 12, "stationTypes": {"1": 1531, "2": 2502, "4": 1932, "8": 3868, "16": 3865}, "descriptionID": 61431, "researchFactor": 0.98, "operationNameID": 61472, "manufacturingFactor": 0.98}
30	31	{"hub": 0.45, "_key": 31, "ratio": 0.4, "border": 0.45, "fringe": 0.0, "corridor": 0.1, "services": [1, 3, 4, 5, 7, 9, 10, 17, 19, 21, 22, 23, 25, 26], "activityID": 13, "stationTypes": {"1": 1529, "2": 2496, "4": 1926, "8": 56, "16": 3865}, "descriptionID": 61432, "researchFactor": 0.98, "operationNameID": 61473, "manufacturingFactor": 0.98}
31	32	{"hub": 0.0, "_key": 32, "ratio": 0.2, "border": 0.0, "fringe": 0.5, "corridor": 0.5, "services": [1, 3, 4, 5, 7, 9, 10, 13, 14, 17, 19, 21, 22, 23, 25, 26, 27], "activityID": 14, "stationTypes": {"1": 1529, "2": 2502, "4": 9857, "8": 57, "16": 3865}, "descriptionID": 61433, "researchFactor": 0.98, "operationNameID": 61474, "manufacturingFactor": 0.97}
32	33	{"hub": 0.4, "_key": 33, "ratio": 0.7, "border": 0.45, "fringe": 0.0, "corridor": 0.15, "services": [1, 3, 4, 5, 7, 9, 10, 13, 17, 19, 21, 22, 23, 25, 26, 27], "activityID": 14, "stationTypes": {"1": 1531, "2": 2502, "4": 1932, "8": 56, "16": 3865}, "descriptionID": 61434, "researchFactor": 0.98, "operationNameID": 61475, "manufacturingFactor": 0.98}
33	34	{"hub": 0.0, "_key": 34, "ratio": 0.1, "border": 0.0, "fringe": 1.0, "corridor": 0.0, "services": [1, 3, 4, 5, 7, 9, 10, 17, 19, 21, 22, 23, 25, 26, 27], "activityID": 14, "stationTypes": {"1": 1530, "2": 2498, "4": 1927, "8": 3868, "16": 3865}, "descriptionID": 61435, "researchFactor": 0.98, "operationNameID": 61476, "manufacturingFactor": 0.98}
34	35	{"hub": 0.85, "_key": 35, "ratio": 0.7, "border": 0.05, "fringe": 0.0, "corridor": 0.1, "services": [1, 3, 5, 7, 9, 17, 19, 21, 22, 23, 25, 26], "activityID": 17, "stationTypes": {"1": 1529, "2": 2502, "4": 1932, "8": 57, "16": 3865}, "descriptionID": 61436, "researchFactor": 0.98, "operationNameID": 61477, "manufacturingFactor": 0.98}
35	36	{"hub": 0.0, "_key": 36, "ratio": 0.3, "border": 0.0, "fringe": 1.0, "corridor": 0.0, "services": [1, 3, 5, 7, 9, 17, 19, 21, 22, 23, 25, 26], "activityID": 17, "stationTypes": {"1": 1530, "2": 2501, "4": 1927, "8": 3868, "16": 3865}, "descriptionID": 61437, "researchFactor": 0.98, "operationNameID": 61478, "manufacturingFactor": 0.98}
36	37	{"hub": 0.5, "_key": 37, "ratio": 1.0, "border": 0.5, "fringe": 0.0, "corridor": 0.0, "services": [1, 3, 5, 7, 10, 13, 14, 17, 19, 21, 22, 23, 25, 26], "activityID": 18, "stationTypes": {"1": 1529, "2": 2500, "4": 1931, "8": 57, "16": 3865}, "descriptionID": 61438, "researchFactor": 0.98, "operationNameID": 61479, "manufacturingFactor": 0.97}
37	38	{"hub": 0.45, "_key": 38, "ratio": 0.8, "border": 0.45, "fringe": 0.0, "corridor": 0.1, "services": [1, 3, 5, 7, 13, 14, 17, 19, 21, 22, 23, 25, 26], "activityID": 19, "stationTypes": {"1": 4024, "2": 2497, "4": 1928, "8": 3867, "16": 3865}, "researchFactor": 0.98, "operationNameID": 61480, "manufacturingFactor": 0.98}
38	39	{"hub": 0.0, "_key": 39, "ratio": 0.2, "border": 0.5, "fringe": 0.0, "corridor": 0.5, "services": [1, 3, 5, 7, 13, 14, 17, 19, 20, 21, 22, 23, 25, 26], "activityID": 19, "stationTypes": {"1": 1531, "2": 2501, "4": 1929, "8": 3870, "16": 3865}, "researchFactor": 0.98, "operationNameID": 61481, "manufacturingFactor": 0.98}
39	40	{"hub": 0.5, "_key": 40, "ratio": 0.4, "border": 0.5, "fringe": 0.0, "corridor": 0.0, "services": [1, 3, 5, 7, 9, 10, 13, 17, 19, 21, 22, 23, 25, 26], "activityID": 15, "stationTypes": {"1": 1530, "2": 2496, "4": 9857, "8": 3868, "16": 3865}, "descriptionID": 61439, "researchFactor": 0.98, "operationNameID": 61482, "manufacturingFactor": 0.98}
40	41	{"hub": 0.2, "_key": 41, "ratio": 0.3, "border": 0.2, "fringe": 0.3, "corridor": 0.3, "services": [1, 3, 5, 7, 9, 10, 17, 19, 21, 22, 23, 25, 26], "activityID": 15, "stationTypes": {"1": 1529, "2": 2500, "4": 1931, "8": 57, "16": 3865}, "descriptionID": 61440, "researchFactor": 0.98, "operationNameID": 61483, "manufacturingFactor": 0.98}
41	42	{"hub": 0.1, "_key": 42, "ratio": 0.3, "border": 0.1, "fringe": 0.5, "corridor": 0.3, "services": [1, 3, 5, 7, 9, 10, 17, 19, 21, 22, 23, 25, 26], "activityID": 15, "stationTypes": {"1": 3871, "2": 2502, "4": 1929, "8": 56, "16": 3865}, "researchFactor": 0.98, "operationNameID": 61484, "manufacturingFactor": 0.98}
42	43	{"hub": 0.0, "_key": 43, "ratio": 0.3, "border": 0.0, "fringe": 0.7, "corridor": 0.3, "services": [1, 3, 5, 7, 9, 17, 19, 21, 22, 23, 25, 26], "activityID": 13, "stationTypes": {"1": 1529, "2": 2500, "4": 1931, "8": 57, "16": 3865}, "descriptionID": 61441, "researchFactor": 0.98, "operationNameID": 61485, "manufacturingFactor": 0.98}
43	44	{"hub": 0.5, "_key": 44, "ratio": 0.3, "border": 0.5, "fringe": 0.0, "corridor": 0.0, "services": [1, 3, 4, 5, 7, 9, 17, 19, 21, 22, 23, 25, 26], "activityID": 13, "stationTypes": {"1": 3872, "2": 2502, "4": 1926, "8": 57, "16": 3865}, "descriptionID": 61442, "researchFactor": 0.98, "operationNameID": 61486, "manufacturingFactor": 0.98}
44	45	{"hub": 0.0, "_key": 45, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [1, 3, 10, 13, 14, 15, 17, 19, 21, 22, 23, 26], "activityID": 20, "researchFactor": 0.8, "operationNameID": 61487, "manufacturingFactor": 0.6}
45	46	{"hub": 0.0, "_key": 46, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [1, 3, 5, 10, 13, 17, 19, 21, 22, 23, 26], "activityID": 20, "researchFactor": 0.8, "operationNameID": 61488, "manufacturingFactor": 0.95}
46	47	{"hub": 0.0, "_key": 47, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [1, 3, 10, 13, 14, 15, 17, 19, 21, 22, 23, 26], "activityID": 20, "researchFactor": 0.7, "operationNameID": 61489, "manufacturingFactor": 0.8}
47	48	{"hub": 0.0, "_key": 48, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [1, 3, 5, 10, 13, 14, 15, 17, 19, 21, 22, 23, 26], "activityID": 20, "researchFactor": 0.5, "operationNameID": 61490, "manufacturingFactor": 0.6}
48	49	{"hub": 0.0, "_key": 49, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [1, 3, 5, 10, 13, 14, 15, 17, 19, 21, 22, 23, 26], "activityID": 20, "researchFactor": 0.6, "operationNameID": 61491, "manufacturingFactor": 0.5}
49	50	{"hub": 0.0, "_key": 50, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [1, 3, 5, 7, 10, 13, 14, 15, 17, 19, 21, 22, 23, 26], "activityID": 20, "researchFactor": 0.6, "operationNameID": 61492, "manufacturingFactor": 0.6}
50	51	{"hub": 0.0, "_key": 51, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [1, 3, 5, 10, 13, 14, 17, 21, 22, 23, 26], "activityID": 20, "researchFactor": 0.6, "operationNameID": 61493, "manufacturingFactor": 0.7}
51	52	{"hub": 0.0, "_key": 52, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 25, 26], "activityID": 7, "descriptionID": 297357, "researchFactor": 0.9, "operationNameID": 297353, "manufacturingFactor": 0.9}
52	53	{"hub": 0.0, "_key": 53, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 25, 26], "activityID": 7, "descriptionID": 297358, "researchFactor": 0.9, "operationNameID": 297354, "manufacturingFactor": 0.9}
53	54	{"hub": 0.0, "_key": 54, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 25, 26], "activityID": 7, "descriptionID": 297359, "researchFactor": 0.9, "operationNameID": 297355, "manufacturingFactor": 0.9}
54	55	{"hub": 0.0, "_key": 55, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 25, 26], "activityID": 7, "descriptionID": 297360, "researchFactor": 0.9, "operationNameID": 297356, "manufacturingFactor": 0.9}
55	106	{"hub": 0.0, "_key": 106, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [5, 7, 10, 13, 14, 17, 18, 19, 20, 22, 23, 24, 25, 21], "activityID": 7, "stationTypes": {}, "descriptionID": 571417, "researchFactor": 0.98, "operationNameID": 567791, "manufacturingFactor": 0.98}
56	109	{"hub": 0.0, "_key": 109, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [5, 7, 10, 13, 14, 17, 18, 19, 20, 22, 23, 24, 25, 21], "activityID": 7, "stationTypes": {}, "descriptionID": 571418, "researchFactor": 0.98, "operationNameID": 569809, "manufacturingFactor": 0.98}
57	110	{"hub": 0.0, "_key": 110, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [5, 7, 10, 13, 14, 17, 18, 19, 20, 22, 23, 24, 25, 21], "activityID": 7, "stationTypes": {}, "descriptionID": 571419, "researchFactor": 0.98, "operationNameID": 569810, "manufacturingFactor": 0.98}
58	111	{"hub": 0.0, "_key": 111, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [5, 7, 10, 13, 14, 17, 18, 19, 20, 22, 23, 24, 25, 21], "activityID": 7, "stationTypes": {}, "descriptionID": 571420, "researchFactor": 0.98, "operationNameID": 569811, "manufacturingFactor": 0.98}
59	112	{"hub": 0.0, "_key": 112, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [5, 7, 10, 13, 14, 17, 18, 19, 20, 22, 23, 24, 25, 21], "activityID": 7, "stationTypes": {}, "descriptionID": 571421, "researchFactor": 0.98, "operationNameID": 569812, "manufacturingFactor": 0.98}
60	113	{"hub": 0.0, "_key": 113, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [5, 7, 10, 13, 14, 17, 18, 19, 20, 22, 23, 24, 25, 21], "activityID": 7, "stationTypes": {}, "descriptionID": 571422, "researchFactor": 0.98, "operationNameID": 569813, "manufacturingFactor": 0.98}
61	114	{"hub": 0.0, "_key": 114, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [5, 7, 10, 13, 14, 17, 18, 19, 20, 21, 22, 23, 25, 26], "activityID": 14, "stationTypes": {}, "descriptionID": 585328, "researchFactor": 0.98, "operationNameID": 585329, "manufacturingFactor": 0.98}
62	117	{"hub": 0.6, "_key": 117, "ratio": 0.55, "border": 0.3, "fringe": 0.0, "corridor": 0.1, "services": [5, 6, 7, 10, 13, 14, 17, 22, 23, 25, 26, 27, 55], "activityID": 5, "stationTypes": {"1": 70890, "2": 72938, "4": 72940, "8": 72939, "16": 70890}, "researchFactor": 1.0, "operationNameID": 626366, "manufacturingFactor": 1.0}
63	118	{"hub": 0.0, "_key": 118, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [5, 7, 10, 13, 14, 17, 18, 19, 20, 21, 22, 23, 25, 26], "activityID": 5, "stationTypes": {"1": 1529, "8": 56}, "researchFactor": 0.98, "operationNameID": 636345, "manufacturingFactor": 0.98}
64	119	{"hub": 0.0, "_key": 119, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [25, 7, 10, 13, 17, 18, 20, 21, 22, 23], "activityID": 12, "stationTypes": {}, "researchFactor": 0.98, "operationNameID": 637505, "manufacturingFactor": 0.98}
65	120	{"hub": 0.0, "_key": 120, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [7, 22], "activityID": 14, "stationTypes": {"2": 2502}, "descriptionID": 638782, "researchFactor": 1.0, "operationNameID": 638756, "manufacturingFactor": 1.0}
66	121	{"hub": 0.0, "_key": 121, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [5, 7, 10, 13, 14, 17, 18, 19, 20, 21, 22, 23, 25, 26], "activityID": 14, "stationTypes": {"16": 78334}, "descriptionID": 669721, "researchFactor": 0.98, "operationNameID": 666500, "manufacturingFactor": 0.98}
67	123	{"hub": 0.0, "_key": 123, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [1, 3, 5, 7, 10, 11, 13, 17, 19, 21, 22, 23, 25, 14], "activityID": 12, "stationTypes": {}, "researchFactor": 0.98, "operationNameID": 1041565, "manufacturingFactor": 0.98}
68	124	{"hub": 0.0, "_key": 124, "ratio": 0.0, "border": 0.0, "fringe": 0.0, "corridor": 0.0, "services": [3, 5, 7, 13, 17, 19, 21, 22, 23, 25, 26, 27], "activityID": 12, "stationTypes": {}, "descriptionID": 1044256, "researchFactor": 0.98, "operationNameID": 1044255, "manufacturingFactor": 0.98}
\.


--
-- Name: stationoperations stationoperations_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.stationoperations
    ADD CONSTRAINT stationoperations_pkey PRIMARY KEY (row_no);


--
-- Name: stationoperations_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX stationoperations_key_idx ON sde_native.stationoperations USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict k4VUSaYPCdZ1X5ROq9QjQheixwKSLXDBTe3Wk0hPADYtjVPcEa2bmmLYSEveIkQ

