--
-- PostgreSQL database dump
--

\restrict MyIVDVRgGdj8JHVAgl0emCRbvrrjhIC0NBRFh2levyJPJdEcy9Mgtq8FkotpCe0

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: triggertypes; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.triggertypes (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: triggertypes; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.triggertypes (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "allowOnGuards": true, "triggerTypeName": "Attacked", "allowOnGuardObject": true}
1	2	{"_key": 2, "allowOnGuards": false, "triggerTypeName": "Ship Entered Proximity", "allowOnGuardObject": true}
2	3	{"_key": 3, "allowOnGuards": true, "triggerTypeName": "Exploding", "allowOnGuardObject": true}
3	4	{"_key": 4, "allowOnGuards": true, "triggerTypeName": "Shield Condition Level", "allowOnGuardObject": true}
4	5	{"_key": 5, "allowOnGuards": true, "triggerTypeName": "Armor Condition Level", "allowOnGuardObject": true}
5	6	{"_key": 6, "allowOnGuards": true, "triggerTypeName": "Structure Condition Level", "allowOnGuardObject": true}
6	7	{"_key": 7, "allowOnGuards": false, "triggerTypeName": "Mined", "allowOnGuardObject": true}
7	8	{"_key": 8, "allowOnGuards": true, "triggerTypeName": "Room Entered", "allowOnGuardObject": true}
8	9	{"_key": 9, "allowOnGuards": true, "triggerTypeName": "Room Mined Out", "allowOnGuardObject": true}
9	10	{"_key": 10, "allowOnGuards": true, "triggerTypeName": "Room Mined", "allowOnGuardObject": true}
10	11	{"_key": 11, "allowOnGuards": false, "triggerTypeName": "Hacking Success", "allowOnGuardObject": true}
11	12	{"_key": 12, "allowOnGuards": false, "triggerTypeName": "Hacking Failure", "allowOnGuardObject": true}
12	13	{"_key": 13, "allowOnGuards": false, "triggerTypeName": "Salvaging Success", "allowOnGuardObject": true}
13	14	{"_key": 14, "allowOnGuards": false, "triggerTypeName": "Salvaging Failure", "allowOnGuardObject": true}
14	15	{"_key": 15, "allowOnGuards": false, "triggerTypeName": "Archaeology Success", "allowOnGuardObject": true}
15	16	{"_key": 16, "allowOnGuards": false, "triggerTypeName": "Archaeology Failure", "allowOnGuardObject": true}
16	17	{"_key": 17, "allowOnGuards": true, "triggerTypeName": "Ships Entered Room", "allowOnGuardObject": true}
17	18	{"_key": 18, "allowOnGuards": false, "triggerTypeName": "Room Captured Corp", "allowOnGuardObject": true}
18	19	{"_key": 19, "allowOnGuards": false, "triggerTypeName": "Room Captured Alliance", "allowOnGuardObject": true}
19	20	{"_key": 20, "allowOnGuards": false, "triggerTypeName": "Room Captured FacWar", "allowOnGuardObject": true}
20	21	{"_key": 21, "allowOnGuards": false, "triggerTypeName": "FW Ship Entered Proximity", "allowOnGuardObject": true}
21	23	{"_key": 23, "allowOnGuards": false, "triggerTypeName": "Item Placed In Mission Container", "allowOnGuardObject": true}
22	26	{"_key": 26, "allowOnGuards": true, "triggerTypeName": "Player Killed by NPC", "allowOnGuardObject": true}
23	27	{"_key": 27, "allowOnGuards": true, "triggerTypeName": "Effect Activated", "allowOnGuardObject": true}
24	28	{"_key": 28, "allowOnGuards": true, "triggerTypeName": "Ships Left Room", "allowOnGuardObject": true}
25	29	{"_key": 29, "allowOnGuards": false, "triggerTypeName": "Ship Left Proximity", "allowOnGuardObject": true}
26	30	{"_key": 30, "allowOnGuards": false, "triggerTypeName": "FW Ship Left Proximity", "allowOnGuardObject": true}
27	31	{"_key": 31, "allowOnGuards": false, "triggerTypeName": "Room Wiped Out", "allowOnGuardObject": true}
28	32	{"_key": 32, "allowOnGuards": false, "triggerTypeName": "Item Removed From Spawn Container", "allowOnGuardObject": true}
29	33	{"_key": 33, "allowOnGuards": true, "triggerTypeName": "Item In Cargo", "allowOnGuardObject": true}
30	34	{"_key": 34, "allowOnGuards": false, "triggerTypeName": "Counter Equal To", "allowOnGuardObject": true}
31	35	{"_key": 35, "allowOnGuards": false, "triggerTypeName": "Counter Greater Than", "allowOnGuardObject": true}
32	36	{"_key": 36, "allowOnGuards": false, "triggerTypeName": "Counter Greater Than Or Equal To", "allowOnGuardObject": true}
33	37	{"_key": 37, "allowOnGuards": false, "triggerTypeName": "Counter Less Than", "allowOnGuardObject": true}
34	38	{"_key": 38, "allowOnGuards": false, "triggerTypeName": "Counter Less Than Or Equal To", "allowOnGuardObject": true}
35	41	{"_key": 41, "allowOnGuards": false, "triggerTypeName": "Timer Complete", "allowOnGuardObject": true}
36	44	{"_key": 44, "allowOnGuards": true, "triggerTypeName": "Hauler Cargo Full", "allowOnGuardObject": true}
37	46	{"_key": 46, "allowOnGuards": false, "triggerTypeName": "Reactive Spawner Total Points Destroyed", "allowOnGuardObject": true}
38	47	{"_key": 47, "allowOnGuards": false, "triggerTypeName": "Wormhole Collapse Impending", "allowOnGuardObject": true}
39	48	{"_key": 48, "allowOnGuards": true, "triggerTypeName": "Asteroid Depleted", "allowOnGuardObject": true}
40	50	{"_key": 50, "allowOnGuards": true, "triggerTypeName": "Blackboard Value Equals String", "allowOnGuardObject": true}
41	51	{"_key": 51, "allowOnGuards": true, "triggerTypeName": "Blackboard Value Equals Integer", "allowOnGuardObject": true}
42	52	{"_key": 52, "allowOnGuards": true, "triggerTypeName": "Ship Boarded", "allowOnGuardObject": true}
43	55	{"_key": 55, "allowOnGuards": false, "triggerTypeName": "Hacking Initialize", "allowOnGuardObject": true}
44	56	{"_key": 56, "allowOnGuards": false, "triggerTypeName": "Occupier Reached Threshold", "allowOnGuardObject": true}
45	57	{"_key": 57, "allowOnGuards": false, "triggerTypeName": "Attacker Reached Threshold", "allowOnGuardObject": true}
46	58	{"_key": 58, "allowOnGuards": false, "triggerTypeName": "Scoreboard Equal To", "allowOnGuardObject": true}
47	59	{"_key": 59, "allowOnGuards": false, "triggerTypeName": "Room Captured Insurgency", "allowOnGuardObject": true}
48	60	{"_key": 60, "allowOnGuards": false, "triggerTypeName": "TowGame Faction Reached Win Threshold", "allowOnGuardObject": true}
49	61	{"_key": 61, "allowOnGuards": false, "triggerTypeName": "Item Trader Trade Successful", "allowOnGuardObject": true}
50	62	{"_key": 62, "allowOnGuards": false, "triggerTypeName": "Hauler Cargo Changed", "allowOnGuardObject": true}
\.


--
-- Name: triggertypes triggertypes_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.triggertypes
    ADD CONSTRAINT triggertypes_pkey PRIMARY KEY (row_no);


--
-- Name: triggertypes_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX triggertypes_key_idx ON sde_native.triggertypes USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict MyIVDVRgGdj8JHVAgl0emCRbvrrjhIC0NBRFh2levyJPJdEcy9Mgtq8FkotpCe0

