--
-- PostgreSQL database dump
--

\restrict YTfWjSUAiRoky56xGxSbFHYI119thS4p2CNYG9pJbzHR5KyLIljDkrN5Ry6Z38A

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: gachacosts; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.gachacosts (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: gachacosts; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.gachacosts (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "cost": [{"toCount": 1, "fromCount": 0, "ticketSpent": 1, "gachaTableId": 1}, {"fromCount": 2, "ticketSpent": 1, "gachaTableId": 1}], "tableName": "cost table  1"}
1	2	{"_key": 2, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 1}], "tableName": "cost table  2"}
2	3	{"_key": 3, "cost": [{"toCount": 1, "fromCount": 0, "ticketSpent": 1, "gachaTableId": 2}, {"fromCount": 2, "ticketSpent": 1, "gachaTableId": 2}], "tableName": "2023 06 05 ship gacha cost table  1"}
3	4	{"_key": 4, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 2}], "tableName": "2023 06 05 ship gacha cost table  2"}
4	5	{"_key": 5, "cost": [{"toCount": 1, "fromCount": 0, "ticketSpent": 1, "gachaTableId": 3}, {"fromCount": 2, "ticketSpent": 1, "gachaTableId": 3}], "tableName": "2023 07 05 ship gacha cost table 1"}
5	6	{"_key": 6, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 3}], "tableName": "2023 07 05 ship gacha cost table  2"}
6	7	{"_key": 7, "cost": [{"toCount": 1, "fromCount": 0, "ticketSpent": 1, "gachaTableId": 4}, {"fromCount": 2, "ticketSpent": 1, "gachaTableId": 4}], "tableName": "2023 08 10 ship gacha cost table 1"}
7	8	{"_key": 8, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 4}], "tableName": "2023 08 10 ship gacha cost table  2"}
8	9	{"_key": 9, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 5}], "tableName": "2023 09 07 ship gacha cost table 1"}
9	10	{"_key": 10, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 5}], "tableName": "2023 09 07 ship gacha cost table  2"}
10	11	{"_key": 11, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 6}], "tableName": "2023 09 21 Buildskin gacha cost table 1"}
11	12	{"_key": 12, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 6}], "tableName": "2023 09 21 Buildskin gacha cost table  2"}
12	13	{"_key": 13, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 7}], "tableName": "Inspector 2023 11 table1"}
13	14	{"_key": 14, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 7}], "tableName": "Inspector 2023 11 table2"}
14	15	{"_key": 15, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 8}], "tableName": "202312 Gabriel 1"}
15	16	{"_key": 16, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 8}], "tableName": "202312 Gabriel 2"}
16	22	{"_key": 22, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 11}], "tableName": "202405 Gabriel 1"}
17	23	{"_key": 23, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 11}], "tableName": "202405 Gabriel 2"}
18	24	{"_key": 24, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 16}], "tableName": "202406 Dziewanna 1"}
19	25	{"_key": 25, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 16}], "tableName": "202406 Dziewanna 2"}
20	26	{"_key": 26, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 13}], "tableName": "Inspector last time 1"}
21	27	{"_key": 27, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 13}], "tableName": "Inspector last time 2"}
22	28	{"_key": 28, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 14}], "tableName": "Xolotl first time 1"}
23	29	{"_key": 29, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 14}], "tableName": "Xolotl first time 2"}
24	30	{"_key": 30, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 15}], "tableName": "202412 Gabriel 1"}
25	31	{"_key": 31, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 15}], "tableName": "202412 Gabriel 2"}
26	32	{"_key": 32, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 17}], "tableName": "2025 03 Stellian 1"}
27	33	{"_key": 33, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 17}], "tableName": "2025 03 Stellian 10"}
28	34	{"_key": 34, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 18}], "tableName": "2025 05 Python 1"}
29	35	{"_key": 35, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 18}], "tableName": "2025 05 Python 10"}
30	36	{"_key": 36, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 19}], "tableName": "Xolotl 2nd time 1"}
31	37	{"_key": 37, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 19}], "tableName": "Xolotl 2nd time 10"}
32	38	{"_key": 38, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 20}], "tableName": "Crescent 1st time 1"}
33	39	{"_key": 39, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 20}], "tableName": "Crescent 1st time 10"}
34	40	{"_key": 40, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 21}], "tableName": "2025 12 Stellian 1"}
35	41	{"_key": 41, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 21}], "tableName": "2025 12 Stellian 10"}
36	42	{"_key": 42, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 22}], "tableName": "2026 01 Python 1"}
37	43	{"_key": 43, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 22}], "tableName": "2026 01 Python 10"}
38	44	{"_key": 44, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 23}], "tableName": "Crescent 2nd time 1"}
39	45	{"_key": 45, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 23}], "tableName": "Crescent 2nd time 10"}
40	46	{"_key": 46, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 24}], "tableName": "Xolotl 3rd time 1"}
41	47	{"_key": 47, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 24}], "tableName": "Xolotl 3rd time 10"}
42	48	{"_key": 48, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 25}], "tableName": "202606 Physeter 1"}
43	49	{"_key": 49, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 25}], "tableName": "202606 Physeter 10"}
44	50	{"_key": 50, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 26}], "tableName": "202610 Stellian 1"}
45	51	{"_key": 51, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 26}], "tableName": "202610 Stellian 10"}
46	9991	{"_key": 9991, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 999}], "tableName": "Matrix gacha 1"}
47	9992	{"_key": 9992, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 999}], "tableName": "Matrix gacha 10"}
48	99911	{"_key": 99911, "cost": [{"fromCount": 0, "ticketSpent": 1, "gachaTableId": 9991}], "tableName": "Matrix up 1"}
49	99912	{"_key": 99912, "cost": [{"fromCount": 0, "ticketSpent": 10, "gachaTableId": 9991}], "tableName": "Matrix up 2"}
\.


--
-- Name: gachacosts gachacosts_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.gachacosts
    ADD CONSTRAINT gachacosts_pkey PRIMARY KEY (row_no);


--
-- Name: gachacosts_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX gachacosts_key_idx ON sde_native.gachacosts USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict YTfWjSUAiRoky56xGxSbFHYI119thS4p2CNYG9pJbzHR5KyLIljDkrN5Ry6Z38A

