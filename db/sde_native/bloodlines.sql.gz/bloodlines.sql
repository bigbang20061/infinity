--
-- PostgreSQL database dump
--

\restrict zxCBuF2zJgLlqAszYuIGTawigphv9laU5TBborgTf8NTXxklF8yLdA09vHU7r1G

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bloodlines; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.bloodlines (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: bloodlines; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.bloodlines (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "iconID": 1633, "memory": 7, "nameID": 59534, "raceID": 1, "charisma": 6, "willpower": 5, "perception": 5, "intelligence": 7, "corporationID": 1000006, "descriptionID": 59520}
1	2	{"_key": 2, "iconID": 1631, "memory": 4, "nameID": 59533, "raceID": 1, "charisma": 6, "willpower": 6, "perception": 9, "intelligence": 5, "corporationID": 1000009, "descriptionID": 59519}
2	3	{"_key": 3, "iconID": 1634, "memory": 6, "nameID": 59536, "raceID": 2, "charisma": 6, "willpower": 6, "perception": 5, "intelligence": 7, "corporationID": 1000046, "descriptionID": 59522}
3	4	{"_key": 4, "iconID": 1635, "memory": 4, "nameID": 59537, "raceID": 2, "charisma": 6, "willpower": 7, "perception": 9, "intelligence": 4, "corporationID": 1000049, "descriptionID": 59523}
4	5	{"_key": 5, "iconID": 1628, "memory": 6, "nameID": 59541, "raceID": 4, "charisma": 3, "willpower": 10, "perception": 4, "intelligence": 7, "corporationID": 1000066, "descriptionID": 59527}
5	6	{"_key": 6, "iconID": 1632, "memory": 6, "nameID": 59539, "raceID": 4, "charisma": 8, "willpower": 4, "perception": 7, "intelligence": 5, "corporationID": 1000072, "descriptionID": 59525}
6	7	{"_key": 7, "iconID": 1629, "memory": 4, "nameID": 59542, "raceID": 8, "charisma": 8, "willpower": 4, "perception": 8, "intelligence": 6, "corporationID": 1000107, "descriptionID": 59528}
7	8	{"_key": 8, "iconID": 1630, "memory": 7, "nameID": 59544, "raceID": 8, "charisma": 6, "willpower": 6, "perception": 3, "intelligence": 8, "corporationID": 1000111, "descriptionID": 59530}
8	9	{"_key": 9, "iconID": 0, "memory": 10, "nameID": 59531, "raceID": 16, "charisma": 5, "willpower": 8, "perception": 7, "intelligence": 10, "corporationID": 1000177, "descriptionID": 59517}
9	10	{"_key": 10, "iconID": 0, "memory": 7, "nameID": 59532, "raceID": 16, "charisma": 7, "willpower": 9, "perception": 10, "intelligence": 7, "corporationID": 1000178, "descriptionID": 59518}
10	11	{"_key": 11, "iconID": 3022, "memory": 6, "nameID": 59535, "raceID": 1, "charisma": 3, "willpower": 6, "perception": 7, "intelligence": 8, "corporationID": 1000014, "descriptionID": 59521}
11	12	{"_key": 12, "iconID": 3024, "memory": 5, "nameID": 59543, "raceID": 8, "charisma": 7, "willpower": 7, "perception": 6, "intelligence": 5, "corporationID": 1000114, "descriptionID": 59529}
12	13	{"_key": 13, "iconID": 3023, "memory": 4, "nameID": 59540, "raceID": 4, "charisma": 5, "willpower": 8, "perception": 8, "intelligence": 5, "corporationID": 1000080, "descriptionID": 59526}
13	14	{"_key": 14, "iconID": 3021, "memory": 8, "nameID": 59538, "raceID": 2, "charisma": 8, "willpower": 3, "perception": 4, "intelligence": 7, "corporationID": 1000060, "descriptionID": 59524}
14	19	{"_key": 19, "iconID": 21404, "memory": 0, "nameID": 305256, "raceID": 16, "charisma": 0, "willpower": 0, "perception": 0, "intelligence": 0, "corporationID": 1000274, "descriptionID": 305412}
15	25	{"_key": 25, "memory": 9, "nameID": 317921, "raceID": 135, "charisma": 9, "willpower": 9, "perception": 9, "intelligence": 9, "corporationID": 1000293, "descriptionID": 317924}
16	26	{"_key": 26, "memory": 9, "nameID": 317922, "raceID": 135, "charisma": 9, "willpower": 9, "perception": 9, "intelligence": 9, "corporationID": 1000293, "descriptionID": 317925}
17	27	{"_key": 27, "memory": 9, "nameID": 317923, "raceID": 135, "charisma": 9, "willpower": 9, "perception": 9, "intelligence": 9, "corporationID": 1000293, "descriptionID": 317926}
18	83	{"_key": 83, "memory": 6, "nameID": 725164, "raceID": 169, "charisma": 6, "willpower": 6, "perception": 6, "intelligence": 6, "corporationID": 1000465}
\.


--
-- Name: bloodlines bloodlines_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.bloodlines
    ADD CONSTRAINT bloodlines_pkey PRIMARY KEY (row_no);


--
-- Name: bloodlines_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX bloodlines_key_idx ON sde_native.bloodlines USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict zxCBuF2zJgLlqAszYuIGTawigphv9laU5TBborgTf8NTXxklF8yLdA09vHU7r1G

