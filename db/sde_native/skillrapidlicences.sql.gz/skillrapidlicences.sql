--
-- PostgreSQL database dump
--

\restrict dqUy4xddfHF5KHNxkBadm09JPNGAACdeWYvpbJiv3MmhVTtnincexDAFK72JqBP

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: skillrapidlicences; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.skillrapidlicences (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: skillrapidlicences; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.skillrapidlicences (row_no, key, data) FROM stdin;
0	11	{"_key": 11, "typeID": 75912, "skillLevels": [{"level": 1, "skillID": 3421}, {"level": 1, "skillID": 3413}, {"level": 1, "skillID": 3423}, {"level": 2, "skillID": 3416}]}
1	221	{"_key": 221, "typeID": 72082, "skillLevels": [{"level": 5, "skillID": 3319}, {"level": 5, "skillID": 12441}]}
2	222	{"_key": 222, "typeID": 72064, "skillLevels": [{"level": 5, "skillID": 21071}, {"level": 5, "skillID": 20314}]}
3	223	{"_key": 223, "typeID": 72065, "skillLevels": [{"level": 5, "skillID": 20312}, {"level": 5, "skillID": 20315}, {"level": 5, "skillID": 12442}]}
4	224	{"_key": 224, "typeID": 72046, "skillLevels": [{"level": 5, "skillID": 3300}, {"level": 5, "skillID": 3310}]}
5	225	{"_key": 225, "typeID": 72047, "skillLevels": [{"level": 5, "skillID": 3316}, {"level": 5, "skillID": 3315}]}
6	226	{"_key": 226, "typeID": 72048, "skillLevels": [{"level": 5, "skillID": 3317}, {"level": 5, "skillID": 3311}, {"level": 5, "skillID": 3312}]}
7	227	{"_key": 227, "typeID": 72049, "skillLevels": [{"level": 5, "skillID": 3392}, {"level": 5, "skillID": 3393}]}
8	228	{"_key": 228, "typeID": 72050, "skillLevels": [{"level": 5, "skillID": 3394}, {"level": 5, "skillID": 33078}]}
9	229	{"_key": 229, "typeID": 72051, "skillLevels": [{"level": 5, "skillID": 22809}, {"level": 5, "skillID": 22807}, {"level": 5, "skillID": 22806}, {"level": 5, "skillID": 22808}]}
10	230	{"_key": 230, "typeID": 72052, "skillLevels": [{"level": 5, "skillID": 3425}]}
11	231	{"_key": 231, "typeID": 72053, "skillLevels": [{"level": 5, "skillID": 3416}, {"level": 5, "skillID": 3419}, {"level": 5, "skillID": 3422}]}
12	232	{"_key": 232, "typeID": 72054, "skillLevels": [{"level": 5, "skillID": 11566}, {"level": 5, "skillID": 12367}, {"level": 5, "skillID": 12365}, {"level": 5, "skillID": 12366}]}
13	233	{"_key": 233, "typeID": 72055, "skillLevels": [{"level": 5, "skillID": 3449}]}
14	234	{"_key": 234, "typeID": 72066, "skillLevels": [{"level": 5, "skillID": 3453}, {"level": 5, "skillID": 3455}]}
15	235	{"_key": 235, "typeID": 72056, "skillLevels": [{"level": 5, "skillID": 4385}]}
16	236	{"_key": 236, "typeID": 72057, "skillLevels": [{"level": 5, "skillID": 3426}, {"level": 5, "skillID": 3318}]}
17	237	{"_key": 237, "typeID": 72058, "skillLevels": [{"level": 5, "skillID": 3418}, {"level": 5, "skillID": 3417}]}
18	238	{"_key": 238, "typeID": 72059, "skillLevels": [{"level": 5, "skillID": 3424}, {"level": 5, "skillID": 3413}, {"level": 5, "skillID": 11207}]}
19	239	{"_key": 239, "typeID": 72060, "skillLevels": [{"level": 5, "skillID": 3436}, {"level": 5, "skillID": 3437}]}
20	240	{"_key": 240, "typeID": 72061, "skillLevels": [{"level": 5, "skillID": 12305}, {"level": 5, "skillID": 23618}]}
21	241	{"_key": 241, "typeID": 72062, "skillLevels": [{"level": 5, "skillID": 3442}, {"level": 5, "skillID": 23566}, {"level": 5, "skillID": 23606}]}
22	242	{"_key": 242, "typeID": 72063, "skillLevels": [{"level": 5, "skillID": 25544}, {"level": 5, "skillID": 3386}, {"level": 5, "skillID": 16281}, {"level": 5, "skillID": 25863}]}
23	243	{"_key": 243, "typeID": 72067, "skillLevels": [{"level": 5, "skillID": 45746}, {"level": 5, "skillID": 3410}, {"level": 5, "skillID": 22578}, {"level": 5, "skillID": 62450}]}
24	244	{"_key": 244, "typeID": 72068, "skillLevels": [{"level": 5, "skillID": 25235}, {"level": 5, "skillID": 16595}]}
25	245	{"_key": 245, "typeID": 72069, "skillLevels": [{"level": 5, "skillID": 3446}, {"level": 5, "skillID": 3443}, {"level": 5, "skillID": 3444}]}
26	246	{"_key": 246, "typeID": 72042, "skillLevels": [{"level": 5, "skillID": 16598}, {"level": 5, "skillID": 3447}, {"level": 5, "skillID": 16596}]}
27	247	{"_key": 247, "typeID": 72043, "skillLevels": [{"level": 5, "skillID": 3380}, {"level": 5, "skillID": 26224}]}
28	248	{"_key": 248, "typeID": 72044, "skillLevels": [{"level": 5, "skillID": 24268}, {"level": 5, "skillID": 3387}]}
29	249	{"_key": 249, "typeID": 72045, "skillLevels": [{"level": 5, "skillID": 3388}, {"level": 5, "skillID": 24625}]}
30	250	{"_key": 250, "typeID": 72171, "skillLevels": [{"level": 5, "skillID": 3331}, {"level": 5, "skillID": 3335}]}
31	251	{"_key": 251, "typeID": 72172, "skillLevels": [{"level": 5, "skillID": 3328}, {"level": 5, "skillID": 3332}]}
32	252	{"_key": 252, "typeID": 72173, "skillLevels": [{"level": 5, "skillID": 3330}, {"level": 5, "skillID": 3334}]}
33	253	{"_key": 253, "typeID": 72174, "skillLevels": [{"level": 5, "skillID": 3329}, {"level": 5, "skillID": 3333}]}
34	254	{"_key": 254, "typeID": 72154, "skillLevels": [{"level": 3, "skillID": 3328}, {"level": 3, "skillID": 3329}, {"level": 3, "skillID": 3330}, {"level": 3, "skillID": 3331}, {"level": 1, "skillID": 3450}, {"level": 2, "skillID": 3424}, {"level": 3, "skillID": 3394}, {"level": 1, "skillID": 3392}, {"level": 1, "skillID": 3393}, {"level": 1, "skillID": 3303}, {"level": 1, "skillID": 3318}]}
35	255	{"_key": 255, "typeID": 72169, "skillLevels": [{"level": 1, "skillID": 3327}, {"level": 3, "skillID": 33091}, {"level": 3, "skillID": 3331}, {"level": 3, "skillID": 33092}, {"level": 3, "skillID": 3330}, {"level": 3, "skillID": 33093}, {"level": 3, "skillID": 3328}, {"level": 3, "skillID": 33094}, {"level": 3, "skillID": 3329}, {"level": 3, "skillID": 3429}, {"level": 2, "skillID": 3300}, {"level": 2, "skillID": 3413}, {"level": 1, "skillID": 3303}, {"level": 1, "skillID": 3424}, {"level": 1, "skillID": 3394}, {"level": 1, "skillID": 3402}, {"level": 1, "skillID": 3318}, {"level": 1, "skillID": 3450}, {"level": 1, "skillID": 3392}, {"level": 1, "skillID": 3449}, {"level": 1, "skillID": 3393}, {"level": 1, "skillID": 72103}]}
36	256	{"_key": 256, "typeID": 72170, "skillLevels": [{"level": 3, "skillID": 3335}, {"level": 3, "skillID": 3334}, {"level": 3, "skillID": 3332}, {"level": 3, "skillID": 3333}, {"level": 3, "skillID": 3394}, {"level": 3, "skillID": 3426}, {"level": 3, "skillID": 3437}, {"level": 3, "skillID": 3436}, {"level": 2, "skillID": 3424}, {"level": 2, "skillID": 3392}, {"level": 2, "skillID": 3319}, {"level": 1, "skillID": 65570}, {"level": 2, "skillID": 3327}, {"level": 1, "skillID": 3321}, {"level": 1, "skillID": 33699}, {"level": 1, "skillID": 19921}]}
37	257	{"_key": 257, "typeID": 73833, "skillLevels": [{"level": 5, "skillID": 3332}, {"level": 5, "skillID": 33093}, {"level": 5, "skillID": 3328}, {"level": 5, "skillID": 3327}]}
38	258	{"_key": 258, "typeID": 73834, "skillLevels": [{"level": 5, "skillID": 3301}, {"level": 5, "skillID": 3304}, {"level": 5, "skillID": 12211}, {"level": 5, "skillID": 3312}, {"level": 3, "skillID": 3300}]}
39	259	{"_key": 259, "typeID": 73835, "skillLevels": [{"level": 5, "skillID": 3300}, {"level": 5, "skillID": 3310}, {"level": 5, "skillID": 3311}, {"level": 5, "skillID": 3316}, {"level": 5, "skillID": 3315}, {"level": 5, "skillID": 3317}]}
40	260	{"_key": 260, "typeID": 73836, "skillLevels": [{"level": 5, "skillID": 3435}, {"level": 5, "skillID": 3449}, {"level": 5, "skillID": 3426}, {"level": 5, "skillID": 3429}, {"level": 5, "skillID": 32999}, {"level": 5, "skillID": 3428}, {"level": 5, "skillID": 3431}]}
41	261	{"_key": 261, "typeID": 73837, "skillLevels": [{"level": 5, "skillID": 3392}, {"level": 5, "skillID": 3393}, {"level": 5, "skillID": 3394}, {"level": 5, "skillID": 33078}, {"level": 5, "skillID": 22806}, {"level": 5, "skillID": 22807}, {"level": 5, "skillID": 22808}, {"level": 5, "skillID": 22809}]}
42	262	{"_key": 262, "typeID": 74310, "skillLevels": [{"level": 5, "skillID": 25719}, {"level": 5, "skillID": 3319}, {"level": 5, "skillID": 21071}, {"level": 5, "skillID": 20211}, {"level": 5, "skillID": 25718}, {"level": 3, "skillID": 3321}, {"level": 5, "skillID": 20312}, {"level": 5, "skillID": 12441}, {"level": 5, "skillID": 12442}, {"level": 5, "skillID": 20315}, {"level": 5, "skillID": 3324}, {"level": 5, "skillID": 20314}]}
43	263	{"_key": 263, "typeID": 74311, "skillLevels": [{"level": 5, "skillID": 3455}, {"level": 5, "skillID": 3449}, {"level": 5, "skillID": 3450}, {"level": 5, "skillID": 3451}, {"level": 5, "skillID": 3452}, {"level": 5, "skillID": 3453}, {"level": 5, "skillID": 3454}, {"level": 5, "skillID": 3327}]}
44	264	{"_key": 264, "typeID": 74312, "skillLevels": [{"level": 5, "skillID": 3424}, {"level": 5, "skillID": 3426}, {"level": 5, "skillID": 3432}, {"level": 1, "skillID": 3402}, {"level": 5, "skillID": 3413}, {"level": 5, "skillID": 3417}, {"level": 5, "skillID": 3418}]}
45	265	{"_key": 265, "typeID": 74313, "skillLevels": [{"level": 5, "skillID": 3392}, {"level": 5, "skillID": 3393}, {"level": 5, "skillID": 3394}, {"level": 5, "skillID": 33078}, {"level": 5, "skillID": 22806}, {"level": 5, "skillID": 22807}, {"level": 5, "skillID": 22808}, {"level": 5, "skillID": 22809}]}
46	266	{"_key": 266, "typeID": 74314, "skillLevels": [{"level": 5, "skillID": 33002}, {"level": 4, "skillID": 3426}, {"level": 5, "skillID": 3428}, {"level": 5, "skillID": 3429}, {"level": 5, "skillID": 3431}, {"level": 2, "skillID": 3449}, {"level": 5, "skillID": 3435}]}
47	267	{"_key": 267, "typeID": 74315, "skillLevels": [{"level": 1, "skillID": 16591}, {"level": 5, "skillID": 3424}, {"level": 1, "skillID": 3402}, {"level": 3, "skillID": 3413}, {"level": 4, "skillID": 3418}, {"level": 5, "skillID": 3318}, {"level": 2, "skillID": 3300}, {"level": 5, "skillID": 3327}, {"level": 5, "skillID": 3335}, {"level": 3, "skillID": 33091}, {"level": 3, "skillID": 3331}]}
\.


--
-- Name: skillrapidlicences skillrapidlicences_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.skillrapidlicences
    ADD CONSTRAINT skillrapidlicences_pkey PRIMARY KEY (row_no);


--
-- Name: skillrapidlicences_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX skillrapidlicences_key_idx ON sde_native.skillrapidlicences USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict dqUy4xddfHF5KHNxkBadm09JPNGAACdeWYvpbJiv3MmhVTtnincexDAFK72JqBP

