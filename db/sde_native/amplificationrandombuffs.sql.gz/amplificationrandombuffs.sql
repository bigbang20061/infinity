--
-- PostgreSQL database dump
--

\restrict KFOXVP1LSSDIB8tflggLwaibt72CO1JWUgJngqlAsinbEedhRH4s9nALExyp8wt

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: amplificationrandombuffs; Type: TABLE; Schema: sde_native; Owner: -
--

CREATE TABLE sde_native.amplificationrandombuffs (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: amplificationrandombuffs; Type: TABLE DATA; Schema: sde_native; Owner: -
--

COPY sde_native.amplificationrandombuffs (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "buffType": 3, "collectionID": 2270, "effectValueTo": 6.0, "effectValueFrom": 2.0}
1	3	{"_key": 3, "buffType": 3, "collectionID": 2272, "effectValueTo": -5.0, "effectValueFrom": -2.0}
2	4	{"_key": 4, "buffType": 4, "collectionID": 2273, "effectValueTo": 16.0, "effectValueFrom": 6.0}
3	5	{"_key": 5, "buffType": 1, "collectionID": 2274, "effectValueTo": 6.0, "effectValueFrom": 2.0}
4	6	{"_key": 6, "buffType": 2, "collectionID": 2275, "effectValueTo": 10.0, "effectValueFrom": 4.0}
5	7	{"_key": 7, "buffType": 2, "collectionID": 2276, "effectValueTo": 12.0, "effectValueFrom": 4.0}
6	8	{"_key": 8, "buffType": 5, "collectionID": 2277, "effectValueTo": 6.0, "effectValueFrom": 2.0}
7	9	{"_key": 9, "buffType": 6, "collectionID": 2278, "effectValueTo": 12.0, "effectValueFrom": 4.0}
8	12	{"_key": 12, "buffType": 26, "collectionID": 2286, "effectValueTo": 10.0, "effectValueFrom": 4.0}
9	13	{"_key": 13, "buffType": 26, "collectionID": 2287, "effectValueTo": -8.0, "effectValueFrom": -3.0}
10	14	{"_key": 14, "buffType": 26, "collectionID": 2288, "effectValueTo": -8.0, "effectValueFrom": -3.0}
11	15	{"_key": 15, "buffType": 26, "collectionID": 2286, "effectValueTo": 8.0, "effectValueFrom": 3.0}
12	16	{"_key": 16, "buffType": 26, "collectionID": 2286, "effectValueTo": 5.0, "effectValueFrom": 2.0}
13	17	{"_key": 17, "buffType": 26, "collectionID": 2286, "effectValueTo": 8.0, "effectValueFrom": 3.0}
14	18	{"_key": 18, "buffType": 26, "collectionID": 2286, "effectValueTo": 5.0, "effectValueFrom": 2.0}
15	19	{"_key": 19, "buffType": 1, "collectionID": 2289, "effectValueTo": -5.0, "effectValueFrom": -2.0}
16	20	{"_key": 20, "buffType": 2, "collectionID": 2290, "effectValueTo": 10.0, "effectValueFrom": 4.0}
17	21	{"_key": 21, "buffType": 2, "collectionID": 2291, "effectValueTo": -8.0, "effectValueFrom": -3.0}
18	22	{"_key": 22, "buffType": 2, "collectionID": 2292, "effectValueTo": -20.0, "effectValueFrom": -8.0}
19	23	{"_key": 23, "buffType": 4, "collectionID": 2293, "effectValueTo": 10.0, "effectValueFrom": 4.0}
20	24	{"_key": 24, "buffType": 4, "collectionID": 2294, "effectValueTo": 16.0, "effectValueFrom": 6.0}
21	25	{"_key": 25, "buffType": 4, "collectionID": 2295, "effectValueTo": -20.0, "effectValueFrom": -8.0}
22	26	{"_key": 26, "buffType": 6, "collectionID": 2296, "effectValueTo": 20.0, "effectValueFrom": 8.0}
23	27	{"_key": 27, "buffType": 7, "collectionID": 2297, "effectValueTo": -10.0, "effectValueFrom": -4.0}
24	28	{"_key": 28, "buffType": 7, "collectionID": 2298, "effectValueTo": 12.0, "effectValueFrom": 4.0}
25	29	{"_key": 29, "buffType": 8, "collectionID": 2299, "effectValueTo": 10.0, "effectValueFrom": 4.0}
26	30	{"_key": 30, "buffType": 9, "collectionID": 2300, "effectValueTo": 10.0, "effectValueFrom": 4.0}
27	31	{"_key": 31, "buffType": 9, "collectionID": 2301, "effectValueTo": -9.0, "effectValueFrom": -3.0}
28	32	{"_key": 32, "buffType": 9, "collectionID": 2302, "effectValueTo": -20.0, "effectValueFrom": -8.0}
29	33	{"_key": 33, "buffType": 8, "collectionID": 2303, "effectValueTo": -15.0, "effectValueFrom": -6.0}
30	34	{"_key": 34, "buffType": 8, "collectionID": 2304, "effectValueTo": -15.0, "effectValueFrom": -6.0}
31	35	{"_key": 35, "buffType": 8, "collectionID": 2305, "effectValueTo": -15.0, "effectValueFrom": -6.0}
32	36	{"_key": 36, "buffType": 8, "collectionID": 2306, "effectValueTo": -15.0, "effectValueFrom": -6.0}
33	37	{"_key": 37, "buffType": 8, "collectionID": 2307, "effectValueTo": 16.0, "effectValueFrom": 6.0}
34	38	{"_key": 38, "buffType": 10, "collectionID": 2308, "effectValueTo": 10.0, "effectValueFrom": 4.0}
35	39	{"_key": 39, "buffType": 11, "collectionID": 2309, "effectValueTo": 10.0, "effectValueFrom": 4.0}
36	40	{"_key": 40, "buffType": 11, "collectionID": 2310, "effectValueTo": -9.0, "effectValueFrom": -3.0}
37	41	{"_key": 41, "buffType": 11, "collectionID": 2311, "effectValueTo": -20.0, "effectValueFrom": -8.0}
38	42	{"_key": 42, "buffType": 10, "collectionID": 2312, "effectValueTo": -15.0, "effectValueFrom": -6.0}
39	43	{"_key": 43, "buffType": 10, "collectionID": 2313, "effectValueTo": -15.0, "effectValueFrom": -6.0}
40	44	{"_key": 44, "buffType": 10, "collectionID": 2314, "effectValueTo": -15.0, "effectValueFrom": -6.0}
41	45	{"_key": 45, "buffType": 10, "collectionID": 2315, "effectValueTo": -15.0, "effectValueFrom": -6.0}
42	46	{"_key": 46, "buffType": 10, "collectionID": 2316, "effectValueTo": -15.0, "effectValueFrom": -6.0}
43	47	{"_key": 47, "buffType": 10, "collectionID": 2317, "effectValueTo": 18.0, "effectValueFrom": 7.0}
44	48	{"_key": 48, "buffType": 12, "collectionID": 2318, "effectValueTo": 12.0, "effectValueFrom": 4.0}
45	49	{"_key": 49, "buffType": 12, "collectionID": 2319, "effectValueTo": -10.0, "effectValueFrom": -4.0}
46	50	{"_key": 50, "buffType": 13, "collectionID": 2320, "effectValueTo": -20.0, "effectValueFrom": -8.0}
47	51	{"_key": 51, "buffType": 13, "collectionID": 2321, "effectValueTo": -20.0, "effectValueFrom": -8.0}
48	52	{"_key": 52, "buffType": 14, "collectionID": 2322, "effectValueTo": 12.0, "effectValueFrom": 4.0}
49	53	{"_key": 53, "buffType": 14, "collectionID": 2323, "effectValueTo": -8.0, "effectValueFrom": -3.0}
50	54	{"_key": 54, "buffType": 14, "collectionID": 2324, "effectValueTo": -20.0, "effectValueFrom": -8.0}
51	55	{"_key": 55, "buffType": 14, "collectionID": 2325, "effectValueTo": 20.0, "effectValueFrom": 8.0}
52	56	{"_key": 56, "buffType": 14, "collectionID": 2326, "effectValueTo": 15.0, "effectValueFrom": 6.0}
53	57	{"_key": 57, "buffType": 15, "collectionID": 2327, "effectValueTo": 12.0, "effectValueFrom": 4.0}
54	58	{"_key": 58, "buffType": 15, "collectionID": 2328, "effectValueTo": -8.0, "effectValueFrom": -3.0}
55	59	{"_key": 59, "buffType": 15, "collectionID": 2329, "effectValueTo": -20.0, "effectValueFrom": -8.0}
56	60	{"_key": 60, "buffType": 15, "collectionID": 2330, "effectValueTo": 15.0, "effectValueFrom": 6.0}
57	61	{"_key": 61, "buffType": 15, "collectionID": 2331, "effectValueTo": 20.0, "effectValueFrom": 8.0}
58	62	{"_key": 62, "buffType": 16, "collectionID": 2332, "effectValueTo": 15.0, "effectValueFrom": 6.0}
59	63	{"_key": 63, "buffType": 16, "collectionID": 2333, "effectValueTo": -8.0, "effectValueFrom": -3.0}
60	64	{"_key": 64, "buffType": 16, "collectionID": 2334, "effectValueTo": -20.0, "effectValueFrom": -8.0}
61	65	{"_key": 65, "buffType": 16, "collectionID": 2335, "effectValueTo": 15.0, "effectValueFrom": 6.0}
62	67	{"_key": 67, "buffType": 17, "collectionID": 2337, "effectValueTo": 20.0, "effectValueFrom": 8.0}
63	68	{"_key": 68, "buffType": 17, "collectionID": 2338, "effectValueTo": 20.0, "effectValueFrom": 8.0}
64	69	{"_key": 69, "buffType": 18, "collectionID": 2339, "effectValueTo": 10.0, "effectValueFrom": 4.0}
65	70	{"_key": 70, "buffType": 18, "collectionID": 2340, "effectValueTo": -10.0, "effectValueFrom": -4.0}
66	71	{"_key": 71, "buffType": 19, "collectionID": 2341, "effectValueTo": -10.0, "effectValueFrom": -4.0}
67	72	{"_key": 72, "buffType": 20, "collectionID": 2341, "effectValueTo": -8.0, "effectValueFrom": -3.0}
68	73	{"_key": 73, "buffType": 20, "collectionID": 2343, "effectValueTo": -12.0, "effectValueFrom": -4.0}
69	74	{"_key": 74, "buffType": 20, "collectionID": 2344, "effectValueTo": 15.0, "effectValueFrom": 6.0}
70	75	{"_key": 75, "buffType": 20, "collectionID": 2345, "effectValueTo": -20.0, "effectValueFrom": -8.0}
71	76	{"_key": 76, "buffType": 20, "collectionID": 2346, "effectValueTo": -20.0, "effectValueFrom": -8.0}
72	77	{"_key": 77, "buffType": 20, "collectionID": 2347, "effectValueTo": -20.0, "effectValueFrom": -8.0}
73	78	{"_key": 78, "buffType": 20, "collectionID": 2348, "effectValueTo": 9.0, "effectValueFrom": 3.0}
74	79	{"_key": 79, "buffType": 20, "collectionID": 2349, "effectValueTo": 15.0, "effectValueFrom": 6.0}
75	80	{"_key": 80, "buffType": 20, "collectionID": 2350, "effectValueTo": 15.0, "effectValueFrom": 6.0}
76	81	{"_key": 81, "buffType": 21, "collectionID": 2351, "effectValueTo": 20.0, "effectValueFrom": 8.0}
77	82	{"_key": 82, "buffType": 21, "collectionID": 2352, "effectValueTo": 20.0, "effectValueFrom": 8.0}
78	83	{"_key": 83, "buffType": 21, "collectionID": 2353, "effectValueTo": 40.0, "effectValueFrom": 16.0}
79	84	{"_key": 84, "buffType": 22, "collectionID": 2354, "effectValueTo": 10.0, "effectValueFrom": 4.0}
80	85	{"_key": 85, "buffType": 22, "collectionID": 2355, "effectValueTo": 10.0, "effectValueFrom": 4.0}
81	86	{"_key": 86, "buffType": 23, "collectionID": 2356, "effectValueTo": 15.0, "effectValueFrom": 6.0}
82	87	{"_key": 87, "buffType": 23, "collectionID": 2357, "effectValueTo": 18.0, "effectValueFrom": 7.0}
83	88	{"_key": 88, "buffType": 23, "collectionID": 2358, "effectValueTo": 18.0, "effectValueFrom": 7.0}
84	89	{"_key": 89, "buffType": 23, "collectionID": 2359, "effectValueTo": 18.0, "effectValueFrom": 7.0}
85	90	{"_key": 90, "buffType": 23, "collectionID": 2360, "effectValueTo": 18.0, "effectValueFrom": 7.0}
86	91	{"_key": 91, "buffType": 23, "collectionID": 2361, "effectValueTo": 12.0, "effectValueFrom": 4.0}
87	92	{"_key": 92, "buffType": 24, "collectionID": 2362, "effectValueTo": 10.0, "effectValueFrom": 4.0}
88	93	{"_key": 93, "buffType": 24, "collectionID": 2363, "effectValueTo": 10.0, "effectValueFrom": 4.0}
89	94	{"_key": 94, "buffType": 24, "collectionID": 2364, "effectValueTo": -15.0, "effectValueFrom": -6.0}
90	95	{"_key": 95, "buffType": 24, "collectionID": 2365, "effectValueTo": 15.0, "effectValueFrom": 6.0}
91	96	{"_key": 96, "buffType": 24, "collectionID": 2366, "effectValueTo": 20.0, "effectValueFrom": 8.0}
92	97	{"_key": 97, "buffType": 24, "collectionID": 2367, "effectValueTo": 15.0, "effectValueFrom": 6.0}
93	98	{"_key": 98, "buffType": 24, "collectionID": 2368, "effectValueTo": 20.0, "effectValueFrom": 8.0}
94	99	{"_key": 99, "buffType": 25, "collectionID": 2369, "effectValueTo": -20.0, "effectValueFrom": -8.0}
95	100	{"_key": 100, "buffType": 6, "collectionID": 2370, "effectValueTo": 10.0, "effectValueFrom": 4.0}
96	101	{"_key": 101, "buffType": 6, "collectionID": 2371, "effectValueTo": 15.0, "effectValueFrom": 6.0}
97	102	{"_key": 102, "buffType": 6, "collectionID": 2372, "effectValueTo": 15.0, "effectValueFrom": 6.0}
\.


--
-- Name: amplificationrandombuffs amplificationrandombuffs_pkey; Type: CONSTRAINT; Schema: sde_native; Owner: -
--

ALTER TABLE ONLY sde_native.amplificationrandombuffs
    ADD CONSTRAINT amplificationrandombuffs_pkey PRIMARY KEY (row_no);


--
-- Name: amplificationrandombuffs_key_idx; Type: INDEX; Schema: sde_native; Owner: -
--

CREATE INDEX amplificationrandombuffs_key_idx ON sde_native.amplificationrandombuffs USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict KFOXVP1LSSDIB8tflggLwaibt72CO1JWUgJngqlAsinbEedhRH4s9nALExyp8wt

