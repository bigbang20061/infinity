--
-- PostgreSQL database dump
--

\restrict G4A7whIsNUTZggc99T86RIOvcQFgc4c9tXhlhPXuSloYgekNhMqPGuozI4chPsb

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: sde_compat; Owner: -
--

CREATE TABLE sde_compat.categories (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: sde_compat; Owner: -
--

COPY sde_compat.categories (row_no, key, data) FROM stdin;
0	0	{"_key": 0, "name": {"en": "#System"}, "published": false}
1	1	{"_key": 1, "name": {"en": "Owner"}, "published": false}
2	2	{"_key": 2, "name": {"en": "Celestial"}, "published": true}
3	3	{"_key": 3, "name": {"en": "Station"}, "published": false}
4	4	{"_key": 4, "name": {"en": "Material"}, "published": true}
5	5	{"_key": 5, "name": {"en": "Accessories"}, "published": true}
6	6	{"_key": 6, "name": {"en": "Ship"}, "published": true}
7	7	{"_key": 7, "name": {"en": "Module"}, "published": true}
8	8	{"_key": 8, "name": {"en": "Charge"}, "published": true}
9	9	{"_key": 9, "name": {"en": "Blueprint"}, "published": true}
10	10	{"_key": 10, "name": {"en": "Trading"}, "published": false}
11	11	{"_key": 11, "name": {"en": "Entity"}, "published": false}
12	14	{"_key": 14, "name": {"en": "Bonus"}, "published": false}
13	16	{"_key": 16, "name": {"en": "Skill"}, "published": true}
14	17	{"_key": 17, "name": {"en": "Commodity"}, "published": true}
15	18	{"_key": 18, "name": {"en": "Drone"}, "published": true}
16	20	{"_key": 20, "name": {"en": "Implant"}, "published": true}
17	22	{"_key": 22, "name": {"en": "Deployable"}, "published": true}
18	23	{"_key": 23, "name": {"en": "Starbase"}, "published": false}
19	24	{"_key": 24, "name": {"en": "Reaction"}, "published": true}
20	25	{"_key": 25, "name": {"en": "Asteroid"}, "published": true}
21	26	{"_key": 26, "name": {"en": "WorldSpace"}, "published": false}
22	29	{"_key": 29, "name": {"en": "Abstract"}, "published": false}
23	30	{"_key": 30, "name": {"en": "Apparel"}, "published": true}
24	32	{"_key": 32, "name": {"en": "Subsystem"}, "published": true}
25	34	{"_key": 34, "name": {"en": "Ancient Relics"}, "published": true}
26	35	{"_key": 35, "name": {"en": "Decryptors"}, "published": true}
27	39	{"_key": 39, "name": {"en": "Infrastructure Upgrades"}, "published": true}
28	40	{"_key": 40, "name": {"en": "Sovereignty Structures"}, "published": true}
29	41	{"_key": 41, "name": {"en": "Planetary Industry"}, "published": true}
30	42	{"_key": 42, "name": {"en": "Planetary Resources"}, "published": true}
31	43	{"_key": 43, "name": {"en": "Planetary Commodities"}, "published": true}
32	46	{"_key": 46, "name": {"en": "Orbitals"}, "published": true}
33	49	{"_key": 49, "name": {"en": "Placeables"}, "published": false}
34	53	{"_key": 53, "name": {"en": "Effects"}, "published": false}
35	54	{"_key": 54, "name": {"en": "Lights"}, "published": false}
36	59	{"_key": 59, "name": {"en": "Cells"}, "published": false}
37	63	{"_key": 63, "name": {"en": "Special Edition Assets"}, "published": true}
38	65	{"_key": 65, "name": {"en": "Structure"}, "published": true}
39	66	{"_key": 66, "name": {"en": "Structure Module"}, "published": true}
40	87	{"_key": 87, "name": {"en": "Fighter"}, "published": true}
41	91	{"_key": 91, "name": {"en": "SKINs"}, "published": true}
42	2100	{"_key": 2100, "name": {"en": "Expert Systems"}, "published": true}
43	2107	{"_key": 2107, "name": {"en": "Mining"}, "published": false}
44	2113	{"_key": 2113, "name": {"en": "Refurbished Component"}, "published": true}
45	2116	{"_key": 2116, "name": {"en": "Module Refurbish Component"}, "published": true}
46	2117	{"_key": 2117, "name": {"en": "Drone Refurbish Component"}, "published": true}
47	2118	{"_key": 2118, "name": {"en": "Personalization"}, "published": true}
48	2120	{"_key": 2120, "name": {"en": "BrawlShip Entropy Module"}, "published": false}
49	2125	{"_key": 2125, "name": {"en": "Structure Skin"}, "published": true}
50	2126	{"_key": 2126, "name": {"en": "Amplification Matrix"}, "published": true}
51	2127	{"_key": 2127, "name": {"en": "Amplification Matrix Materials"}, "published": true}
52	2128	{"_key": 2128, "name": {"en": "CEVE Chest"}, "published": false}
53	2143	{"_key": 2143, "name": {"en": "Colony Resources"}, "published": true}
54	2152	{"_key": 2152, "name": {"en": "QA and Dev Groups"}, "published": false}
55	350001	{"_key": 350001, "name": {"en": "Infantry"}, "published": false}
\.


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: sde_compat; Owner: -
--

ALTER TABLE ONLY sde_compat.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (row_no);


--
-- Name: categories_key_idx; Type: INDEX; Schema: sde_compat; Owner: -
--

CREATE INDEX categories_key_idx ON sde_compat.categories USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict G4A7whIsNUTZggc99T86RIOvcQFgc4c9tXhlhPXuSloYgekNhMqPGuozI4chPsb

