--
-- PostgreSQL database dump
--

\restrict 6rUDrntDrUO7y5O9SW3HgVjRlG4I4JF5hEgSqQEqD8XleNaYxXZOOCH4tquCxBm

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: groups; Type: TABLE; Schema: sde_compat; Owner: -
--

CREATE TABLE sde_compat.groups (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: groups; Type: TABLE DATA; Schema: sde_compat; Owner: -
--

COPY sde_compat.groups (row_no, key, data) FROM stdin;
0	0	{"_key": 0, "name": {"en": "#System"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 0, "useBasePrice": false, "fittableNonSingleton": false}
1	1	{"_key": 1, "name": {"en": "Character"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 1, "useBasePrice": false, "fittableNonSingleton": false}
2	2	{"_key": 2, "name": {"en": "Corporation"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 1, "useBasePrice": false, "fittableNonSingleton": false}
3	3	{"_key": 3, "name": {"en": "Region"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
4	4	{"_key": 4, "name": {"en": "Constellation"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
5	5	{"_key": 5, "name": {"en": "Solar System"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
6	6	{"_key": 6, "name": {"en": "Sun"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
7	7	{"_key": 7, "name": {"en": "Planet"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
8	8	{"_key": 8, "name": {"en": "Moon"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
9	9	{"_key": 9, "name": {"en": "Asteroid Belt"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
10	10	{"_key": 10, "name": {"en": "Stargate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
11	11	{"_key": 11, "name": {"en": "Asteroid OLD"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
12	12	{"_key": 12, "name": {"en": "Cargo Container"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2, "useBasePrice": true, "fittableNonSingleton": false}
13	13	{"_key": 13, "name": {"en": "Ring"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
14	14	{"_key": 14, "name": {"en": "Biomass"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
15	15	{"_key": 15, "name": {"en": "Station"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 3, "useBasePrice": false, "fittableNonSingleton": false}
16	16	{"_key": 16, "name": {"en": "Station Services"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 3, "useBasePrice": false, "fittableNonSingleton": false}
17	17	{"_key": 17, "name": {"en": "Money"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 4, "useBasePrice": false, "fittableNonSingleton": false}
18	18	{"_key": 18, "name": {"en": "Mineral"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 4, "useBasePrice": true, "fittableNonSingleton": false}
19	19	{"_key": 19, "name": {"en": "Faction"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 1, "useBasePrice": false, "fittableNonSingleton": false}
20	20	{"_key": 20, "name": {"en": "Drug"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 4, "useBasePrice": false, "fittableNonSingleton": false}
21	23	{"_key": 23, "name": {"en": "Clone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 5, "useBasePrice": true, "fittableNonSingleton": false}
22	24	{"_key": 24, "name": {"en": "Voucher"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 5, "useBasePrice": false, "fittableNonSingleton": false}
23	25	{"_key": 25, "name": {"en": "Frigate"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
24	26	{"_key": 26, "name": {"en": "Cruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
25	27	{"_key": 27, "name": {"en": "Battleship"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
26	28	{"_key": 28, "name": {"en": "Hauler"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
27	29	{"_key": 29, "name": {"en": "Capsule"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
28	30	{"_key": 30, "name": {"en": "Titan"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
29	31	{"_key": 31, "name": {"en": "Shuttle"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
30	32	{"_key": 32, "name": {"en": "Alliance"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 1, "useBasePrice": false, "fittableNonSingleton": false}
31	38	{"_key": 38, "name": {"en": "Shield Extender"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
32	39	{"_key": 39, "name": {"en": "Shield Recharger"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
33	40	{"_key": 40, "name": {"en": "Shield Booster"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
34	41	{"_key": 41, "name": {"en": "Remote Shield Booster"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
35	43	{"_key": 43, "name": {"en": "Capacitor Recharger"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
36	46	{"_key": 46, "name": {"en": "Propulsion Module"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
37	47	{"_key": 47, "name": {"en": "Cargo Scanner"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
38	48	{"_key": 48, "name": {"en": "Ship Scanner"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
39	49	{"_key": 49, "name": {"en": "Mining Survey Chipset"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
40	52	{"_key": 52, "name": {"en": "Warp Scrambler"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
41	53	{"_key": 53, "name": {"en": "Energy Weapon"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
42	54	{"_key": 54, "name": {"en": "Mining Laser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
43	55	{"_key": 55, "name": {"en": "Projectile Weapon"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
44	56	{"_key": 56, "name": {"en": "Missile Launcher"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
45	57	{"_key": 57, "name": {"en": "Shield Power Relay"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
46	59	{"_key": 59, "name": {"en": "Gyrostabilizer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
47	60	{"_key": 60, "name": {"en": "Damage Control"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
48	61	{"_key": 61, "name": {"en": "Capacitor Battery"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
49	62	{"_key": 62, "name": {"en": "Armor Repair Unit"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": true, "fittableNonSingleton": false}
50	63	{"_key": 63, "name": {"en": "Hull Repair Unit"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
51	65	{"_key": 65, "name": {"en": "Stasis Web"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
52	67	{"_key": 67, "name": {"en": "Remote Capacitor Transmitter"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
53	68	{"_key": 68, "name": {"en": "Energy Nosferatu"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
54	71	{"_key": 71, "name": {"en": "Energy Neutralizer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
55	72	{"_key": 72, "name": {"en": "Smart Bomb"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
56	74	{"_key": 74, "name": {"en": "Hybrid Weapon"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
57	76	{"_key": 76, "name": {"en": "Capacitor Booster"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
58	77	{"_key": 77, "name": {"en": "Shield Hardener"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
59	78	{"_key": 78, "name": {"en": "Reinforced Bulkhead"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
60	80	{"_key": 80, "name": {"en": "Burst Jammer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
61	82	{"_key": 82, "name": {"en": "Passive Targeting System"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
62	83	{"_key": 83, "name": {"en": "Projectile Ammo"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
63	85	{"_key": 85, "name": {"en": "Hybrid Charge"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
64	86	{"_key": 86, "name": {"en": "Frequency Crystal"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
65	87	{"_key": 87, "name": {"en": "Capacitor Booster Charge"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
66	88	{"_key": 88, "name": {"en": "Defender Missiles"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
67	89	{"_key": 89, "name": {"en": "Torpedo"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
68	90	{"_key": 90, "name": {"en": "Bomb"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
69	92	{"_key": 92, "name": {"en": "Mine"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": false}
70	94	{"_key": 94, "name": {"en": "Trading"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 10, "useBasePrice": false, "fittableNonSingleton": false}
71	95	{"_key": 95, "name": {"en": "Trade Session"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 10, "useBasePrice": false, "fittableNonSingleton": false}
72	96	{"_key": 96, "name": {"en": "Automated Targeting System"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
73	97	{"_key": 97, "name": {"en": "Proximity Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 18, "useBasePrice": false, "fittableNonSingleton": false}
74	98	{"_key": 98, "name": {"en": "Armor Coating"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
75	99	{"_key": 99, "name": {"en": "Sentry Gun"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
76	100	{"_key": 100, "name": {"en": "Combat Drone"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 18, "useBasePrice": false, "fittableNonSingleton": false}
77	101	{"_key": 101, "name": {"en": "Mining Drone"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 18, "useBasePrice": false, "fittableNonSingleton": false}
78	104	{"_key": 104, "name": {"en": "Clone Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
79	105	{"_key": 105, "name": {"en": "Frigate Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
80	106	{"_key": 106, "name": {"en": "Cruiser Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
81	107	{"_key": 107, "name": {"en": "Battleship Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
82	108	{"_key": 108, "name": {"en": "Hauler Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
83	109	{"_key": 109, "name": {"en": "Capsule Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
84	110	{"_key": 110, "name": {"en": "Titan Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
85	111	{"_key": 111, "name": {"en": "Shuttle Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
86	118	{"_key": 118, "name": {"en": "Shield Extender Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
87	119	{"_key": 119, "name": {"en": "Shield Recharger Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
88	120	{"_key": 120, "name": {"en": "Shield Booster Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
89	121	{"_key": 121, "name": {"en": "Remote Shield Booster Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
90	123	{"_key": 123, "name": {"en": "Capacitor Recharger Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
91	126	{"_key": 126, "name": {"en": "Propulsion Module Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
92	127	{"_key": 127, "name": {"en": "Cargo Scanner Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
93	128	{"_key": 128, "name": {"en": "Ship Scanner Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
94	129	{"_key": 129, "name": {"en": "Mining Survey Chipset Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
95	130	{"_key": 130, "name": {"en": "ECM Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
96	131	{"_key": 131, "name": {"en": "ECCM Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
97	132	{"_key": 132, "name": {"en": "Warp Scrambler Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
98	133	{"_key": 133, "name": {"en": "Energy Weapon Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
99	134	{"_key": 134, "name": {"en": "Mining Laser Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
100	135	{"_key": 135, "name": {"en": "Projectile Weapon Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
101	136	{"_key": 136, "name": {"en": "Missile Launcher Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
102	137	{"_key": 137, "name": {"en": "Power Manager Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
103	139	{"_key": 139, "name": {"en": "Gunnery Upgrade Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
104	140	{"_key": 140, "name": {"en": "Damage Control Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
105	141	{"_key": 141, "name": {"en": "Capacitor Battery Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
106	142	{"_key": 142, "name": {"en": "Armor Repair Unit Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
107	143	{"_key": 143, "name": {"en": "Hull Repair Unit Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
108	145	{"_key": 145, "name": {"en": "Stasis Web Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
109	147	{"_key": 147, "name": {"en": "Remote Capacitor Transmitter Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
110	148	{"_key": 148, "name": {"en": "Energy Nosferatu Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
111	151	{"_key": 151, "name": {"en": "Energy Neutralizer Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
112	152	{"_key": 152, "name": {"en": "Smart Bomb Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
113	154	{"_key": 154, "name": {"en": "Hybrid Weapon Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
114	156	{"_key": 156, "name": {"en": "Capacitor Booster Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
115	157	{"_key": 157, "name": {"en": "Shield Hardener Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
116	158	{"_key": 158, "name": {"en": "Hull Mods Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
117	160	{"_key": 160, "name": {"en": "Burst Jammer Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
118	161	{"_key": 161, "name": {"en": "Passive Targeting System Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
119	162	{"_key": 162, "name": {"en": "Automated Targeting System Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
120	163	{"_key": 163, "name": {"en": "Armor Coating Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
121	165	{"_key": 165, "name": {"en": "Projectile Ammo Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
122	166	{"_key": 166, "name": {"en": "Missile Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
123	167	{"_key": 167, "name": {"en": "Hybrid Charge Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
124	168	{"_key": 168, "name": {"en": "Frequency Crystal Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
125	169	{"_key": 169, "name": {"en": "Capacitor Booster Charge Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
126	170	{"_key": 170, "name": {"en": "Defender Missile Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
127	172	{"_key": 172, "name": {"en": "Bomb Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
128	174	{"_key": 174, "name": {"en": "Mine Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
129	175	{"_key": 175, "name": {"en": "Proximity Drone Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
130	176	{"_key": 176, "name": {"en": "Combat Drone Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
131	177	{"_key": 177, "name": {"en": "Mining Drone Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
132	178	{"_key": 178, "name": {"en": "Drug Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
133	180	{"_key": 180, "name": {"en": "Protective Sentry Gun"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
134	182	{"_key": 182, "name": {"en": "Police Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
135	185	{"_key": 185, "name": {"en": "Pirate Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
136	186	{"_key": 186, "name": {"en": "Wreck"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
137	190	{"_key": 190, "name": {"en": "Bloodline Bonus"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 14, "useBasePrice": false, "fittableNonSingleton": false}
138	191	{"_key": 191, "name": {"en": "Physical Benefit"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 14, "useBasePrice": false, "fittableNonSingleton": false}
139	192	{"_key": 192, "name": {"en": "Physical Handicap"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 14, "useBasePrice": false, "fittableNonSingleton": false}
140	193	{"_key": 193, "name": {"en": "Phobia Handicap"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 14, "useBasePrice": false, "fittableNonSingleton": false}
141	194	{"_key": 194, "name": {"en": "Social Handicap"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 14, "useBasePrice": false, "fittableNonSingleton": false}
142	195	{"_key": 195, "name": {"en": "Amarr Education"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 14, "useBasePrice": false, "fittableNonSingleton": false}
143	196	{"_key": 196, "name": {"en": "Caldari Education"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 14, "useBasePrice": false, "fittableNonSingleton": false}
144	197	{"_key": 197, "name": {"en": "Gallente Education"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 14, "useBasePrice": false, "fittableNonSingleton": false}
145	198	{"_key": 198, "name": {"en": "Minmatar Education"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 14, "useBasePrice": false, "fittableNonSingleton": false}
146	199	{"_key": 199, "name": {"en": "Career Bonus"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 14, "useBasePrice": false, "fittableNonSingleton": false}
147	201	{"_key": 201, "name": {"en": "ECM"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
148	202	{"_key": 202, "name": {"en": "ECCM"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
149	203	{"_key": 203, "name": {"en": "Sensor Backup Array"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
150	205	{"_key": 205, "name": {"en": "Heat Sink"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
151	208	{"_key": 208, "name": {"en": "Sensor Dampener"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
152	209	{"_key": 209, "name": {"en": "Remote Tracking Computer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
153	210	{"_key": 210, "name": {"en": "Signal Amplifier"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
154	211	{"_key": 211, "name": {"en": "Tracking Enhancer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
155	212	{"_key": 212, "name": {"en": "Sensor Booster"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
156	213	{"_key": 213, "name": {"en": "Tracking Computer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
157	218	{"_key": 218, "name": {"en": "Heat Sink Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
158	223	{"_key": 223, "name": {"en": "Sensor Booster Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
159	224	{"_key": 224, "name": {"en": "Tracking Computer Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
160	225	{"_key": 225, "name": {"en": "Cheat Module Group"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
161	226	{"_key": 226, "name": {"en": "Large Collidable Object"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
162	227	{"_key": 227, "name": {"en": "Cloud"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
163	237	{"_key": 237, "name": {"en": "Corvette"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
164	255	{"_key": 255, "name": {"en": "Gunnery"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
165	256	{"_key": 256, "name": {"en": "Missiles"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
166	257	{"_key": 257, "name": {"en": "Spaceship Command"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
167	258	{"_key": 258, "name": {"en": "Fleet Support"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
168	266	{"_key": 266, "name": {"en": "Corporation Management"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
169	267	{"_key": 267, "name": {"en": "Obsolete Books"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
170	268	{"_key": 268, "name": {"en": "Production"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
171	269	{"_key": 269, "name": {"en": "Rigging"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
172	270	{"_key": 270, "name": {"en": "Science"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
173	272	{"_key": 272, "name": {"en": "Electronic Systems"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
174	273	{"_key": 273, "name": {"en": "Drones"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
175	274	{"_key": 274, "name": {"en": "Trade"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
176	275	{"_key": 275, "name": {"en": "Navigation"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
177	278	{"_key": 278, "name": {"en": "Social"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
178	279	{"_key": 279, "name": {"en": "LCO Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
179	280	{"_key": 280, "name": {"en": "General"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
180	281	{"_key": 281, "name": {"en": "Frozen"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
181	282	{"_key": 282, "name": {"en": "Radioactive"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
182	283	{"_key": 283, "name": {"en": "Livestock"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
183	284	{"_key": 284, "name": {"en": "Biohazard"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
184	285	{"_key": 285, "name": {"en": "CPU Enhancer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
185	286	{"_key": 286, "name": {"en": "Minor Threat"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
186	287	{"_key": 287, "name": {"en": "Rogue Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
187	288	{"_key": 288, "name": {"en": "Faction Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
188	289	{"_key": 289, "name": {"en": "Projected ECCM"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
189	290	{"_key": 290, "name": {"en": "Remote Sensor Booster"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
190	291	{"_key": 291, "name": {"en": "Weapon Disruptor"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
191	295	{"_key": 295, "name": {"en": "Shield Resistance Amplifier"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
192	296	{"_key": 296, "name": {"en": "Shield Resistance Amplifier Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
193	297	{"_key": 297, "name": {"en": "Convoy"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
194	298	{"_key": 298, "name": {"en": "Convoy Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
195	299	{"_key": 299, "name": {"en": "Repair Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 18, "useBasePrice": false, "fittableNonSingleton": false}
196	300	{"_key": 300, "name": {"en": "Cyberimplant"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": true, "fittableNonSingleton": false}
197	301	{"_key": 301, "name": {"en": "Concord Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
198	302	{"_key": 302, "name": {"en": "Magnetic Field Stabilizer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
199	303	{"_key": 303, "name": {"en": "Booster"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": false, "fittableNonSingleton": false}
200	304	{"_key": 304, "name": {"en": "DNA Mutator"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 20, "useBasePrice": false, "fittableNonSingleton": false}
201	305	{"_key": 305, "name": {"en": "Comet"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
202	306	{"_key": 306, "name": {"en": "Spawn Container"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
203	307	{"_key": 307, "name": {"en": "Construction Platform"}, "anchored": false, "published": true, "anchorable": true, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
204	308	{"_key": 308, "name": {"en": "Countermeasure Launcher"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
205	309	{"_key": 309, "name": {"en": "Autopilot"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
206	310	{"_key": 310, "name": {"en": "Beacon"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
207	311	{"_key": 311, "name": {"en": "Reprocessing Array"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
208	312	{"_key": 312, "name": {"en": "Planetary Cloud"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
209	313	{"_key": 313, "name": {"en": "Drugs"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
210	314	{"_key": 314, "name": {"en": "Miscellaneous"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
211	315	{"_key": 315, "name": {"en": "Warp Core Stabilizer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
212	316	{"_key": 316, "name": {"en": "Gang Coordinator"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
213	317	{"_key": 317, "name": {"en": "Computer Interface Node"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
214	318	{"_key": 318, "name": {"en": "Landmark"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
215	319	{"_key": 319, "name": {"en": "Large Collidable Structure"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
216	321	{"_key": 321, "name": {"en": "Shield Disruptor"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
217	323	{"_key": 323, "name": {"en": "Billboard"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
218	324	{"_key": 324, "name": {"en": "Assault Frigate"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
219	325	{"_key": 325, "name": {"en": "Remote Armor Repairer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
220	326	{"_key": 326, "name": {"en": "Energized Armor Membrane"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
221	328	{"_key": 328, "name": {"en": "Armor Hardener"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
222	329	{"_key": 329, "name": {"en": "Armor Plate"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
223	330	{"_key": 330, "name": {"en": "Cloaking Device"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
224	332	{"_key": 332, "name": {"en": "Tool"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
225	333	{"_key": 333, "name": {"en": "Datacores"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
226	334	{"_key": 334, "name": {"en": "Construction Components"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
227	335	{"_key": 335, "name": {"en": "Temporary Cloud"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
228	336	{"_key": 336, "name": {"en": "Mobile Sentry Gun"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
229	337	{"_key": 337, "name": {"en": "Mission Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
230	338	{"_key": 338, "name": {"en": "Shield Boost Amplifier"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
231	339	{"_key": 339, "name": {"en": "Auxiliary Power Core"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
232	340	{"_key": 340, "name": {"en": "Secure Cargo Container"}, "anchored": false, "published": true, "anchorable": true, "categoryID": 2, "useBasePrice": true, "fittableNonSingleton": false}
233	341	{"_key": 341, "name": {"en": "Signature Scrambling"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
234	342	{"_key": 342, "name": {"en": "Anti Warp Scrambler Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
235	343	{"_key": 343, "name": {"en": "Weapon Disruptor Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
236	344	{"_key": 344, "name": {"en": "Tracking Enhancer Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
237	345	{"_key": 345, "name": {"en": "Remote Tracking Computer Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
238	346	{"_key": 346, "name": {"en": "Co-Processor Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
239	347	{"_key": 347, "name": {"en": "Signal Amplifier Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
240	348	{"_key": 348, "name": {"en": "Armor Hardener Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
241	349	{"_key": 349, "name": {"en": "Armor Plate Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
242	350	{"_key": 350, "name": {"en": "Remote Armor Repairer Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
243	352	{"_key": 352, "name": {"en": "Auxiliary Power Core Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
244	353	{"_key": 353, "name": {"en": "QA Module"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
245	355	{"_key": 355, "name": {"en": "Refinables"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
246	356	{"_key": 356, "name": {"en": "Tool Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
247	357	{"_key": 357, "name": {"en": "DroneBayExpander"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
248	358	{"_key": 358, "name": {"en": "Heavy Assault Cruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
249	360	{"_key": 360, "name": {"en": "Shield Boost Amplifier Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
250	361	{"_key": 361, "name": {"en": "Mobile Warp Disruptor"}, "anchored": false, "published": true, "anchorable": true, "categoryID": 22, "useBasePrice": false, "fittableNonSingleton": false}
251	363	{"_key": 363, "name": {"en": "Ship Maintenance Array"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
252	364	{"_key": 364, "name": {"en": "Mobile Storage"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": false, "fittableNonSingleton": false}
253	365	{"_key": 365, "name": {"en": "Control Tower"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
254	366	{"_key": 366, "name": {"en": "Warp Gate"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
255	367	{"_key": 367, "name": {"en": "Ballistic Control System"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
256	368	{"_key": 368, "name": {"en": "Global Warp Disruptor"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
257	369	{"_key": 369, "name": {"en": "Ship Logs"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
258	370	{"_key": 370, "name": {"en": "Criminal Tags"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
259	371	{"_key": 371, "name": {"en": "Mobile Warp Disruptor Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
260	372	{"_key": 372, "name": {"en": "Advanced Autocannon Ammo"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
261	373	{"_key": 373, "name": {"en": "Advanced Railgun Charge"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
262	374	{"_key": 374, "name": {"en": "Advanced Beam Laser Crystal"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
263	375	{"_key": 375, "name": {"en": "Advanced Pulse Laser Crystal"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
264	376	{"_key": 376, "name": {"en": "Advanced Artillery Ammo"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
265	377	{"_key": 377, "name": {"en": "Advanced Blaster Charge"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
266	378	{"_key": 378, "name": {"en": "Cruise Control"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
267	379	{"_key": 379, "name": {"en": "Target Painter"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
268	380	{"_key": 380, "name": {"en": "Deep Space Transport"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
269	381	{"_key": 381, "name": {"en": "Elite Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 6, "useBasePrice": true, "fittableNonSingleton": false}
270	382	{"_key": 382, "name": {"en": "Shipping Crates"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
271	383	{"_key": 383, "name": {"en": "Destructible Sentry Gun"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
272	384	{"_key": 384, "name": {"en": "Light Missile"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
273	385	{"_key": 385, "name": {"en": "Heavy Missile"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
274	386	{"_key": 386, "name": {"en": "Cruise Missile"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
275	387	{"_key": 387, "name": {"en": "Rocket"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
276	394	{"_key": 394, "name": {"en": "Auto-Targeting Light Missile"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
277	395	{"_key": 395, "name": {"en": "Auto-Targeting Heavy Missile"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
278	396	{"_key": 396, "name": {"en": "Auto-Targeting Cruise Missile"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
279	397	{"_key": 397, "name": {"en": "Assembly Array"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
280	400	{"_key": 400, "name": {"en": "Ballistic Control System Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
281	401	{"_key": 401, "name": {"en": "Cloaking Device Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
282	404	{"_key": 404, "name": {"en": "Silo"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
283	405	{"_key": 405, "name": {"en": "Anti Cloaking Pulse"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
284	406	{"_key": 406, "name": {"en": "Smartbomb Supercharger"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
285	407	{"_key": 407, "name": {"en": "Fighter Support Unit"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
286	408	{"_key": 408, "name": {"en": "Drone Upgrade Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
287	409	{"_key": 409, "name": {"en": "Empire Insignia Drops"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
288	410	{"_key": 410, "name": {"en": "Anti Cloaking Pulse Blueprint"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
289	411	{"_key": 411, "name": {"en": "Force Field"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
290	413	{"_key": 413, "name": {"en": "Laboratory"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
291	414	{"_key": 414, "name": {"en": "Mobile Power Core"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": false, "fittableNonSingleton": false}
292	416	{"_key": 416, "name": {"en": "Moon Mining"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
293	417	{"_key": 417, "name": {"en": "Mobile Missile Sentry"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
294	418	{"_key": 418, "name": {"en": "Mobile Shield Generator"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": false, "fittableNonSingleton": false}
295	419	{"_key": 419, "name": {"en": "Combat Battlecruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
296	420	{"_key": 420, "name": {"en": "Destroyer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
297	422	{"_key": 422, "name": {"en": "Gas Isotopes"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 4, "useBasePrice": false, "fittableNonSingleton": false}
298	423	{"_key": 423, "name": {"en": "Ice Product"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 4, "useBasePrice": true, "fittableNonSingleton": false}
299	425	{"_key": 425, "name": {"en": "Orbital Assault Unit"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
300	426	{"_key": 426, "name": {"en": "Mobile Projectile Sentry"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
301	427	{"_key": 427, "name": {"en": "Moon Materials"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 4, "useBasePrice": true, "fittableNonSingleton": false}
302	428	{"_key": 428, "name": {"en": "Intermediate Materials"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 4, "useBasePrice": true, "fittableNonSingleton": false}
303	429	{"_key": 429, "name": {"en": "Composite"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 4, "useBasePrice": true, "fittableNonSingleton": false}
304	430	{"_key": 430, "name": {"en": "Mobile Laser Sentry"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
305	435	{"_key": 435, "name": {"en": "Deadspace Overseer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
306	436	{"_key": 436, "name": {"en": "Simple Reaction"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 24, "useBasePrice": true, "fittableNonSingleton": false}
307	438	{"_key": 438, "name": {"en": "Mobile Reactor"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
308	439	{"_key": 439, "name": {"en": "Electronic Warfare Battery"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
309	440	{"_key": 440, "name": {"en": "Sensor Dampening Battery"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
310	441	{"_key": 441, "name": {"en": "Stasis Webification Battery"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
311	443	{"_key": 443, "name": {"en": "Warp Scrambling Battery"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
312	444	{"_key": 444, "name": {"en": "Shield Hardening Array"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
313	445	{"_key": 445, "name": {"en": "Force Field Array"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
314	446	{"_key": 446, "name": {"en": "Customs Official"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
315	447	{"_key": 447, "name": {"en": "Construction Component Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
316	448	{"_key": 448, "name": {"en": "Audit Log Secure Container"}, "anchored": false, "published": true, "anchorable": true, "categoryID": 2, "useBasePrice": true, "fittableNonSingleton": false}
317	449	{"_key": 449, "name": {"en": "Mobile Hybrid Sentry"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
318	450	{"_key": 450, "name": {"en": "Arkonor"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
319	451	{"_key": 451, "name": {"en": "Bistot"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
320	452	{"_key": 452, "name": {"en": "Crokite"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
321	453	{"_key": 453, "name": {"en": "Dark Ochre"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
322	454	{"_key": 454, "name": {"en": "Hedbergite"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
323	455	{"_key": 455, "name": {"en": "Hemorphite"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
324	456	{"_key": 456, "name": {"en": "Jaspet"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
325	457	{"_key": 457, "name": {"en": "Kernite"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
326	458	{"_key": 458, "name": {"en": "Plagioclase"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
327	459	{"_key": 459, "name": {"en": "Pyroxeres"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
328	460	{"_key": 460, "name": {"en": "Scordite"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
329	461	{"_key": 461, "name": {"en": "Spodumain"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
330	462	{"_key": 462, "name": {"en": "Veldspar"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
331	463	{"_key": 463, "name": {"en": "Mining Barge"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
332	464	{"_key": 464, "name": {"en": "Strip Miner"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
333	465	{"_key": 465, "name": {"en": "Ice"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
334	467	{"_key": 467, "name": {"en": "Gneiss"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
335	468	{"_key": 468, "name": {"en": "Mercoxit"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
336	469	{"_key": 469, "name": {"en": "Omber"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
337	470	{"_key": 470, "name": {"en": "Unanchoring Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 18, "useBasePrice": false, "fittableNonSingleton": false}
338	471	{"_key": 471, "name": {"en": "Corporate Hangar Array"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
339	472	{"_key": 472, "name": {"en": "System Scanner"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
340	473	{"_key": 473, "name": {"en": "Tracking Array"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
341	474	{"_key": 474, "name": {"en": "Acceleration Gate Keys"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
342	475	{"_key": 475, "name": {"en": "Microwarpdrive"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
343	476	{"_key": 476, "name": {"en": "XL Torpedo"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
344	477	{"_key": 477, "name": {"en": "Mining Barge Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
345	478	{"_key": 478, "name": {"en": "System Scanner Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": false, "fittableNonSingleton": false}
346	479	{"_key": 479, "name": {"en": "Scanner Probe"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
347	480	{"_key": 480, "name": {"en": "Stealth Emitter Array"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": false, "fittableNonSingleton": false}
348	481	{"_key": 481, "name": {"en": "Scan Probe Launcher"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
349	482	{"_key": 482, "name": {"en": "Mining Crystal"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
350	483	{"_key": 483, "name": {"en": "Frequency Mining Laser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
351	484	{"_key": 484, "name": {"en": "Complex Reactions"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 24, "useBasePrice": true, "fittableNonSingleton": false}
352	485	{"_key": 485, "name": {"en": "Dreadnought"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
353	486	{"_key": 486, "name": {"en": "Scan Probe Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
354	487	{"_key": 487, "name": {"en": "Destroyer Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
355	489	{"_key": 489, "name": {"en": "Battlecruiser Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
356	490	{"_key": 490, "name": {"en": "Strip Miner Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
357	492	{"_key": 492, "name": {"en": "Survey Probe"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": true, "fittableNonSingleton": true}
358	493	{"_key": 493, "name": {"en": "Overseer Personal Effects"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
359	494	{"_key": 494, "name": {"en": "Deadspace Overseer's Structure"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
360	495	{"_key": 495, "name": {"en": "Deadspace Overseer's Sentry"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
361	496	{"_key": 496, "name": {"en": "Deadspace Overseer's Belongings"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
362	497	{"_key": 497, "name": {"en": "Fuel"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
363	498	{"_key": 498, "name": {"en": "Modifications"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
364	499	{"_key": 499, "name": {"en": "New EW Testing"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
365	500	{"_key": 500, "name": {"en": "Festival Charges"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
366	501	{"_key": 501, "name": {"en": "Festival Launcher"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
367	502	{"_key": 502, "name": {"en": "Cosmic Signature"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
368	503	{"_key": 503, "name": {"en": "Elite Hauler Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": false, "fittableNonSingleton": false}
369	504	{"_key": 504, "name": {"en": "Target Painter Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
370	505	{"_key": 505, "name": {"en": "Fake Skills"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 16, "useBasePrice": false, "fittableNonSingleton": false}
371	506	{"_key": 506, "name": {"en": "Missile Launcher Cruise"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
372	507	{"_key": 507, "name": {"en": "Missile Launcher Rocket"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
373	508	{"_key": 508, "name": {"en": "Missile Launcher Torpedo"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
374	509	{"_key": 509, "name": {"en": "Missile Launcher Light"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
375	510	{"_key": 510, "name": {"en": "Missile Launcher Heavy"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
376	511	{"_key": 511, "name": {"en": "Missile Launcher Rapid Light"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
377	512	{"_key": 512, "name": {"en": "Missile Launcher Defender"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
378	513	{"_key": 513, "name": {"en": "Freighter"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
379	514	{"_key": 514, "name": {"en": "ECM Stabilizer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
380	515	{"_key": 515, "name": {"en": "Siege Module"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
381	516	{"_key": 516, "name": {"en": "Siege Module Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
382	517	{"_key": 517, "name": {"en": "Agents in Space"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
383	518	{"_key": 518, "name": {"en": "Anti Ballistic Defense System"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
384	519	{"_key": 519, "name": {"en": "Terran Artifacts"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 25, "useBasePrice": true, "fittableNonSingleton": false}
385	520	{"_key": 520, "name": {"en": "Storyline Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
386	521	{"_key": 521, "name": {"en": "Identification"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
387	522	{"_key": 522, "name": {"en": "Storyline Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
388	523	{"_key": 523, "name": {"en": "Storyline Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
389	524	{"_key": 524, "name": {"en": "Missile Launcher XL Torpedo"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
390	525	{"_key": 525, "name": {"en": "Freighter Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
391	526	{"_key": 526, "name": {"en": "Commodities"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
392	527	{"_key": 527, "name": {"en": "Storyline Mission Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
393	528	{"_key": 528, "name": {"en": "Artifacts and Prototypes"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
394	530	{"_key": 530, "name": {"en": "Materials and Compounds"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
395	532	{"_key": 532, "name": {"en": "Gang Coordinator Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
396	533	{"_key": 533, "name": {"en": "Storyline Mission Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
397	534	{"_key": 534, "name": {"en": "Storyline Mission Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
398	535	{"_key": 535, "name": {"en": "Construction Platform Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
399	536	{"_key": 536, "name": {"en": "Structure Components"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
400	537	{"_key": 537, "name": {"en": "Dreadnought Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
401	538	{"_key": 538, "name": {"en": "Data Miners"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
402	540	{"_key": 540, "name": {"en": "Command Ship"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
403	541	{"_key": 541, "name": {"en": "Interdictor"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
404	543	{"_key": 543, "name": {"en": "Exhumer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
405	544	{"_key": 544, "name": {"en": "Energy Neutralizer Drone"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 18, "useBasePrice": false, "fittableNonSingleton": false}
406	545	{"_key": 545, "name": {"en": "Warp Scrambling Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 18, "useBasePrice": false, "fittableNonSingleton": false}
407	546	{"_key": 546, "name": {"en": "Mining Upgrade"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
408	547	{"_key": 547, "name": {"en": "Carrier"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
409	548	{"_key": 548, "name": {"en": "Interdiction Probe"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
410	549	{"_key": 549, "name": {"en": "Fighter Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 18, "useBasePrice": false, "fittableNonSingleton": false}
411	550	{"_key": 550, "name": {"en": "Asteroid Angel Cartel Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
412	551	{"_key": 551, "name": {"en": "Asteroid Angel Cartel Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
413	552	{"_key": 552, "name": {"en": "Asteroid Angel Cartel Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
414	553	{"_key": 553, "name": {"en": "Asteroid Angel Cartel Officer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
415	554	{"_key": 554, "name": {"en": "Asteroid Angel Cartel Hauler"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
416	555	{"_key": 555, "name": {"en": "Asteroid Blood Raiders Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
417	556	{"_key": 556, "name": {"en": "Asteroid Blood Raiders Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
418	557	{"_key": 557, "name": {"en": "Asteroid Blood Raiders Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
419	558	{"_key": 558, "name": {"en": "Asteroid Blood Raiders Hauler"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
420	559	{"_key": 559, "name": {"en": "Asteroid Blood Raiders Officer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
421	560	{"_key": 560, "name": {"en": "Asteroid Guristas Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
422	561	{"_key": 561, "name": {"en": "Asteroid Guristas Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
423	562	{"_key": 562, "name": {"en": "Asteroid Guristas Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
424	563	{"_key": 563, "name": {"en": "Asteroid Guristas Hauler"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
425	564	{"_key": 564, "name": {"en": "Asteroid Guristas Officer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
426	565	{"_key": 565, "name": {"en": "Asteroid Sansha's Nation Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
427	566	{"_key": 566, "name": {"en": "Asteroid Sansha's Nation Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
428	567	{"_key": 567, "name": {"en": "Asteroid Sansha's Nation Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
429	568	{"_key": 568, "name": {"en": "Asteroid Sansha's Nation Hauler"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
430	569	{"_key": 569, "name": {"en": "Asteroid Sansha's Nation Officer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
431	570	{"_key": 570, "name": {"en": "Asteroid Serpentis Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
432	571	{"_key": 571, "name": {"en": "Asteroid Serpentis Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
433	572	{"_key": 572, "name": {"en": "Asteroid Serpentis Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
434	573	{"_key": 573, "name": {"en": "Asteroid Serpentis Hauler"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
435	574	{"_key": 574, "name": {"en": "Asteroid Serpentis Officer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
436	575	{"_key": 575, "name": {"en": "Asteroid Angel Cartel Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
437	576	{"_key": 576, "name": {"en": "Asteroid Angel Cartel BattleCruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
438	577	{"_key": 577, "name": {"en": "Asteroid Blood Raiders Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
439	578	{"_key": 578, "name": {"en": "Asteroid Blood Raiders BattleCruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
440	579	{"_key": 579, "name": {"en": "Asteroid Guristas Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
441	580	{"_key": 580, "name": {"en": "Asteroid Guristas BattleCruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
442	581	{"_key": 581, "name": {"en": "Asteroid Sansha's Nation Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
443	582	{"_key": 582, "name": {"en": "Asteroid Sansha's Nation BattleCruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
444	583	{"_key": 583, "name": {"en": "Asteroid Serpentis Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
445	584	{"_key": 584, "name": {"en": "Asteroid Serpentis BattleCruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
446	585	{"_key": 585, "name": {"en": "Remote Hull Repairer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
447	586	{"_key": 586, "name": {"en": "Drone Modules"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
448	588	{"_key": 588, "name": {"en": "Super Weapon"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
449	589	{"_key": 589, "name": {"en": "Interdiction Sphere Launcher"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
450	590	{"_key": 590, "name": {"en": "Jump Portal Generator"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
451	593	{"_key": 593, "name": {"en": "Deadspace Angel Cartel BattleCruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
452	594	{"_key": 594, "name": {"en": "Deadspace Angel Cartel Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
453	595	{"_key": 595, "name": {"en": "Deadspace Angel Cartel Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
454	596	{"_key": 596, "name": {"en": "Deadspace Angel Cartel Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
455	597	{"_key": 597, "name": {"en": "Deadspace Angel Cartel Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
456	602	{"_key": 602, "name": {"en": "Deadspace Blood Raiders BattleCruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
457	603	{"_key": 603, "name": {"en": "Deadspace Blood Raiders Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
458	604	{"_key": 604, "name": {"en": "Deadspace Blood Raiders Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
459	605	{"_key": 605, "name": {"en": "Deadspace Blood Raiders Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
460	606	{"_key": 606, "name": {"en": "Deadspace Blood Raiders Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
461	611	{"_key": 611, "name": {"en": "Deadspace Guristas BattleCruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
462	612	{"_key": 612, "name": {"en": "Deadspace Guristas Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
463	613	{"_key": 613, "name": {"en": "Deadspace Guristas Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
464	614	{"_key": 614, "name": {"en": "Deadspace Guristas Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
465	615	{"_key": 615, "name": {"en": "Deadspace Guristas Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
466	620	{"_key": 620, "name": {"en": "Deadspace Sansha's Nation BattleCruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
467	621	{"_key": 621, "name": {"en": "Deadspace Sansha's Nation Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
468	622	{"_key": 622, "name": {"en": "Deadspace Sansha's Nation Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
469	623	{"_key": 623, "name": {"en": "Deadspace Sansha's Nation Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
470	624	{"_key": 624, "name": {"en": "Deadspace Sansha's Nation Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
471	629	{"_key": 629, "name": {"en": "Deadspace Serpentis BattleCruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
472	630	{"_key": 630, "name": {"en": "Deadspace Serpentis Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
473	631	{"_key": 631, "name": {"en": "Deadspace Serpentis Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
474	632	{"_key": 632, "name": {"en": "Deadspace Serpentis Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
475	633	{"_key": 633, "name": {"en": "Deadspace Serpentis Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
476	638	{"_key": 638, "name": {"en": "Navigation Computer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
477	639	{"_key": 639, "name": {"en": "Electronic Warfare Drone"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 18, "useBasePrice": false, "fittableNonSingleton": false}
478	640	{"_key": 640, "name": {"en": "Logistic Drone"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 18, "useBasePrice": false, "fittableNonSingleton": false}
479	641	{"_key": 641, "name": {"en": "Stasis Webifying Drone"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 18, "useBasePrice": false, "fittableNonSingleton": false}
480	642	{"_key": 642, "name": {"en": "Super Gang Enhancer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
481	643	{"_key": 643, "name": {"en": "Carrier Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
482	644	{"_key": 644, "name": {"en": "Drone Navigation Computer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
483	645	{"_key": 645, "name": {"en": "Drone Damage Modules"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
484	646	{"_key": 646, "name": {"en": "Drone Tracking Modules"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
485	647	{"_key": 647, "name": {"en": "Drone Control Range Module"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
486	648	{"_key": 648, "name": {"en": "Advanced Rocket"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
487	649	{"_key": 649, "name": {"en": "Freight Container"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2, "useBasePrice": true, "fittableNonSingleton": false}
488	650	{"_key": 650, "name": {"en": "Tractor Beam"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
489	651	{"_key": 651, "name": {"en": "Super Weapon Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
490	652	{"_key": 652, "name": {"en": "Lease"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
491	653	{"_key": 653, "name": {"en": "Advanced Light Missile"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
492	654	{"_key": 654, "name": {"en": "Advanced Heavy Assault Missile"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
493	655	{"_key": 655, "name": {"en": "Advanced Heavy Missile"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
494	656	{"_key": 656, "name": {"en": "Advanced Cruise Missile"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
495	657	{"_key": 657, "name": {"en": "Advanced Torpedo"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
496	658	{"_key": 658, "name": {"en": "Cynosural Field Generator"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
497	659	{"_key": 659, "name": {"en": "Supercarrier"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
498	660	{"_key": 660, "name": {"en": "Energy Vampire Slayer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
499	661	{"_key": 661, "name": {"en": "Simple Biochemical Reactions"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 24, "useBasePrice": false, "fittableNonSingleton": false}
500	662	{"_key": 662, "name": {"en": "Complex Biochemical Reactions"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 24, "useBasePrice": false, "fittableNonSingleton": false}
501	663	{"_key": 663, "name": {"en": "Mercoxit Mining Crystal"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
502	665	{"_key": 665, "name": {"en": "Mission Amarr Empire Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
503	666	{"_key": 666, "name": {"en": "Mission Amarr Empire Battlecruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
504	667	{"_key": 667, "name": {"en": "Mission Amarr Empire Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
505	668	{"_key": 668, "name": {"en": "Mission Amarr Empire Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
506	669	{"_key": 669, "name": {"en": "Mission Amarr Empire Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
507	670	{"_key": 670, "name": {"en": "Mission Amarr Empire Other"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
508	671	{"_key": 671, "name": {"en": "Mission Caldari State Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
509	672	{"_key": 672, "name": {"en": "Mission Caldari State Battlecruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
510	673	{"_key": 673, "name": {"en": "Mission Caldari State Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
511	674	{"_key": 674, "name": {"en": "Mission Caldari State Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
512	675	{"_key": 675, "name": {"en": "Mission Caldari State Other"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
513	676	{"_key": 676, "name": {"en": "Mission Caldari State Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
514	677	{"_key": 677, "name": {"en": "Mission Gallente Federation Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
515	678	{"_key": 678, "name": {"en": "Mission Gallente Federation Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
516	679	{"_key": 679, "name": {"en": "Mission Gallente Federation Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
517	680	{"_key": 680, "name": {"en": "Mission Gallente Federation Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
518	681	{"_key": 681, "name": {"en": "Mission Gallente Federation Battlecruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
519	682	{"_key": 682, "name": {"en": "Mission Gallente Federation Other"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
520	683	{"_key": 683, "name": {"en": "Mission Minmatar Republic Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
521	684	{"_key": 684, "name": {"en": "Mission Minmatar Republic Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
522	685	{"_key": 685, "name": {"en": "Mission Minmatar Republic Battlecruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
523	686	{"_key": 686, "name": {"en": "Mission Minmatar Republic Other"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
524	687	{"_key": 687, "name": {"en": "Mission Khanid Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
525	688	{"_key": 688, "name": {"en": "Mission Khanid Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
526	689	{"_key": 689, "name": {"en": "Mission Khanid Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
527	690	{"_key": 690, "name": {"en": "Mission Khanid Battlecruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
528	691	{"_key": 691, "name": {"en": "Mission Khanid Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
529	692	{"_key": 692, "name": {"en": "Mission Khanid Other"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
530	693	{"_key": 693, "name": {"en": "Mission CONCORD Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
531	694	{"_key": 694, "name": {"en": "Mission CONCORD Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
532	695	{"_key": 695, "name": {"en": "Mission CONCORD Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
533	696	{"_key": 696, "name": {"en": "Mission CONCORD Battlecruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
534	697	{"_key": 697, "name": {"en": "Mission CONCORD Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
535	698	{"_key": 698, "name": {"en": "Mission CONCORD Other"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
536	699	{"_key": 699, "name": {"en": "Mission Mordu Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
537	700	{"_key": 700, "name": {"en": "Mission Mordu Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
538	701	{"_key": 701, "name": {"en": "Mission Mordu Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
539	702	{"_key": 702, "name": {"en": "Mission Mordu Battlecruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
540	703	{"_key": 703, "name": {"en": "Mission Mordu Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
541	704	{"_key": 704, "name": {"en": "Mission Mordu Other"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
542	705	{"_key": 705, "name": {"en": "Mission Minmatar Republic Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
543	706	{"_key": 706, "name": {"en": "Mission Minmatar Republic Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
544	707	{"_key": 707, "name": {"en": "Jump Portal Array"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
545	709	{"_key": 709, "name": {"en": "Scanner Array"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
546	710	{"_key": 710, "name": {"en": "Logistics Array"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
547	711	{"_key": 711, "name": {"en": "Harvestable Cloud"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
548	712	{"_key": 712, "name": {"en": "Biochemical Material"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 4, "useBasePrice": false, "fittableNonSingleton": false}
549	715	{"_key": 715, "name": {"en": "Destructible Agents In Space"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
550	716	{"_key": 716, "name": {"en": "Data Interfaces"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
551	718	{"_key": 718, "name": {"en": "Booster Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": false, "fittableNonSingleton": false}
552	721	{"_key": 721, "name": {"en": "Temp"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 20, "useBasePrice": false, "fittableNonSingleton": false}
553	722	{"_key": 722, "name": {"en": "Advanced Hybrid Charge Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
554	723	{"_key": 723, "name": {"en": "Tractor Beam Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
555	724	{"_key": 724, "name": {"en": "Implant Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
556	725	{"_key": 725, "name": {"en": "Advanced Projectile Ammo Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
557	726	{"_key": 726, "name": {"en": "Advanced Frequency Crystal Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
558	727	{"_key": 727, "name": {"en": "Mining Crystal Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
559	728	{"_key": 728, "name": {"en": "Decryptors - Amarr"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 35, "useBasePrice": false, "fittableNonSingleton": false}
560	729	{"_key": 729, "name": {"en": "Decryptors - Minmatar"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 35, "useBasePrice": false, "fittableNonSingleton": false}
561	730	{"_key": 730, "name": {"en": "Decryptors - Gallente"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 35, "useBasePrice": false, "fittableNonSingleton": false}
562	731	{"_key": 731, "name": {"en": "Decryptors - Caldari"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 35, "useBasePrice": false, "fittableNonSingleton": false}
563	732	{"_key": 732, "name": {"en": "Decryptors - Sleepers"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
564	733	{"_key": 733, "name": {"en": "Decryptors - Yan Jung"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
565	734	{"_key": 734, "name": {"en": "Decryptors - Takmahl"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
566	735	{"_key": 735, "name": {"en": "Decryptors - Talocan"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
567	737	{"_key": 737, "name": {"en": "Gas Cloud Scoops"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
568	738	{"_key": 738, "name": {"en": "Cyber Armor"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": true, "fittableNonSingleton": false}
569	739	{"_key": 739, "name": {"en": "Cyber Drones"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": true, "fittableNonSingleton": false}
570	740	{"_key": 740, "name": {"en": "Cyber Electronic Systems"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": true, "fittableNonSingleton": false}
571	741	{"_key": 741, "name": {"en": "Cyber Engineering"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": true, "fittableNonSingleton": false}
572	742	{"_key": 742, "name": {"en": "Cyber Gunnery"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": true, "fittableNonSingleton": false}
573	743	{"_key": 743, "name": {"en": "Cyber Production"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": true, "fittableNonSingleton": false}
574	744	{"_key": 744, "name": {"en": "Cyber Leadership"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": true, "fittableNonSingleton": false}
575	745	{"_key": 745, "name": {"en": "Cyber Learning"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": true, "fittableNonSingleton": false}
576	746	{"_key": 746, "name": {"en": "Cyber Missile"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": true, "fittableNonSingleton": false}
577	747	{"_key": 747, "name": {"en": "Cyber Navigation"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": true, "fittableNonSingleton": false}
578	748	{"_key": 748, "name": {"en": "Cyber Science"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": true, "fittableNonSingleton": false}
579	749	{"_key": 749, "name": {"en": "Cyber Shields"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": true, "fittableNonSingleton": false}
580	750	{"_key": 750, "name": {"en": "Cyber Social"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": true, "fittableNonSingleton": false}
581	751	{"_key": 751, "name": {"en": "Cyber Trade"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": true, "fittableNonSingleton": false}
582	753	{"_key": 753, "name": {"en": "ECM Enhancer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
583	754	{"_key": 754, "name": {"en": "Salvaged Materials"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 4, "useBasePrice": false, "fittableNonSingleton": false}
584	755	{"_key": 755, "name": {"en": "Asteroid Rogue Drone BattleCruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
585	756	{"_key": 756, "name": {"en": "Asteroid Rogue Drone Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
586	757	{"_key": 757, "name": {"en": "Asteroid Rogue Drone Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
587	758	{"_key": 758, "name": {"en": "Asteroid Rogue Drone Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
588	759	{"_key": 759, "name": {"en": "Asteroid Rogue Drone Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
589	760	{"_key": 760, "name": {"en": "Asteroid Rogue Drone Hauler"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
590	761	{"_key": 761, "name": {"en": "Asteroid Rogue Drone Swarm"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
591	762	{"_key": 762, "name": {"en": "Inertial Stabilizer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
592	763	{"_key": 763, "name": {"en": "Nanofiber Internal Structure"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
593	764	{"_key": 764, "name": {"en": "Overdrive Injector System"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
594	765	{"_key": 765, "name": {"en": "Expanded Cargohold"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
595	766	{"_key": 766, "name": {"en": "Power Diagnostic System"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
596	767	{"_key": 767, "name": {"en": "Capacitor Power Relay"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
597	768	{"_key": 768, "name": {"en": "Capacitor Flux Coil"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
598	769	{"_key": 769, "name": {"en": "Reactor Control Unit"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
599	770	{"_key": 770, "name": {"en": "Shield Flux Coil"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
600	771	{"_key": 771, "name": {"en": "Missile Launcher Heavy Assault"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
601	772	{"_key": 772, "name": {"en": "Heavy Assault Missile"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
602	773	{"_key": 773, "name": {"en": "Rig Armor"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
603	774	{"_key": 774, "name": {"en": "Rig Shield"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
604	775	{"_key": 775, "name": {"en": "Rig Energy Weapon"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
605	776	{"_key": 776, "name": {"en": "Rig Hybrid Weapon"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
606	777	{"_key": 777, "name": {"en": "Rig Projectile Weapon"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
607	778	{"_key": 778, "name": {"en": "Rig Drones"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
608	779	{"_key": 779, "name": {"en": "Rig Launcher"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
609	781	{"_key": 781, "name": {"en": "Rig Core"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
610	782	{"_key": 782, "name": {"en": "Rig Navigation"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
611	783	{"_key": 783, "name": {"en": "Cyber X Specials"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": true, "fittableNonSingleton": false}
612	784	{"_key": 784, "name": {"en": "Large Collidable Ship"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
613	786	{"_key": 786, "name": {"en": "Rig Electronic Systems"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
614	787	{"_key": 787, "name": {"en": "Rig Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
615	789	{"_key": 789, "name": {"en": "Asteroid Angel Cartel Commander Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
616	790	{"_key": 790, "name": {"en": "Asteroid Angel Cartel Commander Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
617	791	{"_key": 791, "name": {"en": "Asteroid Blood Raiders Commander Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
618	792	{"_key": 792, "name": {"en": "Asteroid Blood Raiders Commander Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
619	793	{"_key": 793, "name": {"en": "Asteroid Angel Cartel Commander BattleCruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
620	794	{"_key": 794, "name": {"en": "Asteroid Angel Cartel Commander Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
621	795	{"_key": 795, "name": {"en": "Asteroid Blood Raiders Commander BattleCruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
622	796	{"_key": 796, "name": {"en": "Asteroid Blood Raiders Commander Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
623	797	{"_key": 797, "name": {"en": "Asteroid Guristas Commander BattleCruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
624	798	{"_key": 798, "name": {"en": "Asteroid Guristas Commander Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
625	799	{"_key": 799, "name": {"en": "Asteroid Guristas Commander Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
626	800	{"_key": 800, "name": {"en": "Asteroid Guristas Commander Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
627	801	{"_key": 801, "name": {"en": "Deadspace Rogue Drone BattleCruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
628	802	{"_key": 802, "name": {"en": "Deadspace Rogue Drone Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
629	803	{"_key": 803, "name": {"en": "Deadspace Rogue Drone Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
630	804	{"_key": 804, "name": {"en": "Deadspace Rogue Drone Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
631	805	{"_key": 805, "name": {"en": "Deadspace Rogue Drone Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
632	806	{"_key": 806, "name": {"en": "Deadspace Rogue Drone Swarm"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
633	807	{"_key": 807, "name": {"en": "Asteroid Sansha's Nation Commander BattleCruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
634	808	{"_key": 808, "name": {"en": "Asteroid Sansha's Nation Commander Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
635	809	{"_key": 809, "name": {"en": "Asteroid Sansha's Nation Commander Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
636	810	{"_key": 810, "name": {"en": "Asteroid Sansha's Nation Commander Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
637	811	{"_key": 811, "name": {"en": "Asteroid Serpentis Commander BattleCruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
638	812	{"_key": 812, "name": {"en": "Asteroid Serpentis Commander Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
639	813	{"_key": 813, "name": {"en": "Asteroid Serpentis Commander Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
640	814	{"_key": 814, "name": {"en": "Asteroid Serpentis Commander Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
641	815	{"_key": 815, "name": {"en": "Clone Vat Bay"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
642	816	{"_key": 816, "name": {"en": "Mission Generic Battleships"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
643	817	{"_key": 817, "name": {"en": "Mission Generic Cruisers"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
644	818	{"_key": 818, "name": {"en": "Mission Generic Frigates"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
645	819	{"_key": 819, "name": {"en": "Deadspace Overseer Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
646	820	{"_key": 820, "name": {"en": "Deadspace Overseer Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
647	821	{"_key": 821, "name": {"en": "Deadspace Overseer Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
648	822	{"_key": 822, "name": {"en": "Mission Thukker Battlecruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
649	823	{"_key": 823, "name": {"en": "Mission Thukker Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
650	824	{"_key": 824, "name": {"en": "Mission Thukker Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
651	825	{"_key": 825, "name": {"en": "Mission Thukker Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
652	826	{"_key": 826, "name": {"en": "Mission Thukker Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
653	827	{"_key": 827, "name": {"en": "Mission Thukker Other"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
654	828	{"_key": 828, "name": {"en": "Mission Generic Battle Cruisers"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
655	829	{"_key": 829, "name": {"en": "Mission Generic Destroyers"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
656	830	{"_key": 830, "name": {"en": "Covert Ops"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
657	831	{"_key": 831, "name": {"en": "Interceptor"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
658	832	{"_key": 832, "name": {"en": "Logistics"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
659	833	{"_key": 833, "name": {"en": "Force Recon Ship"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
660	834	{"_key": 834, "name": {"en": "Stealth Bomber"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
661	835	{"_key": 835, "name": {"en": "Station Upgrade Platform"}, "anchored": false, "published": true, "anchorable": true, "categoryID": 2, "useBasePrice": true, "fittableNonSingleton": false}
662	836	{"_key": 836, "name": {"en": "Station Improvement Platform"}, "anchored": false, "published": true, "anchorable": true, "categoryID": 2, "useBasePrice": true, "fittableNonSingleton": false}
663	837	{"_key": 837, "name": {"en": "Energy Neutralizing Battery"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
664	838	{"_key": 838, "name": {"en": "Cynosural Generator Array"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
665	839	{"_key": 839, "name": {"en": "Cynosural System Jammer"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
666	840	{"_key": 840, "name": {"en": "Structure Repair Array"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 23, "useBasePrice": false, "fittableNonSingleton": false}
667	841	{"_key": 841, "name": {"en": "Starbase - Control Tower Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
668	842	{"_key": 842, "name": {"en": "Burst Projectors"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
669	843	{"_key": 843, "name": {"en": "Asteroid Rogue Drone Commander BattleCruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
670	844	{"_key": 844, "name": {"en": "Asteroid Rogue Drone Commander Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
671	845	{"_key": 845, "name": {"en": "Asteroid Rogue Drone Commander Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
672	846	{"_key": 846, "name": {"en": "Asteroid Rogue Drone Commander Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
673	847	{"_key": 847, "name": {"en": "Asteroid Rogue Drone Commander Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
674	848	{"_key": 848, "name": {"en": "Asteroid Angel Cartel Commander Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
675	849	{"_key": 849, "name": {"en": "Asteroid Blood Raiders Commander Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
676	850	{"_key": 850, "name": {"en": "Asteroid Guristas Commander Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
677	851	{"_key": 851, "name": {"en": "Asteroid Sansha's Nation Commander Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
678	852	{"_key": 852, "name": {"en": "Asteroid Serpentis Commander Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
679	853	{"_key": 853, "name": {"en": "Starbase - Laser Battery Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
680	854	{"_key": 854, "name": {"en": "Starbase - Projectile Battery Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
681	855	{"_key": 855, "name": {"en": "Starbase - Hybrid Battery Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
682	856	{"_key": 856, "name": {"en": "Starbase - ECM Jamming Array Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
683	857	{"_key": 857, "name": {"en": "Starbase - Warp Scrambling Battery Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
684	858	{"_key": 858, "name": {"en": "Starbase - Stasis Webification Battery Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
685	859	{"_key": 859, "name": {"en": "Starbase - Sensor Dampening Array Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
686	860	{"_key": 860, "name": {"en": "Starbase - Energy Neutralizing Battery Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
687	861	{"_key": 861, "name": {"en": "Mission Fighter Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
688	862	{"_key": 862, "name": {"en": "Missile Launcher Bomb"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
689	863	{"_key": 863, "name": {"en": "Bomb ECM"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
690	864	{"_key": 864, "name": {"en": "Bomb Energy"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
691	865	{"_key": 865, "name": {"en": "Mission Amarr Empire Carrier"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
692	866	{"_key": 866, "name": {"en": "Mission Caldari State Carrier"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
693	867	{"_key": 867, "name": {"en": "Mission Gallente Federation Carrier"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
694	868	{"_key": 868, "name": {"en": "Mission Minmatar Republic Carrier"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
695	870	{"_key": 870, "name": {"en": "Remote Hull Repairer Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
696	871	{"_key": 871, "name": {"en": "Starbase - Missile Battery Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
697	872	{"_key": 872, "name": {"en": "Outpost Improvements"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 5, "useBasePrice": true, "fittableNonSingleton": false}
698	873	{"_key": 873, "name": {"en": "Capital Construction Components"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
699	874	{"_key": 874, "name": {"en": "Disruptable Station Services"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
700	875	{"_key": 875, "name": {"en": "Mission Faction Transports"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
701	876	{"_key": 876, "name": {"en": "Outpost Upgrades"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 5, "useBasePrice": false, "fittableNonSingleton": false}
702	877	{"_key": 877, "name": {"en": "Target Painting Battery"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 23, "useBasePrice": false, "fittableNonSingleton": false}
703	878	{"_key": 878, "name": {"en": "Cloak Enhancements"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
704	879	{"_key": 879, "name": {"en": "Slave Reception"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
705	880	{"_key": 880, "name": {"en": "Sleeper Components"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
706	881	{"_key": 881, "name": {"en": "Freedom Programs"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 24, "useBasePrice": false, "fittableNonSingleton": false}
707	882	{"_key": 882, "name": {"en": "Enslavement Programs"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 24, "useBasePrice": false, "fittableNonSingleton": false}
708	883	{"_key": 883, "name": {"en": "Capital Industrial Ship"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
709	884	{"_key": 884, "name": {"en": "Test Compressed Ore"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
710	885	{"_key": 885, "name": {"en": "Cosmic Anomaly"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
711	886	{"_key": 886, "name": {"en": "Rogue Drone Components"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 4, "useBasePrice": false, "fittableNonSingleton": false}
712	888	{"_key": 888, "name": {"en": "Ore Compression Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
713	889	{"_key": 889, "name": {"en": "Ore Enhancement Blueprints"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 9, "useBasePrice": false, "fittableNonSingleton": false}
714	890	{"_key": 890, "name": {"en": "Ice Compression Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
715	891	{"_key": 891, "name": {"en": "Starbase - Mobile Laboratory Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
716	892	{"_key": 892, "name": {"en": "Planet Satellites"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": false}
717	893	{"_key": 893, "name": {"en": "Electronic Attack Ship"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
718	894	{"_key": 894, "name": {"en": "Heavy Interdiction Cruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
719	896	{"_key": 896, "name": {"en": "Rig Security Transponder"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
720	897	{"_key": 897, "name": {"en": "Covert Cynosural Field"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
721	898	{"_key": 898, "name": {"en": "Black Ops"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
722	899	{"_key": 899, "name": {"en": "Warp Disrupt Field Generator"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
723	900	{"_key": 900, "name": {"en": "Marauder"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
724	901	{"_key": 901, "name": {"en": "Mining Enhancer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
725	902	{"_key": 902, "name": {"en": "Jump Freighter"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
726	903	{"_key": 903, "name": {"en": "Ancient Compressed Ice"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
727	904	{"_key": 904, "name": {"en": "Rig Mining"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
728	905	{"_key": 905, "name": {"en": "Covert Cynosural Field Generator"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
729	906	{"_key": 906, "name": {"en": "Combat Recon Ship"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
730	907	{"_key": 907, "name": {"en": "Tracking Script"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
731	908	{"_key": 908, "name": {"en": "Warp Disruption Script"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
732	909	{"_key": 909, "name": {"en": "Tracking Disruption Script"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
733	910	{"_key": 910, "name": {"en": "Sensor Booster Script"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
734	911	{"_key": 911, "name": {"en": "Sensor Dampener Script"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
735	912	{"_key": 912, "name": {"en": "Script Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
736	913	{"_key": 913, "name": {"en": "Advanced Capital Construction Components"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
737	914	{"_key": 914, "name": {"en": "Advanced Capital Construction Component Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
738	915	{"_key": 915, "name": {"en": "Capital Construction Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
739	916	{"_key": 916, "name": {"en": "Nanite Repair Paste"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": true, "fittableNonSingleton": true}
740	917	{"_key": 917, "name": {"en": "Data Miner Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
741	918	{"_key": 918, "name": {"en": "Scan Probe Launcher Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
742	920	{"_key": 920, "name": {"en": "Effect Beacon"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
743	922	{"_key": 922, "name": {"en": "Capture Point"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
744	924	{"_key": 924, "name": {"en": "Mission Faction Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
745	925	{"_key": 925, "name": {"en": "FW Infrastructure Hub"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
746	927	{"_key": 927, "name": {"en": "Mission Faction Haulers"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
747	934	{"_key": 934, "name": {"en": "Zombie Entities"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
748	935	{"_key": 935, "name": {"en": "WorldSpace"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 26, "useBasePrice": false, "fittableNonSingleton": false}
749	937	{"_key": 937, "name": {"en": "Decorations"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 29, "useBasePrice": false, "fittableNonSingleton": false}
750	940	{"_key": 940, "name": {"en": "Furniture"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 49, "useBasePrice": false, "fittableNonSingleton": false}
751	941	{"_key": 941, "name": {"en": "Industrial Command Ship"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
752	943	{"_key": 943, "name": {"en": "Legacy Currency"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 5, "useBasePrice": false, "fittableNonSingleton": false}
753	944	{"_key": 944, "name": {"en": "Capital Industrial Ship Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
754	945	{"_key": 945, "name": {"en": "Industrial Command Ship Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
755	952	{"_key": 952, "name": {"en": "Mission Container"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
756	954	{"_key": 954, "name": {"en": "Defensive Subsystem"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 32, "useBasePrice": false, "fittableNonSingleton": false}
757	955	{"_key": 955, "name": {"en": "Depricated Subsystems"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
758	956	{"_key": 956, "name": {"en": "Offensive Subsystem"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 32, "useBasePrice": false, "fittableNonSingleton": false}
759	957	{"_key": 957, "name": {"en": "Propulsion Subsystem"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 32, "useBasePrice": false, "fittableNonSingleton": false}
760	958	{"_key": 958, "name": {"en": "Core Subsystem"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 32, "useBasePrice": false, "fittableNonSingleton": false}
761	959	{"_key": 959, "name": {"en": "Deadspace Sleeper Sleepless Sentinel"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
762	960	{"_key": 960, "name": {"en": "Deadspace Sleeper Awakened Sentinel"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
763	961	{"_key": 961, "name": {"en": "Deadspace Sleeper Emergent Sentinel"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
764	963	{"_key": 963, "name": {"en": "Strategic Cruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
765	964	{"_key": 964, "name": {"en": "Hybrid Tech Components"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
766	965	{"_key": 965, "name": {"en": "Hybrid Component Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
767	966	{"_key": 966, "name": {"en": "Ancient Salvage"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 4, "useBasePrice": false, "fittableNonSingleton": false}
768	967	{"_key": 967, "name": {"en": "Wormhole Minerals"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 4, "useBasePrice": false, "fittableNonSingleton": false}
769	971	{"_key": 971, "name": {"en": "Sleeper Propulsion Relics"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 34, "useBasePrice": false, "fittableNonSingleton": false}
770	972	{"_key": 972, "name": {"en": "Obsolete Probes"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
771	973	{"_key": 973, "name": {"en": "Subsystem Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": false, "fittableNonSingleton": false}
772	974	{"_key": 974, "name": {"en": "Hybrid Polymers"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 4, "useBasePrice": false, "fittableNonSingleton": false}
773	976	{"_key": 976, "name": {"en": "Festival Charges Expired"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 63, "useBasePrice": false, "fittableNonSingleton": false}
774	977	{"_key": 977, "name": {"en": "Hybrid Reactions"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 24, "useBasePrice": true, "fittableNonSingleton": false}
775	979	{"_key": 979, "name": {"en": "Decryptors - Hybrid"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 35, "useBasePrice": false, "fittableNonSingleton": false}
776	982	{"_key": 982, "name": {"en": "Deadspace Sleeper Sleepless Defender"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
777	983	{"_key": 983, "name": {"en": "Deadspace Sleeper Sleepless Patroller"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
778	984	{"_key": 984, "name": {"en": "Deadspace Sleeper Awakened Defender"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
779	985	{"_key": 985, "name": {"en": "Deadspace Sleeper Awakened Patroller"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
780	986	{"_key": 986, "name": {"en": "Deadspace Sleeper Emergent Defender"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
781	987	{"_key": 987, "name": {"en": "Deadspace Sleeper Emergent Patroller"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
782	988	{"_key": 988, "name": {"en": "Wormhole"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
783	990	{"_key": 990, "name": {"en": "Sleeper Electronics Relics"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 34, "useBasePrice": false, "fittableNonSingleton": false}
784	991	{"_key": 991, "name": {"en": "Sleeper Offensive Relics"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 34, "useBasePrice": false, "fittableNonSingleton": false}
785	992	{"_key": 992, "name": {"en": "Sleeper Engineering Relics"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 34, "useBasePrice": false, "fittableNonSingleton": false}
786	993	{"_key": 993, "name": {"en": "Sleeper Defensive Relics"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 34, "useBasePrice": false, "fittableNonSingleton": false}
787	995	{"_key": 995, "name": {"en": "Secondary Sun"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
788	996	{"_key": 996, "name": {"en": "Strategic Cruiser Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": false, "fittableNonSingleton": false}
789	997	{"_key": 997, "name": {"en": "Sleeper Hull Relics"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 34, "useBasePrice": false, "fittableNonSingleton": false}
790	1003	{"_key": 1003, "name": {"en": "Territorial Claim Unit"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 40, "useBasePrice": true, "fittableNonSingleton": false}
791	1004	{"_key": 1004, "name": {"en": "Defense Bunkers"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 40, "useBasePrice": false, "fittableNonSingleton": false}
792	1005	{"_key": 1005, "name": {"en": "Sovereignty Blockade Unit"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 40, "useBasePrice": true, "fittableNonSingleton": false}
793	1006	{"_key": 1006, "name": {"en": "Mission Faction Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
794	1007	{"_key": 1007, "name": {"en": "Mission Faction Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
795	1010	{"_key": 1010, "name": {"en": "Compact XL Torpedo"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
796	1012	{"_key": 1012, "name": {"en": "Sovereignty Hub"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 40, "useBasePrice": true, "fittableNonSingleton": false}
797	1013	{"_key": 1013, "name": {"en": "Supercarrier Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
798	1016	{"_key": 1016, "name": {"en": "Infrastructure Hub Strategic Upgrades"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 39, "useBasePrice": true, "fittableNonSingleton": false}
799	1019	{"_key": 1019, "name": {"en": "XL Cruise Missile"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
800	1020	{"_key": 1020, "name": {"en": "Infrastructure Hub Industrial Upgrades"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 39, "useBasePrice": true, "fittableNonSingleton": false}
801	1021	{"_key": 1021, "name": {"en": "Infrastructure Hub Military Upgrades"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 39, "useBasePrice": true, "fittableNonSingleton": false}
802	1022	{"_key": 1022, "name": {"en": "Prototype Exploration Ship"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
803	1023	{"_key": 1023, "name": {"en": "Fighter Bomber"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 18, "useBasePrice": false, "fittableNonSingleton": false}
804	1025	{"_key": 1025, "name": {"en": "Orbital Infrastructure"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 46, "useBasePrice": false, "fittableNonSingleton": false}
805	1026	{"_key": 1026, "name": {"en": "Extractors"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 41, "useBasePrice": true, "fittableNonSingleton": false}
806	1027	{"_key": 1027, "name": {"en": "Command Centers"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 41, "useBasePrice": true, "fittableNonSingleton": false}
807	1028	{"_key": 1028, "name": {"en": "Processors"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 41, "useBasePrice": true, "fittableNonSingleton": false}
808	1029	{"_key": 1029, "name": {"en": "Storage Facilities"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 41, "useBasePrice": true, "fittableNonSingleton": false}
809	1030	{"_key": 1030, "name": {"en": "Spaceports"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 41, "useBasePrice": true, "fittableNonSingleton": false}
810	1031	{"_key": 1031, "name": {"en": "Planetary Resources"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
811	1032	{"_key": 1032, "name": {"en": "Planet Solid - Raw Resource"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 42, "useBasePrice": false, "fittableNonSingleton": false}
812	1033	{"_key": 1033, "name": {"en": "Planet Liquid-Gas - Raw Resource"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 42, "useBasePrice": false, "fittableNonSingleton": false}
813	1034	{"_key": 1034, "name": {"en": "Refined Commodities - Tier 2"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 43, "useBasePrice": true, "fittableNonSingleton": false}
814	1035	{"_key": 1035, "name": {"en": "Planet Organic - Raw Resource"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 42, "useBasePrice": false, "fittableNonSingleton": false}
815	1036	{"_key": 1036, "name": {"en": "Planetary Links"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 41, "useBasePrice": true, "fittableNonSingleton": false}
816	1040	{"_key": 1040, "name": {"en": "Specialized Commodities - Tier 3"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 43, "useBasePrice": true, "fittableNonSingleton": false}
817	1041	{"_key": 1041, "name": {"en": "Advanced Commodities - Tier 4"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 43, "useBasePrice": false, "fittableNonSingleton": false}
818	1042	{"_key": 1042, "name": {"en": "Basic Commodities - Tier 1"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 43, "useBasePrice": true, "fittableNonSingleton": false}
819	1045	{"_key": 1045, "name": {"en": "Sovereignty Structure Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
820	1046	{"_key": 1046, "name": {"en": "Nanite Repair Paste Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
821	1048	{"_key": 1048, "name": {"en": "Starbase Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
822	1051	{"_key": 1051, "name": {"en": "Incursion Sansha's Nation Industrial"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
823	1052	{"_key": 1052, "name": {"en": "Incursion Sansha's Nation Capital"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
824	1053	{"_key": 1053, "name": {"en": "Incursion Sansha's Nation Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
825	1054	{"_key": 1054, "name": {"en": "Incursion Sansha's Nation Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
826	1056	{"_key": 1056, "name": {"en": "Incursion Sansha's Nation Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
827	1063	{"_key": 1063, "name": {"en": "Extractor Control Units"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 41, "useBasePrice": true, "fittableNonSingleton": false}
828	1067	{"_key": 1067, "name": {"en": "MaterialZone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 26, "useBasePrice": false, "fittableNonSingleton": false}
829	1068	{"_key": 1068, "name": {"en": "DetailMesh"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 26, "useBasePrice": false, "fittableNonSingleton": false}
830	1071	{"_key": 1071, "name": {"en": "Flashpoint"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
831	1073	{"_key": 1073, "name": {"en": "Test Orbitals"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 46, "useBasePrice": true, "fittableNonSingleton": false}
832	1079	{"_key": 1079, "name": {"en": "Generic"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 49, "useBasePrice": false, "fittableNonSingleton": false}
833	1081	{"_key": 1081, "name": {"en": "Mercenary Bases"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 41, "useBasePrice": false, "fittableNonSingleton": false}
834	1082	{"_key": 1082, "name": {"en": "Capsuleer Bases"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 41, "useBasePrice": false, "fittableNonSingleton": false}
835	1083	{"_key": 1083, "name": {"en": "Eyewear"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 30, "useBasePrice": false, "fittableNonSingleton": false}
836	1084	{"_key": 1084, "name": {"en": "Tattoos"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 30, "useBasePrice": false, "fittableNonSingleton": false}
837	1085	{"_key": 1085, "name": {"en": "Piercings"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 30, "useBasePrice": false, "fittableNonSingleton": false}
838	1086	{"_key": 1086, "name": {"en": "Scars"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 30, "useBasePrice": false, "fittableNonSingleton": false}
839	1087	{"_key": 1087, "name": {"en": "Mid Layer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 30, "useBasePrice": false, "fittableNonSingleton": false}
840	1088	{"_key": 1088, "name": {"en": "Outer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 30, "useBasePrice": false, "fittableNonSingleton": false}
841	1089	{"_key": 1089, "name": {"en": "Tops"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 30, "useBasePrice": false, "fittableNonSingleton": false}
842	1090	{"_key": 1090, "name": {"en": "Bottoms"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 30, "useBasePrice": false, "fittableNonSingleton": false}
843	1091	{"_key": 1091, "name": {"en": "Footwear"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 30, "useBasePrice": false, "fittableNonSingleton": false}
844	1092	{"_key": 1092, "name": {"en": "Headwear"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 30, "useBasePrice": false, "fittableNonSingleton": false}
845	1093	{"_key": 1093, "name": {"en": "Makeup"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 30, "useBasePrice": false, "fittableNonSingleton": false}
846	1105	{"_key": 1105, "name": {"en": "Lens Flares"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 53, "useBasePrice": false, "fittableNonSingleton": false}
847	1106	{"_key": 1106, "name": {"en": "Orbital Construction Platform"}, "anchored": false, "published": true, "anchorable": true, "categoryID": 46, "useBasePrice": true, "fittableNonSingleton": false}
848	1107	{"_key": 1107, "name": {"en": "Particle Systems"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 53, "useBasePrice": false, "fittableNonSingleton": false}
849	1108	{"_key": 1108, "name": {"en": "Animated Lights"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 53, "useBasePrice": false, "fittableNonSingleton": false}
850	1109	{"_key": 1109, "name": {"en": "Audio"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 29, "useBasePrice": false, "fittableNonSingleton": false}
851	1110	{"_key": 1110, "name": {"en": "Point Lights"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 54, "useBasePrice": false, "fittableNonSingleton": false}
852	1111	{"_key": 1111, "name": {"en": "Box Lights"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 54, "useBasePrice": false, "fittableNonSingleton": false}
853	1112	{"_key": 1112, "name": {"en": "Spot Lights"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 54, "useBasePrice": false, "fittableNonSingleton": false}
854	1118	{"_key": 1118, "name": {"en": "Surface Infrastructure Prefab Units"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
855	1121	{"_key": 1121, "name": {"en": "Perception Points"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 29, "useBasePrice": false, "fittableNonSingleton": false}
856	1122	{"_key": 1122, "name": {"en": "Salvager"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
857	1123	{"_key": 1123, "name": {"en": "Salvager Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
858	1126	{"_key": 1126, "name": {"en": "PhysicalPortals"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 59, "useBasePrice": false, "fittableNonSingleton": false}
859	1136	{"_key": 1136, "name": {"en": "Fuel Block"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 4, "useBasePrice": true, "fittableNonSingleton": false}
860	1137	{"_key": 1137, "name": {"en": "Fuel Block Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
861	1139	{"_key": 1139, "name": {"en": "Mining Laser Upgrade Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
862	1141	{"_key": 1141, "name": {"en": "Research Data"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
863	1142	{"_key": 1142, "name": {"en": "Energy Neutralizer Drone Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
864	1143	{"_key": 1143, "name": {"en": "Electronic Warfare Drone Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
865	1144	{"_key": 1144, "name": {"en": "Logistic Drone Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
866	1145	{"_key": 1145, "name": {"en": "Heavy Fighter Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
867	1146	{"_key": 1146, "name": {"en": "Light Fighter Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
868	1147	{"_key": 1147, "name": {"en": "Stasis Webifying Drone Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
869	1149	{"_key": 1149, "name": {"en": "Mobile Jump Disruptor"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 22, "useBasePrice": false, "fittableNonSingleton": false}
870	1150	{"_key": 1150, "name": {"en": "Armor Resistance Shift Hardener"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
871	1151	{"_key": 1151, "name": {"en": "Armor Resistance Shift Hardener Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
872	1152	{"_key": 1152, "name": {"en": "Drone Damage Module Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
873	1153	{"_key": 1153, "name": {"en": "Shield Booster Script"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
874	1154	{"_key": 1154, "name": {"en": "Signature Suppressor"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
875	1155	{"_key": 1155, "name": {"en": "Signature Suppressor Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
876	1156	{"_key": 1156, "name": {"en": "Ancillary Shield Booster"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
877	1157	{"_key": 1157, "name": {"en": "Fueled Shield Booster Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
878	1158	{"_key": 1158, "name": {"en": "Heavy Defender Missile"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
879	1159	{"_key": 1159, "name": {"en": "Salvage Drone"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 18, "useBasePrice": false, "fittableNonSingleton": false}
880	1160	{"_key": 1160, "name": {"en": "Survey Probe Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
881	1162	{"_key": 1162, "name": {"en": "Container Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
882	1165	{"_key": 1165, "name": {"en": "Satellite"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
883	1166	{"_key": 1166, "name": {"en": "FW Minmatar Republic Frigate"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
884	1167	{"_key": 1167, "name": {"en": "FW Caldari State Frigate"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
885	1168	{"_key": 1168, "name": {"en": "FW Gallente Federation Frigate"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
886	1169	{"_key": 1169, "name": {"en": "FW Amarr Empire Frigate"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
887	1174	{"_key": 1174, "name": {"en": "Asteroid Rogue Drone Officer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
888	1175	{"_key": 1175, "name": {"en": "FW Amarr Empire Destroyer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
889	1176	{"_key": 1176, "name": {"en": "FW Caldari State Destroyer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
890	1177	{"_key": 1177, "name": {"en": "FW Gallente Federation Destroyer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
891	1178	{"_key": 1178, "name": {"en": "FW Minmatar Republic Destroyer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
892	1179	{"_key": 1179, "name": {"en": "FW Amarr Empire Cruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
893	1180	{"_key": 1180, "name": {"en": "FW Caldari State Cruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
894	1181	{"_key": 1181, "name": {"en": "FW Gallente Federation Cruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
895	1182	{"_key": 1182, "name": {"en": "FW Minmatar Republic Cruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
896	1183	{"_key": 1183, "name": {"en": "FW Amarr Empire Battlecruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
897	1184	{"_key": 1184, "name": {"en": "FW Caldari State Battlecruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
898	1185	{"_key": 1185, "name": {"en": "FW Gallente Federation Battlecruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
899	1186	{"_key": 1186, "name": {"en": "FW Minmatar Republic Battlecruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
900	1189	{"_key": 1189, "name": {"en": "Micro Jump Drive"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": true, "fittableNonSingleton": false}
901	1190	{"_key": 1190, "name": {"en": "Salvage Drone Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
902	1191	{"_key": 1191, "name": {"en": "Micro Jump Drive Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
903	1194	{"_key": 1194, "name": {"en": "Special Edition Commodities"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 63, "useBasePrice": false, "fittableNonSingleton": false}
904	1195	{"_key": 1195, "name": {"en": "Tournament Cards: New Eden Open YC 114"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 63, "useBasePrice": false, "fittableNonSingleton": false}
905	1197	{"_key": 1197, "name": {"en": "Special Edition Commodity Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": false, "fittableNonSingleton": false}
906	1198	{"_key": 1198, "name": {"en": "Orbital Target"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
907	1199	{"_key": 1199, "name": {"en": "Ancillary Armor Repairer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
908	1200	{"_key": 1200, "name": {"en": "Fueled Armor Repairer Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": false, "fittableNonSingleton": false}
909	1201	{"_key": 1201, "name": {"en": "Attack Battlecruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
910	1202	{"_key": 1202, "name": {"en": "Blockade Runner"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
911	1206	{"_key": 1206, "name": {"en": "Security Tags"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
912	1207	{"_key": 1207, "name": {"en": "Scatter Container"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
913	1209	{"_key": 1209, "name": {"en": "Shields"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
914	1210	{"_key": 1210, "name": {"en": "Armor"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
915	1212	{"_key": 1212, "name": {"en": "Personal Hangar"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": false, "fittableNonSingleton": false}
916	1213	{"_key": 1213, "name": {"en": "Targeting"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
917	1216	{"_key": 1216, "name": {"en": "Engineering"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
918	1217	{"_key": 1217, "name": {"en": "Scanning"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
919	1218	{"_key": 1218, "name": {"en": "Resource Processing"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
920	1220	{"_key": 1220, "name": {"en": "Neural Enhancement"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
921	1222	{"_key": 1222, "name": {"en": "ECM Stabilizer Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
922	1223	{"_key": 1223, "name": {"en": "Scanning Upgrade"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
923	1224	{"_key": 1224, "name": {"en": "Scanning Upgrade Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
924	1225	{"_key": 1225, "name": {"en": "Tournament Cards: Alliance Tournament All Stars"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 63, "useBasePrice": false, "fittableNonSingleton": false}
925	1226	{"_key": 1226, "name": {"en": "Survey Probe Launcher"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
926	1227	{"_key": 1227, "name": {"en": "Survey Probe Launcher Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
927	1228	{"_key": 1228, "name": {"en": "Cyber Targeting"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": false, "fittableNonSingleton": false}
928	1229	{"_key": 1229, "name": {"en": "Cyber Resource Processing"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": false, "fittableNonSingleton": false}
929	1230	{"_key": 1230, "name": {"en": "Cyber Scanning"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": false, "fittableNonSingleton": false}
930	1231	{"_key": 1231, "name": {"en": "Cyber Biology"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": false, "fittableNonSingleton": false}
931	1232	{"_key": 1232, "name": {"en": "Rig Resource Processing"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
932	1233	{"_key": 1233, "name": {"en": "Rig Scanning"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
933	1234	{"_key": 1234, "name": {"en": "Rig Targeting"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
934	1238	{"_key": 1238, "name": {"en": "Scanning Upgrade Time"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
935	1239	{"_key": 1239, "name": {"en": "Scanning Upgrade Time Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
936	1240	{"_key": 1240, "name": {"en": "Subsystems"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
937	1241	{"_key": 1241, "name": {"en": "Planet Management"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
938	1245	{"_key": 1245, "name": {"en": "Missile Launcher Rapid Heavy"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
939	1246	{"_key": 1246, "name": {"en": "Mobile Depot"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 22, "useBasePrice": false, "fittableNonSingleton": false}
940	1247	{"_key": 1247, "name": {"en": "Mobile Siphon Unit"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 22, "useBasePrice": false, "fittableNonSingleton": false}
941	1248	{"_key": 1248, "name": {"en": "Bounty Encrypted Bonds"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
942	1249	{"_key": 1249, "name": {"en": "Mobile Cyno Inhibitor"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 22, "useBasePrice": false, "fittableNonSingleton": false}
943	1250	{"_key": 1250, "name": {"en": "Mobile Tractor Unit"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 22, "useBasePrice": false, "fittableNonSingleton": false}
944	1252	{"_key": 1252, "name": {"en": "Ghost Sites Angel Cartel Cruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
945	1255	{"_key": 1255, "name": {"en": "Ghost Sites Blood Raiders Cruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
946	1259	{"_key": 1259, "name": {"en": "Ghost Sites Guristas Cruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
947	1262	{"_key": 1262, "name": {"en": "Ghost Sites Serpentis Cruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
948	1265	{"_key": 1265, "name": {"en": "Ghost Sites Sanshas Cruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
949	1267	{"_key": 1267, "name": {"en": "Mobile Siphon Unit Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
950	1268	{"_key": 1268, "name": {"en": "Mobile Cynosural Inhibitor Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
951	1269	{"_key": 1269, "name": {"en": "Mobile Depot Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
952	1270	{"_key": 1270, "name": {"en": "Mobile Tractor Unit Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
953	1271	{"_key": 1271, "name": {"en": "Prosthetics"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 30, "useBasePrice": false, "fittableNonSingleton": false}
954	1273	{"_key": 1273, "name": {"en": "Encounter Surveillance System"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 22, "useBasePrice": true, "fittableNonSingleton": false}
955	1274	{"_key": 1274, "name": {"en": "Mobile Decoy Unit"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 22, "useBasePrice": false, "fittableNonSingleton": false}
956	1275	{"_key": 1275, "name": {"en": "Mobile Scan Inhibitor"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 22, "useBasePrice": false, "fittableNonSingleton": false}
957	1276	{"_key": 1276, "name": {"en": "Mobile Micro Jump Unit"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 22, "useBasePrice": false, "fittableNonSingleton": false}
958	1277	{"_key": 1277, "name": {"en": "Encounter Surveillance System Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
959	1282	{"_key": 1282, "name": {"en": "Compression Array"}, "anchored": false, "published": false, "anchorable": true, "categoryID": 23, "useBasePrice": true, "fittableNonSingleton": false}
960	1283	{"_key": 1283, "name": {"en": "Expedition Frigate"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
961	1285	{"_key": 1285, "name": {"en": "Asteroid Mordus Legion Commander Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
962	1286	{"_key": 1286, "name": {"en": "Asteroid Mordus Legion Commander Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
963	1287	{"_key": 1287, "name": {"en": "Asteroid Mordus Legion Commander Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
964	1288	{"_key": 1288, "name": {"en": "Ghost Sites Mordu's Legion"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
965	1289	{"_key": 1289, "name": {"en": "Warp Accelerator"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
966	1292	{"_key": 1292, "name": {"en": "Drone Tracking Enhancer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
967	1293	{"_key": 1293, "name": {"en": "Mobile Scan Inhibitor Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
968	1294	{"_key": 1294, "name": {"en": "Mobile Micro Jump Unit Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
969	1295	{"_key": 1295, "name": {"en": "Mobile Decoy Unit Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": false, "fittableNonSingleton": false}
970	1297	{"_key": 1297, "name": {"en": "Mobile Vault"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 22, "useBasePrice": false, "fittableNonSingleton": false}
971	1299	{"_key": 1299, "name": {"en": "Jump Drive Economizer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
972	1301	{"_key": 1301, "name": {"en": "Services"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 5, "useBasePrice": false, "fittableNonSingleton": false}
973	1304	{"_key": 1304, "name": {"en": "Generic Decryptor"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 35, "useBasePrice": false, "fittableNonSingleton": false}
974	1305	{"_key": 1305, "name": {"en": "Tactical Destroyer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
975	1306	{"_key": 1306, "name": {"en": "Ship Modifiers"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
976	1307	{"_key": 1307, "name": {"en": "Roaming Sleepers Cruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
977	1308	{"_key": 1308, "name": {"en": "Rig Anchor"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
978	1309	{"_key": 1309, "name": {"en": "Tactical Destroyer Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
979	1310	{"_key": 1310, "name": {"en": "Drifter Battleship"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
980	1311	{"_key": 1311, "name": {"en": "Super Kerr-Induced Nanocoatings"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 5, "useBasePrice": false, "fittableNonSingleton": false}
981	1312	{"_key": 1312, "name": {"en": "Observatory Structures"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 22, "useBasePrice": false, "fittableNonSingleton": false}
982	1313	{"_key": 1313, "name": {"en": "Entosis Link"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
983	1314	{"_key": 1314, "name": {"en": "Unknown Components"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
984	1316	{"_key": 1316, "name": {"en": "Entosis Command Node"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
985	1317	{"_key": 1317, "name": {"en": "Infrastructure Upgrade Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
986	1318	{"_key": 1318, "name": {"en": "Entosis Link Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
987	1319	{"_key": 1319, "name": {"en": "Miscellaneous"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 29, "useBasePrice": false, "fittableNonSingleton": false}
988	1321	{"_key": 1321, "name": {"en": "Structure Citadel Service Module"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
989	1322	{"_key": 1322, "name": {"en": "Structure Resource Processing Service Module"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
990	1323	{"_key": 1323, "name": {"en": "Structure Observatory Service Module"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
991	1324	{"_key": 1324, "name": {"en": "Structure FLEX Service Module"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
992	1325	{"_key": 1325, "name": {"en": "Structure Administration Service Module"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
993	1326	{"_key": 1326, "name": {"en": "Structure Advertisement Service Module"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
994	1327	{"_key": 1327, "name": {"en": "Structure XL Missile Launcher"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
995	1328	{"_key": 1328, "name": {"en": "Structure Guided Bomb Launcher"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
996	1329	{"_key": 1329, "name": {"en": "Structure Energy Neutralizer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
997	1330	{"_key": 1330, "name": {"en": "Structure Area Denial Module"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
998	1331	{"_key": 1331, "name": {"en": "Structure Burst Projector"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
999	1332	{"_key": 1332, "name": {"en": "Structure ECM Battery"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1000	1333	{"_key": 1333, "name": {"en": "Structure Doomsday Weapon"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1001	1395	{"_key": 1395, "name": {"en": "Missile Guidance Enhancer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1002	1396	{"_key": 1396, "name": {"en": "Missile Guidance Computer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1003	1397	{"_key": 1397, "name": {"en": "Missile Guidance Enhancer Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1004	1399	{"_key": 1399, "name": {"en": "Missile Guidance Computer Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1005	1400	{"_key": 1400, "name": {"en": "Missile Guidance Script"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": false}
1006	1402	{"_key": 1402, "name": {"en": "Amarr Navy Roaming Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1007	1404	{"_key": 1404, "name": {"en": "Engineering Complex"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 65, "useBasePrice": false, "fittableNonSingleton": false}
1008	1405	{"_key": 1405, "name": {"en": "Laboratory"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 65, "useBasePrice": false, "fittableNonSingleton": false}
1009	1406	{"_key": 1406, "name": {"en": "Refinery"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 65, "useBasePrice": false, "fittableNonSingleton": false}
1010	1407	{"_key": 1407, "name": {"en": "Observatory Array"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 65, "useBasePrice": false, "fittableNonSingleton": false}
1011	1408	{"_key": 1408, "name": {"en": "Upwell Jump Bridge"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 65, "useBasePrice": false, "fittableNonSingleton": false}
1012	1409	{"_key": 1409, "name": {"en": "Administration Hub"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 65, "useBasePrice": false, "fittableNonSingleton": false}
1013	1410	{"_key": 1410, "name": {"en": "Advertisement Center"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 65, "useBasePrice": false, "fittableNonSingleton": false}
1014	1411	{"_key": 1411, "name": {"en": "Amarr Navy Roaming Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1015	1412	{"_key": 1412, "name": {"en": "Amarr Navy Roaming Capital"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1016	1413	{"_key": 1413, "name": {"en": "Amarr Navy Roaming Logistics"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1017	1414	{"_key": 1414, "name": {"en": "Amarr Navy Roaming Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1018	1415	{"_key": 1415, "name": {"en": "Structure Engineering Service Module"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1019	1416	{"_key": 1416, "name": {"en": "Structure Research Service Module"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1020	1429	{"_key": 1429, "name": {"en": "Structure Weapon Upgrade"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1021	1430	{"_key": 1430, "name": {"en": "Structure Fitting Module"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1022	1441	{"_key": 1441, "name": {"en": "Structure Stasis Webifier"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1023	1442	{"_key": 1442, "name": {"en": "Structure Warp Scrambler"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1024	1452	{"_key": 1452, "name": {"en": "Irregular Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1025	1453	{"_key": 1453, "name": {"en": "Irregular EW Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1026	1454	{"_key": 1454, "name": {"en": "Irregular Fighter"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1027	1455	{"_key": 1455, "name": {"en": "Irregular Fighter Squadron"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1028	1461	{"_key": 1461, "name": {"en": "Unknown Blueprint"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 9, "useBasePrice": false, "fittableNonSingleton": false}
1029	1462	{"_key": 1462, "name": {"en": "Structure Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1030	1465	{"_key": 1465, "name": {"en": "Mission Generic Supercarrier"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1031	1527	{"_key": 1527, "name": {"en": "Logistics Frigate"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
1032	1529	{"_key": 1529, "name": {"en": "Deadspace Sleeper Upgraded Avenger"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1033	1530	{"_key": 1530, "name": {"en": "Drifter Response Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1034	1533	{"_key": 1533, "name": {"en": "Micro Jump Field Generators"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1035	1534	{"_key": 1534, "name": {"en": "Command Destroyer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
1036	1535	{"_key": 1535, "name": {"en": "Structure Signal Amplifier"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1037	1537	{"_key": 1537, "name": {"en": "Support Fighter"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 87, "useBasePrice": false, "fittableNonSingleton": false}
1038	1538	{"_key": 1538, "name": {"en": "Force Auxiliary"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
1039	1542	{"_key": 1542, "name": {"en": "Command Destroyer Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": false, "fittableNonSingleton": false}
1040	1543	{"_key": 1543, "name": {"en": "Micro Jump Field Generator Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1041	1545	{"_key": 1545, "name": {"en": "Structure Management"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
1042	1546	{"_key": 1546, "name": {"en": "Structure Anti-Capital Missile"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1043	1547	{"_key": 1547, "name": {"en": "Structure Anti-Subcapital Missile"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1044	1548	{"_key": 1548, "name": {"en": "Guided Bomb"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1045	1549	{"_key": 1549, "name": {"en": "Structure ECM script"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1046	1550	{"_key": 1550, "name": {"en": "Structure Stasis Webifier Script"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1047	1551	{"_key": 1551, "name": {"en": "Structure Warp Disruptor Script"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1048	1559	{"_key": 1559, "name": {"en": "Structure Resistance Switcher Script"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1049	1562	{"_key": 1562, "name": {"en": "Structure Multirole Missile Launcher"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1050	1566	{"_key": 1566, "name": {"en": "Irregular Shuttle"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1051	1567	{"_key": 1567, "name": {"en": "Irregular Corvette"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1052	1568	{"_key": 1568, "name": {"en": "Irregular Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1053	1569	{"_key": 1569, "name": {"en": "Guidance Disruption Script"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1054	1570	{"_key": 1570, "name": {"en": "Structure Assembly Rig M - Small Tech I Ship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1055	1579	{"_key": 1579, "name": {"en": "Structure Assembly Rig M - Medium Tech I Ship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1056	1580	{"_key": 1580, "name": {"en": "Structure Assembly Rig M - Large Tech I Ship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1057	1581	{"_key": 1581, "name": {"en": "Structure Assembly Rig M - Small Tech II Ship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1058	1582	{"_key": 1582, "name": {"en": "Structure Assembly Rig M - Medium Tech II Ship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1059	1583	{"_key": 1583, "name": {"en": "Structure Assembly Rig M - Large Tech II Ship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1060	1584	{"_key": 1584, "name": {"en": "Structure Assembly Rig M - Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1061	1585	{"_key": 1585, "name": {"en": "Structure Assembly Rig M - Consumable"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1062	1586	{"_key": 1586, "name": {"en": "Structure Assembly Rig M - Module"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1063	1587	{"_key": 1587, "name": {"en": "Structure Assembly Rig L - Module, Consumable, Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1064	1588	{"_key": 1588, "name": {"en": "Structure Assembly Rig L - Tech I Ship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1065	1589	{"_key": 1589, "name": {"en": "Structure Assembly Rig L - Tech II Ship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1066	1590	{"_key": 1590, "name": {"en": "Structure Assembly Rig L - Tech II Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1067	1591	{"_key": 1591, "name": {"en": "Structure Assembly Rig L - Tech I Capital Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1068	1592	{"_key": 1592, "name": {"en": "Structure Assembly Rig L - Structure Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1069	1593	{"_key": 1593, "name": {"en": "Structure Assembly Rig L - Subsystem"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1070	1594	{"_key": 1594, "name": {"en": "Structure Assembly Rig XL - Equipment"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1071	1595	{"_key": 1595, "name": {"en": "Structure Assembly Rig XL - Ship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1072	1596	{"_key": 1596, "name": {"en": "Structure Assembly Rig XL - All Components"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1073	1598	{"_key": 1598, "name": {"en": "Structure Laboratory Rig M - Small Ship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1074	1599	{"_key": 1599, "name": {"en": "Structure Laboratory Rig M - Medium Ship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1075	1600	{"_key": 1600, "name": {"en": "Structure Laboratory Rig M - Large Ship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1076	1601	{"_key": 1601, "name": {"en": "Structure Laboratory Rig M - Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1077	1602	{"_key": 1602, "name": {"en": "Structure Laboratory Rig M - Consumable"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1078	1603	{"_key": 1603, "name": {"en": "Structure Laboratory Rig M - Module"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1079	1604	{"_key": 1604, "name": {"en": "Structure Laboratory Rig L - Module, Consumable, Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1080	1605	{"_key": 1605, "name": {"en": "Structure Laboratory Rig L - Ship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1081	1606	{"_key": 1606, "name": {"en": "Structure Laboratory Rig L - Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1082	1607	{"_key": 1607, "name": {"en": "Structure Laboratory Rig L - Capital Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1083	1608	{"_key": 1608, "name": {"en": "Structure Laboratory Rig L - Structure Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1084	1609	{"_key": 1609, "name": {"en": "Structure Laboratory Rig L - Subsystem"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1085	1610	{"_key": 1610, "name": {"en": "Structure Laboratory Rig XL - Equipment"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1086	1611	{"_key": 1611, "name": {"en": "Structure Laboratory Rig XL - Ship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1087	1612	{"_key": 1612, "name": {"en": "Structure Laboratory Rig XL - All Components"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1088	1613	{"_key": 1613, "name": {"en": "Structure Combat Rig M - Missile Application"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1089	1614	{"_key": 1614, "name": {"en": "Structure Combat Rig M - Missile Projection"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1090	1615	{"_key": 1615, "name": {"en": "Structure Combat Rig M - Energy Neutralizer Projection"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1091	1616	{"_key": 1616, "name": {"en": "Structure Combat Rig M - Energy Neutralizer Cap Reduction"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1092	1617	{"_key": 1617, "name": {"en": "Structure Citadel Rig M - Drone Hitpoints"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1093	1618	{"_key": 1618, "name": {"en": "Structure Citadel Rig M - Drone Speed"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1094	1619	{"_key": 1619, "name": {"en": "Structure Combat Rig M - EW projection"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1095	1620	{"_key": 1620, "name": {"en": "Structure Combat Rig M - EW Cap Reduction"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1096	1621	{"_key": 1621, "name": {"en": "Structure Combat Rig M - Max Targets"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1097	1622	{"_key": 1622, "name": {"en": "Structure Combat Rig M - Boosted Sensors"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1098	1629	{"_key": 1629, "name": {"en": "Structure Combat Rig L - Missile Application and Projection"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1099	1630	{"_key": 1630, "name": {"en": "Structure Combat Rig L - Energy Neutralizer Projection and Cap Reduction"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1100	1631	{"_key": 1631, "name": {"en": "Structure Citadel Rig L - Drone Hitpoints and Speed"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1101	1632	{"_key": 1632, "name": {"en": "Structure Combat Rig L - EW Projection and Cap Reduction"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1102	1633	{"_key": 1633, "name": {"en": "Structure Combat Rig L - AoE Launcher Application and Projection"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1103	1634	{"_key": 1634, "name": {"en": "Structure Combat Rig L - Point Defense Battery Application and Projection"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1104	1635	{"_key": 1635, "name": {"en": "Structure Combat Rig L - Max Targets and Sensor Boosting"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1105	1639	{"_key": 1639, "name": {"en": "Structure Combat Rig XL - Missile and AoE Missile"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1106	1640	{"_key": 1640, "name": {"en": "Structure Citadel Rig XL - Drone and PDB"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1107	1641	{"_key": 1641, "name": {"en": "Structure Combat Rig XL - Energy Neutralizer and EW"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1108	1642	{"_key": 1642, "name": {"en": "Structure Combat Rig XL - Doomsday and Targeting"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1109	1647	{"_key": 1647, "name": {"en": "OLD Structure Resource Rig M - HS Ore Reprocessing"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1110	1648	{"_key": 1648, "name": {"en": "OLD Structure Resource Rig L - Ore Reprocessing"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1111	1649	{"_key": 1649, "name": {"en": "OLD Structure Resource Rig XL - Reprocessing"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1112	1652	{"_key": 1652, "name": {"en": "Light Fighter"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 87, "useBasePrice": false, "fittableNonSingleton": false}
1113	1653	{"_key": 1653, "name": {"en": "Heavy Fighter"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 87, "useBasePrice": false, "fittableNonSingleton": false}
1114	1657	{"_key": 1657, "name": {"en": "Citadel"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 65, "useBasePrice": false, "fittableNonSingleton": false}
1115	1664	{"_key": 1664, "name": {"en": "Irregular Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1116	1665	{"_key": 1665, "name": {"en": "Irregular Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1117	1666	{"_key": 1666, "name": {"en": "Irregular Battlecruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1118	1667	{"_key": 1667, "name": {"en": "Irregular Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1119	1670	{"_key": 1670, "name": {"en": "Augmentations"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 30, "useBasePrice": false, "fittableNonSingleton": false}
1120	1672	{"_key": 1672, "name": {"en": "Stasis Grappler"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1121	1673	{"_key": 1673, "name": {"en": "Missile Launcher Rapid Torpedo"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1122	1674	{"_key": 1674, "name": {"en": "Missile Launcher XL Cruise"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1123	1676	{"_key": 1676, "name": {"en": "Named Components"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 4, "useBasePrice": false, "fittableNonSingleton": false}
1124	1677	{"_key": 1677, "name": {"en": "Advanced XL Torpedo"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1125	1678	{"_key": 1678, "name": {"en": "Advanced XL Cruise Missile"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1126	1679	{"_key": 1679, "name": {"en": "Support Fighter Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1127	1681	{"_key": 1681, "name": {"en": "Asteroid Angel Cartel Dreadnought"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1128	1682	{"_key": 1682, "name": {"en": "Asteroid Angel Cartel Titan"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1129	1683	{"_key": 1683, "name": {"en": "Asteroid Blood Raider Dreadnought"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1130	1684	{"_key": 1684, "name": {"en": "Asteroid Blood Raider Titan"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1131	1685	{"_key": 1685, "name": {"en": "Asteroid Guristas Dreadnought"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1132	1686	{"_key": 1686, "name": {"en": "Asteroid Guristas Titan"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1133	1687	{"_key": 1687, "name": {"en": "Asteroid Sansha's Nation Dreadnought"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1134	1688	{"_key": 1688, "name": {"en": "Asteroid Sansha's Nation Supercarrier"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1135	1689	{"_key": 1689, "name": {"en": "Asteroid Serpentis Dreadnought"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1136	1690	{"_key": 1690, "name": {"en": "Asteroid Serpentis Titan"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1137	1691	{"_key": 1691, "name": {"en": "Asteroid Rogue Drone Carrier"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1138	1692	{"_key": 1692, "name": {"en": "Asteroid Rogue Drone Supercarrier"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1139	1693	{"_key": 1693, "name": {"en": "OLD Structure Resource Rig M - LNS Ore Reprocessing"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1140	1694	{"_key": 1694, "name": {"en": "OLD Structure Resource Rig M - Ice 1 Reprocessing"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1141	1695	{"_key": 1695, "name": {"en": "OLD Structure Resource Rig M - Ice 2 Reprocessing"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1142	1696	{"_key": 1696, "name": {"en": "OLD Structure Resource Rig L - Ice Reprocessing"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1143	1697	{"_key": 1697, "name": {"en": "Ancillary Remote Shield Booster"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1144	1698	{"_key": 1698, "name": {"en": "Ancillary Remote Armor Repairer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1145	1699	{"_key": 1699, "name": {"en": "Flex Armor Hardener"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1146	1700	{"_key": 1700, "name": {"en": "Flex Shield Hardener"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1147	1701	{"_key": 1701, "name": {"en": "Flex Armor Hardener Script"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1148	1702	{"_key": 1702, "name": {"en": "Flex Shield Hardener Script"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1149	1703	{"_key": 1703, "name": {"en": "Burst Projector Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1150	1704	{"_key": 1704, "name": {"en": "Super Weapon Beacon"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1151	1706	{"_key": 1706, "name": {"en": "Capital Sensor Array"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1152	1707	{"_key": 1707, "name": {"en": "Structure Module Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1153	1708	{"_key": 1708, "name": {"en": "Structure Rig Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1154	1709	{"_key": 1709, "name": {"en": "Unpublished Structure Module and Rig Blueprints"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1155	1717	{"_key": 1717, "name": {"en": "Unpublished Structure Modules"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1156	1718	{"_key": 1718, "name": {"en": "Force Auxiliary Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1157	1719	{"_key": 1719, "name": {"en": "Structure Disruption Battery"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1158	1720	{"_key": 1720, "name": {"en": "Roaming Serpentis Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1159	1721	{"_key": 1721, "name": {"en": "Roaming Serpentis Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1160	1722	{"_key": 1722, "name": {"en": "Roaming Serpentis Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1161	1723	{"_key": 1723, "name": {"en": "Shield Resistance Shift Hardener Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1162	1724	{"_key": 1724, "name": {"en": "Irregular Dreadnought"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1163	1725	{"_key": 1725, "name": {"en": "Irregular Force Auxiliary"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1164	1726	{"_key": 1726, "name": {"en": "Irregular Carrier"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1165	1727	{"_key": 1727, "name": {"en": "Roaming Angel Cartel Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1166	1728	{"_key": 1728, "name": {"en": "Roaming Angel Cartel Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1167	1729	{"_key": 1729, "name": {"en": "Roaming Angel Cartel Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1168	1730	{"_key": 1730, "name": {"en": "Special Edition Implant"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": true, "fittableNonSingleton": false}
1169	1731	{"_key": 1731, "name": {"en": "Irregular Super Carrier"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1170	1734	{"_key": 1734, "name": {"en": "Roaming Blood Raider Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1171	1735	{"_key": 1735, "name": {"en": "Roaming Blood Raider Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1172	1736	{"_key": 1736, "name": {"en": "Roaming Blood Raider Battlecruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1173	1737	{"_key": 1737, "name": {"en": "Roaming Blood Raider Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1174	1739	{"_key": 1739, "name": {"en": "Skill Injectors"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 5, "useBasePrice": false, "fittableNonSingleton": false}
1175	1759	{"_key": 1759, "name": {"en": "Irregular Titan"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1176	1761	{"_key": 1761, "name": {"en": "Irregular Mining Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1177	1762	{"_key": 1762, "name": {"en": "Irregular Mining Barge"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1178	1764	{"_key": 1764, "name": {"en": "♦ Mining Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1179	1765	{"_key": 1765, "name": {"en": "♦ Mining Barge"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1180	1766	{"_key": 1766, "name": {"en": "♦ Mining Exhumer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1181	1767	{"_key": 1767, "name": {"en": "♦ Mining Hauler"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1182	1768	{"_key": 1768, "name": {"en": "Seeker Scouts"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1183	1769	{"_key": 1769, "name": {"en": "Shield Command Burst Charges"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1184	1770	{"_key": 1770, "name": {"en": "Command Burst"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1185	1771	{"_key": 1771, "name": {"en": "Mining Foreman Burst Charges"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1186	1772	{"_key": 1772, "name": {"en": "Skirmish Command Burst Charges"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1187	1773	{"_key": 1773, "name": {"en": "Information Command Burst Charges"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1188	1774	{"_key": 1774, "name": {"en": "Armor Command Burst Charges"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1189	1788	{"_key": 1788, "name": {"en": "Hidden Zenith Drifters"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1190	1789	{"_key": 1789, "name": {"en": "Hidden Zenith Amarr Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1191	1790	{"_key": 1790, "name": {"en": "Hidden Zenith Amarr Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1192	1791	{"_key": 1791, "name": {"en": "Hidden Zenith Amarr Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1193	1792	{"_key": 1792, "name": {"en": "Hidden Zenith Caldari Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1194	1793	{"_key": 1793, "name": {"en": "Hidden Zenith Caldari Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1195	1794	{"_key": 1794, "name": {"en": "Hidden Zenith Caldari Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1196	1795	{"_key": 1795, "name": {"en": "Hidden Zenith Gallente Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1197	1796	{"_key": 1796, "name": {"en": "Hidden Zenith Gallente Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1198	1797	{"_key": 1797, "name": {"en": "Hidden Zenith Gallente Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1199	1798	{"_key": 1798, "name": {"en": "Hidden Zenith Minmatar Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1200	1799	{"_key": 1799, "name": {"en": "Hidden Zenith Minmatar Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1201	1800	{"_key": 1800, "name": {"en": "Hidden Zenith Minmatar Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1202	1803	{"_key": 1803, "name": {"en": "♦ Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1203	1804	{"_key": 1804, "name": {"en": "Hidden Zenith Amarr Capital"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1204	1805	{"_key": 1805, "name": {"en": "Hidden Zenith Caldari Capital"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1205	1806	{"_key": 1806, "name": {"en": "Hidden Zenith Gallente Capital"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1206	1807	{"_key": 1807, "name": {"en": "Hidden Zenith Minmatar Capital"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1207	1810	{"_key": 1810, "name": {"en": "Command Burst Charge Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1208	1812	{"_key": 1812, "name": {"en": "Command Burst Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1209	1813	{"_key": 1813, "name": {"en": "♦ Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1210	1814	{"_key": 1814, "name": {"en": "♦ Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1211	1815	{"_key": 1815, "name": {"en": "Titan Phenomena Generator"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1212	1816	{"_key": 1816, "name": {"en": "Structure Engineering Rig M - Equipment ME"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1213	1818	{"_key": 1818, "name": {"en": "Strong Boxes"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1214	1819	{"_key": 1819, "name": {"en": "Structure Engineering Rig M - Equipment TE"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1215	1820	{"_key": 1820, "name": {"en": "Structure Engineering Rig M - Ammunition ME"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1216	1821	{"_key": 1821, "name": {"en": "Structure Engineering Rig M - Ammunition TE"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1217	1822	{"_key": 1822, "name": {"en": "Structure Engineering Rig M - Drone and Fighter ME"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1218	1823	{"_key": 1823, "name": {"en": "Structure Engineering Rig M - Drone and Fighter TE"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1219	1824	{"_key": 1824, "name": {"en": "Structure Engineering Rig M - Basic Small Ship ME"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1220	1825	{"_key": 1825, "name": {"en": "Structure Engineering Rig M - Basic Small Ship TE"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1221	1826	{"_key": 1826, "name": {"en": "Structure Engineering Rig M - Basic Medium Ship ME"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1222	1827	{"_key": 1827, "name": {"en": "Structure Engineering Rig M - Basic Medium Ship TE"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1223	1828	{"_key": 1828, "name": {"en": "Structure Engineering Rig M - Basic Large Ship ME"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1224	1829	{"_key": 1829, "name": {"en": "Structure Engineering Rig M - Basic Large Ship TE"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1225	1830	{"_key": 1830, "name": {"en": "Structure Engineering Rig M - Advanced Small Ship ME"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1226	1831	{"_key": 1831, "name": {"en": "Structure Engineering Rig M - Advanced Small Ship TE"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1227	1832	{"_key": 1832, "name": {"en": "Structure Engineering Rig M - Advanced Medium Ship ME"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1228	1833	{"_key": 1833, "name": {"en": "Structure Engineering Rig M - Advanced Medium Ship TE"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1229	1834	{"_key": 1834, "name": {"en": "Structure Engineering Rig M - Advanced Large Ship ME"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1230	1835	{"_key": 1835, "name": {"en": "Structure Engineering Rig M - Advanced Large Ship TE"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1231	1836	{"_key": 1836, "name": {"en": "Structure Engineering Rig M - Advanced Component ME"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1232	1837	{"_key": 1837, "name": {"en": "Structure Engineering Rig M - Advanced Component TE"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1233	1838	{"_key": 1838, "name": {"en": "Structure Engineering Rig M - Basic Capital Component TE"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1234	1839	{"_key": 1839, "name": {"en": "Structure Engineering Rig M - Basic Capital Component ME"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1235	1840	{"_key": 1840, "name": {"en": "Structure Engineering Rig M - Structure ME"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1236	1841	{"_key": 1841, "name": {"en": "Structure Engineering Rig M - Structure TE"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1237	1842	{"_key": 1842, "name": {"en": "Structure Engineering Rig M - Invention Cost Optimization"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1238	1843	{"_key": 1843, "name": {"en": "Structure Engineering Rig M - Invention Accelerator"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1239	1844	{"_key": 1844, "name": {"en": "Structure Engineering Rig M - ME Research Cost Optimization"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1240	1845	{"_key": 1845, "name": {"en": "Structure Engineering Rig M - ME Research Accelerator"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1241	1846	{"_key": 1846, "name": {"en": "Structure Engineering Rig M - TE Research Cost Optimization"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1242	1847	{"_key": 1847, "name": {"en": "Structure Engineering Rig M - TE Research Accelerator"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1243	1848	{"_key": 1848, "name": {"en": "Structure Engineering Rig M - Blueprint Copy Cost Optimization"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1244	1849	{"_key": 1849, "name": {"en": "Structure Engineering Rig M - Blueprint Copy Accelerator"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1245	1850	{"_key": 1850, "name": {"en": "Structure Engineering Rig L - Equipment Efficiency"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1246	1851	{"_key": 1851, "name": {"en": "Structure Engineering Rig L - Ammunition Efficiency"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1247	1852	{"_key": 1852, "name": {"en": "Structure Engineering Rig L - Drone and Fighter Efficiency"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1248	1853	{"_key": 1853, "name": {"en": "Structure Engineering Rig L - Basic Small Ship Efficiency"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1249	1854	{"_key": 1854, "name": {"en": "Structure Engineering Rig L - Basic Medium Ship Efficiency"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1250	1855	{"_key": 1855, "name": {"en": "Structure Engineering Rig L - Basic Large Ship Efficiency"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1251	1856	{"_key": 1856, "name": {"en": "Structure Engineering Rig L - Advanced Small Ship Efficiency"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1252	1857	{"_key": 1857, "name": {"en": "Structure Engineering Rig L - Advanced Medium Ship Efficiency"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1253	1858	{"_key": 1858, "name": {"en": "Structure Engineering Rig L - Advanced Large Ship Efficiency"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1254	1859	{"_key": 1859, "name": {"en": "Structure Engineering Rig L - Capital Ship Efficiency"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1255	1860	{"_key": 1860, "name": {"en": "Structure Engineering Rig L - Advanced Component Efficiency"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1256	1861	{"_key": 1861, "name": {"en": "Structure Engineering Rig L - Basic Capital Component Efficiency"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1257	1862	{"_key": 1862, "name": {"en": "Structure Engineering Rig L - Structure Efficiency"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1258	1863	{"_key": 1863, "name": {"en": "Structure Engineering Rig L - Invention Optimization"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1259	1864	{"_key": 1864, "name": {"en": "Structure Engineering Rig L - ME Research Optimization"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1260	1865	{"_key": 1865, "name": {"en": "Structure Engineering Rig L - TE Research Optimization"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1261	1866	{"_key": 1866, "name": {"en": "Structure Engineering Rig L - Blueprint Copy Optimization"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1262	1867	{"_key": 1867, "name": {"en": "Structure Engineering Rig XL - Equipment and Consumable Efficiency"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1263	1868	{"_key": 1868, "name": {"en": "Structure Engineering Rig XL - Ship Efficiency"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1264	1869	{"_key": 1869, "name": {"en": "Structure Engineering Rig XL - Structure and Component Efficiency"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1265	1870	{"_key": 1870, "name": {"en": "Structure Engineering Rig XL - Laboratory Optimization"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1266	1872	{"_key": 1872, "name": {"en": "Structure Entities"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1267	1875	{"_key": 1875, "name": {"en": "PLEX"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 5, "useBasePrice": false, "fittableNonSingleton": false}
1268	1876	{"_key": 1876, "name": {"en": "♦ Engineering Complex"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 65, "useBasePrice": false, "fittableNonSingleton": false}
1269	1878	{"_key": 1878, "name": {"en": "♦ Titan"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1270	1879	{"_key": 1879, "name": {"en": "♦ Force Auxiliary"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1271	1880	{"_key": 1880, "name": {"en": "♦ Dreadnought"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1272	1882	{"_key": 1882, "name": {"en": "MassiveEnvironments"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1273	1884	{"_key": 1884, "name": {"en": "Ubiquitous Moon Asteroids"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1274	1886	{"_key": 1886, "name": {"en": "Technical Data Chips"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1275	1887	{"_key": 1887, "name": {"en": "Structure Moon Drilling Service Module"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1276	1888	{"_key": 1888, "name": {"en": "Composite Reaction Formulas"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1277	1889	{"_key": 1889, "name": {"en": "Polymer Reaction Formulas"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1278	1890	{"_key": 1890, "name": {"en": "Biochemical Reaction Formulas"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1279	1891	{"_key": 1891, "name": {"en": "Depricated Subsystem Blueprints"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 9, "useBasePrice": false, "fittableNonSingleton": false}
1280	1894	{"_key": 1894, "name": {"en": "Non-Repeating Hardeners"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1281	1895	{"_key": 1895, "name": {"en": "Irregular Industrial"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1282	1896	{"_key": 1896, "name": {"en": "♦ Industrial Command"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1283	1909	{"_key": 1909, "name": {"en": "♦ Battlecruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1284	1911	{"_key": 1911, "name": {"en": "Empire Asteroids"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1285	1912	{"_key": 1912, "name": {"en": "Structure Drilling Rig M - Efficiency"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1286	1913	{"_key": 1913, "name": {"en": "Structure Drilling Rig M - Stability"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1287	1914	{"_key": 1914, "name": {"en": "Structure Drilling Rig L - Proficiency"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1288	1915	{"_key": 1915, "name": {"en": "Moon Mining Beacon"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1289	1920	{"_key": 1920, "name": {"en": "Common Moon Asteroids"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1290	1921	{"_key": 1921, "name": {"en": "Uncommon Moon Asteroids"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1291	1922	{"_key": 1922, "name": {"en": "Rare Moon Asteroids"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1292	1923	{"_key": 1923, "name": {"en": "Exceptional Moon Asteroids"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1293	1924	{"_key": 1924, "name": {"en": "♦ Stronghold"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 65, "useBasePrice": false, "fittableNonSingleton": false}
1294	1925	{"_key": 1925, "name": {"en": "Irregular Industrial Command Ship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1295	1926	{"_key": 1926, "name": {"en": "Irregular Freighter"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1296	1927	{"_key": 1927, "name": {"en": "Irregular Structure"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1297	1928	{"_key": 1928, "name": {"en": "Irregular Container"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1298	1929	{"_key": 1929, "name": {"en": "Irregular - Unidentified"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1299	1933	{"_key": 1933, "name": {"en": "Structure Composite Reactor Rig M - TE"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1300	1934	{"_key": 1934, "name": {"en": "Structure Composite Reactor Rig M - ME"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1301	1935	{"_key": 1935, "name": {"en": "Structure Hybrid Reactor Rig M - TE"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1302	1936	{"_key": 1936, "name": {"en": "Structure Hybrid Reactor Rig M - ME"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1303	1937	{"_key": 1937, "name": {"en": "Structure Biochemical Reactor Rig M - TE"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1304	1938	{"_key": 1938, "name": {"en": "Structure Biochemical Reactor Rig M - ME"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1305	1939	{"_key": 1939, "name": {"en": "Structure Reactor Rig L - Efficiency"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1306	1940	{"_key": 1940, "name": {"en": "Moon Chunk"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1307	1941	{"_key": 1941, "name": {"en": "Structure Resource Rig M - Asteroid Ore Reprocessing"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1308	1942	{"_key": 1942, "name": {"en": "Structure Resource Rig M - Ice Reprocessing"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1309	1943	{"_key": 1943, "name": {"en": "Structure Resource Rig M - Moon Ore Reprocessing"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1310	1944	{"_key": 1944, "name": {"en": "Structure Resource Rig L - Reprocessing"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1311	1945	{"_key": 1945, "name": {"en": "Structure Resource Rig XL - Reprocessing"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1312	1948	{"_key": 1948, "name": {"en": "Cyber Scanning Implant Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": false, "fittableNonSingleton": false}
1313	1950	{"_key": 1950, "name": {"en": "Permanent SKIN"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 91, "useBasePrice": false, "fittableNonSingleton": false}
1314	1951	{"_key": 1951, "name": {"en": "Volatile SKIN"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 91, "useBasePrice": false, "fittableNonSingleton": false}
1315	1952	{"_key": 1952, "name": {"en": "7-Day SKIN"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 91, "useBasePrice": false, "fittableNonSingleton": false}
1316	1953	{"_key": 1953, "name": {"en": "30-Day SKIN"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 91, "useBasePrice": false, "fittableNonSingleton": false}
1317	1954	{"_key": 1954, "name": {"en": "90-Day SKIN"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 91, "useBasePrice": false, "fittableNonSingleton": false}
1318	1955	{"_key": 1955, "name": {"en": "1-Year SKIN"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 91, "useBasePrice": false, "fittableNonSingleton": false}
1319	1956	{"_key": 1956, "name": {"en": "Drifter Reinforcements"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1320	1962	{"_key": 1962, "name": {"en": "Structure QA Modules"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1321	1964	{"_key": 1964, "name": {"en": "Mutaplasmids"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1322	1966	{"_key": 1966, "name": {"en": "Structure Capacitor Battery"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1323	1967	{"_key": 1967, "name": {"en": "Structure Capacitor Power Relay"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1324	1968	{"_key": 1968, "name": {"en": "Structure Armor Reinforcer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1325	1969	{"_key": 1969, "name": {"en": "Abyssal Modules"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1326	1971	{"_key": 1971, "name": {"en": "Abyssal Hazards"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1327	1972	{"_key": 1972, "name": {"en": "Flag Cruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
1328	1973	{"_key": 1973, "name": {"en": "Locators"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1329	1974	{"_key": 1974, "name": {"en": "Structure Festival Launcher"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1330	1975	{"_key": 1975, "name": {"en": "Non-Interactable Object"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1331	1976	{"_key": 1976, "name": {"en": "Structure Festival Charges"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1332	1977	{"_key": 1977, "name": {"en": "Trinary Data Vaults"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1333	1978	{"_key": 1978, "name": {"en": "Industrial Support Facility"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1334	1979	{"_key": 1979, "name": {"en": "Abyssal Filaments"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1335	1980	{"_key": 1980, "name": {"en": "Non-Scalable Clouds"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1336	1981	{"_key": 1981, "name": {"en": "Triglavian Support Pylons"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1337	1982	{"_key": 1982, "name": {"en": "Abyssal Spaceship Entities"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1338	1983	{"_key": 1983, "name": {"en": "Abyssal Environment"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1339	1984	{"_key": 1984, "name": {"en": "Outpost Conversion Rigs"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1340	1986	{"_key": 1986, "name": {"en": "Precursor Weapon"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1341	1987	{"_key": 1987, "name": {"en": "Exotic Plasma Charge"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": false}
1342	1988	{"_key": 1988, "name": {"en": "Entropic Radiation Sink"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1343	1989	{"_key": 1989, "name": {"en": "Advanced Exotic Plasma Charge"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": false}
1344	1990	{"_key": 1990, "name": {"en": "Precursor Weapon Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1345	1991	{"_key": 1991, "name": {"en": "Filament Trace"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1346	1992	{"_key": 1992, "name": {"en": "Entropic Radiation Sink Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1347	1993	{"_key": 1993, "name": {"en": "Exotic Plasma Charge Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1348	1994	{"_key": 1994, "name": {"en": "Advanced Exotic Plasma Charge Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1349	1995	{"_key": 1995, "name": {"en": "Triglavian Data"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1350	1996	{"_key": 1996, "name": {"en": "Abyssal Materials"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 4, "useBasePrice": false, "fittableNonSingleton": false}
1351	1997	{"_key": 1997, "name": {"en": "Abyssal Drone Entities"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1352	1998	{"_key": 1998, "name": {"en": "Station Conversion Monuments"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1353	2001	{"_key": 2001, "name": {"en": "Citizen Ships"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
1354	2002	{"_key": 2002, "name": {"en": "Triglavian Datastreams"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1355	2003	{"_key": 2003, "name": {"en": "Citizen Modules"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1356	2004	{"_key": 2004, "name": {"en": "Citizen Mining Laser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1357	2005	{"_key": 2005, "name": {"en": "Deployable Advertisement"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 22, "useBasePrice": false, "fittableNonSingleton": false}
1358	2006	{"_key": 2006, "name": {"en": "Deadspace Asteroids"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1359	2008	{"_key": 2008, "name": {"en": "Mass Entanglers"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1360	2009	{"_key": 2009, "name": {"en": "Precursor Cache"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1361	2010	{"_key": 2010, "name": {"en": "Mass Entangler Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1362	2013	{"_key": 2013, "name": {"en": "Stasis Nullifiers"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1363	2015	{"_key": 2015, "name": {"en": "Upwell Monument"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 65, "useBasePrice": false, "fittableNonSingleton": false}
1364	2016	{"_key": 2016, "name": {"en": "Upwell Cyno Jammer"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 65, "useBasePrice": false, "fittableNonSingleton": false}
1365	2017	{"_key": 2017, "name": {"en": "Upwell Cyno Beacon"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 65, "useBasePrice": false, "fittableNonSingleton": false}
1366	2018	{"_key": 2018, "name": {"en": "Mutadaptive Remote Armor Repairer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1367	2019	{"_key": 2019, "name": {"en": "Mutadaptive Remote Armor Repairer Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1368	2020	{"_key": 2020, "name": {"en": "Cynosural Fields"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1369	2022	{"_key": 2022, "name": {"en": "Temporal Resources"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 25, "useBasePrice": true, "fittableNonSingleton": false}
1370	2023	{"_key": 2023, "name": {"en": "Cyber Electronics Implant Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": false, "fittableNonSingleton": false}
1371	2024	{"_key": 2024, "name": {"en": "Fluorite"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1372	2026	{"_key": 2026, "name": {"en": "Triglavian Artifacts"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1373	4028	{"_key": 4028, "name": {"en": "Triglavian Entities"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1374	4029	{"_key": 4029, "name": {"en": "Talassonite"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1375	4030	{"_key": 4030, "name": {"en": "Rakovene"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1376	4031	{"_key": 4031, "name": {"en": "Bezdnacine"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1377	4033	{"_key": 4033, "name": {"en": "Destructible Effect Beacon"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1378	4034	{"_key": 4034, "name": {"en": "EDENCOM Entities"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1379	4035	{"_key": 4035, "name": {"en": "Drifter Entities"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1380	4036	{"_key": 4036, "name": {"en": "Sleeper Entities"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1381	4037	{"_key": 4037, "name": {"en": "Rogue Drone Entities"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1382	4040	{"_key": 4040, "name": {"en": "180-Day SKIN"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 91, "useBasePrice": false, "fittableNonSingleton": false}
1383	4041	{"_key": 4041, "name": {"en": "Jump Filaments"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1384	4050	{"_key": 4050, "name": {"en": "Abyssal Proving Filaments"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1385	4052	{"_key": 4052, "name": {"en": "Jump Filament Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": false, "fittableNonSingleton": false}
1386	4053	{"_key": 4053, "name": {"en": "Irregular Capsule"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1387	4055	{"_key": 4055, "name": {"en": "Invisible Beacon"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1388	4057	{"_key": 4057, "name": {"en": "Masks"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 30, "useBasePrice": false, "fittableNonSingleton": false}
1389	4060	{"_key": 4060, "name": {"en": "Vorton Projector"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1390	4061	{"_key": 4061, "name": {"en": "Advanced Condenser Pack"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": false}
1391	4062	{"_key": 4062, "name": {"en": "Condenser Pack"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": false}
1392	4064	{"_key": 4064, "name": {"en": "Vorton Projector Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": false, "fittableNonSingleton": false}
1393	4065	{"_key": 4065, "name": {"en": "Condenser Pack Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": false, "fittableNonSingleton": false}
1394	4066	{"_key": 4066, "name": {"en": "Advanced Condenser Pack Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": false, "fittableNonSingleton": false}
1395	4067	{"_key": 4067, "name": {"en": "Vorton Projector Upgrade"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1396	4069	{"_key": 4069, "name": {"en": "Vorton Projector Upgrade Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": false, "fittableNonSingleton": false}
1397	4070	{"_key": 4070, "name": {"en": "Exotic Artefact"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1398	4071	{"_key": 4071, "name": {"en": "Type Graveyard"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 29, "useBasePrice": false, "fittableNonSingleton": false}
1399	4072	{"_key": 4072, "name": {"en": "Expired Jump Filaments"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1400	4073	{"_key": 4073, "name": {"en": "Temporary Collidable Structure"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1401	4079	{"_key": 4079, "name": {"en": "Encounter Surveillance System"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1402	4081	{"_key": 4081, "name": {"en": "Disrupted Gate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1403	4086	{"_key": 4086, "name": {"en": "Quantum Cores"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 66, "useBasePrice": true, "fittableNonSingleton": false}
1404	4087	{"_key": 4087, "name": {"en": "Triglavian Space Filaments"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1405	4088	{"_key": 4088, "name": {"en": "Interdiction Burst Probes"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1406	4090	{"_key": 4090, "name": {"en": "QA Expert Systems"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2100, "useBasePrice": false, "fittableNonSingleton": false}
1407	4091	{"_key": 4091, "name": {"en": "Standard Expert Systems"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2100, "useBasePrice": false, "fittableNonSingleton": false}
1408	4093	{"_key": 4093, "name": {"en": "Mobile Cynosural Beacon"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 22, "useBasePrice": false, "fittableNonSingleton": false}
1409	4094	{"_key": 4094, "name": {"en": "Scalable Decorative Asteroid"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1410	4095	{"_key": 4095, "name": {"en": "Mobile Cynosural Beacon Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1411	4096	{"_key": 4096, "name": {"en": "Molecular-Forged Materials"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 4, "useBasePrice": true, "fittableNonSingleton": false}
1412	4097	{"_key": 4097, "name": {"en": "Molecular-Forged Reaction Formulas"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1413	4098	{"_key": 4098, "name": {"en": "Promotional Expert Systems"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2100, "useBasePrice": false, "fittableNonSingleton": false}
1414	4100	{"_key": 4100, "name": {"en": "Logo Display Monument"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1415	4102	{"_key": 4102, "name": {"en": "ESS Reserve Bank Keys"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1416	4105	{"_key": 4105, "name": {"en": "Unidentified Entities"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1417	4106	{"_key": 4106, "name": {"en": "AIR Entities I"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1418	4107	{"_key": 4107, "name": {"en": "Mobile Observatory"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 22, "useBasePrice": false, "fittableNonSingleton": false}
1419	4108	{"_key": 4108, "name": {"en": "Mobile Observatory Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1420	4117	{"_key": 4117, "name": {"en": "Interdiction Nullifier"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1421	4118	{"_key": 4118, "name": {"en": "Interdiction Nullifier Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1422	4127	{"_key": 4127, "name": {"en": "Covert Jump Portal Generator"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1423	4128	{"_key": 4128, "name": {"en": "AIR Entities II"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1424	4129	{"_key": 4129, "name": {"en": "Group 4129"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1425	4130	{"_key": 4130, "name": {"en": "Unidentified Entities II"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1426	4137	{"_key": 4137, "name": {"en": "Mobile Analysis Beacon"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 22, "useBasePrice": true, "fittableNonSingleton": false}
1427	4138	{"_key": 4138, "name": {"en": "Gas Cloud Harvesters"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1428	4139	{"_key": 4139, "name": {"en": "Gas Harvester Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1429	4141	{"_key": 4141, "name": {"en": "Mobile Analysis Beacon Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1430	4142	{"_key": 4142, "name": {"en": "Rogue Drone Analysis Data"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1431	4145	{"_key": 4145, "name": {"en": "Warp Matrix Filaments"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1432	4147	{"_key": 4147, "name": {"en": "Electronic combat drone"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 18, "useBasePrice": false, "fittableNonSingleton": false}
1433	4151	{"_key": 4151, "name": {"en": "Solar Flare Lab"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1434	4153	{"_key": 4153, "name": {"en": "Special SF weapon"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1435	4158	{"_key": 4158, "name": {"en": "Fusion Mutaplasmids"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1436	4159	{"_key": 4159, "name": {"en": "Tomb"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1437	4160	{"_key": 4160, "name": {"en": "舰船适性"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": false, "fittableNonSingleton": false}
1438	4161	{"_key": 4161, "name": {"en": "AIR Ore Asteroid Resources"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 25, "useBasePrice": true, "fittableNonSingleton": false}
1439	4162	{"_key": 4162, "name": {"en": "Solar Flare Materials"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 4, "useBasePrice": false, "fittableNonSingleton": false}
1440	4163	{"_key": 4163, "name": {"en": "BrawlShip Entropy Module"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1441	4165	{"_key": 4165, "name": {"en": "Peculiar Materials"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1442	4166	{"_key": 4166, "name": {"en": "Solar Flare  Implant"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": true, "fittableNonSingleton": false}
1443	4168	{"_key": 4168, "name": {"en": "Compressed Gas"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1444	4174	{"_key": 4174, "name": {"en": "Compressors"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": true, "fittableNonSingleton": false}
1445	4175	{"_key": 4175, "name": {"en": "Compressors Blueprints"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1446	4181	{"_key": 4181, "name": {"en": "Solar Flare Lab Frigates"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
1447	4182	{"_key": 4182, "name": {"en": "Solar Flare Lab Cruisers"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
1448	4183	{"_key": 4183, "name": {"en": "Solar Flare Lab Battleships"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
1449	4184	{"_key": 4184, "name": {"en": "Industrial Jump Portal Generator"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1450	4186	{"_key": 4186, "name": {"en": "Structure Area Denial Ammunition"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1451	4188	{"_key": 4188, "name": {"en": "Structure Area Denial Ammo Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1452	4194	{"_key": 4194, "name": {"en": "Enhancement"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": false, "fittableNonSingleton": false}
1453	4196	{"_key": 4196, "name": {"en": "CloudComputing"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 16, "useBasePrice": false, "fittableNonSingleton": false}
1454	4197	{"_key": 4197, "name": {"en": "Propulsion Module Refurbished Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1455	4201	{"_key": 4201, "name": {"en": "StructureDamageJournal"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1456	4202	{"_key": 4202, "name": {"en": "Corvette Refurbished Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1457	4210	{"_key": 4210, "name": {"en": "Shield Booster Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1458	4211	{"_key": 4211, "name": {"en": "Prototype Exploration Ship Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1459	4212	{"_key": 4212, "name": {"en": "Attack Battlecruiser Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1460	4213	{"_key": 4213, "name": {"en": "Blockade Runner Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1461	4214	{"_key": 4214, "name": {"en": "Expedition Frigate Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1462	4215	{"_key": 4215, "name": {"en": "Tactical Destroyer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1463	4216	{"_key": 4216, "name": {"en": "Logistics Frigate Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1464	4217	{"_key": 4217, "name": {"en": "Command Destroyer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1465	4218	{"_key": 4218, "name": {"en": "Force Auxiliary Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1466	4219	{"_key": 4219, "name": {"en": "Flag Cruiser Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1467	4220	{"_key": 4220, "name": {"en": "Citizen Ships Refurbish Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1468	4221	{"_key": 4221, "name": {"en": "Frigate Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1469	4222	{"_key": 4222, "name": {"en": "Cruiser Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1470	4223	{"_key": 4223, "name": {"en": "Battleship Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1471	4224	{"_key": 4224, "name": {"en": "Hauler Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1472	4225	{"_key": 4225, "name": {"en": "Capsule Refurbish Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1473	4226	{"_key": 4226, "name": {"en": "Titan Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1474	4227	{"_key": 4227, "name": {"en": "Shuttle Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1475	4228	{"_key": 4228, "name": {"en": "Assault Frigate Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1476	4229	{"_key": 4229, "name": {"en": "Heavy Assault Cruiser Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1477	4230	{"_key": 4230, "name": {"en": "Deep Space Transport Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1478	4231	{"_key": 4231, "name": {"en": "Combat Battlecruiser Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1479	4232	{"_key": 4232, "name": {"en": "Destroyer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1480	4233	{"_key": 4233, "name": {"en": "Mining Barge Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1481	4234	{"_key": 4234, "name": {"en": "Dreadnought Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1482	4235	{"_key": 4235, "name": {"en": "Freighter Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1483	4236	{"_key": 4236, "name": {"en": "Command Ship Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1484	4237	{"_key": 4237, "name": {"en": "Interdictor Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1485	4238	{"_key": 4238, "name": {"en": "Exhumer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1486	4239	{"_key": 4239, "name": {"en": "Carrier Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1487	4240	{"_key": 4240, "name": {"en": "Supercarrier Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1488	4241	{"_key": 4241, "name": {"en": "Covert Ops Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1489	4242	{"_key": 4242, "name": {"en": "Interceptor Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1490	4243	{"_key": 4243, "name": {"en": "Logistics Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1491	4244	{"_key": 4244, "name": {"en": "Force Recon Ship Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1492	4245	{"_key": 4245, "name": {"en": "Stealth Bomber Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1493	4246	{"_key": 4246, "name": {"en": "Capital Industrial Ship Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1494	4247	{"_key": 4247, "name": {"en": "Electronic Attack Ship Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1495	4248	{"_key": 4248, "name": {"en": "Heavy Interdiction Cruiser Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1496	4249	{"_key": 4249, "name": {"en": "Black Ops Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1497	4250	{"_key": 4250, "name": {"en": "Marauder Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1498	4251	{"_key": 4251, "name": {"en": "Jump Freighter Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1499	4252	{"_key": 4252, "name": {"en": "Combat Recon Ship Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1500	4253	{"_key": 4253, "name": {"en": "Industrial Command Ship Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1501	4254	{"_key": 4254, "name": {"en": "Strategic Cruiser Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1502	4255	{"_key": 4255, "name": {"en": "Salvager Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1503	4256	{"_key": 4256, "name": {"en": "Armor Resistance Shift Hardener Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1504	4257	{"_key": 4257, "name": {"en": "Signature Suppressor Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1505	4258	{"_key": 4258, "name": {"en": "Ancillary Shield Booster Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1506	4259	{"_key": 4259, "name": {"en": "Micro Jump Drive Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": true, "fittableNonSingleton": false}
1507	4260	{"_key": 4260, "name": {"en": "Ancillary Armor Repairer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1508	4261	{"_key": 4261, "name": {"en": "Scanning Upgrade Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1509	4262	{"_key": 4262, "name": {"en": "Survey Probe Launcher Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1510	4263	{"_key": 4263, "name": {"en": "Rig Resource Processing Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1511	4264	{"_key": 4264, "name": {"en": "Rig Scanning Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1512	4265	{"_key": 4265, "name": {"en": "Rig Targeting Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1513	4266	{"_key": 4266, "name": {"en": "Scanning Upgrade Time Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1514	4267	{"_key": 4267, "name": {"en": "Missile Launcher Rapid Heavy Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1515	4268	{"_key": 4268, "name": {"en": "Warp Accelerator Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1516	4269	{"_key": 4269, "name": {"en": "Drone Tracking Enhancer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1517	4270	{"_key": 4270, "name": {"en": "Jump Drive Economizer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1518	4271	{"_key": 4271, "name": {"en": "Ship Modifiers Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1519	4272	{"_key": 4272, "name": {"en": "Rig Anchor Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1520	4273	{"_key": 4273, "name": {"en": "Entosis Link Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1521	4274	{"_key": 4274, "name": {"en": "Missile Guidance Enhancer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1522	4275	{"_key": 4275, "name": {"en": "Missile Guidance Computer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1523	4276	{"_key": 4276, "name": {"en": "Micro Jump Field Generators Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1524	4277	{"_key": 4277, "name": {"en": "Stasis Grappler Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1525	4278	{"_key": 4278, "name": {"en": "Missile Launcher Rapid Torpedo Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1526	4279	{"_key": 4279, "name": {"en": "Missile Launcher XL Cruise Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1527	4280	{"_key": 4280, "name": {"en": "Ancillary Remote Shield Booster Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1528	4281	{"_key": 4281, "name": {"en": "Ancillary Remote Armor Repairer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1529	4282	{"_key": 4282, "name": {"en": "Flex Armor Hardener Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1530	4283	{"_key": 4283, "name": {"en": "Flex Shield Hardener Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1531	4284	{"_key": 4284, "name": {"en": "Capital Sensor Array Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1532	4285	{"_key": 4285, "name": {"en": "Command Burst Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1533	4286	{"_key": 4286, "name": {"en": "Titan Phenomena Generator Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1534	4287	{"_key": 4287, "name": {"en": "Non-Repeating Hardeners Refurbish Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1535	4288	{"_key": 4288, "name": {"en": "Abyssal Modules Refurbish Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1536	4289	{"_key": 4289, "name": {"en": "Precursor Weapon Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1537	4290	{"_key": 4290, "name": {"en": "Entropic Radiation Sink Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1538	4291	{"_key": 4291, "name": {"en": "Citizen Modules Refurbish Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1539	4292	{"_key": 4292, "name": {"en": "Citizen Mining Laser Refurbish Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1540	4293	{"_key": 4293, "name": {"en": "Mass Entanglers Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1541	4294	{"_key": 4294, "name": {"en": "ECM Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1542	4295	{"_key": 4295, "name": {"en": "Stasis Nullifiers Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1543	4296	{"_key": 4296, "name": {"en": "Mutadaptive Remote Armor Repairer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1544	4297	{"_key": 4297, "name": {"en": "ECCM Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1545	4298	{"_key": 4298, "name": {"en": "Sensor Backup Array Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1546	4299	{"_key": 4299, "name": {"en": "Heat Sink Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1547	4300	{"_key": 4300, "name": {"en": "Sensor Dampener Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1548	4301	{"_key": 4301, "name": {"en": "Remote Tracking Computer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1549	4302	{"_key": 4302, "name": {"en": "Signal Amplifier Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1550	4303	{"_key": 4303, "name": {"en": "Tracking Enhancer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1551	4304	{"_key": 4304, "name": {"en": "Sensor Booster Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1552	4305	{"_key": 4305, "name": {"en": "Tracking Computer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": true, "fittableNonSingleton": false}
1553	4306	{"_key": 4306, "name": {"en": "CPU Enhancer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1554	4307	{"_key": 4307, "name": {"en": "Projected ECCM Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1555	4308	{"_key": 4308, "name": {"en": "Remote Sensor Booster Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1556	4309	{"_key": 4309, "name": {"en": "Weapon Disruptor Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1557	4310	{"_key": 4310, "name": {"en": "Shield Resistance Amplifier Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1558	4311	{"_key": 4311, "name": {"en": "Magnetic Field Stabilizer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1559	4312	{"_key": 4312, "name": {"en": "Countermeasure Launcher Refurbish Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1560	4313	{"_key": 4313, "name": {"en": "Warp Core Stabilizer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1561	4314	{"_key": 4314, "name": {"en": "Gang Coordinator Refurbish Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1562	4315	{"_key": 4315, "name": {"en": "Remote Armor Repairer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1563	4316	{"_key": 4316, "name": {"en": "Energized Armor Membrane Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1564	4317	{"_key": 4317, "name": {"en": "Armor Hardener Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1565	4318	{"_key": 4318, "name": {"en": "Armor Plate Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1566	4319	{"_key": 4319, "name": {"en": "Cloaking Device Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1567	4320	{"_key": 4320, "name": {"en": "Shield Boost Amplifier Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1568	4321	{"_key": 4321, "name": {"en": "Auxiliary Power Core Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1569	4322	{"_key": 4322, "name": {"en": "Signature Scrambling Refurbish Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1570	4323	{"_key": 4323, "name": {"en": "QA Module Refurbish Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1571	4324	{"_key": 4324, "name": {"en": "Ballistic Control system Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1572	4325	{"_key": 4325, "name": {"en": "Target Painter Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1573	4326	{"_key": 4326, "name": {"en": "Shield Extender Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1574	4327	{"_key": 4327, "name": {"en": "Shield Recharger Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1575	4328	{"_key": 4328, "name": {"en": "Vorton Projector Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1576	4329	{"_key": 4329, "name": {"en": "Vorton Projector Upgrade Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1577	4330	{"_key": 4330, "name": {"en": "Fighter Support Unit Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1578	4331	{"_key": 4331, "name": {"en": "Remote Shield Booster Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1579	4332	{"_key": 4332, "name": {"en": "Interdiction Nullifier Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1580	4333	{"_key": 4333, "name": {"en": "Covert Jump Portal Generator Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1581	4334	{"_key": 4334, "name": {"en": "Group 4129 Refurbish Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1582	4335	{"_key": 4335, "name": {"en": "Gas Cloud Harvesters Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1583	4336	{"_key": 4336, "name": {"en": "Compressors Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": true, "fittableNonSingleton": false}
1584	4337	{"_key": 4337, "name": {"en": "Industrial Jump Portal Generator Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1585	4338	{"_key": 4338, "name": {"en": "Capacitor Recharger Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1586	4339	{"_key": 4339, "name": {"en": "Propulsion Module Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1587	4340	{"_key": 4340, "name": {"en": "Strip Miner Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1588	4341	{"_key": 4341, "name": {"en": "Cargo Scanner Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1589	4342	{"_key": 4342, "name": {"en": "System Scanner Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1590	4343	{"_key": 4343, "name": {"en": "Ship Scanner Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1591	4344	{"_key": 4344, "name": {"en": "Scan Probe Launcher Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1592	4345	{"_key": 4345, "name": {"en": "Frequency Mining Laser Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1593	4346	{"_key": 4346, "name": {"en": "Survey Scanner Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1594	4347	{"_key": 4347, "name": {"en": "Festival Launcher Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1595	4348	{"_key": 4348, "name": {"en": "Missile Launcher Cruise Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1596	4349	{"_key": 4349, "name": {"en": "Missile Launcher Rocket Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1597	4350	{"_key": 4350, "name": {"en": "Missile Launcher Torpedo Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1598	4351	{"_key": 4351, "name": {"en": "Missile Launcher Light Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1599	4352	{"_key": 4352, "name": {"en": "Missile Launcher Heavy Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1600	4353	{"_key": 4353, "name": {"en": "Missile Launcher Rapid Light Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1601	4354	{"_key": 4354, "name": {"en": "Missile Launcher Defender Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1602	4355	{"_key": 4355, "name": {"en": "ECM Stabilizer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1603	4356	{"_key": 4356, "name": {"en": "Siege Module Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1604	4357	{"_key": 4357, "name": {"en": "Warp Scrambler Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1605	4358	{"_key": 4358, "name": {"en": "Missile Launcher XL Torpedo Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1606	4359	{"_key": 4359, "name": {"en": "Energy Weapon Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1607	4360	{"_key": 4360, "name": {"en": "Data Miners Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1608	4361	{"_key": 4361, "name": {"en": "Mining Laser Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1609	4362	{"_key": 4362, "name": {"en": "Mining Upgrade Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1610	4363	{"_key": 4363, "name": {"en": "Projectile Weapon Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1611	4364	{"_key": 4364, "name": {"en": "Shield Power Relay Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1612	4365	{"_key": 4365, "name": {"en": "Remote Hull Repairer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1613	4366	{"_key": 4366, "name": {"en": "Super Weapon Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1614	4367	{"_key": 4367, "name": {"en": "Interdiction Sphere Launcher Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1615	4368	{"_key": 4368, "name": {"en": "Gyrostabilizer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1616	4369	{"_key": 4369, "name": {"en": "Jump Portal Generator Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1617	4370	{"_key": 4370, "name": {"en": "Damage Control Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1618	4371	{"_key": 4371, "name": {"en": "Capacitor Battery Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1619	4372	{"_key": 4372, "name": {"en": "Armor Repair Unit Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1620	4373	{"_key": 4373, "name": {"en": "Hull Repair Unit Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1621	4374	{"_key": 4374, "name": {"en": "Drone Navigation Computer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1622	4375	{"_key": 4375, "name": {"en": "Drone Damage Modules Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1623	4376	{"_key": 4376, "name": {"en": "Drone Tracking Modules Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1624	4377	{"_key": 4377, "name": {"en": "Drone Control Range Module Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1625	4378	{"_key": 4378, "name": {"en": "Stasis Web Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1626	4379	{"_key": 4379, "name": {"en": "Tractor Beam Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1627	4380	{"_key": 4380, "name": {"en": "Cynosural Field Generator Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1628	4381	{"_key": 4381, "name": {"en": "Remote Capacitor Transmitter Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1629	4382	{"_key": 4382, "name": {"en": "Energy Nosferatu Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1630	4383	{"_key": 4383, "name": {"en": "Energy Neutralizer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1631	4384	{"_key": 4384, "name": {"en": "Smart Bomb Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1632	4385	{"_key": 4385, "name": {"en": "Gas Cloud Scoops Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1633	4386	{"_key": 4386, "name": {"en": "Hybrid Weapon Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1634	4387	{"_key": 4387, "name": {"en": "Capacitor Booster Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1635	4388	{"_key": 4388, "name": {"en": "Inertial Stabilizer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1636	4389	{"_key": 4389, "name": {"en": "Nanofiber Internal Structure Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1637	4390	{"_key": 4390, "name": {"en": "Overdrive Injector System Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1638	4391	{"_key": 4391, "name": {"en": "Expanded Cargohold Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1639	4392	{"_key": 4392, "name": {"en": "Power Diagnostic System Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1640	4393	{"_key": 4393, "name": {"en": "Capacitor Power Relay Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1641	4394	{"_key": 4394, "name": {"en": "Capacitor Flux Coil Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1642	4395	{"_key": 4395, "name": {"en": "Reactor Control Unit Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1643	4396	{"_key": 4396, "name": {"en": "Shield Hardener Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1644	4397	{"_key": 4397, "name": {"en": "Shield Flux Coil Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1645	4398	{"_key": 4398, "name": {"en": "Missile Launcher Heavy Assault Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1646	4399	{"_key": 4399, "name": {"en": "Rig Armor Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1647	4400	{"_key": 4400, "name": {"en": "Rig Shield Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1648	4401	{"_key": 4401, "name": {"en": "Rig Energy Weapon Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1649	4402	{"_key": 4402, "name": {"en": "Rig Hybrid Weapon Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1650	4403	{"_key": 4403, "name": {"en": "Rig Projectile Weapon Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1651	4404	{"_key": 4404, "name": {"en": "Rig Drones Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1652	4405	{"_key": 4405, "name": {"en": "Rig Launcher Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1653	4406	{"_key": 4406, "name": {"en": "Reinforced Bulkhead Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1654	4407	{"_key": 4407, "name": {"en": "Rig Core Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1655	4408	{"_key": 4408, "name": {"en": "Rig Navigation Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1656	4409	{"_key": 4409, "name": {"en": "Rig Electronic Systems Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1657	4410	{"_key": 4410, "name": {"en": "Burst Jammer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1658	4411	{"_key": 4411, "name": {"en": "Clone Vat Bay Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1659	4412	{"_key": 4412, "name": {"en": "Passive Targeting System Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1660	4413	{"_key": 4413, "name": {"en": "Burst Projectors Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1661	4414	{"_key": 4414, "name": {"en": "Missile Launcher Bomb Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1662	4415	{"_key": 4415, "name": {"en": "Warp Disrupt Field Generator Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1663	4416	{"_key": 4416, "name": {"en": "Rig Mining Refurbish Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1664	4417	{"_key": 4417, "name": {"en": "Automated Targeting System Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1665	4418	{"_key": 4418, "name": {"en": "Armor Coating Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1666	4419	{"_key": 4419, "name": {"en": "Combat Drone Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1667	4420	{"_key": 4420, "name": {"en": "Mining Drone Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1668	4421	{"_key": 4421, "name": {"en": "Salvage Drone Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1669	4422	{"_key": 4422, "name": {"en": "Repair Drone Refurbish Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1670	4423	{"_key": 4423, "name": {"en": "Unanchoring Drone Refurbish Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1671	4424	{"_key": 4424, "name": {"en": "Energy Neutralizer Drone Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1672	4425	{"_key": 4425, "name": {"en": "Warp Scrambling Drone Refurbish Component"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1673	4426	{"_key": 4426, "name": {"en": "Electronic Warfare Drone Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1674	4427	{"_key": 4427, "name": {"en": "Logistic Drone Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1675	4428	{"_key": 4428, "name": {"en": "Stasis Webifying Drone Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1676	4429	{"_key": 4429, "name": {"en": "Multi-Platform Strike Cruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
1677	4430	{"_key": 4430, "name": {"en": "Asteroid Belt"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1678	4431	{"_key": 4431, "name": {"en": "FW Amarr Empire Battleship"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1679	4432	{"_key": 4432, "name": {"en": "FW Caldari State Battleship"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1680	4433	{"_key": 4433, "name": {"en": "FW Gallente Federation Battleship"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1681	4434	{"_key": 4434, "name": {"en": "FW Minmatar Republic Battleship"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1682	4436	{"_key": 4436, "name": {"en": "Multi-Platform Strike Battleship"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
1683	4445	{"_key": 4445, "name": {"en": "Skill Licences"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 20, "useBasePrice": false, "fittableNonSingleton": false}
1684	4446	{"_key": 4446, "name": {"en": "Skill Licences"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1685	4471	{"_key": 4471, "name": {"en": "Ship Emblems"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2118, "useBasePrice": false, "fittableNonSingleton": false}
1686	4477	{"_key": 4477, "name": {"en": "FW Propaganda Broadcast Structure"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 22, "useBasePrice": true, "fittableNonSingleton": false}
1687	4478	{"_key": 4478, "name": {"en": "Arena Ships"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
1688	4479	{"_key": 4479, "name": {"en": "Arena Weapons Projectile"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1689	4480	{"_key": 4480, "name": {"en": "Arena Projectile S"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1690	4481	{"_key": 4481, "name": {"en": "Arena Crystal S"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1691	4482	{"_key": 4482, "name": {"en": "Arena Hybrid S"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1692	4483	{"_key": 4483, "name": {"en": "Arena Weapons Laser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1693	4484	{"_key": 4484, "name": {"en": "Arena Weapons Hybrid"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1694	4485	{"_key": 4485, "name": {"en": "Arena Utility Module"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1695	4486	{"_key": 4486, "name": {"en": "Arena Propulsion Module"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1696	4487	{"_key": 4487, "name": {"en": "Arena Cap Booster"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1697	4488	{"_key": 4488, "name": {"en": "Arena Backup Charge"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1698	4489	{"_key": 4489, "name": {"en": "Arena Shield Boost"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1699	4490	{"_key": 4490, "name": {"en": "Arena Weapon Upgrade"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1700	4491	{"_key": 4491, "name": {"en": "Arena Armor Plates"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1701	4492	{"_key": 4492, "name": {"en": "Arena Ship Upgrade"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1702	4493	{"_key": 4493, "name": {"en": "Mobile Objective Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1703	4494	{"_key": 4494, "name": {"en": "Control Point"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1704	4495	{"_key": 4495, "name": {"en": "Defensive Subsystem Refurbishment Components"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1705	4496	{"_key": 4496, "name": {"en": "Offensive Subsystem Refurbishment Components"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1706	4497	{"_key": 4497, "name": {"en": "Core Subsystem Refurbishment Components"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1707	4498	{"_key": 4498, "name": {"en": "Propulsion Subsystem Refurbishment Components"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1708	4499	{"_key": 4499, "name": {"en": "FW Listening Outpost"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 22, "useBasePrice": true, "fittableNonSingleton": false}
1709	4500	{"_key": 4500, "name": {"en": "Brawl Cloud"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1710	4501	{"_key": 4501, "name": {"en": "Mission Generic Capsules"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1711	4504	{"_key": 4504, "name": {"en": "Brawl Collectible Cloud"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1712	4506	{"_key": 4506, "name": {"en": "Chest"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1713	4513	{"_key": 4513, "name": {"en": "Mordunium"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1714	4514	{"_key": 4514, "name": {"en": "Ytirium"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1715	4515	{"_key": 4515, "name": {"en": "Eifyrium"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1716	4516	{"_key": 4516, "name": {"en": "Ducinium"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1717	4536	{"_key": 4536, "name": {"en": "Brawl Dungeon Guard"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1718	4537	{"_key": 4537, "name": {"en": "StarSetModule"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1719	4538	{"_key": 4538, "name": {"en": "Brawl Killing Medal"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1720	4539	{"_key": 4539, "name": {"en": "StructureSkin"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1721	4545	{"_key": 4545, "name": {"en": "Capital Propulsion Engine Polarization Module"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": true, "fittableNonSingleton": false}
1722	4546	{"_key": 4546, "name": {"en": "Capital Propulsion Engine Polarization Module Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1723	4547	{"_key": 4547, "name": {"en": "Interstellar Shipcaster Beacon"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1724	4548	{"_key": 4548, "name": {"en": "Shipcaster Beacon Constructor"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1725	4549	{"_key": 4549, "name": {"en": "Interstellar Shipcaster"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1726	4564	{"_key": 4564, "name": {"en": "Capital Propulsion Engine Polarization Module Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1727	4566	{"_key": 4566, "name": {"en": "★Missing Hauler"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1728	4567	{"_key": 4567, "name": {"en": "★Missing Freighter"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1729	4568	{"_key": 4568, "name": {"en": "Mutanite"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": true, "fittableNonSingleton": false}
1730	4569	{"_key": 4569, "name": {"en": "Homefront Operations Enemy Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1731	4570	{"_key": 4570, "name": {"en": "Homefront Operations Enemy Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1732	4571	{"_key": 4571, "name": {"en": "Homefront Operations Enemy Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1733	4572	{"_key": 4572, "name": {"en": "Homefront Operations Allied Dreadnought"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1734	4573	{"_key": 4573, "name": {"en": "Homefront Operations Enemy Battlecruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1735	4574	{"_key": 4574, "name": {"en": "Homefront Operations Enemy Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1736	4575	{"_key": 4575, "name": {"en": "Homefront Operations Commodity"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1737	4576	{"_key": 4576, "name": {"en": "Homefront Operations Structure"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1738	4577	{"_key": 4577, "name": {"en": "Homefront Operations Hauler"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1739	4578	{"_key": 4578, "name": {"en": "Crossover Roaming Enemies Light"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1740	4579	{"_key": 4579, "name": {"en": "Scalable Non-Interactable Object"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1741	4580	{"_key": 4580, "name": {"en": "GachaTicketInjector"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1742	4594	{"_key": 4594, "name": {"en": "Lancer Dreadnought"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
1743	4599	{"_key": 4599, "name": {"en": "Warp Vector Data"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1744	4603	{"_key": 4603, "name": {"en": "FOB services"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 66, "useBasePrice": false, "fittableNonSingleton": false}
1745	4604	{"_key": 4604, "name": {"en": "Refinery Skin"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2125, "useBasePrice": false, "fittableNonSingleton": false}
1746	4605	{"_key": 4605, "name": {"en": "Engineering Complex Skin"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2125, "useBasePrice": false, "fittableNonSingleton": false}
1747	4606	{"_key": 4606, "name": {"en": "Citadel Skin"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2125, "useBasePrice": false, "fittableNonSingleton": false}
1748	4607	{"_key": 4607, "name": {"en": "Cyno Beacon Skin"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2125, "useBasePrice": false, "fittableNonSingleton": false}
1749	4622	{"_key": 4622, "name": {"en": "Colossus"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
1750	4632	{"_key": 4632, "name": {"en": "Amplification Matrix"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2126, "useBasePrice": false, "fittableNonSingleton": false}
1751	4636	{"_key": 4636, "name": {"en": "Pirate Entities"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1752	4637	{"_key": 4637, "name": {"en": "Insurgency Roaming Pirates"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1753	4638	{"_key": 4638, "name": {"en": "Insurgency Roaming Enforcers"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1754	4641	{"_key": 4641, "name": {"en": "Amplification Matrix Materials"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2127, "useBasePrice": false, "fittableNonSingleton": false}
1755	4642	{"_key": 4642, "name": {"en": "GachaTicketForGachaServer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1756	4643	{"_key": 4643, "name": {"en": "Self-Choose Chest"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2128, "useBasePrice": false, "fittableNonSingleton": false}
1757	4644	{"_key": 4644, "name": {"en": "Pirate Forward Operating Base"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 65, "useBasePrice": false, "fittableNonSingleton": false}
1758	4647	{"_key": 4647, "name": {"en": "Insurgency Pirate Frigate"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1759	4648	{"_key": 4648, "name": {"en": "Insurgency Pirate Destroyer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1760	4649	{"_key": 4649, "name": {"en": "Insurgency Pirate Cruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1761	4650	{"_key": 4650, "name": {"en": "Insurgency Pirate Battlecruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1762	4651	{"_key": 4651, "name": {"en": "Insurgency Pirate Battleship"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1763	4652	{"_key": 4652, "name": {"en": "Insurgency Mordu Frigate"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1764	4653	{"_key": 4653, "name": {"en": "Insurgency Mordu Destroyer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1765	4654	{"_key": 4654, "name": {"en": "Insurgency Mordu Cruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1766	4655	{"_key": 4655, "name": {"en": "Insurgency Mordu Battlecruiser"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1767	4656	{"_key": 4656, "name": {"en": "Insurgency Mordu Battleship"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1768	4669	{"_key": 4669, "name": {"en": "Amplification Matrix quality 2"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2126, "useBasePrice": false, "fittableNonSingleton": false}
1769	4670	{"_key": 4670, "name": {"en": "Amplification Matrix quality 3"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2126, "useBasePrice": false, "fittableNonSingleton": false}
1770	4671	{"_key": 4671, "name": {"en": "Amplification Matrix quality 4"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2126, "useBasePrice": false, "fittableNonSingleton": false}
1771	4672	{"_key": 4672, "name": {"en": "Exp Amplification Matrix"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2126, "useBasePrice": false, "fittableNonSingleton": false}
1772	4673	{"_key": 4673, "name": {"en": "Insurgency Mining Ship"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1773	4709	{"_key": 4709, "name": {"en": "Colossus Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1774	4712	{"_key": 4712, "name": {"en": "Guided Entities"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1775	4713	{"_key": 4713, "name": {"en": "Guidance Objectives"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1776	4714	{"_key": 4714, "name": {"en": "Non-Interactable Asteroids"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1777	4716	{"_key": 4716, "name": {"en": "Abyssal Battlefield Filament Materials"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1778	4717	{"_key": 4717, "name": {"en": "CD Filaments"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1779	4719	{"_key": 4719, "name": {"en": "Rift"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1780	4723	{"_key": 4723, "name": {"en": "Amplification Matrix Fragment"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2126, "useBasePrice": false, "fittableNonSingleton": false}
1781	4725	{"_key": 4725, "name": {"en": "Sequence Binders"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2118, "useBasePrice": false, "fittableNonSingleton": false}
1782	4726	{"_key": 4726, "name": {"en": "Ship SKIN Design Element"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2118, "useBasePrice": false, "fittableNonSingleton": false}
1783	4729	{"_key": 4729, "name": {"en": "Colony Reagents"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2143, "useBasePrice": true, "fittableNonSingleton": false}
1784	4734	{"_key": 4734, "name": {"en": "Sequencing"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 16, "useBasePrice": true, "fittableNonSingleton": false}
1785	4736	{"_key": 4736, "name": {"en": "Skyhook"}, "anchored": false, "published": true, "anchorable": true, "categoryID": 46, "useBasePrice": false, "fittableNonSingleton": false}
1786	4737	{"_key": 4737, "name": {"en": "Homefront Operations Shuttle"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1787	4742	{"_key": 4742, "name": {"en": "Bluebird Material Ticket"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1788	4743	{"_key": 4743, "name": {"en": "Abyssal Battlefield Filaments"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1789	4744	{"_key": 4744, "name": {"en": "Upwell Moon Drill"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 65, "useBasePrice": false, "fittableNonSingleton": false}
1790	4745	{"_key": 4745, "name": {"en": "Skyhook Reagent Silo"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1791	4755	{"_key": 4755, "name": {"en": "Kylixium"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1792	4756	{"_key": 4756, "name": {"en": "Nocxite"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1793	4757	{"_key": 4757, "name": {"en": "Ueganite"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1794	4758	{"_key": 4758, "name": {"en": "Hezorime"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1795	4759	{"_key": 4759, "name": {"en": "Griemeer"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1796	4768	{"_key": 4768, "name": {"en": "Sovereignty Hub Site Detection Upgrades"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 39, "useBasePrice": true, "fittableNonSingleton": false}
1797	4769	{"_key": 4769, "name": {"en": "Capital Mobility Modules"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1798	4771	{"_key": 4771, "name": {"en": "Homefront Operations Noncombatant"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1799	4772	{"_key": 4772, "name": {"en": "Sovereignty Hub Service Infrastructure Upgrade"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 39, "useBasePrice": true, "fittableNonSingleton": false}
1800	4776	{"_key": 4776, "name": {"en": "Expired Abyssal Battlefields Filaments"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1801	4777	{"_key": 4777, "name": {"en": "Structure Light Fighter"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 87, "useBasePrice": false, "fittableNonSingleton": false}
1802	4778	{"_key": 4778, "name": {"en": "Structure Support Fighter"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 87, "useBasePrice": false, "fittableNonSingleton": false}
1803	4779	{"_key": 4779, "name": {"en": "Structure Heavy Fighter"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 87, "useBasePrice": false, "fittableNonSingleton": false}
1804	4784	{"_key": 4784, "name": {"en": "Rig Precursor Weapon"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1805	4786	{"_key": 4786, "name": {"en": "Rig Precursor Weapon Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1806	4789	{"_key": 4789, "name": {"en": "Rig Overheat Remover Precursor"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1807	4791	{"_key": 4791, "name": {"en": "Alpha City Material"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 4, "useBasePrice": true, "fittableNonSingleton": false}
1808	4792	{"_key": 4792, "name": {"en": "Crossover Roaming Enemies Medium"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1809	4795	{"_key": 4795, "name": {"en": "Asteroid Angel Cartel Officer Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1810	4796	{"_key": 4796, "name": {"en": "Asteroid Angel Cartel Officer Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1811	4797	{"_key": 4797, "name": {"en": "Asteroid Blood Raiders Officer Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1812	4798	{"_key": 4798, "name": {"en": "Asteroid Blood Raiders Officer Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1813	4799	{"_key": 4799, "name": {"en": "Asteroid Guristas Officer Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1814	4800	{"_key": 4800, "name": {"en": "Asteroid Guristas Officer Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1815	4801	{"_key": 4801, "name": {"en": "Asteroid Sansha's Nation Officer Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1816	4802	{"_key": 4802, "name": {"en": "Asteroid Sansha's Nation Officer Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1817	4803	{"_key": 4803, "name": {"en": "Asteroid Serpentis Officer Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1818	4804	{"_key": 4804, "name": {"en": "Asteroid Serpentis Officer Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1819	4807	{"_key": 4807, "name": {"en": "Breacher Pod Launchers"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1820	4808	{"_key": 4808, "name": {"en": "SCARAB Breacher Pods"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1821	4809	{"_key": 4809, "name": {"en": "Capital Mobility Modules Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1822	4810	{"_key": 4810, "name": {"en": "Mercenary Den"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 22, "useBasePrice": false, "fittableNonSingleton": false}
1823	4811	{"_key": 4811, "name": {"en": "Mercenary Den Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1824	4815	{"_key": 4815, "name": {"en": "Defender Mordu Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1825	4816	{"_key": 4816, "name": {"en": "Defender Mordu Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1826	4817	{"_key": 4817, "name": {"en": "Defender Mordu Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1827	4820	{"_key": 4820, "name": {"en": "Mutaplasmid Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1828	4821	{"_key": 4821, "name": {"en": "Atavum"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1829	4824	{"_key": 4824, "name": {"en": "Infomorph Systems"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1830	4825	{"_key": 4825, "name": {"en": "Local Beacon"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1831	4826	{"_key": 4826, "name": {"en": "Blue Drone Components"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 4, "useBasePrice": true, "fittableNonSingleton": false}
1832	4827	{"_key": 4827, "name": {"en": "EDENCOM Data"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1833	4828	{"_key": 4828, "name": {"en": "Pirate Spawners"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1834	4829	{"_key": 4829, "name": {"en": "Breacher Pod Launchers Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1835	4838	{"_key": 4838, "name": {"en": "Sovereignty Hub Colony Resources Management Upgrades"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 39, "useBasePrice": true, "fittableNonSingleton": false}
1836	4839	{"_key": 4839, "name": {"en": "Sovereignty Hub System Effect Generator Upgrades"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 39, "useBasePrice": true, "fittableNonSingleton": false}
1837	4843	{"_key": 4843, "name": {"en": "Limited Rarities"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1838	4857	{"_key": 4857, "name": {"en": "Tyranite"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1839	4900	{"_key": 4900, "name": {"en": "Stability Telemetry"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1840	4901	{"_key": 4901, "name": {"en": "adaption chips injector"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": false, "fittableNonSingleton": false}
1841	4902	{"_key": 4902, "name": {"en": "Expedition Command Ship"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
1842	4903	{"_key": 4903, "name": {"en": "Armor Plate Enforcer"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 7, "useBasePrice": false, "fittableNonSingleton": false}
1843	4904	{"_key": 4904, "name": {"en": "Armor Plate Enforcer Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1844	4905	{"_key": 4905, "name": {"en": "Expedition Command Burst Charges"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 8, "useBasePrice": false, "fittableNonSingleton": true}
1845	4906	{"_key": 4906, "name": {"en": "Expedition Command Ship Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1846	4909	{"_key": 4909, "name": {"en": "Vanguard Entities"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1847	4910	{"_key": 4910, "name": {"en": "Armor Plate Enforcer Refurbish Component"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 2113, "useBasePrice": false, "fittableNonSingleton": false}
1848	4913	{"_key": 4913, "name": {"en": "Mobile Phase Anchor"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 22, "useBasePrice": false, "fittableNonSingleton": false}
1849	4914	{"_key": 4914, "name": {"en": "Mobile Phase Anchor Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1850	4915	{"_key": 4915, "name": {"en": "Prismaticite"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 4, "useBasePrice": false, "fittableNonSingleton": false}
1851	4916	{"_key": 4916, "name": {"en": "Phased Asteroid"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2152, "useBasePrice": false, "fittableNonSingleton": false}
1852	4917	{"_key": 4917, "name": {"en": "♦ Industrial Command Ship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1853	4918	{"_key": 4918, "name": {"en": "Phased Asteroid"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1854	4919	{"_key": 4919, "name": {"en": "DHH General Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1855	4920	{"_key": 4920, "name": {"en": "DHH Elite Drone"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1856	4924	{"_key": 4924, "name": {"en": "Erratic Ore Formula"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1857	4930	{"_key": 4930, "name": {"en": "Managed Asteroid Belt"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1858	4932	{"_key": 4932, "name": {"en": "Unrefined Mineral"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 4, "useBasePrice": true, "fittableNonSingleton": false}
1859	4935	{"_key": 4935, "name": {"en": "Ice Belt"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1860	4936	{"_key": 4936, "name": {"en": "Phased Asteroid Field"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1861	4937	{"_key": 4937, "name": {"en": "Rare Asteroid Field"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1862	4938	{"_key": 4938, "name": {"en": "Ore Deposit"}, "anchored": true, "published": false, "anchorable": false, "categoryID": 2, "useBasePrice": false, "fittableNonSingleton": false}
1863	4939	{"_key": 4939, "name": {"en": "Mobile Environment Generator"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 22, "useBasePrice": false, "fittableNonSingleton": false}
1864	4941	{"_key": 4941, "name": {"en": "QA Phased Asteroids"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 2152, "useBasePrice": false, "fittableNonSingleton": false}
1865	4945	{"_key": 4945, "name": {"en": "Irregular Expedition Command Ship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1866	4947	{"_key": 4947, "name": {"en": "Mobile Environment Generator Blueprint"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 9, "useBasePrice": true, "fittableNonSingleton": false}
1867	4948	{"_key": 4948, "name": {"en": "Ancient Drone Components"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 4, "useBasePrice": true, "fittableNonSingleton": false}
1868	4949	{"_key": 4949, "name": {"en": "InterBus Yoiul LADs"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1869	4972	{"_key": 4972, "name": {"en": "Verity Cryo Tech"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1870	4975	{"_key": 4975, "name": {"en": "Irregular Capital Industrial Ship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1871	5032	{"_key": 5032, "name": {"en": "Fabricator Rogue Drone Frigate"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1872	5063	{"_key": 5063, "name": {"en": "FW Amarr Empire Hauler"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1873	5064	{"_key": 5064, "name": {"en": "FW Caldari State Hauler"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1874	5065	{"_key": 5065, "name": {"en": "FW Gallente Federation Hauler"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1875	5066	{"_key": 5066, "name": {"en": "FW Minmatar Republic Hauler"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1876	5067	{"_key": 5067, "name": {"en": "Fabricator Data"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1877	5068	{"_key": 5068, "name": {"en": "Vigilance Point Data"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 17, "useBasePrice": true, "fittableNonSingleton": false}
1878	5078	{"_key": 5078, "name": {"en": "Moreau’s Capsuleer Outreach Center Entities"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1879	5079	{"_key": 5079, "name": {"en": "Tenzin’s Capsuleer Outreach Center Entities"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1880	5080	{"_key": 5080, "name": {"en": "Roden’s Capsuleer Outreach Center Entities"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1881	5082	{"_key": 5082, "name": {"en": "Portrait Backgrounds"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 30, "useBasePrice": false, "fittableNonSingleton": false}
1882	5083	{"_key": 5083, "name": {"en": "Raspite"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1883	5084	{"_key": 5084, "name": {"en": "Polycrase"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1884	5085	{"_key": 5085, "name": {"en": "Moissanite"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1885	5086	{"_key": 5086, "name": {"en": "Kangite"}, "anchored": true, "published": true, "anchorable": false, "categoryID": 25, "useBasePrice": false, "fittableNonSingleton": false}
1886	5087	{"_key": 5087, "name": {"en": "Special Edition Yachts"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
1887	5089	{"_key": 5089, "name": {"en": "Warpath Invaders - Battlecruisers"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1888	5090	{"_key": 5090, "name": {"en": "Warpath Defenders -  Battlecruisers"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1889	5096	{"_key": 5096, "name": {"en": "Warpath Elite Mercenaries - Battleships"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1890	5097	{"_key": 5097, "name": {"en": "Warpath Elite Mercenaries - Cruisers"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1891	5098	{"_key": 5098, "name": {"en": "Warpath Elite Mercenaries - Frigates"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1892	5099	{"_key": 5099, "name": {"en": "Warpath Defenders - Cruisers"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1893	5100	{"_key": 5100, "name": {"en": "Warpath Invaders - Cruisers"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1894	5101	{"_key": 5101, "name": {"en": "Warpath Defenders - Frigates"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1895	5102	{"_key": 5102, "name": {"en": "Warpath Invaders - Frigates"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1896	5119	{"_key": 5119, "name": {"en": "AIR Holo-Drone Actors"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1897	5120	{"_key": 5120, "name": {"en": "Command Carrier"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 6, "useBasePrice": false, "fittableNonSingleton": false}
1898	5122	{"_key": 5122, "name": {"en": "Fabricator Rogue Drone Destroyer"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1899	5123	{"_key": 5123, "name": {"en": "Fabricator Rogue Drone Cruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1900	5124	{"_key": 5124, "name": {"en": "Fabricator Rogue Drone Battlecruiser"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1901	5125	{"_key": 5125, "name": {"en": "Fabricator Rogue Drone Battleship"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1902	5154	{"_key": 5154, "name": {"en": "Fabricator Rogue Drone Dreadnought"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 11, "useBasePrice": false, "fittableNonSingleton": false}
1903	5201	{"_key": 5201, "name": {"en": "Mobile Advertise Screen"}, "anchored": false, "published": true, "anchorable": false, "categoryID": 22, "useBasePrice": false, "fittableNonSingleton": false}
1904	350858	{"_key": 350858, "name": {"en": "Infantry Weapons"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 350001, "useBasePrice": true, "fittableNonSingleton": false}
1905	351064	{"_key": 351064, "name": {"en": "Infantry Dropsuits"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 350001, "useBasePrice": true, "fittableNonSingleton": false}
1906	351121	{"_key": 351121, "name": {"en": "Infantry Modules"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 350001, "useBasePrice": true, "fittableNonSingleton": false}
1907	351210	{"_key": 351210, "name": {"en": "Infantry Vehicles"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 350001, "useBasePrice": true, "fittableNonSingleton": false}
1908	351648	{"_key": 351648, "name": {"en": "Infantry Skills"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 350001, "useBasePrice": true, "fittableNonSingleton": false}
1909	351844	{"_key": 351844, "name": {"en": "Infantry Equipment"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 350001, "useBasePrice": true, "fittableNonSingleton": false}
1910	354641	{"_key": 354641, "name": {"en": "Infantry Skill Enhancers"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 350001, "useBasePrice": true, "fittableNonSingleton": false}
1911	354753	{"_key": 354753, "name": {"en": "Infantry Installations"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 350001, "useBasePrice": true, "fittableNonSingleton": false}
1912	364204	{"_key": 364204, "name": {"en": "Surface Infrastructure"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 350001, "useBasePrice": true, "fittableNonSingleton": false}
1913	367487	{"_key": 367487, "name": {"en": "Services"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 350001, "useBasePrice": false, "fittableNonSingleton": false}
1914	367580	{"_key": 367580, "name": {"en": "Agents"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 350001, "useBasePrice": false, "fittableNonSingleton": false}
1915	367594	{"_key": 367594, "name": {"en": "Visual Customization"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 350001, "useBasePrice": true, "fittableNonSingleton": false}
1916	367774	{"_key": 367774, "name": {"en": "Salvage Containers"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 350001, "useBasePrice": false, "fittableNonSingleton": false}
1917	367776	{"_key": 367776, "name": {"en": "Salvage Decryptors"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 350001, "useBasePrice": false, "fittableNonSingleton": false}
1918	368656	{"_key": 368656, "name": {"en": "Battle Salvage"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 350001, "useBasePrice": true, "fittableNonSingleton": false}
1919	368666	{"_key": 368666, "name": {"en": "Warbarge"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 350001, "useBasePrice": true, "fittableNonSingleton": false}
1920	368726	{"_key": 368726, "name": {"en": "Infantry Color Skin"}, "anchored": false, "published": false, "anchorable": false, "categoryID": 350001, "useBasePrice": true, "fittableNonSingleton": false}
\.


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: sde_compat; Owner: -
--

ALTER TABLE ONLY sde_compat.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (row_no);


--
-- Name: groups_key_idx; Type: INDEX; Schema: sde_compat; Owner: -
--

CREATE INDEX groups_key_idx ON sde_compat.groups USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict 6rUDrntDrUO7y5O9SW3HgVjRlG4I4JF5hEgSqQEqD8XleNaYxXZOOCH4tquCxBm

