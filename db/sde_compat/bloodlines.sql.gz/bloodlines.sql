--
-- PostgreSQL database dump
--

\restrict LYBAhEqDO5vWeSYIQWXfrANFijvG4j2gt3aD9AUtwzuxPtQNtZ8wloCOrXOXU33

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bloodlines; Type: TABLE; Schema: sde_compat; Owner: -
--

CREATE TABLE sde_compat.bloodlines (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: bloodlines; Type: TABLE DATA; Schema: sde_compat; Owner: -
--

COPY sde_compat.bloodlines (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "name": {"en": "Deteis"}, "iconID": 1633, "memory": 7, "raceID": 1, "charisma": 6, "willpower": 5, "perception": 5, "description": {"en": "The Deteis are regarded as the face of leadership in Caldari society. Commonly possessed of sharp, ordered minds and articulate tongues, they are mostly found in positions of authority within military and political spheres. Driven by the cultural premise that the good of the whole must come before the needs of the individual, they have made the responsibility of upholding the integrity of the entire Caldari State their own."}, "intelligence": 7, "corporationID": 1000006}
1	2	{"_key": 2, "name": {"en": "Civire"}, "iconID": 1631, "memory": 4, "raceID": 1, "charisma": 6, "willpower": 6, "perception": 9, "description": {"en": "Whether engaged in trade or combat, the Civire are absolute masters of focused aggression. Highly competitive individuals, they thrive under chaotic circumstances and frenetic activity. They are often employed in highly stressful industrial and military professions due to an innate ability to think quickly on their feet and remain composed under pressure."}, "intelligence": 5, "corporationID": 1000009}
2	3	{"_key": 3, "name": {"en": "Sebiestor"}, "iconID": 1634, "memory": 6, "raceID": 2, "charisma": 6, "willpower": 6, "perception": 5, "description": {"en": "Widely respected as some of the cluster's most innovative thinkers, the Sebiestor are an ingenious people with a natural fondness for engineering. For the last millennium they have pioneered advances in applied sciences, despite laboring under chronic material shortages. Masters of deriving solutions from impossible circumstances, Sebiestor engineers believe they can build anything, with anything, out of anything."}, "intelligence": 7, "corporationID": 1000046}
3	4	{"_key": 4, "name": {"en": "Brutor"}, "iconID": 1635, "memory": 4, "raceID": 2, "charisma": 6, "willpower": 7, "perception": 9, "description": {"en": "A martial, strong-willed people, the Brutor hold their tribal heritage close to their hearts, and are renowned for living regimented, disciplined lives. Despite presenting a tough, no-nonsense exterior, they are deeply introspective, aware of even the smallest detail at all times. Immersed in ancient martial traditions that begin at childhood, they are physically robust individuals and intimidating to face in the flesh."}, "intelligence": 4, "corporationID": 1000049}
4	5	{"_key": 5, "name": {"en": "Amarr"}, "iconID": 1628, "memory": 6, "raceID": 4, "charisma": 3, "willpower": 10, "perception": 4, "description": {"en": "True Amarrians are proud and supercilious, with a great sense of tradition and ancestry. They are considered arrogant and tyrannical by most others. The Empire's defeat at the hands of the mysterious Jovians, and the Minmatar uprising that followed, left an indelible mark on Amarrian culture. This double failure, a turning point in their history, has shaped an entire generation of policy and philosophy among the imperial elite."}, "intelligence": 7, "corporationID": 1000066}
5	6	{"_key": 6, "name": {"en": "Ni-Kunni"}, "iconID": 1632, "memory": 6, "raceID": 4, "charisma": 8, "willpower": 4, "perception": 7, "description": {"en": "With the exception of the Khanid, the Ni-Kunni were assimilated into Amarr society far more easily than the majority of Amarrian conquests. Conquered more than 1000 years ago by the Amarr Empire, they are not generally considered “enslaved” anymore. Most Ni-Kunni are tradesmen and artisans - occupations traditionally eschewed by true Amarrians, but still considered a vital part of their society."}, "intelligence": 5, "corporationID": 1000072}
6	7	{"_key": 7, "name": {"en": "Gallente"}, "iconID": 1629, "memory": 4, "raceID": 8, "charisma": 8, "willpower": 4, "perception": 8, "description": {"en": "The Gallente value freedom and individual liberty above all else. Founders of the only true democracy of New Eden, they have created an ethnically diverse, culturally rich, progressive society that encourages enterprise and initiative in its citizens. While slow to anger and occasionally indecisive, they are also capable of harnessing enormous military and economic resolve when truly tested."}, "intelligence": 6, "corporationID": 1000107}
7	8	{"_key": 8, "name": {"en": "Intaki"}, "iconID": 1630, "memory": 7, "raceID": 8, "charisma": 6, "willpower": 6, "perception": 3, "description": {"en": "The Intaki are one of the largest ethnicities of the Federation. Exceedingly gifted communicators, they are prominent among the Federal bureaucracy. Though mostly assimilated into Gallente culture, they still cling to their own identities and beliefs, most notably their unusual theories regarding death and rebirth. These theories give them a unique outlook on life and the living, and many attribute the Intaki's stoic nature to this philosophy."}, "intelligence": 8, "corporationID": 1000111}
8	9	{"_key": 9, "name": {"en": "Static"}, "iconID": 0, "memory": 10, "raceID": 16, "charisma": 5, "willpower": 8, "perception": 7, "description": {"en": "The different branches of Jovians that exist are not the result of variations in geographical or climatic differences, but rather that of genetic engineering through the centuries. The Statics are one of the two main branches. Statics are generally introvert and prefer status quo, both socially and biologically. The Statics regard themselves as observers that should interfere as little as possible with the world. They believe that they are as genetically evolved as can be and generally frown upon large-scale genetic engineering programs."}, "intelligence": 10, "corporationID": 1000177}
9	10	{"_key": 10, "name": {"en": "Modifier"}, "iconID": 0, "memory": 7, "raceID": 16, "charisma": 7, "willpower": 9, "perception": 10, "description": {"en": "The different branches of Jovians that exist are not the result of variations in geographical or climatic differences, but rather that of genetic engineering through the centuries. The Modifiers are the enthusiasts of the Jovian family. They are curious and constantly willing to try or experience something new and fresh. Modifiers have lower life expectancy that other Jovians and are more susceptible to the dreaded Jovian Disease. It seems that by constantly living on the edge makes them burn out faster."}, "intelligence": 7, "corporationID": 1000178}
10	11	{"_key": 11, "name": {"en": "Achura"}, "iconID": 3022, "memory": 6, "raceID": 1, "charisma": 3, "willpower": 6, "perception": 7, "description": {"en": "Achura has been part of the Caldari State for three centuries, and yet their culture has always remained something of a mystery. Originally from the Saisio System, they are reclusive and introverted, and show little interest in the ephemeral phenomena of the material world. Intensely spiritual, Achura pilots have only recently taken to the stars, driven in large part by a desire to unlock the secrets of the universe."}, "intelligence": 8, "corporationID": 1000014}
11	12	{"_key": 12, "name": {"en": "Jin-Mei"}, "iconID": 3024, "memory": 5, "raceID": 8, "charisma": 7, "willpower": 7, "perception": 6, "description": {"en": "The nation of Jin-Mei is the latest addition to the Federation. They took to the stars comparatively late, as it took generations for them to transform their rigorous caste system enough for qualified people not to be excluded through class-based discrimination. Despite being at odds with the libertarian culture of the Gallente, the caste system has not been completely eliminated, nor is it likely to be further discouraged by the Federal government due to its cultural implications."}, "intelligence": 5, "corporationID": 1000114}
12	13	{"_key": 13, "name": {"en": "Khanid"}, "iconID": 3023, "memory": 4, "raceID": 4, "charisma": 5, "willpower": 8, "perception": 8, "description": {"en": "Swept up by the Amarr's message of faith during the original Reclaiming, the Khanid were for centuries exalted members of Amarr society, until a bitter feud between the Empire and a Khanid heir forced a secession which led to the creation of the independent Khanid Kingdom. The Khanid have since come back into the fold, bringing an infusion of cultural and technological knowledge into their ancestral Empire."}, "intelligence": 5, "corporationID": 1000080}
13	14	{"_key": 14, "name": {"en": "Vherokior"}, "iconID": 3021, "memory": 8, "raceID": 2, "charisma": 8, "willpower": 3, "perception": 4, "description": {"en": "Originally nomads in Matar's vast and inhospitable desert regions, the Vherokior are among the most diverse individuals of the Republic. They can be found in professions ranging from doctors to mystics, scholars to merchants. Their quiet work ethic and widespread family clans allow them unlimited social mobility in the Republic, with access to both the best and the worst that society has to offer."}, "intelligence": 7, "corporationID": 1000060}
14	19	{"_key": 19, "name": {"en": "Drifter"}, "iconID": 21404, "memory": 0, "raceID": 16, "charisma": 0, "willpower": 0, "perception": 0, "description": {"en": "By all appearances and indications the Drifters are members of the Jove race, albeit far removed and with a strangely altered physiology. The high degree of cybernetic modification that Drifters exhibit seems to go hand in hand with an implacable single-mindedness and utter ruthlessness while pursuing their mysterious goals. Whatever their ends may be, the technology at their command unquestionably rivals and perhaps even surpasses that which other Jove have been seen to use."}, "intelligence": 0, "corporationID": 1000274}
15	25	{"_key": 25, "name": {"en": "Narodnya"}, "iconID": null, "memory": 9, "raceID": 135, "charisma": 9, "willpower": 9, "perception": 9, "description": {"en": "The Narodnya appear to be one of the three mysterious subdivisions of the Triglavian race that individuals can fall into alongside their membership of the so-called Clades."}, "intelligence": 9, "corporationID": 1000293}
16	26	{"_key": 26, "name": {"en": "Koschoi"}, "iconID": null, "memory": 9, "raceID": 135, "charisma": 9, "willpower": 9, "perception": 9, "description": {"en": "The Koschoi appear to be one of the three mysterious subdivisions of the Triglavian race that individuals can fall into alongside their membership of the so-called Clades."}, "intelligence": 9, "corporationID": 1000293}
17	27	{"_key": 27, "name": {"en": "Navka"}, "iconID": null, "memory": 9, "raceID": 135, "charisma": 9, "willpower": 9, "perception": 9, "description": {"en": "The Navka appear to be one of the three mysterious subdivisions of the Triglavian race that individuals can fall into alongside their membership of the so-called Clades."}, "intelligence": 9, "corporationID": 1000293}
18	83	{"_key": 83, "name": {"en": "Alpha City - Fighter"}, "iconID": null, "memory": 6, "raceID": 169, "charisma": 6, "willpower": 6, "perception": 6, "description": null, "intelligence": 6, "corporationID": 1000465}
\.


--
-- Name: bloodlines bloodlines_pkey; Type: CONSTRAINT; Schema: sde_compat; Owner: -
--

ALTER TABLE ONLY sde_compat.bloodlines
    ADD CONSTRAINT bloodlines_pkey PRIMARY KEY (row_no);


--
-- Name: bloodlines_key_idx; Type: INDEX; Schema: sde_compat; Owner: -
--

CREATE INDEX bloodlines_key_idx ON sde_compat.bloodlines USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict LYBAhEqDO5vWeSYIQWXfrANFijvG4j2gt3aD9AUtwzuxPtQNtZ8wloCOrXOXU33

