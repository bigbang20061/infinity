--
-- PostgreSQL database dump
--

\restrict IjZdgYvmjnKZtpHJy4cCw8fQga943092Vr1b3va8pc7au1ixE78uakefMxCYyjV

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: races; Type: TABLE; Schema: sde_compat; Owner: -
--

CREATE TABLE sde_compat.races (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: races; Type: TABLE DATA; Schema: sde_compat; Owner: -
--

COPY sde_compat.races (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "name": {"en": "Caldari"}, "iconID": 1439, "skills": [{"_key": 3300, "_value": 4}, {"_key": 3301, "_value": 1}, {"_key": 3310, "_value": 2}, {"_key": 3311, "_value": 2}, {"_key": 3312, "_value": 2}, {"_key": 3315, "_value": 0}, {"_key": 3316, "_value": 2}, {"_key": 3317, "_value": 1}, {"_key": 3318, "_value": 2}, {"_key": 3319, "_value": 1}, {"_key": 3327, "_value": 3}, {"_key": 3330, "_value": 1}, {"_key": 3342, "_value": 1}, {"_key": 3380, "_value": 1}, {"_key": 3386, "_value": 3}, {"_key": 3392, "_value": 3}, {"_key": 3393, "_value": 0}, {"_key": 3394, "_value": 2}, {"_key": 3402, "_value": 4}, {"_key": 3411, "_value": 1}, {"_key": 3412, "_value": 3}, {"_key": 3413, "_value": 4}, {"_key": 3417, "_value": 3}, {"_key": 3418, "_value": 3}, {"_key": 3419, "_value": 2}, {"_key": 3420, "_value": 2}, {"_key": 3424, "_value": 1}, {"_key": 3425, "_value": 2}, {"_key": 3426, "_value": 4}, {"_key": 3427, "_value": 1}, {"_key": 3428, "_value": 2}, {"_key": 3429, "_value": 3}, {"_key": 3431, "_value": 2}, {"_key": 3432, "_value": 3}, {"_key": 3435, "_value": 1}, {"_key": 3436, "_value": 1}, {"_key": 3437, "_value": 1}, {"_key": 3443, "_value": 2}, {"_key": 3449, "_value": 3}, {"_key": 3450, "_value": 3}, {"_key": 3453, "_value": 1}, {"_key": 3454, "_value": 1}, {"_key": 3455, "_value": 2}, {"_key": 3551, "_value": 3}, {"_key": 13278, "_value": 1}, {"_key": 16598, "_value": 1}, {"_key": 21718, "_value": 1}, {"_key": 22578, "_value": 0}, {"_key": 25739, "_value": 1}, {"_key": 25811, "_value": 1}, {"_key": 25863, "_value": 3}, {"_key": 32918, "_value": 1}], "shipTypeID": 601, "description": {"en": "Founded on the tenets of patriotism and hard work that carried its ancestors through hardships on an inhospitable homeworld, the Caldari State is today a corporate dictatorship, led by rulers who are determined to see it return to the meritocratic ideals of old. Ruthless and efficient in the boardroom as well as on the battlefield, the Caldari are living emblems of strength, persistence, and dignity."}}
1	2	{"_key": 2, "name": {"en": "Minmatar"}, "iconID": 1440, "skills": [{"_key": 3300, "_value": 4}, {"_key": 3302, "_value": 1}, {"_key": 3310, "_value": 2}, {"_key": 3311, "_value": 2}, {"_key": 3312, "_value": 2}, {"_key": 3315, "_value": 0}, {"_key": 3316, "_value": 1}, {"_key": 3317, "_value": 1}, {"_key": 3318, "_value": 2}, {"_key": 3319, "_value": 1}, {"_key": 3327, "_value": 3}, {"_key": 3329, "_value": 1}, {"_key": 3341, "_value": 1}, {"_key": 3380, "_value": 1}, {"_key": 3386, "_value": 3}, {"_key": 3392, "_value": 3}, {"_key": 3393, "_value": 0}, {"_key": 3394, "_value": 3}, {"_key": 3402, "_value": 4}, {"_key": 3411, "_value": 1}, {"_key": 3412, "_value": 3}, {"_key": 3413, "_value": 4}, {"_key": 3417, "_value": 3}, {"_key": 3418, "_value": 3}, {"_key": 3419, "_value": 1}, {"_key": 3420, "_value": 1}, {"_key": 3424, "_value": 1}, {"_key": 3425, "_value": 1}, {"_key": 3426, "_value": 4}, {"_key": 3427, "_value": 1}, {"_key": 3428, "_value": 2}, {"_key": 3429, "_value": 3}, {"_key": 3431, "_value": 2}, {"_key": 3432, "_value": 3}, {"_key": 3435, "_value": 1}, {"_key": 3436, "_value": 1}, {"_key": 3437, "_value": 1}, {"_key": 3443, "_value": 2}, {"_key": 3449, "_value": 3}, {"_key": 3450, "_value": 3}, {"_key": 3453, "_value": 1}, {"_key": 3454, "_value": 1}, {"_key": 3455, "_value": 2}, {"_key": 3551, "_value": 3}, {"_key": 13278, "_value": 1}, {"_key": 16598, "_value": 1}, {"_key": 21718, "_value": 1}, {"_key": 22578, "_value": 0}, {"_key": 25739, "_value": 1}, {"_key": 25811, "_value": 1}, {"_key": 25863, "_value": 3}, {"_key": 32918, "_value": 1}], "shipTypeID": 588, "description": {"en": "Once a thriving tribal civilization, the Minmatar were enslaved by the Amarr Empire for more than 700 years until a massive rebellion freed most, but not all, of those held in servitude. The Minmatar people today are resilient, ingenious, and hard-working. Many of them believe that democracy, though it has served them well for a long time, can never restore what was taken from them so long ago. For this reason they have formed a government truly reflective of their tribal roots. They will forever resent the Amarrians, and yearn for the days before the Empire's accursed ships ever reached their home skies."}}
2	4	{"_key": 4, "name": {"en": "Amarr"}, "iconID": 1442, "skills": [{"_key": 3300, "_value": 4}, {"_key": 3303, "_value": 1}, {"_key": 3310, "_value": 2}, {"_key": 3311, "_value": 2}, {"_key": 3312, "_value": 2}, {"_key": 3315, "_value": 0}, {"_key": 3316, "_value": 2}, {"_key": 3317, "_value": 1}, {"_key": 3318, "_value": 2}, {"_key": 3319, "_value": 1}, {"_key": 3327, "_value": 3}, {"_key": 3331, "_value": 1}, {"_key": 3343, "_value": 1}, {"_key": 3380, "_value": 1}, {"_key": 3386, "_value": 3}, {"_key": 3392, "_value": 3}, {"_key": 3393, "_value": 0}, {"_key": 3394, "_value": 3}, {"_key": 3402, "_value": 4}, {"_key": 3411, "_value": 1}, {"_key": 3412, "_value": 3}, {"_key": 3413, "_value": 4}, {"_key": 3417, "_value": 3}, {"_key": 3418, "_value": 3}, {"_key": 3419, "_value": 1}, {"_key": 3420, "_value": 1}, {"_key": 3424, "_value": 1}, {"_key": 3425, "_value": 1}, {"_key": 3426, "_value": 4}, {"_key": 3427, "_value": 1}, {"_key": 3428, "_value": 2}, {"_key": 3429, "_value": 3}, {"_key": 3431, "_value": 2}, {"_key": 3432, "_value": 3}, {"_key": 3435, "_value": 1}, {"_key": 3436, "_value": 1}, {"_key": 3437, "_value": 1}, {"_key": 3443, "_value": 2}, {"_key": 3449, "_value": 3}, {"_key": 3450, "_value": 3}, {"_key": 3453, "_value": 1}, {"_key": 3454, "_value": 1}, {"_key": 3455, "_value": 2}, {"_key": 3551, "_value": 3}, {"_key": 13278, "_value": 1}, {"_key": 16598, "_value": 1}, {"_key": 21718, "_value": 1}, {"_key": 22578, "_value": 0}, {"_key": 25739, "_value": 1}, {"_key": 25811, "_value": 1}, {"_key": 25863, "_value": 3}, {"_key": 32918, "_value": 1}], "shipTypeID": 596, "description": {"en": "The Amarr Empire is the largest and oldest of the four empires. Ruled by a mighty Empress, this vast theocratic society is supported by a broad foundation of slave labor. Amarr citizens tend to be highly educated and fervent individuals, and as a culture Amarr adheres to the basic tenet that what others call slavery is in fact one step on a indentured person's spiritual path toward fully embracing their faith. Despite several setbacks in recent history, the Empire remains arguably the most stable and militarily powerful nation-state in New Eden."}}
3	8	{"_key": 8, "name": {"en": "Gallente"}, "iconID": 1441, "skills": [{"_key": 3300, "_value": 4}, {"_key": 3301, "_value": 1}, {"_key": 3310, "_value": 2}, {"_key": 3311, "_value": 2}, {"_key": 3312, "_value": 2}, {"_key": 3315, "_value": 0}, {"_key": 3316, "_value": 2}, {"_key": 3317, "_value": 1}, {"_key": 3318, "_value": 2}, {"_key": 3319, "_value": 1}, {"_key": 3327, "_value": 3}, {"_key": 3328, "_value": 1}, {"_key": 3340, "_value": 1}, {"_key": 3380, "_value": 1}, {"_key": 3386, "_value": 3}, {"_key": 3392, "_value": 3}, {"_key": 3393, "_value": 0}, {"_key": 3394, "_value": 3}, {"_key": 3402, "_value": 4}, {"_key": 3411, "_value": 1}, {"_key": 3412, "_value": 3}, {"_key": 3413, "_value": 4}, {"_key": 3417, "_value": 3}, {"_key": 3418, "_value": 3}, {"_key": 3419, "_value": 1}, {"_key": 3420, "_value": 1}, {"_key": 3424, "_value": 1}, {"_key": 3425, "_value": 1}, {"_key": 3426, "_value": 4}, {"_key": 3427, "_value": 1}, {"_key": 3428, "_value": 2}, {"_key": 3429, "_value": 3}, {"_key": 3431, "_value": 2}, {"_key": 3432, "_value": 3}, {"_key": 3435, "_value": 1}, {"_key": 3436, "_value": 1}, {"_key": 3437, "_value": 1}, {"_key": 3443, "_value": 2}, {"_key": 3449, "_value": 3}, {"_key": 3450, "_value": 3}, {"_key": 3453, "_value": 1}, {"_key": 3454, "_value": 1}, {"_key": 3455, "_value": 2}, {"_key": 3551, "_value": 3}, {"_key": 13278, "_value": 1}, {"_key": 16598, "_value": 1}, {"_key": 21718, "_value": 1}, {"_key": 22578, "_value": 0}, {"_key": 25739, "_value": 1}, {"_key": 25811, "_value": 1}, {"_key": 25863, "_value": 3}, {"_key": 32918, "_value": 1}], "shipTypeID": 606, "description": {"en": "Champions of liberty and defenders of the downtrodden, the Gallente play host to the only true democracy in New Eden. Some of the most progressive leaders, scientists, and businessmen of the era have emerged from its diverse peoples. A pioneer of artificial intelligence, the Federation relies heavily on drones and other automated systems. This is not to detract from the skill of their pilots, though: the Gallente Federation is known for producing some of the best and bravest the universe has to offer."}}
4	16	{"_key": 16, "name": {"en": "Jove"}, "iconID": null, "skills": [], "shipTypeID": null, "description": {"en": "The most mysterious and elusive of all the universe's peoples, the Jovians number only a fraction of any of their neighbors, but their technological superiority makes them powerful beyond all proportion."}}
5	32	{"_key": 32, "name": {"en": "Pirate"}, "iconID": null, "skills": [], "shipTypeID": null, "description": null}
6	64	{"_key": 64, "name": {"en": "Sleepers"}, "iconID": null, "skills": [], "shipTypeID": null, "description": null}
7	128	{"_key": 128, "name": {"en": "ORE"}, "iconID": 0, "skills": [], "shipTypeID": null, "description": null}
8	134	{"_key": 134, "name": {"en": "Rogue Drones"}, "iconID": null, "skills": [], "shipTypeID": null, "description": {"en": "Rogue Drones"}}
9	135	{"_key": 135, "name": {"en": "Triglavian"}, "iconID": null, "skills": [], "shipTypeID": null, "description": {"en": "Triglavian"}}
10	161	{"_key": 161, "name": {"en": "Solar Flare"}, "iconID": null, "skills": [], "shipTypeID": 601, "description": null}
11	168	{"_key": 168, "name": {"en": "Upwell"}, "iconID": null, "skills": [], "shipTypeID": null, "description": {"en": "Upwell Consortium"}}
12	169	{"_key": 169, "name": {"en": "Alpha City"}, "iconID": null, "skills": [], "shipTypeID": 601, "description": null}
13	174	{"_key": 174, "name": {"en": "DHH"}, "iconID": null, "skills": [], "shipTypeID": null, "description": null}
\.


--
-- Name: races races_pkey; Type: CONSTRAINT; Schema: sde_compat; Owner: -
--

ALTER TABLE ONLY sde_compat.races
    ADD CONSTRAINT races_pkey PRIMARY KEY (row_no);


--
-- Name: races_key_idx; Type: INDEX; Schema: sde_compat; Owner: -
--

CREATE INDEX races_key_idx ON sde_compat.races USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict IjZdgYvmjnKZtpHJy4cCw8fQga943092Vr1b3va8pc7au1ixE78uakefMxCYyjV

