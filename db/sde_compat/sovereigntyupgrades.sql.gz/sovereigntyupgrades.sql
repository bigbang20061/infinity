--
-- PostgreSQL database dump
--

\restrict vWFTEDYn6BNN4e7r59ZL1HBUxdaQMOw7ZUbHmFHNGfOHkHTlRZWEsQKbrCaDBVl

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: sovereigntyupgrades; Type: TABLE; Schema: sde_compat; Owner: -
--

CREATE TABLE sde_compat.sovereigntyupgrades (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: sovereigntyupgrades; Type: TABLE DATA; Schema: sde_compat; Owner: -
--

COPY sde_compat.sovereigntyupgrades (row_no, key, data) FROM stdin;
\.


--
-- Name: sovereigntyupgrades sovereigntyupgrades_pkey; Type: CONSTRAINT; Schema: sde_compat; Owner: -
--

ALTER TABLE ONLY sde_compat.sovereigntyupgrades
    ADD CONSTRAINT sovereigntyupgrades_pkey PRIMARY KEY (row_no);


--
-- Name: sovereigntyupgrades_key_idx; Type: INDEX; Schema: sde_compat; Owner: -
--

CREATE INDEX sovereigntyupgrades_key_idx ON sde_compat.sovereigntyupgrades USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict vWFTEDYn6BNN4e7r59ZL1HBUxdaQMOw7ZUbHmFHNGfOHkHTlRZWEsQKbrCaDBVl

