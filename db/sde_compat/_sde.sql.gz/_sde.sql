--
-- PostgreSQL database dump
--

\restrict M7Wsm9NOqsgdvDeDXQFLaXqeKRaZxe9nJ1uLsigldD5YrtoDCkfZ1xDlcZVQacq

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _sde; Type: TABLE; Schema: sde_compat; Owner: -
--

CREATE TABLE sde_compat._sde (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: _sde; Type: TABLE DATA; Schema: sde_compat; Owner: -
--

COPY sde_compat._sde (row_no, key, data) FROM stdin;
0	sde	{"_key": "sde", "buildNumber": 3653293, "releaseDate": "2026-10-27T00:50:27.764795Z"}
\.


--
-- Name: _sde _sde_pkey; Type: CONSTRAINT; Schema: sde_compat; Owner: -
--

ALTER TABLE ONLY sde_compat._sde
    ADD CONSTRAINT _sde_pkey PRIMARY KEY (row_no);


--
-- Name: _sde_key_idx; Type: INDEX; Schema: sde_compat; Owner: -
--

CREATE INDEX _sde_key_idx ON sde_compat._sde USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict M7Wsm9NOqsgdvDeDXQFLaXqeKRaZxe9nJ1uLsigldD5YrtoDCkfZ1xDlcZVQacq

