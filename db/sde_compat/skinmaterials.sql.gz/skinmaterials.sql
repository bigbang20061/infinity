--
-- PostgreSQL database dump
--

\restrict PbtybTimMrYiXsKN2dJHikjLbcmvwdc0lcVoGW2IaqmLKALkTA6wo8ghk5gEiih

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: skinmaterials; Type: TABLE; Schema: sde_compat; Owner: -
--

CREATE TABLE sde_compat.skinmaterials (
    row_no integer NOT NULL,
    key text,
    data jsonb NOT NULL
);


--
-- Data for Name: skinmaterials; Type: TABLE DATA; Schema: sde_compat; Owner: -
--

COPY sde_compat.skinmaterials (row_no, key, data) FROM stdin;
0	1	{"_key": 1, "displayName": {"en": "Ardishapur"}, "materialSetID": 1}
1	2	{"_key": 2, "displayName": {"en": "Kador"}, "materialSetID": 2}
2	3	{"_key": 3, "displayName": {"en": "Quafe"}, "materialSetID": 3}
3	4	{"_key": 4, "displayName": {"en": "Khanid"}, "materialSetID": 4}
4	5	{"_key": 5, "displayName": {"en": "Sarum"}, "materialSetID": 5}
5	6	{"_key": 6, "displayName": {"en": "Tash-Murkon"}, "materialSetID": 6}
6	7	{"_key": 7, "displayName": {"en": "Ishukone"}, "materialSetID": 7}
7	8	{"_key": 8, "displayName": {"en": "Kaalakiota"}, "materialSetID": 8}
8	9	{"_key": 9, "displayName": {"en": "Lai Dai"}, "materialSetID": 9}
9	10	{"_key": 10, "displayName": {"en": "Nugoeihuvi"}, "materialSetID": 10}
10	11	{"_key": 11, "displayName": {"en": "Sukuuvestaa"}, "materialSetID": 11}
11	12	{"_key": 12, "displayName": {"en": "Wiyrkomi"}, "materialSetID": 12}
12	13	{"_key": 13, "displayName": {"en": "Aliastra"}, "materialSetID": 13}
13	14	{"_key": 14, "displayName": {"en": "Duvolle"}, "materialSetID": 14}
14	15	{"_key": 15, "displayName": {"en": "Inner Zone Shipping"}, "materialSetID": 15}
15	16	{"_key": 16, "displayName": {"en": "Intaki Syndicate"}, "materialSetID": 16}
16	17	{"_key": 17, "displayName": {"en": "InterBus"}, "materialSetID": 17}
17	18	{"_key": 18, "displayName": {"en": "Federal Police"}, "materialSetID": 18}
18	19	{"_key": 19, "displayName": {"en": "Roden"}, "materialSetID": 19}
19	20	{"_key": 20, "displayName": {"en": "Justice"}, "materialSetID": 20}
20	21	{"_key": 21, "displayName": {"en": "Nefantar"}, "materialSetID": 21}
21	22	{"_key": 22, "displayName": {"en": "Krusual"}, "materialSetID": 22}
22	23	{"_key": 23, "displayName": {"en": "Sebiestor"}, "materialSetID": 23}
23	24	{"_key": 24, "displayName": {"en": "Thukker Tribe"}, "materialSetID": 24}
24	25	{"_key": 25, "displayName": {"en": "Blood Raiders"}, "materialSetID": 25}
25	26	{"_key": 26, "displayName": {"en": "Guristas"}, "materialSetID": 26}
26	27	{"_key": 27, "displayName": {"en": "ORE Development"}, "materialSetID": 27}
27	28	{"_key": 28, "displayName": {"en": "Serenity"}, "materialSetID": 53}
28	29	{"_key": 29, "displayName": {"en": "Serpentis"}, "materialSetID": 29}
29	30	{"_key": 30, "displayName": {"en": "Vherokior"}, "materialSetID": 30}
30	31	{"_key": 31, "displayName": {"en": "Nocx Rush"}, "materialSetID": 31}
31	34	{"_key": 34, "displayName": {"en": "Sanctuary"}, "materialSetID": 34}
32	38	{"_key": 38, "displayName": {"en": "EoM"}, "materialSetID": 79}
33	40	{"_key": 40, "displayName": {"en": "Serenity"}, "materialSetID": 42}
34	41	{"_key": 41, "displayName": {"en": "Serenity"}, "materialSetID": 43}
35	42	{"_key": 42, "displayName": {"en": "Serenity"}, "materialSetID": 44}
36	43	{"_key": 43, "displayName": {"en": "Serenity"}, "materialSetID": 45}
37	50	{"_key": 50, "displayName": {"en": "Serenity"}, "materialSetID": 46}
38	51	{"_key": 51, "displayName": {"en": "Serenity"}, "materialSetID": 47}
39	52	{"_key": 52, "displayName": {"en": "Serenity"}, "materialSetID": 48}
40	53	{"_key": 53, "displayName": {"en": "Serenity"}, "materialSetID": 49}
41	54	{"_key": 54, "displayName": {"en": "Serenity"}, "materialSetID": 50}
42	55	{"_key": 55, "displayName": {"en": "Serenity"}, "materialSetID": 51}
43	56	{"_key": 56, "displayName": {"en": "Serenity"}, "materialSetID": 52}
44	58	{"_key": 58, "displayName": {"en": "Golden"}, "materialSetID": 81}
45	59	{"_key": 59, "displayName": {"en": "Golden"}, "materialSetID": 82}
46	60	{"_key": 60, "displayName": {"en": "Umbral"}, "materialSetID": 78}
47	67	{"_key": 67, "displayName": {"en": "Raata Sunset"}, "materialSetID": 75}
48	68	{"_key": 68, "displayName": {"en": "Blue Tiger"}, "materialSetID": 74}
49	69	{"_key": 69, "displayName": {"en": "Valklear Glory"}, "materialSetID": 76}
50	70	{"_key": 70, "displayName": {"en": "Blue Tiger"}, "materialSetID": 77}
51	74	{"_key": 74, "displayName": {"en": "Victory"}, "materialSetID": 88}
52	80	{"_key": 80, "displayName": {"en": "Serenity"}, "materialSetID": 53}
53	82	{"_key": 82, "displayName": {"en": "Raata Sunset"}, "materialSetID": 84}
54	83	{"_key": 83, "displayName": {"en": "Valimor Legacy"}, "materialSetID": 87}
55	84	{"_key": 84, "displayName": {"en": "Waschi Uprising 'Combat'"}, "materialSetID": 89}
56	85	{"_key": 85, "displayName": {"en": "Waschi Uprising 'Parade'"}, "materialSetID": 90}
57	87	{"_key": 87, "displayName": {"en": "Nova"}, "materialSetID": 91}
58	88	{"_key": 88, "displayName": {"en": "Nova"}, "materialSetID": 92}
59	89	{"_key": 89, "displayName": {"en": "Nova"}, "materialSetID": 93}
60	90	{"_key": 90, "displayName": {"en": "Nova"}, "materialSetID": 94}
61	91	{"_key": 91, "displayName": {"en": "Nova"}, "materialSetID": 95}
62	92	{"_key": 92, "displayName": {"en": "Tronhadar Ink"}, "materialSetID": 86}
63	93	{"_key": 93, "displayName": {"en": "Matigu Seabeast"}, "materialSetID": 85}
64	94	{"_key": 94, "displayName": {"en": "IGC Victory"}, "materialSetID": 98}
65	96	{"_key": 96, "displayName": {"en": "Valkyrie"}, "materialSetID": 106}
66	98	{"_key": 98, "displayName": {"en": "Upwell"}, "materialSetID": 110}
67	99	{"_key": 99, "displayName": {"en": "Palatine"}, "materialSetID": 111}
68	100	{"_key": 100, "displayName": {"en": "Imperial Armaments"}, "materialSetID": 102}
69	102	{"_key": 102, "displayName": {"en": "Purity of the Throne"}, "materialSetID": 121}
70	104	{"_key": 104, "displayName": {"en": "Morphite Shine"}, "materialSetID": 114}
71	106	{"_key": 106, "displayName": {"en": "Digmaster Blazon"}, "materialSetID": 115}
72	107	{"_key": 107, "displayName": {"en": "Paydirt Prospector"}, "materialSetID": 116}
73	108	{"_key": 108, "displayName": {"en": "Cold Iron"}, "materialSetID": 122}
74	116	{"_key": 116, "displayName": {"en": "Ironblood"}, "materialSetID": 120}
75	118	{"_key": 118, "displayName": {"en": "Ironblood"}, "materialSetID": 123}
76	119	{"_key": 119, "displayName": {"en": "Blood Raider Victory"}, "materialSetID": 117}
77	121	{"_key": 121, "displayName": {"en": "Rosada Dawn"}, "materialSetID": 162}
78	123	{"_key": 123, "displayName": {"en": "Amarr Industrial Livery"}, "materialSetID": 154}
79	124	{"_key": 124, "displayName": {"en": "Caldari Industrial Livery"}, "materialSetID": 155}
80	125	{"_key": 125, "displayName": {"en": "Gallente Industrial Livery"}, "materialSetID": 156}
81	126	{"_key": 126, "displayName": {"en": "Minmatar Industrial Livery"}, "materialSetID": 157}
82	127	{"_key": 127, "displayName": {"en": "Angel Industrial Livery"}, "materialSetID": 158}
83	128	{"_key": 128, "displayName": {"en": "Blood Raider Industrial Livery"}, "materialSetID": 159}
84	129	{"_key": 129, "displayName": {"en": "Guristas Industrial Livery"}, "materialSetID": 160}
85	130	{"_key": 130, "displayName": {"en": "Sansha Industrial Livery"}, "materialSetID": 161}
86	132	{"_key": 132, "displayName": {"en": "Claim Foreman"}, "materialSetID": 166}
87	133	{"_key": 133, "displayName": {"en": "Star Captain"}, "materialSetID": 133}
88	135	{"_key": 135, "displayName": {"en": "Glacial Drift"}, "materialSetID": 170}
89	136	{"_key": 136, "displayName": {"en": "Glacial Drift"}, "materialSetID": 173}
90	137	{"_key": 137, "displayName": {"en": "Glacial Drift"}, "materialSetID": 171}
91	138	{"_key": 138, "displayName": {"en": "Glacial Drift"}, "materialSetID": 172}
92	139	{"_key": 139, "displayName": {"en": "Glacial Drift"}, "materialSetID": 174}
93	140	{"_key": 140, "displayName": {"en": "SOE Fire Cell (Defense)"}, "materialSetID": 167}
94	141	{"_key": 141, "displayName": {"en": "SOE Blue Cell (Surveillance)"}, "materialSetID": 168}
95	142	{"_key": 142, "displayName": {"en": "SOE Gold Cell (Archaeology)"}, "materialSetID": 169}
96	147	{"_key": 147, "displayName": {"en": "Versus Redforce"}, "materialSetID": 129}
97	148	{"_key": 148, "displayName": {"en": "Versus Blueforce"}, "materialSetID": 130}
98	149	{"_key": 149, "displayName": {"en": "Versus Redforce"}, "materialSetID": 142}
99	150	{"_key": 150, "displayName": null, "materialSetID": 143}
100	151	{"_key": 151, "displayName": {"en": "Convergence - Nova"}, "materialSetID": 177}
101	152	{"_key": 152, "displayName": {"en": "Midnight"}, "materialSetID": 125}
102	153	{"_key": 153, "displayName": {"en": "IGC Victory"}, "materialSetID": 97}
103	154	{"_key": 154, "displayName": {"en": "Spirit"}, "materialSetID": 184}
104	155	{"_key": 155, "displayName": {"en": "Spirit"}, "materialSetID": 185}
105	157	{"_key": 157, "displayName": {"en": "IGC Victory"}, "materialSetID": 188}
106	160	{"_key": 160, "displayName": {"en": "Sapphire Sungrazer"}, "materialSetID": 187}
107	164	{"_key": 164, "displayName": {"en": "YC119"}, "materialSetID": 192}
108	173	{"_key": 173, "displayName": {"en": "CONCORD Aerospace 'Prototype'"}, "materialSetID": 201}
109	174	{"_key": 174, "displayName": {"en": "YC119 Capsuleer Day"}, "materialSetID": 199}
110	175	{"_key": 175, "displayName": {"en": "Hostile Takeover"}, "materialSetID": 198}
111	178	{"_key": 178, "displayName": {"en": "Guristas Victory"}, "materialSetID": 197}
112	179	{"_key": 179, "displayName": {"en": "Hazard Control"}, "materialSetID": 205}
113	180	{"_key": 180, "displayName": {"en": "Ruby Sungrazer"}, "materialSetID": 186}
114	181	{"_key": 181, "displayName": {"en": "Angel's Hex"}, "materialSetID": 223}
115	184	{"_key": 184, "displayName": {"en": "Exoplanets Hunter"}, "materialSetID": 215}
116	185	{"_key": 185, "displayName": {"en": "Exoplanets Hunter"}, "materialSetID": 210}
117	186	{"_key": 186, "displayName": {"en": "Exoplanets Hunter"}, "materialSetID": 212}
118	187	{"_key": 187, "displayName": {"en": "Exoplanets Hunter"}, "materialSetID": 214}
119	188	{"_key": 188, "displayName": {"en": "Exoplanets Hunter"}, "materialSetID": 213}
120	189	{"_key": 189, "displayName": {"en": "Firewall Breach"}, "materialSetID": 217}
121	190	{"_key": 190, "displayName": {"en": "Firewatch"}, "materialSetID": 207}
122	191	{"_key": 191, "displayName": {"en": "Sunburst"}, "materialSetID": 224}
123	192	{"_key": 192, "displayName": {"en": "Nightfire"}, "materialSetID": 225}
124	193	{"_key": 193, "displayName": {"en": "Skyliner"}, "materialSetID": 226}
125	194	{"_key": 194, "displayName": {"en": "Battlescar"}, "materialSetID": 227}
126	195	{"_key": 195, "displayName": {"en": "IGC"}, "materialSetID": 188}
127	196	{"_key": 196, "displayName": {"en": "IGC"}, "materialSetID": 230}
128	197	{"_key": 197, "displayName": {"en": "IGC"}, "materialSetID": 231}
129	198	{"_key": 198, "displayName": {"en": "Steel Cardinal"}, "materialSetID": 239}
130	199	{"_key": 199, "displayName": {"en": "Kairiola's Sacrifice"}, "materialSetID": 243}
131	200	{"_key": 200, "displayName": {"en": "Valkyrie"}, "materialSetID": 247}
132	201	{"_key": 201, "displayName": {"en": "Valkyrie"}, "materialSetID": 248}
133	202	{"_key": 202, "displayName": {"en": "Valkyrie"}, "materialSetID": 249}
134	203	{"_key": 203, "displayName": {"en": "Kopis Edge"}, "materialSetID": 259}
135	204	{"_key": 204, "displayName": {"en": "Spectral Shift"}, "materialSetID": 195}
136	205	{"_key": 205, "displayName": {"en": "Imperial Jubilee"}, "materialSetID": 266}
137	206	{"_key": 206, "displayName": {"en": "Forgemaster"}, "materialSetID": 240}
138	207	{"_key": 207, "displayName": {"en": "Serpentis Victory (Gallente Hulls)"}, "materialSetID": 236}
139	208	{"_key": 208, "displayName": {"en": "Serpentis Victory (Angel Hulls)"}, "materialSetID": 237}
140	209	{"_key": 209, "displayName": {"en": "War Reserves Lieutenant"}, "materialSetID": 246}
141	210	{"_key": 210, "displayName": {"en": "Military Stockpile Captain"}, "materialSetID": 262}
142	211	{"_key": 211, "displayName": {"en": "Strategic Materiel Defender"}, "materialSetID": 269}
143	212	{"_key": 212, "displayName": {"en": "Fleet Ordnance Spike"}, "materialSetID": 270}
144	213	{"_key": 213, "displayName": {"en": "Headhunter"}, "materialSetID": 280}
145	214	{"_key": 214, "displayName": {"en": "Headhunter"}, "materialSetID": 281}
146	215	{"_key": 215, "displayName": {"en": "Headhunter"}, "materialSetID": 282}
147	216	{"_key": 216, "displayName": {"en": "Headhunter"}, "materialSetID": 283}
148	217	{"_key": 217, "displayName": {"en": "Octopus Red Flight"}, "materialSetID": 273}
149	218	{"_key": 218, "displayName": {"en": "Lodestrike"}, "materialSetID": 274}
150	219	{"_key": 219, "displayName": {"en": "Lodestrike"}, "materialSetID": 275}
151	220	{"_key": 220, "displayName": {"en": "Lodestrike"}, "materialSetID": 276}
152	221	{"_key": 221, "displayName": {"en": "Lodestrike"}, "materialSetID": 277}
153	222	{"_key": 222, "displayName": {"en": "Lodestrike"}, "materialSetID": 278}
154	223	{"_key": 223, "displayName": {"en": "Glacial Drift"}, "materialSetID": 285}
155	224	{"_key": 224, "displayName": {"en": "Glacial Drift"}, "materialSetID": 286}
156	225	{"_key": 225, "displayName": {"en": "Glacial Drift"}, "materialSetID": 287}
157	226	{"_key": 226, "displayName": {"en": "Glacial Drift"}, "materialSetID": 288}
158	227	{"_key": 227, "displayName": {"en": "Glacial Drift"}, "materialSetID": 289}
159	228	{"_key": 228, "displayName": {"en": "Glacial Drift"}, "materialSetID": 290}
160	229	{"_key": 229, "displayName": {"en": "King's Ransom – Luecin"}, "materialSetID": 293}
161	230	{"_key": 230, "displayName": {"en": "King's Ransom – Darouen"}, "materialSetID": 294}
162	231	{"_key": 231, "displayName": {"en": "Serene Hao"}, "materialSetID": 296}
163	232	{"_key": 232, "displayName": {"en": "Serene Mang"}, "materialSetID": 297}
164	233	{"_key": 233, "displayName": {"en": "Serene Song"}, "materialSetID": 305}
165	234	{"_key": 234, "displayName": {"en": "Serene Tu"}, "materialSetID": 306}
166	235	{"_key": 235, "displayName": {"en": "Serene Rou"}, "materialSetID": 307}
167	236	{"_key": 236, "displayName": {"en": "\\"Blaze\\" Squadron"}, "materialSetID": 313}
168	237	{"_key": 237, "displayName": {"en": "\\"Blaze\\" Squadron"}, "materialSetID": 314}
169	238	{"_key": 238, "displayName": {"en": "\\"Blaze\\" Squadron"}, "materialSetID": 315}
170	239	{"_key": 239, "displayName": {"en": "\\"Blaze\\" Squadron"}, "materialSetID": 316}
171	240	{"_key": 240, "displayName": {"en": "\\"Blaze\\" Squadron"}, "materialSetID": 317}
172	241	{"_key": 241, "displayName": {"en": "Bloody Hands"}, "materialSetID": 299}
173	242	{"_key": 242, "displayName": {"en": "Crystal Blast"}, "materialSetID": 298}
174	243	{"_key": 243, "displayName": {"en": "Eros Blossom"}, "materialSetID": 332}
175	244	{"_key": 244, "displayName": {"en": "Eros Blossom"}, "materialSetID": 333}
176	245	{"_key": 245, "displayName": {"en": "Eros Blossom"}, "materialSetID": 334}
177	246	{"_key": 246, "displayName": {"en": "Eros Blossom"}, "materialSetID": 335}
178	247	{"_key": 247, "displayName": {"en": "Eros Blossom"}, "materialSetID": 336}
179	248	{"_key": 248, "displayName": {"en": "Spirit"}, "materialSetID": 329}
180	249	{"_key": 249, "displayName": {"en": "Spirit"}, "materialSetID": 330}
181	250	{"_key": 250, "displayName": {"en": "Spirit"}, "materialSetID": 331}
182	251	{"_key": 251, "displayName": {"en": "Shakim Warlord"}, "materialSetID": 324}
183	252	{"_key": 252, "displayName": {"en": "Empyrean Dragons"}, "materialSetID": 300}
184	253	{"_key": 253, "displayName": {"en": "One Eden"}, "materialSetID": 308}
185	254	{"_key": 254, "displayName": {"en": "Hunter's Quiver"}, "materialSetID": 346}
186	255	{"_key": 255, "displayName": {"en": "Hunter's Quiver"}, "materialSetID": 347}
187	256	{"_key": 256, "displayName": {"en": "Hunter's Quiver"}, "materialSetID": 348}
188	257	{"_key": 257, "displayName": {"en": "Hunter's Quiver"}, "materialSetID": 349}
189	258	{"_key": 258, "displayName": {"en": "Ace of Podhunters"}, "materialSetID": 350}
190	259	{"_key": 259, "displayName": {"en": "Glittering Dream"}, "materialSetID": 303}
191	260	{"_key": 260, "displayName": {"en": "Sariel's Flames"}, "materialSetID": 337}
192	261	{"_key": 261, "displayName": {"en": "Versus Redforce"}, "materialSetID": 146}
193	262	{"_key": 262, "displayName": {"en": "Versus Blueforce"}, "materialSetID": 147}
194	263	{"_key": 263, "displayName": {"en": "Silver Racer"}, "materialSetID": 124}
195	264	{"_key": 264, "displayName": {"en": "Octopus Orange Flight"}, "materialSetID": 304}
196	265	{"_key": 265, "displayName": {"en": "Capsuleer Day XV"}, "materialSetID": 341}
197	266	{"_key": 266, "displayName": {"en": "Capsuleer Day XV"}, "materialSetID": 342}
198	267	{"_key": 267, "displayName": {"en": "Capsuleer Day XV"}, "materialSetID": 343}
199	268	{"_key": 268, "displayName": {"en": "Capsuleer Day XV"}, "materialSetID": 344}
200	270	{"_key": 270, "displayName": {"en": "Capsuleer Elite XV"}, "materialSetID": 323}
201	271	{"_key": 271, "displayName": {"en": "Capsuleer Elite XV"}, "materialSetID": 321}
202	272	{"_key": 272, "displayName": {"en": "Capsuleer Elite XV"}, "materialSetID": 319}
203	273	{"_key": 273, "displayName": {"en": "Capsuleer Elite XV"}, "materialSetID": 320}
204	274	{"_key": 274, "displayName": {"en": "Capsuleer Elite XV"}, "materialSetID": 322}
205	275	{"_key": 275, "displayName": {"en": "Capsuleer Elite XV"}, "materialSetID": 351}
206	276	{"_key": 276, "displayName": {"en": "Capsuleer Networker XV"}, "materialSetID": 345}
207	277	{"_key": 277, "displayName": {"en": "SARO 'Black Troop'"}, "materialSetID": 327}
208	278	{"_key": 278, "displayName": {"en": "Sarpati's Revenge - Igil"}, "materialSetID": 302}
209	279	{"_key": 279, "displayName": {"en": "Sarpati's Revenge - Virge"}, "materialSetID": 301}
210	280	{"_key": 280, "displayName": {"en": "Ghostbird"}, "materialSetID": 295}
211	281	{"_key": 281, "displayName": {"en": "Dos Rouvenor's Bequest"}, "materialSetID": 361}
212	282	{"_key": 282, "displayName": {"en": "Luminaire Rising"}, "materialSetID": 353}
213	283	{"_key": 283, "displayName": {"en": "Luminaire Rising"}, "materialSetID": 354}
214	284	{"_key": 284, "displayName": {"en": "Luminaire Rising"}, "materialSetID": 355}
215	285	{"_key": 285, "displayName": {"en": "Luminaire Rising"}, "materialSetID": 356}
216	286	{"_key": 286, "displayName": {"en": "Luminaire Zenith"}, "materialSetID": 357}
217	287	{"_key": 287, "displayName": {"en": "Luminaire Zenith"}, "materialSetID": 358}
218	288	{"_key": 288, "displayName": {"en": "Luminaire Zenith"}, "materialSetID": 359}
219	289	{"_key": 289, "displayName": {"en": "Luminaire Zenith"}, "materialSetID": 360}
220	291	{"_key": 291, "displayName": {"en": "Chainbreaker Khumaak"}, "materialSetID": 362}
221	292	{"_key": 292, "displayName": {"en": "Dawn of Liberation"}, "materialSetID": 363}
222	293	{"_key": 293, "displayName": {"en": "Ultra Jungle (Magneto)"}, "materialSetID": 364}
223	294	{"_key": 294, "displayName": {"en": "Ultra Jungle (Ladar)"}, "materialSetID": 365}
224	295	{"_key": 295, "displayName": {"en": "IGC"}, "materialSetID": 97}
225	296	{"_key": 296, "displayName": {"en": "IGC"}, "materialSetID": 98}
226	297	{"_key": 297, "displayName": {"en": "Triglavian Victory"}, "materialSetID": 381}
227	298	{"_key": 298, "displayName": {"en": "Quantum Potential"}, "materialSetID": 371}
228	299	{"_key": 299, "displayName": {"en": "DED 'Master-at-Arms' Recruiter"}, "materialSetID": 369}
229	300	{"_key": 300, "displayName": {"en": "DED 'Alpha Plus' Taskforce"}, "materialSetID": 370}
230	301	{"_key": 301, "displayName": {"en": "Singularity Storm"}, "materialSetID": 392}
231	302	{"_key": 302, "displayName": {"en": "Hadean Horror"}, "materialSetID": 398}
232	303	{"_key": 303, "displayName": {"en": "Planetary Extraction (Upwell)"}, "materialSetID": 382}
233	304	{"_key": 304, "displayName": {"en": "Combat Medic Section"}, "materialSetID": 372}
234	305	{"_key": 305, "displayName": {"en": "Combat Medic Section"}, "materialSetID": 373}
235	306	{"_key": 306, "displayName": {"en": "Combat Medic Section"}, "materialSetID": 374}
236	307	{"_key": 307, "displayName": {"en": "Combat Medic Section"}, "materialSetID": 375}
237	308	{"_key": 308, "displayName": {"en": "Emergency Response Squad"}, "materialSetID": 376}
238	309	{"_key": 309, "displayName": {"en": "Emergency Response Squad"}, "materialSetID": 377}
239	310	{"_key": 310, "displayName": {"en": "Emergency Response Squad"}, "materialSetID": 378}
240	311	{"_key": 311, "displayName": {"en": "Emergency Response Squad"}, "materialSetID": 379}
241	312	{"_key": 312, "displayName": {"en": "Caldari Union Day"}, "materialSetID": 401}
242	313	{"_key": 313, "displayName": {"en": "Sovereign Claim"}, "materialSetID": 393}
243	314	{"_key": 314, "displayName": {"en": "Storm Bear"}, "materialSetID": 402}
244	315	{"_key": 315, "displayName": {"en": "Storm Bear"}, "materialSetID": 403}
245	316	{"_key": 316, "displayName": {"en": "Cordite Blossom"}, "materialSetID": 414}
246	317	{"_key": 317, "displayName": {"en": "Cordite Blossom"}, "materialSetID": 415}
247	318	{"_key": 318, "displayName": {"en": "Cordite Blossom"}, "materialSetID": 416}
248	319	{"_key": 319, "displayName": {"en": "Cordite Blossom"}, "materialSetID": 417}
249	321	{"_key": 321, "displayName": {"en": "Cryptic Mimesis"}, "materialSetID": 165}
250	322	{"_key": 322, "displayName": {"en": "Cryptic Mimesis"}, "materialSetID": 432}
251	323	{"_key": 323, "displayName": {"en": "Cryptic Mimesis"}, "materialSetID": 163}
252	324	{"_key": 324, "displayName": {"en": "Cryptic Mimesis"}, "materialSetID": 431}
253	325	{"_key": 325, "displayName": {"en": "Absent Heroes"}, "materialSetID": 94}
254	326	{"_key": 326, "displayName": {"en": "Deathglow Hunters"}, "materialSetID": 433}
255	327	{"_key": 327, "displayName": {"en": "Deathglow Hunters"}, "materialSetID": 434}
256	328	{"_key": 328, "displayName": {"en": "Serenity Flame SKIN"}, "materialSetID": 418}
257	329	{"_key": 329, "displayName": {"en": "Serenity Cloud SKIN"}, "materialSetID": 420}
258	330	{"_key": 330, "displayName": {"en": "Serenity Water SKIN"}, "materialSetID": 421}
259	331	{"_key": 331, "displayName": {"en": "Serenity Electric SKIN"}, "materialSetID": 422}
260	332	{"_key": 332, "displayName": {"en": "Serenity Splatter SKIN (Thorax)"}, "materialSetID": 423}
261	333	{"_key": 333, "displayName": {"en": "Serenity Splatter SKIN (Ashimmu)"}, "materialSetID": 424}
262	334	{"_key": 334, "displayName": {"en": "Serenity Circle SKIN"}, "materialSetID": 425}
263	335	{"_key": 335, "displayName": {"en": "Serenity Twirl SKIN (Cynabal)"}, "materialSetID": 426}
264	336	{"_key": 336, "displayName": {"en": "Abyssal Afterglow"}, "materialSetID": 435}
265	337	{"_key": 337, "displayName": {"en": "Abyssal Firestorm (Guristas)"}, "materialSetID": 436}
266	338	{"_key": 338, "displayName": {"en": "Abyssal Thunderstorm"}, "materialSetID": 437}
267	340	{"_key": 340, "displayName": {"en": "Lavacore Imperial"}, "materialSetID": 427}
268	341	{"_key": 341, "displayName": {"en": "Operation Permafrost"}, "materialSetID": 439}
269	342	{"_key": 342, "displayName": {"en": "Icecloud Investigators"}, "materialSetID": 447}
270	343	{"_key": 343, "displayName": {"en": "Chromodynamic Candy"}, "materialSetID": 448}
271	345	{"_key": 345, "displayName": {"en": "Chromodynamic Candy"}, "materialSetID": 449}
272	346	{"_key": 346, "displayName": {"en": "Chromodynamic Candy"}, "materialSetID": 450}
273	347	{"_key": 347, "displayName": {"en": "Chromodynamic Candy"}, "materialSetID": 451}
274	348	{"_key": 348, "displayName": {"en": "Blackfire Steel"}, "materialSetID": 446}
275	354	{"_key": 354, "displayName": {"en": "Yoiul Festival YC121"}, "materialSetID": 444}
276	355	{"_key": 355, "displayName": {"en": "Yoiul Festival YC121"}, "materialSetID": 442}
277	356	{"_key": 356, "displayName": {"en": "Yoiul Festival YC121"}, "materialSetID": 440}
278	357	{"_key": 357, "displayName": {"en": "Yoiul Festival YC121"}, "materialSetID": 441}
279	358	{"_key": 358, "displayName": {"en": "Yoiul Festival YC121"}, "materialSetID": 443}
280	359	{"_key": 359, "displayName": {"en": "Amaranthine Mantle"}, "materialSetID": 454}
281	360	{"_key": 360, "displayName": {"en": "Amaranthine Mantle"}, "materialSetID": 455}
282	361	{"_key": 361, "displayName": {"en": "Amaranthine Mantle"}, "materialSetID": 456}
283	362	{"_key": 362, "displayName": {"en": "Metamateria Exotica"}, "materialSetID": 400}
284	364	{"_key": 364, "displayName": {"en": "Caille Neon"}, "materialSetID": 438}
285	365	{"_key": 365, "displayName": {"en": "Netherworld Striker"}, "materialSetID": 461}
286	2366	{"_key": 2366, "displayName": {"en": "Emperor Bear"}, "materialSetID": 469}
287	2367	{"_key": 2367, "displayName": {"en": "Emperor Bear"}, "materialSetID": 470}
288	2368	{"_key": 2368, "displayName": {"en": "Red Meatgrinder"}, "materialSetID": 479}
289	2370	{"_key": 2370, "displayName": {"en": "Capsuleer Day XVI (SoCT)"}, "materialSetID": 474}
290	2371	{"_key": 2371, "displayName": {"en": "Argyros Elite XVI (Amarr)"}, "materialSetID": 475}
291	2372	{"_key": 2372, "displayName": {"en": "Argyros Elite XVI (Caldari)"}, "materialSetID": 476}
292	2373	{"_key": 2373, "displayName": {"en": "Argyros Elite XVI (Minmatar)"}, "materialSetID": 477}
293	2374	{"_key": 2374, "displayName": {"en": "Argyros Elite XVI (Gallente)"}, "materialSetID": 478}
294	2375	{"_key": 2375, "displayName": {"en": "Permaband Holo XVI"}, "materialSetID": 462}
295	2378	{"_key": 2378, "displayName": {"en": "Triglavian Twilight"}, "materialSetID": 2485}
296	2379	{"_key": 2379, "displayName": {"en": "Triglavian Twilight"}, "materialSetID": 2486}
297	2380	{"_key": 2380, "displayName": {"en": "Deadspace Dreamtime"}, "materialSetID": 2487}
298	2381	{"_key": 2381, "displayName": {"en": "Violet Vellication"}, "materialSetID": 2482}
299	2383	{"_key": 2383, "displayName": {"en": "In Rust We Trust"}, "materialSetID": 467}
300	2384	{"_key": 2384, "displayName": {"en": "Red Forests Thunderbird"}, "materialSetID": 2483}
301	2385	{"_key": 2385, "displayName": {"en": "Vitalshift EGO"}, "materialSetID": 471}
302	2387	{"_key": 2387, "displayName": {"en": "True Deliverance"}, "materialSetID": 460}
303	2389	{"_key": 2389, "displayName": {"en": "Kimotoro Eskeitan"}, "materialSetID": 2492}
304	2390	{"_key": 2390, "displayName": {"en": "Niflhel Gildclaw"}, "materialSetID": 2489}
305	2391	{"_key": 2391, "displayName": {"en": "Niflhel Gildclaw"}, "materialSetID": 2490}
306	2392	{"_key": 2392, "displayName": {"en": "Niflhel Gildclaw"}, "materialSetID": 2491}
307	2394	{"_key": 2394, "displayName": {"en": "Aetheric Raiders"}, "materialSetID": 2494}
308	2395	{"_key": 2395, "displayName": {"en": "Inner Zone Vanguard"}, "materialSetID": 2493}
309	2396	{"_key": 2396, "displayName": {"en": "Crown and Swords"}, "materialSetID": 2505}
310	2397	{"_key": 2397, "displayName": {"en": "Snowline Bladeracer"}, "materialSetID": 2508}
311	2398	{"_key": 2398, "displayName": {"en": "Malagrin Marshlight"}, "materialSetID": 2510}
312	2399	{"_key": 2399, "displayName": {"en": "Malagrin Marshlight"}, "materialSetID": 2511}
313	2400	{"_key": 2400, "displayName": {"en": "Malagrin Marshlight"}, "materialSetID": 2512}
314	2401	{"_key": 2401, "displayName": {"en": "Malagrin Marshlight"}, "materialSetID": 2513}
315	2402	{"_key": 2402, "displayName": {"en": "Malagrin Marshlight"}, "materialSetID": 2516}
316	2403	{"_key": 2403, "displayName": {"en": "All-Stars Casino Clash"}, "materialSetID": 2509}
317	2404	{"_key": 2404, "displayName": {"en": "Abyssal Firestorm"}, "materialSetID": 2517}
318	2405	{"_key": 2405, "displayName": {"en": "Abyssal Firestorm"}, "materialSetID": 2518}
319	2406	{"_key": 2406, "displayName": {"en": "Abyssal Firestorm"}, "materialSetID": 2519}
320	2407	{"_key": 2407, "displayName": {"en": "Abyssal Firestorm"}, "materialSetID": 2520}
321	2408	{"_key": 2408, "displayName": {"en": "Zento Isideko Combine"}, "materialSetID": 2515}
322	2409	{"_key": 2409, "displayName": {"en": "Harmonious Ascension"}, "materialSetID": 2523}
323	2410	{"_key": 2410, "displayName": {"en": "Harmonious Ascension"}, "materialSetID": 2524}
324	2411	{"_key": 2411, "displayName": {"en": "Harmonious Ascension"}, "materialSetID": 2522}
325	2412	{"_key": 2412, "displayName": {"en": "Harmonious Ascension"}, "materialSetID": 2525}
326	2414	{"_key": 2414, "displayName": {"en": "Liminal Crossings"}, "materialSetID": 2526}
327	2415	{"_key": 2415, "displayName": {"en": "Liminal Crossings"}, "materialSetID": 2527}
328	2416	{"_key": 2416, "displayName": {"en": "Liminal Crossings"}, "materialSetID": 2528}
329	2419	{"_key": 2419, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2532}
330	2420	{"_key": 2420, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2531}
331	2421	{"_key": 2421, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2530}
332	2422	{"_key": 2422, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2529}
333	2423	{"_key": 2423, "displayName": {"en": "Yoiul Star"}, "materialSetID": 2533}
334	2424	{"_key": 2424, "displayName": {"en": "Yoiul Star"}, "materialSetID": 2534}
335	2425	{"_key": 2425, "displayName": {"en": "Yoiul Star"}, "materialSetID": 2535}
336	2426	{"_key": 2426, "displayName": {"en": "Yoiul Star"}, "materialSetID": 2536}
337	2427	{"_key": 2427, "displayName": {"en": "Yoiul Star"}, "materialSetID": 2537}
338	2428	{"_key": 2428, "displayName": {"en": "Metalbee Minmatar SKIN"}, "materialSetID": 2498}
339	2429	{"_key": 2429, "displayName": {"en": "Metalbee Gallente SKIN"}, "materialSetID": 2497}
340	2430	{"_key": 2430, "displayName": {"en": "Metalbee Amarr SKIN"}, "materialSetID": 2496}
341	2431	{"_key": 2431, "displayName": {"en": "Metalbee Caldari SKIN"}, "materialSetID": 2495}
342	2432	{"_key": 2432, "displayName": {"en": "Metamateria Exotica"}, "materialSetID": 2542}
343	2433	{"_key": 2433, "displayName": {"en": "Blackfire Steel"}, "materialSetID": 2543}
344	2434	{"_key": 2434, "displayName": {"en": "Hadean Horror"}, "materialSetID": 2544}
345	2440	{"_key": 2440, "displayName": {"en": "Singularity Storm"}, "materialSetID": 2545}
346	2442	{"_key": 2442, "displayName": {"en": "Singularity Storm"}, "materialSetID": 2546}
347	2443	{"_key": 2443, "displayName": {"en": "All-Stars Casino Clash"}, "materialSetID": 2547}
348	2444	{"_key": 2444, "displayName": {"en": "Singularity Storm"}, "materialSetID": 2548}
349	2445	{"_key": 2445, "displayName": {"en": "All-Stars Casino Clash"}, "materialSetID": 2549}
350	2446	{"_key": 2446, "displayName": {"en": "Oasis of Faith"}, "materialSetID": 480}
351	2447	{"_key": 2447, "displayName": {"en": "Blackfire Steel"}, "materialSetID": 2539}
352	2448	{"_key": 2448, "displayName": {"en": "Blackfire Steel"}, "materialSetID": 2540}
353	2449	{"_key": 2449, "displayName": {"en": "Blackfire Steel"}, "materialSetID": 2541}
354	2450	{"_key": 2450, "displayName": {"en": "Heartsurge"}, "materialSetID": 2556}
355	2451	{"_key": 2451, "displayName": {"en": "Heartsurge"}, "materialSetID": 2557}
356	2452	{"_key": 2452, "displayName": {"en": "Heartsurge"}, "materialSetID": 2558}
357	2453	{"_key": 2453, "displayName": {"en": "Heartsurge"}, "materialSetID": 2559}
358	2454	{"_key": 2454, "displayName": {"en": "Heartsurge"}, "materialSetID": 2560}
359	2455	{"_key": 2455, "displayName": {"en": "Abyssal Darkfield"}, "materialSetID": 2486}
360	2456	{"_key": 2456, "displayName": {"en": "Abyssal Exostorm"}, "materialSetID": 2555}
361	2459	{"_key": 2459, "displayName": {"en": "DED Army Reserve"}, "materialSetID": 2561}
362	2460	{"_key": 2460, "displayName": {"en": "Metamateria Exotica"}, "materialSetID": 2553}
363	2461	{"_key": 2461, "displayName": {"en": "Metamateria Exotica"}, "materialSetID": 2552}
364	2462	{"_key": 2462, "displayName": {"en": "Metamateria Exotica"}, "materialSetID": 2551}
365	2463	{"_key": 2463, "displayName": {"en": "Helmatt's Harriers"}, "materialSetID": 2566}
366	2464	{"_key": 2464, "displayName": {"en": "Dragon Phoenix"}, "materialSetID": 2480}
367	2465	{"_key": 2465, "displayName": {"en": "Dragon Phoenix"}, "materialSetID": 2481}
368	2466	{"_key": 2466, "displayName": {"en": "Dragon Phoenix"}, "materialSetID": 2576}
369	2467	{"_key": 2467, "displayName": {"en": "Frontier Safeguarder (Gallente)"}, "materialSetID": 2562}
370	2468	{"_key": 2468, "displayName": {"en": "Frontier Safeguarder (Caldari)"}, "materialSetID": 2563}
371	2469	{"_key": 2469, "displayName": {"en": "Frontier Safeguarder (Minmatar)"}, "materialSetID": 2564}
372	2470	{"_key": 2470, "displayName": {"en": "Frontier Safeguarder (Amarr)"}, "materialSetID": 2565}
373	2471	{"_key": 2471, "displayName": {"en": "Permaband Roadies"}, "materialSetID": 468}
374	2473	{"_key": 2473, "displayName": {"en": "Capsuleer Day XVII Capsule"}, "materialSetID": 2569}
375	2474	{"_key": 2474, "displayName": {"en": "Capsuleer Day XVII SOCT"}, "materialSetID": 2570}
376	2475	{"_key": 2475, "displayName": {"en": "Capsuleer Day XVII Amarr"}, "materialSetID": 2571}
377	2476	{"_key": 2476, "displayName": {"en": "Capsuleer Day XVII Caldari"}, "materialSetID": 2572}
378	2477	{"_key": 2477, "displayName": {"en": "Capsuleer Day XVII Gallente"}, "materialSetID": 2573}
379	2478	{"_key": 2478, "displayName": {"en": "Capsuleer Day XVII Minmatar"}, "materialSetID": 2574}
380	2479	{"_key": 2479, "displayName": {"en": "Eden's Hunters"}, "materialSetID": 2580}
381	2480	{"_key": 2480, "displayName": {"en": "Eden's Hunters"}, "materialSetID": 2581}
382	2481	{"_key": 2481, "displayName": {"en": "Eden's Hunters"}, "materialSetID": 2582}
383	2482	{"_key": 2482, "displayName": {"en": "Eden's Hunters"}, "materialSetID": 2583}
384	2483	{"_key": 2483, "displayName": {"en": "Eden's Hunters"}, "materialSetID": 2584}
385	2484	{"_key": 2484, "displayName": {"en": "Eden's Hunters"}, "materialSetID": 2585}
386	2485	{"_key": 2485, "displayName": {"en": "Eden's Hunters"}, "materialSetID": 2586}
387	2486	{"_key": 2486, "displayName": {"en": "Kybernaut Clade"}, "materialSetID": 2587}
388	2487	{"_key": 2487, "displayName": {"en": "Kybernaut Clade"}, "materialSetID": 2588}
389	2488	{"_key": 2488, "displayName": {"en": "Kybernaut Clade"}, "materialSetID": 2589}
390	2489	{"_key": 2489, "displayName": {"en": "Kybernaut Clade"}, "materialSetID": 2590}
391	2490	{"_key": 2490, "displayName": {"en": "Kybernaut Clade"}, "materialSetID": 2591}
392	2491	{"_key": 2491, "displayName": {"en": "Kybernaut Clade"}, "materialSetID": 2592}
393	2492	{"_key": 2492, "displayName": {"en": "Kybernaut Clade"}, "materialSetID": 2593}
394	2515	{"_key": 2515, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2600}
395	2516	{"_key": 2516, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2601}
396	2517	{"_key": 2517, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2602}
397	2518	{"_key": 2518, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2603}
398	2519	{"_key": 2519, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2604}
399	2520	{"_key": 2520, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2605}
400	2521	{"_key": 2521, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2606}
401	2522	{"_key": 2522, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2607}
402	2523	{"_key": 2523, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2608}
403	2524	{"_key": 2524, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2609}
404	2525	{"_key": 2525, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2610}
405	2526	{"_key": 2526, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2611}
406	2527	{"_key": 2527, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2612}
407	2528	{"_key": 2528, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2613}
408	2529	{"_key": 2529, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2614}
409	2530	{"_key": 2530, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2615}
410	2531	{"_key": 2531, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2616}
411	2532	{"_key": 2532, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2617}
412	2533	{"_key": 2533, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2618}
413	2534	{"_key": 2534, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2619}
414	2535	{"_key": 2535, "displayName": {"en": "Biosecurity Responders"}, "materialSetID": 2620}
415	2536	{"_key": 2536, "displayName": {"en": "Freedom's Revolution"}, "materialSetID": 2621}
416	2537	{"_key": 2537, "displayName": {"en": "Freedom's Revolution"}, "materialSetID": 2622}
417	2538	{"_key": 2538, "displayName": {"en": "Starline Majestic"}, "materialSetID": 2623}
418	2539	{"_key": 2539, "displayName": {"en": "Starline Majestic"}, "materialSetID": 2624}
419	2542	{"_key": 2542, "displayName": {"en": "Abyssal Glory - Amarr"}, "materialSetID": 2628}
420	2543	{"_key": 2543, "displayName": {"en": "Abyssal Glory - Caldari"}, "materialSetID": 2629}
421	2544	{"_key": 2544, "displayName": {"en": "Abyssal Glory - Gallente"}, "materialSetID": 2630}
422	2545	{"_key": 2545, "displayName": {"en": "Abyssal Glory - Minmatar"}, "materialSetID": 2631}
423	2546	{"_key": 2546, "displayName": {"en": "Bluestar Defenders"}, "materialSetID": 2633}
424	2548	{"_key": 2548, "displayName": {"en": "Strikeflight Red"}, "materialSetID": 2638}
425	2549	{"_key": 2549, "displayName": {"en": "Malagrin Marshlight"}, "materialSetID": 2647}
426	2550	{"_key": 2550, "displayName": {"en": "Rockbreaker Pioneers"}, "materialSetID": 2639}
427	2551	{"_key": 2551, "displayName": {"en": "Rockbreaker Pioneers"}, "materialSetID": 2640}
428	2552	{"_key": 2552, "displayName": {"en": "Rockbreaker Pioneers"}, "materialSetID": 2641}
429	2553	{"_key": 2553, "displayName": {"en": "Rockbreaker Pioneers"}, "materialSetID": 2642}
430	2554	{"_key": 2554, "displayName": {"en": "Rockbreaker Pioneers"}, "materialSetID": 2643}
431	2555	{"_key": 2555, "displayName": {"en": "Deathglow Remnant"}, "materialSetID": 2648}
432	2556	{"_key": 2556, "displayName": {"en": "Scope Syndication YC122"}, "materialSetID": 2649}
433	2557	{"_key": 2557, "displayName": {"en": "Hazard Control"}, "materialSetID": 2651}
434	2558	{"_key": 2558, "displayName": {"en": "Hazard Control"}, "materialSetID": 2652}
435	2559	{"_key": 2559, "displayName": {"en": "Hazard Control"}, "materialSetID": 2653}
436	2560	{"_key": 2560, "displayName": {"en": "Jita 4-4"}, "materialSetID": 2656}
437	2561	{"_key": 2561, "displayName": {"en": "Redclaw Sable"}, "materialSetID": 2657}
438	2562	{"_key": 2562, "displayName": {"en": "Redclaw Sable"}, "materialSetID": 2658}
439	2563	{"_key": 2563, "displayName": {"en": "Redclaw Sable"}, "materialSetID": 2659}
440	2564	{"_key": 2564, "displayName": {"en": "Redclaw Sable"}, "materialSetID": 2660}
441	2565	{"_key": 2565, "displayName": {"en": "Redclaw Sable"}, "materialSetID": 2661}
442	2566	{"_key": 2566, "displayName": {"en": "Redclaw Sable"}, "materialSetID": 2662}
443	2567	{"_key": 2567, "displayName": {"en": "Redclaw Sable"}, "materialSetID": 2663}
444	2568	{"_key": 2568, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2685}
445	2569	{"_key": 2569, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2673}
446	2570	{"_key": 2570, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2678}
447	2571	{"_key": 2571, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2680}
448	2572	{"_key": 2572, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2683}
449	2573	{"_key": 2573, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2674}
450	2574	{"_key": 2574, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2677}
451	2575	{"_key": 2575, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2681}
452	2576	{"_key": 2576, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2684}
453	2577	{"_key": 2577, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2675}
454	2578	{"_key": 2578, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2676}
455	2579	{"_key": 2579, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2679}
456	2580	{"_key": 2580, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2682}
457	2581	{"_key": 2581, "displayName": {"en": "Zakura Shumyu"}, "materialSetID": 2664}
458	2582	{"_key": 2582, "displayName": {"en": "Zakura Shumyu"}, "materialSetID": 2665}
459	2583	{"_key": 2583, "displayName": {"en": "Zakura Shumyu"}, "materialSetID": 2666}
460	2584	{"_key": 2584, "displayName": {"en": "Zakura Shumyu"}, "materialSetID": 2667}
461	2585	{"_key": 2585, "displayName": {"en": "Zakura Shumyu"}, "materialSetID": 2668}
462	2586	{"_key": 2586, "displayName": {"en": "Zakura Shumyu"}, "materialSetID": 2669}
463	2587	{"_key": 2587, "displayName": {"en": "Zakura Shumyu"}, "materialSetID": 2670}
464	2588	{"_key": 2588, "displayName": {"en": "Zakura Shumyu"}, "materialSetID": 2671}
465	2589	{"_key": 2589, "displayName": {"en": "Zakura Shumyu"}, "materialSetID": 2686}
466	2590	{"_key": 2590, "displayName": {"en": "Zakura Shumyu"}, "materialSetID": 2672}
467	2591	{"_key": 2591, "displayName": {"en": "Zakura Hansei"}, "materialSetID": 2672}
468	2592	{"_key": 2592, "displayName": {"en": "Zakura Hansei"}, "materialSetID": 2665}
469	2593	{"_key": 2593, "displayName": {"en": "Zakura Hansei"}, "materialSetID": 2664}
470	2594	{"_key": 2594, "displayName": {"en": "Zakura Hansei"}, "materialSetID": 2666}
471	2595	{"_key": 2595, "displayName": {"en": "Zakura Hansei"}, "materialSetID": 2667}
472	2597	{"_key": 2597, "displayName": {"en": "Serpentis"}, "materialSetID": 2698}
473	2598	{"_key": 2598, "displayName": {"en": "EDENCOM Victory"}, "materialSetID": 2707}
474	2599	{"_key": 2599, "displayName": {"en": "GalNet StreamCast Unit"}, "materialSetID": 2701}
475	2600	{"_key": 2600, "displayName": {"en": "GalNet StreamCast Unit"}, "materialSetID": 2702}
476	2601	{"_key": 2601, "displayName": {"en": "GalNet StreamCast Unit"}, "materialSetID": 2703}
477	2602	{"_key": 2602, "displayName": {"en": "GalNet StreamCast Unit"}, "materialSetID": 2704}
478	2603	{"_key": 2603, "displayName": {"en": "GalNet StreamCast Unit"}, "materialSetID": 2705}
479	2604	{"_key": 2604, "displayName": {"en": "BlackIce Derailers"}, "materialSetID": 2700}
480	2605	{"_key": 2605, "displayName": {"en": "Ghost's Hex"}, "materialSetID": 2723}
481	2606	{"_key": 2606, "displayName": {"en": "Ghost's Hex"}, "materialSetID": 2724}
482	2607	{"_key": 2607, "displayName": {"en": "Vampire's Hex"}, "materialSetID": 2725}
483	2608	{"_key": 2608, "displayName": {"en": "Vampire's Hex"}, "materialSetID": 2726}
484	2609	{"_key": 2609, "displayName": {"en": "Capsuleer Day XVIII"}, "materialSetID": 2713}
485	2610	{"_key": 2610, "displayName": {"en": "Capsuleer Day XVIII"}, "materialSetID": 2714}
486	2611	{"_key": 2611, "displayName": {"en": "Capsuleer Day XVIII"}, "materialSetID": 2722}
487	2612	{"_key": 2612, "displayName": {"en": "Capsuleer Day XVIII"}, "materialSetID": 2715}
488	2613	{"_key": 2613, "displayName": {"en": "Capsuleer Day XVIII"}, "materialSetID": 2719}
489	2614	{"_key": 2614, "displayName": {"en": "Capsuleer Day XVIII"}, "materialSetID": 2716}
490	2615	{"_key": 2615, "displayName": {"en": "Capsuleer Day XVIII"}, "materialSetID": 2720}
491	2616	{"_key": 2616, "displayName": {"en": "Capsuleer Day XVIII"}, "materialSetID": 2717}
492	2617	{"_key": 2617, "displayName": {"en": "Capsuleer Day XVIII"}, "materialSetID": 2721}
493	2618	{"_key": 2618, "displayName": {"en": "Capsuleer Day XVIII"}, "materialSetID": 2718}
494	2619	{"_key": 2619, "displayName": {"en": "Ultraviolence Vortex"}, "materialSetID": 2709}
495	2620	{"_key": 2620, "displayName": {"en": "Ultraviolence Vortex"}, "materialSetID": 2710}
496	2621	{"_key": 2621, "displayName": {"en": "Ultraviolence Vortex"}, "materialSetID": 2711}
497	2622	{"_key": 2622, "displayName": {"en": "Ultraviolence Vortex"}, "materialSetID": 2712}
498	2623	{"_key": 2623, "displayName": {"en": "Capsuleer Day XVIII"}, "materialSetID": 2728}
499	2624	{"_key": 2624, "displayName": {"en": "Capsuleer Day XVIII"}, "materialSetID": 2729}
500	2626	{"_key": 2626, "displayName": {"en": "Republic Fleet"}, "materialSetID": 2730}
501	2627	{"_key": 2627, "displayName": {"en": "Caldari Navy"}, "materialSetID": 2731}
502	2628	{"_key": 2628, "displayName": {"en": "Federation Navy"}, "materialSetID": 2732}
503	2629	{"_key": 2629, "displayName": {"en": "Imperial Navy"}, "materialSetID": 2733}
504	2630	{"_key": 2630, "displayName": {"en": "Fireblade Guerilla"}, "materialSetID": 2738}
505	2631	{"_key": 2631, "displayName": {"en": "Fireblade Guerilla"}, "materialSetID": 2739}
506	2632	{"_key": 2632, "displayName": {"en": "Fireblade Guerilla"}, "materialSetID": 2740}
507	2633	{"_key": 2633, "displayName": {"en": "Fireblade Guerilla"}, "materialSetID": 2741}
508	2634	{"_key": 2634, "displayName": {"en": "Fireblade Guerilla"}, "materialSetID": 2742}
509	2635	{"_key": 2635, "displayName": {"en": "Iceblade Guerilla"}, "materialSetID": 2743}
510	2636	{"_key": 2636, "displayName": {"en": "Iceblade Guerilla"}, "materialSetID": 2744}
511	2637	{"_key": 2637, "displayName": {"en": "Iceblade Guerilla"}, "materialSetID": 2745}
512	2638	{"_key": 2638, "displayName": {"en": "Iceblade Guerilla"}, "materialSetID": 2746}
513	2639	{"_key": 2639, "displayName": {"en": "Iceblade Guerilla"}, "materialSetID": 2747}
514	2640	{"_key": 2640, "displayName": {"en": "Green Demons"}, "materialSetID": 2625}
515	2641	{"_key": 2641, "displayName": {"en": "Green Demons"}, "materialSetID": 2626}
516	2642	{"_key": 2642, "displayName": {"en": "Green Demons"}, "materialSetID": 2627}
517	2644	{"_key": 2644, "displayName": {"en": "Minmatar Liberation Games"}, "materialSetID": 2736}
518	2646	{"_key": 2646, "displayName": {"en": "ASES Skin Astero"}, "materialSetID": 2764}
519	2648	{"_key": 2648, "displayName": {"en": "ASES Skin Ishtar"}, "materialSetID": 2770}
520	2649	{"_key": 2649, "displayName": {"en": "Brutor"}, "materialSetID": 2768}
521	2650	{"_key": 2650, "displayName": {"en": "Starkmanir"}, "materialSetID": 2737}
522	2651	{"_key": 2651, "displayName": {"en": "ASES Skin Gila"}, "materialSetID": 2772}
523	2652	{"_key": 2652, "displayName": {"en": "ASES Skin Stratios"}, "materialSetID": 2777}
524	2653	{"_key": 2653, "displayName": {"en": "Ammatar"}, "materialSetID": 2778}
525	2654	{"_key": 2654, "displayName": {"en": "State Police"}, "materialSetID": 2568}
526	2657	{"_key": 2657, "displayName": {"en": "Friendship League"}, "materialSetID": 2774}
527	2658	{"_key": 2658, "displayName": {"en": "ASES Capsule"}, "materialSetID": 2795}
528	2659	{"_key": 2659, "displayName": {"en": "AIR Laboratories"}, "materialSetID": 2758}
529	2660	{"_key": 2660, "displayName": {"en": "AIR Laboratories"}, "materialSetID": 2760}
530	2661	{"_key": 2661, "displayName": {"en": "AIR Laboratories"}, "materialSetID": 2775}
531	2663	{"_key": 2663, "displayName": {"en": "AIR Laboratories"}, "materialSetID": 2759}
532	2664	{"_key": 2664, "displayName": {"en": "Combat Medic Section"}, "materialSetID": 2797}
533	2665	{"_key": 2665, "displayName": {"en": "Emergency Response Squad"}, "materialSetID": 2798}
534	2666	{"_key": 2666, "displayName": {"en": "Semiotique Sports"}, "materialSetID": 2788}
535	2667	{"_key": 2667, "displayName": {"en": "Semiotique Sports"}, "materialSetID": 2787}
536	2668	{"_key": 2668, "displayName": {"en": "Semiotique Sports"}, "materialSetID": 2791}
537	2669	{"_key": 2669, "displayName": {"en": "Semiotique Superluminal"}, "materialSetID": 2781}
538	2670	{"_key": 2670, "displayName": {"en": "Semiotique Superluminal"}, "materialSetID": 2782}
539	2671	{"_key": 2671, "displayName": {"en": "Semiotique Superluminal"}, "materialSetID": 2783}
540	2672	{"_key": 2672, "displayName": {"en": "Semiotique Superluminal"}, "materialSetID": 2784}
541	2673	{"_key": 2673, "displayName": {"en": "Semiotique Superluminal"}, "materialSetID": 2786}
542	2674	{"_key": 2674, "displayName": {"en": "Aspirant Explorer"}, "materialSetID": 2748}
543	2675	{"_key": 2675, "displayName": {"en": "Aspirant Explorer"}, "materialSetID": 2749}
544	2676	{"_key": 2676, "displayName": {"en": "Aspirant Explorer"}, "materialSetID": 2750}
545	2677	{"_key": 2677, "displayName": {"en": "Aspirant Industrialist"}, "materialSetID": 2751}
546	2678	{"_key": 2678, "displayName": {"en": "Aspirant Enforcer"}, "materialSetID": 2752}
547	2679	{"_key": 2679, "displayName": {"en": "Aspirant Enforcer"}, "materialSetID": 2753}
548	2680	{"_key": 2680, "displayName": {"en": "Aspirant Soldier"}, "materialSetID": 2754}
549	2681	{"_key": 2681, "displayName": {"en": "Aspirant Soldier"}, "materialSetID": 2755}
550	2682	{"_key": 2682, "displayName": {"en": "Semiotique Sports"}, "materialSetID": 2790}
551	2683	{"_key": 2683, "displayName": {"en": "Malagrin Marshlight"}, "materialSetID": 2828}
552	2684	{"_key": 2684, "displayName": {"en": "Malagrin Marshlight"}, "materialSetID": 2829}
553	2685	{"_key": 2685, "displayName": {"en": "Malagrin Marshlight"}, "materialSetID": 2830}
554	2686	{"_key": 2686, "displayName": {"en": "Malagrin Marshlight"}, "materialSetID": 2831}
555	2687	{"_key": 2687, "displayName": {"en": "Malagrin Marshlight"}, "materialSetID": 2832}
556	2688	{"_key": 2688, "displayName": {"en": "Malagrin Marshlight"}, "materialSetID": 2833}
557	2689	{"_key": 2689, "displayName": {"en": "Deathglow Hunters"}, "materialSetID": 2805}
558	2690	{"_key": 2690, "displayName": {"en": "Deathglow Hunters"}, "materialSetID": 2806}
559	2691	{"_key": 2691, "displayName": {"en": "Quafe Green Apple"}, "materialSetID": 2834}
560	2692	{"_key": 2692, "displayName": {"en": "Serenity Golden (Amarr)"}, "materialSetID": 2849}
561	2693	{"_key": 2693, "displayName": {"en": "Serenity Golden (Caldari)"}, "materialSetID": 2850}
562	2694	{"_key": 2694, "displayName": {"en": "IGC Victory"}, "materialSetID": 230}
563	2695	{"_key": 2695, "displayName": {"en": "IGC"}, "materialSetID": 2840}
564	2696	{"_key": 2696, "displayName": {"en": "Copper Lightning"}, "materialSetID": 2847}
565	2698	{"_key": 2698, "displayName": {"en": "Copper Lightning"}, "materialSetID": 2843}
566	2699	{"_key": 2699, "displayName": {"en": "Copper Lightning"}, "materialSetID": 2844}
567	2700	{"_key": 2700, "displayName": {"en": "Copper Lightning"}, "materialSetID": 2845}
568	2701	{"_key": 2701, "displayName": {"en": "Copper Lightning"}, "materialSetID": 2846}
569	2703	{"_key": 2703, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2856}
570	2704	{"_key": 2704, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2857}
571	2705	{"_key": 2705, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2858}
572	2706	{"_key": 2706, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2859}
573	2707	{"_key": 2707, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2860}
574	2708	{"_key": 2708, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2861}
575	2709	{"_key": 2709, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2862}
576	2710	{"_key": 2710, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2863}
577	2711	{"_key": 2711, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2864}
578	2712	{"_key": 2712, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 2865}
579	2713	{"_key": 2713, "displayName": {"en": "Radioactives Reclamation"}, "materialSetID": 2866}
580	2714	{"_key": 2714, "displayName": {"en": "Radioactives Reclamation"}, "materialSetID": 2867}
581	2715	{"_key": 2715, "displayName": {"en": "Radioactives Reclamation"}, "materialSetID": 2868}
582	2716	{"_key": 2716, "displayName": {"en": "Radioactives Reclamation"}, "materialSetID": 2869}
583	2718	{"_key": 2718, "displayName": {"en": "Warp Convergence"}, "materialSetID": 2870}
584	2719	{"_key": 2719, "displayName": {"en": "Warp Convergence"}, "materialSetID": 2872}
585	2720	{"_key": 2720, "displayName": {"en": "Warp Convergence"}, "materialSetID": 2873}
586	2721	{"_key": 2721, "displayName": {"en": "Warp Convergence"}, "materialSetID": 2874}
587	2722	{"_key": 2722, "displayName": {"en": "Serenity 2021 Christmas"}, "materialSetID": 2878}
588	2723	{"_key": 2723, "displayName": {"en": "Serenity 2021 Christmas"}, "materialSetID": 2879}
589	2724	{"_key": 2724, "displayName": {"en": "Serenity 2021 Christmas"}, "materialSetID": 2880}
590	2725	{"_key": 2725, "displayName": {"en": "Versus Redforce"}, "materialSetID": 126}
591	2726	{"_key": 2726, "displayName": {"en": "Versus Blueforce"}, "materialSetID": 127}
592	2727	{"_key": 2727, "displayName": {"en": "Versus Redforce"}, "materialSetID": 131}
593	2728	{"_key": 2728, "displayName": {"en": "Versus Blueforce"}, "materialSetID": 132}
594	2729	{"_key": 2729, "displayName": {"en": "Versus Redforce"}, "materialSetID": 138}
595	2730	{"_key": 2730, "displayName": {"en": "Versus Blueforce"}, "materialSetID": 139}
596	2731	{"_key": 2731, "displayName": {"en": "Versus Redforce"}, "materialSetID": 140}
597	2732	{"_key": 2732, "displayName": {"en": "Versus Blueforce"}, "materialSetID": 141}
598	2733	{"_key": 2733, "displayName": {"en": "Serenity 2022 NewYear (Caracal)"}, "materialSetID": 2882}
599	2734	{"_key": 2734, "displayName": {"en": "Serenity 2022 NewYear (Catalyst)"}, "materialSetID": 2883}
600	2735	{"_key": 2735, "displayName": {"en": "Serenity 2022 NewYear (Paladin)"}, "materialSetID": 2884}
601	2736	{"_key": 2736, "displayName": {"en": "Serenity 2022 NewYear (Stiletto)"}, "materialSetID": 2885}
602	2737	{"_key": 2737, "displayName": {"en": "Serenity 2022 NewYear (Machariel)"}, "materialSetID": 2886}
603	2738	{"_key": 2738, "displayName": {"en": "Interstellar Convergence"}, "materialSetID": 2889}
604	2739	{"_key": 2739, "displayName": {"en": "Interstellar Convergence"}, "materialSetID": 2888}
605	2740	{"_key": 2740, "displayName": {"en": "Interstellar Convergence"}, "materialSetID": 2890}
606	2741	{"_key": 2741, "displayName": {"en": "Interstellar Convergence"}, "materialSetID": 2891}
607	2742	{"_key": 2742, "displayName": {"en": "Interstellar Convergence"}, "materialSetID": 2892}
608	2743	{"_key": 2743, "displayName": {"en": "Serenity 2022 Tiger (Nightmare)"}, "materialSetID": 2895}
609	2744	{"_key": 2744, "displayName": {"en": "Triumphant Elite"}, "materialSetID": 2855}
610	2747	{"_key": 2747, "displayName": {"en": "Semiotique Superluminal"}, "materialSetID": 2906}
611	2748	{"_key": 2748, "displayName": {"en": "Semiotique Superluminal"}, "materialSetID": 2907}
612	2749	{"_key": 2749, "displayName": {"en": "Semiotique Superluminal"}, "materialSetID": 2908}
613	2750	{"_key": 2750, "displayName": {"en": "Semiotique Superluminal"}, "materialSetID": 2909}
614	2751	{"_key": 2751, "displayName": {"en": "Ace of Podhunters"}, "materialSetID": 2965}
615	2752	{"_key": 2752, "displayName": {"en": "Ace of Podhunters"}, "materialSetID": 2966}
616	2753	{"_key": 2753, "displayName": {"en": "Ace of Podhunters"}, "materialSetID": 2967}
617	2754	{"_key": 2754, "displayName": {"en": "Alienware"}, "materialSetID": 2979}
618	2755	{"_key": 2755, "displayName": {"en": "Carmine Horizon"}, "materialSetID": 2687}
619	2756	{"_key": 2756, "displayName": {"en": "Carmine Horizon"}, "materialSetID": 2688}
620	2757	{"_key": 2757, "displayName": {"en": "Carmine Horizon"}, "materialSetID": 2689}
621	2758	{"_key": 2758, "displayName": {"en": "Carmine Horizon"}, "materialSetID": 2690}
622	2759	{"_key": 2759, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2807}
623	2760	{"_key": 2760, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2808}
624	2761	{"_key": 2761, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2809}
625	2762	{"_key": 2762, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2810}
626	2763	{"_key": 2763, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2811}
627	2764	{"_key": 2764, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2812}
628	2765	{"_key": 2765, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2813}
629	2766	{"_key": 2766, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2814}
630	2767	{"_key": 2767, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2815}
631	2768	{"_key": 2768, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2816}
632	2769	{"_key": 2769, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2817}
633	2770	{"_key": 2770, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2818}
634	2771	{"_key": 2771, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2819}
635	2772	{"_key": 2772, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2820}
636	2773	{"_key": 2773, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2821}
637	2774	{"_key": 2774, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2822}
638	2775	{"_key": 2775, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2823}
639	2776	{"_key": 2776, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2824}
640	2777	{"_key": 2777, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2825}
641	2778	{"_key": 2778, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2826}
642	2779	{"_key": 2779, "displayName": {"en": "Halcyon Dawn"}, "materialSetID": 2827}
643	2780	{"_key": 2780, "displayName": {"en": "Versus Redforce"}, "materialSetID": 151}
644	2781	{"_key": 2781, "displayName": {"en": "Versus Blueforce"}, "materialSetID": 152}
645	2782	{"_key": 2782, "displayName": {"en": "Versus Redforce"}, "materialSetID": 2981}
646	2783	{"_key": 2783, "displayName": {"en": "Versus Blueforce"}, "materialSetID": 2980}
647	2784	{"_key": 2784, "displayName": {"en": "Versus Redforce"}, "materialSetID": 2982}
648	2785	{"_key": 2785, "displayName": {"en": "Versus Blueforce"}, "materialSetID": 2983}
649	2786	{"_key": 2786, "displayName": {"en": "Versus Redforce"}, "materialSetID": 2984}
650	2787	{"_key": 2787, "displayName": {"en": "Versus Blueforce"}, "materialSetID": 2985}
651	2788	{"_key": 2788, "displayName": {"en": "Capsuleer Elite XIX"}, "materialSetID": 2957}
652	2789	{"_key": 2789, "displayName": {"en": "Capsuleer Elite XIX"}, "materialSetID": 2958}
653	2790	{"_key": 2790, "displayName": {"en": "Capsuleer Elite XIX"}, "materialSetID": 2959}
654	2791	{"_key": 2791, "displayName": {"en": "Capsuleer Elite XIX"}, "materialSetID": 2960}
655	2792	{"_key": 2792, "displayName": {"en": "Capsuleer Elite XIX"}, "materialSetID": 2961}
656	2793	{"_key": 2793, "displayName": {"en": "Capsuleer Elite XIX"}, "materialSetID": 2976}
657	2797	{"_key": 2797, "displayName": {"en": "Capsuleer Day XIX"}, "materialSetID": 2962}
658	2798	{"_key": 2798, "displayName": {"en": "Capsuleer Day XIX"}, "materialSetID": 2963}
659	2799	{"_key": 2799, "displayName": {"en": "Capsuleer Day XIX"}, "materialSetID": 2964}
660	2800	{"_key": 2800, "displayName": {"en": "Kimotoro Eskeitan Commander"}, "materialSetID": 2989}
661	2801	{"_key": 2801, "displayName": {"en": "Semiotique Sports"}, "materialSetID": 2789}
662	2803	{"_key": 2803, "displayName": {"en": "Interbus Material"}, "materialSetID": 3031}
663	2804	{"_key": 2804, "displayName": {"en": "Corporate Police Force"}, "materialSetID": 3018}
664	2805	{"_key": 2805, "displayName": {"en": "Home Guard"}, "materialSetID": 3019}
665	2806	{"_key": 2806, "displayName": {"en": "Internal Security"}, "materialSetID": 3020}
666	2807	{"_key": 2807, "displayName": {"en": "Ishukone Watch"}, "materialSetID": 3021}
667	2808	{"_key": 2808, "displayName": {"en": "Lai Dai Protection Service"}, "materialSetID": 3022}
668	2809	{"_key": 2809, "displayName": {"en": "Peace and Order Unit"}, "materialSetID": 3023}
669	2810	{"_key": 2810, "displayName": {"en": "Spacelane Patrol"}, "materialSetID": 3024}
670	2811	{"_key": 2811, "displayName": {"en": "Wiyrkomi Peace Corps"}, "materialSetID": 3025}
671	2813	{"_key": 2813, "displayName": {"en": "Union Day Workers"}, "materialSetID": 3035}
672	2814	{"_key": 2814, "displayName": {"en": "Union Day Executive"}, "materialSetID": 3037}
673	2815	{"_key": 2815, "displayName": {"en": "Union Day Executive"}, "materialSetID": 3038}
674	2819	{"_key": 2819, "displayName": {"en": "Sanguinary Savant"}, "materialSetID": 3082}
675	2820	{"_key": 2820, "displayName": {"en": "Order of Tetrimon"}, "materialSetID": 2842}
676	2821	{"_key": 2821, "displayName": {"en": "Nirvanaflame"}, "materialSetID": 3088}
677	2822	{"_key": 2822, "displayName": {"en": "Nirvanaflame"}, "materialSetID": 3089}
678	2823	{"_key": 2823, "displayName": {"en": "Nirvanaflame"}, "materialSetID": 3090}
679	2824	{"_key": 2824, "displayName": {"en": "Tercio Rojo"}, "materialSetID": 3084}
680	2825	{"_key": 2825, "displayName": {"en": "Tercio Rojo"}, "materialSetID": 3085}
681	2826	{"_key": 2826, "displayName": {"en": "Glittering Dream"}, "materialSetID": 3099}
682	2827	{"_key": 2827, "displayName": {"en": "Glittering Dream"}, "materialSetID": 3100}
683	2828	{"_key": 2828, "displayName": {"en": "Glittering Dream"}, "materialSetID": 3101}
684	2829	{"_key": 2829, "displayName": {"en": "Semiotique Sports"}, "materialSetID": 3098}
685	2831	{"_key": 2831, "displayName": {"en": "YC124 Clash"}, "materialSetID": 3106}
686	2832	{"_key": 2832, "displayName": {"en": "YC124 Clash"}, "materialSetID": 3107}
687	2833	{"_key": 2833, "displayName": {"en": "YC124 Clash"}, "materialSetID": 3108}
688	2834	{"_key": 2834, "displayName": {"en": "YC124 Clash"}, "materialSetID": 3109}
689	2835	{"_key": 2835, "displayName": {"en": "Iceblue Watcher"}, "materialSetID": 3110}
690	2836	{"_key": 2836, "displayName": {"en": "Iceblue Watcher"}, "materialSetID": 3111}
691	2837	{"_key": 2837, "displayName": {"en": "Iceblue Watcher"}, "materialSetID": 3112}
692	2838	{"_key": 2838, "displayName": {"en": "Iceblue Watcher"}, "materialSetID": 3113}
693	2839	{"_key": 2839, "displayName": {"en": "Solitude Frenzy"}, "materialSetID": 3114}
694	2840	{"_key": 2840, "displayName": {"en": "Solitude Frenzy"}, "materialSetID": 3115}
695	2841	{"_key": 2841, "displayName": {"en": "Solitude Frenzy"}, "materialSetID": 3116}
696	2842	{"_key": 2842, "displayName": {"en": "Solitude Frenzy"}, "materialSetID": 3117}
697	2843	{"_key": 2843, "displayName": {"en": "Serenity 2022 Christmas (Orca)"}, "materialSetID": 3124}
698	2846	{"_key": 2846, "displayName": {"en": "Luminae Polaris"}, "materialSetID": 3120}
699	2847	{"_key": 2847, "displayName": {"en": "Luminae Polaris"}, "materialSetID": 3118}
700	2848	{"_key": 2848, "displayName": {"en": "Luminae Polaris"}, "materialSetID": 3119}
701	2849	{"_key": 2849, "displayName": {"en": "Serenity 2022 Christmas (Charon)"}, "materialSetID": 3128}
702	2850	{"_key": 2850, "displayName": {"en": "Serenity 2022 Christmas (Rhea)"}, "materialSetID": 3129}
703	2851	{"_key": 2851, "displayName": {"en": "Serenity 2022 Christmas (Reindeer)"}, "materialSetID": 3105}
704	2852	{"_key": 2852, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 3121}
705	2853	{"_key": 2853, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 3130}
706	2854	{"_key": 2854, "displayName": {"en": "Serenity 2022 Christmas (Raven)"}, "materialSetID": 3133}
707	2855	{"_key": 2855, "displayName": {"en": "Serenity 2022 Christmas (Golem)"}, "materialSetID": 3134}
708	2856	{"_key": 2856, "displayName": {"en": "Serenity 2022 Christmas (RavenNavy)"}, "materialSetID": 3135}
709	2857	{"_key": 2857, "displayName": {"en": "SH 2022 Christmas (Amarr Hulls A)"}, "materialSetID": 3136}
710	2858	{"_key": 2858, "displayName": {"en": "SH 2022 Christmas (Amarr Hulls B)"}, "materialSetID": 3137}
711	2859	{"_key": 2859, "displayName": {"en": "SH 2022 Christmas (Amarr Hulls C)"}, "materialSetID": 3140}
712	2860	{"_key": 2860, "displayName": {"en": "SH 2022 Christmas (Caldari Hulls A)"}, "materialSetID": 3141}
713	2862	{"_key": 2862, "displayName": {"en": "Red Stargazer"}, "materialSetID": 3157}
714	2863	{"_key": 2863, "displayName": {"en": "Red Stargazer"}, "materialSetID": 3158}
715	2864	{"_key": 2864, "displayName": {"en": "Red Stargazer"}, "materialSetID": 3159}
716	2865	{"_key": 2865, "displayName": {"en": "Red Stargazer"}, "materialSetID": 3160}
717	2866	{"_key": 2866, "displayName": {"en": "Red Stargazer"}, "materialSetID": 3161}
718	2867	{"_key": 2867, "displayName": {"en": "Red Stargazer"}, "materialSetID": 3162}
719	2868	{"_key": 2868, "displayName": {"en": "Red Stargazer"}, "materialSetID": 3163}
720	2869	{"_key": 2869, "displayName": {"en": "Minmatar Victory"}, "materialSetID": 3091}
721	2870	{"_key": 2870, "displayName": {"en": "Penumbral Shadows"}, "materialSetID": 3173}
722	2871	{"_key": 2871, "displayName": {"en": "Penumbral Shadows"}, "materialSetID": 3174}
723	2872	{"_key": 2872, "displayName": {"en": "Penumbral Shadows"}, "materialSetID": 3175}
724	2873	{"_key": 2873, "displayName": {"en": "Penumbral Shadows"}, "materialSetID": 3177}
725	2874	{"_key": 2874, "displayName": {"en": "Penumbral Shadows"}, "materialSetID": 3176}
726	2875	{"_key": 2875, "displayName": {"en": "Penumbral Shadows"}, "materialSetID": 3178}
727	2876	{"_key": 2876, "displayName": {"en": "SkyRealm (Capsule)"}, "materialSetID": 3182}
728	2877	{"_key": 2877, "displayName": {"en": "YC125_3 (Oreba T2)"}, "materialSetID": 3184}
729	2878	{"_key": 2878, "displayName": {"en": "YC125_3 (Oreba T1)"}, "materialSetID": 3185}
730	2879	{"_key": 2879, "displayName": {"en": "GalNet StreamCast Unit"}, "materialSetID": 3126}
731	2880	{"_key": 2880, "displayName": {"en": "GalNet StreamCast Unit"}, "materialSetID": 3127}
732	2881	{"_key": 2881, "displayName": {"en": "Sky Realm (Astero)"}, "materialSetID": 3189}
733	2882	{"_key": 2882, "displayName": {"en": "Sky Realm (Epithal)"}, "materialSetID": 3190}
734	2883	{"_key": 2883, "displayName": {"en": "Zydrine Burn"}, "materialSetID": 3192}
735	2884	{"_key": 2884, "displayName": {"en": "Zydrine Burn"}, "materialSetID": 3193}
736	2885	{"_key": 2885, "displayName": {"en": "Wave Breaker (Archon)"}, "materialSetID": 3194}
737	2886	{"_key": 2886, "displayName": {"en": "Wave Breaker (Thanatos)"}, "materialSetID": 3195}
738	2887	{"_key": 2887, "displayName": {"en": "Wave Breaker (FJJJ)"}, "materialSetID": 3196}
739	2888	{"_key": 2888, "displayName": {"en": "Wave Breaker (Chimera)"}, "materialSetID": 3197}
740	2889	{"_key": 2889, "displayName": {"en": "Capsuleer Day XX"}, "materialSetID": 3198}
741	2890	{"_key": 2890, "displayName": {"en": "Capsuleer Day XX"}, "materialSetID": 3199}
742	2891	{"_key": 2891, "displayName": {"en": "Capsuleer Day XX"}, "materialSetID": 3200}
743	2892	{"_key": 2892, "displayName": {"en": "Capsuleer Day XX"}, "materialSetID": 3201}
744	2893	{"_key": 2893, "displayName": {"en": "Capsuleer Day XX"}, "materialSetID": 3202}
745	2894	{"_key": 2894, "displayName": {"en": "Capsuleer Day XX"}, "materialSetID": 3203}
746	2895	{"_key": 2895, "displayName": {"en": "Capsuleer Day XX"}, "materialSetID": 3204}
747	2896	{"_key": 2896, "displayName": {"en": "YC125 Anniversary - Mountain - NightFire"}, "materialSetID": 3211}
748	2897	{"_key": 2897, "displayName": {"en": "YC125 Anniversary - Mountain - Golden Polis"}, "materialSetID": 3212}
749	2898	{"_key": 2898, "displayName": {"en": "YC125 Anniversary - Mountain - Wraith"}, "materialSetID": 3213}
750	2899	{"_key": 2899, "displayName": {"en": "YC125 Anniversary - Mountain - CONCORD Aerospace 'Prototype'"}, "materialSetID": 3214}
751	2900	{"_key": 2900, "displayName": {"en": "YC125 Anniversary - Mountain - Cyber Wave"}, "materialSetID": 3215}
752	2901	{"_key": 2901, "displayName": {"en": "Dewberry Brawl Black Silver"}, "materialSetID": 3216}
753	2902	{"_key": 2902, "displayName": {"en": "Dewberry Brawl Blood Silver"}, "materialSetID": 3217}
754	2903	{"_key": 2903, "displayName": {"en": "Coconut Brawl Black Silver"}, "materialSetID": 3218}
755	2904	{"_key": 2904, "displayName": {"en": "Coconut Brawl Blood Silver"}, "materialSetID": 3219}
756	2905	{"_key": 2905, "displayName": {"en": "Bryony Brawl Black Silver"}, "materialSetID": 3220}
757	2906	{"_key": 2906, "displayName": {"en": "Bryony Brawl Blood Silver"}, "materialSetID": 3221}
758	2907	{"_key": 2907, "displayName": {"en": "Avocado Brawl Black Silver"}, "materialSetID": 3222}
759	2908	{"_key": 2908, "displayName": {"en": "Avocado Brawl Blood Silver"}, "materialSetID": 3223}
760	2909	{"_key": 2909, "displayName": {"en": "YC125 Anniversary - Mountain - Skyline"}, "materialSetID": 3225}
761	2910	{"_key": 2910, "displayName": {"en": "Capsuleer Elite XX"}, "materialSetID": 3207}
762	2911	{"_key": 2911, "displayName": {"en": "Capsuleer Elite XX"}, "materialSetID": 3206}
763	2912	{"_key": 2912, "displayName": {"en": "Capsuleer Elite XX"}, "materialSetID": 3209}
764	2913	{"_key": 2913, "displayName": {"en": "Capsuleer Elite XX"}, "materialSetID": 3208}
765	2914	{"_key": 2914, "displayName": {"en": "Capsuleer Elite XX"}, "materialSetID": 3210}
766	2915	{"_key": 2915, "displayName": {"en": "Gilded Predator"}, "materialSetID": 50}
767	2916	{"_key": 2916, "displayName": {"en": "Gilded Predator"}, "materialSetID": 52}
768	2917	{"_key": 2917, "displayName": {"en": "Gilded Predator"}, "materialSetID": 48}
769	2918	{"_key": 2918, "displayName": {"en": "Gilded Predator"}, "materialSetID": 82}
770	2919	{"_key": 2919, "displayName": {"en": "Gilded Predator"}, "materialSetID": 51}
771	2920	{"_key": 2920, "displayName": {"en": "Gilded Predator"}, "materialSetID": 47}
772	2923	{"_key": 2923, "displayName": {"en": "Sacribis Platinum"}, "materialSetID": 3239}
773	2924	{"_key": 2924, "displayName": {"en": "Sacribis Guristas"}, "materialSetID": 3240}
774	2925	{"_key": 2925, "displayName": {"en": "Sacribis Empire"}, "materialSetID": 3241}
775	2928	{"_key": 2928, "displayName": {"en": "Luminaire Rising"}, "materialSetID": 3248}
776	2929	{"_key": 2929, "displayName": {"en": "infinity_corpskin1"}, "materialSetID": 3252}
777	2930	{"_key": 2930, "displayName": {"en": "infinity_corpskin2"}, "materialSetID": 3253}
778	2931	{"_key": 2931, "displayName": {"en": "infinity_corpskin3"}, "materialSetID": 3254}
779	2932	{"_key": 2932, "displayName": {"en": "infinity_corpskin4"}, "materialSetID": 3255}
780	2933	{"_key": 2933, "displayName": {"en": "infinity_corpskin5"}, "materialSetID": 3256}
781	2934	{"_key": 2934, "displayName": {"en": "infinity_corpskin6"}, "materialSetID": 3258}
782	2935	{"_key": 2935, "displayName": {"en": "infinity_corpskin7"}, "materialSetID": 3259}
783	2936	{"_key": 2936, "displayName": {"en": "infinity_corpskin8"}, "materialSetID": 3260}
784	2937	{"_key": 2937, "displayName": {"en": "infinity_corpskin9"}, "materialSetID": 3261}
785	2938	{"_key": 2938, "displayName": {"en": "infinity_corpskin10"}, "materialSetID": 3262}
786	2939	{"_key": 2939, "displayName": {"en": "infinity_corpskin11"}, "materialSetID": 3263}
787	2940	{"_key": 2940, "displayName": {"en": "infinity_corpskin12"}, "materialSetID": 3264}
788	2941	{"_key": 2941, "displayName": {"en": "infinity_corpskin13"}, "materialSetID": 3265}
789	2942	{"_key": 2942, "displayName": {"en": "infinity_corpskin14"}, "materialSetID": 3266}
790	2943	{"_key": 2943, "displayName": {"en": "infinity_corpskin15"}, "materialSetID": 3267}
791	2944	{"_key": 2944, "displayName": {"en": "infinity_corpskin16"}, "materialSetID": 3268}
792	2945	{"_key": 2945, "displayName": {"en": "infinity_corpskin17"}, "materialSetID": 3269}
793	2946	{"_key": 2946, "displayName": {"en": "infinity_corpskin18"}, "materialSetID": 3270}
794	2947	{"_key": 2947, "displayName": {"en": "infinity_corpskin19"}, "materialSetID": 3271}
795	2948	{"_key": 2948, "displayName": {"en": "infinity_corpskin20"}, "materialSetID": 3272}
796	2951	{"_key": 2951, "displayName": {"en": "Nirvanaflame Predator"}, "materialSetID": 3277}
797	2952	{"_key": 2952, "displayName": {"en": "Sky Realm Athanor cyber"}, "materialSetID": 3250}
798	2953	{"_key": 2953, "displayName": {"en": "Gallente Victory"}, "materialSetID": 3247}
799	2954	{"_key": 2954, "displayName": {"en": "infinity_corpskin21"}, "materialSetID": 3283}
800	2955	{"_key": 2955, "displayName": {"en": "infinity_corpskin22"}, "materialSetID": 3284}
801	2956	{"_key": 2956, "displayName": {"en": "infinity_corpskin23"}, "materialSetID": 3285}
802	2957	{"_key": 2957, "displayName": {"en": "infinity_corpskin24"}, "materialSetID": 3286}
803	2959	{"_key": 2959, "displayName": {"en": "Skyrealm Keepstar"}, "materialSetID": 3290}
804	2960	{"_key": 2960, "displayName": {"en": "Skyrealm Azbel"}, "materialSetID": 3291}
805	2961	{"_key": 2961, "displayName": {"en": "Skyrealm Fortizar"}, "materialSetID": 3292}
806	2962	{"_key": 2962, "displayName": {"en": "Skyrealm Astrahus"}, "materialSetID": 3293}
807	2965	{"_key": 2965, "displayName": {"en": "Immortal Eden"}, "materialSetID": 3279}
808	2966	{"_key": 2966, "displayName": {"en": "Solar Brilliance"}, "materialSetID": 81}
809	2967	{"_key": 2967, "displayName": {"en": "spirit astrahus"}, "materialSetID": 3295}
810	2968	{"_key": 2968, "displayName": {"en": "Verdict \\"Player's Choice\\" SKIN"}, "materialSetID": 3297}
811	2969	{"_key": 2969, "displayName": {"en": "Haemorrhage \\"Player's Choice\\" SKIN"}, "materialSetID": 3298}
812	2970	{"_key": 2970, "displayName": {"en": "nobility athanor"}, "materialSetID": 3300}
813	2971	{"_key": 2971, "displayName": {"en": "Nobility Fortizar"}, "materialSetID": 3301}
814	2972	{"_key": 2972, "displayName": {"en": "nobility keepstar"}, "materialSetID": 3302}
815	2973	{"_key": 2973, "displayName": {"en": "nobility azbel"}, "materialSetID": 3303}
816	2974	{"_key": 2974, "displayName": {"en": "BlackFriday"}, "materialSetID": 2845}
817	2975	{"_key": 2975, "displayName": {"en": "refinery upwell tatara"}, "materialSetID": 3318}
818	2976	{"_key": 2976, "displayName": {"en": "skyrealm tatara"}, "materialSetID": 3317}
819	2977	{"_key": 2977, "displayName": {"en": "Awakening YC125"}, "materialSetID": 3311}
820	2978	{"_key": 2978, "displayName": {"en": "Awakening YC125"}, "materialSetID": 3312}
821	2979	{"_key": 2979, "displayName": {"en": "Awakening YC125"}, "materialSetID": 3313}
822	2980	{"_key": 2980, "displayName": {"en": "Awakening YC125"}, "materialSetID": 3314}
823	2981	{"_key": 2981, "displayName": {"en": "Genolution Dazzle"}, "materialSetID": 3316}
824	2985	{"_key": 2985, "displayName": {"en": "Empyrean Outlaws"}, "materialSetID": 3332}
825	2986	{"_key": 2986, "displayName": {"en": "Empyrean Outlaws"}, "materialSetID": 3333}
826	2987	{"_key": 2987, "displayName": {"en": "SMCA1 skin mat"}, "materialSetID": 3335}
827	2988	{"_key": 2988, "displayName": {"en": "Arkombine Arisen"}, "materialSetID": 3341}
828	2989	{"_key": 2989, "displayName": {"en": "Arkombine Arisen"}, "materialSetID": 3342}
829	2990	{"_key": 2990, "displayName": {"en": "Arkombine Arisen"}, "materialSetID": 3344}
830	2991	{"_key": 2991, "displayName": {"en": "Arkombine Arisen"}, "materialSetID": 3345}
831	2992	{"_key": 2992, "displayName": {"en": "SMCA2 mat"}, "materialSetID": 3346}
832	2993	{"_key": 2993, "displayName": {"en": "SMCA3 skin mat"}, "materialSetID": 3357}
833	2999	{"_key": 2999, "displayName": {"en": "Arkombine Arisen"}, "materialSetID": 3364}
834	3004	{"_key": 3004, "displayName": {"en": "Luminae Polaris"}, "materialSetID": 3358}
835	3005	{"_key": 3005, "displayName": {"en": "Luminae Polaris"}, "materialSetID": 3359}
836	3006	{"_key": 3006, "displayName": {"en": "Luminae Polaris"}, "materialSetID": 3360}
837	3007	{"_key": 3007, "displayName": {"en": "Luminae Polaris"}, "materialSetID": 3361}
838	3009	{"_key": 3009, "displayName": {"en": "SMCA4 skin mat"}, "materialSetID": 3369}
839	3010	{"_key": 3010, "displayName": {"en": "SMCA5 skin mat"}, "materialSetID": 3370}
840	3011	{"_key": 3011, "displayName": {"en": "SMCA6 skin mat"}, "materialSetID": 3372}
841	3014	{"_key": 3014, "displayName": {"en": "Gabriel - Nightfire"}, "materialSetID": 3377}
842	3015	{"_key": 3015, "displayName": {"en": "Gabriel - Golden Polis"}, "materialSetID": 3378}
843	3016	{"_key": 3016, "displayName": {"en": "Gabriel - Heartsurge"}, "materialSetID": 3379}
844	3017	{"_key": 3017, "displayName": {"en": "Gabriel - Angel's Hex"}, "materialSetID": 3380}
845	3018	{"_key": 3018, "displayName": {"en": "Gabriel - Deathglow Hunters"}, "materialSetID": 3381}
846	3020	{"_key": 3020, "displayName": {"en": "Phoenix NI - Wraith"}, "materialSetID": 3382}
847	3021	{"_key": 3021, "displayName": {"en": "Imperial Police"}, "materialSetID": 3374}
848	3022	{"_key": 3022, "displayName": {"en": "Republic Police"}, "materialSetID": 3375}
849	3023	{"_key": 3023, "displayName": {"en": "Aegis Police"}, "materialSetID": 3376}
850	3026	{"_key": 3026, "displayName": {"en": "Arkombine Arisen"}, "materialSetID": 3386}
851	3027	{"_key": 3027, "displayName": {"en": "Arkombine Arisen"}, "materialSetID": 3387}
852	3029	{"_key": 3029, "displayName": {"en": "Empyrean Dragons"}, "materialSetID": 3390}
853	3030	{"_key": 3030, "displayName": {"en": "Empyrean Dragons"}, "materialSetID": 3391}
854	3031	{"_key": 3031, "displayName": {"en": "Empyrean Dragons"}, "materialSetID": 3392}
855	3032	{"_key": 3032, "displayName": {"en": "Empyrean Dragons"}, "materialSetID": 3393}
856	3033	{"_key": 3033, "displayName": {"en": "Empyrean Dragons"}, "materialSetID": 3394}
857	3035	{"_key": 3035, "displayName": {"en": "Arkombine Arisen"}, "materialSetID": 3398}
858	3036	{"_key": 3036, "displayName": {"en": "Zydrine Burn"}, "materialSetID": 3400}
859	3037	{"_key": 3037, "displayName": {"en": "Zydrine Burn"}, "materialSetID": 3401}
860	3038	{"_key": 3038, "displayName": {"en": "Capsuleer Day XXI"}, "materialSetID": 3413}
861	3039	{"_key": 3039, "displayName": {"en": "Capsuleer Day XXI"}, "materialSetID": 3412}
862	3040	{"_key": 3040, "displayName": {"en": "Capsuleer Day XXI"}, "materialSetID": 3411}
863	3041	{"_key": 3041, "displayName": {"en": "Capsuleer Day XXI"}, "materialSetID": 3410}
864	3042	{"_key": 3042, "displayName": {"en": "Capsuleer Day XXI"}, "materialSetID": 3409}
865	3043	{"_key": 3043, "displayName": {"en": "Capsuleer Day XXI"}, "materialSetID": 3408}
866	3044	{"_key": 3044, "displayName": {"en": "Capsuleer Day XXI"}, "materialSetID": 3407}
867	3045	{"_key": 3045, "displayName": {"en": "Capsuleer Day XXI"}, "materialSetID": 3406}
868	3046	{"_key": 3046, "displayName": {"en": "Capsuleer Day XXI"}, "materialSetID": 3405}
869	3047	{"_key": 3047, "displayName": {"en": "Capsuleer Day XXI"}, "materialSetID": 3404}
870	3049	{"_key": 3049, "displayName": {"en": "Golden Polis"}, "materialSetID": 3417}
871	3051	{"_key": 3051, "displayName": {"en": "Blackfire Steel"}, "materialSetID": 3418}
872	3052	{"_key": 3052, "displayName": {"en": "Midnight"}, "materialSetID": 3419}
873	3053	{"_key": 3053, "displayName": {"en": "Purple Camouflage"}, "materialSetID": 3420}
874	3054	{"_key": 3054, "displayName": {"en": "Quafe Green Apple"}, "materialSetID": 3421}
875	3055	{"_key": 3055, "displayName": {"en": "War for the Empire"}, "materialSetID": 3422}
876	3056	{"_key": 3056, "displayName": {"en": "War for the State"}, "materialSetID": 3423}
877	3057	{"_key": 3057, "displayName": {"en": "War for the Federation"}, "materialSetID": 3424}
878	3058	{"_key": 3058, "displayName": {"en": "War for the Republic"}, "materialSetID": 3425}
879	3059	{"_key": 3059, "displayName": {"en": "Equinox Era"}, "materialSetID": 3426}
880	3060	{"_key": 3060, "displayName": {"en": "Equinox Era"}, "materialSetID": 3427}
881	3061	{"_key": 3061, "displayName": {"en": "Media Miasma"}, "materialSetID": 3429}
882	3062	{"_key": 3062, "displayName": {"en": "Media Miasma"}, "materialSetID": 3430}
883	3063	{"_key": 3063, "displayName": {"en": "Media Miasma"}, "materialSetID": 3431}
884	3064	{"_key": 3064, "displayName": {"en": "Media Miasma"}, "materialSetID": 3432}
885	3065	{"_key": 3065, "displayName": {"en": "Media Miasma"}, "materialSetID": 3433}
886	3066	{"_key": 3066, "displayName": {"en": "Media Miasma"}, "materialSetID": 3434}
887	3067	{"_key": 3067, "displayName": {"en": "Media Miasma"}, "materialSetID": 3435}
888	3069	{"_key": 3069, "displayName": {"en": "Flash Obsidian"}, "materialSetID": 3439}
889	3070	{"_key": 3070, "displayName": {"en": "Mabebu Exchange"}, "materialSetID": 3440}
890	3071	{"_key": 3071, "displayName": {"en": "Mabebu Exchange"}, "materialSetID": 3441}
891	3072	{"_key": 3072, "displayName": {"en": "Mabebu Exchange"}, "materialSetID": 3442}
892	3073	{"_key": 3073, "displayName": {"en": "Mabebu Exchange"}, "materialSetID": 3443}
893	3074	{"_key": 3074, "displayName": {"en": "Mabebu Exchange"}, "materialSetID": 3444}
894	3075	{"_key": 3075, "displayName": {"en": "infinity_corpskin25"}, "materialSetID": 3464}
895	3076	{"_key": 3076, "displayName": {"en": "Autumn Night"}, "materialSetID": 3465}
896	3077	{"_key": 3077, "displayName": {"en": "Empyrean Outlaws"}, "materialSetID": 3470}
897	3078	{"_key": 3078, "displayName": {"en": "Empyrean Outlaws"}, "materialSetID": 3471}
898	3079	{"_key": 3079, "displayName": {"en": "Empyrean Outlaws"}, "materialSetID": 3472}
899	3080	{"_key": 3080, "displayName": {"en": "CONCORD Victory"}, "materialSetID": 3473}
900	3081	{"_key": 3081, "displayName": {"en": "Victorious Venom"}, "materialSetID": 3474}
901	3094	{"_key": 3094, "displayName": {"en": "Arkombine Arisen"}, "materialSetID": 3461}
902	3095	{"_key": 3095, "displayName": {"en": "Arkombine Arisen"}, "materialSetID": 3462}
903	3096	{"_key": 3096, "displayName": {"en": "Arkombine Arisen"}, "materialSetID": 3463}
904	3097	{"_key": 3097, "displayName": {"en": "Luminae Polaris"}, "materialSetID": 3468}
905	3098	{"_key": 3098, "displayName": {"en": "Luminae Polaris"}, "materialSetID": 3469}
906	3099	{"_key": 3099, "displayName": {"en": "Warm Sunshine"}, "materialSetID": 3491}
907	3100	{"_key": 3100, "displayName": {"en": "Dark Shadow"}, "materialSetID": 3492}
908	3101	{"_key": 3101, "displayName": {"en": "Red Tempreture"}, "materialSetID": 3493}
909	3102	{"_key": 3102, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 3455}
910	3103	{"_key": 3103, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 3456}
911	3104	{"_key": 3104, "displayName": {"en": "Shattered Paradigm"}, "materialSetID": 3488}
912	3105	{"_key": 3105, "displayName": {"en": "Shattered Paradigm"}, "materialSetID": 3489}
913	3106	{"_key": 3106, "displayName": {"en": "Shattered Paradigm"}, "materialSetID": 3490}
914	3107	{"_key": 3107, "displayName": {"en": "Athanor Dragon Skin"}, "materialSetID": 3497}
915	3108	{"_key": 3108, "displayName": {"en": "Keepstar Dragon Skin"}, "materialSetID": 3498}
916	3109	{"_key": 3109, "displayName": {"en": "Azbel Dragon Skin"}, "materialSetID": 3499}
917	3110	{"_key": 3110, "displayName": {"en": "Raitaru Dragon Skin"}, "materialSetID": 3500}
918	3111	{"_key": 3111, "displayName": {"en": "Fortizar Dragon Skin"}, "materialSetID": 3501}
919	3112	{"_key": 3112, "displayName": {"en": "Astrahus Dragon Skin"}, "materialSetID": 3502}
920	3113	{"_key": 3113, "displayName": {"en": "Sotiyo Dragon Skin"}, "materialSetID": 3503}
921	3114	{"_key": 3114, "displayName": {"en": "Tatara Dragon Skin"}, "materialSetID": 3504}
922	3115	{"_key": 3115, "displayName": {"en": "Ansiblex Jump Gate Dragon Skin"}, "materialSetID": 3505}
923	3117	{"_key": 3117, "displayName": {"en": "Stellian Icecream Skin"}, "materialSetID": 3511}
924	3118	{"_key": 3118, "displayName": {"en": "YC127 Spring Rattlesnake"}, "materialSetID": 3517}
925	3119	{"_key": 3119, "displayName": {"en": "Celestial Coalescence"}, "materialSetID": 3512}
926	3120	{"_key": 3120, "displayName": {"en": "Celestial Coalescence"}, "materialSetID": 3513}
927	3121	{"_key": 3121, "displayName": {"en": "Celestial Coalescence"}, "materialSetID": 3514}
928	3122	{"_key": 3122, "displayName": {"en": "Celestial Coalescence"}, "materialSetID": 3515}
929	3123	{"_key": 3123, "displayName": {"en": "Celestial Coalescence"}, "materialSetID": 3516}
930	3124	{"_key": 3124, "displayName": {"en": "YC127 Spring Mamba"}, "materialSetID": 3518}
931	3126	{"_key": 3126, "displayName": {"en": "Resplendent Coil"}, "materialSetID": 3522}
932	3127	{"_key": 3127, "displayName": {"en": "Resplendent Coil"}, "materialSetID": 3524}
933	3128	{"_key": 3128, "displayName": {"en": "Zydrine Burn"}, "materialSetID": 3526}
934	3129	{"_key": 3129, "displayName": {"en": "Federal Police"}, "materialSetID": 3527}
935	3130	{"_key": 3130, "displayName": {"en": "Khanid Cyber Knight"}, "materialSetID": 3528}
936	3131	{"_key": 3131, "displayName": {"en": "Khanid Cyber Knight"}, "materialSetID": 3529}
937	3132	{"_key": 3132, "displayName": {"en": "Stellian Golden Polis SKIN"}, "materialSetID": 3531}
938	3134	{"_key": 3134, "displayName": {"en": "Tyrantbreaker"}, "materialSetID": 3532}
939	3135	{"_key": 3135, "displayName": {"en": "Tyrantbreaker"}, "materialSetID": 3534}
940	3136	{"_key": 3136, "displayName": {"en": "Tyrantbreaker"}, "materialSetID": 3535}
941	3137	{"_key": 3137, "displayName": {"en": "Tyrantbreaker"}, "materialSetID": 3537}
942	3138	{"_key": 3138, "displayName": {"en": "Tyrantbreaker"}, "materialSetID": 3538}
943	3139	{"_key": 3139, "displayName": {"en": "Tyrantbreaker"}, "materialSetID": 3536}
944	3140	{"_key": 3140, "displayName": {"en": "Tyrantbreaker"}, "materialSetID": 3533}
945	3141	{"_key": 3141, "displayName": {"en": "Tyrantbreaker"}, "materialSetID": 3539}
946	3142	{"_key": 3142, "displayName": {"en": "Tyrantbreaker"}, "materialSetID": 3540}
947	3143	{"_key": 3143, "displayName": {"en": "Tyrantbreaker"}, "materialSetID": 3541}
948	3144	{"_key": 3144, "displayName": {"en": "Tyrantbreaker"}, "materialSetID": 3542}
949	3145	{"_key": 3145, "displayName": {"en": "Blackbody Drift"}, "materialSetID": 3547}
950	3146	{"_key": 3146, "displayName": {"en": "Sponsored Security"}, "materialSetID": 3548}
951	3147	{"_key": 3147, "displayName": {"en": "Sponsored Security"}, "materialSetID": 3549}
952	3148	{"_key": 3148, "displayName": {"en": "Sponsored Security"}, "materialSetID": 3550}
953	3149	{"_key": 3149, "displayName": {"en": "Python CN Skin MaterialSet"}, "materialSetID": 3551}
954	3150	{"_key": 3150, "displayName": {"en": "Python Night Hunter Skin MaterialSet"}, "materialSetID": 3552}
955	3151	{"_key": 3151, "displayName": {"en": "Python Traditional Guristas Skin MaterialSet"}, "materialSetID": 3553}
956	3152	{"_key": 3152, "displayName": {"en": "Python Golden Polis Skin MaterialSet"}, "materialSetID": 3554}
957	3153	{"_key": 3153, "displayName": {"en": "Azdaja Extirpated"}, "materialSetID": 3555}
958	3154	{"_key": 3154, "displayName": {"en": "Monster Pink (Mordu Hulls)"}, "materialSetID": 3556}
959	3155	{"_key": 3155, "displayName": {"en": "Hrada-Oki Offender"}, "materialSetID": 3559}
960	3156	{"_key": 3156, "displayName": {"en": "Khanid Cyber Knight"}, "materialSetID": 3560}
961	3157	{"_key": 3157, "displayName": {"en": "Crescent Carthum"}, "materialSetID": 3561}
962	3158	{"_key": 3158, "displayName": {"en": "Crescent Imperial"}, "materialSetID": 2645}
963	3159	{"_key": 3159, "displayName": {"en": "Crescent Bloody Moon"}, "materialSetID": 3562}
964	3160	{"_key": 3160, "displayName": {"en": "Arkombine Arisen"}, "materialSetID": 3563}
965	3161	{"_key": 3161, "displayName": {"en": "Deathglow Remnant"}, "materialSetID": 3567}
966	3163	{"_key": 3163, "displayName": {"en": "Cold Wind's Call"}, "materialSetID": 3568}
967	3164	{"_key": 3164, "displayName": {"en": "Ore Steam Punk Skin"}, "materialSetID": 3569}
968	3165	{"_key": 3165, "displayName": {"en": "Steampunk Structure Skin - Athanor"}, "materialSetID": 3570}
969	3169	{"_key": 3169, "displayName": {"en": "Sanguinary Savant"}, "materialSetID": 3572}
970	3170	{"_key": 3170, "displayName": {"en": "Steampunk Structure Skin - Tatara"}, "materialSetID": 3570}
971	3174	{"_key": 3174, "displayName": {"en": "Azdaja Extirpated"}, "materialSetID": 3575}
972	3175	{"_key": 3175, "displayName": {"en": "Shattered Paradigm"}, "materialSetID": 3576}
973	3176	{"_key": 3176, "displayName": {"en": "Shattered Paradigm"}, "materialSetID": 3573}
974	3177	{"_key": 3177, "displayName": {"en": "Shattered Paradigm"}, "materialSetID": 3574}
975	3178	{"_key": 3178, "displayName": {"en": "Sanguinary Savant"}, "materialSetID": 3579}
976	3179	{"_key": 3179, "displayName": {"en": "Refined Resourcer"}, "materialSetID": 3583}
977	3180	{"_key": 3180, "displayName": {"en": "Aurora Universalis"}, "materialSetID": 3585}
978	3181	{"_key": 3181, "displayName": {"en": "Refined Resourcer"}, "materialSetID": 3586}
979	3182	{"_key": 3182, "displayName": {"en": "Caldari Victory"}, "materialSetID": 3589}
980	3183	{"_key": 3183, "displayName": {"en": "Friendship League"}, "materialSetID": 3600}
981	3184	{"_key": 3184, "displayName": {"en": "Friendship League"}, "materialSetID": 3601}
982	3185	{"_key": 3185, "displayName": {"en": "Media Miasma"}, "materialSetID": 3602}
983	3186	{"_key": 3186, "displayName": {"en": "Media Miasma"}, "materialSetID": 3603}
984	3187	{"_key": 3187, "displayName": {"en": "Media Miasma"}, "materialSetID": 3604}
985	3188	{"_key": 3188, "displayName": {"en": "Media Miasma"}, "materialSetID": 3605}
986	3189	{"_key": 3189, "displayName": {"en": "Media Miasma"}, "materialSetID": 3606}
987	3190	{"_key": 3190, "displayName": {"en": "Media Miasma"}, "materialSetID": 3607}
988	3191	{"_key": 3191, "displayName": {"en": "Media Miasma"}, "materialSetID": 3608}
989	3192	{"_key": 3192, "displayName": {"en": "Macherial YC128 new year"}, "materialSetID": 3609}
990	3193	{"_key": 3193, "displayName": {"en": "Khizriel YC128 new year"}, "materialSetID": 3610}
991	3194	{"_key": 3194, "displayName": {"en": "Anhinga Incoming Warning"}, "materialSetID": 3611}
992	3195	{"_key": 3195, "displayName": {"en": "Skua Incoming Warning"}, "materialSetID": 3612}
993	3196	{"_key": 3196, "displayName": {"en": "Naga Incoming Warning"}, "materialSetID": 3613}
994	3197	{"_key": 3197, "displayName": {"en": "Jackdaw Incoming Warning"}, "materialSetID": 3614}
995	3198	{"_key": 3198, "displayName": {"en": "Unbridled Glory"}, "materialSetID": 3628}
996	3199	{"_key": 3199, "displayName": {"en": "Unbridled Glory"}, "materialSetID": 3629}
997	3200	{"_key": 3200, "displayName": {"en": "Unbridled Glory"}, "materialSetID": 3630}
998	3201	{"_key": 3201, "displayName": {"en": "Unbridled Glory"}, "materialSetID": 3631}
999	3202	{"_key": 3202, "displayName": {"en": "Unbridled Glory"}, "materialSetID": 3632}
1000	3203	{"_key": 3203, "displayName": {"en": "Discovery Bound"}, "materialSetID": 3634}
1001	3204	{"_key": 3204, "displayName": {"en": "Cryptic Ecdysis"}, "materialSetID": 3637}
1002	3205	{"_key": 3205, "displayName": {"en": "Pride of the Federation"}, "materialSetID": 3638}
1003	3206	{"_key": 3206, "displayName": {"en": "Pride of the Federation"}, "materialSetID": 3639}
1004	3207	{"_key": 3207, "displayName": {"en": "Pride of the Federation"}, "materialSetID": 3640}
1005	3209	{"_key": 3209, "displayName": {"en": "Penumbral Shadows"}, "materialSetID": 3646}
1006	3210	{"_key": 3210, "displayName": {"en": "Penumbral Shadows"}, "materialSetID": 3645}
1007	3214	{"_key": 3214, "displayName": {"en": "Capsuleer Day XXIII"}, "materialSetID": 3647}
1008	3215	{"_key": 3215, "displayName": {"en": "Capsuleer Day XXIII"}, "materialSetID": 3648}
1009	3216	{"_key": 3216, "displayName": {"en": "Capsuleer Day XXIII"}, "materialSetID": 3649}
1010	3217	{"_key": 3217, "displayName": {"en": "Capsuleer Day XXIII"}, "materialSetID": 3650}
1011	3218	{"_key": 3218, "displayName": {"en": "Physeter XXXX"}, "materialSetID": 3664}
1012	3219	{"_key": 3219, "displayName": {"en": "Physeter Federation"}, "materialSetID": 3651}
1013	3220	{"_key": 3220, "displayName": {"en": "Physeter DeepSpace(CyberKnight)"}, "materialSetID": 3663}
1014	3221	{"_key": 3221, "displayName": {"en": "Mandate of Faith"}, "materialSetID": 3656}
1015	3222	{"_key": 3222, "displayName": {"en": "State Regulator"}, "materialSetID": 3657}
1016	3223	{"_key": 3223, "displayName": {"en": "Presidential Agent"}, "materialSetID": 3658}
1017	3224	{"_key": 3224, "displayName": {"en": "Stark Strategist"}, "materialSetID": 3659}
1018	3225	{"_key": 3225, "displayName": {"en": "Forever Creative"}, "materialSetID": 3661}
1019	3227	{"_key": 3227, "displayName": {"en": "Presidential Agent"}, "materialSetID": 3668}
1020	3228	{"_key": 3228, "displayName": {"en": "Serenity 20th Amarr"}, "materialSetID": 3669}
1021	3229	{"_key": 3229, "displayName": {"en": "Serenity 20th Caldari"}, "materialSetID": 3670}
1022	3230	{"_key": 3230, "displayName": {"en": "Serenity 20th Gallente"}, "materialSetID": 3671}
1023	3231	{"_key": 3231, "displayName": {"en": "Serenity 20th Minmatar"}, "materialSetID": 3672}
1024	3232	{"_key": 3232, "displayName": {"en": "Serenity 20th Capsule"}, "materialSetID": 3673}
1025	3233	{"_key": 3233, "displayName": {"en": "Forever Creative"}, "materialSetID": 3676}
1026	3234	{"_key": 3234, "displayName": {"en": "Forever Creative"}, "materialSetID": 3677}
1027	3235	{"_key": 3235, "displayName": {"en": "Forever Creative"}, "materialSetID": 3678}
1028	3236	{"_key": 3236, "displayName": {"en": "Forever Creative"}, "materialSetID": 3679}
1029	3237	{"_key": 3237, "displayName": {"en": "Vedmak YC128 new year"}, "materialSetID": 3686}
\.


--
-- Name: skinmaterials skinmaterials_pkey; Type: CONSTRAINT; Schema: sde_compat; Owner: -
--

ALTER TABLE ONLY sde_compat.skinmaterials
    ADD CONSTRAINT skinmaterials_pkey PRIMARY KEY (row_no);


--
-- Name: skinmaterials_key_idx; Type: INDEX; Schema: sde_compat; Owner: -
--

CREATE INDEX skinmaterials_key_idx ON sde_compat.skinmaterials USING btree (key);


--
-- PostgreSQL database dump complete
--

\unrestrict PbtybTimMrYiXsKN2dJHikjLbcmvwdc0lcVoGW2IaqmLKALkTA6wo8ghk5gEiih

