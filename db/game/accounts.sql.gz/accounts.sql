--
-- PostgreSQL database dump
--

\restrict mwg5EhgYWZFUhMieuZsY5UaiFw0oNLDymwlUrIDM3AbMiKugtw0rJCnBtTfvRlG

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.accounts (
    user_id bigint NOT NULL,
    user_name text NOT NULL,
    password_hash bytea NOT NULL,
    role bigint NOT NULL,
    user_type integer DEFAULT 20 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_login timestamp with time zone,
    plex_balance bigint DEFAULT 1000 NOT NULL
);


--
-- Name: accounts_user_id_seq; Type: SEQUENCE; Schema: game; Owner: -
--

CREATE SEQUENCE game.accounts_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accounts_user_id_seq; Type: SEQUENCE OWNED BY; Schema: game; Owner: -
--

ALTER SEQUENCE game.accounts_user_id_seq OWNED BY game.accounts.user_id;


--
-- Name: accounts user_id; Type: DEFAULT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.accounts ALTER COLUMN user_id SET DEFAULT nextval('game.accounts_user_id_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.accounts (user_id, user_name, password_hash, role, user_type, created_at, last_login, plex_balance) FROM stdin;
10000001	tester	\\xb7c129f04df6cc72819b7240e309407e830f4be7	6944550625405571072	20	2026-10-27 01:28:17.738258+00	2026-10-27 10:58:01.332882+00	1000
\.


--
-- Name: accounts_user_id_seq; Type: SEQUENCE SET; Schema: game; Owner: -
--

SELECT pg_catalog.setval('game.accounts_user_id_seq', 10000001, true);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (user_id);


--
-- Name: accounts_user_name_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE UNIQUE INDEX accounts_user_name_idx ON game.accounts USING btree (lower(user_name));


--
-- PostgreSQL database dump complete
--

\unrestrict mwg5EhgYWZFUhMieuZsY5UaiFw0oNLDymwlUrIDM3AbMiKugtw0rJCnBtTfvRlG

