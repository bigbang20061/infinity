--
-- PostgreSQL database dump
--

\restrict qzcmiOm6DsamSQdFxDf5fJw9fDuQ67aCRO8yRP1WozaJDzoqWhLVEIyO455MMI9

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: fittings; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.fittings (
    fitting_id bigint NOT NULL,
    owner_id bigint NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    ship_type_id integer NOT NULL,
    fit_types integer[] DEFAULT '{}'::integer[] NOT NULL,
    fit_flags integer[] DEFAULT '{}'::integer[] NOT NULL,
    fit_qty integer[] DEFAULT '{}'::integer[] NOT NULL
);


--
-- Name: fittings_fitting_id_seq; Type: SEQUENCE; Schema: game; Owner: -
--

CREATE SEQUENCE game.fittings_fitting_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fittings_fitting_id_seq; Type: SEQUENCE OWNED BY; Schema: game; Owner: -
--

ALTER SEQUENCE game.fittings_fitting_id_seq OWNED BY game.fittings.fitting_id;


--
-- Name: fittings fitting_id; Type: DEFAULT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.fittings ALTER COLUMN fitting_id SET DEFAULT nextval('game.fittings_fitting_id_seq'::regclass);


--
-- Data for Name: fittings; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.fittings (fitting_id, owner_id, name, description, ship_type_id, fit_types, fit_flags, fit_qty) FROM stdin;
\.


--
-- Name: fittings_fitting_id_seq; Type: SEQUENCE SET; Schema: game; Owner: -
--

SELECT pg_catalog.setval('game.fittings_fitting_id_seq', 1, false);


--
-- Name: fittings fittings_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.fittings
    ADD CONSTRAINT fittings_pkey PRIMARY KEY (fitting_id);


--
-- Name: fittings_owner_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX fittings_owner_idx ON game.fittings USING btree (owner_id);


--
-- PostgreSQL database dump complete
--

\unrestrict qzcmiOm6DsamSQdFxDf5fJw9fDuQ67aCRO8yRP1WozaJDzoqWhLVEIyO455MMI9

