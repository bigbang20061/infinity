--
-- PostgreSQL database dump
--

\restrict oM6bhDZdHfjtOWLZ9lXB8fh7bBilu3DNOxB5ayddX7MmcbHXFGvMT4gzO3CqevW

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: mail_messages; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.mail_messages (
    message_id bigint NOT NULL,
    sender_id bigint NOT NULL,
    to_character_ids text DEFAULT ''::text NOT NULL,
    to_list_id bigint,
    to_corp_or_alliance_id bigint,
    title text NOT NULL,
    body text NOT NULL,
    sent_date bigint NOT NULL
);


--
-- Name: mail_messages_message_id_seq; Type: SEQUENCE; Schema: game; Owner: -
--

CREATE SEQUENCE game.mail_messages_message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mail_messages_message_id_seq; Type: SEQUENCE OWNED BY; Schema: game; Owner: -
--

ALTER SEQUENCE game.mail_messages_message_id_seq OWNED BY game.mail_messages.message_id;


--
-- Name: mail_messages message_id; Type: DEFAULT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.mail_messages ALTER COLUMN message_id SET DEFAULT nextval('game.mail_messages_message_id_seq'::regclass);


--
-- Data for Name: mail_messages; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.mail_messages (message_id, sender_id, to_character_ids, to_list_id, to_corp_or_alliance_id, title, body, sent_date) FROM stdin;
\.


--
-- Name: mail_messages_message_id_seq; Type: SEQUENCE SET; Schema: game; Owner: -
--

SELECT pg_catalog.setval('game.mail_messages_message_id_seq', 1, false);


--
-- Name: mail_messages mail_messages_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.mail_messages
    ADD CONSTRAINT mail_messages_pkey PRIMARY KEY (message_id);


--
-- PostgreSQL database dump complete
--

\unrestrict oM6bhDZdHfjtOWLZ9lXB8fh7bBilu3DNOxB5ayddX7MmcbHXFGvMT4gzO3CqevW

