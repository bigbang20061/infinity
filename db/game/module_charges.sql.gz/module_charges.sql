--
-- PostgreSQL database dump
--

\restrict sCW46MByJiY6ORdcJMacBIeSxNqUdBD45adEaX2ydRDrafi4iORBT0KHUOL1p8m

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: module_charges; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.module_charges (
    ship_id bigint NOT NULL,
    flag_id integer NOT NULL,
    type_id integer NOT NULL,
    quantity integer NOT NULL
);


--
-- Data for Name: module_charges; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.module_charges (ship_id, flag_id, type_id, quantity) FROM stdin;
1000000000004	32	206	40
1000000000004	27	206	36
1000000000004	29	206	36
1000000000004	28	206	36
1000000000004	30	206	36
1000000000004	31	206	36
\.


--
-- Name: module_charges module_charges_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.module_charges
    ADD CONSTRAINT module_charges_pkey PRIMARY KEY (ship_id, flag_id);


--
-- PostgreSQL database dump complete
--

\unrestrict sCW46MByJiY6ORdcJMacBIeSxNqUdBD45adEaX2ydRDrafi4iORBT0KHUOL1p8m

