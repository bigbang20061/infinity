--
-- PostgreSQL database dump
--

\restrict 8w6cxGZ4BN9wz8qAdTK8G33HCKBGtuNg5LpR5MS373K1BqzL6QZK8O9hdifPcst

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: corp_applications; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.corp_applications (
    application_id bigint NOT NULL,
    corporation_id bigint NOT NULL,
    character_id bigint NOT NULL,
    application_text text NOT NULL,
    status integer NOT NULL,
    created bigint NOT NULL,
    custom_message text DEFAULT ''::text NOT NULL
);


--
-- Name: corp_applications_application_id_seq; Type: SEQUENCE; Schema: game; Owner: -
--

CREATE SEQUENCE game.corp_applications_application_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: corp_applications_application_id_seq; Type: SEQUENCE OWNED BY; Schema: game; Owner: -
--

ALTER SEQUENCE game.corp_applications_application_id_seq OWNED BY game.corp_applications.application_id;


--
-- Name: corp_applications application_id; Type: DEFAULT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.corp_applications ALTER COLUMN application_id SET DEFAULT nextval('game.corp_applications_application_id_seq'::regclass);


--
-- Data for Name: corp_applications; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.corp_applications (application_id, corporation_id, character_id, application_text, status, created, custom_message) FROM stdin;
\.


--
-- Name: corp_applications_application_id_seq; Type: SEQUENCE SET; Schema: game; Owner: -
--

SELECT pg_catalog.setval('game.corp_applications_application_id_seq', 1, false);


--
-- Name: corp_applications corp_applications_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.corp_applications
    ADD CONSTRAINT corp_applications_pkey PRIMARY KEY (application_id);


--
-- Name: corp_applications_char_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX corp_applications_char_idx ON game.corp_applications USING btree (character_id, status);


--
-- Name: corp_applications_corp_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX corp_applications_corp_idx ON game.corp_applications USING btree (corporation_id, status);


--
-- PostgreSQL database dump complete
--

\unrestrict 8w6cxGZ4BN9wz8qAdTK8G33HCKBGtuNg5LpR5MS373K1BqzL6QZK8O9hdifPcst

