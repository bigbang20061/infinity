--
-- PostgreSQL database dump
--

\restrict hZbKZGa6Y6J5OCWxMgAAp36C1DKuL4mUNaPZodZg9NSCE0RtZJUg4Pm8XLNc4oI

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: employment_history; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.employment_history (
    char_id bigint NOT NULL,
    corporation_id bigint NOT NULL,
    start_date bigint NOT NULL
);


--
-- Data for Name: employment_history; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.employment_history (char_id, corporation_id, start_date) FROM stdin;
\.


--
-- Name: employment_history_char_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX employment_history_char_idx ON game.employment_history USING btree (char_id, start_date);


--
-- PostgreSQL database dump complete
--

\unrestrict hZbKZGa6Y6J5OCWxMgAAp36C1DKuL4mUNaPZodZg9NSCE0RtZJUg4Pm8XLNc4oI

