--
-- PostgreSQL database dump
--

\restrict iWnITgxcoIasHj9VaZk4p1S0i1ALHiw8VTVAs6m9Z6U2Ofyx6dYyiVMyZdQ6ay5

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: skill_plans; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.skill_plans (
    plan_id bytea NOT NULL,
    character_id bigint NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    skill_ids integer[] DEFAULT '{}'::integer[] NOT NULL,
    levels integer[] DEFAULT '{}'::integer[] NOT NULL,
    active boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Data for Name: skill_plans; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.skill_plans (plan_id, character_id, name, description, skill_ids, levels, active, created_at) FROM stdin;
\.


--
-- Name: skill_plans skill_plans_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.skill_plans
    ADD CONSTRAINT skill_plans_pkey PRIMARY KEY (plan_id);


--
-- Name: skill_plans_character_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX skill_plans_character_idx ON game.skill_plans USING btree (character_id);


--
-- Name: skill_plans skill_plans_character_id_fkey; Type: FK CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.skill_plans
    ADD CONSTRAINT skill_plans_character_id_fkey FOREIGN KEY (character_id) REFERENCES game.characters(character_id);


--
-- PostgreSQL database dump complete
--

\unrestrict iWnITgxcoIasHj9VaZk4p1S0i1ALHiw8VTVAs6m9Z6U2Ofyx6dYyiVMyZdQ6ay5

