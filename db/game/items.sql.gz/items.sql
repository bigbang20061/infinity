--
-- PostgreSQL database dump
--

\restrict iT54BieuOaGYRoc3j6T7mTmGaQZsMQwmagDYH8pM6DH1Dfa7UXRdaTXvdOMRM0u

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: items; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.items (
    item_id bigint NOT NULL,
    type_id integer NOT NULL,
    owner_id bigint NOT NULL,
    location_id bigint NOT NULL,
    flag_id integer NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    singleton boolean DEFAULT false NOT NULL,
    custom_info text,
    name text,
    x double precision,
    y double precision,
    z double precision,
    online boolean DEFAULT false NOT NULL
);


--
-- Name: items_item_id_seq; Type: SEQUENCE; Schema: game; Owner: -
--

CREATE SEQUENCE game.items_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: items_item_id_seq; Type: SEQUENCE OWNED BY; Schema: game; Owner: -
--

ALTER SEQUENCE game.items_item_id_seq OWNED BY game.items.item_id;


--
-- Name: items item_id; Type: DEFAULT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.items ALTER COLUMN item_id SET DEFAULT nextval('game.items_item_id_seq'::regclass);


--
-- Data for Name: items; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.items (item_id, type_id, owner_id, location_id, flag_id, quantity, singleton, custom_info, name, x, y, z, online) FROM stdin;
1000000000001	606	90000001	60015049	4	1	t	\N	\N	\N	\N	\N	f
1000000000002	601	90000002	60015159	4	1	t	\N	\N	\N	\N	\N	f
1000000000006	208	90000002	1000000000004	5	1000	f	\N	\N	\N	\N	\N	f
1000000000007	207	90000002	1000000000004	5	1000	f	\N	\N	\N	\N	\N	f
1000000000009	2410	90000002	1000000000004	27	1	t	\N	\N	\N	\N	\N	t
1000000000010	2410	90000002	1000000000004	28	1	t	\N	\N	\N	\N	\N	t
1000000000011	2410	90000002	1000000000004	29	1	t	\N	\N	\N	\N	\N	t
1000000000012	2410	90000002	1000000000004	30	1	t	\N	\N	\N	\N	\N	t
1000000000013	2410	90000002	1000000000004	31	1	t	\N	\N	\N	\N	\N	t
1000000000014	2410	90000002	1000000000004	32	1	t	\N	\N	\N	\N	\N	t
1000000000015	12058	90000002	1000000000004	19	1	t	\N	\N	\N	\N	\N	t
1000000000016	3841	90000002	1000000000004	20	1	t	\N	\N	\N	\N	\N	t
1000000000017	3841	90000002	1000000000004	21	1	t	\N	\N	\N	\N	\N	t
1000000000018	2281	90000002	1000000000004	22	1	t	\N	\N	\N	\N	\N	t
1000000000019	2281	90000002	1000000000004	23	1	t	\N	\N	\N	\N	\N	t
1000000000020	2301	90000002	1000000000004	24	1	t	\N	\N	\N	\N	\N	t
1000000000021	22291	90000002	1000000000004	11	1	t	\N	\N	\N	\N	\N	t
1000000000022	22291	90000002	1000000000004	12	1	t	\N	\N	\N	\N	\N	t
1000000000023	22291	90000002	1000000000004	13	1	t	\N	\N	\N	\N	\N	t
1000000000024	2048	90000002	1000000000004	14	1	t	\N	\N	\N	\N	\N	t
1000000000025	31790	90000002	1000000000004	92	1	t	\N	\N	\N	\N	\N	t
1000000000026	31790	90000002	1000000000004	93	1	t	\N	\N	\N	\N	\N	t
1000000000027	31790	90000002	1000000000004	94	1	t	\N	\N	\N	\N	\N	t
1000000000005	209	90000002	1000000000004	5	2240	f	\N	\N	\N	\N	\N	f
1000000000008	206	90000002	1000000000004	5	760	f	\N	\N	\N	\N	\N	f
1000000000028	27042	90000002	30001397	0	1	t	\N	\N	24551682000.45043	930353562.9872682	-9769058736.461329	f
1000000000004	24698	90000002	30001397	0	1	t	\N	Taiyang's Drake	-72380374452.1221	-2749213093.8152003	-171936218650.01578	f
\.


--
-- Name: items_item_id_seq; Type: SEQUENCE SET; Schema: game; Owner: -
--

SELECT pg_catalog.setval('game.items_item_id_seq', 1000000000028, true);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (item_id);


--
-- Name: items_location_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX items_location_idx ON game.items USING btree (location_id, flag_id);


--
-- Name: items_owner_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX items_owner_idx ON game.items USING btree (owner_id);


--
-- PostgreSQL database dump complete
--

\unrestrict iT54BieuOaGYRoc3j6T7mTmGaQZsMQwmagDYH8pM6DH1Dfa7UXRdaTXvdOMRM0u

