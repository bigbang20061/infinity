--
-- PostgreSQL database dump
--

\restrict fqEytpifieM7ntVrkzlBfv8UpyMHqbMn9mfly1NCvQOOkYQuvwhzv0Qln5NSalQ

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: mail_status; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.mail_status (
    message_id bigint NOT NULL,
    char_id bigint NOT NULL,
    status_mask integer DEFAULT 0 NOT NULL,
    label_mask integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: mail_status; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.mail_status (message_id, char_id, status_mask, label_mask) FROM stdin;
\.


--
-- Name: mail_status mail_status_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.mail_status
    ADD CONSTRAINT mail_status_pkey PRIMARY KEY (char_id, message_id);


--
-- Name: mail_status mail_status_message_id_fkey; Type: FK CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.mail_status
    ADD CONSTRAINT mail_status_message_id_fkey FOREIGN KEY (message_id) REFERENCES game.mail_messages(message_id);


--
-- PostgreSQL database dump complete
--

\unrestrict fqEytpifieM7ntVrkzlBfv8UpyMHqbMn9mfly1NCvQOOkYQuvwhzv0Qln5NSalQ

