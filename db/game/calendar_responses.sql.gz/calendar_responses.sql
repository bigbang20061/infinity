--
-- PostgreSQL database dump
--

\restrict wSF5HkQWp68heKEoGSJoS10pCVp8lfF7qVmxPsqIvkeReC3psdDQv9Z0IpzWFdi

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: calendar_responses; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.calendar_responses (
    event_id bigint NOT NULL,
    char_id bigint NOT NULL,
    status integer NOT NULL
);


--
-- Data for Name: calendar_responses; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.calendar_responses (event_id, char_id, status) FROM stdin;
\.


--
-- Name: calendar_responses calendar_responses_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.calendar_responses
    ADD CONSTRAINT calendar_responses_pkey PRIMARY KEY (event_id, char_id);


--
-- Name: calendar_responses_char_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX calendar_responses_char_idx ON game.calendar_responses USING btree (char_id);


--
-- PostgreSQL database dump complete
--

\unrestrict wSF5HkQWp68heKEoGSJoS10pCVp8lfF7qVmxPsqIvkeReC3psdDQv9Z0IpzWFdi

