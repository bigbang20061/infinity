--
-- PostgreSQL database dump
--

\restrict k3gibde21EenSWDmMrvf5JpC4EQBHIfNEeybfUXviEBds2r9jrZ8MJ4pTz8wqyD

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: industry_jobs; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.industry_jobs (
    job_id bigint NOT NULL,
    installer_id bigint NOT NULL,
    owner_id bigint NOT NULL,
    activity_id integer NOT NULL,
    blueprint_id bigint NOT NULL,
    blueprint_type_id integer NOT NULL,
    blueprint_copy boolean NOT NULL,
    facility_id bigint NOT NULL,
    solar_system_id bigint NOT NULL,
    runs integer NOT NULL,
    licensed_runs integer DEFAULT 1 NOT NULL,
    successful_runs integer,
    product_type_id integer,
    optional_type_id integer,
    cost double precision NOT NULL,
    probability double precision DEFAULT 1 NOT NULL,
    time_seconds bigint NOT NULL,
    start_date bigint NOT NULL,
    end_date bigint NOT NULL,
    completed_date bigint,
    completed_by bigint,
    status integer NOT NULL
);


--
-- Name: industry_jobs_job_id_seq; Type: SEQUENCE; Schema: game; Owner: -
--

CREATE SEQUENCE game.industry_jobs_job_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: industry_jobs_job_id_seq; Type: SEQUENCE OWNED BY; Schema: game; Owner: -
--

ALTER SEQUENCE game.industry_jobs_job_id_seq OWNED BY game.industry_jobs.job_id;


--
-- Name: industry_jobs job_id; Type: DEFAULT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.industry_jobs ALTER COLUMN job_id SET DEFAULT nextval('game.industry_jobs_job_id_seq'::regclass);


--
-- Data for Name: industry_jobs; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.industry_jobs (job_id, installer_id, owner_id, activity_id, blueprint_id, blueprint_type_id, blueprint_copy, facility_id, solar_system_id, runs, licensed_runs, successful_runs, product_type_id, optional_type_id, cost, probability, time_seconds, start_date, end_date, completed_date, completed_by, status) FROM stdin;
\.


--
-- Name: industry_jobs_job_id_seq; Type: SEQUENCE SET; Schema: game; Owner: -
--

SELECT pg_catalog.setval('game.industry_jobs_job_id_seq', 1, false);


--
-- Name: industry_jobs industry_jobs_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.industry_jobs
    ADD CONSTRAINT industry_jobs_pkey PRIMARY KEY (job_id);


--
-- Name: industry_jobs_blueprint_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX industry_jobs_blueprint_idx ON game.industry_jobs USING btree (blueprint_id) WHERE (status = 1);


--
-- Name: industry_jobs_owner_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX industry_jobs_owner_idx ON game.industry_jobs USING btree (owner_id, status);


--
-- PostgreSQL database dump complete
--

\unrestrict k3gibde21EenSWDmMrvf5JpC4EQBHIfNEeybfUXviEBds2r9jrZ8MJ4pTz8wqyD

