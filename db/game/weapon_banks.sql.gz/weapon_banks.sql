--
-- PostgreSQL database dump
--

\restrict zsdA3Hc7TB0Gm6xUgX0hWKX4QfcfjmGVNQ8FO91elWjwJdZwZHC1oOVYJbq3cd3

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: weapon_banks; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.weapon_banks (
    ship_id bigint NOT NULL,
    master_id bigint NOT NULL,
    slave_id bigint NOT NULL
);


--
-- Data for Name: weapon_banks; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.weapon_banks (ship_id, master_id, slave_id) FROM stdin;
\.


--
-- Name: weapon_banks weapon_banks_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.weapon_banks
    ADD CONSTRAINT weapon_banks_pkey PRIMARY KEY (slave_id);


--
-- PostgreSQL database dump complete
--

\unrestrict zsdA3Hc7TB0Gm6xUgX0hWKX4QfcfjmGVNQ8FO91elWjwJdZwZHC1oOVYJbq3cd3

