--
-- PostgreSQL database dump
--

\restrict xwkfTUcl0hCMpi1ETggg3NuTPhWKuKc5LUgypnvfb8tQregXhGAB5qDMuBVFzh8

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: corp_enlistment_factions; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.corp_enlistment_factions (
    corporation_id bigint NOT NULL,
    faction_id bigint NOT NULL
);


--
-- Data for Name: corp_enlistment_factions; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.corp_enlistment_factions (corporation_id, faction_id) FROM stdin;
\.


--
-- Name: corp_enlistment_factions corp_enlistment_factions_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.corp_enlistment_factions
    ADD CONSTRAINT corp_enlistment_factions_pkey PRIMARY KEY (corporation_id, faction_id);


--
-- PostgreSQL database dump complete
--

\unrestrict xwkfTUcl0hCMpi1ETggg3NuTPhWKuKc5LUgypnvfb8tQregXhGAB5qDMuBVFzh8

