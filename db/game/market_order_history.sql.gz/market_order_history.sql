--
-- PostgreSQL database dump
--

\restrict 6Gp7DVFgDjbZ3tusWnb5uxa0GT1DaHIt5bdHe9wX3X0NNfeWqLkmJIN7jxYV3BH

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: market_order_history; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.market_order_history (
    order_id bigint NOT NULL,
    type_id integer NOT NULL,
    char_id bigint NOT NULL,
    station_id bigint NOT NULL,
    region_id bigint NOT NULL,
    price double precision NOT NULL,
    vol_entered integer NOT NULL,
    vol_remaining integer NOT NULL,
    min_volume integer NOT NULL,
    bid boolean NOT NULL,
    range integer NOT NULL,
    duration integer NOT NULL,
    issued bigint NOT NULL,
    state integer NOT NULL,
    closed bigint NOT NULL
);


--
-- Data for Name: market_order_history; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.market_order_history (order_id, type_id, char_id, station_id, region_id, price, vol_entered, vol_remaining, min_volume, bid, range, duration, issued, state, closed) FROM stdin;
\.


--
-- Name: market_order_history market_order_history_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.market_order_history
    ADD CONSTRAINT market_order_history_pkey PRIMARY KEY (order_id);


--
-- Name: market_order_history_char_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX market_order_history_char_idx ON game.market_order_history USING btree (char_id, closed);


--
-- PostgreSQL database dump complete
--

\unrestrict 6Gp7DVFgDjbZ3tusWnb5uxa0GT1DaHIt5bdHe9wX3X0NNfeWqLkmJIN7jxYV3BH

