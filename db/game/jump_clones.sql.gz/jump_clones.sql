--
-- PostgreSQL database dump
--

\restrict CecpT6QaIENs67SN4perSzXjTmiiHLRvjYqq7kD5mvaiSprhgflvieF88Lequib

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: jump_clones; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.jump_clones (
    clone_id bigint NOT NULL,
    owner_id bigint NOT NULL,
    location_id bigint NOT NULL,
    name text DEFAULT ''::text NOT NULL
);


--
-- Name: jump_clones_clone_id_seq; Type: SEQUENCE; Schema: game; Owner: -
--

CREATE SEQUENCE game.jump_clones_clone_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: jump_clones_clone_id_seq; Type: SEQUENCE OWNED BY; Schema: game; Owner: -
--

ALTER SEQUENCE game.jump_clones_clone_id_seq OWNED BY game.jump_clones.clone_id;


--
-- Name: jump_clones clone_id; Type: DEFAULT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.jump_clones ALTER COLUMN clone_id SET DEFAULT nextval('game.jump_clones_clone_id_seq'::regclass);


--
-- Data for Name: jump_clones; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.jump_clones (clone_id, owner_id, location_id, name) FROM stdin;
\.


--
-- Name: jump_clones_clone_id_seq; Type: SEQUENCE SET; Schema: game; Owner: -
--

SELECT pg_catalog.setval('game.jump_clones_clone_id_seq', 1, false);


--
-- Name: jump_clones jump_clones_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.jump_clones
    ADD CONSTRAINT jump_clones_pkey PRIMARY KEY (clone_id);


--
-- Name: jump_clones_owner_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX jump_clones_owner_idx ON game.jump_clones USING btree (owner_id);


--
-- PostgreSQL database dump complete
--

\unrestrict CecpT6QaIENs67SN4perSzXjTmiiHLRvjYqq7kD5mvaiSprhgflvieF88Lequib

