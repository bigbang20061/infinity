--
-- PostgreSQL database dump
--

\restrict edfLAw3h9iJy2ovUY8ITtju480uXJypzxR1Ku8cvWgAQxutYiy2cFKgHRhbDF3b

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: exploration_systems; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.exploration_systems (
    system_id bigint NOT NULL,
    generated_at bigint NOT NULL
);


--
-- Data for Name: exploration_systems; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.exploration_systems (system_id, generated_at) FROM stdin;
30001397	134375701615614136
31000898	134375705478759428
\.


--
-- Name: exploration_systems exploration_systems_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.exploration_systems
    ADD CONSTRAINT exploration_systems_pkey PRIMARY KEY (system_id);


--
-- PostgreSQL database dump complete
--

\unrestrict edfLAw3h9iJy2ovUY8ITtju480uXJypzxR1Ku8cvWgAQxutYiy2cFKgHRhbDF3b

