--
-- PostgreSQL database dump
--

\restrict j8nyh5cvOoBL3ImSkewxOAYw8qFItnFS7ePWMraU93KgPljekwXep1a9xLbStq7

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: calendar_events; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.calendar_events (
    event_id bigint NOT NULL,
    owner_id bigint NOT NULL,
    creator_id bigint NOT NULL,
    event_date bigint NOT NULL,
    duration integer DEFAULT 0 NOT NULL,
    title text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    importance integer DEFAULT 0 NOT NULL,
    modified bigint NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- Name: calendar_events_event_id_seq; Type: SEQUENCE; Schema: game; Owner: -
--

CREATE SEQUENCE game.calendar_events_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: calendar_events_event_id_seq; Type: SEQUENCE OWNED BY; Schema: game; Owner: -
--

ALTER SEQUENCE game.calendar_events_event_id_seq OWNED BY game.calendar_events.event_id;


--
-- Name: calendar_events event_id; Type: DEFAULT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.calendar_events ALTER COLUMN event_id SET DEFAULT nextval('game.calendar_events_event_id_seq'::regclass);


--
-- Data for Name: calendar_events; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.calendar_events (event_id, owner_id, creator_id, event_date, duration, title, description, importance, modified, deleted) FROM stdin;
\.


--
-- Name: calendar_events_event_id_seq; Type: SEQUENCE SET; Schema: game; Owner: -
--

SELECT pg_catalog.setval('game.calendar_events_event_id_seq', 1, false);


--
-- Name: calendar_events calendar_events_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.calendar_events
    ADD CONSTRAINT calendar_events_pkey PRIMARY KEY (event_id);


--
-- Name: calendar_events_owner_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX calendar_events_owner_idx ON game.calendar_events USING btree (owner_id, event_date);


--
-- PostgreSQL database dump complete
--

\unrestrict j8nyh5cvOoBL3ImSkewxOAYw8qFItnFS7ePWMraU93KgPljekwXep1a9xLbStq7

