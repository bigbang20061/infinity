--
-- PostgreSQL database dump
--

\restrict HZ0IXiWTkV5CEBnhV4z5plIwEgTfolRUsOdd60WgdZ5j4Hl5Z4efdHor6cSSK1t

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: corporations; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.corporations (
    corporation_id bigint NOT NULL,
    name text NOT NULL,
    ticker text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    url text DEFAULT ''::text NOT NULL,
    tax_rate double precision DEFAULT 0 NOT NULL,
    lp_tax_rate double precision DEFAULT 0 NOT NULL,
    ceo_id bigint,
    creator_id bigint NOT NULL,
    station_id bigint NOT NULL,
    is_recruiting boolean DEFAULT true NOT NULL,
    friendly_fire boolean DEFAULT false NOT NULL,
    shape1 integer,
    shape2 integer,
    shape3 integer,
    color1 integer,
    color2 integer,
    color3 integer,
    typeface integer,
    welcome_mail text DEFAULT ''::text NOT NULL,
    created bigint NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


--
-- Name: corporations_corporation_id_seq; Type: SEQUENCE; Schema: game; Owner: -
--

CREATE SEQUENCE game.corporations_corporation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: corporations_corporation_id_seq; Type: SEQUENCE OWNED BY; Schema: game; Owner: -
--

ALTER SEQUENCE game.corporations_corporation_id_seq OWNED BY game.corporations.corporation_id;


--
-- Name: corporations corporation_id; Type: DEFAULT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.corporations ALTER COLUMN corporation_id SET DEFAULT nextval('game.corporations_corporation_id_seq'::regclass);


--
-- Data for Name: corporations; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.corporations (corporation_id, name, ticker, description, url, tax_rate, lp_tax_rate, ceo_id, creator_id, station_id, is_recruiting, friendly_fire, shape1, shape2, shape3, color1, color2, color3, typeface, welcome_mail, created, deleted) FROM stdin;
\.


--
-- Name: corporations_corporation_id_seq; Type: SEQUENCE SET; Schema: game; Owner: -
--

SELECT pg_catalog.setval('game.corporations_corporation_id_seq', 98000000, true);


--
-- Name: corporations corporations_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.corporations
    ADD CONSTRAINT corporations_pkey PRIMARY KEY (corporation_id);


--
-- Name: corporations_name_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE UNIQUE INDEX corporations_name_idx ON game.corporations USING btree (lower(name)) WHERE (NOT deleted);


--
-- Name: corporations_ticker_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE UNIQUE INDEX corporations_ticker_idx ON game.corporations USING btree (upper(ticker)) WHERE (NOT deleted);


--
-- PostgreSQL database dump complete
--

\unrestrict HZ0IXiWTkV5CEBnhV4z5plIwEgTfolRUsOdd60WgdZ5j4Hl5Z4efdHor6cSSK1t

