--
-- PostgreSQL database dump
--

\restrict q9w3zc1uxL1i5YBy79e3UTcqZWkGNQvy48GhDB5TSbVMjqleeXDcBfsya9OaAsM

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: epic_arc_missions; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.epic_arc_missions (
    character_id bigint NOT NULL,
    arc_id bigint NOT NULL,
    mission_id integer NOT NULL,
    state text NOT NULL,
    accepted_at bigint,
    completed_at bigint,
    quit_at bigint
);


--
-- Data for Name: epic_arc_missions; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.epic_arc_missions (character_id, arc_id, mission_id, state, accepted_at, completed_at, quit_at) FROM stdin;
\.


--
-- Name: epic_arc_missions epic_arc_missions_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.epic_arc_missions
    ADD CONSTRAINT epic_arc_missions_pkey PRIMARY KEY (character_id, arc_id, mission_id);


--
-- PostgreSQL database dump complete
--

\unrestrict q9w3zc1uxL1i5YBy79e3UTcqZWkGNQvy48GhDB5TSbVMjqleeXDcBfsya9OaAsM

