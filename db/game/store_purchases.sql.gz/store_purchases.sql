--
-- PostgreSQL database dump
--

\restrict sP26bX2L9CnM9aaDvjXfrt3sBKNIbZzcblTFXZivdr8e1FKBqci6Dt3CRm0kyNC

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: store_purchases; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.store_purchases (
    user_id bigint NOT NULL,
    offer_id integer NOT NULL,
    quantity integer NOT NULL,
    price bigint NOT NULL,
    purchased_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Data for Name: store_purchases; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.store_purchases (user_id, offer_id, quantity, price, purchased_at) FROM stdin;
\.


--
-- Name: store_purchases_user_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX store_purchases_user_idx ON game.store_purchases USING btree (user_id, offer_id);


--
-- Name: store_purchases store_purchases_user_id_fkey; Type: FK CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.store_purchases
    ADD CONSTRAINT store_purchases_user_id_fkey FOREIGN KEY (user_id) REFERENCES game.accounts(user_id);


--
-- PostgreSQL database dump complete
--

\unrestrict sP26bX2L9CnM9aaDvjXfrt3sBKNIbZzcblTFXZivdr8e1FKBqci6Dt3CRm0kyNC

