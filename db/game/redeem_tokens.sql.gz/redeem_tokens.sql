--
-- PostgreSQL database dump
--

\restrict ijNkOW4BahGMQMvaLgAc5TVgg8oSn1W6wPKRJ9gfz08qjndXVEy8yPiiepQOvX2

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: redeem_tokens; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.redeem_tokens (
    token_id bigint NOT NULL,
    user_id bigint NOT NULL,
    type_id integer NOT NULL,
    quantity integer NOT NULL,
    label text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    created bigint NOT NULL
);


--
-- Name: redeem_tokens_token_id_seq; Type: SEQUENCE; Schema: game; Owner: -
--

CREATE SEQUENCE game.redeem_tokens_token_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: redeem_tokens_token_id_seq; Type: SEQUENCE OWNED BY; Schema: game; Owner: -
--

ALTER SEQUENCE game.redeem_tokens_token_id_seq OWNED BY game.redeem_tokens.token_id;


--
-- Name: redeem_tokens token_id; Type: DEFAULT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.redeem_tokens ALTER COLUMN token_id SET DEFAULT nextval('game.redeem_tokens_token_id_seq'::regclass);


--
-- Data for Name: redeem_tokens; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.redeem_tokens (token_id, user_id, type_id, quantity, label, description, created) FROM stdin;
1	10000001	57003	1	UI/LoginRewards/WindowCaption		134375544351548117
2	10000001	94055	1	UI/LoginRewards/WindowCaption		134375544351561104
\.


--
-- Name: redeem_tokens_token_id_seq; Type: SEQUENCE SET; Schema: game; Owner: -
--

SELECT pg_catalog.setval('game.redeem_tokens_token_id_seq', 2, true);


--
-- Name: redeem_tokens redeem_tokens_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.redeem_tokens
    ADD CONSTRAINT redeem_tokens_pkey PRIMARY KEY (token_id);


--
-- Name: redeem_tokens_user_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX redeem_tokens_user_idx ON game.redeem_tokens USING btree (user_id);


--
-- Name: redeem_tokens redeem_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.redeem_tokens
    ADD CONSTRAINT redeem_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES game.accounts(user_id);


--
-- PostgreSQL database dump complete
--

\unrestrict ijNkOW4BahGMQMvaLgAc5TVgg8oSn1W6wPKRJ9gfz08qjndXVEy8yPiiepQOvX2

