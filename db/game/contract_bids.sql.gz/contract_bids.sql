--
-- PostgreSQL database dump
--

\restrict K8ovphzjXo9WNMNXoM3ulOTn28KeBfkqbFTgwO1cRJyxUIVgKKDoAZs7nYGtpC2

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: contract_bids; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.contract_bids (
    bid_id bigint NOT NULL,
    contract_id bigint NOT NULL,
    bidder_id bigint NOT NULL,
    amount double precision NOT NULL,
    date bigint NOT NULL
);


--
-- Name: contract_bids_bid_id_seq; Type: SEQUENCE; Schema: game; Owner: -
--

CREATE SEQUENCE game.contract_bids_bid_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contract_bids_bid_id_seq; Type: SEQUENCE OWNED BY; Schema: game; Owner: -
--

ALTER SEQUENCE game.contract_bids_bid_id_seq OWNED BY game.contract_bids.bid_id;


--
-- Name: contract_bids bid_id; Type: DEFAULT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.contract_bids ALTER COLUMN bid_id SET DEFAULT nextval('game.contract_bids_bid_id_seq'::regclass);


--
-- Data for Name: contract_bids; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.contract_bids (bid_id, contract_id, bidder_id, amount, date) FROM stdin;
\.


--
-- Name: contract_bids_bid_id_seq; Type: SEQUENCE SET; Schema: game; Owner: -
--

SELECT pg_catalog.setval('game.contract_bids_bid_id_seq', 1, false);


--
-- Name: contract_bids contract_bids_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.contract_bids
    ADD CONSTRAINT contract_bids_pkey PRIMARY KEY (bid_id);


--
-- Name: contract_bids_contract_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX contract_bids_contract_idx ON game.contract_bids USING btree (contract_id, amount DESC);


--
-- Name: contract_bids contract_bids_contract_id_fkey; Type: FK CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.contract_bids
    ADD CONSTRAINT contract_bids_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES game.contracts(contract_id);


--
-- PostgreSQL database dump complete
--

\unrestrict K8ovphzjXo9WNMNXoM3ulOTn28KeBfkqbFTgwO1cRJyxUIVgKKDoAZs7nYGtpC2

