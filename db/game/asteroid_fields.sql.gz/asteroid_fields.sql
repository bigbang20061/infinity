--
-- PostgreSQL database dump
--

\restrict TzeZWcUC8UcVTdDJm4UH8dVhmmq2bVZ25jxcfmlcmqlZ14p9vPdj8cvZfMhd3Zn

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: asteroid_fields; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.asteroid_fields (
    field_id bigint NOT NULL,
    system_id bigint NOT NULL,
    grown_at bigint NOT NULL,
    depleted_at bigint
);


--
-- Data for Name: asteroid_fields; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.asteroid_fields (field_id, system_id, grown_at, depleted_at) FROM stdin;
\.


--
-- Name: asteroid_fields asteroid_fields_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.asteroid_fields
    ADD CONSTRAINT asteroid_fields_pkey PRIMARY KEY (field_id);


--
-- PostgreSQL database dump complete
--

\unrestrict TzeZWcUC8UcVTdDJm4UH8dVhmmq2bVZ25jxcfmlcmqlZ14p9vPdj8cvZfMhd3Zn

