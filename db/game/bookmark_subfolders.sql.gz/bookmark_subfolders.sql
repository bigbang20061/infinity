--
-- PostgreSQL database dump
--

\restrict SCpHmLwblT5sTArAykYV21be6mIYbvvhzTf0IuhSGUXUKTVLw1AvsIXmqss8IKj

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bookmark_subfolders; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.bookmark_subfolders (
    subfolder_id bigint NOT NULL,
    folder_id bigint NOT NULL,
    name text NOT NULL
);


--
-- Name: bookmark_subfolders_subfolder_id_seq; Type: SEQUENCE; Schema: game; Owner: -
--

CREATE SEQUENCE game.bookmark_subfolders_subfolder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bookmark_subfolders_subfolder_id_seq; Type: SEQUENCE OWNED BY; Schema: game; Owner: -
--

ALTER SEQUENCE game.bookmark_subfolders_subfolder_id_seq OWNED BY game.bookmark_subfolders.subfolder_id;


--
-- Name: bookmark_subfolders subfolder_id; Type: DEFAULT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.bookmark_subfolders ALTER COLUMN subfolder_id SET DEFAULT nextval('game.bookmark_subfolders_subfolder_id_seq'::regclass);


--
-- Data for Name: bookmark_subfolders; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.bookmark_subfolders (subfolder_id, folder_id, name) FROM stdin;
\.


--
-- Name: bookmark_subfolders_subfolder_id_seq; Type: SEQUENCE SET; Schema: game; Owner: -
--

SELECT pg_catalog.setval('game.bookmark_subfolders_subfolder_id_seq', 1, false);


--
-- Name: bookmark_subfolders bookmark_subfolders_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.bookmark_subfolders
    ADD CONSTRAINT bookmark_subfolders_pkey PRIMARY KEY (subfolder_id);


--
-- PostgreSQL database dump complete
--

\unrestrict SCpHmLwblT5sTArAykYV21be6mIYbvvhzTf0IuhSGUXUKTVLw1AvsIXmqss8IKj

