--
-- PostgreSQL database dump
--

\restrict UB7MeLJgNzRrPjWZ38vTSTXWXoYT629zoyOlNOVGe1SWdCUlc8GSdOaIpV0fqAB

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: asteroid_seq; Type: SEQUENCE; Schema: game; Owner: -
--

CREATE SEQUENCE game.asteroid_seq
    START WITH 9700000000000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: asteroid_seq; Type: SEQUENCE SET; Schema: game; Owner: -
--

SELECT pg_catalog.setval('game.asteroid_seq', 9700000000000, false);


--
-- PostgreSQL database dump complete
--

\unrestrict UB7MeLJgNzRrPjWZ38vTSTXWXoYT629zoyOlNOVGe1SWdCUlc8GSdOaIpV0fqAB

