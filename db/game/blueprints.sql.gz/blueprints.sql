--
-- PostgreSQL database dump
--

\restrict vMseUQtvSAOksXQdOdfhXNk8rv9NioGg3A2QDMEoxI3QaVMUBrZhJAcfaltolUn

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: blueprints; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.blueprints (
    item_id bigint NOT NULL,
    material_efficiency integer DEFAULT 0 NOT NULL,
    time_efficiency integer DEFAULT 0 NOT NULL,
    runs integer DEFAULT '-1'::integer NOT NULL
);


--
-- Data for Name: blueprints; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.blueprints (item_id, material_efficiency, time_efficiency, runs) FROM stdin;
\.


--
-- Name: blueprints blueprints_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.blueprints
    ADD CONSTRAINT blueprints_pkey PRIMARY KEY (item_id);


--
-- PostgreSQL database dump complete
--

\unrestrict vMseUQtvSAOksXQdOdfhXNk8rv9NioGg3A2QDMEoxI3QaVMUBrZhJAcfaltolUn

