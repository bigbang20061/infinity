--
-- PostgreSQL database dump
--

\restrict iRctMV3t3cMXITfsNdPd9V7NfHvczlELLNFNmaWG6Rg8WERgjV8lrS4PhhwaO0K

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: exploration_scanned; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.exploration_scanned (
    character_id bigint NOT NULL,
    site_id bigint NOT NULL
);


--
-- Data for Name: exploration_scanned; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.exploration_scanned (character_id, site_id) FROM stdin;
90000002	9500000000005
\.


--
-- Name: exploration_scanned exploration_scanned_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.exploration_scanned
    ADD CONSTRAINT exploration_scanned_pkey PRIMARY KEY (character_id, site_id);


--
-- PostgreSQL database dump complete
--

\unrestrict iRctMV3t3cMXITfsNdPd9V7NfHvczlELLNFNmaWG6Rg8WERgjV8lrS4PhhwaO0K

