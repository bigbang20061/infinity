--
-- PostgreSQL database dump
--

\restrict HogWtbI9AhYSRceVENkHYUqGhWdlYEYVLzHgO8HDbnirGaidSbgvtdw9kxb0Eu5

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bookmarks; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.bookmarks (
    bookmark_id bigint NOT NULL,
    folder_id bigint NOT NULL,
    subfolder_id bigint,
    creator_id bigint NOT NULL,
    item_id bigint,
    type_id integer,
    location_id bigint NOT NULL,
    x double precision NOT NULL,
    y double precision NOT NULL,
    z double precision NOT NULL,
    memo text NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    created bigint NOT NULL,
    expiry bigint
);


--
-- Name: bookmarks_bookmark_id_seq; Type: SEQUENCE; Schema: game; Owner: -
--

CREATE SEQUENCE game.bookmarks_bookmark_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bookmarks_bookmark_id_seq; Type: SEQUENCE OWNED BY; Schema: game; Owner: -
--

ALTER SEQUENCE game.bookmarks_bookmark_id_seq OWNED BY game.bookmarks.bookmark_id;


--
-- Name: bookmarks bookmark_id; Type: DEFAULT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.bookmarks ALTER COLUMN bookmark_id SET DEFAULT nextval('game.bookmarks_bookmark_id_seq'::regclass);


--
-- Data for Name: bookmarks; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.bookmarks (bookmark_id, folder_id, subfolder_id, creator_id, item_id, type_id, location_id, x, y, z, memo, note, created, expiry) FROM stdin;
\.


--
-- Name: bookmarks_bookmark_id_seq; Type: SEQUENCE SET; Schema: game; Owner: -
--

SELECT pg_catalog.setval('game.bookmarks_bookmark_id_seq', 1, false);


--
-- Name: bookmarks bookmarks_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.bookmarks
    ADD CONSTRAINT bookmarks_pkey PRIMARY KEY (bookmark_id);


--
-- Name: bookmarks_folder_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX bookmarks_folder_idx ON game.bookmarks USING btree (folder_id);


--
-- PostgreSQL database dump complete
--

\unrestrict HogWtbI9AhYSRceVENkHYUqGhWdlYEYVLzHgO8HDbnirGaidSbgvtdw9kxb0Eu5

