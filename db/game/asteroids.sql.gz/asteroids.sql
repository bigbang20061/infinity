--
-- PostgreSQL database dump
--

\restrict xX4JfaNAQordCoFZK34tNNh4N5XD1G7sTKXmCmIDbfGSJcSdJbRodvmZjB2YgnL

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: asteroids; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.asteroids (
    asteroid_id bigint DEFAULT nextval('game.asteroid_seq'::regclass) NOT NULL,
    system_id bigint NOT NULL,
    field_id bigint NOT NULL,
    type_id integer NOT NULL,
    quantity bigint NOT NULL,
    original_quantity bigint NOT NULL,
    radius real,
    x double precision NOT NULL,
    y double precision NOT NULL,
    z double precision NOT NULL
);


--
-- Data for Name: asteroids; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.asteroids (asteroid_id, system_id, field_id, type_id, quantity, original_quantity, radius, x, y, z) FROM stdin;
\.


--
-- Name: asteroids asteroids_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.asteroids
    ADD CONSTRAINT asteroids_pkey PRIMARY KEY (asteroid_id);


--
-- Name: asteroids_system; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX asteroids_system ON game.asteroids USING btree (system_id);


--
-- PostgreSQL database dump complete
--

\unrestrict xX4JfaNAQordCoFZK34tNNh4N5XD1G7sTKXmCmIDbfGSJcSdJbRodvmZjB2YgnL

