--
-- PostgreSQL database dump
--

\restrict gMkcWqpjArxGZz6PGFS4WC56XxoimSOnTVLMrvfIu30P5kv2kEgOvIkvprLW2S2

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: exploration_sites; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.exploration_sites (
    site_id bigint NOT NULL,
    system_id bigint NOT NULL,
    target text NOT NULL,
    kind smallint NOT NULL,
    strength_attr bigint NOT NULL,
    ease double precision NOT NULL,
    dungeon_id bigint,
    name_id bigint,
    archetype bigint,
    faction bigint,
    difficulty bigint NOT NULL,
    x double precision NOT NULL,
    y double precision NOT NULL,
    z double precision NOT NULL,
    overlay_x double precision NOT NULL,
    overlay_y double precision NOT NULL,
    overlay_z double precision NOT NULL,
    deviation double precision NOT NULL,
    in_space boolean DEFAULT false NOT NULL,
    containers bigint[],
    hacked bigint[] DEFAULT '{}'::bigint[] NOT NULL,
    wh_type integer,
    wh_dest_system bigint,
    wh_dest_class bigint,
    wh_other bigint,
    wh_born bigint,
    wh_life_minutes double precision,
    wh_mass_max double precision,
    wh_mass_used double precision,
    wh_jump_mass double precision,
    wh_nebula bigint
);


--
-- Data for Name: exploration_sites; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.exploration_sites (site_id, system_id, target, kind, strength_attr, ease, dungeon_id, name_id, archetype, faction, difficulty, x, y, z, overlay_x, overlay_y, overlay_z, deviation, in_space, containers, hacked, wh_type, wh_dest_system, wh_dest_class, wh_other, wh_born, wh_life_minutes, wh_mass_max, wh_mass_used, wh_jump_mass, wh_nebula) FROM stdin;
9500000000000	30001397	BDF-215	0	1136	1	3416	111315	24	500010	1	24554677928.760563	930167956.0932989	-9771603207.882547	24554677928.760563	930167956.0932989	-9771603207.882547	0	f	\N	{}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9500000000001	30001397	DAC-043	0	1136	0.8	2312	110985	24	500010	2	-936557721771.471	-35548878553.304276	-375380992950.10144	-936557721771.471	-35548878553.304276	-375380992950.10144	0	f	\N	{}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9500000000002	30001397	DFA-216	1	1136	0.8	1236	111727	24	500010	2	24550403896.486496	930492124.2297521	-9767054980.843649	91904857116.88379	-84933814479.60887	78580547212.17596	718069779360	f	\N	{}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9500000000003	30001397	ECG-172	1	208	0.8	1626	111900	45	500010	1	24546639240.638725	930089166.0689945	-9769999007.449165	31549749224.5462	-14803978767.887619	-7528342452.481042	718069779360	f	\N	{}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9500000000004	30001397	BED-090	1	210	0.8	14004	1036401	44	500010	1	-41838536814.803246	-1589402695.6972702	-357243570866.4516	27804219586.203896	-110849563028.1548	-332737604953.5226	718069779360	f	\N	{}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9500000000007	31000898	ABB-185	0	1136	0.5	3808	112053	24	500021	4	-142166299301.01074	-884216749.416152	-265366944958.79858	-142166299301.01074	-884216749.416152	-265366944958.79858	0	f	\N	{}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9500000000008	31000898	ADC-076	0	1136	0.5	3718	113155	24	500021	4	-1586629986369.217	-21388663632.476574	2860308444995.554	-1586629986369.217	-21388663632.476574	2860308444995.554	0	f	\N	{}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9500000000009	31000898	EED-031	0	1136	0.6	3707	111670	24	500021	3	-1586621500655.1963	-21388755740.583763	2860308030301.479	-1586621500655.1963	-21388755740.583763	2860308030301.479	0	f	\N	{}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9500000000010	31000898	CCC-027	1	208	0.5	3746	111673	45	500021	3	-1586622869610.04	-21389307461.33603	2860306901079.7637	-1569395161488.2322	-76149190322.10522	2902303793985.044	897587224200	f	\N	{}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9500000000011	31000898	EDG-049	1	210	0.5	3728	113157	44	500021	3	56755678141.858635	18820121613.17187	-56864309920.2605	88077825345.12201	-26938666026.03432	-40222078817.45214	897587224200	f	\N	{}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9500000000012	31000898	DAF-044	1	1908	0.8	\N	\N	\N	\N	1	56752927496.630875	18821085842.318684	-56860786404.51375	76651864784.492	-49091706293.98976	-19517358604.94748	718069779360	f	\N	{}	30579	31000029	1	9500000000013	134375705478672433	960	100000000	0	62000000	11781
9500000000013	31000029	GEB-185	1	1908	0.8	\N	\N	\N	\N	1	326894117669.69025	4987830718.290092	-41546116622.696945	336009995727.2892	-6972106841.3033085	-38537488651.28689	718069779360	f	\N	{}	30831	31000898	3	9500000000012	134375705478672433	960	100000000	0	62000000	11783
9500000000006	31000898	BDC-092	1	1908	0.8	\N	\N	\N	\N	1	-142164652495.42926	-883938423.2730585	-265362852394.63272	-136783397771.52562	-6121134326.610053	-263310421167.3417	718069779360	t	\N	{}	30831	30001397	7	9500000000005	134375701615527697	960	1000000000	27000000	62000000	11807
9500000000005	30001397	CAD-141	1	1908	0.8	\N	\N	\N	\N	1	-72380376630.82323	-2749209495.5191684	-171936219243.11392	-60966151589.04287	-135881524906.40971	-150726942930.18567	718069779360	t	\N	{}	30662	31000898	3	9500000000006	134375701615527697	960	1000000000	27000000	62000000	11783
\.


--
-- Name: exploration_sites exploration_sites_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.exploration_sites
    ADD CONSTRAINT exploration_sites_pkey PRIMARY KEY (site_id);


--
-- Name: exploration_sites_system; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX exploration_sites_system ON game.exploration_sites USING btree (system_id);


--
-- PostgreSQL database dump complete
--

\unrestrict gMkcWqpjArxGZz6PGFS4WC56XxoimSOnTVLMrvfIu30P5kv2kEgOvIkvprLW2S2

