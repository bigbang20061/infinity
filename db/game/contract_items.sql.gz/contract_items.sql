--
-- PostgreSQL database dump
--

\restrict DPtapQQCzT9lQv2KX6Bfeg7PpWAtqVdPN6rkir548XFdfbYzpcFo7wDz6WawUcy

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: contract_items; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.contract_items (
    contract_id bigint NOT NULL,
    item_id bigint,
    type_id integer NOT NULL,
    quantity integer NOT NULL,
    in_crate boolean NOT NULL
);


--
-- Data for Name: contract_items; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.contract_items (contract_id, item_id, type_id, quantity, in_crate) FROM stdin;
\.


--
-- Name: contract_items_contract_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX contract_items_contract_idx ON game.contract_items USING btree (contract_id);


--
-- Name: contract_items contract_items_contract_id_fkey; Type: FK CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.contract_items
    ADD CONSTRAINT contract_items_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES game.contracts(contract_id);


--
-- PostgreSQL database dump complete
--

\unrestrict DPtapQQCzT9lQv2KX6Bfeg7PpWAtqVdPN6rkir548XFdfbYzpcFo7wDz6WawUcy

