--
-- PostgreSQL database dump
--

\restrict GvhHxi0v4paSugdD8UVhH7kDRzTqjLRKziXc3TmaaKfnI9kXnOiOc7T8T9FHn3X

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_missions; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.agent_missions (
    character_id bigint NOT NULL,
    agent_id bigint NOT NULL,
    mission_id integer NOT NULL,
    dungeon_id integer NOT NULL,
    faction_id bigint NOT NULL,
    state integer NOT NULL,
    system_id bigint NOT NULL,
    x double precision NOT NULL,
    y double precision NOT NULL,
    z double precision NOT NULL,
    reward_isk bigint NOT NULL,
    reward_lp bigint NOT NULL,
    offered_at bigint NOT NULL,
    accepted_at bigint,
    kind text DEFAULT 'kill'::text NOT NULL,
    arc_id bigint,
    dest_agent bigint,
    cargo_type integer,
    cargo_qty integer
);


--
-- Data for Name: agent_missions; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.agent_missions (character_id, agent_id, mission_id, dungeon_id, faction_id, state, system_id, x, y, z, reward_isk, reward_lp, offered_at, accepted_at, kind, arc_id, dest_agent, cargo_type, cargo_qty) FROM stdin;
90000002	3013323	13660	2960	500002	2	30001397	24551675102.371075	930355362.2786707	-9769063066.640104	1000000	1300	134375622483307613	134375622530969318	kill	\N	\N	\N	\N
\.


--
-- Name: agent_missions agent_missions_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.agent_missions
    ADD CONSTRAINT agent_missions_pkey PRIMARY KEY (character_id, agent_id);


--
-- Name: agent_missions agent_missions_character_id_fkey; Type: FK CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.agent_missions
    ADD CONSTRAINT agent_missions_character_id_fkey FOREIGN KEY (character_id) REFERENCES game.characters(character_id);


--
-- PostgreSQL database dump complete
--

\unrestrict GvhHxi0v4paSugdD8UVhH7kDRzTqjLRKziXc3TmaaKfnI9kXnOiOc7T8T9FHn3X

