--
-- PostgreSQL database dump
--

\restrict ZfgVybCH5VS6VpkWTYPXu7Gw8LPb2JbYCPna8X0saLI03Fnz6i145PcaB5WoItX

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: market_transactions; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.market_transactions (
    transaction_id bigint NOT NULL,
    type_id integer NOT NULL,
    quantity integer NOT NULL,
    price double precision NOT NULL,
    buyer_id bigint NOT NULL,
    seller_id bigint NOT NULL,
    station_id bigint NOT NULL,
    region_id bigint NOT NULL,
    date bigint NOT NULL
);


--
-- Name: market_transactions_transaction_id_seq; Type: SEQUENCE; Schema: game; Owner: -
--

CREATE SEQUENCE game.market_transactions_transaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: market_transactions_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: game; Owner: -
--

ALTER SEQUENCE game.market_transactions_transaction_id_seq OWNED BY game.market_transactions.transaction_id;


--
-- Name: market_transactions transaction_id; Type: DEFAULT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.market_transactions ALTER COLUMN transaction_id SET DEFAULT nextval('game.market_transactions_transaction_id_seq'::regclass);


--
-- Data for Name: market_transactions; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.market_transactions (transaction_id, type_id, quantity, price, buyer_id, seller_id, station_id, region_id, date) FROM stdin;
\.


--
-- Name: market_transactions_transaction_id_seq; Type: SEQUENCE SET; Schema: game; Owner: -
--

SELECT pg_catalog.setval('game.market_transactions_transaction_id_seq', 1, false);


--
-- Name: market_transactions market_transactions_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.market_transactions
    ADD CONSTRAINT market_transactions_pkey PRIMARY KEY (transaction_id);


--
-- Name: market_transactions_buyer_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX market_transactions_buyer_idx ON game.market_transactions USING btree (buyer_id, date);


--
-- Name: market_transactions_history_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX market_transactions_history_idx ON game.market_transactions USING btree (region_id, type_id, date);


--
-- Name: market_transactions_seller_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX market_transactions_seller_idx ON game.market_transactions USING btree (seller_id, date);


--
-- PostgreSQL database dump complete
--

\unrestrict ZfgVybCH5VS6VpkWTYPXu7Gw8LPb2JbYCPna8X0saLI03Fnz6i145PcaB5WoItX

