--
-- PostgreSQL database dump
--

\restrict Szhdgcpcx6F7YW6jp0hUk99kd9e2XN962sQzBqRGZ7eKW5xjYJWXjB7BmAojoKg

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: lp_balances; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.lp_balances (
    char_id bigint NOT NULL,
    corp_id bigint NOT NULL,
    amount bigint NOT NULL
);


--
-- Data for Name: lp_balances; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.lp_balances (char_id, corp_id, amount) FROM stdin;
\.


--
-- Name: lp_balances lp_balances_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.lp_balances
    ADD CONSTRAINT lp_balances_pkey PRIMARY KEY (char_id, corp_id);


--
-- PostgreSQL database dump complete
--

\unrestrict Szhdgcpcx6F7YW6jp0hUk99kd9e2XN962sQzBqRGZ7eKW5xjYJWXjB7BmAojoKg

