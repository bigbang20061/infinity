--
-- PostgreSQL database dump
--

\restrict fUVd56xuan55ffFTKGqnmDn7s02D2ZXYRV9D41z0e4EgqOSfVVdSyGGhK4Yf0Fs

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: mail_labels; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.mail_labels (
    char_id bigint NOT NULL,
    label_id integer NOT NULL,
    name text NOT NULL,
    color integer
);


--
-- Data for Name: mail_labels; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.mail_labels (char_id, label_id, name, color) FROM stdin;
\.


--
-- Name: mail_labels mail_labels_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.mail_labels
    ADD CONSTRAINT mail_labels_pkey PRIMARY KEY (char_id, label_id);


--
-- PostgreSQL database dump complete
--

\unrestrict fUVd56xuan55ffFTKGqnmDn7s02D2ZXYRV9D41z0e4EgqOSfVVdSyGGhK4Yf0Fs

