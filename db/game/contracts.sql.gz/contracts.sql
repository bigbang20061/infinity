--
-- PostgreSQL database dump
--

\restrict 5zvRray0vDiiAhRpe7T8W3UOadWbAswnFTwQnEYtYi1eHf8dGv07RQfBfsfgcdB

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: contracts; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.contracts (
    contract_id bigint NOT NULL,
    type integer NOT NULL,
    issuer_id bigint NOT NULL,
    issuer_corp_id bigint NOT NULL,
    assignee_id bigint DEFAULT 0 NOT NULL,
    acceptor_id bigint DEFAULT 0 NOT NULL,
    start_station_id bigint NOT NULL,
    end_station_id bigint DEFAULT 0 NOT NULL,
    price double precision DEFAULT 0 NOT NULL,
    reward double precision DEFAULT 0 NOT NULL,
    collateral double precision DEFAULT 0 NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    volume double precision DEFAULT 0 NOT NULL,
    num_days integer DEFAULT 0 NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    date_issued bigint NOT NULL,
    date_expired bigint NOT NULL,
    date_accepted bigint DEFAULT 0 NOT NULL,
    date_completed bigint DEFAULT 0 NOT NULL,
    package_id bigint
);


--
-- Name: contracts_contract_id_seq; Type: SEQUENCE; Schema: game; Owner: -
--

CREATE SEQUENCE game.contracts_contract_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contracts_contract_id_seq; Type: SEQUENCE OWNED BY; Schema: game; Owner: -
--

ALTER SEQUENCE game.contracts_contract_id_seq OWNED BY game.contracts.contract_id;


--
-- Name: contracts contract_id; Type: DEFAULT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.contracts ALTER COLUMN contract_id SET DEFAULT nextval('game.contracts_contract_id_seq'::regclass);


--
-- Data for Name: contracts; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.contracts (contract_id, type, issuer_id, issuer_corp_id, assignee_id, acceptor_id, start_station_id, end_station_id, price, reward, collateral, title, description, volume, num_days, status, date_issued, date_expired, date_accepted, date_completed, package_id) FROM stdin;
\.


--
-- Name: contracts_contract_id_seq; Type: SEQUENCE SET; Schema: game; Owner: -
--

SELECT pg_catalog.setval('game.contracts_contract_id_seq', 1, false);


--
-- Name: contracts contracts_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.contracts
    ADD CONSTRAINT contracts_pkey PRIMARY KEY (contract_id);


--
-- Name: contracts_acceptor_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX contracts_acceptor_idx ON game.contracts USING btree (acceptor_id);


--
-- Name: contracts_assignee_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX contracts_assignee_idx ON game.contracts USING btree (assignee_id);


--
-- Name: contracts_issuer_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX contracts_issuer_idx ON game.contracts USING btree (issuer_id);


--
-- Name: contracts_status_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX contracts_status_idx ON game.contracts USING btree (status, type);


--
-- PostgreSQL database dump complete
--

\unrestrict 5zvRray0vDiiAhRpe7T8W3UOadWbAswnFTwQnEYtYi1eHf8dGv07RQfBfsfgcdB

