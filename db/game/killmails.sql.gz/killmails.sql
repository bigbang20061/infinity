--
-- PostgreSQL database dump
--

\restrict hFg6dPoWWuOachM7Cb0LpSyiIRPTdbMhVWpw0vcnC4xQu7ovpDUmSU5SxZjNnvr

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: killmails; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.killmails (
    kill_id bigint NOT NULL,
    kill_time bigint NOT NULL,
    solar_system_id bigint NOT NULL,
    victim_id bigint NOT NULL,
    victim_corp_id bigint NOT NULL,
    victim_ship_type integer NOT NULL,
    damage_taken double precision NOT NULL,
    final_char_id bigint,
    final_corp_id bigint,
    final_ship_type integer NOT NULL,
    final_weapon_type integer NOT NULL,
    final_damage double precision NOT NULL,
    final_sec_status double precision NOT NULL,
    isk_lost double precision NOT NULL,
    attacker_ids bigint[] NOT NULL,
    blob text NOT NULL
);


--
-- Name: killmails_kill_id_seq; Type: SEQUENCE; Schema: game; Owner: -
--

CREATE SEQUENCE game.killmails_kill_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: killmails_kill_id_seq; Type: SEQUENCE OWNED BY; Schema: game; Owner: -
--

ALTER SEQUENCE game.killmails_kill_id_seq OWNED BY game.killmails.kill_id;


--
-- Name: killmails kill_id; Type: DEFAULT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.killmails ALTER COLUMN kill_id SET DEFAULT nextval('game.killmails_kill_id_seq'::regclass);


--
-- Data for Name: killmails; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.killmails (kill_id, kill_time, solar_system_id, victim_id, victim_corp_id, victim_ship_type, damage_taken, final_char_id, final_corp_id, final_ship_type, final_weapon_type, final_damage, final_sec_status, isk_lost, attacker_ids, blob) FROM stdin;
\.


--
-- Name: killmails_kill_id_seq; Type: SEQUENCE SET; Schema: game; Owner: -
--

SELECT pg_catalog.setval('game.killmails_kill_id_seq', 1, false);


--
-- Name: killmails killmails_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.killmails
    ADD CONSTRAINT killmails_pkey PRIMARY KEY (kill_id);


--
-- Name: killmails_attackers_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX killmails_attackers_idx ON game.killmails USING gin (attacker_ids);


--
-- Name: killmails_victim_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX killmails_victim_idx ON game.killmails USING btree (victim_id, kill_id);


--
-- PostgreSQL database dump complete
--

\unrestrict hFg6dPoWWuOachM7Cb0LpSyiIRPTdbMhVWpw0vcnC4xQu7ovpDUmSU5SxZjNnvr

