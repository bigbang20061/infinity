--
-- PostgreSQL database dump
--

\restrict 7ETfgAq7UdHcAAejwEB4AiKC57PmCPSt2TnarJlf7OiMuLCvpVdE7e3dCty4k84

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: login_reward_claims; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.login_reward_claims (
    user_id bigint NOT NULL,
    campaign_id integer NOT NULL,
    day date NOT NULL,
    clone_grade integer NOT NULL
);


--
-- Data for Name: login_reward_claims; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.login_reward_claims (user_id, campaign_id, day, clone_grade) FROM stdin;
10000001	2376	2026-10-27	1
\.


--
-- Name: login_reward_claims login_reward_claims_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.login_reward_claims
    ADD CONSTRAINT login_reward_claims_pkey PRIMARY KEY (user_id, campaign_id, day);


--
-- Name: login_reward_claims login_reward_claims_user_id_fkey; Type: FK CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.login_reward_claims
    ADD CONSTRAINT login_reward_claims_user_id_fkey FOREIGN KEY (user_id) REFERENCES game.accounts(user_id);


--
-- PostgreSQL database dump complete
--

\unrestrict 7ETfgAq7UdHcAAejwEB4AiKC57PmCPSt2TnarJlf7OiMuLCvpVdE7e3dCty4k84

