--
-- PostgreSQL database dump
--

\restrict 7qQe7igrGXqE2M0pSwg0GFeXNahYmifLC3xNlJhiMG4Z1m2znu47zFhXh5MsAKf

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: skill_queue; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.skill_queue (
    character_id bigint NOT NULL,
    "position" integer NOT NULL,
    type_id integer NOT NULL,
    to_level integer NOT NULL,
    start_sp bigint NOT NULL,
    dest_sp bigint NOT NULL,
    start_time bigint,
    end_time bigint
);


--
-- Data for Name: skill_queue; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.skill_queue (character_id, "position", type_id, to_level, start_sp, dest_sp, start_time, end_time) FROM stdin;
\.


--
-- Name: skill_queue skill_queue_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.skill_queue
    ADD CONSTRAINT skill_queue_pkey PRIMARY KEY (character_id, "position");


--
-- Name: skill_queue skill_queue_character_id_fkey; Type: FK CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.skill_queue
    ADD CONSTRAINT skill_queue_character_id_fkey FOREIGN KEY (character_id) REFERENCES game.characters(character_id);


--
-- PostgreSQL database dump complete
--

\unrestrict 7qQe7igrGXqE2M0pSwg0GFeXNahYmifLC3xNlJhiMG4Z1m2znu47zFhXh5MsAKf

