--
-- PostgreSQL database dump
--

\restrict kFUv0Ty7TZOCEGJef98uS4PYrdYiFNPWLWDnsJJiggXwfWcyVtZJbQXlZ35KSX8

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: air_npe_state; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.air_npe_state (
    character_id bigint NOT NULL,
    state smallint NOT NULL,
    changed_at bigint NOT NULL
);


--
-- Data for Name: air_npe_state; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.air_npe_state (character_id, state, changed_at) FROM stdin;
\.


--
-- Name: air_npe_state air_npe_state_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.air_npe_state
    ADD CONSTRAINT air_npe_state_pkey PRIMARY KEY (character_id);


--
-- PostgreSQL database dump complete
--

\unrestrict kFUv0Ty7TZOCEGJef98uS4PYrdYiFNPWLWDnsJJiggXwfWcyVtZJbQXlZ35KSX8

