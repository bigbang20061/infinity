--
-- PostgreSQL database dump
--

\restrict m5xRbjsGa6XjUbOrBwQIbLyfdVIGGYYygHgIYVOSA8RRltfxbY1cjAvzgfQiUyj

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bookmark_folders; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.bookmark_folders (
    folder_id bigint NOT NULL,
    owner_id bigint NOT NULL,
    name text NOT NULL,
    description text DEFAULT ''::text NOT NULL
);


--
-- Name: bookmark_folders_folder_id_seq; Type: SEQUENCE; Schema: game; Owner: -
--

CREATE SEQUENCE game.bookmark_folders_folder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bookmark_folders_folder_id_seq; Type: SEQUENCE OWNED BY; Schema: game; Owner: -
--

ALTER SEQUENCE game.bookmark_folders_folder_id_seq OWNED BY game.bookmark_folders.folder_id;


--
-- Name: bookmark_folders folder_id; Type: DEFAULT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.bookmark_folders ALTER COLUMN folder_id SET DEFAULT nextval('game.bookmark_folders_folder_id_seq'::regclass);


--
-- Data for Name: bookmark_folders; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.bookmark_folders (folder_id, owner_id, name, description) FROM stdin;
\.


--
-- Name: bookmark_folders_folder_id_seq; Type: SEQUENCE SET; Schema: game; Owner: -
--

SELECT pg_catalog.setval('game.bookmark_folders_folder_id_seq', 1, false);


--
-- Name: bookmark_folders bookmark_folders_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.bookmark_folders
    ADD CONSTRAINT bookmark_folders_pkey PRIMARY KEY (folder_id);


--
-- Name: bookmark_folders_owner_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX bookmark_folders_owner_idx ON game.bookmark_folders USING btree (owner_id);


--
-- PostgreSQL database dump complete
--

\unrestrict m5xRbjsGa6XjUbOrBwQIbLyfdVIGGYYygHgIYVOSA8RRltfxbY1cjAvzgfQiUyj

