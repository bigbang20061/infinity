--
-- PostgreSQL database dump
--

\restrict JktK97TmSKOt942VJ2IBzleCXOYiyo4H3GjiMzyHOjuLAwxcA3Pj1QoqHX51aJ6

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: notifications; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.notifications (
    notification_id bigint NOT NULL,
    receiver_id bigint NOT NULL,
    type_id integer NOT NULL,
    group_id integer NOT NULL,
    sender_id bigint NOT NULL,
    created bigint NOT NULL,
    processed boolean DEFAULT false NOT NULL,
    data text DEFAULT '{}'::text NOT NULL
);


--
-- Name: notifications_notification_id_seq; Type: SEQUENCE; Schema: game; Owner: -
--

CREATE SEQUENCE game.notifications_notification_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_notification_id_seq; Type: SEQUENCE OWNED BY; Schema: game; Owner: -
--

ALTER SEQUENCE game.notifications_notification_id_seq OWNED BY game.notifications.notification_id;


--
-- Name: notifications notification_id; Type: DEFAULT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.notifications ALTER COLUMN notification_id SET DEFAULT nextval('game.notifications_notification_id_seq'::regclass);


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.notifications (notification_id, receiver_id, type_id, group_id, sender_id, created, processed, data) FROM stdin;
\.


--
-- Name: notifications_notification_id_seq; Type: SEQUENCE SET; Schema: game; Owner: -
--

SELECT pg_catalog.setval('game.notifications_notification_id_seq', 1, false);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (notification_id);


--
-- Name: notifications_receiver_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX notifications_receiver_idx ON game.notifications USING btree (receiver_id, notification_id);


--
-- PostgreSQL database dump complete
--

\unrestrict JktK97TmSKOt942VJ2IBzleCXOYiyo4H3GjiMzyHOjuLAwxcA3Pj1QoqHX51aJ6

