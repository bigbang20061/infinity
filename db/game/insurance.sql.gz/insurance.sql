--
-- PostgreSQL database dump
--

\restrict EjfhxCroGtxeAQX9a9Hi5QAcxQ67tviydGidbErcdXDFgE8xqQbgEGu4gH5jNqy

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: insurance; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.insurance (
    ship_id bigint NOT NULL,
    owner_id bigint NOT NULL,
    type_id integer NOT NULL,
    fraction double precision NOT NULL,
    start_date bigint NOT NULL,
    end_date bigint NOT NULL
);


--
-- Data for Name: insurance; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.insurance (ship_id, owner_id, type_id, fraction, start_date, end_date) FROM stdin;
\.


--
-- Name: insurance insurance_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.insurance
    ADD CONSTRAINT insurance_pkey PRIMARY KEY (ship_id);


--
-- Name: insurance_owner_idx; Type: INDEX; Schema: game; Owner: -
--

CREATE INDEX insurance_owner_idx ON game.insurance USING btree (owner_id);


--
-- PostgreSQL database dump complete
--

\unrestrict EjfhxCroGtxeAQX9a9Hi5QAcxQ67tviydGidbErcdXDFgE8xqQbgEGu4gH5jNqy

