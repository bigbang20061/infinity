--
-- PostgreSQL database dump
--

\restrict 4FErEml1ClUfVa7VnhLGPDFn1Ctkpz9xDz4yKc63QbLuhf4RceZBsaeoVXapvEN

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: standings; Type: TABLE; Schema: game; Owner: -
--

CREATE TABLE game.standings (
    char_id bigint NOT NULL,
    from_id bigint NOT NULL,
    standing double precision NOT NULL
);


--
-- Data for Name: standings; Type: TABLE DATA; Schema: game; Owner: -
--

COPY game.standings (char_id, from_id, standing) FROM stdin;
\.


--
-- Name: standings standings_pkey; Type: CONSTRAINT; Schema: game; Owner: -
--

ALTER TABLE ONLY game.standings
    ADD CONSTRAINT standings_pkey PRIMARY KEY (char_id, from_id);


--
-- PostgreSQL database dump complete
--

\unrestrict 4FErEml1ClUfVa7VnhLGPDFn1Ctkpz9xDz4yKc63QbLuhf4RceZBsaeoVXapvEN

