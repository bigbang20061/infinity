--
-- PostgreSQL database dump
--

\restrict 3gqEGwW96fgmHPjN7IhX8um9aof5mYFd1U4gJdaM8AiPCssrkGTh2uvaBoqkodK

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: inv_categories; Type: TABLE; Schema: sde; Owner: -
--

CREATE TABLE sde.inv_categories (
    category_id integer NOT NULL,
    name text,
    published boolean,
    icon_id integer,
    data jsonb
);


--
-- Data for Name: inv_categories; Type: TABLE DATA; Schema: sde; Owner: -
--

COPY sde.inv_categories (category_id, name, published, icon_id, data) FROM stdin;
0	#System	f	\N	{"_key": 0, "name": {"en": "#System"}, "published": false}
1	Owner	f	\N	{"_key": 1, "name": {"en": "Owner"}, "published": false}
2	Celestial	t	\N	{"_key": 2, "name": {"en": "Celestial"}, "published": true}
3	Station	f	\N	{"_key": 3, "name": {"en": "Station"}, "published": false}
4	Material	t	\N	{"_key": 4, "name": {"en": "Material"}, "published": true}
5	Accessories	t	\N	{"_key": 5, "name": {"en": "Accessories"}, "published": true}
6	Ship	t	\N	{"_key": 6, "name": {"en": "Ship"}, "published": true}
7	Module	t	\N	{"_key": 7, "name": {"en": "Module"}, "published": true}
8	Charge	t	\N	{"_key": 8, "name": {"en": "Charge"}, "published": true}
9	Blueprint	t	\N	{"_key": 9, "name": {"en": "Blueprint"}, "published": true}
10	Trading	f	\N	{"_key": 10, "name": {"en": "Trading"}, "published": false}
11	Entity	f	\N	{"_key": 11, "name": {"en": "Entity"}, "published": false}
14	Bonus	f	\N	{"_key": 14, "name": {"en": "Bonus"}, "published": false}
16	Skill	t	\N	{"_key": 16, "name": {"en": "Skill"}, "published": true}
17	Commodity	t	\N	{"_key": 17, "name": {"en": "Commodity"}, "published": true}
18	Drone	t	\N	{"_key": 18, "name": {"en": "Drone"}, "published": true}
20	Implant	t	\N	{"_key": 20, "name": {"en": "Implant"}, "published": true}
22	Deployable	t	\N	{"_key": 22, "name": {"en": "Deployable"}, "published": true}
23	Starbase	f	\N	{"_key": 23, "name": {"en": "Starbase"}, "published": false}
24	Reaction	t	\N	{"_key": 24, "name": {"en": "Reaction"}, "published": true}
25	Asteroid	t	\N	{"_key": 25, "name": {"en": "Asteroid"}, "published": true}
26	WorldSpace	f	\N	{"_key": 26, "name": {"en": "WorldSpace"}, "published": false}
29	Abstract	f	\N	{"_key": 29, "name": {"en": "Abstract"}, "published": false}
30	Apparel	t	\N	{"_key": 30, "name": {"en": "Apparel"}, "published": true}
32	Subsystem	t	\N	{"_key": 32, "name": {"en": "Subsystem"}, "published": true}
34	Ancient Relics	t	\N	{"_key": 34, "name": {"en": "Ancient Relics"}, "published": true}
35	Decryptors	t	\N	{"_key": 35, "name": {"en": "Decryptors"}, "published": true}
39	Infrastructure Upgrades	t	\N	{"_key": 39, "name": {"en": "Infrastructure Upgrades"}, "published": true}
40	Sovereignty Structures	t	\N	{"_key": 40, "name": {"en": "Sovereignty Structures"}, "published": true}
41	Planetary Industry	t	\N	{"_key": 41, "name": {"en": "Planetary Industry"}, "published": true}
42	Planetary Resources	t	\N	{"_key": 42, "name": {"en": "Planetary Resources"}, "published": true}
43	Planetary Commodities	t	\N	{"_key": 43, "name": {"en": "Planetary Commodities"}, "published": true}
46	Orbitals	t	\N	{"_key": 46, "name": {"en": "Orbitals"}, "published": true}
49	Placeables	f	\N	{"_key": 49, "name": {"en": "Placeables"}, "published": false}
53	Effects	f	\N	{"_key": 53, "name": {"en": "Effects"}, "published": false}
54	Lights	f	\N	{"_key": 54, "name": {"en": "Lights"}, "published": false}
59	Cells	f	\N	{"_key": 59, "name": {"en": "Cells"}, "published": false}
63	Special Edition Assets	t	\N	{"_key": 63, "name": {"en": "Special Edition Assets"}, "published": true}
65	Structure	t	\N	{"_key": 65, "name": {"en": "Structure"}, "published": true}
66	Structure Module	t	\N	{"_key": 66, "name": {"en": "Structure Module"}, "published": true}
87	Fighter	t	\N	{"_key": 87, "name": {"en": "Fighter"}, "published": true}
91	SKINs	t	\N	{"_key": 91, "name": {"en": "SKINs"}, "published": true}
2100	Expert Systems	t	\N	{"_key": 2100, "name": {"en": "Expert Systems"}, "published": true}
2107	Mining	f	\N	{"_key": 2107, "name": {"en": "Mining"}, "published": false}
2113	Refurbished Component	t	\N	{"_key": 2113, "name": {"en": "Refurbished Component"}, "published": true}
2116	Module Refurbish Component	t	\N	{"_key": 2116, "name": {"en": "Module Refurbish Component"}, "published": true}
2117	Drone Refurbish Component	t	\N	{"_key": 2117, "name": {"en": "Drone Refurbish Component"}, "published": true}
2118	Personalization	t	\N	{"_key": 2118, "name": {"en": "Personalization"}, "published": true}
2120	BrawlShip Entropy Module	f	\N	{"_key": 2120, "name": {"en": "BrawlShip Entropy Module"}, "published": false}
2125	Structure Skin	t	\N	{"_key": 2125, "name": {"en": "Structure Skin"}, "published": true}
2126	Amplification Matrix	t	\N	{"_key": 2126, "name": {"en": "Amplification Matrix"}, "published": true}
2127	Amplification Matrix Materials	t	\N	{"_key": 2127, "name": {"en": "Amplification Matrix Materials"}, "published": true}
2128	CEVE Chest	f	\N	{"_key": 2128, "name": {"en": "CEVE Chest"}, "published": false}
2143	Colony Resources	t	\N	{"_key": 2143, "name": {"en": "Colony Resources"}, "published": true}
2152	QA and Dev Groups	f	\N	{"_key": 2152, "name": {"en": "QA and Dev Groups"}, "published": false}
350001	Infantry	f	\N	{"_key": 350001, "name": {"en": "Infantry"}, "published": false}
\.


--
-- Name: inv_categories inv_categories_pkey; Type: CONSTRAINT; Schema: sde; Owner: -
--

ALTER TABLE ONLY sde.inv_categories
    ADD CONSTRAINT inv_categories_pkey PRIMARY KEY (category_id);


--
-- PostgreSQL database dump complete
--

\unrestrict 3gqEGwW96fgmHPjN7IhX8um9aof5mYFd1U4gJdaM8AiPCssrkGTh2uvaBoqkodK

