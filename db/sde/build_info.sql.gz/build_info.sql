--
-- PostgreSQL database dump
--

\restrict Ysz82zhAdP2hexUmen91aUQJsNdjMk4hXcnDW5TLhWcK13e5uCa9jbWqVMCJeQz

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: build_info; Type: TABLE; Schema: sde; Owner: -
--

CREATE TABLE sde.build_info (
    build_number integer,
    release_date text
);


--
-- Data for Name: build_info; Type: TABLE DATA; Schema: sde; Owner: -
--

COPY sde.build_info (build_number, release_date) FROM stdin;
3653293	2026-10-27T00:50:27.764795Z
\.


--
-- PostgreSQL database dump complete
--

\unrestrict Ysz82zhAdP2hexUmen91aUQJsNdjMk4hXcnDW5TLhWcK13e5uCa9jbWqVMCJeQz

